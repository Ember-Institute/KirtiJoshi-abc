本目录是 `Genl.HeightTheory.StatementII` 纯定义的源／目标完整表达式审查草稿。仅写/tmp；未编译、未调用CI/API/Git，未改主工作区。

源码纯定义位于原 `Genl.GeneralPosition.HeightTheory` 模块，旧缓存 `.olean` 确实存在。`configs/source-config.json` pin 原 HeightTheory.lean 的完整文本／SHA及原缓存SHA；查询的真实 imported owner 经 actual module index 验证，不从pretty-printer恢复名字。源码读取的是 `ConstantInfo.type` 和 `.defnInfo.value`，没有读取任何来源 theorem proof。

入口：

1. 源4.35：`queries/SourceStatementIIDefinition.lean`，环境 `STATEMENTII_DEFINITION_CONFIG=<absolute configs/source-config.json>`。只import cached `Genl.GeneralPosition.HeightTheory`。复用主界173声明 exporter的原4.35 Expr codec、structural Name、owner API与memoized公理查询。新逻辑限于这一条纯定义：导出 actual Name/owner/levelParams/完整TYPE/value、全树BinderInfo、telescope和直接TYPE/value常量的actualName/owner/kind；递归公理只准标准三公理。
2. 先把此前v57纯Definition候选安装到目标工作区，执行目标4.33首次叶和产物检查。此目录未复制或修改主区文件。
3. `bind_target.py --source-facts <actual source JSON> --source-receipt <actual successful receipt> --target-leaf <receipt> --target-artifact <receipt>`。脚本绑定source事实与真实config/receipt/manifest SHA，核对原source/cache未变，检查所有actual项目常量都有现成具名data映射或显式closed Prop支持记录，绑定安装目标完整文本和实际CI。输出 `bound/final.json` 及 `maps/actual-source-selection.json`。脚本只绑定，不把Boolean或静态操作当成内核验收。
4. 目标4.33：`queries/TargetStatementIIDefinition.lean`，同一环境键指向bound/final.json。复用已验收c2审查的target Expr codec、Kernel.check/isDefEq、TYPE/value解码和全树BinderInfo位置算法。每个具名target data constant由actual owner核验，未猜任何宇宙置换。源／目标完整TYPE和完整definition value都由Kernel.check验证，两个value的推得type与其记录TYPE分别比较，随后比较两边完整TYPE与完整value。TYPE/value的BinderInfo顺序及每个树位置分别要求一致，不能用kernel忽略BinderInfo来冒充严格一致。

`maps/data-map.candidate.json` 的10项是实际现有data名候选：HeightTheory本身、8个字段投影和原全局DiscrepancyLE。它们分别来自已经发布的HeightTheory和BoundedDiscrepancy包，带真实平台Definition ID、owner和当前源码SHA。这不是声明实际Expr里必有十个常量，运行source exporter后应按actual constants选择。不得把“十一项generic theorem候选map”误用为这一条pure def的actual计数。

若完整TYPE/value含额外项目常量，查询只允许显式导出并递归处理**无宇宙参数、闭合的命题证明值**。任何未映射data或非闭合／有宇宙参数命题支持均停止报错，不能替换为假设或默默吞掉。源和目标所有实际support type/value、公理和Name都会保留，目标用Kernel.check核验这些closed Prop的actual proof Expr及其type后再做明确的proof-only展开。即使预期support为空，也不能预填为空冒充真实输出。

源config需要主智能体的实际独占manifest包含query、config、原source文件和`.olean`缓存的SHA；source配置pin缓存SHA本身不等于证明缓存来自当前源码，原缓存来源回执仍应按已有接受记录引用。目标manifest同理应含bound config、事实、纯Definition和产物；所有新叶首次60s/16GiB，后续按真实回执估计。

`replay-command-span-plan.json` 单独保留后续 `Iut.statementII_of_cor312` 源replay的原始范围候选和AST重新绑定流程。行坐标／raw SHA不是已经运行的AST结果；接受真实source AST后，再从完整declaration/context/proof spans生成narrow replay，不能把显示名称推成actual compiler Name。本目录的pure def审查不需要该theorem replay先通过，也不声称generic StatementII已被证明或与项目canonical高度身份相同。

目标审查成功只接受纯定义、完整type/value和对应公理，不接受任何StatementII命题证明。compactly bounded中文译名仍占位，按用户答复后替换，不阻塞形式审查。
