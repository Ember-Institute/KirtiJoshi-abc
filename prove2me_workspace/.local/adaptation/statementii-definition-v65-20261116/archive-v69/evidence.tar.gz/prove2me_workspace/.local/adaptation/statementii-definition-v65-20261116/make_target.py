from pathlib import Path
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
tp=W/'.local/adaptation/c2-open-v48-20261116/target/AuditOpenStatementType.lean';tt=tp.read_text();a=tt.index('/-! Stable JSON');b=tt.index('\ndef actualTargetProof');targetCore=tt[a:b]+'\nend FoundationAudit\n'
sp=(D/'queries/SourceStatementIIDefinition.lean').read_text();start=sp.index('namespace StatementIIDefinitionAudit');end=sp.index('\nend StatementIIDefinitionAudit',start)+len('\nend StatementIIDefinitionAudit');shared=sp[start:end]
rest=r'''
namespace StatementIIDefinitionAudit
open Lean Elab Term Meta FoundationAudit

def boundJson (binding : Json) : MetaM Json := do
  if binding == Json.null then throwError "Pending root receipt/facts binding"
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do throwError "Bound JSON contents changed"
  unless (← checked (stringField binding "sha256")).length == 64 do throwError "Missing SHA binding"
  return actual

def passedReceipt (binding : Json) : MetaM Json := do
  let r ← boundJson binding
  unless (← checked (stringField r "status")) == "succeeded" do throwError "Receipt not succeeded"
  let result ← checked (field r "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Receipt failed"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Expected actual exclusive-worktree receipt"
  return r

def targetClosedProofs (known : Array Name) (root : Name) (exprs : Array Expr) : MetaM (Array Json) := do
  let env ← getEnv
  let mut queue : Array Name := #[]
  for e in exprs do
    for n in e.getUsedConstants do
      if projectOwned env n && !known.contains n && !queue.contains n then queue := queue.push n
  let mut rows : Array Json := #[]
  let mut index := 0
  while index < queue.size do
    let n := queue[index]!
    index := index + 1
    if n == root then throwError "Target root recursively appears in its own type/value"
    let ci ← getConstInfo n
    unless ci.levelParams.isEmpty && (← isProp ci.type) do
      throwError "Unmapped target data or nonclosed proposition support {n}; never substitute data"
    let value ← supportValue ci
    expressionClosed s!"target support type {n}" ci.type
    expressionClosed s!"target support value {n}" value
    let axs ← collectAxioms n
    let taxs ← expressionAxioms ci.type
    let vaxs ← expressionAxioms value
    for xs in #[axs,taxs,vaxs] do ensureStandard s!"target closed proposition {n}" xs
    for e in #[ci.type,value] do
      for dep in e.getUsedConstants do
        if projectOwned env dep && !known.contains dep && !queue.contains dep then queue := queue.push dep
    rows := rows.push (Json.mkObj [
      ("name",toJson n.toString),("nameExpr",encodeName n),
      ("owner",(moduleOf env n).map encodeName |>.getD Json.null),
      ("isProposition",toJson true),("isClosed",toJson true),("levelParams",Json.arr #[]),
      ("actualTypeExpr",← checked (encodeExpr ci.type)),
      ("actualProofExpr",← checked (encodeExpr value)),
      ("axioms",toJson (axs.map Name.toString)),("typeAxioms",toJson (taxs.map Name.toString)),
      ("proofAxioms",toJson (vaxs.map Name.toString))])
  return rows

def validateClosedProofRows (names : TypeNames) (rows : Array Json) : MetaM Unit := do
  for row in rows do
    let n ← checked (decodeName (← checked (field row "nameExpr")))
    unless (← checked (row.getObjValAs? Bool "isProposition")) &&
        (← checked (row.getObjValAs? Bool "isClosed")) &&
        (← checked (arrayField row "levelParams")).isEmpty do
      throwError "Nonclosed/non-Prop support in explicit resolution {n}"
    let t ← checked (decodeType names rows #[] true (← checked (field row "actualTypeExpr")))
    let v ← checked (decodeType names rows #[n] true (← checked (field row "actualProofExpr")))
    let vt ← kernelCheck s!"actual closed support proof {n}" v
    unless ← isProp vt do throwError "Data substitution prohibited in support resolution {n}"
    kernelTypeEq s!"closed support type/value {n}" vt t
    for key in #["axioms","typeAxioms","proofAxioms"] do
      for ax in ← checked (arrayField row key) do
        unless (standardAxioms.map fun a => Json.str a.toString).contains ax do
          throwError "Nonstandard source/target support axiom {n}"
    ensureStandard s!"expanded support proof {n}" (← expressionAxioms v)

def mappedNames (cfg : Json) : MetaM (TypeNames × Array Name) := do
  let mut names : TypeNames := #[]
  let mut targets : Array Name := #[]
  for row in ← checked (arrayField cfg "dataMap") do
    let src ← checked (decodeName (← checked (field row "sourceNameExpr")))
    let dst ← checked (decodeName (← checked (field row "targetNameExpr")))
    let owner ← checked (decodeName (← checked (field row "targetOwnerExpr")))
    unless moduleOf (← getEnv) dst == some owner do throwError "Mapped target data owner differs: {dst}"
    unless (← checked (field row "targetToSourceUniverseIndices")) == Json.null do
      throwError "No unverified universe permutation is allowed: {src}"
    if names.any (·.1 == src) then throwError "Duplicate source data mapping {src}"
    names := names.push (src,dst)
    if !names.any (·.1 == dst) then names := names.push (dst,dst)
    unless targets.contains dst do targets := targets.push dst
  return (names,targets)

run_meta do
  let cfg ← jsonFile (← absoluteEnv "STATEMENTII_DEFINITION_CONFIG")
  unless (← checked (stringField cfg "schema")) == "statementii-target-definition-config/v58" do throwError "Wrong target definition configuration"
  unless Lean.versionString == "4.33.1" do throwError "Wrong target compiler"
  let _ ← passedReceipt (← checked (field cfg "sourceReceipt"))
  let _ ← passedReceipt (← checked (field cfg "targetLeafReceipt"))
  let _ ← passedReceipt (← checked (field cfg "targetArtifactReceipt"))
  let facts ← boundJson (← checked (field cfg "sourceFactsBinding"))
  unless (← checked (stringField facts "schema")) == "statementii-source-definition-facts/v58" &&
      (← checked (stringField facts "name")) == "Genl.HeightTheory.StatementII" &&
      (← checked (facts.getObjValAs? Bool "definitionValueRead")) &&
      !(← checked (facts.getObjValAs? Bool "sourceTheoremProofRead")) do throwError "Wrong source pure-definition facts"
  let sourceOwner ← checked (decodeName (← checked (field facts "owner")))
  unless sourceOwner == `Genl.GeneralPosition.HeightTheory do throwError "Wrong actual source owner"
  let sourceName ← checked (decodeName (← checked (field facts "nameExpr")))
  unless sourceName == `Genl.HeightTheory.StatementII do throwError "Source actual Name differs"
  let owner ← checked (decodeName (← checked (field cfg "targetOwnerExpr")))
  let n ← actualNamedConstant (← checked (stringField cfg "targetName")) owner
  let ci ← getConstInfo n
  let value ← actualDefinitionValue "target StatementII" ci
  let text ← IO.FS.readFile (← checked (stringField cfg "installedSource"))
  unless text == (← checked (stringField cfg "expectedTargetSourceText")) do throwError "Installed target definition changed"
  let (names,knownTargets) ← mappedNames cfg
  let sourceProofs ← checked (arrayField facts "closedPropSupportValues")
  let targetProofs ← targetClosedProofs knownTargets n #[ci.type,value]
  validateClosedProofRows names sourceProofs
  validateClosedProofRows names targetProofs
  let sourceType ← checked (decodeType names sourceProofs #[] true (← checked (field facts "typeExpr")))
  let sourceValue ← checked (decodeType names sourceProofs #[] true (← checked (field facts "valueExpr")))
  let targetType ← checked (decodeType names targetProofs #[] true (← checked (encodeExpr ci.type)))
  let targetValue ← checked (decodeType names targetProofs #[] true (← checked (encodeExpr value)))
  let sourceParams ← namesFromJson (← checked (field facts "levelParams"))
  unless sourceParams.length == ci.levelParams.length do throwError "Definition universe arity differs"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let st := sourceType.instantiateLevelParams sourceParams canonical
  let sv := sourceValue.instantiateLevelParams sourceParams canonical
  let tt := targetType.instantiateLevelParams ci.levelParams canonical
  let tv := targetValue.instantiateLevelParams ci.levelParams canonical
  kernelTypeEq "complete source/target definition TYPE" st tt
  kernelTypeEq "source definition value has its recorded TYPE" (← kernelCheck "source definition value" sv) st
  kernelTypeEq "target definition value has its recorded TYPE" (← kernelCheck "target definition value" tv) tt
  kernelTermEq "complete source/target definition value" sv tv
  let sourceTypeRaw ← checked (decodeType names sourceProofs #[] false (← checked (field facts "typeExpr")))
  let sourceValueRaw ← checked (decodeType names sourceProofs #[] false (← checked (field facts "valueExpr")))
  unless binderInventory sourceTypeRaw == binderInventory ci.type &&
      binderPlacement sourceTypeRaw == binderPlacement ci.type do throwError "Full TYPE BinderInfo differs"
  unless binderInventory sourceValueRaw == binderInventory value &&
      binderPlacement sourceValueRaw == binderPlacement value do throwError "Full definition value BinderInfo differs"
  let axs ← collectAxioms n
  let taxs ← expressionAxioms ci.type
  let vaxs ← expressionAxioms value
  for xs in #[axs,taxs,vaxs] do ensureStandard "actual target pure definition" xs
  for m in (← getEnv).header.moduleNames do
    if #[`Iut,`Genl,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf m) then
      throwError "Original project import leaked into target audit: {m}"
  let constants ← #[ci.type,value].mapM fun e => do
    e.getUsedConstants.qsort Name.lt |>.mapM fun c => do
      return Json.mkObj [
        ("name",toJson c.toString),("nameExpr",encodeName c),
        ("owner",(moduleOf (← getEnv) c).map encodeName |>.getD Json.null)]
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "statementii-definition-type-value-audit/v58"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("sourceName",toJson sourceName.toString),("targetName",toJson n.toString),
    ("targetNameExpr",encodeName n),("targetOwner",encodeName owner),
    ("sourceLevelParams",← checked (field facts "levelParams")),
    ("targetLevelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("sourceTypeExpr",← checked (field facts "typeExpr")),("sourceValueExpr",← checked (field facts "valueExpr")),
    ("targetTypeExpr",← checked (encodeExpr ci.type)),("targetValueExpr",← checked (encodeExpr value)),
    ("sourceClosedPropSupportValues",Json.arr sourceProofs),("targetClosedPropSupportValues",Json.arr targetProofs),
    ("completeKernelTypeEqual",toJson true),("completeKernelValueEqual",toJson true),
    ("fullTypeBinderInventoryEqual",toJson true),("fullTypeBinderPlacementEqual",toJson true),
    ("fullValueBinderInventoryEqual",toJson true),("fullValueBinderPlacementEqual",toJson true),
    ("sourceValueKernelHasRecordedType",toJson true),("targetValueKernelHasRecordedType",toJson true),
    ("typeConstants",Json.arr constants[0]!), ("valueConstants",Json.arr constants[1]!),
    ("targetAxioms",toJson (axs.map Name.toString)),("targetTypeAxioms",toJson (taxs.map Name.toString)),
    ("targetValueAxioms",toJson (vaxs.map Name.toString)),("targetSorryAx",toJson false),
    ("pureDefinitionAccepted",toJson true),("proofOfStatementIIClaimed",toJson false)]).pretty ++ "\n")
  logInfo "Pure StatementII definition full TYPE/value and BinderInfo accepted; no theorem proof is claimed"
end StatementIIDefinitionAudit
'''
(D/'queries/TargetStatementIIDefinition.lean').write_text('import Lean\nimport Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII\n\n'+targetCore+'\n'+shared+'\n'+rest)
