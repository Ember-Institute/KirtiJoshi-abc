#!/usr/bin/env python3
"""Bind actual source definition facts and real CI receipts; no compiler/API/Git use."""
from pathlib import Path
import argparse,json,hashlib,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def binding(p):
 p=Path(p).resolve();return {'path':str(p),'sha256':sha(p),'contents':read(p)}
def receipt(p):
 b=binding(p);r=b['contents'];assert r['status']=='succeeded'and r['result']['exit_code']==0
 assert r['request']['workspace']==str(W)and r['request']['exclusive']is True
 s=r['result']['snapshot'];assert s['workspace_mode']=='exclusive_worktree'and s['snapshot_id']is None
 return b
def nm(n):return ''if not n else nm(n[0])+('.'if n[0]else'')+str(n[2])
ap=argparse.ArgumentParser();ap.add_argument('--source-facts',type=Path,required=True);ap.add_argument('--source-receipt',type=Path,required=True);ap.add_argument('--target-leaf',type=Path,required=True);ap.add_argument('--target-artifact',type=Path,required=True);ap.add_argument('--out',type=Path,default=D/'bound/final.json');a=ap.parse_args()
c=read(D/'configs/target-config.template.json');f=binding(a.source_facts);s=f['contents'];assert s['schema']=='statementii-source-definition-facts/v58'and s['definitionValueRead']is True and s['sourceTheoremProofRead']is False
assert s['name']=='Genl.HeightTheory.StatementII'and nm(s['nameExpr'])==s['name']and nm(s['owner'])=='Genl.GeneralPosition.HeightTheory'
r=receipt(a.source_receipt);cfg=Path(r['contents']['request']['environment']['STATEMENTII_DEFINITION_CONFIG']);sc=read(cfg);assert sc==s['configuration'];assert r['contents']['request']['worktree_manifest']['input_hashes'].get(str(cfg))==sha(cfg)
assert sha(sc['sourcePath'])==sc['sourceSha256'];assert Path(sc['sourcePath']).read_text()==sc['expectedSourceText'];assert sha(sc['sourceCache']['path'])==sc['sourceCache']['sha256']
# Source actual ConstantInfo names and owners must match every selected named-data identity.
rows=c['dataMap'];known={x['sourceName']:x for x in rows};assert len(known)==len(rows)
for row in rows:
 assert nm(row['sourceNameExpr'])==row['sourceName'];assert nm(row['targetNameExpr'])==row['targetName'];assert nm(row['sourceOwnerExpr'])==row['sourceOwner'];assert nm(row['targetOwnerExpr'])==row['targetOwner'];assert row['targetToSourceUniverseIndices']is None;assert sha(row['definitionSource'])==row['definitionSourceSha256']
constants={nm(x['nameExpr']):x for k in ['typeConstants','valueConstants']for x in s[k]}
for n,x in constants.items():
 if n in known:assert nm(x['owner'])==known[n]['sourceOwner']
proofs=s['closedPropSupportValues'];proofnames={nm(x['nameExpr'])for x in proofs};assert len(proofnames)==len(proofs)
for x in proofs:
 assert x['isProposition']is True and x['isClosed']is True and x['levelParams']==[]
 for k in ['axioms','typeAxioms','proofAxioms']:assert set(x[k])<={'propext','Classical.choice','Quot.sound'}
used=set()
def walk(x):
 if isinstance(x,dict):
  if x.get('kind')in ['const','proj']:
   n=nm(x['name'])
   if n.startswith(('Genl.','Iut.','_private.','AbcAdaptation.'))or n=='DiscrepancyLE':used.add(n)
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
for k in ['typeExpr','valueExpr']:walk(s[k])
for x in proofs:walk(x['actualTypeExpr']);walk(x['actualProofExpr'])
assert used<=set(known)|proofnames,('Unmapped actual source data/Prop names',sorted(used-set(known)-proofnames))
for k in ['axioms','typeAxioms','valueAxioms']:assert set(s[k])<={'propext','Classical.choice','Quot.sound'}
target=Path(c['installedSource']);assert target.read_text()==c['expectedTargetSourceText']
for key,p in [('targetLeafReceipt',a.target_leaf),('targetArtifactReceipt',a.target_artifact)]:
 b=receipt(p);assert b['contents']['request']['worktree_manifest']['input_hashes'].get(str(target))==sha(target);c[key]=b
c['sourceFactsBinding']=f;c['sourceReceipt']=r;c['sourceFactsMode']='actual cached pure definition TYPE/value; no source theorem proof';c['kernelTypeValueAuditPending']=True
out=a.out.resolve();assert out.is_relative_to(D);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
selection={'sourceFactsPath':f['path'],'sourceFactsSha256':f['sha256'],'actualSourceProjectNames':sorted(used),'actualNamedDataSelection':sorted(used&set(known)),'closedSourcePropSupportNames':sorted(proofnames),'closedSourcePropSupportRecordsRetained':proofs,'allActualSourceDataNamesMapped':True,'sourceOwnersChecked':True,'kernelProofResolutionPerformedByBinder':False,'targetKernelTypeValueAuditRequired':True}
(D/'maps/actual-source-selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n');print(out,sha(out))
