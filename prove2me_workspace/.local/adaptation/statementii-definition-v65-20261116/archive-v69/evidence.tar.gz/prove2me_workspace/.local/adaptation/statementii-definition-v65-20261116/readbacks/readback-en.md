# Independent formal-definition readback — English

Reader model: `gpt-6.1-sol`. This is a readback of the definition of `StatementII` and its supplied formal context. It does not assert that the defined proposition has been proved.

Fix a universe level \(u\) and a height-theory structure \(T\). Its formal data consist of a type \(\operatorname{Curve}\) in that universe; a type \(\operatorname{Pt}(X)\) in that same universe for each \(X\in\operatorname{Curve}\); two predicates \(\operatorname{Hyperbolic}\) and \(\operatorname{DivisorFree}\) on \(\operatorname{Curve}\); and, for each \(X\) and natural number \(n\), subsets \(\operatorname{ptLE}(X,n)\) and \(\operatorname{ptEQ}(X,n)\) of \(\operatorname{Pt}(X)\). The structure requires

\[
\operatorname{ptLE}(X,0)=\varnothing,\qquad
\operatorname{ptLE}(X,n+1)=\operatorname{ptLE}(X,n)\cup\operatorname{ptEQ}(X,n+1)
\]

for every \(X\) and \(n\). It also supplies three real-valued functions \(h_X,\delta_X,\kappa_X:\operatorname{Pt}(X)\to\mathbb R\), corresponding respectively to `htCan`, `logDiff`, and `logCond`; a distinguished element \(P=\operatorname{tripod}\in\operatorname{Curve}\) with \(\operatorname{Hyperbolic}(P)\); a type \(\mathcal K=T.\mathrm{CBS}\) in that same universe; and a map \(S=T.\mathrm{cbsSet}:\mathcal K\to\mathcal P(\operatorname{Pt}(P))\).

Here these are abstract types, predicates, subsets, and functions. In particular, no topology, support map, fixed set of primes, field of definition, or numerical degree function is part of this structure. The names of the data do not impose additional geometric or arithmetic laws. The functions \(h_X,\delta_X,\kappa_X\) have no sign or compatibility conditions in the supplied structure. The elements of \(\mathcal K\) are the objects labelled “compactly bounded subsets” in the code, with underlying subsets \(S(K)\); the formal requirements on them are exactly the type and map just described.

For this fixed \(T\), `StatementII` is the following proposition: for every natural number \(d\in\mathbb N\), every real number \(\varepsilon\in\mathbb R\), if \(\varepsilon>0\), then for every \(K\in\mathcal K\) there exists a real number \(C\in\mathbb R\) such that every \(x\in\operatorname{Pt}(P)\) satisfies

\[
x\in S(K)\cap\operatorname{ptLE}(P,d)
\quad\Longrightarrow\quad
h_P(x)\le (1+\varepsilon)\bigl(\delta_P(x)+\kappa_P(x)\bigr)+C.
\]

Thus the quantifier order is: fix \(T\); choose \(d\); choose \(\varepsilon\); assume \(\varepsilon>0\); choose \(K\); obtain \(C\); then consider every \(x\) in the specified subset. The constant \(C\) may depend on \(T,d,\varepsilon,K\), and is uniform in \(x\). It is an arbitrary real constant: neither \(C>0\) nor \(C\ge0\) is required. The only numerical positivity hypothesis in the definition is \(\varepsilon>0\). There is no requirement \(d>0\).

The finite natural-number bound \(d\) restricts the domain through the supplied subset \(\operatorname{ptLE}(P,d)\). This does not assert that this subset is finite, and the code does not identify it with points having a particular field-theoretic degree. When \(d=0\), that subset is empty by the stated structure law, so the condition on \(x\) is vacuous. If \(S(K)\) or its intersection with the restricted domain is empty, the condition is also vacuous. The structure does not require \(\mathcal K\) to be inhabited.

The displayed inequality expands the notation `≲`: for real-valued functions \(f,g\) on a common type and a subset \(A\), \(f\lesssim_A g\) means that some real \(C\) satisfies \(f(x)\le g(x)+C\) for every \(x\in A\). It is an upper bound on the left-hand function by the right-hand function plus a constant. `StatementII` requires only this direction. It does not require the reverse bound or a bound on the absolute difference. The separately supplied relation `≈` requires both directional bounds; it is not the relation used here. No quotient by that relation is formed in the definition. Addition and multiplication by \(1+\varepsilon\) in the displayed formula act pointwise on the real-valued functions.

The declaration has the explicit structure parameter \(T\), with the universe level \(u\) implicit. The variables \(d,\varepsilon,K,C,x\) are quantified inside the proposition; they are not further external parameters. The general discrepancy relation has an implicit ambient type, instantiated here by \(\operatorname{Pt}(P)\), and explicit function and subset arguments. No additional mathematical type-class hypotheses are parameters of `StatementII`; the real arithmetic and pointwise function operations use their standard imported instances.
