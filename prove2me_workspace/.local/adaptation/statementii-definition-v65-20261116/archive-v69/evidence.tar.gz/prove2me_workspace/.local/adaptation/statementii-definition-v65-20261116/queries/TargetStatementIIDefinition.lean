import Lean
import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

abbrev TypeNames := Array (Name × Name)

-- Proof bodies are substituted only for explicitly exported, closed Prop
-- constants in the original TYPE. Data constants require an actual named map.
partial def decodeType (names : TypeNames) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := decodeType names proofs visiting expandProofs
  let relocate : Name → Except String Name := fun n => do
    if let some p := names.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`Definitions,`Theorems,`Solutions].any (·.isPrefixOf n) then
      throw s!"Unmapped TYPE project constant: {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    let levels ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName original)) then
      unless levels.isEmpty do throw "Closed source proof unexpectedly has universe arguments"
      if !expandProofs then return .const original levels.toList
      if visiting.contains original then throw s!"Cyclic proof-only resolution: {original}"
      return ← decodeType names proofs (visiting.push original) true (← field p "actualProofExpr")
    return .const (← relocate original) levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

end FoundationAudit

namespace StatementIIDefinitionAudit
open Lean Elab Term Meta FoundationAudit

-- Expected public names are lookup keys only. The stored identity is the actual Name.
def actualNamedConstant (display : String) (owner : Name) : MetaM Name := do
  let env ← getEnv
  let matching := env.constants.fold (fun xs n _ =>
    if n.toString == display && moduleOf env n == some owner then xs.push n else xs)
    (#[] : Array Name)
  unless matching.size == 1 do throwError "Expected one actual constant {display} in {owner}; found {matching.size}"
  return matching[0]!

def actualDefinitionValue (label : String) (ci : ConstantInfo) : MetaM Expr := do
  match ci with
  | .defnInfo d =>
      unless d.safety == .safe do throwError "Unsafe definition in {label}"
      return d.value
  | _ => throwError "Expected genuine definition in {label}: {ci.name}"

def expressionClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def supportValue (ci : ConstantInfo) : MetaM Expr := do
  match ci with
  | .thmInfo t => return t.value
  | .defnInfo d => return d.value
  | .opaqueInfo o => return o.value
  | _ => throwError "No actual closed proposition value: {ci.name}"

def projectOwned (env : Environment) (n : Name) : Bool :=
  #[`Genl, `Iut, `AbcAdaptation, `Definitions, `Theorems, `Solutions].any (·.isPrefixOf n) ||
    (moduleOf env n).any fun owner =>
      #[`Genl, `Iut, `Definitions, `Theorems, `Solutions].any (·.isPrefixOf owner)

end StatementIIDefinitionAudit

namespace StatementIIDefinitionAudit
open Lean Elab Term Meta FoundationAudit

def boundJson (binding : Json) : MetaM Json := do
  if binding == Json.null then throwError "Pending root receipt/facts binding"
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do throwError "Bound JSON contents changed"
  unless (← checked (stringField binding "sha256")).length == 64 do throwError "Missing SHA binding"
  return actual

def passedReceipt (binding : Json) : MetaM Json := do
  let r ← boundJson binding
  unless (← checked (stringField r "status")) == "succeeded" do throwError "Receipt not succeeded"
  let result ← checked (field r "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Receipt failed"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Expected actual exclusive-worktree receipt"
  return r

def targetClosedProofs (known : Array Name) (root : Name) (exprs : Array Expr) : MetaM (Array Json) := do
  let env ← getEnv
  let mut queue : Array Name := #[]
  for e in exprs do
    for n in e.getUsedConstants do
      if projectOwned env n && !known.contains n && !queue.contains n then queue := queue.push n
  let mut rows : Array Json := #[]
  let mut index := 0
  while index < queue.size do
    let n := queue[index]!
    index := index + 1
    if n == root then throwError "Target root recursively appears in its own type/value"
    let ci ← getConstInfo n
    unless ci.levelParams.isEmpty && (← isProp ci.type) do
      throwError "Unmapped target data or nonclosed proposition support {n}; never substitute data"
    let value ← supportValue ci
    expressionClosed s!"target support type {n}" ci.type
    expressionClosed s!"target support value {n}" value
    let axs ← collectAxioms n
    let taxs ← expressionAxioms ci.type
    let vaxs ← expressionAxioms value
    for xs in #[axs,taxs,vaxs] do ensureStandard s!"target closed proposition {n}" xs
    for e in #[ci.type,value] do
      for dep in e.getUsedConstants do
        if projectOwned env dep && !known.contains dep && !queue.contains dep then queue := queue.push dep
    rows := rows.push (Json.mkObj [
      ("name",toJson n.toString),("nameExpr",encodeName n),
      ("owner",(moduleOf env n).map encodeName |>.getD Json.null),
      ("isProposition",toJson true),("isClosed",toJson true),("levelParams",Json.arr #[]),
      ("actualTypeExpr",← checked (encodeExpr ci.type)),
      ("actualProofExpr",← checked (encodeExpr value)),
      ("axioms",toJson (axs.map Name.toString)),("typeAxioms",toJson (taxs.map Name.toString)),
      ("proofAxioms",toJson (vaxs.map Name.toString))])
  return rows

def validateClosedProofRows (names : TypeNames) (rows : Array Json) : MetaM Unit := do
  for row in rows do
    let n ← checked (decodeName (← checked (field row "nameExpr")))
    unless (← checked (row.getObjValAs? Bool "isProposition")) &&
        (← checked (row.getObjValAs? Bool "isClosed")) &&
        (← checked (arrayField row "levelParams")).isEmpty do
      throwError "Nonclosed/non-Prop support in explicit resolution {n}"
    let t ← checked (decodeType names rows #[] true (← checked (field row "actualTypeExpr")))
    let v ← checked (decodeType names rows #[n] true (← checked (field row "actualProofExpr")))
    let vt ← kernelCheck s!"actual closed support proof {n}" v
    unless ← isProp vt do throwError "Data substitution prohibited in support resolution {n}"
    kernelTypeEq s!"closed support type/value {n}" vt t
    for key in #["axioms","typeAxioms","proofAxioms"] do
      for ax in ← checked (arrayField row key) do
        unless (standardAxioms.map fun a => Json.str a.toString).contains ax do
          throwError "Nonstandard source/target support axiom {n}"
    ensureStandard s!"expanded support proof {n}" (← expressionAxioms v)

def mappedNames (cfg : Json) : MetaM (TypeNames × Array Name) := do
  let mut names : TypeNames := #[]
  let mut targets : Array Name := #[]
  for row in ← checked (arrayField cfg "dataMap") do
    let src ← checked (decodeName (← checked (field row "sourceNameExpr")))
    let dst ← checked (decodeName (← checked (field row "targetNameExpr")))
    let owner ← checked (decodeName (← checked (field row "targetOwnerExpr")))
    unless moduleOf (← getEnv) dst == some owner do throwError "Mapped target data owner differs: {dst}"
    unless (← checked (field row "targetToSourceUniverseIndices")) == Json.null do
      throwError "No unverified universe permutation is allowed: {src}"
    if names.any (·.1 == src) then throwError "Duplicate source data mapping {src}"
    names := names.push (src,dst)
    if !names.any (·.1 == dst) then names := names.push (dst,dst)
    unless targets.contains dst do targets := targets.push dst
  return (names,targets)

run_meta do
  let cfg ← jsonFile (← absoluteEnv "STATEMENTII_DEFINITION_CONFIG")
  unless (← checked (stringField cfg "schema")) == "statementii-target-definition-config/v58" do throwError "Wrong target definition configuration"
  unless Lean.versionString == "4.33.1" do throwError "Wrong target compiler"
  let _ ← passedReceipt (← checked (field cfg "sourceReceipt"))
  let _ ← passedReceipt (← checked (field cfg "targetLeafReceipt"))
  let _ ← passedReceipt (← checked (field cfg "targetArtifactReceipt"))
  let facts ← boundJson (← checked (field cfg "sourceFactsBinding"))
  unless (← checked (stringField facts "schema")) == "statementii-source-definition-facts/v58" &&
      (← checked (stringField facts "name")) == "Genl.HeightTheory.StatementII" &&
      (← checked (facts.getObjValAs? Bool "definitionValueRead")) &&
      !(← checked (facts.getObjValAs? Bool "sourceTheoremProofRead")) do throwError "Wrong source pure-definition facts"
  let sourceOwner ← checked (decodeName (← checked (field facts "owner")))
  unless sourceOwner == `Genl.GeneralPosition.HeightTheory do throwError "Wrong actual source owner"
  let sourceName ← checked (decodeName (← checked (field facts "nameExpr")))
  unless sourceName == `Genl.HeightTheory.StatementII do throwError "Source actual Name differs"
  let owner ← checked (decodeName (← checked (field cfg "targetOwnerExpr")))
  let n ← actualNamedConstant (← checked (stringField cfg "targetName")) owner
  let ci ← getConstInfo n
  let value ← actualDefinitionValue "target StatementII" ci
  let text ← IO.FS.readFile (← checked (stringField cfg "installedSource"))
  unless text == (← checked (stringField cfg "expectedTargetSourceText")) do throwError "Installed target definition changed"
  let (names,knownTargets) ← mappedNames cfg
  let sourceProofs ← checked (arrayField facts "closedPropSupportValues")
  let targetProofs ← targetClosedProofs knownTargets n #[ci.type,value]
  validateClosedProofRows names sourceProofs
  validateClosedProofRows names targetProofs
  let sourceType ← checked (decodeType names sourceProofs #[] true (← checked (field facts "typeExpr")))
  let sourceValue ← checked (decodeType names sourceProofs #[] true (← checked (field facts "valueExpr")))
  let targetType ← checked (decodeType names targetProofs #[] true (← checked (encodeExpr ci.type)))
  let targetValue ← checked (decodeType names targetProofs #[] true (← checked (encodeExpr value)))
  let sourceParams ← namesFromJson (← checked (field facts "levelParams"))
  unless sourceParams.length == ci.levelParams.length do throwError "Definition universe arity differs"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let st := sourceType.instantiateLevelParams sourceParams canonical
  let sv := sourceValue.instantiateLevelParams sourceParams canonical
  let tt := targetType.instantiateLevelParams ci.levelParams canonical
  let tv := targetValue.instantiateLevelParams ci.levelParams canonical
  kernelTypeEq "complete source/target definition TYPE" st tt
  kernelTypeEq "source definition value has its recorded TYPE" (← kernelCheck "source definition value" sv) st
  kernelTypeEq "target definition value has its recorded TYPE" (← kernelCheck "target definition value" tv) tt
  kernelTermEq "complete source/target definition value" sv tv
  let sourceTypeRaw ← checked (decodeType names sourceProofs #[] false (← checked (field facts "typeExpr")))
  let sourceValueRaw ← checked (decodeType names sourceProofs #[] false (← checked (field facts "valueExpr")))
  unless binderInventory sourceTypeRaw == binderInventory ci.type &&
      binderPlacement sourceTypeRaw == binderPlacement ci.type do throwError "Full TYPE BinderInfo differs"
  unless binderInventory sourceValueRaw == binderInventory value &&
      binderPlacement sourceValueRaw == binderPlacement value do throwError "Full definition value BinderInfo differs"
  let axs ← collectAxioms n
  let taxs ← expressionAxioms ci.type
  let vaxs ← expressionAxioms value
  for xs in #[axs,taxs,vaxs] do ensureStandard "actual target pure definition" xs
  for m in (← getEnv).header.moduleNames do
    if #[`Iut,`Genl,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf m) then
      throwError "Original project import leaked into target audit: {m}"
  let constants ← #[ci.type,value].mapM fun e => do
    e.getUsedConstants.qsort Name.lt |>.mapM fun c => do
      return Json.mkObj [
        ("name",toJson c.toString),("nameExpr",encodeName c),
        ("owner",(moduleOf (← getEnv) c).map encodeName |>.getD Json.null)]
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "statementii-definition-type-value-audit/v58"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("sourceName",toJson sourceName.toString),("targetName",toJson n.toString),
    ("targetNameExpr",encodeName n),("targetOwner",encodeName owner),
    ("sourceLevelParams",← checked (field facts "levelParams")),
    ("targetLevelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("sourceTypeExpr",← checked (field facts "typeExpr")),("sourceValueExpr",← checked (field facts "valueExpr")),
    ("targetTypeExpr",← checked (encodeExpr ci.type)),("targetValueExpr",← checked (encodeExpr value)),
    ("sourceClosedPropSupportValues",Json.arr sourceProofs),("targetClosedPropSupportValues",Json.arr targetProofs),
    ("completeKernelTypeEqual",toJson true),("completeKernelValueEqual",toJson true),
    ("fullTypeBinderInventoryEqual",toJson true),("fullTypeBinderPlacementEqual",toJson true),
    ("fullValueBinderInventoryEqual",toJson true),("fullValueBinderPlacementEqual",toJson true),
    ("sourceValueKernelHasRecordedType",toJson true),("targetValueKernelHasRecordedType",toJson true),
    ("typeConstants",Json.arr constants[0]!), ("valueConstants",Json.arr constants[1]!),
    ("targetAxioms",toJson (axs.map Name.toString)),("targetTypeAxioms",toJson (taxs.map Name.toString)),
    ("targetValueAxioms",toJson (vaxs.map Name.toString)),("targetSorryAx",toJson false),
    ("pureDefinitionAccepted",toJson true),("proofOfStatementIIClaimed",toJson false)]).pretty ++ "\n")
  logInfo "Pure StatementII definition full TYPE/value and BinderInfo accepted; no theorem proof is claimed"
end StatementIIDefinitionAudit
