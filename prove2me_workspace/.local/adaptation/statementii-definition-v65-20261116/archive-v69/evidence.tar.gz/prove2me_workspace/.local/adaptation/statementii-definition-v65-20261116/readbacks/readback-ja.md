# 形式的定義の読み戻し——日本語訳

本訳は同じディレクトリに固定した `readback-en.md` に対応する。独立した英語の読み戻しを行ったモデルは `gpt-6.1-sol` であり、本訳は別個の独立監査ではない。対象は `StatementII` の定義と提示された形式的な文脈であり、定義された命題が証明済みであるという主張ではない。

宇宙レベル \(u\) と高さ理論の構造 \(T\) を固定する。その形式的データは、この宇宙に属する型 \(\operatorname{Curve}\)、各 \(X\in\operatorname{Curve}\) に対する同じ宇宙に属する型 \(\operatorname{Pt}(X)\)、\(\operatorname{Curve}\) 上の二つの述語 \(\operatorname{Hyperbolic}\) と \(\operatorname{DivisorFree}\)、および各 \(X\) と自然数 \(n\) に対する \(\operatorname{Pt}(X)\) の部分集合 \(\operatorname{ptLE}(X,n)\) と \(\operatorname{ptEQ}(X,n)\) からなる。構造には、すべての \(X,n\) について

\[
\operatorname{ptLE}(X,0)=\varnothing,\qquad
\operatorname{ptLE}(X,n+1)=\operatorname{ptLE}(X,n)\cup\operatorname{ptEQ}(X,n+1)
\]

が成り立つことが含まれる。さらに、`htCan`、`logDiff`、`logCond` にそれぞれ対応する三つの実数値関数 \(h_X,\delta_X,\kappa_X:\operatorname{Pt}(X)\to\mathbb R\)、\(\operatorname{Hyperbolic}(P)\) を満たす指定された元 \(P=\operatorname{tripod}\in\operatorname{Curve}\)、同じ宇宙に属する型 \(\mathcal K=T.\mathrm{CBS}\)、および写像 \(S=T.\mathrm{cbsSet}:\mathcal K\to\mathcal P(\operatorname{Pt}(P))\) が与えられる。

これらは抽象的な型、述語、部分集合、関数である。この構造には位相、台を与える写像、固定された素数集合、定義体、数値としての次数関数は含まれない。各データの名称から幾何学的・数論的な法則が追加されるわけではない。提示された構造では \(h_X,\delta_X,\kappa_X\) の符号や相互の整合性にも条件が課されていない。\(\mathcal K\) の元はコード内で「コンパクト有界部分集合（compactly bounded subset）」と呼ばれ、その台となる部分集合は \(S(K)\) である。形式的に課される条件は、上述の型と写像に尽きる。

この固定された \(T\) に対し、`StatementII` は次の命題を定義する。任意の自然数 \(d\in\mathbb N\) と任意の実数 \(\varepsilon\in\mathbb R\) について、\(\varepsilon>0\) ならば、任意の \(K\in\mathcal K\) に対してある実数 \(C\in\mathbb R\) が存在し、すべての \(x\in\operatorname{Pt}(P)\) が

\[
x\in S(K)\cap\operatorname{ptLE}(P,d)
\quad\Longrightarrow\quad
h_P(x)\le (1+\varepsilon)\bigl(\delta_P(x)+\kappa_P(x)\bigr)+C
\]

を満たす。

量化の順序は、\(T\) を固定し、\(d\) を取り、\(\varepsilon\) を取り、\(\varepsilon>0\) を仮定し、\(K\) を取り、\(C\) の存在を得た後で、指定された部分集合内のすべての \(x\) を考える、というものである。定数 \(C\) は \(T,d,\varepsilon,K\) に依存してよいが、\(x\) に関しては共通である。\(C\) は任意の実定数でよく、\(C>0\) も \(C\ge0\) も要求されない。定義における数値の正性の仮定は \(\varepsilon>0\) のみであり、\(d>0\) は要求されない。

有限の自然数の上限 \(d\) は、指定された部分集合 \(\operatorname{ptLE}(P,d)\) を通じて対象となる点を制限する。この部分集合が有限集合であるとは主張されていない。また、コード内ではこれを特定の体論的次数を持つ点の集合と同一視していない。\(d=0\) のとき、構造に含まれる上記の等式によってこの部分集合は空となり、\(x\) に関する条件は空虚に成り立つ。\(S(K)\) または制限された部分集合との共通部分が空の場合も同様である。\(\mathcal K\) が空でないことも要求されない。

上の不等式は記号 `≲` を展開したものである。同一の型上の実数値関数 \(f,g\) と部分集合 \(A\) に対し、\(f\lesssim_A g\) は、ある実数 \(C\) が存在し、すべての \(x\in A\) について \(f(x)\le g(x)+C\) が成り立つことを意味する。すなわち、右側の関数に定数を加えたものが左側の関数の上界を与える。`StatementII` が要求するのはこの向きだけであり、逆向きの上界や差の絶対値の有界性は要求しない。別に与えられた関係 `≈` は両方向の上界を要求するが、ここで使用する関係ではない。この定義では、その関係による商も取らない。式に現れる関数の加法と \(1+\varepsilon\) による乗法は点ごとに行う。

この宣言の明示的な構造パラメータは \(T\) であり、宇宙レベル \(u\) は暗黙のパラメータである。\(d,\varepsilon,K,C,x\) は命題の内部で量化された変数であり、追加の外部パラメータではない。一般の偏差関係には台となる型が暗黙のパラメータとしてあり、ここでは \(\operatorname{Pt}(P)\) に具体化される。関数と部分集合はこの関係の明示的な引数である。`StatementII` には追加の数学的な型クラスの仮定はなく、実数の演算と関数の点ごとの演算には導入された標準のインスタンスを用いる。
