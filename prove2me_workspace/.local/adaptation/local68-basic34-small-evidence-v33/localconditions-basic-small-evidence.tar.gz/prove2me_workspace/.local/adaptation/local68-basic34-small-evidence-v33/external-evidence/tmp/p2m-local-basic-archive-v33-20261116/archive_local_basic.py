#!/usr/bin/env python3
"""Archive the completed LocalConditions + Basic unit's small saved evidence.

Default: report only. --apply writes the existing manifest + tar.gz format.
No API, compiler, CI, Git, deletion, proof replay, or registry mutation.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

ROOT=Path('/home/admin-wsl/Coq/abc')
W=ROOT/'prove2me_workspace'
A=W/'.local/adaptation'
BIND_TOOLS=Path('/tmp/p2m-local-basic-ready-bind-v31-20261116')
SMALL_LIMIT=4*1024**2
PIN_LIMIT=2*1024**2
DOSSIER_LIMIT=16*1024**2
MODULES={'LocalConditions':68,'Basic':34}


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--local-delivery',type=Path,default=A/'local68-delivery-v31')
    p.add_argument('--basic-delivery',type=Path,default=A/'basic34-delivery-v31')
    p.add_argument('--local-dossier',type=Path,default=A/'reference-initial-theta-carriers-20261115/local-remaining48-v25/final-local68-kernel-dossier.json')
    p.add_argument('--basic-dossier',type=Path,default=A/'reference-initial-theta-carriers-20261115/basic34-math-dossier-v27/final-kernel-dossier.json')
    p.add_argument('--tool-dir',type=Path,action='append',default=[])
    p.add_argument('--destination',type=Path,default=A/'local68-basic34-small-evidence-v33')
    p.add_argument('--apply',action='store_true')
    a=p.parse_args()
    destination=a.destination.resolve()
    if not destination.is_relative_to(W/'.local/adaptation'):
        p.error('--destination must be in the existing .local/adaptation tree')
    if destination.exists():
        p.error('Destination exists; inspect the stable archive rather than overwriting it')
    selected,excluded,missing,invalid={}, {}, [], []
    cache={}
    identities={}

    def identity(path):
        st=path.stat()
        return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)

    def read_small(path,limit=SMALL_LIMIT):
        path=Path(path).resolve()
        if not path.is_file():
            missing.append(str(path));return None
        if path.stat().st_size>limit:
            invalid.append({'path':str(path),'reason':'required small JSON exceeds selection limit; not read or hashed','bytes':path.stat().st_size});return None
        if path not in cache:
            cache[path]=path.read_bytes()
            identities[path]=identity(path)
        return json.loads(cache[path])

    def need(ok,message):
        if not ok:invalid.append({'reason':message})
        return ok

    def add(path,expected=None,limit=SMALL_LIMIT):
        path=Path(path)
        if not path.is_absolute():path=W/path
        # Reject symlinks before resolve; archive only actual small files.
        if path.is_symlink():
            invalid.append({'path':str(path),'reason':'symlink evidence cannot be frozen as an actual file'});return
        path=path.resolve();key=str(path)
        if key in selected:
            if expected is not None:need(selected[key]['sha256']==expected,'Conflicting saved pin: '+key)
            return
        if path.name=='.env' or any(s in path.name.lower() for s in ['credentials','access_token','refresh_token']):
            excluded[key]={'reason':'credential input excluded','existingPin':expected};return
        if not path.is_file():
            missing.append(key);return
        size=path.stat().st_size
        if size>limit:
            excluded[key]={'reason':'large pre-pinned source/report excluded without reading, copying, or hashing',
                'bytes':size,'existingPin':expected,'archiveSizeLimit':limit};return
        if path.is_relative_to(ROOT):member=path.relative_to(ROOT).as_posix()
        elif path.is_relative_to('/tmp'):
            member=(destination.relative_to(ROOT)/'external-evidence/tmp'/path.relative_to('/tmp')).as_posix()
        else:
            excluded[key]={'reason':'outside this repository and task temporary evidence','existingPin':expected};return
        need(not PurePosixPath(member).is_absolute() and '..' not in PurePosixPath(member).parts,'Unsafe archive member')
        if path not in cache:
            cache[path]=path.read_bytes()
            identities[path]=identity(path)
        digest=sha_bytes(cache[path])
        if expected is not None and not need(digest==expected,'Small saved evidence pin changed: '+key):return
        excluded.pop(key,None)
        selected[key]={'source':key,'archive_path':member,'bytes':size,'sha256':digest}

    def pins(value):
        # The complete dossier already retains the source/config/report bindings.
        # Keep these deep DAG/export references without stat, read, copy or rehash.
        if isinstance(value,dict):
            if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
                path=Path(value['path'])
                if not path.is_absolute():path=W/path
                key=str(path)
                if key not in selected:
                    old=excluded.get(key,{}).get('existingPins',[])
                    excluded[key]={'reason':'deep dossier evidence retained by existing pin only; not read, copied or rehashed',
                        'existingPins':sorted(set(old+[value['sha256']]))}
            for child in value.values():pins(child)
        elif isinstance(value,list):
            for child in value:pins(child)

    units=[]
    pairs=[('LocalConditions',a.local_delivery,a.local_dossier),('Basic',a.basic_delivery,a.basic_dossier)]
    for short,delivery,dossier_path in pairs:
        delivery,dossier_path=delivery.resolve(),dossier_path.resolve()
        packet=read_small(delivery/'packet.json',DOSSIER_LIMIT)
        ready=read_small(delivery/'ready.final.json',DOSSIER_LIMIT)
        dossier=read_small(dossier_path,DOSSIER_LIMIT)
        if packet is None or ready is None or dossier is None:continue
        count=MODULES[short];module='Iut.Cor312.ThetaData.'+short
        need(ready.get('passed') is True and packet.get('publicationReady') is True,'Unready delivery: '+short)
        need(dossier.get('module')==module and dossier.get('kernelCoverage')==
            {'source':count,'resolved':count,'named':count,'proof':0,'standard_proof':0,'source_proof_standalone_aliases':0},'Incomplete actual math dossier: '+short)
        need(dossier.get(f'all{count}NamedMathGatesPassed') is True and dossier.get(f'all{count}OwnedAxiomAndOwnerClosuresPassed') is True,'Incomplete saved named/owned acceptance: '+short)
        need(packet.get('kernel_coverage')==dossier['kernelCoverage']==ready.get('kernel_coverage'),'Coverage binding changed: '+short)
        need(packet.get('actual_kernel_evidence',{}).get('path')==str(dossier_path),'Different dossier bound to packet: '+short)
        dossier_pin=sha_bytes(cache[dossier_path])
        need(packet.get('actual_kernel_evidence',{}).get('sha256')==dossier_pin,'Dossier SHA differs from publication binding: '+short)
        need(ready.get('packet_sha256')==sha_bytes(cache[delivery/'packet.json']),'Packet SHA differs from ready: '+short)
        rows=packet.get('publications',[])
        if not need(len(rows)==1,'Only one existing Definition publication is expected: '+short):continue
        row=rows[0];tag=row['tag'];platform=delivery/'platform'
        required=['packet-binding.json','published-ids.json','root-graph-before.json','root-graph-after.json',
            tag+'-intent.json',tag+'-submit.json',tag+'-result.json',tag+'-published-item.json']
        journal={name:read_small(platform/name) for name in required}
        if any(v is None for v in journal.values()):continue
        job=journal[tag+'-result.json'];published=journal[tag+'-published-item.json'];submit=journal[tag+'-submit.json']
        need(job.get('status')=='PUBLISHED' and job.get('id')==submit.get('job_id'),'Original publication job is not PUBLISHED: '+short)
        need(journal[tag+'-intent.json']==row,'Original POST intent changed: '+short)
        need(journal['packet-binding.json']=={'packet_sha256':ready['packet_sha256'],'names':[tag]},'Original packet journal binding changed: '+short)
        need(journal['published-ids.json'].get(tag)==published.get('definition_id')==job.get('theorem_id'),'Published Definition identity differs: '+short)
        need(published.get('visibility')=='private' and published.get('mathlib_rev')==packet.get('environment'),'Published private environment differs: '+short)
        for key in ['definition_name','definition_title','definition','natural_language_statement','source']:
            need(published.get(key)==row['payload'].get(key),'Exact published readback differs: '+short+'/'+key)
        need(journal['root-graph-before.json']==journal['root-graph-after.json'],'Original root graph preservation evidence differs: '+short)
        # These checks reuse the original publisher outcome; they add no math or delivery gate.
        for path in delivery.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and not path.is_relative_to(destination):add(path)
        add(dossier_path,dossier_pin,limit=DOSSIER_LIMIT)
        for binding in [packet['metadata_sha256'],ready['evidence_sha256']]:
            for path,digest in binding.items():add(path,digest)
        pins(dossier)
        # Preserve the small merger, leaf reviewer and explicit input plans.
        for key in ['mergeTool','leafReviewTool','sourcePlan','sourcePlans','exactInputOverridePlans']:
            bindings=dossier.get(key,[])
            if isinstance(bindings,dict):bindings=[bindings]
            for evidence in bindings:
                if isinstance(evidence,dict) and 'path' in evidence and 'sha256' in evidence:
                    add(evidence['path'],evidence['sha256'],limit=PIN_LIMIT)
        for receipt in dossier['actualReceipts']:
            add(receipt['path'],receipt['sha256'])
            need(str(Path(receipt['path']).resolve()) in selected,'Required actual receipt was not archived: '+receipt['path'])
        # Keep the small actual request, submission and generated type-check source.
        # Nested parser source-record/config/report DAGs remain pin-only above.
        for leaf in dossier.get('actualLeafResults',[]):
            for key in ['request','submit','source']:
                evidence=leaf.get(key)
                if isinstance(evidence,dict) and 'path' in evidence and 'sha256' in evidence:
                    add(evidence['path'],evidence['sha256'],limit=PIN_LIMIT)
        for relative,digest in packet['source_sha256'].items():add(W/relative,digest)
        for name in ['Definition.lean','payload.json','readback.json','paper-context.json','readback-original-pins.json','publisher.py','module-profile.json','source-ledger.final.json','final-frozen-review.json']:
            if not (delivery/name).is_file():missing.append(str(delivery/name))
        units.append({'module':module,'delivery':str(delivery),'publishedDefinition':published['definition_id'],
            'publishJob':job['id'],'source':count,'named':count,'owned':count,'genuineSourceProofValues':0,'aliasCount':0,
            'sourceSha256':next(iter(packet['source_sha256'].values())),
            'kernelDossier':{'path':str(dossier_path),'sha256':dossier_pin},'actualMathReceipts':len(dossier['actualReceipts']),'kernelDossierSha256':dossier_pin,
            'rawAnnotationEqualityClaimed':False,'faithfulReplayAndFullComputationalValuesAccepted':True,
            'canonicalC22Connected':False,'root_graph_membership':False})
    for directory in [BIND_TOOLS]+a.tool_dir:
        directory=directory.resolve()
        if not directory.is_dir():missing.append(str(directory));continue
        for path in directory.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix in ['.py','.json','.md','.txt','.lean']:
                add(path)
    add(Path(__file__).resolve())
    add(ROOT/'refer/iut/LICENSE')
    for short in MODULES:add(ROOT/('refer/iut/Iut/Cor312/ThetaData/'+short+'.lean'))
    entries=sorted(selected.values(),key=lambda r:r['archive_path'])
    need(len({e['archive_path'] for e in entries})==len(entries),'Duplicate archive member names')
    size=sum(e['bytes'] for e in entries)
    need(len(units)==2,'Both real platform Definition outcomes are required before archival')
    report={'ready':not missing and not invalid,'apply':a.apply,'destination':str(destination),
        'modules':units,'files':len(entries),'input_bytes':size,'input_mib':size/1024**2,
        'missingRequiredOrPinnedFiles':sorted(set(missing)),'invalidBindings':invalid,
        'excludedLargeOrOtherReferences':excluded,'archiveWritten':False,'deletions':[]}
    if missing or invalid:
        print(json.dumps(report,ensure_ascii=False,indent=2));return 2
    if not a.apply:
        print(json.dumps(report,ensure_ascii=False,indent=2));return 0
    # Freeze only the selected small bytes. If any input changed since planning,
    # stop rather than stamp a successful manifest onto different evidence.
    for entry in entries:
        path=Path(entry['source'])
        if not path.is_file() or path.is_symlink() or path.stat().st_size!=entry['bytes'] or identity(path)!=identities[path]:
            report['ready']=False;report['invalidBindings'].append({'reason':'Small selected input changed before archive write','path':str(path)})
            print(json.dumps(report,ensure_ascii=False,indent=2));return 2
    destination.mkdir(parents=True)
    archive_path=destination/'localconditions-basic-small-evidence.tar.gz'
    try:
        with tarfile.open(archive_path,'w:gz') as archive:
            for entry in entries:
                # Use the exact selected bytes; do not re-read mutable source files.
                info=tarfile.TarInfo(entry['archive_path']);info.size=entry['bytes']
                info.mode=0o644
                archive.addfile(info,io.BytesIO(cache[Path(entry['source'])]))
        with tarfile.open(archive_path,'r:gz') as archive:
            if {m.name for m in archive.getmembers()}!={e['archive_path'] for e in entries}:raise ValueError('Archive member list differs')
            for entry in entries:
                stream=archive.extractfile(entry['archive_path'])
                if stream is None or sha_bytes(stream.read())!=entry['sha256']:raise ValueError('Archive member SHA differs: '+entry['archive_path'])
        manifest={'schema':'localconditions-basic-small-evidence-archive/v33','source':[str(a.local_delivery.resolve()),str(a.basic_delivery.resolve())],
            'publishedDefinitions':units,'input_bytes':size,'input_mib':size/1024**2,'files':entries,'excludedReferences':excluded,
            'scope':{'modules':[u['module'] for u in units],'canonicalC22Connected':False,'scopeAllFourModules':False,'all200FormalAcceptanceClaimedByThisArchive':False,'scopeNote':'This two-package archive does not adjudicate the four-module aggregate; use all four actual complete dossiers and publication evidence.'},
            'archiveNames':'Repo-relative keys; /tmp evidence under virtual external-evidence/tmp subtree.',
            'archive_sha256':sha_bytes(archive_path.read_bytes()),'archive_bytes':archive_path.stat().st_size,'deletions':[]}
        (destination/'archive-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    except Exception as error:
        report['ready']=False;report['invalidBindings'].append({'reason':'Archive write/verification failed; no successful manifest should be inferred','error':str(error)})
        print(json.dumps(report,ensure_ascii=False,indent=2));return 2
    report.update(archiveWritten=True,archive=str(archive_path),archive_sha256=manifest['archive_sha256'])
    print(json.dumps(report,ensure_ascii=False,indent=2));return 0


if __name__=='__main__':raise SystemExit(main())
