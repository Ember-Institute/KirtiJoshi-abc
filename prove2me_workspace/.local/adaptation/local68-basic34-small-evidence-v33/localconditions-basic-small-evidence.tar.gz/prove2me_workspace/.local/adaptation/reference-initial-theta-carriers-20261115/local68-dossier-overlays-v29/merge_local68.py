#!/usr/bin/env python3
"""Assemble LocalConditions68 only when every saved actual math gate has passed.

Reuse the accepted frozen12 and the unchanged per-leaf receipt reviewer. No CI,
compiler, API, Git or submitted-input writes. Only explicit output files change.
"""
import sys
sys.dont_write_bytecode=True
import argparse
import copy
import json
from pathlib import Path
import merge_actual as leaf_review

HERE=Path(__file__).resolve().parent
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
B=W/'.local/adaptation/reference-initial-theta-carriers-20261115'
OWNER='Iut.Cor312.ThetaData.LocalConditions'
FROZEN=Path('/tmp/p2m-local-basic-remaining-v24-20261116/frozen-passed-local-basic.json')
FROZEN_SHA='c2a308b291296c90fdc9a40c0bce0f88cc4b45e62efd89b49f0ced0e47674df1'
TATE=Path('/tmp/p2m-tate-final-local-review-v22-20261116/final-kernel-dossier.json')
TATE_SHA='9217c96b9cef35953c4e20afd99950faf33a53860d4ae748eb346e30e105caf3'
REVIEW_SHA='9f06872816708211f34645fcdff0ef0076512a2bf0718007b0d0fdda204ad138'
DEF=W/'Definitions/Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions.lean'
DEF_SHA='b54a834f96ec1df6ad6a6c0c71d0edfcc05a974159fd513771c7f908ae22a265'


def dump(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.tmp');temp.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');temp.replace(p)


def frozen_rows():
    leaf_review.verified({'path':str(FROZEN),'sha256':FROZEN_SHA})
    rows=[r for r in leaf_review.load(FROZEN)['declarations'] if r['owner']==OWNER]
    leaf_review.need(len(rows)==12 and sum(len(r['leaves']) for r in rows)==24,'Exact accepted frozen12/24 required')
    for row in rows:
        for e in row['leaves']:
            leaf_review.need(e['innerGatesChecked'] is True,'Frozen inner acceptance missing')
            # Preserve prior acceptance; verify small immutable pins, do not add
            # new mathematical requirements to historical receipt manifests.
            for key in ('receipt','source','config','sourceRecord','report'):leaf_review.verified(e[key])
    return copy.deepcopy(rows)


def review_plan(path,receipt_dir,overrides):
    plan=leaf_review.load(path);deps=leaf_review.dependencies(plan);results=[]
    for original_leaf in plan['leaves']:
        l=overrides.get((original_leaf['original'],original_leaf['mode']),original_leaf)
        if l is not original_leaf:
            for key in ('original','mode','config','sourceRecord','task_type','target'):
                leaf_review.need(l[key]==original_leaf[key],'Override changed protected slot input: '+key)
            leaf_review.need(l['environment']['NEXT_CARRIER_AUDIT_CONFIG']==original_leaf['environment']['NEXT_CARRIER_AUDIT_CONFIG'],'Override changed original config path')
        try:r=leaf_review.inspect(l,plan,deps,W,receipt_dir)
        except Exception as ex:r={'original':l['original'],'mode':l['mode'],'submitTag':l['submitTag'],
                                 'accepted':False,'state':'verification-failed','error':str(ex)}
        if l is not original_leaf:
            r['inputOverrideApplied']=True
            r['originalMasterSlot']={'source':original_leaf['source'],'submitTag':original_leaf['submitTag'],
                'environment':original_leaf['environment']}
            previous=receipt_dir/(original_leaf['submitTag']+'-result.json')
            if previous.is_file():r['originalMasterSlot']['savedPriorReceipt']=leaf_review.pin(previous)
        results.append(r)
    return plan,results


def global_inventory():
    leaf_review.verified({'path':str(TATE),'sha256':TATE_SHA})
    evidence=leaf_review.load(TATE)['actualGlobalClosureResult']
    for key in ('receipt','source','config','report'):leaf_review.verified(evidence[key])
    row=next(r for r in leaf_review.load(evidence['report']['path'])['report']['modules'] if r['sourceOwner']==OWNER)
    leaf_review.need(len(row['actualMappedNames'])==len(row['actualOwnedNames'])==68,'Exact68 inventory required')
    leaf_review.need(set(row['actualMappedNames'])==set(row['actualOwnedNames']),'No Local compiler-only helper allowed')
    leaf_review.need(row['exactConfiguredImportsChecked'] is True,'Exact module import inventory missing')
    return evidence,row


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--first-plan',type=Path,default=B/'local-next-eight-v24/next-eight-plan.json')
    p.add_argument('--remaining-plan',type=Path,default=B/'local-remaining48-v25/local-remaining-plan.json')
    p.add_argument('--receipts',type=Path,default=B)
    p.add_argument('--progress',type=Path,required=True);p.add_argument('--dossier',type=Path,required=True)
    p.add_argument('--require-all',action='store_true')
    p.add_argument('--override-plan',type=Path,action='append',default=[])
    a=p.parse_args()
    leaf_review.verified({'path':str(HERE/'merge_actual.py'),'sha256':REVIEW_SHA})
    leaf_review.verified({'path':str(DEF),'sha256':DEF_SHA})
    override_map={};override_pins=[]
    master_slots={(l['original'],l['mode']) for path in (a.first_plan,a.remaining_plan) for l in leaf_review.load(path)['leaves']}
    for path in a.override_plan:
        o=leaf_review.load(path);leaf_review.need(o['schema']=='exact-leaf-input-overrides-v29','Exact override schema required')
        for l in o['leaves']:
            key=(l['original'],l['mode'])
            leaf_review.need(key in master_slots and key not in override_map,'Unknown or duplicate exact override slot')
            override_map[key]=l
        override_pins.append(leaf_review.pin(path))
    frozen=frozen_rows();first,first_results=review_plan(a.first_plan,a.receipts,override_map)
    remaining,remaining_results=review_plan(a.remaining_plan,a.receipts,override_map)
    leaf_review.need(len(first_results)==8 and len(remaining_results)==84,'Exact8+84 new mode slots required')
    new=first_results+remaining_results
    expected=set(r['original'] for r in frozen)|{r['original'] for r in new}
    leaf_review.need(len(expected)==68 and len({(r['original'],r['mode']) for r in new})==92,'Exact12+8+48 partition required')
    global_evidence,owned=global_inventory()
    cfg=leaf_review.load(first['leaves'][0]['config']['path'])
    identities={r['original']:r for r in cfg['projectMap'] if r.get('target') in set(owned['actualMappedNames'])}
    leaf_review.need(set(identities)==expected and {r['target'] for r in identities.values()}==set(owned['actualMappedNames']),'Exact source-map/owned partition differs')
    groups={r['original']:r['leaves'] for r in frozen};pending=[]
    for name in sorted({r['original'] for r in new}):
        rows=[r for r in new if r['original']==name]
        modes=['complete-existing'] if any(r['mode']=='complete-existing' for r in rows) else ['signature','value','axioms']
        missing=[m for m in modes if not any(r['mode']==m and r['accepted'] for r in rows)]
        if missing:pending.append({'original':name,'missingModes':missing,
            'leafStates':[{'mode':r['mode'],'state':r['state'],'job_id':r.get('job_id'),'error':r.get('error')} for r in rows]})
        else:groups[name]=rows
    progress={'schema':'localconditions68-math-progress-v27','module':OWNER,
        'requiredNamed':68,'actualCompleteNamed':len(groups),'frozenPreviouslyAcceptedNamed':12,
        'newModeSlots':92,'newAcceptedModeSlots':sum(r['accepted'] for r in new),
        'pendingNamed':pending,'newLeafResults':new,'frozenPassed':leaf_review.pin(FROZEN),
        'sourcePlans':[leaf_review.pin(a.first_plan),leaf_review.pin(a.remaining_plan)],
        'exactInputOverridePlans':override_pins,
        'all68NamedMathGatesPassed':not pending,'finalDossierWritten':False,
        'publicationReady':False,'all200FormalAccepted':False,'compilerCiApiGitCalled':False}
    if pending:
        leaf_review.need(not a.dossier.exists(),'Refusing to leave an existing final dossier beside incomplete progress')
        dump(a.progress,progress)
        print(json.dumps({'progress':leaf_review.pin(a.progress),'actualCompleteNamed':len(groups),
                          'pendingNamed':len(pending),'finalDossierWritten':False}))
        if a.require_all:raise SystemExit(1)
        return
    named=[];all_leaves=[]
    for name in sorted(expected):
        evidence=groups[name];signature=next(e for e in evidence if e['mode'] in ('signature','complete-existing'))
        raw=signature.get('originalRawFlags',signature.get('rawFlags'))
        leaf_review.need(raw is not None,'Actual raw signature flags required')
        named.append({**identities[name],'accepted':True,'actualEvidence':evidence,
            'requiredModes':[e['mode'] for e in evidence],'rawSignatureFlags':raw})
        all_leaves+=evidence
    leaf_review.need(len(all_leaves)==116,'Exact116 math leaves required')
    receipts={e['job_id']:e['receipt'] for e in all_leaves+[global_evidence]}
    leaf_review.need(len(receipts)==117,'Exact116 math +1 inventory receipt required')
    coverage={'source':68,'resolved':68,'named':68,'proof':0,'standard_proof':0,'source_proof_standalone_aliases':0}
    result={'schema':'localconditions68-actual-kernel-dossier-v27','module':OWNER,
        'status':'all LocalConditions actual saved mathematical gates complete',
        'kernelCoverage':coverage,'all68NamedMathGatesPassed':True,'all68OwnedAxiomAndOwnerClosuresPassed':True,
        'namedCorrespondence':named,'genuineSourceProofValues':[],
        'actualLeafResults':all_leaves,'actualNew92LeafResults':new,
        'reusedFrozenLeaves':[e for r in frozen for e in r['leaves']],
        'actualGlobalClosureResult':global_evidence,
        'globalClosureUse':'exact Local imports/source-map/68 named and68 owned inventory only; contributes no Local mathematical declaration acceptance',
        'actualReceipts':[{'job_id':k,**v} for k,v in sorted(receipts.items())],
        'ownedInventory':{'named':68,'owned':68,'actualMappedNames':owned['actualMappedNames'],
            'actualOwnedNames':owned['actualOwnedNames'],'actualDirectImports':owned['actualDirectImports'],
            'exactConfiguredImportsChecked':True,'compilerOnlyHelpers':[]},
        'axiomAudit':{'sorryAx_found':False,'unexpected_axioms':[],
            'allowedStandardAxioms':sorted(leaf_review.STD),'scope':'all68 actual named type/value/recursor owner and axiom closures'},
        'binderInfoScope':{'sourceSignatureRawFlags':[{'original':r['original'],**r['rawSignatureFlags']} for r in named],
            'allOriginalRawSignatureBinderInfoEqual':False,'all68FaithfulReplaySignaturesAccepted':True,
            'all68ExactDataSlotAccountingAccepted':True,'completeComputationalValuesSemanticReplayAccepted':True,
            'completeRecursorRulesSemanticReplayAccepted':True,'computationalValueRawBinderInfoIdentityTested':False,
            'recursorRuleRawBinderInfoIdentityTested':False,'rawComputationalAnnotationEqualityClaimed':False,
            'genuineSourceProofInferredTypeBinderInfoAllEqual':True,'sourceProofStandaloneAliases':[]},
        'sourceDefinition':leaf_review.pin(DEF),'sourcePlans':progress['sourcePlans'],
        'exactInputOverridePlans':override_pins,
        'frozenPassed':leaf_review.pin(FROZEN),'mergeTool':leaf_review.pin(Path(__file__)),
        'leafReviewTool':leaf_review.pin(HERE/'merge_actual.py'),
        'all200FormalAccepted':False,'root_graph_membership':False,'publicationReady':False,
        'deliveryGatesCompletedByThisMathMerge':False,'compilerCiApiGitCalled':False,
        'originalGBExportsReadOrRehashed':False}
    dump(a.dossier,result);progress['finalDossierWritten']=True;progress['dossier']=leaf_review.pin(a.dossier)
    dump(a.progress,progress)
    print(json.dumps({'dossier':leaf_review.pin(a.dossier),'kernelCoverage':coverage,
        'actualReceipts':117,'all68NamedMathGatesPassed':True,'publicationReady':False}))


if __name__=='__main__':main()
