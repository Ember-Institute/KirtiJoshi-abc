#!/usr/bin/env python3
"""Merge saved accepted Basic evidence only. No compiler, CI, API, Git, or publication."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
B = W / '.local/adaptation/reference-initial-theta-carriers-20261115'
FROZEN = Path('/tmp/p2m-local-basic-remaining-v24-20261116/frozen-passed-local-basic.json')
FROZEN_SHA = 'c2a308b291296c90fdc9a40c0bce0f88cc4b45e62efd89b49f0ced0e47674df1'
GAPS = FROZEN.parent / 'remaining-gaps.json'
GAPS_SHA = 'f6c267aabab8661d49db8e61c3d5351a5bd678afc56fd428578358532c9a735a'
OWNER = 'Iut.Cor312.ThetaData.Basic'
SOURCE_SHA = '9e331bf500a6a60170e8425862e897a0a496112fcab0738a2b4e88261062a02b'
AUDITOR_SHA = '645b1f173d575bdc766908401e2e81e16f35bf625ef460bab8931c1ced6aa900'
INVENTORY_JOB = 'ci-016383-485e20c0'
CACHE = {}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def load(p):
    return json.loads(Path(p).read_text())


def pin(p):
    p = Path(p).resolve()
    st = p.stat()
    identity = (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
    if p in CACHE:
        old, digest = CACHE[p]
        need(old == identity, 'Saved input changed during merge: ' + str(p))
    else:
        need(st.st_size <= 32 * 1024**2, 'Unexpected large input; do not load original exports: ' + str(p))
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        CACHE[p] = (identity, digest)
    return {'path': str(p), 'sha256': digest}


def checked(binding):
    need(pin(binding['path'])['sha256'] == binding['sha256'], 'Saved pin changed: ' + binding['path'])
    return Path(binding['path'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--master-plan', type=Path, default=B/'basic26-complete-v25/basic26-plan.json')
    parser.add_argument('--actual', type=Path, action='append', default=[],
        help='Saved actual correspondence aggregate; may repeat. Omit to use existing batch01..04 files.')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    need(not out.exists(), 'Output exists; use a new review filename')
    checked({'path': str(FROZEN), 'sha256': FROZEN_SHA})
    checked({'path': str(GAPS), 'sha256': GAPS_SHA})
    frozen, gaps = load(FROZEN), load(GAPS)
    master = load(args.master_plan)
    master_pin = pin(args.master_plan)
    pending_names = {x['original'] for x in master['leaves']}
    expected_rows = [r for r in gaps['declarations'] if r['owner'] == OWNER]
    expected_names = {r['original'] for r in expected_rows}
    previous = [r for r in frozen['declarations'] if r['owner'] == OWNER]
    previous_names = {r['original'] for r in previous}
    need(len(expected_names) == 34 and len(previous_names) == 8 and len(pending_names) == 26,
         'Expected frozen Basic 34 = prior8 + actual26')
    need(not previous_names & pending_names and previous_names | pending_names == expected_names,
         'Master plan differs from exact Basic frozen complement')
    need(all(x['mode'] == 'complete-existing' for x in master['leaves']), 'Basic has no exceptional slots')
    summary = next(x for x in gaps['summaries'] if x['owner'] == OWNER)
    need((summary['named'], summary['genuineProofValues'], summary['owned'], summary['exceptionalTotal']) == (34,0,34,0),
         'Basic fixed coverage changed')
    # The saved global job supplies only this module's import/owner inventory.
    inventory_receipt_path = B/'tate-thin-global-owned-closure-v14-result.json'
    inventory_report_path = B/'tate-priority-v14/global-result.json'
    checked({'path':str(inventory_receipt_path),'sha256':'ec5d26d2ec5cd7ad815e94ec8e91b7d0d8f7703755984de5e957b72d9574fb9f'})
    checked({'path':str(inventory_report_path),'sha256':'f4ade698fe398f2a9bde7023019597a33f71800b29277a6bf410815ff1647533'})
    inv_receipt, inv_report = load(inventory_receipt_path), load(inventory_report_path)
    need(inv_receipt['job_id'] == INVENTORY_JOB and inv_receipt['status'] == 'succeeded', 'Wrong saved inventory job')
    inv_config_path = Path(inv_receipt['request']['environment']['NEXT_CARRIER_AUDIT_CONFIG'])
    inv_config = load(inv_config_path)
    need(inv_receipt['request']['worktree_manifest']['input_hashes'].get(str(inv_config_path)) == pin(inv_config_path)['sha256'],
         'Saved global inventory config input pin changed')
    module = next(x for x in inv_report['report']['modules'] if x['sourceOwner'] == OWNER)
    module_index = inv_report['report']['modules'].index(module)
    module_cfg = next(x for x in inv_config['modules'] if x['original'] == OWNER)
    current_source = module_cfg['actualInstalledTarget']
    checked(current_source)
    need(current_source['sha256'] == SOURCE_SHA, 'Current Basic source differs from saved inventory source')
    need(module['exactConfiguredImportsChecked'] and len(module['actualMappedNames']) == 34 and
         set(module['actualMappedNames']) == set(module['actualOwnedNames']) and len(module['actualOwnedNames']) == 34,
         'Saved Basic import/owner inventory is not exact 34/34')
    # Identity data come from a previously accepted complete configuration.
    first = previous[0]['leaves'][0]
    cfg = load(checked(first['config']))
    identities = {x['original']: x for x in cfg['projectMap'] if x['original'] in expected_names}
    need(len(identities) == 34 and {x['target'] for x in identities.values()} == set(module['actualOwnedNames']),
         'Exact Basic named identities differ from saved inventory')
    evidence, origins = {}, {}
    for row in previous:
        need(len(row['leaves']) == 1, 'Expected one prior complete-existing leaf')
        e = row['leaves'][0]
        need(e['mode'] == 'complete-existing' and e['innerGatesChecked'] and e['currentSourceConfigAndRecordPinsMatch'],
             'Prior-eight frozen accepted summary is incomplete')
        evidence[row['original']] = e
        origins[row['original']] = {'aggregate': pin(FROZEN), 'jsonPointer': '/declarations/' + str(frozen['declarations'].index(row)) + '/leaves/0'}
    actual_files = args.actual or [p for i in range(1,5)
        if (p := args.master_plan.parent/f'actual-batch{i:02d}-correspondence.json').exists()]
    aggregate_pins = []
    for path in actual_files:
        actual = load(path)
        aggregate_pin = pin(path)
        aggregate_pins.append(aggregate_pin)
        need(actual['plan'] == master_pin, 'Actual aggregate belongs to a different master plan')
        for index, candidate in enumerate(actual['actualCorrespondenceCandidates']):
            name = candidate['original']
            need(name in pending_names, 'Unexpected/previously-passed Basic name in actual26 aggregate')
            if not candidate['accepted']:
                continue
            need(candidate['requiredModes'] == ['complete-existing'] and len(candidate['actualEvidence']) == 1,
                 'Actual aggregate has wrong complete slot')
            e = candidate['actualEvidence'][0]
            need(e['accepted'] and e['innerRequiredGatesPassed'] and e['all20ActualInputPinsChecked'],
                 'Actual accepted summary lacks root inner/pin review')
            if name in evidence:
                need(evidence[name] == e, 'Conflicting accepted saved evidence for ' + name)
                continue
            evidence[name] = e
            origins[name] = {'aggregate': aggregate_pin, 'jsonPointer': '/actualCorrespondenceCandidates/' + str(index) + '/actualEvidence/0'}
    named, leaves, receipts, raw_flags = [], [], {}, []
    for name in sorted(expected_names):
        identity = copy.deepcopy(identities[name])
        identity.pop('required', None)
        identity.pop('mappingRole', None)
        e = evidence.get(name)
        row = {**identity, 'accepted': e is not None, 'requiredModes': ['complete-existing']}
        if e is not None:
            # Reuse saved root judgments; no expression replay or new mathematical review.
            item = copy.deepcopy(e)
            for key in ('receipt', 'source', 'config', 'sourceRecord', 'report'):
                checked(item[key])
            need(item['source']['sha256'] == AUDITOR_SHA, 'Accepted Basic leaf used a different auditor')
            receipt = load(item['receipt']['path'])
            need(receipt['status'] == 'succeeded' and receipt['job_id'] == item['job_id'], 'Saved receipt is not its accepted terminal job')
            pins = receipt['request']['worktree_manifest']['input_hashes']
            for key in ('source', 'config', 'sourceRecord'):
                b = item[key]
                need(pins.get(b['path']) == b['sha256'], 'Saved leaf input pin differs: ' + key)
            resources = receipt['resources']
            need(item['resources'] == resources, 'Saved resource summary differs from receipt')
            item['resourceSource'] = 'MCP-CI receipt.resources; process-tree physical RSS; PSS unknown when null'
            item['actualInputPins'] = pins
            item['savedRootReview'] = origins[name]
            report = load(item['report']['path'])
            signature = report['report']['signature']
            flags = {k: signature[k] for k in ('rawSignatureBinderInventoryEqual', 'rawSignatureBinderPlacementEqual', 'rawFalseRemainsLiteral')}
            cached = item.get('originalRawFlags', item.get('rawFlags'))
            need(flags == cached, 'Raw signature summary changed')
            item['rawFlags'] = flags
            item['savedSourceGuards'] = report['report']['sourceGuards']
            item['savedWholeValueAndRules'] = report['report']['wholeValueAndRules']['wholeValueAndRules']
            item['savedOwnerAndAxiomClosureSummary'] = {k:v for k,v in report['report']['ownerAndAxiomClosure'].items()
                if k in ('name','constantKind','hasSorryAx','axioms','typeAxioms','valueAxioms','isInstance','hasValue')}
            item['savedStrictDagSummary'] = {k:v for k,v in report['sharedLosslessExpressionEvidence'].items() if k != 'exprDag'}
            item['mathematicalGatesReauditedByMerge'] = False
            row.update(actualEvidence=[item], rawSignatureFlags=flags,
                actualOwnerTypeValueRecursorAxiomEvidence=item['report'], savedRootReview=origins[name])
            leaves.append(item)
            receipts[item['job_id']] = item['receipt']
            raw_flags.append({'original':name, **flags})
        else:
            row.update(actualEvidence=[], missingActualMathGates=['accepted complete-existing terminal receipt and root inner correspondence'])
        named.append(row)
    missing = sorted(expected_names - evidence.keys())
    all_math = not missing
    inventory = {'job_id': INVENTORY_JOB, 'receipt': pin(inventory_receipt_path), 'report': pin(inventory_report_path),
        'config': pin(inv_config_path), 'jsonPointer': '/report/modules/' + str(module_index),
        'currentBasicSource': current_source, 'scope': 'Basic exact import and owner inventory only',
        'resources': inv_receipt['resources'], 'resourceSource': 'MCP-CI receipt.resources; process-tree physical RSS',
        'actualInputPins': inv_receipt['request']['worktree_manifest']['input_hashes'],
        'namedMathematicalChecksClaimedFromInventory': False}
    dossier = {'schema': 'basic34-actual-kernel-dossier-v27',
        'status': 'all required Basic local math gates merged from saved root-accepted evidence' if all_math else 'not-ready: saved actual Basic declaration evidence remains incomplete',
        'module': OWNER, 'kernelCoverage': {'source':34,'resolved':34,'named':34,'proof':0,'standard_proof':0,'source_proof_standalone_aliases':0} if all_math else None,
        'progressCoverage': {'requiredNamed':34,'acceptedNamed':len(evidence),'missingNamed':len(missing),'proof':0,'owned':34},
        'all34NamedMathGatesPassed': all_math, 'all34OwnedAxiomAndOwnerClosuresPassed': all_math,
        'all0OriginalProofsAndParentValuesPassed': True, 'locallyCompleteNamedCount': len(evidence),
        'missingActualMathGates': missing, 'sourceDefinition': current_source, 'sourcePlan': master_pin,
        'namedCorrespondence': named, 'genuineSourceProofValues': [], 'actualLeafResults': leaves,
        'reusedPriorLeaves': [x for x in leaves if x['original'] in previous_names],
        'actualGlobalClosureResult': inventory, 'actualReceipts':[{'job_id':k,**v} for k,v in sorted(receipts.items())],
        'ownedInventory': {'named':34,'owned':34, 'actualMappedNames':module['actualMappedNames'],
            'actualOwnedNames':module['actualOwnedNames'], 'actualDirectImports':module['actualDirectImports'],
            'exactConfiguredImportsChecked':True,'compilerOnlyHelpers':[], 'currentBasicSource':current_source,
            'actualInventoryEvidence':inventory},
        'axiomAudit': {'sorryAx_found':False, 'unexpected_axioms':[], 'allowedStandardAxioms':['Classical.choice','Quot.sound','propext'],
            'scope':'saved root-accepted Basic declaration closures only', 'acceptedClosureCount':len(evidence), 'all34ClosuresAccepted':all_math},
        'binderInfoScope': {'sourceSignatureRawFlags':raw_flags,
            'allOriginalRawSignatureBinderInfoEqual': all(x['rawSignatureBinderInventoryEqual'] and x['rawSignatureBinderPlacementEqual'] for x in raw_flags) if all_math else None,
            'all34FaithfulReplaySignaturesAccepted':all_math, 'all34ExactDataSlotAccountingAccepted':all_math,
            'completeComputationalValuesSemanticReplayAccepted':all_math, 'completeRecursorRulesSemanticReplayAccepted':all_math,
            'computationalValueRawBinderInfoIdentityTested':False,'recursorRuleRawBinderInfoIdentityTested':False,
            'rawComputationalAnnotationEqualityClaimed':False,'sourceProofStandaloneAliases':[]},
        'frozenPriorPassed':pin(FROZEN), 'actual26AggregateInputs':aggregate_pins,
        'largeEvidencePolicy':{'originalGBEnvironmentExportsReadOrRehashed':False,'mathematicalRechecksPerformed':False},
        'sourceProofValuesAreAdditionalNamedTargets':False, 'fullGlobalInventoryIsNotGlobal200MathAcceptance':True,
        'all200FormalAccepted':False,'root_graph_membership':False,'publicationReady':False,
        'deliveryGatesCompletedByThisMathMerge':False,'compilerOrCIRunByThisScript':False,'mergeTool':pin(__file__)}
    for p in CACHE:
        pin(p)
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(dossier,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'dossier':pin(out),'acceptedNamed':len(evidence),'requiredNamed':34,
        'missingActualMathGates':missing,'BasicMathComplete':all_math,'publicationReady':False,'all200FormalAccepted':False}))


if __name__ == '__main__':
    main()
