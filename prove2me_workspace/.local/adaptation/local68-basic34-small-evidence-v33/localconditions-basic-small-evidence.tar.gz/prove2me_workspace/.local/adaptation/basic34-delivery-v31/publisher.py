"""One-Definition draft using the existing private Definition publication protocol.
Import/check do not call an API. Root must bind completed actual evidence first.
"""
from pathlib import Path
import ast
import hashlib
import json
import time
import urllib.parse

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
OUT = Path(__file__).resolve().parent
ENV = '0df444a360eaa60ab8c11dca51a86af692955474'
MISSION = 'eeb5193f-68c0-41d0-9263-4a5ff7c801ee'
ROOT = 'e33ff731-60a7-43ef-87ae-c12aeba23cb5'
CREATOR = '89966734-f388-427a-9ea1-983923ff28a1'
PROTOCOL = W / '.local/adaptation/reference-volume-tate-carriers-20261115/delivery.py'
GATES = {'new_leaf_modules', 'checks_axioms', 'wrapped_kernel_type_identity',
    'new_leaf_artifacts', 'import_audit', 'act1scene1', 'axiom_audit',
    'independent_readbacks', 'source_ledger_consumers', 'git_diff_check',
    'existing_mission_scope', 'final_frozen_review'}


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def check(packet_path, ready_path):
    packet, ready = read(packet_path), read(ready_path)
    profile = read(OUT / 'module-profile.json')
    require(ready['passed'] is True and packet['publicationReady'] is True,
            'This is an unready draft until root binds the actual module results.')
    require(ready['packet_sha256'] == sha(packet_path), 'The packet binding changed.')
    require(set(ready['gates']) == GATES and all(value is True for value in ready['gates'].values())
            and ready['pending'] == [], 'An existing delivery gate is pending.')
    require(ready['pending_bindings'] == {} or all(value is not None for value in ready['pending_bindings'].values()),
            'An existing final evidence binding is pending.')
    require(packet['kernel_coverage'] == ready['kernel_coverage'] == profile['requiredKernelCoverage'],
            'Root must bind this module actual named/proof coverage.')
    require(packet['required_owned_count'] == profile['requiredOwnedCount'] and
            packet['target_only_compiler_helpers'] == [], 'Keep this module ownership scope.')
    require(packet['workspace'] == str(W) and packet['mission_id'] == MISSION and
            packet['root_id'] == ROOT and packet['environment'] == ENV and
            packet['visibility'] == 'private' and packet['verification'] == [] and
            packet['publication_post_limit'] == 1, 'Use the existing private one-Definition scope.')
    require(packet['root_graph_membership'] is False and packet['canonicalC22Connected'] is False and
            packet['all200FormalAccepted'] is ready['all200FormalAccepted'] is False and
            packet['module_scope']['scopeAllFourModules'] is False, 'Keep the single-module scope.')
    require(packet['actual_kernel_evidence'] is not None and packet['actual_leaf_results'] is not None and
            packet['actual_global_closure_result'] is not None, 'The actual module dossier is not bound.')
    require(packet['source_proof_values'] == [] and packet['source_proof_standalone_aliases'] == [],
            'Do not import the Orbicurve/Tate source-proof counts into this module.')
    require(ready['axiom_audit']['sorryAx_found'] is False and ready['axiom_audit']['unexpected_axioms'] == [],
            'The existing axiom gate is pending.')
    require(not packet['pending_parent_bindings'], 'A prerequisite Definition identity is pending.')
    for group in ready['ci_receipts'].values():
        require(bool(group), 'An existing CI gate lacks its bound receipt.')
        require(all(path in ready['evidence_sha256'] for path in group), 'A receipt lacks its hash.')
    require(bool(ready['gate_evidence']['final_frozen_review']), 'The existing final frozen review is pending.')
    for path, digest in {**packet['metadata_sha256'], **ready['evidence_sha256']}.items():
        require(sha(path) == digest, 'Pinned evidence changed: ' + path)
    for path, digest in packet['source_sha256'].items():
        require(sha(W / path) == digest, 'The installed source changed: ' + path)
    row, = packet['publications']
    require(row['endpoint'] == '/submit-definition' and row['tag'] == profile['definitionName'] and
            row['payload']['definition_name'] == profile['definitionName'] and
            row['payload']['env'] == ENV and row['payload']['private'] is True, 'The payload scope changed.')
    require(row['payload']['definition'] == (W / profile['target']).read_text(), 'The payload source changed.')
    frozen = read(OUT / 'readback.json')
    require(all(frozen[key] in row['payload']['natural_language_statement'] for key in ['en', 'zh-Hans', 'ja']),
            'The frozen readback changed.')
    return packet


def _protocol():
    names = {'check_scope', 'check_job', 'check_definition', 'poll'}
    nodes = [node for node in ast.parse(PROTOCOL.read_text()).body
        if isinstance(node, ast.FunctionDef) and node.name in names]
    require({node.name for node in nodes} == names, 'The existing Definition protocol changed.')
    namespace = dict(Path=Path, read=read, save=save, require=require, ENV=ENV,
        MISSION=MISSION, ROOT=ROOT, CREATOR=CREATOR, time=time, urllib=urllib)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<existing-definition-network-protocol>', 'exec'), namespace)
    return namespace


def _parents(api, packet, directory):
    profile = read(OUT / 'module-profile.json')
    require([row['definitionName'] for row in packet['parent_foundation_definitions']] ==
            profile['directImportedDefinitions'], 'Use the exact existing source imports.')
    for parent in packet['parent_foundation_definitions']:
        prior = parent['registryEvidence']
        require(prior['id'] is not None, 'Publish and bind the prerequisite Definition first.')
        item = api.request('/definitions/' + urllib.parse.quote(prior['id'], safe=''))
        save(directory / ('parent-' + prior['name'] + '.json'), item)
        require(item['definition_id'] == prior['id'] and item['definition_name'] == prior['name'] and
                item['visibility'] == 'private' and item['mathlib_rev'] == ENV and
                item['deprecated_at'] is None, 'A published direct parent changed.')
        require(hashlib.sha256(item['definition'].encode()).hexdigest() == parent['currentDefinition']['sha256'],
                'A published parent source changed.')


def deliver(api, packet_path, ready_path, directory, timeout_seconds=900):
    packet = check(packet_path, ready_path)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    protocol = _protocol()
    protocol['check_scope'](api, directory)
    _parents(api, packet, directory)
    before = api.request('/theorems/' + ROOT + '/graph')
    baseline = directory / 'root-graph-before.json'
    if baseline.exists():
        require(read(baseline) == before, 'The original mission graph changed.')
    else:
        save(baseline, before)
    row, = packet['publications']
    binding = directory / 'packet-binding.json'
    identity = {'packet_sha256': sha(packet_path), 'names': [row['tag']]}
    if binding.exists():
        require(read(binding) == identity, 'The journal belongs to another packet.')
    else:
        save(binding, identity)
    intent, submitted = directory / (row['tag'] + '-intent.json'), directory / (row['tag'] + '-submit.json')
    if intent.exists():
        require(read(intent) == row and submitted.exists(), 'Reconcile the original POST outcome before another submission.')
    else:
        require(not submitted.exists(), 'The original submission intent is missing.')
        save(intent, row)
        save(submitted, api.request('/submit-definition', row['payload'], 'POST'))
    posted = read(submitted)
    require(posted.get('job_id') and not posted.get('errors'), 'The original POST receipt is invalid.')
    job = protocol['poll'](api, directory, row, posted['job_id'], timeout_seconds)
    protocol['check_definition'](api, directory, row, job['theorem_id'])
    after = api.request('/theorems/' + ROOT + '/graph')
    save(directory / 'root-graph-after.json', after)
    require(before == after, 'Definition publication changed the mission graph.')
    ids = {row['tag']: job['theorem_id']}
    save(directory / 'published-ids.json', ids)
    return ids


def reconcile(api, packet_path, ready_path, directory, job_id):
    packet = check(packet_path, ready_path)
    directory = Path(directory)
    row, = packet['publications']
    require(read(directory / (row['tag'] + '-intent.json')) == row, 'The original submission intent changed.')
    protocol = _protocol()
    protocol['check_scope'](api, directory)
    job = api.request('/publish-jobs/' + urllib.parse.quote(job_id, safe=''))
    save(directory / (row['tag'] + '-reconcile-readback.json'), job)
    protocol['check_job'](job, row)
    require(job['id'] == job_id and job['status'] == 'PUBLISHED', 'The original job has not published.')
    protocol['check_definition'](api, directory, row, job['theorem_id'])
    submitted = directory / (row['tag'] + '-submit.json')
    if submitted.exists():
        require(read(submitted)['job_id'] == job_id, 'Another original job is already bound.')
    else:
        save(submitted, {'job_id': job_id, 'reconciled_exact_readback': True})
    return job['theorem_id']
