#!/usr/bin/env python3
"""Root offline binding to the unchanged one-Definition publisher. No CI/API/Git."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
REGISTRY = W/'.local/adaptation/platform-node-registry.json'
PIN_MANIFEST_SHA = 'af0e3d1b2234831a048e017514a197961d7e8e0feef43b0b68cb547503c4342a'
BASIC_DOSSIER_SHA = '0efd5de890fd1b5d3180da270635e4fed31dfc1549d7939698f63955773b2b99'
LOCAL_NAME = 'AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions'
CACHE = {}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read(p):
    return json.loads(Path(p).read_text())


def pin(p):
    p = Path(p).resolve()
    st = p.stat()
    identity = (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
    if p in CACHE:
        before, digest = CACHE[p]
        need(before == identity, 'Pinned input changed during binding: '+str(p))
    else:
        need(st.st_size <= 32*1024**2, 'Do not rehash large exports: '+str(p))
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        CACHE[p] = (identity,digest)
    return {'path':str(p),'sha256':digest}


def checked(b):
    need(pin(b['path'])['sha256'] == b['sha256'], 'Pinned evidence changed: '+b['path'])
    return Path(b['path'])


def save(p, value):
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def frozen(module):
    manifest = HERE/'frozen-input-pins.json'
    need(pin(manifest)['sha256']==PIN_MANIFEST_SHA,'Frozen v24 snapshot pin manifest changed')
    for b in read(manifest):
        checked(b)
    base = HERE/'frozen'/module
    return base, read(base/'packet.json'), read(base/'module-profile.json')


def parent_packet(module, registry_path, local_published_readback=None):
    base, packet, profile = frozen(module)
    registry = read(registry_path)
    definitions = registry['reference_source_preparation']['definitions']
    rows = {x['name']:x for x in definitions}
    need(len(rows)==len(definitions), 'Registry has duplicate Definition names')
    for parent in packet['parent_foundation_definitions']:
        name = parent['definitionName']
        row = rows.get(name)
        if name == LOCAL_NAME and module=='Basic' and row is None:
            need(local_published_readback is not None,'Basic requires the real newly published LocalConditions readback')
            item = read(local_published_readback)
            need(item['definition_name']==name and item['definition_id'],'Wrong LocalConditions published readback')
            row = {'name':name,'id':item['definition_id'],'status':'PUBLISHED'}
        need(row is not None and row.get('id'),'A real published direct parent is missing: '+name)
        old_id = parent['registryEvidence']['id']
        need(old_id is None or old_id==row['id'],'An existing direct parent ID changed: '+name)
        parent['registryEvidence']={'name':name,'id':row['id'],'status':'PUBLISHED'}
        parent['savedPublicationEvidence']={'registry':pin(registry_path)}
        if name==LOCAL_NAME and module=='Basic' and local_published_readback is not None:
            parent['savedPublicationEvidence']['publishedReadback']=pin(local_published_readback)
    packet['pending_parent_bindings']=[]
    return base,packet,profile


def bind(module,dossier_path,dossier_sha,git_diff_check,scope_directory,out,registry_path=REGISTRY,local_published_readback=None):
    dossier_path,git_diff_check,scope_directory,out,registry_path = map(Path,[dossier_path,git_diff_check,scope_directory,out,registry_path])
    need(not out.exists(),'Output exists; never overwrite a frozen packet or publication journal')
    base,packet,profile=parent_packet(module,registry_path,local_published_readback)
    dossier_pin=pin(dossier_path)
    need(dossier_pin['sha256']==dossier_sha,'Root supplied dossier SHA differs')
    if module=='Basic':
        need(dossier_sha==BASIC_DOSSIER_SHA,'Use the frozen actual Basic34 final dossier')
    dossier=read(dossier_path)
    coverage=profile['requiredKernelCoverage'];count=coverage['named']
    need(dossier['module']==profile['module'] and dossier.get('kernelCoverage')==coverage,'Complete actual module coverage is required')
    need(dossier.get(f'all{count}NamedMathGatesPassed') is True and
         dossier.get(f'all{count}OwnedAxiomAndOwnerClosuresPassed') is True,'Actual named/owned math dossier is not complete')
    named=dossier['namedCorrespondence']
    need(len(named)==count and len({r['original'] for r in named})==count and all(r['accepted'] for r in named),
         'Every original declaration needs saved root-accepted actual correspondence')
    need(dossier['genuineSourceProofValues']==[] and dossier['ownedInventory']['compilerOnlyHelpers']==[], 'Keep this module proof/helper counts at zero')
    need(dossier['ownedInventory']['named']==count and dossier['ownedInventory']['owned']==count,'Exact owned scope changed')
    need(dossier['sourceDefinition']['sha256']==profile['sourceSha256']==pin(W/profile['target'])['sha256'], 'Actual current module source differs')
    checked(dossier['sourceDefinition'])
    need(dossier['axiomAudit']['sorryAx_found'] is False and dossier['axiomAudit']['unexpected_axioms']==[], 'Actual axiom dossier is not accepted')
    need(not dossier.get('missingActualMathGates',[]),'Actual math gates remain pending')
    # Generic Basic keys and the existing Local final merger's leaf-list alias.
    leaves=dossier.get('actualLeafResults',dossier.get('actual48LeafResults'))
    need(leaves is not None and len(leaves)>0,'Actual leaf result list missing')
    closure=dossier['actualGlobalClosureResult']
    closure_paths=[]
    for key in ('receipt','source','config','report'):
        if key in closure:
            closure_paths.append(checked(closure[key]))
    receipts=dossier['actualReceipts']
    for r in receipts:
        checked(r)
        actual=read(r['path'])
        need(actual['job_id']==r['job_id'] and actual['status']=='succeeded' and actual['result']['exit_code']==0,
             'Saved root-accepted terminal receipt changed')
    reuse_path=HERE/f'{module}-production-gate-reuse.json';reuse=read(reuse_path)
    checked(reuse['productionReceipt'])
    for r in reuse['productionPinnedInputs']:
        need(r['sha256']==r['expectedFromReceipt'],'Production input pin changed')
        checked(r)
    for r in reuse['existingModuleLeafAndArtifact']:
        checked(r)
        need(r['currentSourceSha256']==profile['sourceSha256'],'Native leaf/artifact has a different source version')
    scope_paths=[scope_directory/'mission-list-readback.json',scope_directory/'mission-root-readback.json']
    listing,root=map(read,scope_paths)
    mission,=[r for r in listing['missions'] if r['id']==packet['mission_id']]
    need(mission['visibility']=='private' and mission['creator']['id']=='89966734-f388-427a-9ea1-983923ff28a1' and
         mission['main_theorem']['theorem_id']==packet['root_id'] and root['visibility']=='private' and root['mathlib_rev']==packet['environment'],
         'Existing private mission scope differs')
    parent_paths=[]
    for parent in packet['parent_foundation_definitions']:
        p=scope_directory/('parent-'+parent['definitionName']+'.json');item=read(p)
        need(item['definition_id']==parent['registryEvidence']['id'] and item['definition_name']==parent['definitionName'] and
             item['visibility']=='private' and item['mathlib_rev']==packet['environment'] and item['deprecated_at'] is None,'Current direct parent scope differs')
        need(hashlib.sha256(item['definition'].encode()).hexdigest()==parent['currentDefinition']['sha256'], 'Published parent source differs')
        checked(parent['currentDefinition'])
        parent['savedPublicationEvidence']['publishedReadback']=pin(p);parent_paths.append(p)
    need([p['definitionName'] for p in packet['parent_foundation_definitions']]==profile['directImportedDefinitions'], 'Direct parent order changed')
    diff=read(git_diff_check)
    need(diff.get('passed') is True or diff.get('exit_code')==0,'Root actual git diff check is not passed')
    # Everything above is binding of previously accepted evidence, not new math.
    shutil.copytree(base,out)
    ready=read(out/'ready.template.json');ledger=read(out/'source-ledger.candidate.json')
    lookup={r['original']:r for r in named}
    for row in ledger['namedCorrespondence']:
        actual=lookup[row['original']]
        need(row['target']==actual['target'],'Named source/target identity changed')
        row.update(accepted=True,actualEvidence=actual['actualEvidence'],actualCorrespondence=actual)
    ledger.update(status='Actual single module math dossier bound; private publication binding only',kernelCoverage=coverage,
        actualKernelDossier=dossier_pin,actualOwnedInventory=dossier['ownedInventory'],targetOnlyCompilerProvenanceAccepted=True)
    ledger_path=out/'source-ledger.final.json';save(ledger_path,ledger)
    packet.update(kernel_coverage=coverage,actual_kernel_receipt=closure['receipt']['path'],actual_kernel_job_id=closure['job_id'],
        actual_kernel_evidence=dossier_pin,actual_leaf_results=leaves,actual_global_closure_result=closure,
        binder_info_scope=dossier['binderInfoScope'],publicationReady=True)
    need(packet['publications'][0]['payload']==read(out/'payload.json'),'Frozen payload changed')
    for f in ['Definition.lean','payload.json','readback.json','paper-context.json','readback-original-pins.json','publisher.py']:
        need((out/f).read_bytes()==(base/f).read_bytes(),'Frozen content changed: '+f)
    final_review={'schema':'single-local-basic-final-frozen-review-v31','passed':True,'module':profile['module'],
        'actualDossier':dossier_pin,'sourceSha256':packet['source_sha256'],'frozenSourcePayloadReadbacksMochizukiAndPublisherUnchanged':True,
        'scope':'Existing final_frozen_review delivery binding only; no new mathematical review',
        'canonicalC22Connected':False,'all200FormalAccepted':False}
    review_path=out/'final-frozen-review.json';save(review_path,final_review)
    extras=[dossier_path,ledger_path,reuse_path,review_path,Path(__file__),registry_path,git_diff_check]+scope_paths+parent_paths+closure_paths
    extras += [Path(r['path']) for r in receipts]+[Path(r['path']) for r in reuse['existingModuleLeafAndArtifact']]+[Path(reuse['productionReceipt']['path'])]
    hashes={str(p.resolve()):pin(p)['sha256'] for p in extras}
    packet['metadata_sha256'].update(hashes);save(out/'packet.json',packet)
    ready.update(kernel_coverage=coverage,packet_sha256=pin(out/'packet.json')['sha256'],source_sha256=packet['source_sha256'],axiom_audit=dossier['axiomAudit'])
    ready['evidence_sha256'].update(hashes)
    native={r['kind']:r['path'] for r in reuse['existingModuleLeafAndArtifact']}
    all_receipts=[r['path'] for r in receipts]
    production=reuse['productionReceipt']['path']
    ready['ci_receipts'].update(new_leaf_modules=[native['leaf']],new_leaf_artifacts=[native['artifact']],
        wrapped_kernel_type_identity=all_receipts,checks_axioms=all_receipts,
        import_audit=[production],act1scene1=[production],axiom_audit=[production]+all_receipts)
    ready['gate_evidence'].update(source_ledger_consumers=[str(ledger_path)],git_diff_check=[str(git_diff_check)],
        existing_mission_scope=[str(p) for p in scope_paths+parent_paths],final_frozen_review=[str(review_path)])
    ready['pending_bindings'].update(actualModuleDossier=dossier_pin,actualNamedProofOwnedCoverage={'kernelCoverage':coverage,'owned':count},
        sourceSignatureRawFlags=dossier['binderInfoScope'],recursiveAxiomAudit=dossier['axiomAudit'],
        currentDirectPublishedParents=[pin(p) for p in parent_paths],finalLeafArtifactVersionSha=reuse['existingModuleLeafAndArtifact'],
        existingProductionReuse=pin(reuse_path),existingPrivateMissionScope=[pin(p) for p in scope_paths],
        gitDiffCheck=pin(git_diff_check),finalFrozenReview=pin(review_path))
    ready.update(gates={k:True for k in ready['gates']},pending=[],passed=True,
        note='Exact actual module dossier and existing twelve gates bound; frozen one-Definition protocol/payload unchanged')
    save(out/'ready.final.json',ready)
    publisher=load_module('unchanged_v24_publisher',out/'publisher.py')
    publisher.check(out/'packet.json',out/'ready.final.json')
    return {'packet':pin(out/'packet.json'),'ready':pin(out/'ready.final.json'),'ledger':pin(ledger_path),
        'frozenPayload':pin(out/'payload.json'),'publicationPOSTPerformed':False,'all200FormalAccepted':False}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--module',choices=['LocalConditions','Basic'],required=True)
    p.add_argument('--dossier',type=Path,required=True);p.add_argument('--dossier-sha256',required=True)
    p.add_argument('--git-diff-check',type=Path,required=True);p.add_argument('--scope-directory',type=Path,required=True)
    p.add_argument('--registry',type=Path,default=REGISTRY);p.add_argument('--local-published-readback',type=Path)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    print(json.dumps(bind(a.module,a.dossier,a.dossier_sha256,a.git_diff_check,a.scope_directory,a.out,a.registry,a.local_published_readback),ensure_ascii=False,indent=2))
