#!/usr/bin/env python3
"""Offline metadata-only drafts for LocalConditions then Basic. No API/compiler/CI/Git."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sys
sys.dont_write_bytecode = True

OUT = Path(__file__).resolve().parent
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
I = W / '.local/adaptation/reference-initial-theta-carriers-20261115'
ENV = '0df444a360eaa60ab8c11dca51a86af692955474'
MODULES = [('LocalConditions', 68), ('Basic', 34)]
GATES = ['new_leaf_modules', 'checks_axioms', 'wrapped_kernel_type_identity',
    'new_leaf_artifacts', 'import_audit', 'act1scene1', 'axiom_audit',
    'independent_readbacks', 'source_ledger_consumers', 'git_diff_check',
    'existing_mission_scope', 'final_frozen_review']


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    path = Path(path)
    assert path.stat().st_size < 16 * 1024 ** 2, 'Reuse a prior pin for large evidence'
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path):
    return {'path': str(Path(path).resolve()), 'sha256': sha(path)}


def save(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(OUT)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def prepare():
    shutil.copyfile(W.parent / 'refer/iut/LICENSE', OUT / 'LICENSE.iut.Apache-2.0')
    report_path, blind_path = I / 'generated-wrapped/foundation-wrapper-report.json', I / 'blind-readbacks.json'
    paper_path, ledger_path = I / 'paper-context.json', I / 'SOURCE_LEDGER.json'
    report, blind, paper, ledger = map(read, [report_path, blind_path, paper_path, ledger_path])
    bundles = {row['definitionName']: row for row in report['bundles']}
    protocol_path = I / 'delivery.py'
    spec = importlib.util.spec_from_file_location('existing_initial_offline_metadata', protocol_path)
    protocol = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(protocol)
    # Reuse the completed independent-readback record and formatter. This is a
    # frozen-file/string check, not another mathematical or independent review.
    reviews = protocol.validate_independent_readbacks(blind, bundles)
    registry = read(W / '.local/adaptation/platform-node-registry.json')
    saved_ids = {}

    def registry_ids(value):
        if isinstance(value, dict):
            if isinstance(value.get('name'), str) and value['name'].startswith('AbcAdaptation_Reference_Iut_Cor312_ThetaData_') and value.get('id'):
                saved_ids[value['name']] = value['id']
            for child in value.values():
                registry_ids(child)
        elif isinstance(value, list):
            for child in value:
                registry_ids(child)

    registry_ids(registry)
    frozen_pins = []
    for review in reviews.values():
        original = Path(review['original_artifact'])
        frozen = OUT / 'frozen-readbacks' / (sha(original)[:12] + '-' + original.name)
        frozen.parent.mkdir(exist_ok=True)
        shutil.copyfile(original, frozen)
        frozen_pins.append({'original': pin(original), 'frozenCopy': pin(frozen)})
    outputs = []
    for short, count in MODULES:
        module = 'Iut.Cor312.ThetaData.' + short
        name = 'AbcAdaptation_Reference_' + module.replace('.', '_')
        directory = OUT / short
        directory.mkdir(exist_ok=True)
        generated = bundles[name]
        relative = 'Definitions/Def_' + name + '.lean'
        installed = W / relative
        code = installed.read_text()
        rb = next(row for row in blind['bundles'] if row['definition_name'] == name)
        original = read(rb['provenance']['original_artifact'])['bundles'][rb['provenance']['original_bundle_index']]
        for key in ['en', 'zh-Hans', 'ja', 'pending_chinese_terms', 'declarations', 'ambiguities']:
            assert rb[key] == original[key]
        assert sha(installed) == generated['sha256'] == rb['source_sha256']
        assert installed.read_bytes() == Path(generated['path']).read_bytes()
        assert sha(generated['payload']) == generated['payloadSha256']
        assert read(generated['payload']) == {'definition_name': name, 'code': code}
        paper_row = next(row for row in paper['bundles'] if row['module'] == module)
        assert paper_row['blocks_definition_delivery'] is False
        paper_subset = {key: value for key, value in paper.items() if key in ['schema', 'language', 'purpose']}
        paper_subset['bundles'] = [paper_row]
        paper_subset['quotations'] = [row for row in paper['quotations'] if row['id'] in paper_row['quotation_ids']]
        ids = {row['paper_id'] for row in paper_subset['quotations']}
        paper_subset['paper_sources'] = {key: value for key, value in paper['paper_sources'].items() if key in ids}
        assert {row['id'] for row in paper_subset['quotations']} == set(paper_row['quotation_ids'])
        imported = [line.removeprefix('import Definitions.Def_') for line in code.splitlines()
                    if line.startswith('import Definitions.Def_')]
        parents, pending = [], []
        for parent_name in imported:
            parent_path = W / 'Definitions' / ('Def_' + parent_name + '.lean')
            parent_id = saved_ids.get(parent_name)
            published_path = None
            if parent_name.endswith('_Orbicurve'):
                published_path = W / '.local/adaptation/orbicurve70-delivery-20261116/platform' / (parent_name + '-published-item.json')
            elif parent_name.endswith('_TateFamily'):
                published_path = W / '.local/adaptation/tate28-delivery-20261116/platform' / (parent_name + '-published-item.json')
            evidence = {'registry': pin(W / '.local/adaptation/platform-node-registry.json')}
            if published_path is not None:
                saved = read(published_path)
                assert saved['definition_name'] == parent_name and saved['definition_id'] == parent_id
                assert saved['definition'] == parent_path.read_text()
                evidence['publishedReadback'] = pin(published_path)
            if parent_name.endswith('_LocalConditions'):
                assert short == 'Basic'
                parent_id = None
                pending.append({'definitionName': parent_name, 'id': None,
                    'bindAfter': 'LocalConditions private Definition PUBLISHED exact readback',
                    'draftPacket': str(OUT / 'LocalConditions/packet.json')})
            else:
                assert parent_id is not None
            parents.append({'definitionName': parent_name,
                'registryEvidence': {'name': parent_name, 'id': parent_id,
                    'status': 'PUBLISHED' if parent_id is not None else 'pending LocalConditions publication'},
                'currentDefinition': pin(parent_path), 'savedPublicationEvidence': evidence})
        assert len(parents) == (4 if short == 'LocalConditions' else 5)
        coverage = {'source': count, 'resolved': count, 'named': count, 'proof': 0,
            'standard_proof': 0, 'source_proof_standalone_aliases': 0}
        profile = {'schema': 'initial-single-module-publishing-profile/v24', 'module': module,
            'definitionName': name, 'target': relative, 'sourceSha256': sha(installed),
            'requiredKernelCoverage': coverage, 'requiredOwnedCount': count,
            'genuineSourceProofValues': [], 'compilerOnlyHelpers': [],
            'directImportedDefinitions': imported,
            'coverageBasis': 'Root initial_next_bounded_v11 actual global inventory: LocalConditions68/68, Basic34/34; metadata requirements only, not local acceptance.'}
        save(directory / 'module-profile.json', profile)
        payload = {'definition_name': name, 'definition_title': rb['definition_title'], 'definition': code,
            'natural_language_statement': protocol.publication_statement(rb, paper_row),
            'source': rb['source'], 'env': ENV, 'private': True}
        save(directory / 'payload.json', payload)
        (directory / 'Definition.lean').write_bytes(installed.read_bytes())
        save(directory / 'readback.json', rb)
        save(directory / 'paper-context.json', paper_subset)
        save(directory / 'readback-original-pins.json', {'originalStringsUnchanged': True,
            'validatorReused': pin(protocol_path), 'originalArtifacts': frozen_pins,
            'codeOnlyInput': pin(generated['blindReadback']['path'])})
        commands = [row for row in ledger['records'] if row['module'] == module]
        selected = [declaration for row in commands for declaration in row['ownedSourceDeclarations'] if declaration['selected']]
        assert len(selected) == count and len({row['name'] for row in selected}) == count
        scope = {'module': module, 'scopeAll200': False, 'scopeAllFourModules': False,
            'fourModuleCorrespondenceAccepted': False,
            'pendingModules': ['Iut.Cor312.ThetaData.Basic'] if short == 'LocalConditions' else []}
        projected = {'schema': 'initial-single-module-consumer-projection/v24',
            'status': 'metadata-only draft; actual mathematical binding pending', 'module': module,
            'sourceLedger': pin(ledger_path), 'sourceCommands': commands,
            'structures': [row for row in ledger['structures'] if row['module'] == module],
            'bundle': next(row for row in ledger['bundles'] if row['module'] == module),
            'requiredKernelCoverage': coverage, 'kernelCoverage': None,
            'namedCorrespondence': [{'original': row['name'], 'target': 'AbcAdaptation.Reference.' + row['name'],
                'accepted': False, 'actualEvidence': None} for row in selected],
            'genuineSourceProofValues': [], 'sourceProofStandaloneAliases': [],
            'actualOwnedRequired': count, 'targetOnlyCompilerDeclarations': [],
            'targetOnlyCompilerProvenanceAccepted': False, 'scope': scope,
            'all200FormalAccepted': False, 'canonicalC22Connected': False}
        save(directory / 'source-ledger.candidate.json', projected)
        shutil.copyfile(OUT / 'publisher-template.py', directory / 'publisher.py')
        metadata_paths = [report_path, blind_path, paper_path, ledger_path, protocol_path,
            Path(generated['path']), Path(generated['payload']), Path(generated['blindReadback']['path']),
            OUT / 'publisher-template.py', OUT / 'prepare.py', OUT / 'LICENSE.iut.Apache-2.0', directory / 'publisher.py',
            directory / 'module-profile.json', directory / 'payload.json', directory / 'Definition.lean',
            directory / 'readback.json', directory / 'paper-context.json', directory / 'readback-original-pins.json',
            directory / 'source-ledger.candidate.json']
        metadata_paths += [Path(record['frozenCopy']['path']) for record in frozen_pins]
        metadata_paths += [Path(record['original']['path']) for record in frozen_pins]
        for parent in parents:
            metadata_paths.append(Path(parent['currentDefinition']['path']))
            if 'publishedReadback' in parent['savedPublicationEvidence']:
                metadata_paths.append(Path(parent['savedPublicationEvidence']['publishedReadback']['path']))
        packet = {'schema': 'initial-single-private-definition-draft/v24', 'workspace': str(W),
            'mission_id': protocol.MISSION, 'root_id': protocol.ROOT, 'environment': ENV,
            'scope': protocol.SCOPE, 'visibility': 'private', 'root_graph_membership': False,
            'canonicalC22Connected': False, 'module_scope': scope,
            'required_kernel_coverage': coverage, 'kernel_coverage': None,
            'required_owned_count': count, 'target_only_compiler_helpers': [],
            'source_proof_values': [], 'source_proof_standalone_aliases': [],
            'source_sha256': {relative: sha(installed)},
            'metadata_sha256': {str(path): sha(path) for path in metadata_paths},
            'actual_kernel_receipt': None, 'actual_kernel_job_id': None, 'actual_kernel_evidence': None,
            'actual_leaf_results': None, 'actual_global_closure_result': None,
            'binder_info_scope': {'sourceSignatureRawFlags': None,
                'actualSemanticReplayAcceptance': None, 'rawComputationalAnnotationEqualityClaimed': False},
            'parent_foundation_definitions': parents, 'pending_parent_bindings': pending,
            'publications': [{'tag': name, 'endpoint': '/submit-definition', 'payload': payload}],
            'verification': [], 'publication_post_limit': 1,
            'publicationReady': False, 'all200FormalAccepted': False}
        save(directory / 'packet.json', packet)
        gates = {gate: gate == 'independent_readbacks' for gate in GATES}
        ready = {'schema': 'initial-single-private-definition-ready/v24', 'passed': False,
            'packet_sha256': sha(directory / 'packet.json'), 'source_sha256': packet['source_sha256'],
            'required_kernel_coverage': coverage, 'kernel_coverage': None,
            'module_scope': scope, 'gates': gates,
            'ci_receipts': {gate: [] for gate in GATES[:7]},
            'axiom_audit': {'sorryAx_found': None, 'unexpected_axioms': None, 'scope': 'pending actual module dossier'},
            'gate_evidence': {gate: [str(directory / 'readback.json')] if gate == 'independent_readbacks' else []
                for gate in GATES[7:]}, 'evidence_sha256': packet['metadata_sha256'].copy(),
            'pending': [gate for gate in GATES if not gates[gate]],
            'pending_bindings': {'actualModuleDossier': None, 'actualNamedProofOwnedCoverage': None,
                'sourceSignatureRawFlags': None, 'recursiveAxiomAudit': None,
                'currentDirectPublishedParents': None, 'finalLeafArtifactVersionSha': None,
                'existingProductionReuse': None, 'existingPrivateMissionScope': None,
                'gitDiffCheck': None, 'finalFrozenReview': None},
            'all200FormalAccepted': False,
            'note': 'Only frozen readbacks are reused as an existing completed gate. Root owns the actual mathematical and delivery bindings; no new gate is introduced.'}
        save(directory / 'ready.template.json', ready)
        save(directory / 'terminology-policy.json', {'originalPendingChineseTerms': rb['pending_chinese_terms'],
            'newUnconfirmedTerms': [], 'policy': 'Preserve code identifiers for any new unconfirmed term; record placeholders without blocking offline preparation. No terminology gate.'})
        outputs.append({'module': module, 'directory': str(directory), 'packet': pin(directory / 'packet.json'),
            'definition': pin(directory / 'Definition.lean'), 'requiredCoverage': coverage,
            'requiredOwnedCount': count, 'pendingParents': pending})
    save(OUT / 'draft-index.json', {'schema': 'initial-local-basic-private-drafts/v24',
        'publicationOrder': ['LocalConditions', 'Basic'], 'definitions': outputs,
        'rootOwnsActualMathematicalBindings': True, 'publicationReady': False,
        'canonicalC22Connected': False, 'all200FormalAccepted': False,
        'APIInvoked': False, 'compilerInvoked': False, 'CIInvoked': False, 'GitInvoked': False,
        'mainWorkspaceModified': False})
    return outputs


if __name__ == '__main__':
    print(json.dumps(prepare(), ensure_ascii=False, indent=2))
