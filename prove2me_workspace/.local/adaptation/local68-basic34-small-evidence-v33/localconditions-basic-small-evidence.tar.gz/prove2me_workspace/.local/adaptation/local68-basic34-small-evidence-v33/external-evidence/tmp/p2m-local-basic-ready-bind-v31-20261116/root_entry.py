#!/usr/bin/env python3
"""Explicit root entry to unchanged v24 protocol. This file never runs on import."""
import argparse
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import bind_ready as binding


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['collect-scope','check','deliver','reconcile'])
    p.add_argument('--module',choices=['LocalConditions','Basic'],required=True)
    p.add_argument('--delivery-directory',type=Path)
    p.add_argument('--scope-directory',type=Path)
    p.add_argument('--registry',type=Path,default=binding.REGISTRY)
    p.add_argument('--local-published-readback',type=Path)
    p.add_argument('--job-id')
    a=p.parse_args()
    if a.command=='collect-scope':
        if a.scope_directory is None:p.error('collect-scope requires --scope-directory outside the future binding output')
        base,packet,_=binding.parent_packet(a.module,a.registry,a.local_published_readback)
        publisher=binding.load_module('v24_original_scope_publisher',base/'publisher.py')
        api=binding.load_module('existing_prove2me_api',binding.W/'.local/abc-item/api.py')
        a.scope_directory.mkdir(parents=True,exist_ok=True)
        publisher._protocol()['check_scope'](api,a.scope_directory)
        publisher._parents(api,packet,a.scope_directory)
        print('Existing private scope and exact direct parents saved; no POST.')
        return
    if a.delivery_directory is None:p.error('This command requires --delivery-directory')
    out=a.delivery_directory
    publisher=binding.load_module('v24_original_bound_publisher',out/'publisher.py')
    profile=publisher.read(out/'module-profile.json')
    publisher.require(profile['module']=='Iut.Cor312.ThetaData.'+a.module,'Wrong bound module directory')
    if a.command=='check':
        publisher.check(out/'packet.json',out/'ready.final.json')
        print('Original v24 publisher check passed; no API invoked.')
        return
    api=binding.load_module('existing_prove2me_api',binding.W/'.local/abc-item/api.py')
    if a.command=='deliver':
        result=publisher.deliver(api,out/'packet.json',out/'ready.final.json',out/'platform')
    else:
        if not a.job_id:p.error('reconcile requires the original --job-id')
        result=publisher.reconcile(api,out/'packet.json',out/'ready.final.json',out/'platform',a.job_id)
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
