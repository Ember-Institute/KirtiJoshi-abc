#!/usr/bin/env python3
"""Merge only saved terminal receipts and true inner initial-theta audit gates.

No CI/compiler/API/Git. Write only the explicit --out file. Pending stays pending.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re

STD={'propext','Classical.choice','Quot.sound'}
HASHES={}


def need(ok,message):
    if not ok:raise ValueError(message)


def load(p):
    p=Path(p);need(p.stat().st_size<=32*1024**2,'Unexpected large JSON; use existing cached evidence')
    return json.loads(p.read_text())


def pin(p):
    p=Path(p).resolve()
    if p not in HASHES:
        need(p.stat().st_size<=32*1024**2,'Refusing large hash input')
        HASHES[p]=hashlib.sha256(p.read_bytes()).hexdigest()
    return {'path':str(p),'sha256':HASHES[p]}


def verified(binding):
    p=Path(binding['path']).resolve();need(pin(p)['sha256']==binding['sha256'],'Input pin changed: '+str(p))
    return p


def duration(x):
    if isinstance(x,(int,float)):return float(x)
    m=re.fullmatch(r'(\d+(?:\.\d+)?)(s|m|h)',x)
    need(m is not None,'Unknown duration representation')
    return float(m[1])*{'s':1,'m':60,'h':3600}[m[2]]


def memory(x):
    if isinstance(x,(int,float)):return int(x)
    m=re.fullmatch(r'(\d+(?:\.\d+)?)(B|KiB|MiB|GiB|KB|MB|GB)',x)
    need(m is not None,'Unknown memory representation')
    return int(float(m[1])*{'B':1,'KiB':1024,'MiB':1024**2,'GiB':1024**3,
                           'KB':1000,'MB':1000**2,'GB':1000**3}[m[2]])


def dependencies(plan):
    x=plan['runtimeReadDependencies']
    if isinstance(x,dict):x=load(verified(x))['dependencies']
    need(len(x)==len({r['path'] for r in x})==17,'Expected17 exact unique runtime dependencies')
    for b in x:verified(b)
    return x


def standard_axioms(row,target):
    need(row['name']==target and row['hasSorryAx'] is False,'Owner/axiom identity or sorryAx')
    for k in ('axioms','typeAxioms','valueAxioms'):
        need(set(row[k])<=STD,'Unexpected axiom in '+k)


def signature(row,expected):
    for k in ('diagnosticPassed','faithfulReplaySignatureKernelEqual','exactExprEqualRoundTrip',
              'allOtherBinderInfoStrictlyEqual'):
        need(row[k] is True,'Signature inner gate failed: '+k)
    e=row['exposedDomains']
    need(e['allExposedBinderFlagsStrict'] and e['completeClosedResultKernelEqual'],'Exposed signature result gate')
    need(all(d['completeClosedDomainKernelEqual'] for d in e['domains']),'Exposed domain gate')
    for k,v in expected.items():need(row[k] is v,'Original raw signature flag changed: '+k)
    inv=row['rawSignatureBinderInventoryEqual'];place=row['rawSignatureBinderPlacementEqual']
    need(row['rawFalseRemainsLiteral']==(not inv or not place),'Literal raw-false accounting')
    return {'rawSignatureBinderInventoryEqual':inv,'rawSignatureBinderPlacementEqual':place,
            'rawFalseRemainsLiteral':row['rawFalseRemainsLiteral']}


def value(row,record):
    need(row['completeTypePreconditionKernelChecked'] is True,'Complete value type precondition')
    replay=row['wholeTypeReplay']
    need(replay['allRequiredKernelChecksPassed'] and replay['exactExprEqualInverseReconstruction'],'Complete type replay/inverse')
    need(row['kernelPropositionalValueEqualityUsed'] is False,'Propositional whole-data shortcut')
    v=row['wholeValueAndRules'];need(v['completeComputationShapeEqual'] is True,'Computation shape')
    need(v['kernelPropositionalValueEqualityUsed'] is False,'Propositional data/rule shortcut')
    data_required=not record['isProposition'] and record['valueExpr'] is not None
    need(v['completeComputationalDataValueCompared']==data_required,'Full computational value coverage')
    need(v['proofValueComparisonOmittedForPropositions']==record['isProposition'],'Proposition value policy')
    rules=len(record['recursorRuleRhs']);need(v['completeRecursorRulesCompared']==rules,'Complete recursor rule coverage')
    locations={r['location']:r for r in v['replayLocations']}
    expected=['whole-computational-value'] if data_required else []
    expected += ['recursor-rule-'+str(i) for i in range(rules)]
    if record['structure'] is not None:
        expected += ['structure-autoParam-'+str(i) for i,a in enumerate(record['structure']['fieldAutoParamExprs']) if a is not None]
    need(set(expected)==set(locations),'Full value/rule/autoParam replay locations')
    for location in expected:
        r=locations[location];p=r['replay']
        need(p['allRequiredKernelChecksPassed'] and p['exactExprEqualInverseReconstruction'],'Value/rule replay/inverse: '+location)
    return {'completeTypePreconditionKernelChecked':True,
        'completeComputationalDataValueCompared':v['completeComputationalDataValueCompared'],
        'completeRecursorRulesCompared':rules,'replayLocations':expected,
        'proofValueComparisonOmittedForPropositions':v['proofValueComparisonOmittedForPropositions']}


def inspect(leaf,plan,dep_pins,workspace,receipt_dir):
    tag=leaf['submitTag'];request=receipt_dir/(tag+'-request.json')
    submitted=receipt_dir/(tag+'-submit.json');result=receipt_dir/(tag+'-result.json')
    base={'original':leaf['original'],'mode':leaf['mode'],'submitTag':tag}
    if not request.is_file() or not submitted.is_file():return {**base,'state':'not-submitted','accepted':False}
    q=load(request);s=load(submitted);base.update(job_id=s['job_id'],request=pin(request),submit=pin(submitted))
    if not result.is_file():return {**base,'state':'awaiting-saved-terminal-result','accepted':False}
    r=load(result);need(r['job_id']==s['job_id'],'Submit/result job ID mismatch')
    if r['status']!='succeeded':
        return {**base,'state':r['status'],'accepted':False,'receipt':pin(result),
            'diagnostics':(r.get('result') or {}).get('diagnostics',[]),'resources':r.get('resources')}
    actual=r['request']
    for key,val in q.items():
        if key=='expected_duration':need(duration(val)==duration(actual[key]),'Saved request duration differs')
        elif key=='expected_memory':need(memory(val)==memory(actual[key]),'Saved request memory differs')
        else:need(val==actual.get(key),'Saved request differs from actual receipt: '+key)
    need(actual['workspace']==str(workspace) and actual['exclusive'] is True,'Actual workspace/exclusive request')
    need(actual['language']=='lean' and actual['target']=='file','Actual language/target')
    expected_task=leaf['task_type']
    need(actual['task_type']==expected_task or (expected_task=='leaf' and actual['task_type']=='review'),'Actual task type')
    source=verified(leaf.get('source',plan.get('source')))
    cfg_path=verified(leaf['config']);cfg=load(cfg_path)
    view_binding=leaf.get('sourceRecord',leaf.get('singleSourceDeclaration'));view=verified(view_binding)
    need(cfg['singleSourceDeclaration']==view_binding,'Config/plan complete record binding differs')
    need(cfg['splitOriginal']==leaf['original'] and cfg['splitMode']==leaf['mode'],'Exact config declaration/mode')
    record=load(view)['record'];need(record['name']==leaf['original'] and record['selected'],'Exact original selected record')
    need((workspace/actual['parameters']['source']).resolve()==source,'Actual source path differs')
    rr=r['result'];need(rr['exit_code']==0 and rr['actual_arguments']==['lean',actual['parameters']['source']],'Actual exit/arguments')
    need(rr['snapshot']['workspace_mode']=='exclusive_worktree' and rr['snapshot']['snapshot_id'] is None,'Actual exclusive workspace receipt')
    if actual['task_type']=='review':need(rr['review']['passed'] is True,'Scheduler review did not pass')
    env=actual['environment']
    for k,v in leaf['environment'].items():need(env.get(k)==v,'Actual configured environment path differs: '+k)
    need(Path(env['NEXT_CARRIER_AUDIT_CONFIG']).resolve()==cfg_path,'Actual config path')
    hashes=actual['worktree_manifest']['input_hashes']
    all_pins=[pin(source),pin(cfg_path),pin(view)]+dep_pins
    for b in all_pins:need(hashes.get(b['path'])==b['sha256'],'Missing/different actual input hash: '+b['path'])
    need(actual['worktree_manifest']['source_sha256']==pin(source)['sha256'],'Actual source hash')
    resources=r['resources'];rss=resources.get('peak_rss_bytes')
    need(rss is not None and 0<rss<=16*1024**3,'Physical process-tree RSS acceptance gate')
    cpu=[resources.get(k) for k in ('cpu_time_seconds','cpu_user_seconds','cpu_system_seconds')]
    if all(v is not None for v in cpu):need(math.isclose(cpu[0],cpu[1]+cpu[2],abs_tol=0.01),'CPU total differs from user+system')
    output=Path(env['NEXT_CARRIER_SPLIT_DIAGNOSTIC_OUTPUT']);report=load(output)
    need(report['original']==leaf['original'] and report['mode']==leaf['mode'],'Actual report declaration/mode')
    need(report['compilerVersion']=='4.33.1' and report['defaultLogicalCheckHeartbeatBudget']==200000,'Compiler/default budget')
    need(report['completeSingleSourceRecordBinding']==view_binding,'Actual report complete record binding')
    dag=report['sharedLosslessExpressionEvidence']
    need(dag['allRootsStrictExprEqualRoundTrip'] and dag['includesFullNamesBinderNamesBinderInfoAndUniverseLevels'] and dag['rootCount']>0,'Full strict expression DAG roundtrip')
    need(report['standardCompatibilityEvidence']['allRequiredKernelChecksPassed'],'Standard/source compatibility gates')
    row=report['report'];raw=None;values=None;mode=leaf['mode']
    expected=leaf.get('expectedLiteralRawFlags',cfg.get('expectedPreviousSignatureFlags',
        {'rawSignatureBinderInventoryEqual':False,'rawSignatureBinderPlacementEqual':False}))
    if mode=='complete-existing':
        need(row['completeSingleDeclarationChecksPassed'] is True,'Complete single-declaration gate')
        need(row['priorDiagnosticReclassifiedAsFormal'] is False,'Old diagnostic was promoted')
        g=row['sourceGuards'];need(g['original']==leaf['original'] and g['target']==report['target'],'Source guard identity')
        need(g['sourceRecordReference']==view_binding,'Source guards complete record pin')
        for k in ('constantKindUniverseOrderSourceAxiomsAndInstanceRegistryChecked',
                  'completeStructureMetadataAndAutoParamBinderPlacementChecked','exactSourceAndTargetOwnerChecked'):
            need(g[k] is True,'Source guard failed: '+k)
        raw=signature(row['signature'],expected);values=value(row['wholeValueAndRules'],record)
        standard_axioms(row['ownerAndAxiomClosure'],report['target'])
    elif mode=='signature':raw=signature(row,expected)
    elif mode=='value':values=value(row,record)
    elif mode=='axioms':standard_axioms(row,report['target'])
    else:raise ValueError('Unsupported planned mode '+mode)
    return {**base,'state':'accepted-leaf','accepted':True,'request':pin(request),'submit':pin(submitted),'receipt':pin(result),
        'source':pin(source),'config':pin(cfg_path),'sourceRecord':view_binding,'report':pin(output),
        'all20ActualInputPinsChecked':True,'innerRequiredGatesPassed':True,'originalRawFlags':raw,
        'wholeValueFacts':values,'strictDagRootCount':dag['rootCount'],
        'resources':resources,'resourceSource':'MCP-CI receipt.resources; process-tree physical RSS',
        'cpuAccountingKnown':all(v is not None for v in cpu),'peakPssKnown':resources.get('peak_pss_bytes') is not None}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--batch',type=int)
    p.add_argument('--workspace',type=Path,default=Path('/home/admin-wsl/Coq/abc/prove2me_workspace'))
    p.add_argument('--receipts',type=Path);p.add_argument('--require-all',action='store_true')
    a=p.parse_args();workspace=a.workspace.resolve()
    receipt_dir=a.receipts or workspace/'.local/adaptation/reference-initial-theta-carriers-20261115'
    plan=load(a.plan);deps=dependencies(plan)
    leaves=[l for l in plan['leaves'] if a.batch is None or l.get('batch')==a.batch]
    need(leaves,'No selected planned leaves');need(len({(l['original'],l['mode']) for l in leaves})==len(leaves),'Duplicate plan leaf')
    results=[]
    for leaf in leaves:
        try:results.append(inspect(leaf,plan,deps,workspace,receipt_dir))
        except Exception as e:results.append({'original':leaf['original'],'mode':leaf['mode'],
            'submitTag':leaf['submitTag'],'state':'verification-failed','accepted':False,'error':str(e)})
    candidates=[]
    for name in dict.fromkeys(l['original'] for l in leaves):
        group=[r for r in results if r['original']==name]
        modes=['complete-existing'] if any(r['mode']=='complete-existing' for r in group) else ['signature','value','axioms']
        passed=[r for r in group if r['accepted']];missing=[m for m in modes if not any(r['mode']==m for r in passed)]
        if not missing:candidates.append({'original':name,'accepted':True,'requiredModes':modes,'actualEvidence':passed})
    complete=all(r['accepted'] for r in results)
    output={'schema':'initial-declaration-actual-correspondence-candidates-v26',
        'plan':pin(a.plan),'selectedBatch':a.batch,'selectedLeafCount':len(leaves),
        'acceptedLeafCount':sum(r['accepted'] for r in results),'allSelectedLeavesAccepted':complete,
        'actualCorrespondenceCandidates':candidates,'leafResults':results,
        'runtimeReadDependencies':deps,'requiredPhysicalRssAtMostBytes':16*1024**3,
        'moduleOrGlobalAcceptanceClaimed':False,'publicationReady':False,
        'compilerCiApiGitCalled':False,'tool':pin(Path(__file__))}
    a.out.parent.mkdir(parents=True,exist_ok=True)
    temporary=a.out.with_name(a.out.name+'.tmp');temporary.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n');temporary.replace(a.out)
    print(json.dumps({'output':pin(a.out),'acceptedLeaves':output['acceptedLeafCount'],'selectedLeaves':len(leaves),
        'correspondenceCandidates':len(candidates),'allSelectedLeavesAccepted':complete,
        'notAccepted':[{'original':r['original'],'mode':r['mode'],'state':r['state'],'error':r.get('error')} for r in results if not r['accepted']]},ensure_ascii=False))
    if a.require_all and not complete:raise SystemExit(1)


if __name__=='__main__':main()
