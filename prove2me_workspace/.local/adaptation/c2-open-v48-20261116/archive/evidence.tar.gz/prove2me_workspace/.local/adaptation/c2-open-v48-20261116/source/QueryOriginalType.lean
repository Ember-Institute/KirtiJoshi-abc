import Lean
import Iut.Implication.Corollary22

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  -- moduleNames maps the entire module array; use the indexed record directly.
  let imported ← env.header.modules[index.toNat]?
  return imported.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace PureArithmeticTypeSource
open Lean Elab Term Meta FoundationAudit

-- Deliberately never read any selected root theorem value/axiom closure.
def actualProofValue (ci : ConstantInfo) : Option Expr :=
  match ci with
  | .thmInfo i => some i.value
  | .defnInfo i => some i.value
  | .opaqueInfo i => some i.value
  | _ => none

run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected original4.35 type exporter"
  let cfg ← jsonFile (← absoluteEnv "PURE_TYPE_SOURCE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "pure-arithmetic-type-source-config/v9" do
    throwError "Unexpected type-export config"
  let roots ← checked (arrayField cfg "roots")
  unless roots.size == 1 do throwError "Expected exactly one independent type-fact root"
  let env ← getEnv
  let owner := (← checked (stringField cfg "sourceModule")).toName
  let dataNames := (← checked (cfg.getObjValAs? (Array String) "allowedDataNames")).map String.toName
  let rootNames ← roots.mapM fun r => do checked (decodeName (← checked (field r "nameExpr")))
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let mut records : Array Json := #[]
  let mut proofQueue : Array Name := #[]
  for n in rootNames do
    let ci ← getConstInfo n
    unless moduleOf env n == some owner do throwError "Wrong original type owner {n}"
    unless ← isProp ci.type do throwError "Selected declaration is not a theorem type {n}"
    let typeAxioms ← expressionAxioms cache ci.type
    ensureStandard s!"original TYPE {n}" typeAxioms
    for dep in ci.type.getUsedConstants do
      if ((`Iut).isPrefixOf dep || moduleOf env dep == some owner) && !dataNames.contains dep then
        if rootNames.contains dep then throwError "Selected theorem occurs in source TYPE {n}: {dep}"
        unless proofQueue.contains dep do proofQueue := proofQueue.push dep
    records := records.push (Json.mkObj [
      ("name", toJson n.toString), ("nameExpr", encodeName n), ("module", toJson owner.toString),
      ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
      ("elaboratedExpr", ← checked (encodeExpr ci.type)),
      ("binderInventory", toJson (binderInventory ci.type)), ("typeAxioms", toJson (typeAxioms.map Name.toString)),
      ("originalTheoremProofRead", toJson false), ("sourceSha256", ← checked (field cfg "sourceSha256"))])
  let mut proofs : Array Json := #[]
  let mut i := 0
  while i < proofQueue.size do
    let n := proofQueue[i]!
    i := i + 1
    if rootNames.contains n || dataNames.contains n then throwError "Invalid proof-only resolution {n}"
    let ci ← getConstInfo n
    unless moduleOf env n == some owner do throwError "Proof coercion outside original source module {n}"
    unless ci.levelParams.isEmpty && !ci.type.hasFVar && !ci.type.hasMVar && !ci.type.hasLooseBVars do
      throwError "Source helper is not closed with zero universe params {n}"
    unless ← isProp ci.type do throwError "Non-Prop source constant needs a real data map, not proof resolution: {n}"
    let some value := actualProofValue ci | throwError "Source closed Prop helper has no actual proof body {n}"
    if value.hasFVar || value.hasMVar || value.hasLooseBVars then throwError "Open source proof body {n}"
    let axs ← cachedAxioms cache n
    let taxs ← expressionAxioms cache ci.type
    let vaxs ← expressionAxioms cache value
    for xs in #[axs,taxs,vaxs] do ensureStandard s!"actual closed Prop proof {n}" xs
    for e in #[ci.type,value] do
      for dep in e.getUsedConstants do
        if ((`Iut).isPrefixOf dep || moduleOf env dep == some owner) && !dataNames.contains dep then
          if rootNames.contains dep then throwError "Selected theorem proof referenced by helper {n}"
          unless proofQueue.contains dep do proofQueue := proofQueue.push dep
    proofs := proofs.push (Json.mkObj [
      ("name", toJson n.toString), ("nameExpr", encodeName n), ("module", toJson owner.toString),
      ("levelParams", Json.arr #[]), ("isProposition", toJson true), ("isClosed", toJson true),
      ("actualTypeExpr", ← checked (encodeExpr ci.type)), ("actualProofExpr", ← checked (encodeExpr value)),
      ("axioms", toJson (axs.map Name.toString)), ("typeAxioms", toJson (taxs.map Name.toString)),
      ("proofAxioms", toJson (vaxs.map Name.toString)),
      ("resolutionRole", toJson "actual source closed Prop body occurring in TYPE; no native name alias/data substitution")])
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema", toJson "pure-arithmetic-original-type-facts/v9"), ("compilerVersion", toJson Lean.versionString),
    ("configuration", cfg), ("records", Json.arr records), ("closedTypeProofValues", Json.arr proofs),
    ("rootTheoremProofsRead", toJson false), ("purpose", toJson "TYPE FACTS ONLY; not an independent proof oracle")]).pretty ++ "\n")
  logInfo s!"Exported {records.size} actual complete TYPE Exprs and {proofs.size} explicit closed Prop proof coercions; no root theorem proof values read"

end PureArithmeticTypeSource
