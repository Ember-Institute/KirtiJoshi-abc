#!/usr/bin/env python3
"""Bind actual cached c2 TYPE/stub receipts. This does not accept a c2 proof."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import argparse,json,hashlib
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def binding(p):p=Path(p).resolve();return {'path':str(p),'sha256':sha(p),'contents':read(p)}
def receipt(p):
 b=binding(p);r=b['contents'];assert r['status']=='succeeded'and r['result']['exit_code']==0 and r['request']['exclusive']is True and r['request']['workspace']==str(W);assert r['result']['snapshot']['workspace_mode']=='exclusive_worktree'and r['result']['snapshot']['snapshot_id']is None;return b
ap=argparse.ArgumentParser();ap.add_argument('--source-facts',type=Path,required=True);ap.add_argument('--source-receipt',type=Path,required=True);ap.add_argument('--stub-leaf',type=Path,required=True);ap.add_argument('--stub-artifact',type=Path,required=True);a=ap.parse_args();c=read(D/'target/type-config.template.json');fb=binding(a.source_facts);facts=fb['contents'];assert facts['schema']=='pure-arithmetic-original-type-facts/v9'and facts['rootTheoremProofsRead']is False;root,=facts['records'];assert root['name']=='Iut.Corollary22Inputs.c2';sr=receipt(a.source_receipt);source_cfg=Path(sr['contents']['request']['environment']['PURE_TYPE_SOURCE_CONFIG']);assert read(source_cfg)==facts['configuration']and sr['contents']['request']['worktree_manifest']['input_hashes'].get(str(source_cfg))==sha(source_cfg)
def nm(n):return ''if not n else nm(n[0])+('.'if n[0]else'')+str(n[2])
rows=facts['closedTypeProofValues'];proofnames={nm(r['nameExpr'])for r in rows};assert len(proofnames)==len(rows)
for r in rows:
 assert r['isProposition']is True and r['isClosed']is True and r['levelParams']==[]
 for k in ['axioms','typeAxioms','proofAxioms']:assert set(r[k])<={'propext','Classical.choice','Quot.sound'}
 # Retain full actual proof Expr and type Expr; never rewrite it to a guessed native proof name.
 assert isinstance(r['actualProofExpr'],dict)and isinstance(r['actualTypeExpr'],dict)
known={r['original']for r in read(D/'maps/named-map.candidate.json')['rows']};used=set()
def collect(x):
 if isinstance(x,dict):
  if x.get('kind')in ['const','proj']:
   n=nm(x['name'])
   if n.startswith(('Iut.','Genl.','_private.')):used.add(n)
  for y in x.values():collect(y)
 elif isinstance(x,list):
  for y in x:collect(y)
collect(root['elaboratedExpr'])
for r in rows:collect(r['actualTypeExpr']);collect(r['actualProofExpr'])
assert used<=known|proofnames,('Actual source TYPE/proof resolution has unmapped data; add an exact existing map before target audit',sorted(used-known-proofnames))
expected=read(D/'handoff.json')['expectedBinders'];actual=root['binderInventory'];assert len([x for x in actual if x.startswith('forall:')])>=len(expected),'Source Expr telescope unexpectedly shortened'
stub=Path(c['installedSource']);assert stub.read_text()==c['expectedStubText']
for key,p in [('stubLeafReceipt',a.stub_leaf),('stubArtifactReceipt',a.stub_artifact)]:
 rb=receipt(p);assert rb['contents']['request']['worktree_manifest']['input_hashes'].get(str(stub))==sha(stub);c[key]=rb
c['sourceFactsBinding']=fb;c['sourceTypeReceipt']=sr;c['sourceConfig']={'path':str(source_cfg),'sha256':sha(source_cfg)};c['status']='Actual TYPE/stub input receipts bound; target kernel type/BinderInfo and closed Prop proof checking remain pending.';out=D/'target/type-config.bound.json';out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
report={'sourceFacts':{'path':fb['path'],'sha256':fb['sha256']},'allActualSourceTypeAndResolutionDataMapped':True,'projectNamesObserved':sorted(used),'closedSourceProofNames':sorted(proofnames),'closedSourceProofRecordsRetained':rows,'closedSourceProofValuesKernelCheckedByThisBinder':False,'kernelCheckRequired':'target/AuditOpenStatementType.lean validates every closed Prop type/proof and standard axioms before expanding it for TYPE equality','proofAccepted':False,'namedDataMap':{'path':str(D/'maps/named-map.candidate.json'),'sha256':sha(D/'maps/named-map.candidate.json')}};(D/'maps/actual-type-selection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(out,sha(out))
