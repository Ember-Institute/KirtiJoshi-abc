from pathlib import Path
import sys
sys.dont_write_bytecode=True
import json,hashlib
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';G=A/'main-chain-open-20261116/tools/generated';N='Iut.Corollary22Inputs.c2';T='AbcAdaptation.Reference.'+N;read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();pin=lambda p:{'path':str(p),'sha256':sha(p)}
def save(p,j):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def en(n):
 x=[]
 for a in n.split('.'):x=[x,'str',a]
 return x
m=read(G/'metadata/Iut_Corollary22Inputs_c2.json');raw=Path(m['originalCoordinateSource']).read_bytes();contexts=[]
for c in m['allSourceContexts']:
 r=c['range'];contexts.append({**c,'exactText':raw[r['start']['offset']:r['end']['offset']].decode()})
oldtype=A/'reference-extraction-20261115/Iut-Corollary22Inputs-c2-compiler-type.json'
save(D/'source/context-and-ast.json',{'metadata':pin(G/'metadata/Iut_Corollary22Inputs_c2.json'),'source':pin(m['originalCoordinateSource']),'contexts':contexts,'existingCompiledDisplayRecord':pin(oldtype),'compiledDisplayTelescope':m['graphCompilerTelescope'],'actualConsumerEdges':m['actualConsumerEdges'],'telescopeIsPreviouslyCompilerProducedNotNewReceipt':True})
pre='''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open AbcAdaptation.Reference
open AbcAdaptation.Reference.Iut
universe u v w

'''
formal='''theorem AbcAdaptation.Reference.Iut.Corollary22Inputs.c2
    {T : Genl.HeightTheory} {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
    {K : T.CBS} {d : ℕ} (I : Corollary22Inputs T K d)
    {P : Corollary312VariantData.{u, v} AG TG → Prop} (hd : 1 ≤ d)
    (ex : ThetaDataExistence P I) (cheb : ChebyshevBound) (pnt : PrimeCountingBound)
    (h312 : ∀ X : Corollary312VariantData.{u, v} AG TG, P X → Corollary312Variant X)
    (x : T.Pt T.tripod) (hx : x ∈ T.cbsSet K ∩ T.ptLE T.tripod d) (hxe : x ∉ I.excCore)
    (hH : I.threshold cheb ≤ I.h x) :
    1 / 6 * I.h x ≤ (1 + epsilonE (deltaBound d) (I.h x)) *
        (T.logDiff T.tripod x + T.logCond T.tripod x) + (40 * pnt.η + I.B / 3) ∧
      epsilonE (deltaBound d) (I.h x) ≤ 1 ∧
      0 ≤ T.logDiff T.tripod x + T.logCond T.tripod x := by
  sorry
'''
rel='Theorems/Thm_'+T.replace('.','_')+'.lean';stub=D/'stub'/Path(rel).name;stub.parent.mkdir();stub.write_text(pre+formal)
# Name maps are existing declaration correspondences, not TYPE proof-resolution replacements.
sources=[A/'main5-local-dossier-v27-20261116/current-owned176-config.json',A/'main5-local-dossier-v27-20261116/current-source-log32-config.json',A/'c2-complete-inputs-20261116/final44-two-value-config-v5.json'];maps={}
for p in sources:
 j=read(p)
 for key in ['projectMap','priorDependencies']:
  for r in j.get(key,[]):maps[r['original']]=(p,key,r)
regpath=A/'platform-node-registry.json';reg=read(regpath)['reference_source_preparation'];defs={r['name']:r for r in reg['definitions']};rows=[];missing=[]
for n in m['graphTypeDependencies']:
 found=maps.get(n)
 if n=='Iut.epsilonE':
  p=A/'supplier-carriers-delivery-20261116/platform-three/AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs-published-item.json';j=read(p);assert 'noncomputable def epsilonE' in j['definition'];found=(p,'publishedDefinitionCode',{'original':n,'target':'AbcAdaptation.Reference.Iut.epsilonE','targetOwner':'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs','targetToSourceUniverseIndices':None,'evidence':'Exact published NumericInputs source code and accepted source-definition correspondence; no new alias.'})
 if not found:missing.append(n);continue
 p,key,r=found;owner=r['targetOwner'];file=W/Path(owner.replace('.','/')+'.lean');rows.append({'original':n,'originalName':en(n),'target':r['target'],'targetName':en(r['target']),'targetOwner':owner,'targetOwnerName':en(owner),'targetToSourceUniverseIndices':r.get('targetToSourceUniverseIndices'),'existingMap':pin(p),'existingMapSection':key,'existingMapRow':r,'publishedDefinition':defs[owner.removeprefix('Definitions.Def_')],'currentSource':pin(file)})
assert not missing,missing
save(D/'maps/named-map.candidate.json',{'count':len(rows),'missing':missing,'rows':rows,'graphTypeDeps':m['graphTypeDependencies'],'actualTYPEExprConfirmed':False,'closedProofResolutionPolicy':'Exported zero-universe closed Prop proof bodies are explicit resolution records, never guessed native Names or data substitutions. Actual extra data names block binding until mapped.','registry':pin(regpath),'newDataIdentityGate':False})
# Source compiler reads cached actual Corollary22 theorem TYPE, including any closed Prop roots referenced by TYPE.
q=A/'independent-two-four-role-v25-20261116/QueryIndependentTypeFacts.lean';s=q.read_text().replace('import Iut.Implication.Theorem110','import Iut.Implication.Corollary22');(D/'source/QueryOriginalType.lean').write_text(s)
scfg={'schema':'pure-arithmetic-type-source-config/v9','publish':False,'roots':[{'name':N,'nameExpr':en(N)}],'expectedRootCount':1,'sourceModule':'Iut.Implication.Corollary22','sourceSha256':m['originalCoordinateSha256'],'source':pin(m['originalCoordinateSource']),'allowedDataNames':m['graphTypeDependencies'],'outputFile':str(D/'actual/source-type.json'),'mode':'Read cached actual c2 TYPE only. Selected c2 proof value is never read; all non-data closed Prop TYPE constants are exported with actual source type/proof Expr and standard-axiom checks.'};save(D/'source/type-config.json',scfg)
# Existing actual Expr codec/kernel checks and closed Prop resolution validation.
base=(A/'main-pure-type-identity-20261116/AuditP5GlobalSolution.lean').read_text();common=base[base.index('/-! Stable JSON'):base.index('def pureArithmeticTypeAudit :')];extra=(A/'independent-two-four-role-v25-20261116/common-extra.lean.txt').read_text();extra=extra[:extra.index('\ndef boundJson')];a=extra.index('def nativeDataNames :');z=extra.index('\n\ndef typeProofRows',a);pairs=[]
for r in rows:pairs.extend([(r['original'],r['target']),(r['target'],r['target'])])
mt='def nativeDataNames : TypeNames := #[\n'+',\n'.join('  (`'+a+', `'+b+')'for a,b in pairs)+']';extra=extra[:a]+mt+extra[z:];extra=extra.replace('n != `AbcAdaptation.Reference.Iut.epsilonE && ','!nativeDataNames.any (·.2 == n) && ').replace('dep != `AbcAdaptation.Reference.Iut.epsilonE && ','!nativeDataNames.any (·.2 == dep) && ')
# Explicitly verify mapped target owners in the actual native environment.
ownerpairs='def expectedDataOwners : Array (Name × Name) := #[\n'+',\n'.join('  (`'+r['target']+', `'+r['targetOwner']+')'for r in rows)+']\n'
body='''
run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33 c2 open-statement TYPE audit"
  let cfg ← jsonFile (← absoluteEnv "OPEN_STATEMENT_TYPE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "c2-open-statement-type-config/v46" do throwError "Wrong c2 open-statement config"
  let bind ← checked (field cfg "sourceFactsBinding")
  if bind == Json.null then throwError "Actual source TYPE binding pending"
  let facts ← jsonFile (← checked (stringField bind "path"))
  unless facts == (← checked (field bind "contents")) do throwError "Source TYPE facts changed"
  unless (← checked (facts.getObjValAs? Bool "rootTheoremProofsRead")) == false do throwError "Selected c2 proof was read"
  let records ← checked (arrayField facts "records")
  unless records.size == 1 do throwError "Expected one source TYPE"
  let r := records[0]!
  unless (← checked (stringField r "name")) == "Iut.Corollary22Inputs.c2" do throwError "Wrong root"
  for (n,o) in expectedDataOwners do
    unless moduleOf (← getEnv) n == some o do throwError "Wrong mapped data owner {n}"
  let sourceProofs ← checked (arrayField facts "closedTypeProofValues")
  validateProofRows sourceProofs
  let n := `AbcAdaptation.Reference.Iut.Corollary22Inputs.c2
  let ci ← getConstInfo n
  unless moduleOf (← getEnv) n == some `Theorems.Thm_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2 do throwError "Wrong c2 stub owner"
  let targetProofs ← typeProofRows #[ci.type]
  validateProofRows targetProofs
  let sourceExpr ← checked (decodeType nativeDataNames sourceProofs #[] true (← checked (field r "elaboratedExpr")))
  let targetExpr ← checked (decodeType nativeDataNames targetProofs #[] true (← checked (encodeExpr ci.type)))
  let sourceSig ← checked (decodeType nativeDataNames sourceProofs #[] false (← checked (field r "elaboratedExpr")))
  let targetSig ← checked (decodeType nativeDataNames targetProofs #[] false (← checked (encodeExpr ci.type)))
  let ps ← namesFromJson (← checked (field r "levelParams"))
  unless ps.length == ci.levelParams.length do throwError "Universe arity differs"
  let us := (canonicalLevels ps.length).map Level.param
  kernelTypeEq "c2 open complete source/target TYPE" (sourceExpr.instantiateLevelParams ps us) (targetExpr.instantiateLevelParams ci.levelParams us)
  unless binderInventory sourceSig == binderInventory targetSig && binderPlacement sourceSig == binderPlacement targetSig do throwError "Full BinderInfo placement differs"
  let axs ← expressionAxioms ci.type
  ensureStandard "c2 target TYPE only" axs
  let text ← IO.FS.readFile (← checked (stringField cfg "installedSource"))
  unless text == (← checked (stringField cfg "expectedStubText")) do throwError "Installed c2 stub changed"
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "c2-open-statement-type-audit/v46"),("targetName",toJson n.toString),
    ("statementTypeAccepted",toJson true),("completeKernelTypeEqual",toJson true),
    ("binderInventoryEqual",toJson true),("binderPlacementEqual",toJson true),
    ("typeAxioms",toJson (axs.map Name.toString)),("sourceClosedTYPEProofValues",Json.arr sourceProofs),
    ("targetClosedTYPEProofValues",Json.arr targetProofs),
    ("sourceTypeExpr",← checked (field r "elaboratedExpr")),("targetTypeExpr",← checked (encodeExpr ci.type)),
    ("proofAccepted",toJson false),("fourRoleProofAuditPerformed",toJson false),
    ("expectedOpenSorry",toJson true),("configuration",cfg)]).pretty ++ "\\n")
  logInfo "c2 open TYPE/BinderInfo accepted; closed TYPE Prop proofs kernel checked; no c2 proof acceptance"
end FoundationAudit
'''
(D/'target').mkdir();(D/'target/AuditOpenStatementType.lean').write_text('import Lean\nimport '+rel[:-5].replace('/','.')+'\n\n'+common+extra+'\n'+ownerpairs+body)
save(D/'target/type-config.template.json',{'schema':'c2-open-statement-type-config/v46','sourceFactsBinding':None,'sourceTypeReceipt':None,'sourceConfig':pin(D/'source/type-config.json'),'stubLeafReceipt':None,'stubArtifactReceipt':None,'installedSource':str(W/rel),'expectedStubText':pre+formal,'outputFile':str(D/'actual/target-type-audit.json'),'namedMap':pin(D/'maps/named-map.candidate.json'),'closedProofResolution':'actual source/target closed Prop bodies, no data substitution or target name guessing','proofAcceptanceClaimed':False})
RB=A/'main-chain-open-20261116/independent-readbacks-v9';rb=next(x for x in read(RB/'trilingual-a.json')['nodes']if x['sourceName']==N);save(D/'readbacks/frozen-selected-A.json',rb)
P=A/'main-c22-numeric-reference-split-20261115';old=next(x for x in read(P/'paper-source-context.en.json')if x['declaration']=='Iut.c2_final');quotes=[x for x in read(P/'paper-quotation-verification.json')if x['declaration']=='Iut.c2_final'];save(D/'paper/context.json',{'paperManifest':pin(P/'paper-pdf-manifest.json'),'paperManifestContents':read(P/'paper-pdf-manifest.json'),'existingContext':pin(P/'paper-source-context.en.json'),'existingQuoteVerification':pin(P/'paper-quotation-verification.json'),'existingParentC2ProofContext':old,'verifiedShortQuotations':quotes,'scope':'Mochizuki IUT IV Corollary2.2(ii) proof pp46-48. These exact excerpts were previously verified as c2_final parent context; here they locate the actual c2 conditional consequence. Do not claim a new visual audit or identify the implementation constant B with paper B without normalization.','normalization':'Paper C_K=40eta+2B_K bounds a height difference already divided by6; source C_K=40eta+I.B/3 uses I.B before division. No extra PrimeCountingBound factor is inferred.','newVisualAuditClaimed':False})
langs=rb['readbacks'];tr='\n\n'.join('**'+title+'**\n\n'+langs[k]for k,title in [('en','English'),('zh_Hans'if'zh_Hans'in langs else'zh-Hans','简体中文'),('ja','日本語')]);qtext='\n\n'.join('> '+q['quote']+'\n\n— IUT IV, printed/PDF p. '+str(q['printed_page'])for q in quotes);payload={'theorem_name':T,'theorem_title':'Conditional Corollary 2.2 height estimate — 条件性推论2.2高度估计 — 条件付き系2.2の高さ評価','preamble':pre,'formal_statement':formal.rstrip(),'natural_language_statement':tr+'\n\n**Paper source context**\n\n'+old['source_description_en']+'\n\n'+old['source_adaptation_note_en']+'\n\n**Short existing quotations**\n\n'+qtext,'source':'https://github.com/lana-agents/iut/blob/07cb1da58f6d428a670dbb5dd6093d428bcbcdd8/Iut/Implication/Corollary22.lean#L386-L394','env':'0df444a360eaa60ab8c11dca51a86af692955474','private':True};save(D/'payload.not-ready.json',payload)
save(D/'handoff.json',{'sourceName':N,'targetName':T,'statementOnly':True,'nativeProofCreated':False,'sourceCompiledDisplay':pin(oldtype),'sourceActualExprExportReceipt':None,'compiledDisplayBinders':m['graphCompilerTelescope'],'expectedBinders':[{'name':x['name'],'binderInfo':x['binderInfo']}for x in m['graphCompilerTelescope']['binders']],'instanceBindersInExistingCompilerTelescope':[],'actualConsumerEdges':m['actualConsumerEdges'],'sourceGraphProjectConstants':len(rows),'actualExprProjectConstantsConfirmed':False,'sourceTYPEQuery':pin(D/'source/QueryOriginalType.lean'),'targetTYPEQuery':pin(D/'target/AuditOpenStatementType.lean'),'namedMap':pin(D/'maps/named-map.candidate.json'),'frozenReader':'A; not B','frozenReadbackPins':[pin(RB/f)for f in ['readback-a-en.json','trilingual-a.json','terminology-a.json','coverage.json']],'paperContext':pin(D/'paper/context.json'),'missingGates':['actual original cached c2 TYPE Expr/export receipt','explicit source closed TYPE Prop proof-resolution records if any; target counterparts resolved and kernel checked','target stub leaf/artifact','complete source-target TYPE/BinderInfo and mapped-owner/TYPE axiom audit','final frozen ReaderA/paper/source payload review','project required production checks/import/aggregate/axiom/diff or valid current-pin reuse','existing private mission publication scope binding'],'proofAcceptanceClaimed':False,'fourRoleProofAuditCreated':False,'canonicalC22Connected':False,'S204Completed':False,'CIInvoked':False,'APIInvoked':False,'GitInvoked':False,'mainWorkspaceModified':False})
print('Prepared c2 open statement; 16 previous compiler binders,',len(rows),'candidate project data names. No native proof.')
