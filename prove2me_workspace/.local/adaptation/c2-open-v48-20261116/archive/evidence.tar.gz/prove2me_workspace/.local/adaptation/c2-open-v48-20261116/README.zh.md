本包只准备 `AbcAdaptation.Reference.Iut.Corollary22Inputs.c2` 的开放陈述类型验收；不提供c2证明、不建本轮proof四角色门、不伪造native/solution。

最小stub：`stub/Thm_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2.lean`；payload为`payload.not-ready.json`。全部16个binder按已保存真实compiler telescope生成：

- 隐式：`T, AG, TG, K, d`，随后显式`I`，再隐式`P`。
- 显式：`hd, ex, cheb, pnt, h312, x, hx, hxe, hH`。
- 既有compiler telescope无instance binder。

T/AG/TG/K/d/I全保留，`P : Corollary312VariantData AG TG → Prop`全保留；`h312`仍全称量化所有X并接收P X。阈值、例外集合、所属集合/degree限制以及三个合取结论完全保留。结论是显式I.h和源epsilonE/deltaBound，不替换canonical辅助高度，也不消除P7和h312。AST全部namespace/options/variables及旧compiler telescope见`source/context-and-ast.json`。

已有`Iut-Corollary22Inputs-c2-compiler-type.json`保存实际打印TYPE和BinderInfo（不是新编译结果，也不是完整raw Expr）。本轮仍需原缓存 `Iut.Implication.Corollary22` 的真实Expr导出：`source/QueryOriginalType.lean`、`source/type-config.json`，环境`PURE_TYPE_SOURCE_CONFIG`、原4.35环境。复用已有TYPE exporter，不读c2 theorem proof；对TYPE引用而不属于明确data map的closed Prop常量，逐项导出真实actualTypeExpr/actualProofExpr、验证zero universes/closed/Prop/standard axioms，保留完整resolution records，不丢弃。若它发现非闭合/有宇宙参数证明或尚未映射data，明确停止，不能改成任意假设。

`maps/named-map.candidate.json`含23项source graph候选data映射；实际Expr导出后须收缩/确认。main5 projectMap、完整C22 current44 projectMap/priorDependencies和已发布NumericInputs定义提供原名字、target owner/Definition ID和当前源码pin。epsilonE按已发布NumericInputs actual definition读取，无猜private数字前缀。map本身不等于新data identity数学验收。

目标审查：`target/AuditOpenStatementType.lean`、`target/type-config.template.json`，环境`OPEN_STATEMENT_TYPE_CONFIG`、目标4.33。它复用原Expr codec/kernel和closed Prop resolution方法：

1. 对源TYPE中的所有closed proof值逐一Kernel.check并核对实际proposition及标准公理。
2. 从目标stub TYPE提取其closed Prop支持值，同样验证，无data替换或source-name alias。
3. 明确映射现行data owner，展开已验证的proof值后比较完整TYPE kernel equality；不展开的签名用于完整树的BinderInfo位置/顺序比较。
4. 只查TYPE公理；stub body预期sorry，输出明确`proofAccepted=false`、`fourRoleProofAuditPerformed=false`。

因此closed TYPE proof-resolution不是“证明c2”；它只消除类型中编译器生成证明项的表示差异。所有原/目标type与proof-resolution Expr都会写进报告，不只给Boolean。

source TYPE和stub leaf/artifact真实通过后，root运行`bind_type_audit.py --source-facts ... --source-receipt ... --stub-leaf ... --stub-artifact ...`，绑定source config/receipt源码hash并检查actual Expr及所有resolution中项目常量都有显式map；额外proof/data不被静默吞掉。然后把bound target config交MCP-CI执行target query。原query和source config可由root复制到稳定W并重定位output，实际receipt与config对应仍必须核对。

c2冻结main35读回正确来源为 **Reader A**，Reader B没有该条。`readbacks/frozen-selected-A.json`从原trilingual-a节点按字段保存，原英文/中日不改，继续保留旧sorry输入描述；`handoff.json` pin全部原reader文件。

论文复用既有IUT IV Corollary2.2(ii) proof pp46–48背景、短引句及其旧核验记录。上下文来自之前c2_final父证明材料，明确不是新增视觉审查。纸面`C_K=40η+2B_K`中B_K已除6，来源陈述用`40η+I.B/3`且I.B在除法前；该归一化差别写明，不能把两种B直接认作同数。源陈述的P7/高度理论/对象存在性仍是显式输入，论文引用不构造它们。

缺门见handoff：真实source TYPE Expr及resolution回执、stub叶/产物、目标TYPE/BinderInfo与所有proof-resolution kernel检查、TYPE公理、最终冻结来源/论文review及项目必须生产门/mission绑定。未来真正c2父归约另做。本/tmp稿未编译、无CI/API/Git/主区写入，canonicalC22和S2-04仍不完成。
