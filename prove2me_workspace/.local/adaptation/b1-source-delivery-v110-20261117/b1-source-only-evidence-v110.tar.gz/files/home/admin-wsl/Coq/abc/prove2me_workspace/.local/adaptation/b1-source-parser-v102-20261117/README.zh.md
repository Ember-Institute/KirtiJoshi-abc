这是冻结的最窄 parser 修补，只在 /tmp 写入，未编译、未运行 CI/API/Git，未修改主区。

QueryB123Parser.lean 仅将原第5行
  open scoped RestrictedProduct WithZero Real IntermediateField Classical
改为
  open scoped RestrictedProduct WithZero IntermediateField Classical
即删除5个UTF8字节 `Real `；WithZero等scope完整保留。旧driver完整副本为QueryB123Parser.history-v100.lean；diff见remove-driver-Real.patch；hash见freeze-manifest.json。

根因依据：Mathlib/Analysis/SpecialFunctions/Trigonometric/Basic.lean:132 的 π 是 scoped notation；Lean/ScopedEnvExtension.lean:211 的 activateScoped 才把该命名空间syntax加入当前parser状态。原driver在读取getEnv前显式open scoped Real，故Parser.testParseModule拿到已激活π的parser环境；Lean/Parser/Module.lean:182–202的testParseModule只parse commands，不elab原imports或逐条处理普通open scoped上下文。新driver不再激活这个与九份原source无关的scope；不替换变量π、不改proof，不改坐标。

九份原source raw/normalized hash都已核对；九份都没有原open scoped Real。nine-source-scope-and-pi-audit.json逐份记录原open scoped行和所有π字节位置（包括注释/docstrings，所以不称Lean lexer token或新AST）。LocalTheory真正π常量写成Real.pi，π字符仅出现在文档。TateInputsConstruct/Ordp有真实原π变量，保留其全部文本。原scope/实例/属性命令仍由旧driver完整AST流程原样输出。

建议remaining-eight.config.json：不重parse已有完整CurveOf，从ci-018466-5d214558失败批次复用该module53command的成功summary与一致输入hash；新8份AST写b1-source-parser-v102-20261117/parser-output，不覆盖旧partial目录。此复用证据见reuse-CurveOf-from-failed-batch.json，明确批次failed，不把单module成功冒充整任务成功。若root决定重parse九份，all-nine.config.json可用，仍写新目录。

新driver的实际编译与8份parser-only验收交root统一exclusive MCP-CI。本静态修补不宣称source数学elaboration、B1实际TYPE或证明值、公理闭包通过。后续prepare.py可同时消费旧CurveOf目录和新8份目录；若选择9份重parse，则只消费新目录以免重复module拒绝。
