import Lean
import B1SourceReplay

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  -- moduleNames maps the entire module array; use the indexed record directly.
  let imported ← env.header.modules[index.toNat]?
  return imported.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace B1SourceRootActualFacts
open Lean Elab Term Meta FoundationAudit

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open actual Expr {label}"

def checkedValueType (label : String) (value type : Expr) : MetaM Expr := do
  requireClosed label value
  requireClosed s!"TYPE of {label}" type
  let inferred ← match Kernel.check (← getEnv) {} value with
    | .ok t => pure t
    | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} inferred type with
  | .ok true => pure ()
  | .ok false => throwError "Kernel actual value/TYPE mismatch {label}"
  | .error ex => throwKernelException ex
  return inferred

def rootRecord (ci : ConstantInfo) : MetaM Json := do
  let env ← getEnv
  let some value := ci.value? (allowOpaque := true) | throwError "No actual proof value {ci.name}"
  let inferred ← checkedValueType ci.name.toString value ci.type
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let axs ← cachedAxioms cache ci.name
  let taxs ← expressionAxioms cache ci.type
  let vaxs ← expressionAxioms cache value
  for xs in #[axs,taxs,vaxs] do ensureStandard ci.name.toString xs
  let typeDeps := ci.type.getUsedConstants.qsort Name.lt
  let valueDeps := value.getUsedConstants.qsort Name.lt
  let mut directFacts : Array Json := #[]
  for dep in (typeDeps ++ valueDeps).qsort Name.lt do
    unless directFacts.any (fun j => (j.getObjValAs? String "name").toOption == some dep.toString) do
      let d ← getConstInfo dep
      let owner := moduleOf env dep
      directFacts := directFacts.push (Json.mkObj [
        ("name",toJson dep.toString),("nameExpr",encodeName dep),
        ("ownerNameExpr",owner.map encodeName |>.getD Json.null),
        ("owner",toJson (owner.map Name.toString)),("kind",toJson (kind d)),
        ("levelParams",Json.arr (d.levelParams.toArray.map encodeName)),
        ("isProposition",toJson (← isProp d.type)),
        ("isInstance",toJson (Lean.Meta.isInstanceCore env dep)),
        ("inRootType",toJson (typeDeps.contains dep)),("inRootValue",toJson (valueDeps.contains dep)),
        ("directTypeConstants",Json.arr (d.type.getUsedConstants.qsort Name.lt |>.map encodeName))])
  return Json.mkObj [
    ("name",toJson ci.name.toString),("nameExpr",encodeName ci.name),
    ("ownerNameExpr",(moduleOf env ci.name).map encodeName |>.getD Json.null),
    ("kind",toJson (kind ci)),("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("actualTypeExpr",← checked (encodeExpr ci.type)),
    ("actualProofExpr",← checked (encodeExpr value)),
    ("actualTypeDisplay",toJson (← ppExpr ci.type).pretty),
    ("telescope",← telescopeJson ci.type),("binderInventory",toJson (binderInventory ci.type)),
    ("kernelInferredProofTypeExpr",← checked (encodeExpr inferred)),
    ("kernelProofTypeMatchesActualTYPE",toJson true),
    ("kernelInferredTypeStructurallyEqual",toJson (inferred == ci.type)),
    ("axioms",toJson (axs.qsort Name.lt |>.map Name.toString)),
    ("typeAxioms",toJson (taxs.qsort Name.lt |>.map Name.toString)),
    ("proofAxioms",toJson (vaxs.qsort Name.lt |>.map Name.toString)),
    ("hasSorryAx",toJson (axs.contains `sorryAx)),
    ("directTypeConstants",Json.arr (typeDeps.map encodeName)),
    ("directValueConstants",Json.arr (valueDeps.map encodeName)),
    ("directActualDependencyFacts",Json.arr directFacts)]

run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected source4.35 compiler"
  let cfg ← jsonFile (← absoluteEnv "B1_SOURCE_ROOT_FACTS_CONFIG")
  unless (← checked (cfg.getObjValAs? String "schema")) == "B1-source-root-actual-facts-config/v106" do
    throwError "Wrong source root query config"
  let display ← checked (cfg.getObjValAs? String "rootDisplayName")
  let env ← getEnv
  let names := env.constants.fold (fun acc n _ => if n.toString == display then acc.push n else acc)
    (#[] : Array Name)
  unless names.size == 1 do throwError "Expected unique actual source root {display}"
  let name := names[0]!
  unless moduleOf env name == some `B1SourceReplay do throwError "Wrong actual root owner {name}"
  let ci ← getConstInfo name
  let record ← rootRecord ci
  let output ← checked (cfg.getObjValAs? String "outputFile")
  if let some parent := (System.FilePath.mk output).parent then
    IO.FS.createDirAll parent
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "B1-source-root-actual-facts/v106"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("actualOwner",encodeName `B1SourceReplay),("root",record),
    ("actualKernelProofChecked",toJson true),("standardAxiomAuditPassed",toJson true),
    ("closedSourceTYPEExported",toJson true),("fullCarrierClosureExported",toJson false),
    ("nativeTargetComparisonAccepted",toJson false)]).pretty ++ "\n")
  logInfo "Actual B1 source root TYPE/proof/direct dependencies exported; kernel and standard axioms checked"
end B1SourceRootActualFacts
