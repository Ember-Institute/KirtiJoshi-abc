import Iut.Implication.Corollary22
import Iut.Tripod.Basic
import Iut.Tripod.Legendre
import Iut.Cor312.ThetaData.PlaceUnder
import Iut.Cor312.ThetaData.BadPlaceNorm
import Mathlib.NumberTheory.RamificationInertia.Valuation

section

namespace Iut

universe u v

open NumberField IsDedekindDomain

open scoped Pointwise

variable (K : Type u) [Field K] [NumberField K]

/-- The completion `K_w` of `K` at a finite place. -/
noncomputable abbrev completionAt (w : FinitePlace K) : Type u :=
  w.maximalIdeal.adicCompletion K

/-- The ramification index `e_w` of the finite place `w` over its residue
characteristic. -/
noncomputable def ramIdx (w : FinitePlace K) : ℕ :=
  Ideal.ramificationIdx w.maximalIdeal.asIdeal ℤ

/-- The residue degree `f_w` of the finite place `w` over its residue characteristic. -/
noncomputable def inertDeg (w : FinitePlace K) : ℕ :=
  Ideal.inertiaDeg w.maximalIdeal.asIdeal ℤ

/-- The local degree `[K_w : ℚ_p] = e_w · f_w`. -/
noncomputable def localDeg (w : FinitePlace K) : ℕ := ramIdx K w * inertDeg K w

/-- The valuation `ord_p` on `K_w`, normalized by `ord_p(p) = 1`: since the norm of the
adic completion satisfies `‖p‖ = p^{−[K_w : ℚ_p]}`, `ord_p(x) = −log‖x‖/([K_w : ℚ_p]·log p)`. -/
noncomputable def ordp (w : FinitePlace K) (x : completionAt K w) : ℝ :=
  -Real.log ‖x‖ / (localDeg K w * Real.log (residueChar w))

/-- The ramification index of a place of `K` over its rational place (`1` at infinite
places, by convention). -/
noncomputable def ramIdxAt : Place K → ℕ
  | .finite w => ramIdx K w
  | .infinite _ => 1

open scoped Classical in
/-- The exponent `ord_𝔭(𝔡_{K/ℚ})` of the different ideal of `K` at the finite place `w`. -/
noncomputable def ordDifferent (w : FinitePlace K) : ℕ :=
  Multiset.count w.maximalIdeal.asIdeal
    (UniqueFactorizationMonoid.normalizedFactors (differentIdeal ℤ (𝓞 K)))

/-- The **different exponent** `d_w` of `K_w` over `ℚ_p` in the normalization
`ord_p(p) = 1`: `d_w = ord_𝔭(𝔡_{K/ℚ})/e_w` (the local different at `w` is the
completion of the global one; IUT IV, Proposition 1.3). -/
noncomputable def differentExponent (w : FinitePlace K) : ℝ :=
  (ordDifferent K w : ℝ) / ramIdx K w

/-- The **tensor packets** `⊗_j K_{c j}` as topological commutative rings, indexed by a
rational place `v_ℚ` and a finite family `c` of places of `K` (meaningful when every
`c j` lies over `v_ℚ`; junk otherwise). Separated from `LocalTheory` so that the ring
structure is available as an instance for the statements about them. -/
structure LocalTensor where
  /-- The **tensor packet** `⊗_{j} K_{c j}` over `ℚ_p` (resp. `ℝ`), presented as a
  topological commutative ring (a finite product of local fields). -/
  Tensor : ∀ {ι : Type} [Fintype ι], RationalPlace → (ι → Place K) → Type v
  /-- Ring structure. -/
  [ring : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    CommRing (Tensor vQ c)]
  /-- Topology. -/
  [top : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    TopologicalSpace (Tensor vQ c)]
  /-- The archimedean packets are `ℝ`-algebras. -/
  [algR : ∀ {ι : Type} [Fintype ι] (c : ι → Place K), Algebra ℝ (Tensor .infinite c)]

attribute [instance] LocalTensor.ring LocalTensor.top LocalTensor.algR

/-- **The local-field theory of the tensor packets** over the number field `K`: the
standard-mathematics input of the concrete large volume container (taxis #4, #278).
Every field is a target statement for `lana-agents/padic-log-volume`; see the module
docstring. -/
structure LocalTheory extends LocalTensor.{u, v} K where
  /-- Residue characteristics of finite places are prime. -/
  residueChar_prime : ∀ w : FinitePlace K, (residueChar w).Prime
  /-- Finitely many finite places over each prime. -/
  fiber_finite : ∀ p : ℕ, Finite {w : FinitePlace K // residueChar w = p}
  /-- Only finitely many finite places are ramified over `ℚ`. -/
  ramified_finite : {w : FinitePlace K | ramIdx K w ≠ 1}.Finite
  /-- Local degrees are positive. -/
  localDeg_pos : ∀ w, 0 < localDeg K w
  /-- Ramification indices are positive. -/
  ramIdx_pos : ∀ w, 0 < ramIdx K w
  /-- The different exponent vanishes at unramified places (`𝔭 ∤ 𝔡_{K/ℚ}` iff `𝔭` is
  unramified). -/
  ordDifferent_eq_zero : ∀ w, ramIdx K w = 1 → ordDifferent K w = 0
  /-- `∑_{w ∣ p} [K_w : ℚ_p] = [K : ℚ]` (`Ideal.sum_ramification_inertia`). -/
  sum_localDeg : ∀ p : ℕ, p.Prime → ∀ [Fintype {w : FinitePlace K // residueChar w = p}],
    ∑ w : {w : FinitePlace K // residueChar w = p}, localDeg K w.1 = Module.finrank ℚ K
  /-- `∑_{w ∣ ∞} [K_w : ℝ] = [K : ℚ]` (`NumberField.InfinitePlace.sum_mult_eq`). -/
  sum_mult : ∑ w : InfinitePlace K, w.mult = Module.finrank ℚ K
  /-- `ord_p(p) = 1`. -/
  ordp_p : ∀ w : FinitePlace K, ordp K w (algebraMap K _ (residueChar w : K)) = 1
  /-- `ord_p` is multiplicative. -/
  ordp_mul : ∀ w (x y : completionAt K w), x ≠ 0 → y ≠ 0 →
    ordp K w (x * y) = ordp K w x + ordp K w y
  /-- The inclusion of the `j`-th tensor factor at a nonarchimedean place. -/
  incl : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K) (j : ι)
    (w : FinitePlace K), c j = Place.finite w → completionAt K w →+* Tensor (.finite p) c
  /-- Units of a factor are units of the packet. -/
  isUnit_incl : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K) (j : ι)
    (w : FinitePlace K) (h : c j = Place.finite w) (x : completionAt K w), x ≠ 0 →
    IsUnit (incl p c j w h x)
  /-- The **integral structure**: `(R_I)^∼`, the ring of integers of the product of local
  fields, at nonarchimedean places (IUT IV, Proposition 1.2); the product of unit balls
  `B_I` at the archimedean place (Proposition 1.5(iii)). -/
  integral : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    Set (Tensor vQ c)
  /-- `1 ∈ (R_I)^∼`. -/
  one_mem_integral : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    (1 : Tensor vQ c) ∈ integral vQ c
  /-- Scaling by an element of nonnegative `ord_p` shrinks the integral structure. -/
  smul_integral_subset : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K) (j : ι)
    (w : FinitePlace K) (h : c j = Place.finite w) (x : completionAt K w), x ≠ 0 →
    0 ≤ ordp K w x → incl p c j w h x • integral (.finite p) c ⊆ integral (.finite p) c
  /-- The **tensor product of the log-shells** `⊗_j 𝓘_{c j}` (IUT III, Proposition 3.2). -/
  logShell : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    Set (Tensor vQ c)
  /-- Log-shells are relatively compact. -/
  logShell_relCompact : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    IsCompact (closure (logShell vQ c))
  /-- At nonarchimedean places the log-shell contains the integral structure
  (IUT III, Proposition 1.2). -/
  integral_subset_logShell : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K),
    integral (.finite p) c ⊆ logShell (.finite p) c
  /-- At an odd prime unramified in every factor the log-shell is the integral structure
  (IUT I, Definition 5.4.5; IUT IV, Proposition 1.4(iv)). -/
  logShell_eq_integral : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K),
    Odd (p : ℕ) → (∀ j w, c j = Place.finite w → ramIdx K w = 1) →
    logShell (.finite p) c = integral (.finite p) c
  /-- The **normalized Haar log-volume** on regions of a packet (IUT IV,
  Proposition 1.4(i); IUT III, Proposition 3.9). -/
  componentVol : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    Set (Tensor vQ c) → ℝ
  /-- `μ^log((R_I)^∼) = 0`. -/
  componentVol_integral : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    componentVol vQ c (integral vQ c) = 0
  /-- Monotonicity of the log-volume between hull regions `a·O ⊆ b·O` (`a`, `b` units). -/
  componentVol_mono : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K)
    (a b : Tensor vQ c), IsUnit a → IsUnit b → a • integral vQ c ⊆ b • integral vQ c →
    componentVol vQ c (a • integral vQ c) ≤ componentVol vQ c (b • integral vQ c)
  /-- Archimedean radial scaling: `μ^log(t·B_I) = log t` for real `t > 0`
  (Proposition 1.5(iii) with the normalization `μ^log(B_I) = 0`). -/
  componentVol_arch_scale : ∀ {ι : Type} [Fintype ι] (c : ι → Place K) (t : ℝ), 0 < t →
    componentVol .infinite c (algebraMap ℝ (Tensor .infinite c) t • integral .infinite c) =
      Real.log t
  /-- The **admissible class** of the holomorphic hull (IUT III, Remark 3.9.5(i)):
  nonempty relatively compact regions of finite nonzero log-volume. -/
  admissible : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    Set (Set (Tensor vQ c))
  /-- Admissible regions are nonempty. -/
  admissible_nonempty : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K)
    (U : Set (Tensor vQ c)), U ∈ admissible vQ c → U.Nonempty
  /-- Admissible regions are relatively compact. -/
  admissible_relCompact : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K)
    (U : Set (Tensor vQ c)), U ∈ admissible vQ c → IsCompact (closure U)
  /-- The integral structure is admissible. -/
  integral_admissible : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    integral vQ c ∈ admissible vQ c
  /-- Scaled integral structures are admissible. -/
  smul_integral_admissible : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace)
    (c : ι → Place K) (a : Tensor vQ c), IsUnit a → a • integral vQ c ∈ admissible vQ c
  /-- `μ^log(p⁻¹·U) = μ^log(U) + log p`, for admissible regions `U` (nonempty, relatively
  compact, of finite nonzero Haar measure) of a packet all of whose places lie over `p`
  (IUT III, Proposition 3.9(i)). The restriction to admissible regions is essential: the
  identity is false for `U = ∅` (it would give `log p = 0`) and, with a real-valued
  log-volume, for regions of zero or infinite measure. -/
  componentVol_prime_preimage : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K),
    (∀ j, ∃ w : FinitePlace K, c j = Place.finite w ∧ residueChar w = p) →
    ∀ U ∈ admissible (.finite p) c,
    componentVol (.finite p) c ((fun x => ((p : ℕ) : Tensor (.finite p) c) * x) ⁻¹' U) =
      componentVol (.finite p) c U + Real.log p
  /-- **Existence of least hull regions at a prime** (IUT III, Remark 3.9.5(i)): every
  admissible region of a nonarchimedean packet is contained in a least region `a·(R_I)^∼`
  with `a` a unit, least among all such regions. -/
  exists_leastHull : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K)
    (U : Set (Tensor (.finite p) c)), U ∈ admissible (.finite p) c →
    ∃ a : Tensor (.finite p) c, IsUnit a ∧ U ⊆ a • integral (.finite p) c ∧
      ∀ b : Tensor (.finite p) c, IsUnit b → U ⊆ b • integral (.finite p) c →
        a • integral (.finite p) c ⊆ b • integral (.finite p) c
  /-- **Existence of least hull regions at the archimedean place** (IUT III,
  Remark 3.9.5(i); IUT IV, Proposition 1.5(iii)): every admissible region of an
  archimedean packet is contained in a least real radial scaling `t·B_I` (`t > 0`) of the
  product of unit balls. The hull regions at `∞` are the radial scalings only: among
  arbitrary units `b` of the packet a least `b·B_I` containing a given region need not
  exist. -/
  exists_leastHull_infinite : ∀ {ι : Type} [Fintype ι] (c : ι → Place K)
    (U : Set (Tensor .infinite c)), U ∈ admissible .infinite c →
    ∃ t : ℝ, 0 < t ∧ U ⊆ algebraMap ℝ (Tensor .infinite c) t • integral .infinite c ∧
      ∀ t' : ℝ, 0 < t' → U ⊆ algebraMap ℝ (Tensor .infinite c) t' • integral .infinite c →
        t ≤ t'
  /-- The radial scalings of `B_I` are monotone: `t·B_I ⊆ t'·B_I` for `0 < t ≤ t'`. -/
  smul_integral_infinite_mono : ∀ {ι : Type} [Fintype ι] (c : ι → Place K) (t t' : ℝ),
    0 < t → t ≤ t' →
    algebraMap ℝ (Tensor .infinite c) t • integral .infinite c ⊆
      algebraMap ℝ (Tensor .infinite c) t' • integral .infinite c
  /-- The **indeterminacy automorphisms** `φ` of IUT IV, Proposition 1.2: the
  automorphisms of the packet through which the indeterminacies (Ind1), (Ind2) act. -/
  indAut : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    Set (Tensor vQ c → Tensor vQ c)
  /-- The identity is an indeterminacy automorphism. -/
  id_mem_indAut : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    id ∈ indAut vQ c
  /-- Indeterminacy automorphisms preserve the log-shell (IUT IV, Proposition 1.2). -/
  indAut_logShell : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K)
    (φ : Tensor vQ c → Tensor vQ c), φ ∈ indAut vQ c → φ '' logShell vQ c ⊆ logShell vQ c
  /-- The union of the images of a scaled integral structure under the indeterminacy
  automorphisms is admissible for the hull. -/
  theta_admissible : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K)
    (s : Tensor vQ c), IsUnit s →
    (⋃ φ ∈ indAut vQ c, φ '' (s • integral vQ c)) ∈ admissible vQ c
  /-- The union of the images of the log-shell under the indeterminacy automorphisms is
  admissible for the hull. -/
  thetaShell_admissible : ∀ {ι : Type} [Fintype ι] (vQ : RationalPlace) (c : ι → Place K),
    (⋃ φ ∈ indAut vQ c, φ '' logShell vQ c) ∈ admissible vQ c
  /-- **IUT IV, Proposition 1.4(iii)**: for a scaling element `x` of the `j`-th factor
  with `ord_p(x) = λ ≥ 0`, the images `φ(x·(R_I)^∼)` under all indeterminacy
  automorphisms lie in a hull region `a·(R_I)^∼` whose log-volume is at most
  `(−λ + d_I + 1)·log p + ∑_{i ∈ I*} (3 + log e_i)`, where `d_I = ∑_i d_i` is the sum of
  the different exponents (`d_i = ord_p` of a generator of the different of `K_{c i}`
  over `ℚ_p`), `e_i` the ramification indices, and `I* = {i | p − 2 < e_i}`. The
  different exponent is passed in as the function `d`. Stated, like
  `componentVol_prime_preimage`, for packets all of whose places lie over `p`: for a
  packet with a place not over `p` (the zero ring in the concrete construction) the
  log-volume is identically `0` while the bound is negative for `ord_p(x)` large. -/
  prop14_iii : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K),
    (∀ j, ∃ w : FinitePlace K, c j = Place.finite w ∧ residueChar w = p) →
    ∀ (d : ι → ℝ) (j : ι) (w : FinitePlace K) (h : c j = Place.finite w)
    (x : completionAt K w), x ≠ 0 → 0 ≤ ordp K w x →
    (∀ i w', c i = Place.finite w' → d i = differentExponent K w') →
    ∃ a : Tensor (.finite p) c, IsUnit a ∧
      (∀ φ ∈ indAut (.finite p) c,
        φ '' (incl p c j w h x • integral (.finite p) c) ⊆ a • integral (.finite p) c) ∧
      componentVol (.finite p) c (a • integral (.finite p) c) ≤
        (-ordp K w x + ∑ i, d i + 1) * Real.log p +
          ∑ i, if (p : ℕ) - 2 < ramIdxAt K (c i) then 3 + Real.log (ramIdxAt K (c i)) else 0
  /-- **IUT IV, Proposition 1.4(iv)**: the indeterminacy automorphisms preserve the
  integral structure `(R_I)^∼` (stated there at odd primes unramified in every factor; for
  the maximal order `(R_I)^∼` — the integral closure of `ℤ_p` in the packet — it holds at
  every prime, since automorphisms of a `ℚ_p`-algebra map integral elements to integral
  elements). -/
  prop14_iv : ∀ {ι : Type} [Fintype ι] (p : Nat.Primes) (c : ι → Place K),
    ∀ φ ∈ indAut (.finite p) c, φ '' integral (.finite p) c ⊆ integral (.finite p) c
  /-- **IUT IV, Proposition 1.5(iii),(iv)**: at the archimedean place the images of the
  log-shell under the indeterminacy automorphisms lie in `π^{|I|}·B_I`. -/
  prop15 : ∀ {ι : Type} [Fintype ι] (c : ι → Place K),
    ∀ φ ∈ indAut .infinite c, φ '' logShell .infinite c ⊆
      algebraMap ℝ (Tensor .infinite c) (Real.pi ^ Fintype.card ι) • integral .infinite c

end Iut

end


section

namespace Iut

universe u v

open NumberField

open scoped Pointwise

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}

variable (D : InitialThetaData AG TG)

/-- The `ℓ`-torsion field of the Θ-data, as a type. -/
abbrev InitialThetaData.Kt : Type u := ↥D.prime.torsionField

end Iut

end


section

namespace Iut

universe u v

open NumberField

open scoped Pointwise

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}

variable {D : InitialThetaData AG TG} {LT : LocalTheory.{u, v} D.Kt}

section Tripodal

variable (F : Type*) [Field F] [NumberField F] (E : WeierstrassCurve F) [E.IsElliptic]

open scoped Classical in
/-- The `x`-coordinates of the `F`-rational `2`-torsion points of `E`. -/
def twoTorsionXOf : Set F :=
  {a | ∃ (b : F) (h : E.toAffine.Nonsingular a b),
    WeierstrassCurve.Affine.Point.some a b h ∈ AddSubgroup.torsionBy E.toAffine.Point 2}

/-- **The tripodal field** `F_tpd = F_mod(E[2])` (IUT IV, Theorem 1.10; Proposition
1.8(ii),(iii)): the subfield of `F` generated over `ℚ` by `j(E)` and the `x`-coordinates
of the `2`-torsion points (rational over `F` by IUT I, Definition 3.1(b)). -/
noncomputable def tripodalFieldOf : IntermediateField ℚ F :=
  IntermediateField.adjoin ℚ (insert E.j (twoTorsionXOf F E))

instance : FiniteDimensional ℚ ↥(tripodalFieldOf F E) :=
  Module.Finite.left ℚ ↥(tripodalFieldOf F E) F

instance : NumberField ↥(tripodalFieldOf F E) where

end Tripodal

end Iut

end


section

namespace Iut

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum

open scoped WithZero

variable {k K : Type*} [Field k] [NumberField k] [Field K] [NumberField K] [Algebra k K]

section Norm

variable {w : FinitePlace K}

/-- The norm on the completion `K_w` of the image of `y ∈ K`, in terms of the valuation. -/
lemma norm_emb_le_one_iff (y : K) :
    ‖(FinitePlace.embedding w.maximalIdeal y : localCompletion w)‖ ≤ 1 ↔
      w.maximalIdeal.valuation K y ≤ 1 := by
  rw [norm_le_one_iff_valued, FinitePlace.embedding_apply, valuedAdicCompletion_eq_valuation']

end Norm

section Transfer

variable {w : FinitePlace K} {v : FinitePlace k} (hwv : FinitePlace.LiesOver w v)

include hwv

/-- The ramification index of `w` over `v` is nonzero. -/
lemma ramificationIdx'_ne_zero :
    v.maximalIdeal.asIdeal.ramificationIdx' w.maximalIdeal.asIdeal ≠ 0 := by
  haveI : w.maximalIdeal.asIdeal.LiesOver v.maximalIdeal.asIdeal := hwv
  exact Ideal.IsDedekindDomain.ramificationIdx'_ne_zero_of_liesOver _ v.maximalIdeal.ne_bot

/-- `w(x) = v(x)^e` for `x ∈ k`, where `e` is the ramification index of `w` over `v`. -/
lemma valuation_algebraMap_eq_pow (x : k) :
    w.maximalIdeal.valuation K (algebraMap k K x) =
      v.maximalIdeal.valuation k x ^
        v.maximalIdeal.asIdeal.ramificationIdx' w.maximalIdeal.asIdeal := by
  haveI : w.maximalIdeal.asIdeal.LiesOver v.maximalIdeal.asIdeal := hwv
  rw [Ideal.ramificationIdx'_eq_ramificationIdx
    v.maximalIdeal.asIdeal w.maximalIdeal.asIdeal v.maximalIdeal.ne_bot]
  exact (valuation_liesOver K v.maximalIdeal w.maximalIdeal x).symm

end Transfer

end Iut

end


section

namespace Iut

open NumberField IsDedekindDomain WithZero

noncomputable section

section IntValuation

variable {R S : Type*} [CommRing R] [IsDedekindDomain R] [CommRing S] [IsDedekindDomain S]

omit [IsDedekindDomain R] [IsDedekindDomain S] in
lemma mem_comap_pow_iff (f : R →+* S) (hf : Function.Bijective f) (I : Ideal S) (a : R)
    (n : ℕ) : a ∈ (I.comap f) ^ n ↔ f a ∈ I ^ n := by
  let e := RingEquiv.ofBijective f hf
  have he : I.comap f = I.comap e := by
    ext x; rw [Ideal.mem_comap, Ideal.mem_comap, RingEquiv.coe_ofBijective]
  have hea : f a = e a := (RingEquiv.coe_ofBijective f hf).symm ▸ rfl
  rw [he, hea, ← Ideal.map_symm, ← Ideal.map_pow, Ideal.map_symm, Ideal.mem_comap]

/-- The `intValuation` at the prime `w = f⁻¹(v)` of `a` is the `intValuation` at `v` of `f a`. -/
theorem intValuation_of_comap {v : HeightOneSpectrum S} {w : HeightOneSpectrum R} (f : R →+* S)
    (hf : Function.Bijective f) (hw : w.asIdeal = v.asIdeal.comap f) (a : R) :
    w.intValuation a = v.intValuation (f a) := by
  have key : ∀ n : ℕ, w.intValuation a ≤ exp (-(n : ℤ)) ↔
      v.intValuation (f a) ≤ exp (-(n : ℤ)) := by
    intro n
    rw [HeightOneSpectrum.intValuation_le_pow_iff_mem, HeightOneSpectrum.intValuation_le_pow_iff_mem,
      hw]
    exact mem_comap_pow_iff f hf v.asIdeal a n
  by_cases ha : a = 0
  · subst ha; simp
  have hfa : f a ≠ 0 := (map_ne_zero_iff f hf.injective).2 ha
  obtain ⟨m, hm⟩ : ∃ m : ℕ, w.intValuation a = exp (-(m : ℤ)) :=
    ⟨_, w.intValuation_if_neg ha⟩
  obtain ⟨m', hm'⟩ : ∃ m' : ℕ, v.intValuation (f a) = exp (-(m' : ℤ)) :=
    ⟨_, v.intValuation_if_neg hfa⟩
  rw [hm, hm'] at key ⊢
  simp only [exp_le_exp, neg_le_neg_iff, Nat.cast_le] at key
  rw [le_antisymm ((key m).1 le_rfl) ((key m').2 le_rfl)]

/-- The valuation at `w = f⁻¹(v)` of `x` is the valuation at `v` of `φ x`, for `φ` a field
homomorphism extending `f`. -/
theorem valuation_of_comap {K L : Type*} [Field K] [Algebra R K] [IsFractionRing R K] [Field L]
    [Algebra S L] [IsFractionRing S L] {v : HeightOneSpectrum S} {w : HeightOneSpectrum R}
    (f : R →+* S) (hf : Function.Bijective f) (hw : w.asIdeal = v.asIdeal.comap f)
    (φ : K →+* L) (hφ : ∀ r : R, φ (algebraMap R K r) = algebraMap S L (f r)) (x : K) :
    w.valuation K x = v.valuation L (φ x) := by
  obtain ⟨⟨r, s⟩, rfl⟩ := IsLocalization.mk'_surjective (nonZeroDivisors R) x
  have h3 : v.valuation L (algebraMap S L (f r)) = v.intValuation (f r) :=
    v.valuation_of_algebraMap (K := L) (f r)
  have h4 : v.valuation L (algebraMap S L (f s)) = v.intValuation (f s) :=
    v.valuation_of_algebraMap (K := L) (f s)
  change w.valuation K (IsLocalization.mk' K r s) = v.valuation L (φ (IsLocalization.mk' K r s))
  rw [HeightOneSpectrum.valuation_of_mk', IsFractionRing.mk'_eq_div, map_div₀, hφ, hφ, map_div₀,
    h3, h4, intValuation_of_comap f hf hw, intValuation_of_comap f hf hw]

end IntValuation

section Galois

variable {k K : Type*} [Field k] [NumberField k] [Field K] [NumberField K] [Algebra k K]

variable (σ : K ≃ₐ[k] K) (w : FinitePlace K)

lemma toNNReal_congr {e e' : NNReal} (h : e = e') (he : e ≠ 0) (he' : e' ≠ 0) (x : ℤᵐ⁰) :
    WithZeroMulInt.toNNReal he x = WithZeroMulInt.toNNReal he' x := by
  subst h; rfl

end Galois

end

end Iut

end


section

namespace Iut

open NumberField IsDedekindDomain WithZero

noncomputable section

section Places

variable {k K : Type*} [Field k] [NumberField k] [Field K] [NumberField K] [Algebra k K]
  {v : FinitePlace K} {w : FinitePlace k}

/-- The ramification index `e(v/w)` of `v` over `w`. -/
abbrev relRamIdx (v : FinitePlace K) (w : FinitePlace k) : ℕ :=
  w.maximalIdeal.asIdeal.ramificationIdx' v.maximalIdeal.asIdeal

end Places

end

end Iut

end


section

namespace Iut

open NumberField IsDedekindDomain WithZero TateCurvesTheta

open scoped WithZero

noncomputable section

section Single

variable {K : Type*} [Field K] [NumberField K]

/-- The prime of `ℤ` below the prime of a finite place is generated by its residue
characteristic. -/
lemma under_int_eq (v : FinitePlace K) :
    v.maximalIdeal.asIdeal.under ℤ = Ideal.span {(residueChar v : ℤ)} := by
  set P := v.maximalIdeal.asIdeal
  have hp : (residueChar v).Prime := residueChar_prime v
  haveI : CharP (𝓞 K ⧸ P) (residueChar v) := ringChar.charP _
  have hmem : (residueChar v : ℤ) ∈ P.under ℤ := by
    rw [Ideal.under_def, Ideal.mem_comap, map_natCast]
    exact Ideal.natCast_mem_of_charP_quotient (residueChar v) P
  have hle : Ideal.span {(residueChar v : ℤ)} ≤ P.under ℤ := by
    rw [Ideal.span_le, Set.singleton_subset_iff]
    exact hmem
  haveI hprime : (Ideal.span {(residueChar v : ℤ)}).IsPrime :=
    (Ideal.span_singleton_prime (by exact_mod_cast hp.ne_zero)).mpr
      (Nat.prime_iff_prime_int.mp hp)
  have hmax : (Ideal.span {(residueChar v : ℤ)}).IsMaximal :=
    IsPrime.to_maximal_ideal (by
      rw [Ne, Ideal.span_singleton_eq_bot]
      exact_mod_cast hp.ne_zero)
  haveI : (P.under ℤ).IsPrime := Ideal.comap_isPrime _ _
  exact (hmax.eq_of_le (Ideal.IsPrime.ne_top inferInstance) hle).symm

/-- The prime of `ℤ` below a finite place is nonzero. -/
lemma under_int_ne_bot (v : FinitePlace K) : v.maximalIdeal.asIdeal.under ℤ ≠ ⊥ := by
  rw [under_int_eq, Ne, Ideal.span_singleton_eq_bot]
  exact_mod_cast (residueChar_prime v).ne_zero

/-- The prime of `ℤ` below a finite place is maximal. -/
lemma under_int_isMaximal (v : FinitePlace K) : (v.maximalIdeal.asIdeal.under ℤ).IsMaximal := by
  have hp : (residueChar v).Prime := residueChar_prime v
  rw [under_int_eq]
  haveI : (Ideal.span {(residueChar v : ℤ)}).IsPrime :=
    (Ideal.span_singleton_prime (by exact_mod_cast hp.ne_zero)).mpr
      (Nat.prime_iff_prime_int.mp hp)
  exact IsPrime.to_maximal_ideal (by
    rw [Ne, Ideal.span_singleton_eq_bot]
    exact_mod_cast hp.ne_zero)

/-- The prime of a finite place lies over `(p)`, `p` its residue characteristic. -/
lemma liesOver_span_residueChar (v : FinitePlace K) :
    v.maximalIdeal.asIdeal.LiesOver (Ideal.span {(residueChar v : ℤ)}) :=
  ⟨(under_int_eq v).symm⟩

/-- `N(𝔭_v) = p^{f_v}`. -/
lemma absNorm_eq_pow_residueChar (v : FinitePlace K) :
    Ideal.absNorm v.maximalIdeal.asIdeal = residueChar v ^ inertDeg K v := by
  haveI := liesOver_span_residueChar v
  exact (Ideal.pow_inertiaDeg (residueChar v) v.maximalIdeal.asIdeal).symm

/-- `f_v > 0`. -/
lemma inertDeg_pos' (v : FinitePlace K) : 0 < inertDeg K v :=
  Ideal.inertiaDeg_pos v.maximalIdeal.asIdeal ℤ

/-- `e_v > 0`. -/
lemma ramIdx_pos' (v : FinitePlace K) : 0 < ramIdx K v :=
  v.maximalIdeal.asIdeal.ramificationIdx_pos ℤ

/-- The norm of an element of valuation `exp m` is `(p^{f_v})^m`. -/
lemma norm_eq_zpow_of_valued (v : FinitePlace K) (x : completionAt K v) (m : ℤ)
    (hx : Valued.v x = exp m) :
    ‖x‖ = ((residueChar v : ℝ) ^ inertDeg K v) ^ m := by
  rw [FinitePlace.norm_def, hx, WithZeroMulInt.toNNReal_neg_apply _ exp_ne_zero]
  rw [WithZero.log_exp, NNReal.coe_zpow, NNReal.coe_natCast,
    absNorm_eq_pow_residueChar, Nat.cast_pow]

end Single

section Extension

variable {k K : Type*} [Field k] [NumberField k] [Field K] [NumberField K] [Algebra k K]

/-- `𝓞_K` is torsion-free over `𝓞_k`. -/
instance ringOfIntegers_isTorsionFree : Module.IsTorsionFree (𝓞 k) (𝓞 K) where
  isSMulRegular r hr a b hab := by
    have hr0 : algebraMap (𝓞 k) (𝓞 K) r ≠ 0 :=
      (map_ne_zero_iff _ algebraMap_ringOfIntegers_injective).mpr hr.ne_zero
    simp only [Algebra.smul_def] at hab
    exact mul_left_cancel₀ hr0 hab

variable {v : FinitePlace K} {w : FinitePlace k} (hvw : FinitePlace.LiesOver v w)

include hvw

/-- The prime of `ℤ` below `v` is the prime below `w`. -/
lemma under_int_eq_under_int : v.maximalIdeal.asIdeal.under ℤ = w.maximalIdeal.asIdeal.under ℤ := by
  haveI : v.maximalIdeal.asIdeal.LiesOver w.maximalIdeal.asIdeal := hvw
  rw [← Ideal.under_under (B := 𝓞 k) v.maximalIdeal.asIdeal,
    ← Ideal.over_def v.maximalIdeal.asIdeal w.maximalIdeal.asIdeal]

/-- Places over each other have the same residue characteristic. -/
lemma residueChar_eq_of_liesOver : residueChar v = residueChar w := by
  have h := under_int_eq_under_int hvw
  rw [under_int_eq, under_int_eq, Ideal.span_singleton_eq_span_singleton] at h
  have h' := Int.natAbs_eq_iff_associated.mpr h
  simpa using h'

/-- The ramification index `e(v/w)` is nonzero. -/
lemma relRamIdx_ne_zero : relRamIdx v w ≠ 0 := ramificationIdx'_ne_zero hvw

/-- `e_v = e_w · e(v/w)`. -/
lemma ramIdx_eq_mul : ramIdx K v = ramIdx k w * relRamIdx v w := by
  haveI : v.maximalIdeal.asIdeal.LiesOver w.maximalIdeal.asIdeal := hvw
  have hp : v.maximalIdeal.asIdeal.under ℤ ≠ ⊥ := under_int_ne_bot v
  haveI : w.maximalIdeal.asIdeal.LiesOver (v.maximalIdeal.asIdeal.under ℤ) :=
    Ideal.LiesOver.tower_bot v.maximalIdeal.asIdeal w.maximalIdeal.asIdeal _
  have h1 : ramIdx K v = (v.maximalIdeal.asIdeal.under ℤ).ramificationIdx' v.maximalIdeal.asIdeal :=
    (Ideal.ramificationIdx'_eq_ramificationIdx _ v.maximalIdeal.asIdeal hp).symm
  have h2 : ramIdx k w =
      (v.maximalIdeal.asIdeal.under ℤ).ramificationIdx' w.maximalIdeal.asIdeal := by
    have := (Ideal.ramificationIdx'_eq_ramificationIdx (w.maximalIdeal.asIdeal.under ℤ)
      w.maximalIdeal.asIdeal (under_int_ne_bot w)).symm
    rw [under_int_eq_under_int hvw]
    exact this
  rw [h1, h2]
  exact Ideal.ramificationIdx'_algebra_tower' _ w.maximalIdeal.asIdeal v.maximalIdeal.asIdeal

/-- The residue degree `f(v/w)` of `v` over `w`. -/
abbrev relInertDeg (v : FinitePlace K) (w : FinitePlace k) : ℕ :=
  w.maximalIdeal.asIdeal.inertiaDeg' v.maximalIdeal.asIdeal

/-- `f_v = f_w · f(v/w)`. -/
lemma inertDeg_eq_mul : inertDeg K v = inertDeg k w * relInertDeg v w := by
  haveI : v.maximalIdeal.asIdeal.LiesOver w.maximalIdeal.asIdeal := hvw
  haveI : w.maximalIdeal.asIdeal.LiesOver (v.maximalIdeal.asIdeal.under ℤ) :=
    Ideal.LiesOver.tower_bot v.maximalIdeal.asIdeal w.maximalIdeal.asIdeal _
  haveI : (v.maximalIdeal.asIdeal.under ℤ).IsMaximal := under_int_isMaximal v
  haveI : w.maximalIdeal.asIdeal.IsMaximal :=
    w.maximalIdeal.isPrime.isMaximal w.maximalIdeal.ne_bot
  haveI : v.maximalIdeal.asIdeal.IsMaximal :=
    v.maximalIdeal.isPrime.isMaximal v.maximalIdeal.ne_bot
  have h1 : inertDeg K v = (v.maximalIdeal.asIdeal.under ℤ).inertiaDeg' v.maximalIdeal.asIdeal :=
    (Ideal.inertiaDeg'_eq_inertiaDeg _ v.maximalIdeal.asIdeal).symm
  have h2 : inertDeg k w = (v.maximalIdeal.asIdeal.under ℤ).inertiaDeg' w.maximalIdeal.asIdeal := by
    haveI : (w.maximalIdeal.asIdeal.under ℤ).IsMaximal := under_int_isMaximal w
    have := (Ideal.inertiaDeg'_eq_inertiaDeg (w.maximalIdeal.asIdeal.under ℤ)
      w.maximalIdeal.asIdeal).symm
    rw [under_int_eq_under_int hvw]
    exact this
  rw [h1, h2]
  exact Ideal.inertiaDeg'_algebra_tower _ w.maximalIdeal.asIdeal v.maximalIdeal.asIdeal

/-- `[K_v : ℚ_p] = [k_w : ℚ_p] · e(v/w) f(v/w)`. -/
lemma localDeg_eq_mul : localDeg K v = localDeg k w * (relRamIdx v w * relInertDeg v w) := by
  unfold localDeg
  rw [ramIdx_eq_mul hvw, inertDeg_eq_mul hvw]
  ring

end Extension

section Sum

variable {k K : Type*} [Field k] [NumberField k] [Field K] [NumberField K] [Algebra k K]

/-- `∑_{v ∣ w} e_v f_v = [K : k] · e_w f_w`, for any finset `s` of places of `K` consisting of
exactly the places over `w`. -/
theorem sum_localDeg_liesOver (w : FinitePlace k) (s : Finset (FinitePlace K))
    (hs : ∀ v, v ∈ s ↔ FinitePlace.LiesOver v w) :
    ∑ v ∈ s, localDeg K v = Module.finrank k K * localDeg k w := by
  classical
  haveI : w.maximalIdeal.asIdeal.IsMaximal :=
    w.maximalIdeal.isPrime.isMaximal w.maximalIdeal.ne_bot
  have hp0 : w.maximalIdeal.asIdeal ≠ ⊥ := w.maximalIdeal.ne_bot
  have hsum := Ideal.sum_ramification_inertia (𝓞 K) k K hp0 (p := w.maximalIdeal.asIdeal)
  have hbij : ∑ v ∈ s, (relRamIdx v w * relInertDeg v w) =
      ∑ P ∈ IsDedekindDomain.primesOverFinset w.maximalIdeal.asIdeal (𝓞 K),
        w.maximalIdeal.asIdeal.ramificationIdx' P * w.maximalIdeal.asIdeal.inertiaDeg' P := by
    refine Finset.sum_bij (fun v _ => v.maximalIdeal.asIdeal) ?_ ?_ ?_ ?_
    · intro v hv
      haveI : v.maximalIdeal.asIdeal.LiesOver w.maximalIdeal.asIdeal := (hs v).mp hv
      exact (IsDedekindDomain.mem_primesOverFinset_iff hp0 (𝓞 K)).mpr ⟨inferInstance, inferInstance⟩
    · intro v₁ _ v₂ _ h
      exact (FinitePlace.maximalIdeal_inj _ _).mp (HeightOneSpectrum.ext h)
    · intro P hP
      obtain ⟨hprime, hover⟩ := (IsDedekindDomain.mem_primesOverFinset_iff hp0 (𝓞 K)).mp hP
      have hne : P ≠ ⊥ := Ideal.ne_bot_of_liesOver_of_ne_bot hp0 P
      refine ⟨FinitePlace.mk ⟨P, hprime, hne⟩, ?_, ?_⟩
      · rw [hs]
        unfold FinitePlace.LiesOver
        rw [FinitePlace.maximalIdeal_mk]
        exact hover
      · rw [FinitePlace.maximalIdeal_mk]
    · intro v _
      rfl
  have h : ∀ v ∈ s, localDeg K v = localDeg k w * (relRamIdx v w * relInertDeg v w) :=
    fun v hv => localDeg_eq_mul ((hs v).mp hv)
  rw [Finset.sum_congr rfl h, ← Finset.mul_sum, hbij, hsum, mul_comm]

end Sum

section Uniformizer

variable {k : Type*} [Field k] [NumberField k] (w : FinitePlace k)

/-- A uniformizer in the sense of `TateCurvesTheta.IsUniformizer` has valuation `exp (−1)`. -/
lemma valued_eq_of_isUniformizer {π : localCompletion w} (hπ : IsUniformizer π) :
    Valued.v π = exp (-1 : ℤ) := by
  -- an element of valuation `exp (-1)`
  obtain ⟨π₀, hπ₀⟩ := w.maximalIdeal.valuation_exists_uniformizer' (K := k)
  have hπ₀' : Valued.v (FinitePlace.embedding w.maximalIdeal π₀ : localCompletion w) =
      exp (-1 : ℤ) := by
    rw [FinitePlace.embedding_apply, HeightOneSpectrum.valuedAdicCompletion_eq_valuation', hπ₀]
  have hN : (1 : ℝ) < (residueChar w : ℝ) ^ inertDeg k w := by
    have hp : (residueChar w).Prime := residueChar_prime w
    exact one_lt_pow₀ (by exact_mod_cast hp.one_lt) (inertDeg_pos' w).ne'
  have hN0 : (0 : ℝ) < (residueChar w : ℝ) ^ inertDeg k w := zero_lt_one.trans hN
  have hπ' : Valued.v π ≠ 0 := (Valuation.ne_zero_iff _).2 hπ.ne_zero
  set m : ℤ := log (Valued.v π)
  have hm : Valued.v π = exp m := (exp_log hπ').symm
  have hnorm : ‖π‖ = ((residueChar w : ℝ) ^ inertDeg k w) ^ m := norm_eq_zpow_of_valued w π m hm
  have hm0 : m < 0 := by
    have := hπ.norm_lt_one
    rw [hnorm, zpow_lt_one_iff_right₀ hN] at this
    exact this
  have hunit : (FinitePlace.embedding w.maximalIdeal π₀ : localCompletion w) ≠ 0 := by
    intro h
    rw [h, map_zero] at hπ₀'
    exact exp_ne_zero hπ₀'.symm
  obtain ⟨n, hn⟩ := hπ.generates (Units.mk0 _ hunit)
  rw [Units.val_mk0, norm_eq_zpow_of_valued w _ _ hπ₀', hnorm, ← zpow_mul] at hn
  have hmn : (-1 : ℤ) = m * n := zpow_right_injective₀ hN0 hN.ne' hn
  have hm1 : m = -1 := by
    have hunit : IsUnit m := IsUnit.of_mul_eq_one (-n) (by rw [mul_neg, ← hmn]; norm_num)
    rcases Int.isUnit_iff.mp hunit with h | h
    · omega
    · exact h
  rw [hm, hm1]

variable {w}

/-- The valuation of a Tate parameter is `exp (−orderNat)`, for the normalized order with
respect to a uniformizer. -/
lemma valued_tateParameter_q (t : TateParameter (localCompletion w)) {π : localCompletion w}
    (hπ : IsUniformizer π) :
    Valued.v (t.q : localCompletion w) = exp (-((t.toOrdered hπ).orderNat : ℤ)) := by
  have hq : (t.q : localCompletion w) ≠ 0 := t.q.ne_zero
  have hq' : Valued.v (t.q : localCompletion w) ≠ 0 := (Valuation.ne_zero_iff _).2 hq
  set m : ℤ := log (Valued.v (t.q : localCompletion w))
  have hm : Valued.v (t.q : localCompletion w) = exp m := (exp_log hq').symm
  have hN : (1 : ℝ) < (residueChar w : ℝ) ^ inertDeg k w := by
    have hp : (residueChar w).Prime := residueChar_prime w
    exact one_lt_pow₀ (by exact_mod_cast hp.one_lt) (inertDeg_pos' w).ne'
  have h1 := t.norm_q_eq_pow_orderNat hπ
  rw [norm_eq_zpow_of_valued w _ m hm,
    norm_eq_zpow_of_valued w π _ (valued_eq_of_isUniformizer w hπ)] at h1
  set N : ℝ := (residueChar w : ℝ) ^ inertDeg k w with hN'
  rw [← zpow_natCast, ← zpow_mul] at h1
  have := zpow_right_injective₀ (zero_lt_one.trans hN) hN.ne' h1
  rw [hm, this]
  congr 1
  ring

end Uniformizer

end

end Iut

end


section

namespace Iut

universe u v

open NumberField WeierstrassCurve TateCurvesTheta OrbicurveDataSection

/-- An elliptic curve `E` over a number field `F` with a chosen algebraic closure `F̄`. -/
structure EllipticCurveData : Type (u + 1) where
  /-- The number field `F`. -/
  F : Type u
  /-- `F` is a field. -/
  [fieldF : Field F]
  /-- `F` is a number field. -/
  [numberFieldF : NumberField F]
  /-- The algebraic closure `F̄`. -/
  Fbar : Type u
  /-- `F̄` is a field. -/
  [fieldFbar : Field Fbar]
  /-- `F̄` is an `F`-algebra. -/
  [algebraFbar : Algebra F Fbar]
  /-- `F̄` is an algebraic closure of `F`. -/
  [isAlgClosure : IsAlgClosure F Fbar]
  /-- The elliptic curve `E/F`. -/
  E : WeierstrassCurve F
  /-- `E` is an elliptic curve. -/
  [isElliptic : E.IsElliptic]

namespace EllipticCurveData

attribute [instance] fieldF numberFieldF fieldFbar algebraFbar isAlgClosure isElliptic

variable (C : EllipticCurveData.{u})

/-- The places of `F` at which `E` has (bad) multiplicative reduction. -/
def badAll : Set (FinitePlace C.F) := {w | HasMultiplicativeReductionAt C.E w}

/-- **The arithmetic of the curve** (IUT IV, Proposition 1.8; the places of `F/F_mod`):
the standard facts about `E/F` consumed by the construction of initial Θ-data. -/
structure CurveArithmetic : Prop where
  /-- `√−1 ∈ F`. -/
  sqrt_neg_one : IsSquare (-1 : C.F)
  /-- `E` has stable reduction at every finite place of `F`. -/
  stable_reduction : ∀ w : FinitePlace C.F, HasStableReductionAt C.E w
  /-- The `6`-torsion of `E` is rational over `F`. -/
  six_torsion_rational : SixTorsionRational C.F C.E C.Fbar
  /-- `F/F_mod` is Galois of degree prime to every prime `ℓ ≥ 7`. -/
  galois_deg_prime : ∀ ℓ : ℕ, ℓ.Prime → 7 ≤ ℓ → IsGaloisOfDegreePrimeTo C.F C.E ℓ
  /-- Every finite place of `F` lies over a finite place of `F_mod`. -/
  exists_liesOver : ∀ w : FinitePlace C.F,
    ∃ v : FinitePlace ↥(fieldOfModuli C.F C.E), FinitePlace.LiesOver w v
  /-- A place of `F` over a place of `F_mod` has the same residue characteristic. -/
  residueChar_liesOver : ∀ (v : FinitePlace ↥(fieldOfModuli C.F C.E)) (w : FinitePlace C.F),
    FinitePlace.LiesOver w v → residueChar w = residueChar v
  /-- Multiplicative reduction does not depend on the place of `F` over a given place of
  `F_mod` of odd residue characteristic (`E` descends to `F_tpd` up to twist and has
  semistable reduction). -/
  mult_invariant : ∀ v : FinitePlace ↥(fieldOfModuli C.F C.E), residueChar v ≠ 2 →
    ∀ w w' : FinitePlace C.F, FinitePlace.LiesOver w v → FinitePlace.LiesOver w' v →
    HasMultiplicativeReductionAt C.E w → HasMultiplicativeReductionAt C.E w'
  /-- The bad locus is finite. -/
  badAll_finite : C.badAll.Finite
  /-- Residue degrees are positive. -/
  inertDeg_pos : ∀ w : FinitePlace C.F, 0 < inertDeg C.F w
  /-- Over a rational prime, the residue degrees of the bad places sum to at most
  `[F : ℚ]`. -/
  sum_inertDeg_le : ∀ q : ℕ,
    ∑ w ∈ badAll_finite.toFinset.filter (fun w => residueChar w = q), inertDeg C.F w ≤
      Module.finrank ℚ C.F

/-- **Tate parameters** of `E` at its multiplicative places, with uniformizers of the
completions (the interface of taxis #37). -/
structure TateInputs : Type u where
  /-- The Tate parameter `q_w` of `E` at each multiplicative place. -/
  tate : ∀ w ∈ C.badAll, TateParameter (localCompletion w)
  /-- The Tate parameter is that of `E`: the `j`-invariant of its Tate curve is `j(E)`. -/
  tateJ_eq : ∀ w (hw : w ∈ C.badAll),
    (tate w hw).tateJ = FinitePlace.embedding w.maximalIdeal C.E.j
  /-- A chosen uniformizer of each completion. -/
  unif : ∀ w ∈ C.badAll, localCompletion w
  /-- The chosen elements are uniformizers. -/
  unif_isUniformizer : ∀ w (hw : w ∈ C.badAll), IsUniformizer (unif w hw)

variable {C} in
/-- The normalized order `h_w = ord_w(q_w)` of the Tate parameter. -/
noncomputable def TateInputs.qOrder (TI : C.TateInputs) (w : FinitePlace C.F)
    (hw : w ∈ C.badAll) : ℕ :=
  ((TI.tate w hw).toOrdered (TI.unif_isUniformizer w hw)).orderNat

variable {C} in
lemma TateInputs.qOrder_pos (TI : C.TateInputs) (w : FinitePlace C.F) (hw : w ∈ C.badAll) :
    0 < TI.qOrder w hw :=
  ((TI.tate w hw).toOrdered (TI.unif_isUniformizer w hw)).orderNat_pos

open scoped Classical in
/-- **The mod-`ℓ` Galois representation** of `E` (taxis #277): a basis of `E(F̄)[ℓ]`, the
representation `ρ : Gal(F̄/F) → GL₂(𝔽_ℓ)` computing the Galois action in this basis,
and the openness of its kernel. -/
structure ModEllRepData (ℓ : ℕ) : Type u where
  /-- A chosen `𝔽_ℓ`-basis of the `ℓ`-torsion. -/
  torsionBasis :
    AddSubgroup.torsionBy (Affine.Point (Affine.baseChange C.E C.Fbar)) ℓ ≃+
      (Fin 2 → ZMod ℓ)
  /-- The mod-`ℓ` representation. -/
  rep : (C.Fbar ≃ₐ[C.F] C.Fbar) →* Matrix.GeneralLinearGroup (Fin 2) (ZMod ℓ)
  /-- `ρ σ` is the matrix of the Galois action of `σ` in the chosen basis. -/
  rep_spec : ∀ (σ : C.Fbar ≃ₐ[C.F] C.Fbar)
    (P : AddSubgroup.torsionBy (Affine.Point (Affine.baseChange C.E C.Fbar)) ℓ),
    torsionBasis ⟨galPointMap C.F C.E C.Fbar σ P.1, galPointMap_torsionBy C.F C.E C.Fbar σ P.2⟩ =
      (rep σ : Matrix (Fin 2) (Fin 2) (ZMod ℓ)).mulVec (torsionBasis P)
  /-- The kernel of `ρ` is open. -/
  ker_isOpen : IsOpen (rep.ker : Set (C.Fbar ≃ₐ[C.F] C.Fbar))

open scoped Classical in
/-- **The local height data** of `E/F` (IUT IV, Theorem 1.10; [GenEll], Definition 3.3):
the multiplicative places with their residue characteristics, the orders of the Tate
parameters, and the residue degrees. -/
noncomputable def localHeightData (CA : C.CurveArithmetic) (TI : C.TateInputs) :
    LocalHeightData.{u} where
  ι := FinitePlace C.F
  bad := CA.badAll_finite.toFinset
  p := residueChar
  hv w := if h : w ∈ C.badAll then TI.qOrder w h else 0
  f := inertDeg C.F
  deg := Module.finrank ℚ C.F
  one_le_deg := Module.finrank_pos
  p_prime w _ := residueChar_prime w
  one_le_hv w hw := by
    rw [Set.Finite.mem_toFinset] at hw
    rw [dif_pos hw]
    exact TI.qOrder_pos w hw
  one_le_f w _ := CA.inertDeg_pos w
  sum_f_le := CA.sum_inertDeg_le

end EllipticCurveData

end Iut

end


section

namespace Iut

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum WeierstrassCurve
  TateCurvesTheta

section Uniformizer

variable {F : Type*} [Field F] [NumberField F] (w : FinitePlace F)

/-- The image in `F_w` of an element of `F` of valuation `exp (-1)` is a uniformizer of the
normed field `F_w`. -/
lemma isUniformizer_of_valuation_eq {π : F}
    (hπ : w.maximalIdeal.valuation F π = WithZero.exp (-1 : ℤ)) :
    IsUniformizer (FinitePlace.embedding w.maximalIdeal π) := by
  have hv : Valued.v (FinitePlace.embedding w.maximalIdeal π) = WithZero.exp (-1 : ℤ) := by
    rw [FinitePlace.embedding_apply, valuedAdicCompletion_eq_valuation', hπ]
  have hne : FinitePlace.embedding w.maximalIdeal π ≠ 0 := by
    rw [← (Valued.v).ne_zero_iff, hv]
    exact WithZero.exp_ne_zero
  refine ⟨hne, ?_, ?_⟩
  · rw [norm_lt_one_iff_valued, hv, ← WithZero.exp_zero, WithZero.exp_lt_exp]
    norm_num
  · intro x
    set π' := FinitePlace.embedding w.maximalIdeal π with hπ'
    have hx0 : Valued.v (x : localCompletion w) ≠ 0 := (Valued.v).ne_zero_iff.mpr x.ne_zero
    refine ⟨-WithZero.log (Valued.v (x : localCompletion w)), ?_⟩
    -- the quotient `x / π ^ n` has valuation `1`, hence norm `1`
    have hunit : ‖(x : localCompletion w) / π' ^ (-WithZero.log (Valued.v (x : localCompletion w)))‖
        = 1 := by
      rw [norm_eq_one_iff_valued, map_div₀, map_zpow₀, hv, ← WithZero.exp_zsmul, smul_neg,
        smul_eq_mul, mul_one, neg_neg, WithZero.exp_log hx0, div_self hx0]
    rw [norm_div, norm_zpow] at hunit
    have hπpos : 0 < ‖π'‖ := norm_pos_iff.mpr hne
    have hpow : 0 < ‖π'‖ ^ (-WithZero.log (Valued.v (x : localCompletion w))) := zpow_pos hπpos _
    rw [div_eq_one_iff_eq hpow.ne'] at hunit
    exact hunit

/-- Every completion `F_w` has a uniformizer in the sense of `TateCurvesTheta.IsUniformizer`. -/
lemma exists_isUniformizer : ∃ π : localCompletion w, IsUniformizer π := by
  obtain ⟨π, hπ⟩ := w.maximalIdeal.valuation_exists_uniformizer F
  exact ⟨_, isUniformizer_of_valuation_eq w hπ⟩

end Uniformizer

namespace EllipticCurveData

variable (C : EllipticCurveData.{u})

/-- At a place of multiplicative reduction, the `j`-invariant has norm `> 1` in `F_w`
(`Iut.one_lt_valuation_j_of_mult`, via a minimal model `C • E`). -/
lemma one_lt_norm_j {w : FinitePlace C.F} (hw : w ∈ C.badAll) :
    1 < ‖FinitePlace.embedding w.maximalIdeal C.E.j‖ :=
  not_le.1 fun h => not_le.2 (one_lt_valuation_j_of_mult C.E w hw) ((norm_emb_le_one_iff _).1 h)

/-- The Tate parameter of `E` at a place of multiplicative reduction: the unique Tate
parameter of `F_w` whose Tate curve has `j`-invariant `j(E)`. -/
noncomputable def tateParameter {w : FinitePlace C.F} (hw : w ∈ C.badAll) :
    TateParameter (localCompletion w) :=
  (TateParameter.exists_tateParameter_tateJ_eq (twelve_ne_zero w) (C.one_lt_norm_j hw)).choose

lemma tateParameter_tateJ {w : FinitePlace C.F} (hw : w ∈ C.badAll) :
    (C.tateParameter hw).tateJ = FinitePlace.embedding w.maximalIdeal C.E.j :=
  (TateParameter.exists_tateParameter_tateJ_eq (twelve_ne_zero w)
    (C.one_lt_norm_j hw)).choose_spec

/-- **The Tate inputs** of an elliptic curve over a number field: Tate parameters at the
multiplicative places, via the `j`-parametrization of Tate curves, and uniformizers of the
completions. -/
noncomputable def tateInputs : C.TateInputs where
  tate _ hw := C.tateParameter hw
  tateJ_eq _ hw := C.tateParameter_tateJ hw
  unif w _ := (exists_isUniformizer w).choose
  unif_isUniformizer w _ := (exists_isUniformizer w).choose_spec

end EllipticCurveData

end Iut

end


section

namespace Iut

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum WeierstrassCurve

universe u

section Reduction

variable {F : Type*} [Field F] [NumberField F] (E : WeierstrassCurve F) [E.IsElliptic]
  (w : FinitePlace F)

/-- `v_w(j(E)) ≤ 1` at a place of good reduction: the good model `C • E` is integral with
`v_w(Δ) = 1`, and `j` is invariant under changes of variables. -/
lemma valuation_j_le_one_of_good (hw : HasGoodReductionAt E w) :
    w.maximalIdeal.valuation F E.j ≤ 1 := by
  obtain ⟨C, hC⟩ := hw
  haveI : ((C • E).baseChange (w.maximalIdeal.adicCompletion F)).HasGoodReduction
    (w.maximalIdeal.adicCompletionIntegers F) := hC
  have hΔ : ‖((C • E).baseChange (w.maximalIdeal.adicCompletion F)).Δ‖ = 1 :=
    (valuation_eq_one_iff w _).1 HasGoodReduction.goodReduction
  have hc₄ : ‖((C • E).baseChange (w.maximalIdeal.adicCompletion F)).c₄‖ ≤ 1 := norm_c₄_le_one _
  rw [baseChange_adicCompletion_eq, map_Δ] at hΔ
  rw [baseChange_adicCompletion_eq, map_c₄] at hc₄
  rw [← variableChange_j E C, ← norm_emb_le_one_iff, j_eq_inv_Δ_mul, map_mul, map_inv₀,
    map_pow, norm_mul, norm_inv, norm_pow, hΔ, inv_one, one_mul]
  exact pow_le_one₀ (norm_nonneg _) hc₄

/-- At a place of stable reduction, `E` has multiplicative reduction iff `v_w(j(E)) > 1`. -/
lemma hasMultiplicativeReductionAt_iff_of_stable (hst : HasStableReductionAt E w) :
    HasMultiplicativeReductionAt E w ↔ ¬ w.maximalIdeal.valuation F E.j ≤ 1 := by
  constructor
  · intro hw
    exact not_le.2 (one_lt_valuation_j_of_mult E w hw)
  · intro h
    rcases hst with hg | hm
    · exact absurd (valuation_j_le_one_of_good E w hg) h
    · exact hm

end Reduction

end Iut

end


section

namespace Iut.Tripod

open WeierstrassCurve NumberField

open scoped IntermediateField

/-- A chosen square root of `−1` in `ℚ̄`. -/
noncomputable def sqrtNegOne : Qbar :=
  (IsAlgClosed.exists_pow_nat_eq (-1 : Qbar) two_pos).choose

/-- A chosen square root of `λ` in `ℚ̄`. -/
noncomputable def sqrtLam (l : Qbar) : Qbar := (IsAlgClosed.exists_pow_nat_eq l two_pos).choose

/-- A chosen square root of `1 − λ` in `ℚ̄`. -/
noncomputable def sqrtOneSubLam (l : Qbar) : Qbar :=
  (IsAlgClosed.exists_pow_nat_eq (1 - l) two_pos).choose

/-- The set of affine coordinates of a point of `E_λ(ℚ̄)`: `∅` for the origin, `{x, y}` for an
affine point `(x, y)`. -/
def coords {l : Qbar} : (legendre l).toAffine.Point → Set Qbar
  | 0 => ∅
  | Affine.Point.some x y _ => {x, y}

open scoped Classical in
/-- The `n`-torsion points of `E_λ(ℚ̄)`. -/
def torsionSet (l : Qbar) (n : ℕ) : Set (legendre l).toAffine.Point := {P | n • P = 0}

/-- **Finiteness of the `n`-torsion** of `E_λ(ℚ̄)`: the hypothesis of the construction of
the field of definition. It is a theorem for every `λ` and `n ≠ 0`
(`Iut.Tripod.legendre_torsionFinite`, from the division polynomials), and follows also from
`E_λ[n](ℚ̄) ≅ (ℤ/n)²` (`torsionFinite_of_equiv`). -/
def TorsionFinite (l : Qbar) (n : ℕ) : Prop := (torsionSet l n).Finite

/-- The coordinates of the `n`-torsion points of `E_λ(ℚ̄)`. -/
def torsionCoords (l : Qbar) (n : ℕ) : Set Qbar := ⋃ P ∈ torsionSet l n, coords P

theorem torsionCoords_finite {l : Qbar} {n : ℕ} (h : TorsionFinite l n) :
    (torsionCoords l n).Finite :=
  h.biUnion fun P _ ↦ by
    cases P with
    | zero => exact Set.finite_empty
    | some x y _ => exact (Set.finite_singleton y).insert x

/-- **The field of definition** `F_λ = ℚ(λ, √−1, √λ, √(1 − λ), E_λ[3], E_λ[5]) ⊆ ℚ̄` of the
Legendre curve of `λ`.

The square roots `√λ`, `√(1 − λ)` are adjoined so that `F_λ` is Galois over the field of
moduli `ℚ(j)`, as required by `Iut.IsGaloisOfDegreePrimeTo` (proved in
`Iut/Tripod/Galois.lean`): over `ℚ(j)` the conjugates of `λ` are the six values
`λ, 1 − λ, 1/λ, 1/(1 − λ), λ/(λ − 1), (λ − 1)/λ`; `E_{1−λ} ≅ E_λ` over `ℚ(λ, √−1)`, while
`E_{1/λ}` and `E_{1/(1−λ)}` are the quadratic twists of `E_λ` by `λ` and by `1 − λ`, so
`ℚ(λ, √−1, √λ, √(1 − λ), E_λ[15])` contains the `15`-torsion fields of all the conjugate
curves and is Galois over `ℚ(j)`. -/
noncomputable def fieldOf' (l : Qbar) : IntermediateField ℚ Qbar :=
  IntermediateField.adjoin ℚ
    ({l, sqrtNegOne, sqrtLam l, sqrtOneSubLam l} ∪ torsionCoords l 3 ∪ torsionCoords l 5)

theorem mem_fieldOf'_self (l : Qbar) : l ∈ fieldOf' l :=
  IntermediateField.subset_adjoin _ _ (Or.inl (Or.inl (by simp)))

/-- `F_λ` is a finite extension of `ℚ` when the `3`- and `5`-torsion of `E_λ(ℚ̄)` are
finite. -/
theorem finiteDimensional_fieldOf' {l : Qbar} (h3 : TorsionFinite l 3) (h5 : TorsionFinite l 5) :
    FiniteDimensional ℚ (fieldOf' l) := by
  have hfin : ({l, sqrtNegOne, sqrtLam l, sqrtOneSubLam l} ∪ torsionCoords l 3 ∪
      torsionCoords l 5).Finite :=
    ((Set.toFinite _).union (torsionCoords_finite h3)).union (torsionCoords_finite h5)
  haveI := hfin.to_subtype
  exact IntermediateField.finiteDimensional_adjoin fun x _ ↦ isIntegral x

/-- The element `λ` of `F_λ`. -/
noncomputable def gen' (l : Qbar) : fieldOf' l := ⟨l, mem_fieldOf'_self l⟩

theorem gen'_ne_zero {l : Qbar} (hl : l ≠ 0) : gen' l ≠ 0 := by
  intro h
  exact hl (congrArg Subtype.val h)

theorem gen'_ne_one {l : Qbar} (hl : l ≠ 1) : gen' l ≠ 1 := by
  intro h
  exact hl (congrArg Subtype.val h)

/-- `ℚ̄` is torsion-free over every intermediate field `F ⊆ ℚ̄` (an explicit instance, since
the generic search times out). -/
instance (F : IntermediateField ℚ Qbar) : Module.IsTorsionFree F Qbar :=
  Module.isTorsionFree_iff_algebraMap_injective.mpr (algebraMap F Qbar).injective

/-- `ℚ̄` is an algebraic closure of every intermediate field `F ⊆ ℚ̄`. -/
instance (F : IntermediateField ℚ Qbar) : IsAlgClosure F Qbar := by
  haveI : Algebra.IsAlgebraic ℚ Qbar := AlgebraicClosure.isAlgebraic ℚ
  exact (isAlgClosure_iff F Qbar).mpr ⟨inferInstance, Algebra.IsAlgebraic.tower_top (K := ℚ) F⟩

/-- The Legendre curve of `λ` over `F_λ` is elliptic. -/
theorem legendre_gen'_isElliptic (x : Pt) : (legendre (gen' x.1)).IsElliptic :=
  legendre_isElliptic (gen'_ne_zero x.2.1) (gen'_ne_one x.2.2)

/-- **The elliptic curve of a point `λ` of the tripod**: the Legendre curve `E_λ` over its
field of definition `F_λ = ℚ(λ, √−1, √λ, √(1 − λ), E_λ[3], E_λ[5])`, with the algebraic
closure `ℚ̄`. -/
noncomputable def curveOf (x : Pt) (h3 : TorsionFinite x.1 3) (h5 : TorsionFinite x.1 5) :
    EllipticCurveData :=
  letI := finiteDimensional_fieldOf' h3 h5
  { F := fieldOf' x.1
    Fbar := Qbar
    E := legendre (gen' x.1)
    isElliptic := legendre_gen'_isElliptic x }

end Iut.Tripod

end


section

namespace Iut.Tripod

open WeierstrassCurve NumberField Polynomial

open scoped IntermediateField

section Curve

variable (x : Pt) (h3 : TorsionFinite x.1 3) (h5 : TorsionFinite x.1 5)

/-- `λ` as an element of the field `F_λ = (curveOf x h3 h5).F` of the curve. -/
noncomputable abbrev genC : (curveOf x h3 h5).F := gen' x.1

/-- `j(E_λ) ∈ ℚ(λ)`. -/
theorem j_mem_adjoin : (curveOf x h3 h5).E.j ∈ ℚ⟮genC x h3 h5⟯ := by
  have hg : genC x h3 h5 ∈ ℚ⟮genC x h3 h5⟯ := IntermediateField.mem_adjoin_simple_self ℚ _
  have h256 : (256 : (curveOf x h3 h5).F) ∈ ℚ⟮genC x h3 h5⟯ := by
    have : (256 : (curveOf x h3 h5).F) = ((256 : ℕ) : (curveOf x h3 h5).F) := by norm_num
    rw [this]
    exact IntermediateField.natCast_mem _ _
  haveI : (legendre (genC x h3 h5)).IsElliptic := (curveOf x h3 h5).isElliptic
  have hj : (curveOf x h3 h5).E.j = 256 * (genC x h3 h5 ^ 2 - genC x h3 h5 + 1) ^ 3 /
      (genC x h3 h5 ^ 2 * (genC x h3 h5 - 1) ^ 2) := legendre_j (l := genC x h3 h5)
  rw [hj]
  exact div_mem (mul_mem h256 (pow_mem (add_mem (sub_mem (pow_mem hg 2) hg) (one_mem _)) 3))
    (mul_mem (pow_mem hg 2) (pow_mem (sub_mem hg (one_mem _)) 2))

/-- The embedding `F_λ → ℚ̄` as a `ℚ`-algebra homomorphism (for the `ℚ`-algebra structure
of `F_λ` as a number field). -/
noncomputable def embC : (curveOf x h3 h5).F →ₐ[ℚ] Qbar :=
  RingHom.toRatAlgHom ((fieldOf' x.1).val.toRingHom : (curveOf x h3 h5).F →+* Qbar)

@[simp] theorem embC_apply (a : (curveOf x h3 h5).F) :
    embC x h3 h5 a = (fieldOf' x.1).val a := rfl

/-- `ℚ(λ) ⊆ F_λ` is isomorphic to `ℚ(λ) ⊆ ℚ̄`. -/
noncomputable def adjoinGenCEquiv : ℚ⟮genC x h3 h5⟯ ≃ₐ[ℚ] fieldOf x.1 :=
  (IntermediateField.equivMap ℚ⟮genC x h3 h5⟯ (embC x h3 h5)).trans
    (IntermediateField.equivOfEq (by
      rw [IntermediateField.adjoin_map, Set.image_singleton, embC_apply]
      rfl))

open scoped Classical in
/-- The `x`-coordinates of the `F_λ`-rational `2`-torsion points of `E_λ` are `0`, `1`,
`λ`. -/
theorem twoTorsionXOf_eq :
    twoTorsionXOf (curveOf x h3 h5).F (curveOf x h3 h5).E = {0, 1, genC x h3 h5} := by
  haveI : (legendre (genC x h3 h5)).IsElliptic := (curveOf x h3 h5).isElliptic
  ext a
  simp only [twoTorsionXOf, Set.mem_setOf_eq, Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · rintro ⟨b, h, hP⟩
    rw [AddSubgroup.torsionBy, Submodule.mem_toAddSubgroup, Submodule.mem_torsionBy_iff] at hP
    have hP' : (2 : ℕ) • Affine.Point.some a b h = 0 := by rw [← natCast_zsmul]; exact hP
    have hb : b = 0 := (two_nsmul_some_eq_zero_iff (genC x h3 h5) h).mp hP'
    subst hb
    exact legendre_equation_y_zero _ ((Affine.nonsingular_iff _ _).mp h).1
  · intro ha
    have hE : (curveOf x h3 h5).E.toAffine.Equation a 0 := by
      rcases ha with rfl | rfl | rfl
      · exact legendre_equation_zero (genC x h3 h5)
      · exact legendre_equation_one (genC x h3 h5)
      · exact legendre_equation_self (genC x h3 h5)
    refine ⟨0, Affine.equation_iff_nonsingular.mp hE, ?_⟩
    rw [AddSubgroup.torsionBy, Submodule.mem_toAddSubgroup, Submodule.mem_torsionBy_iff]
    have := two_nsmul_some_zero (genC x h3 h5) (Affine.equation_iff_nonsingular.mp hE)
    rwa [← natCast_zsmul] at this

/-- **The tripodal field of `E_λ` is `ℚ(λ)`**: `F_tpd = ℚ(j, 0, 1, λ) = ℚ(λ)`. -/
theorem tripodalFieldOf_eq :
    tripodalFieldOf (curveOf x h3 h5).F (curveOf x h3 h5).E = ℚ⟮genC x h3 h5⟯ := by
  rw [tripodalFieldOf, twoTorsionXOf_eq]
  apply le_antisymm
  · rw [IntermediateField.adjoin_le_iff, Set.insert_subset_iff]
    refine ⟨j_mem_adjoin x h3 h5, ?_⟩
    rintro a (rfl | rfl | rfl)
    · exact zero_mem _
    · exact one_mem _
    · exact IntermediateField.mem_adjoin_simple_self ℚ _
  · rw [IntermediateField.adjoin_simple_le_iff]
    exact IntermediateField.subset_adjoin _ _ (Set.mem_insert_of_mem _ (by simp))

end Curve

/-- **The providers of the curve data**: the finiteness of the `3`- and `5`-torsion of
`E_λ(ℚ̄)` for every `λ`, the arithmetic `EllipticCurveData.CurveArithmetic` of `E_λ/F_λ`
(IUT IV, Proposition 1.8: everywhere stable reduction, `F_λ/F_mod` Galois of degree prime
to `ℓ ≥ 7`, …; its fields `sqrt_neg_one` and `six_torsion_rational` are proved above and
the five general fields in `Iut.EllipticCurveData.CurveArithmetic.ofCore`), and the
mod-`ℓ` representations (`Iut.EllipticCurveData.modEllRepData` from a basis of
`E_λ[ℓ]`). -/
structure CurveProviders where
  /-- The `3`-torsion of `E_λ(ℚ̄)` is finite. -/
  torsionFinite3 : ∀ l : Qbar, TorsionFinite l 3
  /-- The `5`-torsion of `E_λ(ℚ̄)` is finite. -/
  torsionFinite5 : ∀ l : Qbar, TorsionFinite l 5
  /-- The arithmetic of `E_λ/F_λ`. -/
  arith : ∀ x : Pt, (curveOf x (torsionFinite3 x.1) (torsionFinite5 x.1)).CurveArithmetic
  /-- The mod-`ℓ` representations of `E_λ`. -/
  modRep : ∀ (x : Pt) (ℓ : ℕ), ℓ.Prime →
    (curveOf x (torsionFinite3 x.1) (torsionFinite5 x.1)).ModEllRepData ℓ

namespace CurveProviders

variable (P : CurveProviders)

/-- The curve `E_λ/F_λ` of a point. -/
noncomputable def curve (x : Pt) : EllipticCurveData :=
  curveOf x (P.torsionFinite3 x.1) (P.torsionFinite5 x.1)

/-- The Tate inputs of `E_λ` (`Iut.EllipticCurveData.tateInputs`). -/
noncomputable def tate (x : Pt) : (P.curve x).TateInputs := (P.curve x).tateInputs

/-- The local height data of `E_λ`. -/
noncomputable def localData (x : Pt) : LocalHeightData :=
  (P.curve x).localHeightData (P.arith x) (P.tate x)

/-- The height `h(λ) = log(q_∀(E_λ))`. -/
noncomputable def h (x : Pt) : ℝ := (P.localData x).height

end CurveProviders

end Iut.Tripod

end


section

namespace Iut

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum WithZero

open scoped WithZero

section MapEquiv

variable {k k' : Type*} [Field k] [NumberField k] [Field k'] [NumberField k']

/-- **The bijection of finite places along an isomorphism** `e : k ≃+* k'` of number fields:
the place of the prime `(e⁻¹)⁻¹(𝔭_v) = e(𝔭_v)` of `𝓞 k'`. -/
noncomputable def FinitePlace.mapEquiv (e : k ≃+* k') : FinitePlace k ≃ FinitePlace k' :=
  FinitePlace.equivHeightOneSpectrum.trans
    ((HeightOneSpectrum.equivOfRingEquiv (RingOfIntegers.mapRingEquiv e)).trans
      FinitePlace.equivHeightOneSpectrum.symm)

variable (e : k ≃+* k') (v : FinitePlace k)

lemma FinitePlace.mapEquiv_maximalIdeal :
    (FinitePlace.mapEquiv e v).maximalIdeal.asIdeal =
      v.maximalIdeal.asIdeal.comap ((RingOfIntegers.mapRingEquiv e).symm : 𝓞 k' →+* 𝓞 k) := by
  simp only [FinitePlace.mapEquiv, Equiv.trans_apply, FinitePlace.equivHeightOneSpectrum_apply,
    HeightOneSpectrum.equivOfRingEquiv_apply]
  exact congrArg HeightOneSpectrum.asIdeal (FinitePlace.maximalIdeal_mk _)

/-- The valuation of the transported place is the valuation of `e⁻¹`. -/
lemma FinitePlace.mapEquiv_valuation (x : k') :
    (FinitePlace.mapEquiv e v).maximalIdeal.valuation k' x =
      v.maximalIdeal.valuation k (e.symm x) :=
  valuation_of_comap ((RingOfIntegers.mapRingEquiv e).symm : 𝓞 k' →+* 𝓞 k)
    (RingOfIntegers.mapRingEquiv e).symm.bijective (FinitePlace.mapEquiv_maximalIdeal e v)
    (e.symm : k' →+* k) (fun _ => rfl) x

/-- The absolute norm of the prime of the transported place. -/
lemma FinitePlace.mapEquiv_absNorm :
    Ideal.absNorm (FinitePlace.mapEquiv e v).maximalIdeal.asIdeal =
      Ideal.absNorm v.maximalIdeal.asIdeal := by
  rw [Ideal.absNorm_apply, Ideal.absNorm_apply, Submodule.cardQuot_apply, Submodule.cardQuot_apply]
  have hIJ : v.maximalIdeal.asIdeal =
      (FinitePlace.mapEquiv e v).maximalIdeal.asIdeal.map
        ((RingOfIntegers.mapRingEquiv e).symm : 𝓞 k' →+* 𝓞 k) := by
    rw [FinitePlace.mapEquiv_maximalIdeal,
      Ideal.map_comap_of_surjective (f := ((RingOfIntegers.mapRingEquiv e).symm : 𝓞 k' →+* 𝓞 k))
        (RingOfIntegers.mapRingEquiv e).symm.surjective]
  exact Nat.card_congr (Ideal.quotientEquiv _ _ (RingOfIntegers.mapRingEquiv e).symm hIJ).toEquiv

/-- The absolute value of the transported place is the absolute value of `e⁻¹`. -/
lemma FinitePlace.mapEquiv_apply (x : k') :
    FinitePlace.mapEquiv e v x = v (e.symm x) := by
  rw [← FinitePlace.norm_embedding_eq, ← FinitePlace.norm_embedding_eq,
    FinitePlace.norm_embedding', FinitePlace.norm_embedding', FinitePlace.mapEquiv_valuation]
  congr 1
  refine toNNReal_congr ?_ _ _ _
  exact_mod_cast FinitePlace.mapEquiv_absNorm e v

end MapEquiv

namespace EllipticCurveData

open TateCurvesTheta

variable (C : EllipticCurveData) {w : FinitePlace C.F}

/-- **`v_w(j(E)) = exp(ord_w(q_w))`** at a multiplicative place: `‖j‖ = ‖q‖⁻¹` for the Tate
curve, and `j(E_{q_w}) = j(E)`. -/
lemma valuation_j_eq_exp_qOrder (hw : w ∈ C.badAll) :
    w.maximalIdeal.valuation C.F C.E.j = exp ((C.tateInputs.qOrder w hw : ℕ) : ℤ) := by
  have hq : Valued.v ((C.tateInputs.tate w hw).q : localCompletion w) =
      exp (-((C.tateInputs.qOrder w hw : ℕ) : ℤ)) :=
    valued_tateParameter_q _ (C.tateInputs.unif_isUniformizer w hw)
  have hJ : (C.tateInputs.tate w hw).tateJ = FinitePlace.embedding w.maximalIdeal C.E.j :=
    C.tateInputs.tateJ_eq w hw
  have hnorm : ‖(C.tateInputs.tate w hw).tateJ‖ =
      ‖((C.tateInputs.tate w hw).q : localCompletion w)‖⁻¹ :=
    (C.tateInputs.tate w hw).norm_tateJ (twelve_ne_zero w)
  have hq0 : ((C.tateInputs.tate w hw).q : localCompletion w) ≠ 0 :=
    (C.tateInputs.tate w hw).q.ne_zero
  have h1 : ‖(C.tateInputs.tate w hw).tateJ * ((C.tateInputs.tate w hw).q : localCompletion w)‖
      = 1 := by
    rw [norm_mul, hnorm, inv_mul_cancel₀ (norm_ne_zero_iff.mpr hq0)]
  rw [norm_eq_one_iff_valued, map_mul, hJ, hq, FinitePlace.embedding_apply,
    valuedAdicCompletion_eq_valuation', exp_neg] at h1
  rw [eq_inv_of_mul_eq_one_left h1, inv_inv]

end EllipticCurveData

end Iut

namespace Iut.Tripod

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum WithZero WeierstrassCurve

open scoped WithZero

variable (P : CurveProviders) (x : Pt)

/-- The tripodal field `F_tpd = ℚ(j, x(E_λ[2])) = ℚ(λ)` of the curve of `x`, as an intermediate
field of `F_λ`. -/
noncomputable abbrev tpd : IntermediateField ℚ (P.curve x).F :=
  tripodalFieldOf (P.curve x).F (P.curve x).E

/-- `λ` as an element of `F_λ = (P.curve x).F`. -/
noncomputable abbrev genC' : (P.curve x).F := genC x (P.torsionFinite3 x.1) (P.torsionFinite5 x.1)

/-- The curve of `x` is the Legendre curve of `λ`. -/
theorem curve_E_eq : (P.curve x).E = legendre (genC' P x) := rfl

instance : (legendre (genC' P x)).IsElliptic := (P.curve x).isElliptic

/-- `λ ∈ F_tpd`. -/
theorem genC_mem_tpd : genC' P x ∈ tpd P x := by
  change _ ∈ tripodalFieldOf (curveOf x _ _).F (curveOf x _ _).E
  rw [tripodalFieldOf_eq]
  exact IntermediateField.mem_adjoin_simple_self ℚ _

/-- `λ` as an element of `F_tpd`. -/
noncomputable def genT : tpd P x := ⟨_, genC_mem_tpd P x⟩

@[simp] theorem coe_genT : (genT P x : (P.curve x).F) = genC' P x := rfl

theorem algebraMap_genT : algebraMap (tpd P x) (P.curve x).F (genT P x) = genC' P x := rfl

/-- **`F_tpd ≃ ℚ(λ)`**: the tripodal field of `E_λ` inside `F_λ` is isomorphic to the minimal
field of definition `ℚ(λ) ⊆ ℚ̄` of `λ`. -/
noncomputable def tpdEquiv : tpd P x ≃ₐ[ℚ] fieldOf x.1 :=
  (IntermediateField.equivOfEq (tripodalFieldOf_eq x (P.torsionFinite3 x.1)
    (P.torsionFinite5 x.1))).trans (adjoinGenCEquiv x _ _)

theorem tpdEquiv_genT : tpdEquiv P x (genT P x) = gen x.1 := by
  apply Subtype.ext
  rfl

/-- `[F_tpd : ℚ] = deg λ`. -/
theorem finrank_tpd : Module.finrank ℚ (tpd P x) = deg x.1 := by
  rw [(tpdEquiv P x).toLinearEquiv.finrank_eq, deg_eq_finrank]

/-- `log|y|_𝔭 = log v_𝔭(y) · f_𝔭 · log p`. -/
theorem log_apply_eq {T : Type*} [Field T] [NumberField T] (𝔭 : FinitePlace T) {y : T}
    (hy : y ≠ 0) :
    Real.log (𝔭 y) = ((log (𝔭.maximalIdeal.valuation T y) : ℤ) : ℝ) *
      (inertDeg T 𝔭 * Real.log (residueChar 𝔭)) := by
  have hv : 𝔭.maximalIdeal.valuation T y ≠ 0 := (Valuation.ne_zero_iff _).mpr hy
  rw [← FinitePlace.norm_embedding_eq,
    norm_eq_zpow_of_valued 𝔭 _ (log (𝔭.maximalIdeal.valuation T y)) (by
      rw [FinitePlace.embedding_apply, valuedAdicCompletion_eq_valuation', exp_log hv]),
    Real.log_zpow, Real.log_pow]

end Iut.Tripod

end


section

namespace Iut

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum WithZero

open scoped WithZero Real

section FinHeight

variable {T : Type*} [Field T] [NumberField T]

/-- **The finite part of the logarithmic height**: `h_fin(y) = ∑_{v finite} log⁺|y|_v`. -/
noncomputable def finHeight (y : T) : ℝ := ∑ᶠ v : FinitePlace T, log⁺ (v y)

/-- The support of `v ↦ log⁺|y|_v` is contained in the multiplicative support of
`v ↦ |y|_v`. -/
lemma support_posLog_subset (y : T) :
    Function.support (fun v : FinitePlace T => log⁺ (v y)) ⊆
      Function.mulSupport (fun v : FinitePlace T => v y) := by
  intro v hv
  simp only [Function.mem_support, Function.mem_mulSupport] at hv ⊢
  intro h
  apply hv
  rw [h, Real.posLog_one]

/-- `v ↦ log⁺|y|_v` has finite support. -/
lemma hasFiniteSupport_posLog (y : T) :
    Function.HasFiniteSupport (fun v : FinitePlace T => log⁺ (v y)) := by
  by_cases hy : y = 0
  · subst hy
    refine Set.Finite.subset Set.finite_empty ?_
    intro v hv
    simp at hv
  · exact Set.Finite.subset (FinitePlace.hasFiniteMulSupport hy) (support_posLog_subset y)

/-- `h_fin(y)` as a sum over any finite set containing the support. -/
lemma finHeight_eq_sum {y : T} {S : Finset (FinitePlace T)}
    (hS : ∀ v : FinitePlace T, log⁺ (v y) ≠ 0 → v ∈ S) :
    finHeight y = ∑ v ∈ S, log⁺ (v y) :=
  finsum_eq_sum_of_support_subset _ fun v hv => hS v hv

/-- The finite part of the height is invariant under isomorphisms of number fields. -/
lemma finHeight_mapEquiv {T' : Type*} [Field T'] [NumberField T'] (e : T ≃+* T') (y : T) :
    finHeight (e y) = finHeight y := by
  unfold finHeight
  rw [← finsum_comp_equiv (FinitePlace.mapEquiv e)]
  refine finsum_congr fun v => ?_
  rw [FinitePlace.mapEquiv_apply, RingEquiv.symm_apply_apply]

/-- The weight `f_w · log p_w` of a finite place: `|y|_w = p_w^{f_w · m}` for `v_w(y) = exp m`. -/
noncomputable def finWeight (w : FinitePlace T) : ℝ := inertDeg T w * Real.log (residueChar w)

lemma finWeight_pos (w : FinitePlace T) : 0 < finWeight w :=
  mul_pos (by exact_mod_cast inertDeg_pos' w)
    (Real.log_pos (by exact_mod_cast (residueChar_prime w).one_lt))

/-- `log⁺|y|_w = f_w log p_w · max(0, log v_w(y))`. -/
lemma posLog_apply_eq (w : FinitePlace T) {y : T} (hy : y ≠ 0) :
    log⁺ (w y) = finWeight w * max 0 ((log (w.maximalIdeal.valuation T y) : ℤ) : ℝ) := by
  rw [Real.posLog_apply, Iut.Tripod.log_apply_eq w hy, mul_max_of_nonneg _ _ (finWeight_pos w).le,
    mul_zero, mul_comm]
  rfl

end FinHeight

section Extension

variable {k K : Type*} [Field k] [NumberField k] [Field K] [NumberField K] [Algebra k K]

/-- The place below is unique. -/
lemma placeUnder_eq_of_liesOver_place {w : FinitePlace K} {v : FinitePlace k}
    (hwv : FinitePlace.LiesOver w v) : placeUnder w = v := by
  symm
  apply (FinitePlace.maximalIdeal_inj _ _).mp
  apply IsDedekindDomain.HeightOneSpectrum.ext
  rw [placeUnder_maximalIdeal]
  exact hwv.over

/-- The local degree `e(w/v) f(w/v)` of `w` over `v`. -/
noncomputable abbrev relLocalDeg (w : FinitePlace K) (v : FinitePlace k) : ℕ :=
  relRamIdx w v * relInertDeg w v

lemma relLocalDeg_ne_zero {w : FinitePlace K} {v : FinitePlace k}
    (hwv : FinitePlace.LiesOver w v) : relLocalDeg w v ≠ 0 := by
  have h := inertDeg_eq_mul hwv
  have hpos := inertDeg_pos' w
  refine mul_ne_zero (relRamIdx_ne_zero hwv) fun h0 => ?_
  rw [h, h0, mul_zero] at hpos
  exact lt_irrefl _ hpos

/-- **`|y|_w = |y|_v^{e(w/v) f(w/v)}`** for `y ∈ k` and `w ∣ v`. -/
lemma apply_algebraMap_eq_pow {w : FinitePlace K} {v : FinitePlace k}
    (hwv : FinitePlace.LiesOver w v) (y : k) :
    w (algebraMap k K y) = v y ^ relLocalDeg w v := by
  by_cases hy : y = 0
  · subst hy
    rw [map_zero, map_zero, map_zero, zero_pow (relLocalDeg_ne_zero hwv)]
  have hy' : algebraMap k K y ≠ 0 := (map_ne_zero _).mpr hy
  have hpos : 0 < w (algebraMap k K y) := FinitePlace.pos_iff.mpr hy'
  have hpos' : 0 < v y := FinitePlace.pos_iff.mpr hy
  have hlog : Real.log (w (algebraMap k K y)) = relLocalDeg w v * Real.log (v y) := by
    rw [Iut.Tripod.log_apply_eq w hy', Iut.Tripod.log_apply_eq v hy,
      valuation_algebraMap_eq_pow hwv, log_pow, inertDeg_eq_mul hwv,
      residueChar_eq_of_liesOver hwv]
    simp only [nsmul_eq_mul]
    push_cast
    ring
  rw [← Real.exp_log hpos, hlog, ← Real.log_pow, Real.exp_log (pow_pos hpos' _)]

/-- `log⁺|y|_w = e(w/v) f(w/v) · log⁺|y|_v` for `y ∈ k` and `w ∣ v`. -/
lemma posLog_apply_algebraMap_eq {w : FinitePlace K} {v : FinitePlace k}
    (hwv : FinitePlace.LiesOver w v) (y : k) :
    log⁺ (w (algebraMap k K y)) = relLocalDeg w v * log⁺ (v y) := by
  rw [apply_algebraMap_eq_pow hwv, Real.posLog_pow]

/-- `∑_{w ∣ v} e(w/v) f(w/v) = [K : k]`. -/
lemma sum_relLocalDeg_liesOver (v : FinitePlace k) (s : Finset (FinitePlace K))
    (hs : ∀ w, w ∈ s ↔ FinitePlace.LiesOver w v) :
    ∑ w ∈ s, relLocalDeg w v = Module.finrank k K := by
  have h := sum_localDeg_liesOver v s hs
  have h' : ∑ w ∈ s, localDeg K w = localDeg k v * ∑ w ∈ s, relLocalDeg w v := by
    rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun w hw => localDeg_eq_mul ((hs w).mp hw)
  have hpos : 0 < localDeg k v := Nat.mul_pos (ramIdx_pos' v) (inertDeg_pos' v)
  rw [h', mul_comm (Module.finrank k K)] at h
  exact Nat.eq_of_mul_eq_mul_left hpos h

/-- **The finite part of the height is invariant under finite extensions**:
`h_fin^K(y) = [K : k] · h_fin^k(y)` for `y ∈ k`. -/
theorem finHeight_algebraMap (y : k) :
    finHeight (algebraMap k K y) = Module.finrank k K * finHeight y := by
  classical
  set Sk := (hasFiniteSupport_posLog y).toFinset with hSk
  set SK := (hasFiniteSupport_posLog (algebraMap k K y)).toFinset with hSK
  have hmemk : ∀ v, v ∈ Sk ↔ log⁺ (v y) ≠ 0 := fun v => by
    have hs : (Function.support (fun v : FinitePlace k => log⁺ (v y))).Finite :=
      hasFiniteSupport_posLog y
    exact Set.Finite.mem_toFinset hs
  have hmemK : ∀ w, w ∈ SK ↔ log⁺ (w (algebraMap k K y)) ≠ 0 := fun w => by
    have hs : (Function.support
        (fun w : FinitePlace K => log⁺ (w (algebraMap k K y)))).Finite :=
      hasFiniteSupport_posLog (algebraMap k K y)
    exact Set.Finite.mem_toFinset hs
  have hfib : ∀ w : FinitePlace K,
      log⁺ (w (algebraMap k K y)) = relLocalDeg w (placeUnder w) * log⁺ (placeUnder w y) :=
    fun w => posLog_apply_algebraMap_eq (liesOver_placeUnder w) y
  have hmaps : ∀ w ∈ SK, placeUnder w ∈ Sk := by
    intro w hw
    rw [hmemK, hfib] at hw
    rw [hmemk]
    exact (mul_ne_zero_iff.mp hw).2
  rw [finHeight_eq_sum fun w hw => (hmemK w).mpr hw, finHeight_eq_sum fun v hv => (hmemk v).mpr hv,
    ← Finset.sum_fiberwise_of_maps_to hmaps, Finset.mul_sum]
  refine Finset.sum_congr rfl fun v hv => ?_
  have hs : ∀ w, w ∈ SK.filter (fun w => placeUnder w = v) ↔ FinitePlace.LiesOver w v := by
    intro w
    rw [Finset.mem_filter, hmemK]
    constructor
    · rintro ⟨-, rfl⟩
      exact liesOver_placeUnder w
    · intro hwv
      have hv' := placeUnder_eq_of_liesOver_place hwv
      refine ⟨?_, hv'⟩
      rw [hfib, hv']
      exact mul_ne_zero (by exact_mod_cast relLocalDeg_ne_zero hwv) ((hmemk v).mp hv)
  calc ∑ w ∈ SK.filter (fun w => placeUnder w = v), log⁺ (w (algebraMap k K y))
      = ∑ w ∈ SK.filter (fun w => placeUnder w = v), (relLocalDeg w v : ℝ) * log⁺ (v y) := by
        refine Finset.sum_congr rfl fun w hw => ?_
        rw [posLog_apply_algebraMap_eq ((hs w).mp hw)]
    _ = (Module.finrank k K : ℝ) * log⁺ (v y) := by
        rw [← Finset.sum_mul, ← Nat.cast_sum, sum_relLocalDeg_liesOver v _ hs]

end Extension

section LegendreJ

/-- `j(λ) = 256(λ² − λ + 1)³/(λ²(λ − 1)²)`, as an explicit expression. -/
noncomputable def legendreJ {R : Type*} [Field R] (l : R) : R :=
  256 * (l ^ 2 - l + 1) ^ 3 / (l ^ 2 * (l - 1) ^ 2)

lemma map_legendreJ {R S F : Type*} [Field R] [Field S] [FunLike F R S] [RingHomClass F R S]
    (f : F) (l : R) : f (legendreJ l) = legendreJ (f l) := by
  simp only [legendreJ, map_div₀, map_mul, map_pow, map_sub, map_add, map_one, map_ofNat]

open WeierstrassCurve Iut.Tripod in
/-- `j(E_λ) = legendreJ λ`. -/
lemma legendre_j_eq_legendreJ {R : Type*} [Field R] [NeZero (2 : R)] {l : R}
    [(legendre l).IsElliptic] : (legendre l).j = legendreJ l :=
  legendre_j

end LegendreJ

end Iut

namespace Iut.Tripod

open NumberField IsDedekindDomain IsDedekindDomain.HeightOneSpectrum WithZero WeierstrassCurve

open scoped WithZero Real

variable (P : CurveProviders) (x : Pt)

/-- `j(E_λ)` as an element of `F_tpd`. -/
noncomputable abbrev jT : tpd P x := legendreJ (genT P x)

/-- `j(E_λ) = legendreJ λ` in `F_λ`. -/
theorem curve_j_eq_legendreJ : (P.curve x).E.j = legendreJ (genC' P x) := by
  change (legendre (genC' P x)).j = _
  exact legendre_j_eq_legendreJ

/-- `j(E_λ)` comes from `F_tpd`. -/
theorem curve_j_eq_algebraMap :
    (P.curve x).E.j = algebraMap (tpd P x) (P.curve x).F (jT P x) := by
  rw [curve_j_eq_legendreJ, jT, map_legendreJ, algebraMap_genT]

/-- `F_tpd ≅ ℚ(λ)` maps `j` to `legendreJ λ`. -/
theorem tpdEquiv_jT : tpdEquiv P x (jT P x) = legendreJ (gen x.1) := by
  rw [jT, map_legendreJ, tpdEquiv_genT]

/-- **At a multiplicative place, `log⁺|j|_w = ord_w(q_w) f_w log p_w`.** -/
theorem posLog_j_eq_of_mem_badAll {w : FinitePlace (P.curve x).F} (hw : w ∈ (P.curve x).badAll) :
    log⁺ (w (P.curve x).E.j) =
      ((P.tate x).qOrder w hw : ℝ) * inertDeg (P.curve x).F w * Real.log (residueChar w) := by
  have hvj : w.maximalIdeal.valuation _ (P.curve x).E.j = exp (((P.tate x).qOrder w hw : ℕ) : ℤ) :=
    (P.curve x).valuation_j_eq_exp_qOrder hw
  have hj0 : (P.curve x).E.j ≠ 0 := by
    intro h
    rw [h, map_zero] at hvj
    exact exp_ne_zero hvj.symm
  rw [posLog_apply_eq w hj0, hvj, log_exp, finWeight, max_eq_right (by positivity)]
  push_cast
  ring

/-- **At a place of good reduction, `log⁺|j|_w = 0`** (stable reduction). -/
theorem posLog_j_eq_zero_of_not_mem_badAll {w : FinitePlace (P.curve x).F}
    (hw : w ∉ (P.curve x).badAll) : log⁺ (w (P.curve x).E.j) = 0 := by
  have hst := (P.arith x).stable_reduction w
  have hle : w.maximalIdeal.valuation _ (P.curve x).E.j ≤ 1 := by
    by_contra h
    exact hw ((hasMultiplicativeReductionAt_iff_of_stable (P.curve x).E w hst).mpr h)
  rw [Real.posLog_eq_zero_iff, abs_of_nonneg (apply_nonneg _ _), ← FinitePlace.norm_embedding_eq]
  exact (norm_emb_le_one_iff _).mpr hle

/-- **`[F_λ : ℚ]·log(q_∀(E_λ)) = h_fin^{F_λ}(j)`.** -/
theorem finrank_mul_h_eq_finHeight :
    (Module.finrank ℚ (P.curve x).F : ℝ) * P.h x = finHeight (P.curve x).E.j := by
  classical
  have h := (P.localData x).deg_mul_height
  change ((P.localData x).deg : ℝ) * (P.localData x).height = _
  rw [h]
  have hmem : ∀ w, w ∈ (P.localData x).bad ↔ w ∈ (P.curve x).badAll := fun w =>
    (P.arith x).badAll_finite.mem_toFinset
  have hhv : ∀ w, (P.localData x).hv w =
      if h : w ∈ (P.curve x).badAll then (P.tate x).qOrder w h else 0 := fun w => rfl
  have hf : ∀ w, (P.localData x).f w = inertDeg (P.curve x).F w := fun w => rfl
  have hp : ∀ w, (P.localData x).p w = residueChar w := fun w => rfl
  rw [finHeight_eq_sum (S := (P.localData x).bad) (fun w hw => ?_)]
  · refine Finset.sum_congr rfl fun w hw => ?_
    rw [hmem] at hw
    rw [hhv, hf, hp, dif_pos hw, posLog_j_eq_of_mem_badAll P x hw]
  · refine (hmem w).mpr ?_
    by_contra h'
    exact hw (posLog_j_eq_zero_of_not_mem_badAll P x h')

/-- **`log(q_∀(E_λ)) = h_fin(j)/[ℚ(λ) : ℚ]`**, with `h_fin` computed in `ℚ(λ)`. -/
theorem h_eq_finHeight_div : P.h x = finHeight (legendreJ (gen x.1)) / deg x.1 := by
  have h1 := finrank_mul_h_eq_finHeight P x
  haveI : Module.Finite (tpd P x) (P.curve x).F := Module.Finite.right ℚ (tpd P x) (P.curve x).F
  have hT : finHeight (jT P x) = finHeight (legendreJ (gen x.1)) := by
    rw [← tpdEquiv_jT]
    exact (finHeight_mapEquiv (tpdEquiv P x : tpd P x ≃+* fieldOf x.1) (jT P x)).symm
  rw [curve_j_eq_algebraMap, finHeight_algebraMap, hT] at h1
  have h2 : (Module.finrank ℚ (P.curve x).F : ℝ) =
      deg x.1 * Module.finrank (tpd P x) (P.curve x).F := by
    rw [← finrank_tpd P x]
    exact_mod_cast (Module.finrank_mul_finrank ℚ (tpd P x) (P.curve x).F).symm
  have h3 : (Module.finrank (tpd P x) (P.curve x).F : ℝ) ≠ 0 := by
    intro h0
    have hpos : (0 : ℝ) < Module.finrank ℚ (P.curve x).F := by
      exact_mod_cast Module.finrank_pos
    rw [h2, h0, mul_zero] at hpos
    exact lt_irrefl _ hpos
  rw [h2] at h1
  rw [eq_div_iff (deg_pos_real x.1).ne']
  apply mul_left_cancel₀ h3
  calc (Module.finrank (tpd P x) (P.curve x).F : ℝ) * (P.h x * deg x.1)
      = deg x.1 * Module.finrank (tpd P x) (P.curve x).F * P.h x := by ring
    _ = _ := h1

end Iut.Tripod

end
