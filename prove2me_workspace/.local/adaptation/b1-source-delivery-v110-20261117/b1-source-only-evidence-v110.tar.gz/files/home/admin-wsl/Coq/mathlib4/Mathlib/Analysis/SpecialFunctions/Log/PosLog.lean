/-
Copyright (c) 2025 Stefan Kebekus. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Stefan Kebekus
-/
module

public import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-!
# The Positive Part of the Logarithm

This file defines the function `Real.posLog = r ↦ max 0 (log r)` and introduces the notation
`log⁺`. For a finite length-`n` sequence `f i` of reals, it establishes the following standard
estimates.

- `theorem posLog_prod : log⁺ (∏ i, f i) ≤ ∑ i, log⁺ (f i)`

- `theorem posLog_sum : log⁺ (∑ i, f i) ≤ log n + ∑ i, log⁺ (f i)`

See `Mathlib/Analysis/SpecialFunctions/Integrals/PosLogEqCircleAverage.lean` for the presentation of
`log⁺` as a Circle Average.
-/

@[expose] public section

namespace Real

variable {x y : ℝ}

/-!
## Definition, Notation and Reformulations
-/

/-- Definition: the positive part of the logarithm. -/
noncomputable def posLog : ℝ → ℝ := fun r ↦ max 0 (log r)

/-- Notation `log⁺` for the positive part of the logarithm. -/
scoped notation "log⁺" => posLog

/-- Definition of the positive part of the logarithm, formulated as a theorem. -/
theorem posLog_apply : log⁺ x = max 0 (log x) := rfl

/-- Definition of the positive part of the logarithm, formulated as a theorem. -/
theorem posLog_def : log⁺ = max 0 (log ·) := rfl

/-!
## Elementary Properties
-/

/-- Presentation of `log` in terms of its positive part. -/
theorem posLog_sub_posLog_inv : log⁺ x - log⁺ x⁻¹ = log x := by
  rw [posLog_apply, posLog_apply, log_inv]
  by_cases! h : 0 ≤ log x
  · simp [h]
  · simp [neg_nonneg.1 (Left.nonneg_neg_iff.2 h.le)]

/-- Presentation of `log⁺` in terms of `log`. -/
theorem half_mul_log_add_log_abs : 2⁻¹ * (log x + |log x|) = log⁺ x := by
  by_cases! hr : 0 ≤ log x
  · simp [posLog, hr, abs_of_nonneg]
    ring
  · simp [posLog, hr.le, abs_of_nonpos]

@[simp] lemma posLog_zero : log⁺ 0 = 0 := by simp [posLog]

@[simp] lemma posLog_one : log⁺ 1 = 0 := by simp [posLog]

/-- The positive part of `log` is never negative. -/
theorem posLog_nonneg : 0 ≤ log⁺ x := by simp [posLog]

/-- The function `log⁺` is even. -/
@[simp] theorem posLog_neg (x : ℝ) : log⁺ (-x) = log⁺ x := by simp [posLog]

/-- The function `log⁺` is even. -/
@[simp] theorem posLog_abs (x : ℝ) : log⁺ |x| = log⁺ x := by simp [posLog]

/-- The function `log⁺` is zero in the interval [-1,1]. -/
theorem posLog_eq_zero_iff (x : ℝ) : log⁺ x = 0 ↔ |x| ≤ 1 := by
  rw [← posLog_abs, ← log_nonpos_iff (abs_nonneg x)]
  simp [posLog]

/-- The function `log⁺` equals `log` outside of the interval (-1,1). -/
theorem posLog_eq_log (hx : 1 ≤ |x|) : log⁺ x = log x := by
  simp only [posLog, sup_eq_right]
  rw [← log_abs]
  apply log_nonneg hx

/-- The function `log⁺` is monotone on the interval [-1,∞). -/
theorem monotoneOn_posLog : MonotoneOn log⁺ (Set.Ici (-1)) := by
  intro x hx y _ hxy
  grind [posLog_eq_zero_iff, posLog_nonneg, posLog_eq_log, log_le_log]

/-- The function `log⁺` is antitone on the interval (-∞,1]. -/
theorem antitoneOn_posLog : AntitoneOn log⁺ (Set.Iic 1) := by
  intro x hx y hy hxy
  rw [← posLog_neg x, ← posLog_neg y]
  exact monotoneOn_posLog (by grind) (by grind) (neg_le_neg hxy)

/-- The function `log⁺` equals `log` for all natural numbers. -/
theorem log_of_nat_eq_posLog {n : ℕ} : log⁺ n = log n := by
  by_cases hn : n = 0
  · simp [hn, posLog]
  · simp [posLog_eq_log, Nat.one_le_iff_ne_zero.2 hn]

/-- Presentation of `|log|` in terms of the positive part of the logarithm. -/
theorem abs_log_eq_posLog_add_posLog_inv (x : ℝ) : |log x| = log⁺ x + log⁺ x⁻¹ := by
  grind [half_mul_log_add_log_abs (x := x), log_inv x ▸ half_mul_log_add_log_abs (x := x⁻¹)]

/-- The function `log⁺` equals `log (max 1 _)` for non-negative real numbers. -/
theorem posLog_eq_log_max_one (hx : 0 ≤ x) : log⁺ x = log (max 1 x) := by
  grind [le_abs, posLog_eq_log, log_one, max_eq_left, log_nonpos, posLog_apply]

@[gcongr]
lemma posLog_le_posLog (hx : -1 ≤ x) (hxy : x ≤ y) : log⁺ x ≤ log⁺ y :=
  monotoneOn_posLog (by grind) (by grind) hxy

/-- The function `log⁺` commutes with taking powers. -/
@[simp] lemma posLog_pow (n : ℕ) (x : ℝ) : log⁺ (x ^ n) = n * log⁺ x := by
  by_cases hn : n = 0
  · simp_all
  by_cases hx : |x| ≤ 1
  · simp_all [pow_le_one₀, (posLog_eq_zero_iff _).2]
  rw [not_le] at hx
  have : 1 ≤ |x ^ n| := by simp_all [one_le_pow₀, hx.le]
  simp [posLog_eq_log this, posLog_eq_log hx.le]

/-- The function `log⁺` commutes with real powers with nonnegative base and exponent. -/
@[simp] theorem posLog_rpow {x α : ℝ} (hx : -1 ≤ x) (hα : 0 ≤ α) : log⁺ (x ^ α) = α * log⁺ x := by
  rcases le_or_gt x 0 with h | h
  · have h₁ : |x| ≤ 1 := abs_le.2 ⟨hx, h.trans zero_le_one⟩
    rw [(posLog_eq_zero_iff x).2 h₁, mul_zero, (posLog_eq_zero_iff _).2]
    exact (abs_rpow_le_abs_rpow x α).trans (rpow_le_one (abs_nonneg x) h₁ hα)
  · rw [posLog_apply, posLog_apply, log_rpow h, mul_max_of_nonneg _ _ hα, mul_zero]

/-- The function `log⁺` is continuous. -/
@[fun_prop] theorem continuous_posLog : Continuous log⁺ := by
  rw [continuous_iff_continuousAt]
  intro x
  by_cases hx : x = 0
  · apply ContinuousAt.congr (f := fun _ ↦ 0) (by fun_prop)
    filter_upwards [Metric.ball_mem_nhds _ zero_lt_one] with y hy
    rw [eq_comm, posLog_eq_zero_iff y]
    simp_all [le_of_lt]
  rw [posLog_def]
  fun_prop

/-!
## Trivial Estimates
-/

/-- For nonnegative `x`, the positive part of the logarithm is bounded by `log (1 + x)`. -/
lemma posLog_le_log_one_add {x : ℝ} (hx : 0 ≤ x) : log⁺ x ≤ log (1 + x) := by
  rw [posLog_eq_log_max_one hx]
  exact log_le_log (by positivity) (max_le (by linarith) (by linarith))

/-- Converse to `posLog_le_log_one_add` up to the additive constant `log 2`. -/
lemma log_one_add_le_posLog {x : ℝ} : log (1 + x) ≤ log⁺ x + log 2 := by
  have h₁ : (1 : ℝ) ≤ max 1 |x| := le_max_left ..
  have h₂ : |1 + x| ≤ max 1 |x| * 2 := by
    linarith [abs_add_le 1 x, le_max_right 1 |x|, abs_one (α := ℝ)]
  calc log (1 + x)
  _ ≤ log⁺ (1 + x) := le_max_right ..
  _ = log⁺ |1 + x| := (posLog_abs _).symm
  _ ≤ log⁺ (max 1 |x| * 2) := posLog_le_posLog (neg_one_lt_zero.le.trans (abs_nonneg _)) h₂
  _ = log⁺ x + log 2 := by
    rw [posLog_eq_log (by rw [abs_of_nonneg (by positivity)]; linarith),
      log_mul (by positivity) two_ne_zero, ← posLog_eq_log_max_one (abs_nonneg x), posLog_abs]

/-- The positive part of the logarithm is bounded by the absolute value: `log⁺ x ≤ |x|`. -/
lemma posLog_le_abs (x : ℝ) : log⁺ x ≤ |x| := by
  rcases le_or_gt |x| 1 with h | h
  · rw [(posLog_eq_zero_iff x).2 h]
    exact abs_nonneg x
  · rw [← posLog_abs, posLog_eq_log (by rw [abs_abs]; exact h.le)]
    linarith [log_le_sub_one_of_pos (lt_trans one_pos h)]

/-!
## Estimates for Products
-/

/-- Estimate for `log⁺` of a product. See `Real.posLog_prod` for a variant involving
multiple factors. -/
theorem posLog_mul : log⁺ (x * y) ≤ log⁺ x + log⁺ y := by
  by_cases ha : x = 0
  · simp [ha, posLog]
  by_cases hb : y = 0
  · simp [hb, posLog]
  unfold posLog
  nth_rw 1 [← add_zero 0, log_mul ha hb]
  exact max_add_add_le_max_add_max

/-- Estimate for `log⁺` of a product. Special case of `Real.posLog_mul` where one of
the factors is a natural number. -/
theorem posLog_nat_mul {n : ℕ} : log⁺ (n * x) ≤ log n + log⁺ x := by
  rw [← log_of_nat_eq_posLog]
  exact posLog_mul

/-- Estimate for `log⁺` of a product. See `Real.posLog_mul` for a variant with
only two factors. -/
theorem posLog_prod {α : Type*} (s : Finset α) (f : α → ℝ) :
    log⁺ (∏ t ∈ s, f t) ≤ ∑ t ∈ s, log⁺ (f t) := by
  classical
  induction s using Finset.induction with
  | empty => simp [posLog]
  | insert a s ha hs =>
    calc log⁺ (∏ t ∈ insert a s, f t)
    _ = log⁺ (f a * ∏ t ∈ s, f t) := by rw [Finset.prod_insert ha]
    _ ≤ log⁺ (f a) + log⁺ (∏ t ∈ s, f t) := posLog_mul
    _ ≤ log⁺ (f a) + ∑ t ∈ s, log⁺ (f t) := add_le_add (by rfl) hs
    _ = ∑ t ∈ insert a s, log⁺ (f t) := by rw [Finset.sum_insert ha]

/-!
## Estimates for Sums
-/

/-- Estimate for `log⁺` of a sum. See `Real.posLog_add` for a variant involving
just two summands. -/
theorem posLog_sum {α : Type*} (s : Finset α) (f : α → ℝ) :
    log⁺ (∑ t ∈ s, f t) ≤ log (s.card) + ∑ t ∈ s, log⁺ (f t) := by
  -- Trivial case: empty sum
  by_cases! hs : s = ∅
  · simp [hs, posLog]
  -- Nontrivial case: Obtain maximal element…
  obtain ⟨t_max, ht_max⟩ := s.exists_max_image (fun t ↦ |f t|) hs
  -- …then calculate
  calc log⁺ (∑ t ∈ s, f t)
  _ = log⁺ |∑ t ∈ s, f t| := by
    rw [Real.posLog_abs]
  _ ≤ log⁺ (∑ t ∈ s, |f t|) := by
    apply posLog_le_posLog (neg_one_lt_zero.le.trans (abs_nonneg _))
    simp [Finset.abs_sum_le_sum_abs]
  _ ≤ log⁺ (∑ t ∈ s, |f t_max|) := by
    apply posLog_le_posLog (neg_one_lt_zero.le.trans (Finset.sum_nonneg fun _ _ ↦ abs_nonneg _))
    apply Finset.sum_le_sum (fun i ih ↦ ht_max.2 i ih)
  _ = log⁺ (s.card * |f t_max|) := by
    simp [Finset.sum_const]
  _ ≤ log s.card + log⁺ |f t_max| := posLog_nat_mul
  _ ≤ log s.card + ∑ t ∈ s, log⁺ (f t) := by
    gcongr
    rw [posLog_abs]
    apply Finset.single_le_sum (fun _ _ ↦ posLog_nonneg) ht_max.1

/--
Variant of `posLog_sum` for norms of elements in normed additive commutative
groups, using monotonicity of `log⁺` and the triangle inequality.
-/
lemma posLog_norm_sum_le {E : Type*} [SeminormedAddCommGroup E] {α : Type*} (s : Finset α)
    (f : α → E) :
    log⁺ ‖∑ t ∈ s, f t‖ ≤ log s.card + ∑ t ∈ s, log⁺ ‖f t‖ := by
  grw [norm_sum_le, posLog_sum]
  exact neg_one_lt_zero.le.trans (norm_nonneg _)

/--
Estimate for `log⁺` of a sum. See `Real.posLog_sum` for a variant involving multiple summands.
-/
theorem posLog_add : log⁺ (x + y) ≤ log 2 + log⁺ x + log⁺ y := by
  convert posLog_sum Finset.univ ![x, y] using 1 <;> simp [add_assoc]

/--
Variant of `posLog_add` for norms of elements in normed additive commutative groups, using
monotonicity of `log⁺` and the triangle inequality.
-/
lemma posLog_norm_add_le {E : Type*} [SeminormedAddCommGroup E] (a b : E) :
    log⁺ ‖a + b‖ ≤ log⁺ ‖a‖ + log⁺ ‖b‖ + log 2 := by
  grw [norm_add_le, posLog_add, add_rotate]
  exact neg_one_lt_zero.le.trans (norm_nonneg _)

/--
Multiplying the argument of `log⁺` by a nonzero factor `x` changes its value by at most
`log⁺ x + log⁺ x⁻¹`, which equals `|log x|` by `Real.abs_log_eq_posLog_add_posLog_inv`.
-/
theorem abs_posLog_mul_sub_posLog_le_posLog_add_posLog {x y : ℝ} (hx : x ≠ 0) :
    |log⁺ (x * y) - log⁺ y| ≤ log⁺ x + log⁺ x⁻¹ := by
  rw [abs_le]
  constructor
  · grind [posLog_mul (x := x⁻¹) (y := x * y), posLog_nonneg]
  · grind [posLog_mul, posLog_nonneg]

end Real
