#!/usr/bin/env python3
"""Archive B1 source-only acceptance. Writes only task /tmp children; no CI/API/Git/compiler."""
import argparse, copy, hashlib, io, json, os, tarfile
from pathlib import Path
TASK=Path('/tmp/p2m-b1-source-delivery-v110-20261117')
ROOT=Path('/home/admin-wsl/Coq/abc');W=ROOT/'prove2me_workspace';A=W/'.local/adaptation'
D=A/'b1-source-replay-v104-20261117';C=A/'main-chain-open-20261116'
RB=Path('/tmp/p2m-b1-blind-readback-v107-20261117')
SOURCE_SHA='b839c7b89a0d79908151a08dd020c8878f6db640393d5c67b44bb835a09ddb2c'
FACT_SHA='c0007f077aa8b0541aff158c753a7b62d404184d3b344851379ccb63aa1478a9'
STANDARD={'propext','Classical.choice','Quot.sound'}
RECEIPTS={
 'source_leaf':'b1-source-replay-leaf-v106-result.json',
 'source_artifact':'b1-source-replay-artifact-v107-result.json',
 'root_facts':'b1-source-root-facts-v109-result.json',
 'eight_parser':'b1-eight-source-owner-parser-v102-result.json',
 'CurveOf_partial_parser':'b1-nine-source-owner-parser-v100-result.json',
 'Kt_parser':'b1-Kt-owner-parser-v105-result.json',
 'failed_source_leaf':'b1-source-replay-leaf-v104-relative-result.json',
 'failed_query_API':'b1-source-root-facts-v108-result.json',
 'failed_closure_heartbeat':'b1-source-actual-closure-v110-result.json'}


def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def walk(x):
 if isinstance(x,dict):
  yield x
  for v in x.values():yield from walk(v)
 elif isinstance(x,list):
  for v in x:yield from walk(v)
def name(n):return '' if not n else name(n[0])+('.' if n[0] else '')+str(n[2])
def sliced(data,r):return data[r['start']['offset']:r['end']['offset']]
def resource(d):
 r=d.get('resources') or d.get('result',{}).get('resources') or {}
 t,u,s=[r.get(k) for k in ['cpu_time_seconds','cpu_user_seconds','cpu_system_seconds']]
 return {**r,'cpu_total_equals_user_plus_system':None if None in (t,u,s) else abs(t-u-s)<.02,
  'peak_rss_GiB':r.get('peak_rss_bytes')/1024**3 if r.get('peak_rss_bytes') is not None else None,
  'peak_pss_GiB':r.get('peak_pss_bytes')/1024**3 if r.get('peak_pss_bytes') is not None else None,
  'resource_source':r.get('resource_source',r.get('source')),'resource_degraded':r.get('degraded'),
  'memory_basis':'MCP-CI process-tree physical RSS/PSS bytes; omitted metrics remain unknown/null'}
def accepted(d,review=False):
 q,r=d['request'],d['result'];assert d['status']=='succeeded' and r['exit_code']==0
 assert Path(q['workspace']).resolve()==W and q['exclusive'] is True
 assert r['snapshot']['workspace_mode']=='exclusive_worktree' and r['snapshot']['snapshot_id'] is None
 assert resource(d)['peak_rss_bytes']<=16*1024**3
 assert resource(d)['cpu_total_equals_user_plus_system'] is True
 assert not [x for x in r.get('diagnostics',[]) if x.get('severity')=='error']
 if review:
  rev=r['review'];assert q['task_type']=='review' and rev['passed'] is True
  assert rev['checks']['no_sorryAx'] is True and rev['checks']['assumptions_reported'] is True
  assert not rev['violations']
 return d


def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--output',type=Path,default=TASK/'dryrun')
 ap.add_argument('--evidence-directory',type=Path,default=A/'b1-source-delivery-v110-20261117')
 ap.add_argument('--registry',type=Path,default=A/'platform-node-registry.json')
 ap.add_argument('--source',type=Path,default=D/'source-project/B1SourceReplay.lean')
 ap.add_argument('--actual',type=Path,default=D/'actual/root-source-facts-v106.json')
 ap.add_argument('--readback',type=Path,default=RB)
 ap.add_argument('--leaf-receipt',type=Path,default=C/RECEIPTS['source_leaf'])
 ap.add_argument('--artifact-receipt',type=Path,default=C/RECEIPTS['source_artifact'])
 ap.add_argument('--root-receipt',type=Path,default=C/RECEIPTS['root_facts'])
 ap.add_argument('--archive',action='store_true')
 x=ap.parse_args();out=x.output.resolve();assert TASK in out.parents and out!=TASK
 out.mkdir(parents=True,exist_ok=True);evidence=x.evidence_directory.resolve()
 receipts={k:(C/v,read(C/v)) for k,v in RECEIPTS.items()}
 for k,p in [('source_leaf',x.leaf_receipt),('source_artifact',x.artifact_receipt),('root_facts',x.root_receipt)]:receipts[k]=(p,read(p))
 source=x.source.read_bytes();facts=read(x.actual);root=facts['root'];hm=read(D/'compat-v105/handoff-manifest.json');spans=read(D/'compat-v105/source-replay-spans-map.json');patch=read(D/'compat-v105/proof-compatibility-replacements.json')
 gates={};errors={}
 def gate(k,f):
  try:f();gates[k]=True
  except (OSError,AssertionError,KeyError,ValueError,TypeError) as e:gates[k]=False;errors[k]=str(e)
 def source_acceptance():
  assert sha(x.source)==SOURCE_SHA==hm['source']['sha256']
  assert hm['originalDeclarationCount']==132 and hm['originalCommandContextCount']==281
  assert len(spans['modules'])==14 and len(spans['commands'])==281
  for key in ['source_leaf','source_artifact']:
   d=accepted(receipts[key][1]);q,r=d['request'],d['result']
   assert q['worktree_manifest']['input_hashes'][str(x.source.resolve())]==SOURCE_SHA
   assert q['worktree_manifest']['source_resolved_against_working_directory']==str(x.source.resolve())
   assert r['actual_arguments'][0:2]==['lean','B1SourceReplay.lean']
  assert receipts['source_leaf'][1]['job_id']=='ci-018534-6a278498'
  assert receipts['source_artifact'][1]['job_id']=='ci-018538-2c5490b3'
 gate('source132_in14_modules_leaf_and_artifact',source_acceptance)
 def AST_and_compat():
  assert patch['declarationTypesChanged'] is False and patch['Height77BodyEdited'] is False
  assert len(patch['replacements'])==5 and all(r['proofOnly'] is True for r in patch['replacements'])
  assert hm['proofEditCount']==5 and hm['changedProofCommandCount']==4
  assert hm['declarationTYPEsAndStructureFieldsEdited'] is False
  changed=[]
  for module in spans['modules']:
   for key in ['source','coordinateSource','AST']:
    pin=module[key];assert sha(pin['path'])==pin['sha256']
  for row in spans['commands']:
   raw=sliced(Path(row['coordinateSource']).read_bytes(),row['originalRange']);effective=sliced(source,row['effectiveReplayRange'])
   assert hashlib.sha256(raw).hexdigest()==row['originalSHA256']
   assert hashlib.sha256(effective).hexdigest()==row['effectiveSHA256']
   assert len(raw)==row['originalBytes'] and len(effective)==row['effectiveBytes']
   if row['originalBytesUnchanged']:assert raw==effective
   else:
    changed.append(row);assert row['proofOnlyPatches']
    reconstructed=raw
    for edit in row['proofOnlyPatches']:
     assert edit['proofOnly'] is True
     old,new=edit['old'].encode(),edit['new'].encode()
     assert reconstructed.count(old)==1
     reconstructed=reconstructed.replace(old,new,1)
    assert reconstructed==effective
  assert len(changed)==4
  assert sum(len(r['proofOnlyPatches']) for r in changed)==5
  driver=read(A/'b1-source-parser-v102-20261117/freeze-manifest.json')
  assert driver['removedByteCount']==5 and driver['removedUTF8Bytes']=='Real ' and driver['sourceByteEdits']==0
  olddriver=A/'b1-source-parser-v102-20261117/QueryB123Parser.history-v100.lean';newdriver=A/'b1-source-parser-v102-20261117/QueryB123Parser.lean'
  assert sha(olddriver)==driver['oldDriverSHA256'] and sha(newdriver)==driver['newDriverSHA256']
  assert len(olddriver.read_bytes())-len(newdriver.read_bytes())==5
  assert len(spans['addedActualSourceSeeds'])==2
  assert {(r['sourceModule'],r['originalCommandIndex']) for r in spans['addedActualSourceSeeds']}=={('Iut.Concrete.ThetaRegion',14),('Iut.Cor312.ThetaData.GalCompletion',55)}
  assert all(r['originalBytesUnchanged'] for r in spans['addedActualSourceSeeds'])
  proof=hm['preservedHeight77Proof'];assert proof['bytes']==1124
  actual=sliced(source,proof['effectiveReplayBodyRange']);original=sliced((ROOT/'refer/iut/Iut/Tripod/Height.lean').read_bytes(),proof['originalBodyRange'])
  assert actual==original and len(actual)==1124 and hashlib.sha256(actual).hexdigest()==proof['sha256']
  accepted(receipts['eight_parser'][1]);accepted(receipts['Kt_parser'][1])
  curve=receipts['CurveOf_partial_parser'][1]
  assert curve['job_id']=='ci-018466-5d214558' and curve['status']=='failed'
  assert 'Foundation parser-only ranges for Iut.Tripod.CurveOf:' in curve['result']['stdout']
 gate('actual_AST_original_spans_five_proof_edits_Height77_unchanged',AST_and_compat)
 def root_actual():
  d=accepted(receipts['root_facts'][1],True);assert d['job_id']=='ci-018542-4dae4da4'
  assert sha(x.actual)==FACT_SHA
  assert facts['schema']=='B1-source-root-actual-facts/v106' and facts['compilerVersion']=='4.35.0-rc3'
  for flag in ['standardAxiomAuditPassed','closedSourceTYPEExported','actualKernelProofChecked']:assert facts[flag] is True
  assert facts['nativeTargetComparisonAccepted'] is False and facts['fullCarrierClosureExported'] is False
  assert root['name']=='Iut.Tripod.h_eq_finHeight_div' and name(root['ownerNameExpr'])=='B1SourceReplay'
  assert root['kind']=='theorem' and root['levelParams']==[] and root['hasSorryAx'] is False
  assert root['kernelProofTypeMatchesActualTYPE'] is True and root['kernelInferredTypeStructurallyEqual'] is False
  for k in ['axioms','typeAxioms','proofAxioms']:assert set(root[k])==STANDARD
  assert [(r['name'],r['binderInfo'],r['typeDisplay']) for r in root['telescope']['binders']]==[('P','default','Iut.Tripod.CurveProviders'),('x','default','Iut.Tripod.Pt')]
  for field in ['actualTypeExpr','actualProofExpr','kernelInferredProofTypeExpr']:assert isinstance(root[field],dict)
  cfg=facts['configuration'];assert cfg['sourceSHA256']==SOURCE_SHA and Path(cfg['outputFile'])==x.actual
  qp=W/d['request']['parameters']['source'];cp=Path(d['request']['environment']['B1_SOURCE_ROOT_FACTS_CONFIG'])
  assert read(cp)==cfg
  for p in [x.source,qp,cp]:assert d['request']['worktree_manifest']['input_hashes'][str(p)]==sha(p)
 gate('actual_root_TYPE_proof_two_default_binders_and_standard_axioms',root_actual)
 def readback():
  orig=read(x.readback/'input-manifest.json');add=read(x.readback/'v109-type-confirmation/input-manifest.json')
  assert orig['model']=='gpt-6.1-sol' and add['model']=='gpt-6.1-sol'
  assert orig['root_source']['sha256']==SOURCE_SHA
  assert orig['compiled_type_confirmation']['status']=='pending_main_agent_actual_compiled_TYPE'
  assert add['kernel_inferred_type_structurally_equal'] is False and add['kernel_proof_type_matches_actual_TYPE'] is True
  assert add['full_carrier_closure_exported'] is False and add['native_target_comparison_accepted'] is False
  for doc in [orig,add]:
   for node in walk(doc):
    if isinstance(node.get('path'),str) and 'sha256' in node:assert sha(node['path'])==node['sha256'],'readback input changed: '+node['path']
 gate('independent_original_trilingual_readback_and_actual_TYPE_addendum',readback)
 def negative_history():
  for key,jid,diagnostic in [('failed_source_leaf','ci-018518-5e8a533a',None),('failed_query_API','ci-018540-71bb06da','parent'),('failed_closure_heartbeat','ci-018549-cdc80819','heartbeats')]:
   d=receipts[key][1];assert d['job_id']==jid and d['status']=='failed'
   if diagnostic:assert diagnostic in json.dumps(d['result'],ensure_ascii=False)
 gate('source_leaf_query_API_and_closure_heartbeat_failures_preserved',negative_history)
 complete=all(gates.values());state={'schema':'B1-source-only-delivery-gates/v110','sourceOnlyComplete':complete,'gates':gates,'errors':errors,'fullCarrierClosureExported':False,'nativeTargetComparisonAccepted':False,'targetWrapperCreated':False,'platformPublished':False,'Height603FirstClassOpen':True,'mathematicalParentClosed':False,'mainWorkspaceWritten':False,'CICompilerAPIGitExecuted':False}
 write(out/'completion-gates.json',state)
 files={};pins={};historical=[]
 def add(p):
  p=Path(p).absolute()
  if not p.is_file():return
  if p.is_symlink() or '.lake' in p.parts or p.suffix in {'.olean','.ilean','.ir','.o','.a','.so'}:
   pins[str(p)]={'path':str(p),'copied':False,'reason':'prebuilt/symlink pin; cache not read or traversed'};return
  files[str(p)]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'member':'files/'+str(p).lstrip('/')}
 def tree(p):
  for folder,dirs,names in os.walk(p):
   dirs[:]=sorted(d for d in dirs if d not in ['.lake','.git','__pycache__'] and not Path(folder,d).is_symlink())
   for n in names:
    if n not in ['credentials.json','.env']:add(Path(folder,n))
 # Explicit stable inputs. Exclude live closure query/config/output subtree from traversal.
 for folder in [D/'compat-v105',D/'history-v104',x.readback]:tree(folder)
 for p in (A/'b1-source-parser-v102-20261117').iterdir():
  if p.is_file():add(p)
 stable_old_facts=Path('/tmp/p2m-b1-source-replay-v100-20261117/source-facts-v106')
 for p in stable_old_facts.iterdir():
  if p.is_file():add(p)
 for p in [x.source,x.actual,D/'queries/QueryB1SourceRootActualFacts.lean',D/'queries/root-source-facts.config.json',D/'handoff-manifest.json',D/'source-replay-spans-map.json',D/'cache-input-pins.json',D/'cached-name-boundary-audit.json',D/'narrow-source-import-plan.json',D/'source-fact-query-plan.json',x.registry,Path(__file__),TASK/'README.md']:add(p)
 for module in spans['modules']:
  for key in ['source','coordinateSource','AST']:add(module[key]['path'])
 for doc in [read(x.readback/'input-manifest.json'),read(x.readback/'v109-type-confirmation/input-manifest.json'),patch]:
  for node in walk(doc):
   if isinstance(node.get('path'),str) and Path(node['path']).is_absolute():add(node['path'])
 ci=[]
 for key,(p,d) in receipts.items():
  add(p);q,r=d['request'],d.get('result',{});m=q.get('worktree_manifest',{})
  ci.append({'role':key,'path':str(p),'sha256':sha(p),'jobId':d['job_id'],'attemptId':d.get('attempt_id'),'status':d['status'],'exitCode':r.get('exit_code'),'workspace':q['workspace'],'taskType':q['task_type'],'target':q['target'],'parameters':q['parameters'],'actualArguments':r.get('actual_arguments'),'workspaceMode':r.get('snapshot',{}).get('workspace_mode'),'snapshotId':r.get('snapshot',{}).get('snapshot_id'),'resources':resource(d),'diagnostics':r.get('diagnostics'),'inputManifestPointer':str(p)+'#/request/worktree_manifest','rawReceiptInArchive':True})
  for input_path,digest in m.get('input_hashes',{}).items():
   pp=Path(input_path)
   if '.lake' in pp.parts or pp.suffix in {'.olean','.ilean','.ir','.o','.a','.so'}:pins[input_path]={'path':input_path,'sha256':digest,'copied':False};continue
   # A historical hash is not replaced with a new query that occupies the old path.
   if pp.is_file() and sha(pp)==digest:add(pp)
   else:
    candidates=[D/'history-v104'/pp.name,A/'b1-source-parser-v102-20261117/QueryB123Parser.history-v100.lean',stable_old_facts/pp.name]
    saved=next((candidate for candidate in candidates if candidate.is_file() and sha(candidate)==digest),None)
    if saved:add(saved)
    historical.append({'jobId':d['job_id'],'path':input_path,'recordedSHA256':digest,'currentMatches':False,'rawReceiptPreserved':True,'savedExactVersion':str(saved) if saved else None})
  for artifact in r.get('artifacts',[]):pins[str(artifact)]={'path':str(artifact),'copied':False,'reason':'MCP-CI artifact store reference; not accessed'}
 write(out/'ci-history.json',ci);write(out/'historical-input-versions.json',historical);write(out/'prebuilt-pins.json',list(pins.values()))
 pointer={'path':str(x.actual),'sha256':FACT_SHA,'bytes':x.actual.stat().st_size,'archiveMember':'files/'+str(x.actual).lstrip('/'),'rawJSONCopiedOutsideArchive':False}
 ledger={'schema':'B1-source-only-compact-ledger/v110','status':'ACCEPTED_SOURCE_REPLAY_AND_ROOT_FACTS' if complete else 'PENDING_SOURCE_GATES','sourceOnly':True,'sourceSHA256':SOURCE_SHA,'sourceModule':'B1SourceReplay','sourceDeclarationCount':132,'sourceModuleCount':14,'originalCommandCount':281,'proofOnlyCompatibilityEdits':5,'changedProofCommandCount':4,'Height77ProofBytes':1124,'Height77ProofUnchanged':True,'root':'Iut.Tripod.h_eq_finHeight_div','actualFacts':pointer,'actualTYPE':{'display':root['actualTypeDisplay'],'levelParams':root['levelParams'],'binders':root['telescope']['binders'],'axioms':root['axioms'],'hasSorryAx':False,'kernelProofTypeMatchesActualTYPE':True,'kernelInferredTypeStructurallyEqual':False},'producerConsumers':[{'producer':'original14module AST commands','consumer':str(x.source),'fidelity':'132 source declarations replayed; five proof-only compatibility edits across four commands; original Height77 proof preserved'}, {'producer':'B1SourceReplay.Iut.Tripod.h_eq_finHeight_div','consumer':str(x.actual)+'#/root','fidelity':'actual closed source TYPE/proof and direct dependency facts; kernel proof TYPE matches actual TYPE; raw inferred TYPE structural equality false retained','targetConsumer':None}],'leafJob':receipts['source_leaf'][1]['job_id'],'artifactJob':receipts['source_artifact'][1]['job_id'],'actualRootFactsJob':receipts['root_facts'][1]['job_id'],'readback':str(evidence/'readback.tar.gz'),'originalEnglishReadbackPreserved':True,'v109CompiledTYPEAddendumSeparate':True,'fullCarrierClosureExported':False,'nativeTargetComparisonAccepted':False,'targetWrapperCreated':False,'platformPublished':False,'Height603FirstClassOpen':True,'mathematicalParentClosed':False}
 write(out/'SOURCE_LEDGER.json',ledger);write(out/'large-evidence-pointers.json',{'schema':'B1-large-evidence-pointers/v110','actualRootFacts':pointer,'policy':'Raw large JSON lives in compressed evidence archive; compact external SHA and member pointers only. Original file remains untouched.'})
 unit={k:v for k,v in ledger.items() if k not in ['producerConsumers','actualTYPE']};unit.update(evidenceDirectory=str(evidence),sourceLedger=str(evidence/'SOURCE_LEDGER.json'),archive=str(evidence/'b1-source-only-evidence-v110.tar.gz'),rootGraphMembership=False)
 fragment={'reference_source_preparation':{'b1_source_replay_and_root_facts_unit':unit}};write(out/'registry-merge-fragment.json',fragment)
 registry=read(x.registry);merged=copy.deepcopy(registry);merged['reference_source_preparation'].update(fragment['reference_source_preparation']);write(out/'platform-node-registry.merged.json',merged)
 write(out/'registry-merge-preconditions.json',{'basePath':str(x.registry),'baseSHA256':sha(x.registry),'replaceExactPaths':['/reference_source_preparation/b1_source_replay_and_root_facts_unit'],'mayApplySourceOnlyProgress':complete,'preserveOtherKeysGraphCountsDefinitionsProofNodesAndEdges':True})
 (out/'plan-append-proposal.md').write_text('- ['+('x' if complete else ' ')+'] 完成 B1 的来源重放编译及 root facts：14 个来源模块的 132 项声明／281 条原命令上下文，5 处仅证明兼容改动；Height 第 77 条的 1124 字节原证明不变。source leaf ci018534、artifact ci018538、实际 root TYPE/proof 审查 ci018542 通过；独立英文读回及中日译文保留，v109 实际类型附件另列。实际根仅 P、x 两个显式 default 参数、无宇宙参数，标准三公理且无 sorryAx；保留 kernelInferredTypeStructurallyEqual=false 与 kernelProofTypeMatchesActualTYPE=true。\n- [ ] 完成 B1 全载体闭包导出、目标版本包装和实际对应、平台验收；当前 fullCarrierClosureExported=false，未造 target wrapper、未发布平台。Height603 状态表第一类及数学父义务保持开放；132 项来源声明不等于 132 项 target 对应。\n')
 # Keep readback as its own small compressed artifact, verify every member.
 rbfiles=sorted(p for p in x.readback.rglob('*') if p.is_file());rbindex=[]
 rbarchive=out/'readback.tar.gz'
 if x.archive and complete:
  with tarfile.open(rbarchive,'w:gz') as t:
   for p in rbfiles:rbindex.append({'path':str(p),'member':str(p.relative_to(x.readback)),'sha256':sha(p)});t.add(p,arcname=str(p.relative_to(x.readback)),recursive=False)
  with tarfile.open(rbarchive,'r:gz') as t:
   for item in rbindex:assert hashlib.sha256(t.extractfile(item['member']).read()).hexdigest()==item['sha256']
  write(out/'readback-archive-manifest.json',{'path':str(rbarchive),'sha256':sha(rbarchive),'allMembersReopenedSHA256Verified':True,'files':rbindex});add(rbarchive)
 for p in out.iterdir():
  if p.is_file() and p.suffix in ['.json','.md'] and p.name!='archive-manifest.json':add(p)
 manifest={'schema':'B1-source-only-content-archive/v110','sourceOnlyComplete':complete,'archiveCreated':False,'files':[files[k] for k in sorted(files)],'fullCarrierClosureExported':False,'liveClosureOutputExcluded':True,'policy':'No source/query deletion; raw large JSON and raw receipts only compressed in tar; compact external ledger/history. Source-only unit does not accept target correspondence.'};write(out/'archive-manifest.json',manifest)
 if x.archive:
  assert complete,'source-only gates failed'
  archive=out/'b1-source-only-evidence-v110.tar.gz';index=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
  with tarfile.open(archive,'w:gz') as t:
   info=tarfile.TarInfo('archive-index.json');info.size=len(index);t.addfile(info,io.BytesIO(index))
   for item in manifest['files']:assert sha(item['path'])==item['sha256'];t.add(item['path'],arcname=item['member'],recursive=False)
  with tarfile.open(archive,'r:gz') as t:
   assert len(t.getmembers())==len(manifest['files'])+1 and t.extractfile('archive-index.json').read()==index
   for item in manifest['files']:
    h=hashlib.sha256();f=t.extractfile(item['member'])
    for b in iter(lambda:f.read(1048576),b''):h.update(b)
    assert h.hexdigest()==item['sha256'] and sha(item['path'])==item['sha256']
  manifest.update(archiveCreated=True,archive=str(archive),archiveSHA256=sha(archive),archiveBytes=archive.stat().st_size,allMembersReopenedSHA256Verified=True);write(out/'archive-manifest.json',manifest)
 print(json.dumps({'sourceOnlyComplete':complete,'gates':gates,'errors':errors,'output':str(out),'fileCount':len(files),'archiveCreated':manifest['archiveCreated']},ensure_ascii=False))
if __name__=='__main__':main()
