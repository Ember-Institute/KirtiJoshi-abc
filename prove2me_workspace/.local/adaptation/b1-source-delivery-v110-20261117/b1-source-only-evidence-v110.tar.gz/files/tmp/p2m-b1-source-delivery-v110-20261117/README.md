# B1 来源重放与 root facts 单元

只读既有材料，仅写此任务 `/tmp` 子目录；不 CI、不编译、不 API、不 Git、不修改主区、不删除源码或 query。

```bash
python3 /tmp/p2m-b1-source-delivery-v110-20261117/prepare_archive.py \
  --archive \
  --evidence-directory /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/b1-source-delivery-v110-20261117 \
  --output /tmp/p2m-b1-source-delivery-v110-20261117/final
```

移除 `--archive` 可只做 dry-run。`--source`、`--actual`、三种成功 receipt、`--readback`、`--registry` 可显式覆盖，但须继续满足精确本次 source/facts SHA 与合同。`--evidence-directory` 只用于建议路径，不在那里写文件。

交付范围：14 个原始来源模块、132 项声明、281 条命令上下文的来源重放；5 个仅证明兼容改动、4 条改变的 proof commands；原 Height77 的 1124 字节证明逐字不变。两项真实来源 seed `InitialThetaData.Kt` 与 `toNNReal_congr` 的原 AST 和字节保留。driver scoped Real 修复仅删除 driver 的 `Real ` 五字节，原文件不改。

source leaf ci018534、artifact ci018538 以及 root actual TYPE/proof 审查 ci018542 通过。实际根为 `Iut.Tripod.h_eq_finHeight_div`，仅 P/x 两个显式 default 参数、宇宙参数为空、标准三公理且无 sorryAx。`kernelInferredTypeStructurallyEqual=false` 与 `kernelProofTypeMatchesActualTYPE=true` 同时保留，不用后者覆盖前者。实际导出仅 root 与直接依赖；`fullCarrierClosureExported=false`。

独立原英文及中日译文原样归档；原 manifest 里当时 pending actual TYPE 状态保留，另附 v109 编译实际 TYPE 确认，不回写历史独立读回。model 记录为 gpt-6.1-sol。`readback.tar.gz` 和总 evidence tar 都重开逐成员校验 SHA。

巨大 actual JSON（77,707,930 bytes）仅作为压缩总归档成员，不在输出目录再展开复制。外部 `large-evidence-pointers.json` 和 compact `SOURCE_LEDGER.json` 保留完整原文件 SHA 与 archive member；原文件不删除。原 AST、source bodies、patch、实际 JSON、完整原 CI receipts 和 readback 全部纳入总 tar。`ci-history.json` 仅保存紧凑角色／参数／退出原因／全部原资源字段／raw manifest 指针，CPU user/sys/total、wall、RSS/PSS、未知 source/degraded 均保留。

失败 ci018518、FilePath.parent API 失败 ci018540、200k heartbeat 失败 ci018549 及 exact old input 原件保留。CurveOf 使用 ci018466 failed batch 中该模块完整 parser data，不称整任务成功。ci018497 覆盖八模块 parser，ci018523 覆盖 ThetaRegion。活动 closure query/config/output 不当作本次归档输入；后续成功闭包须独立并入，不等其完成才生成当前来源单元。

root 审查后的主区写列表：

1. 复制整个 `final/` 至建议 evidence-directory；不要解压巨大 actual 到外部。
2. 核对 `registry-merge-preconditions.json` base SHA 后应用 `platform-node-registry.merged.json`。仅新增 `reference_source_preparation.b1_source_replay_and_root_facts_unit`，其他键、graph counts、definitions、proof nodes、edges 保持。
3. 追加审查后的 `plan-append-proposal.md`；仅来源重放及 root facts 勾选。
4. 此处 `SOURCE_LEDGER.json` 是独立单元账本，不覆盖主区旧总账本。

目标 wrapper 未构造，native target comparison 未接受，平台未发布，Height603 状态表第一类保持开放。132 项来源声明不等于 132 项 target 对应；数学父义务未关闭。没有 cleanup 入口，不删除源代码、queries、历史回放输入或缓存。
