# 実際にコンパイルされた型の照合：元の独立読み戻しとは別に保存

親ディレクトリの英文、簡体字中国語文、日本語文の読み戻しは、全文を変更せず保持する。その数学的な読み戻しは、今回のコンパイル済み事実の照合より前に作成したものである。

実際のソースの事実ファイルは、根定理の型を次のように報告する。

```lean
∀ (P : Iut.Tripod.CurveProviders) (x : Iut.Tripod.Pt),
  P.h x = Iut.finHeight (Iut.legendreJ (Iut.Tripod.gen ↑x)) / ↑(Iut.Tripod.deg ↑x)
```

出力されたパラメータ列は `P : Iut.Tripod.CurveProviders` と `x : Iut.Tripod.Pt` の二つのみである。いずれも `binderInfo: default` であり、明示的なパラメータである。`levelParams` は空である。したがって、元の読み戻しの P と x の網羅性を確認でき、継承された暗黙のパラメータや宇宙パラメータを加える必要はない。j の式に含まれる大域定数は `Iut.legendreJ` である。

事実ファイルのソースのハッシュは、元の独立読み戻しが記録したハッシュと完全に一致する。実際のソースのコンパイラは `4.35.0-rc3`、根定理の所属モジュールは `B1SourceReplay` である。

根定理、その型、その証明がそれぞれ報告する公理は、`propext`、`Classical.choice`、`Quot.sound` の三つに限られる。`hasSorryAx` は偽である。出力記録は `actualKernelProofChecked: true` と `kernelProofTypeMatchesActualTYPE: true` を報告する。一方、`kernelInferredTypeStructurallyEqual: false` も別に報告するため、これを構造的同一性と表現してはならない。この出力は対象バージョンとのネイティブ比較を受理せず、完全な台の閉包の出力も報告しない。

主エージェントは本出力をジョブ `ci-018542-4dae4da4` に対応させる。補足の入力一覧は、事実ファイルのハッシュと実行記録の出所を記録する。本付記はコンパイルされたソースの事実を照合するものであり、新たな独立した数学的審査ではない。元の読み戻しの範囲は変わらない。すなわち、与えられたデータを条件とする恒等式であり、データの存在や最終的な abc の主張を断言しない。


## 保存された MCP-CI 実行記録

ジョブ `ci-018542-4dae4da4` の保存済み `ci_result` は、終状態 `succeeded`、終了コード 0、診断なしと報告する。`/home/admin-wsl/Coq/abc/prove2me_workspace` で `QueryB1SourceRootActualFacts.lean` を検査し、`workspace_mode: exclusive_worktree`、`snapshot_id: null` を用いる。実経過時間は 159.0188941000015 秒である。CPU 時間の合計は 159.12 秒で、ユーザー時間 11.17 秒とシステム時間 147.95 秒の和に等しい。プロセスツリーの物理常駐メモリの最大値は 9,284,927,488 バイト、すなわち 8.647262573242188 GiB である。比例配分された物理メモリの値は不明である。補足の入力一覧は実行記録のパスとハッシュを記録する。本読者はこのジョブを投入・実行していない。
