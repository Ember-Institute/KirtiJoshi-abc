# Independent formal readback — B1 root

Root: `Iut.Tripod.h_eq_finHeight_div`.

This readback uses the formal declarations and definitions listed in `input-manifest.json`. Source comments and declaration names do not supply mathematical premises. No paper claim, existing natural-language node draft, or reported compilation outcome supplies the readback.

## Parameters and the data package

The visible root declaration takes `P : CurveProviders` and `x : Pt`. Here `Qbar` is a chosen algebraic closure of the rational numbers. A point `x` is an element λ of this closure, together with proofs that λ ≠ 0 and λ ≠ 1.

The actual structure `CurveProviders` has exactly these four fields:

1. For every λ in the algebraic closure, the set of points killed by multiplication by 3 on the nonsingular-point group of the Legendre equation is finite.
2. For every λ in the algebraic closure, the analogous set killed by 5 is finite.
3. For every point x, arithmetic data `arith x` for the curve constructed below.
4. For every point x and every natural prime ℓ, representation data `modRep x ℓ`. These data contain an additive-group isomorphism from the ℓ-torsion over the chosen algebraic closure to `(ℤ/ℓℤ)²`. They also contain a group homomorphism from the algebraic-automorphism group of that closure over the curve's field to `GL₂(ℤ/ℓℤ)`. The isomorphism sends each Galois-transformed torsion point to the represented matrix times its coordinate vector. The homomorphism has an open kernel in the topology supplied on that automorphism group.

The first two fields range over all λ, including 0 and 1. The last two range over `Pt`. In particular, `curve` and `tate` are derived definitions, not fields of this four-field structure.

## The actual curve and arithmetic premises

For λ = x.1, let F be the subfield of the chosen algebraic closure generated over ℚ by λ, a chosen square root of −1, a chosen square root of λ, a chosen square root of 1−λ, and the affine coordinates of all points killed by 3 or by 5 on the Legendre equation over the closure. The identity point contributes no coordinates. The first two fields of P supply the finiteness used to give F its number-field structure.

The constructed curve C = `P.curve x` has field F, algebraic closure `Qbar`, and Weierstrass coefficients `(0, −(1+λ), 0, λ, 0)`, with λ now viewed in F. Thus its affine equation is

\[
E_\lambda:\quad Y^2=X(X-1)(X-\lambda).
\]

Write M = ℚ(j(E)) inside F. The arithmetic premise `P.arith x` contains all ten conditions below:

1. −1 is a square in F.
2. At every finite place w of F, E has good or multiplicative reduction. Each reduction predicate allows a global change of Weierstrass variables before base change to the completion and its integer ring.
3. Every point killed by 6 over the chosen algebraic closure lies in the image of base change from F-rational points.
4. For every prime ℓ ≥ 7, F/M is Galois and `[F:M]` is coprime to ℓ.
5. Every finite place of F lies over some finite place of M.
6. Finite places over one another in F/M have the same residue characteristic.
7. If a finite place of M has residue characteristic different from 2, multiplicative reduction at one place above it implies multiplicative reduction at every other place above it.
8. The set B of all finite places of F with multiplicative reduction is finite.
9. The residue degree f_w of each finite place w of F is positive.
10. For every natural number q, the sum of f_w over w in B with residue characteristic q is at most `[F:ℚ]`.

These are input conditions supplied by P. This root does not construct a package P satisfying them.

## Height, fields, and normalization

For each w in B, the derived `P.tate x` chooses a Tate parameter q_w in the completion F_w whose Tate j-invariant equals the image of j(E). It also chooses a uniformizer. Let n_w be the positive natural number obtained as `qOrder` from this parameter and uniformizer. This is the discrete valuation order of q_w, normalized by the chosen uniformizer. Write p_w for the residue characteristic and f_w for `Ideal.inertiaDeg` of the prime of w over ℤ. The left side is the actual definition

\[
P.h(x)=\frac{\sum_{w\in B}n_w f_w\log p_w}{[F:\mathbb Q]}.
\]

Let k = ℚ(λ) inside `Qbar`. The definition `deg λ` is the natural degree of the minimal polynomial of λ over ℚ; it equals `[k:ℚ]` and is positive. The definition `gen λ` is λ viewed as an element of k. Put

\[
J(t)=\frac{256(t^2-t+1)^3}{t^2(t-1)^2}.
\]

For any number field L and y in L, the unnormalized finite height is

\[
 h_{\mathrm{fin}}^L(y)=\sum_{v\text{ finite in }L}\log^+|y|_v,
 \qquad \log^+ r=\max(0,\log r).
\]

The sum has finite support. The finite absolute values use the prime-ideal norm normalization: a uniformizer at v has absolute value `N(𝔭_v)⁻¹`, with `N(𝔭_v)=p_v^{f_v}`. Thus the residue-degree weight is already inside the absolute value. No archimedean places occur in this definition. The real logarithm in the formal library has value 0 at 0; the statement therefore also permits J(λ)=0.

For precision, T = `tpd P x` is an intermediate field of F. It is generated by j(E) and the first affine coordinates of F-rational points killed by 2. In this construction, those coordinates form `{0,1,λ}`, and T = ℚ(λ) **inside F**. The map `tpdEquiv P x` is a ℚ-algebra isomorphism T → k; it sends `genT P x` to `gen λ`. The element `jT P x` is J(`genT P x`) in T. Its image in F is j(E), and its image in k is J(`gen λ`). Moreover,

\[
[T:\mathbb Q]=\deg\lambda,\qquad
[F:\mathbb Q]=(\deg\lambda)[F:T],\qquad [F:T]>0.
\]

The finite height scales by `[F:T]` under the inclusion T → F and is preserved by the isomorphism T → k. These facts explain the field change and the cancellation in the root.

## Root assertion and its scope

For every such package P and every such point x, with λ = x.1, the root states the exact identity

\[
\boxed{\displaystyle
P.h(x)=\frac{h_{\mathrm{fin}}^{\mathbb Q(\lambda)}(J(\lambda))}{[\mathbb Q(\lambda):\mathbb Q]}.}
\]

The numerator evaluates J(λ) in k, not λ itself and not in the larger field F. Both denominators above are positive. An empty B gives zero on the left. The root has no nonzero-j premise, error term, inequality constant, degree bound, or restriction to a bounded subset. It equates two expressions from the same supplied curve data. It does not assert a comparison with the separately defined height `htCan`, the existence of P, or the final abc statement.

## Type check boundary

The source-visible binder list is `(P : CurveProviders) (x : Pt)`. Earlier `include hwv` and `include hvw` occur inside sections that end before this root's section. This readback does not invent any extra inherited binders. The main agent must compare this account with the actual compiled declaration type before marking its binder coverage final. No compilation was run by this reader.
