# Compiled-type confirmation, separate from the original blind readback

The original English, Simplified Chinese, and Japanese readbacks remain complete and unchanged in the parent directory. Their mathematical account predates this compiled-fact check.

The actual source facts file reports this root type:

```lean
∀ (P : Iut.Tripod.CurveProviders) (x : Iut.Tripod.Pt),
  P.h x = Iut.finHeight (Iut.legendreJ (Iut.Tripod.gen ↑x)) / ↑(Iut.Tripod.deg ↑x)
```

The exported telescope contains exactly two binders: `P : Iut.Tripod.CurveProviders` and `x : Iut.Tripod.Pt`. Both have `binderInfo: default`, so both are explicit. `levelParams` is empty. This confirms the original readback's P/x coverage; no inherited implicit parameter or universe parameter must be added. The j-expression's global constant is `Iut.legendreJ`.

The fact file's source SHA-256 equals the SHA-256 recorded for the original blind readback. Its actual source compiler is `4.35.0-rc3`, and the root's owner is `B1SourceReplay`.

The root, its type, and its proof each report exactly `propext`, `Classical.choice`, and `Quot.sound`. `hasSorryAx` is false. The export reports `actualKernelProofChecked: true` and `kernelProofTypeMatchesActualTYPE: true`. It separately reports `kernelInferredTypeStructurallyEqual: false`; these are not claims of structural identity. The export does not accept a native target comparison and does not report a full carrier-closure export.

The main agent associates this export with job `ci-018542-4dae4da4`. The supplementary manifest records the fact-file hash and receipt provenance. This is a check against compiled source facts, not another independent mathematical review. The original readback's scope remains: an identity conditional on the supplied provider, without a provider-existence claim or the final abc claim.


## Saved MCP-CI receipt

The saved `ci_result` receipt for `ci-018542-4dae4da4` reports `succeeded`, exit code 0, and no diagnostics. It checks `QueryB1SourceRootActualFacts.lean` in `/home/admin-wsl/Coq/abc/prove2me_workspace` with `workspace_mode: exclusive_worktree` and `snapshot_id: null`. Its wall time is 159.0188941000015 seconds. Total CPU time is 159.12 seconds: 11.17 user seconds plus 147.95 system seconds. Peak process-tree RSS is 9,284,927,488 bytes (8.647262573242188 GiB); PSS is unknown. The supplementary manifest records the receipt's path and SHA-256. The reader did not submit or run this job.
