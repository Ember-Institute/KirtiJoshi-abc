# 实际编译类型核对：与原独立盲读分开保存

上级目录中的英文、简中和日文读回均保持全文完整且未改动。其数学读回先于本次编译事实核对形成。

实际源码事实文件报告的根定理类型为：

```lean
∀ (P : Iut.Tripod.CurveProviders) (x : Iut.Tripod.Pt),
  P.h x = Iut.finHeight (Iut.legendreJ (Iut.Tripod.gen ↑x)) / ↑(Iut.Tripod.deg ↑x)
```

导出的参数列表恰有两个参数：`P : Iut.Tripod.CurveProviders` 和 `x : Iut.Tripod.Pt`。二者的 `binderInfo` 均为 `default`，因此均是显式参数。`levelParams` 为空。这确认原读回对 P 和 x 的覆盖，无须增加继承的隐式参数或宇宙参数。j 表达式中的全局常量为 `Iut.legendreJ`。

事实文件中的源码摘要与原盲读所记录的源码摘要完全一致。实际源码编译器版本为 `4.35.0-rc3`，根定理所属模块为 `B1SourceReplay`。

根定理、其类型及其证明各自报告的公理恰为 `propext`、`Classical.choice` 和 `Quot.sound`。`hasSorryAx` 为假。导出记录报告 `actualKernelProofChecked: true` 与 `kernelProofTypeMatchesActualTYPE: true`，但另行报告 `kernelInferredTypeStructurallyEqual: false`，故不能把上述核对表述为结构相同。该导出未接受目标版本的原生比较，也未报告完整载体闭包导出。

主智能体将本导出关联至任务 `ci-018542-4dae4da4`。补充清单记录事实文件摘要和回执来源。本附件核对实际编译源码事实，不构成另一次独立数学审查。原读回的范围保持不变：这是以输入数据包为条件的恒等式，不断言数据包存在，也不断言最终的 abc 主张。


## 已保存的 MCP-CI 回执

任务 `ci-018542-4dae4da4` 的已保存 `ci_result` 回执报告终态为 `succeeded`、退出码为 0，且没有诊断。该任务在 `/home/admin-wsl/Coq/abc/prove2me_workspace` 中检查 `QueryB1SourceRootActualFacts.lean`，采用 `workspace_mode: exclusive_worktree`，`snapshot_id: null`。墙钟时间为 159.0188941000015 秒。中央处理器总时间为 159.12 秒，其中用户态为 11.17 秒，内核态为 147.95 秒。进程树峰值物理常驻内存为 9,284,927,488 字节，即 8.647262573242188 GiB；按比例分摊的物理内存未知。补充清单记录回执路径与摘要。本审读者未提交或运行该任务。
