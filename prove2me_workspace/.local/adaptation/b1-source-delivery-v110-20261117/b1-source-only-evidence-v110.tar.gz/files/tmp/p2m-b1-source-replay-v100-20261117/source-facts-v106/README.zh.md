source4.35 B1 producer actual-facts 查询草稿，仅/tmp写入，无CI/编译/API/Git/主区写入。

先运行 QueryB1SourceRootActualFacts.lean + root-source-facts.config.json，env B1_SOURCE_ROOT_FACTS_CONFIG。它导出真实唯一Iut.Tripod.h_eq_finHeight_div完整TYPE/proof、所有direct TYPE/value常量实际NameExpr/owner，读取actual telescope/BinderInfo并做Kernel.check proof与Kernel.isDefEq到actualTYPE、root/type/proof三路标准公理/no sorry审查。新query首编60s/16GiB。必须把已验收flat B1SourceReplay.olean所在source-project/.lake/build/lib/lean置LEAN_PATH首位。准确路径与hash在root-query-handoff.json。

第二份 QueryB1SourceActualClosure.lean + closure-source-facts.config.json，env B1_SOURCE_CLOSURE_FACTS_CONFIG。它先保存独立kernel检查root-first.json，再按真实Expr常量和compiler metadata BFS写actual-facts.jsonl/actual-edges.jsonl，完整后写summary.json。没有静态30seed，也不依据raw签名猜依赖。

闭包政策：actual owner B1SourceReplay全TYPE/value递归；actual owner为Iut/Genl命名空间的cached source模块非Prop data完整TYPE/value及ctor/rec/structure metadata递归；cached Iut/Genl source closed、零universe Prop作为实际proof support完整值递归；cached project polymorphic proof保留实际TYPE依赖且proof body显式cache边界；Init/Lean/Std/Mathlib/Batteries和所有其它外部库（含TateCurvesTheta）明确停止，不导出整个Mathlib证明。实际owner边界保留在每条记录与边中，不能称无边界的全Mathlib闭包。B1/Basic/Cor22的真实owner由env模块索引读取，不手工重命名。

所有full value均Kernel.check并与actual TYPE kernel-defeq核对，标准公理/no sorry按declaration/TYPE/value分别检查。原结构所有field/parent/autoparam metadata与ctor/rec参数、每rule.rhs保留；recursor实际Name从env元数据一次扫描建立index，不拼字符串。所有TYPE/定义/metadata引用的项目carrier继续递归。每项actual fullTYPE与definition/proof Expr按原compiler序列化，不从pretty文本反解。

本查询绑定有效source b839c7…：五处兼容proof edit已接受，132原stmt和完整structure字段保留；仅Height77根proof继续原1124bytes字节不变。原版本proof全字节identity不成立，应以有效source审计。这里完全不是native4.33 target结果，不生成任何target wrapper或声称native映射通过。Iut.legendreJ等精确fullname必须从actual Expr读取，不能凭Tripod文件路径臆造namespace。

小rootquery的原草稿FilePath.parent错误已由root在stage副本修复，root正在执行v109；此处不改已stage小query。第二closure query没有FilePath.parent调用，目录直接来自outputDir字符串。closure只在rootfact终态后由root按实测规模决定是否提交或继续拆分。
