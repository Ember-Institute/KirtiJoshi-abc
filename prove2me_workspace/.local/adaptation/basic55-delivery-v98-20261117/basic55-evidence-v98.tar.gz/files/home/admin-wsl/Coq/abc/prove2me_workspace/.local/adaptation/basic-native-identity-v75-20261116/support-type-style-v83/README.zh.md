# 55项原始签名差异静态审查

仅3项不同，均为既有规范层的支持定理：

| 源声明末段 | 源全称量词/匿名函数数量 | 原生全称量词/匿名函数数量 |
|---|---:|---:|
| deg_eq_finrank | 1 / 1 | 1 / 5 |
| logCond_eq_sum | 1 / 218 | 1 / 204 |
| logDiff_eq_log_absNorm_differentIdeal | 1 / 304 | 1 / 237 |

3项所有全称量词和匿名函数的 BinderInfo 都为 default。数学输入均只有最外层一个显式全称量词。不存在显式/隐式参数风格变化。其余52项完整 binderInventory 和 binderPlacement 都相等，包括新根 tripodTheory、结构、构造子、递归器和字段。

deg_eq_finrank 的额外4个匿名函数位于 Module.finrank 的第4个实参（从0起编号3），即推断的 AddCommMonoid 实例：源采用 AddSubmonoidClass.toAddCommMonoid；原生采用 Semiring.toAddCommMonoid，经 DivisionSemiring.toSemiring、Semifield.toDivisionSemiring、Field.toSemifield，多次出现携带同一成员谓词的 Subtype。两边公开定理仍是 ∀z，deg(z)=finrank(ℚ,ℚ(z))。

原失败查询在原始绑定信息门之前先检查完整 source/native TYPE 的内核相等性。因此首项 deg_eq_finrank 已通过完整 TYPE 门；后两项尚未到达，不能声称内核相等性已通过。

推荐只对白名单这3个既有支持定理增加兼容证书：保留原完整 TYPE 内核门，精确绑定源/原生事实摘要及完整原始 Expr，逐项核对原始 inventory/placement，强制公开量词仍恰为一个 default，全称类型必须在内核相等，再用实际 Eq.refl 项内核检查完整 TYPE 相等命题。保留 signatureBinderInfoEqual=false 和完整差异。新根、结构元数据和其余52项仍走原严格门。

这是完整 TYPE 表达式的相等证书，不是读取过源定理证明值的声明。这3个 source proof value 均尚未读取；不能将类型证书称为 source/native 证明代码字节或证明值身份已完成。

文件：
- all55-raw-signature-diagnostic.json：全55项及所有差异路径、原始表达式规范序列化摘要。
- support-type-style-certificates.draft.json：3个精确白名单及两侧完整原始 TYPE Expr、事实摘要。
- AuditBasicNativeComparison.lean / support-type-style.patch：完整查询草稿及窄补丁。
- merge_style_certificates.py：将证书加入一个新文件中的原有 bound config，不覆盖失败输入。
- patch-scope.json：静态范围与当前摘要。

本目录未经编译或内核验收。仅静态分析既有实际表达式；未调用CI/API/Git，未改主区。
