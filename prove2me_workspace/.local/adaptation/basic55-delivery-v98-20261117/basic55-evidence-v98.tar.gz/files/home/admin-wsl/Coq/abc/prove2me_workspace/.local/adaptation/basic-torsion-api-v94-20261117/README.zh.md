# Basic torsion API 窄查询草稿（v93）

本目录仅含草稿及从已存在实际 JSON 提取的诊断，不含新的编译回执。未运行 Lean、MCP-CI、Git 或外部 API；未修改主工作区。

## 主智能体可运行的三个独立叶查询

1. 源 4.35：`QuerySourceTorsionAPI.lean`，环境 `BASIC_TORSION_API_CONFIG=/tmp/p2m-torsion-api-v93-20261117/source-api.config.json`。
2. 目标 4.33：`QueryTargetTorsionAPI.lean`，环境 `BASIC_TORSION_API_CONFIG=/tmp/p2m-torsion-api-v93-20261117/target-api.config.json`。
3. 目标全部缺失常量枚举：`QueryTargetConstantExistence.lean`，环境 `BASIC_TARGET_CONSTANT_INVENTORY_CONFIG=/tmp/p2m-torsion-api-v93-20261117/target-inventory.config.json`。

源 imports 与已有成功 source normalization query 相同；目标 imports 与当前 v92 comparison 相同。主智能体按仓库协议提交这些文件，使用对应现有依赖 LEAN_PATH。每个新叶模块首次预估 60s、16GiB。可复制到主智能体选定的受审目录后再提交；若移动配置，须同步绝对输入/输出路径和绑定。

API 查询导出实际 Name、owner、宇宙参数、完整 TYPE、完整 value（含 opaque 可读值）、TYPE/value/声明公理、结构元数据、计算元数据及 recursor RHS。不存在的请求名称保留 exists=false。`HasUniqueDiv`、`IsAddTorsionFree`、`IsAffineAddMonoid` 三个家族按实际环境枚举，另含 torsion 实例和若干窄 seeds。它们仅导出事实，不接受任何 rename/substitution，也不引入外国 Expr。

目标 existence 查询只 decode 精确 Name，逐名使用 `env.find?`；不 decode 或 kernel-check 源 Expr。输入内容与 config 中 namesFileBinding 完全一致才继续。结果 `missing` 覆盖全部诊断范围；`requiredMissing` 只包含当前比较实际需用且不属于既有 closedProp 展开根的名字。存在性不是 TYPE/计算值相等证书。

## 已有实际输入的提取结果

`constant-use-input.json` 记录 source-enriched 99 项、selected55、closedSourceProofSupport 9 项、closedNativeProofSupport 8 项、source normalization 4 项的常量引用集合与输入 SHA256。准确保留 Name 的 str/num 成分；唯一项目改名来自现有 actualNameMapCandidates 69 对，未额外发明 Mathlib 改名。

总计 289 个不同名字，232 个标为 requiredForComparison。scope 分开保留 source99Raw、selected55Raw、closedSource9、closedNative8、normalized4 和 effectiveSelected55；最后一个 scope 按当前比较器使用源 normalized TYPE/value 替代指定 4 字段。closedProp 支持根会在现比较器中展开，因此单独标记 expandedClosedPropSupport；其完整 TYPE/proof 中的依赖仍纳入 required 范围。native8 已是目标 Name，不对新加入的 native 名字再做源名迁移。

`torsion-actual-occurrences.json` 保留完整应用及实参 AST，不把带 #0 的子项谎称为闭 Expr。该常量只出现在 `Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal` TYPE 中；source99Raw、selected55Raw、normalized4、effectiveSelected55 是同一数学位置的四种观察，不是四个独立应用。

该应用的三个实参为：

- `NumberField.RingOfIntegers (...)`；
- 相应的 `Ring.toAddCommGroup ...`；
- `IsAffineAddMonoid.toHasUniqueDiv ...`，其中包含 `HasUniqueDiv.of_isCancelMulZero_charZero ...`。

## 源码可确认的范围

源 Mathlib `Algebra/Group/Monoid.lean:526` 的新版 `IsAddTorsionFree` 有 `AddCommute` 前提；`:572` 的 `HasUniqueDiv` 字段是 `nsmul_right_injective`。目标 `Algebra/Group/Defs.lean:790` 的旧 `IsAddTorsionFree` 也以该单射字段定义。故 HasUniqueDiv 不是仍保留的同名旧类 alias；全局保持新版 IsAddTorsionFree 名字也不能证明旧新同义。

源 `Algebra/Module/Torsion/Free.lean:152` 的实例参数为 HasUniqueDiv，目标同文件 `:143` 的参数为旧 IsAddTorsionFree。源/目标 `Algebra/AffineMonoid/Basic.lean:20` 的 class abbrev 最后一项也分别为这两个类，生成了 toHasUniqueDiv / toIsAddTorsionFree 两个投影。

这些源码对应关系只是候选，不是内核证书。下一步必须先取得两端 API 实际导出，再对精确实例 TYPE/计算值及相关类/投影计算行为验收。不得任意替换实例数据，不能跳过完整 TYPE/值比较。没有新公理、没有小公开数学节点、没有 production comparison 修改。

`prepare.py` 可重建这些草稿及从既有实际 JSON 得到的诊断；其行为只是 Python JSON/文本处理。根智能体若已开始独占 CI，不应再运行本脚本或编辑所提交的输入。
