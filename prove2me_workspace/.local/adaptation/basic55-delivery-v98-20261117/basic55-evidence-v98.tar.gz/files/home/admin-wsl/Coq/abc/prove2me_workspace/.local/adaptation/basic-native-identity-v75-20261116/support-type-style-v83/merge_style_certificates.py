#!/usr/bin/env python3
"""Merge exact support style contracts into a *new* bound CI config. No CI/API/Git."""
import argparse,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--bound-config',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
assert a.output.resolve()!=a.bound_config.resolve(), 'Write a new config; preserve the failed attempt input.'
c=json.loads(a.bound_config.read_text());d=json.loads((Path(__file__).parent/'support-type-style-certificates.draft.json').read_text())
assert c['schema']=='Basic-native-comparison-config/v63'
for r in d['supportTheoremTypeStyleCertificates']:
 for side,tag in [('source','sourceFactsBinding'),('native','nativeFactsBinding')]:
  binding=c[tag]
  assert binding['sha256']==r[side+'FactsSHA256']
  actual=hashlib.sha256(Path(binding['path']).read_bytes()).hexdigest();assert actual==binding['sha256']
  assert json.loads(Path(binding['path']).read_text())==binding['contents']
 assert r['certificateKernelChecked'] is False
c.update(d)
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(c,ensure_ascii=False,separators=(',',':'))+'\n')
print(a.output)
