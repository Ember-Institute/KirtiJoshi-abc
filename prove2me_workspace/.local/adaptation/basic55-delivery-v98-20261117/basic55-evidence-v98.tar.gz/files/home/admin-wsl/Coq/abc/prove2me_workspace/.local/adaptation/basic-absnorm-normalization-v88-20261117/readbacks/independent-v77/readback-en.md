# Independent formal-data readback — English

Reader model: `gpt-6.1-sol`. This is a readback of the data definition `AbcAdaptation.Tripod.tripodTheory` and the actual definitions it uses. The declaration packages existing data and degree identities as a height-theory structure. It does not state or prove a new height inequality or an arithmetic conjecture.

The declaration is a fixed noncomputable object, with no explicit or implicit mathematical parameters and no external type-class hypotheses. Its type is the height-theory structure at the universe of small types. Its curve-index type is the one-element type `Unit`, whose unique element is denoted $*$. The distinguished index `tripod` is $*$. For every curve index, the predicate `Hyperbolic` is the proposition True, and `DivisorFree` is the proposition False. Thus the first predicate holds at the unique index by the proof of True. The definition does not construct a projective line, a divisor, or a geometric test for either predicate; the words used to name the fields do not add such data or tests.

Let $\overline{ℚ}$ denote the specified algebraic closure `AlgebraicClosure ℚ`. At the unique curve index, the point type is

$$
\mathcal P=\{z∈\overline{ℚ}:z≠0\text{ and }z≠1\}.
$$

A point is an algebraic-closure element together with witnesses of these two inequalities. No quotient by conjugacy or by a choice of field of definition is taken, and no extra point at infinity is adjoined. For such an element $z$, let $n_z$ be the degree of its minimal polynomial over $ℚ$, let $F_z=ℚ(z)⊆\overline{ℚ}$ be the simple intermediate field, and let $g_z∈F_z$ be its generator, whose image in $\overline{ℚ}$ is $z$. The imported definitions provide $n_z>0$ and $n_z=[F_z:ℚ]$, and make $F_z$ a number field.

For every natural number $d$, the subsets assigned to the unique index are

$$
\mathrm{ptLE}(*,d)=\{x∈\mathcal P:n_x≤d\},\qquad
\mathrm{ptEQ}(*,d)=\{x∈\mathcal P:n_x=d\}.
$$

The structure's required identities are supplied by the existing proofs that the first subset is empty for $d=0$ and that $\mathrm{ptLE}(*,d+1)=\mathrm{ptLE}(*,d)∪\mathrm{ptEQ}(*,d+1)$. Natural numbers here include zero; the use of a finite degree bound does not assert that the set of points with that bound is finite.

The three functions assigned at this same index have domain $\mathcal P$ and codomain $ℝ$. They are, for $x$ represented by $z$,

$$
h(x)=\frac{\mathrm{Height.logHeight}_1(g_z)}{n_z},\qquad
δ(x)=\frac{\log|\operatorname{disc}(F_z)|}{n_z},\qquad
κ(x)=\frac{1}{n_z}\sum_{v∈B_z}\log N(\mathfrak p_v),
$$

and correspond respectively to the fields `htCan`, `logDiff`, and `logCond`. The discriminant is the number-field discriminant, cast from integers to reals before taking its absolute value. For a finite place $v$ of $F_z$, $\mathfrak p_v$ is its associated prime ideal in the ring of integers, and $N(\mathfrak p_v)$ is its absolute ideal norm, cast to a real number. The finite set of places used in the conductor formula is

$$
B_z=\{v:\ v(g_z)≠1\text{ or }v(g_z-1)≠1\}.
$$

Here finite places act as positive real multiplicative absolute values on nonzero elements, not as additive valuations. The imported code establishes finiteness of $B_z$ for the points in $\mathcal P$ and expresses its finite-support sum as the displayed finite sum. Each bad place contributes its norm logarithm once; this formula does not attach an additional ramification multiplicity to that contribution. All three denominators are positive because $n_z>0$.

To specify the height normalization completely, the imported number-field height is the logarithm of the product of $\max(w(g_z),1)^{m_w}$ over the infinite places $w$ of $F_z$ and $\max(v(g_z),1)$ over its finite places $v$. Here $m_w$ is the usual multiplicity of the infinite place (one for a real place and two for a complex place); the product over finite places has finite multiplicative support. Division by $n_z$ in $h$ is performed after taking this logarithm. The construction therefore uses the generator in its own number field and this precise degree normalization, rather than introducing a height as a new arbitrary function. The imported module also supplies nonnegativity results for $h,δ,κ$; the present declaration simply uses their definitions as structure fields.

The type assigned to the field `CBS` consists of records $K=(V,c)$ together with proofs that $V$ is a finite set of natural primes and $2∈V$, where $c∈ℝ$. There is no requirement $c≥0$ or $c>0$. These records are the objects labelled “compactly bounded subsets” in the code. For each such record, the field `cbsSet` assigns the following subset of $\mathcal P$:

$$
\begin{aligned}
S_{V,c}=\{x∈\mathcal P:\;&\text{for every finite place }v\text{ of }F_z,
\ p_v∈V\Rightarrow
|\log v(g_z)|≤c\ \text{and}\ |\log v(g_z-1)|≤c;\\
&\text{and for every infinite place }w\text{ of }F_z,
|\log w(g_z)|≤c\ \text{and}\ |\log w(g_z-1)|≤c\},
\end{aligned}
$$

where $z$ represents $x$ and $p_v$ is the characteristic of the actual quotient $\mathcal O_{F_z}/\mathfrak p_v$. Infinite places also act as multiplicative absolute values. The same $c$ applies to both expressions, all the indicated places, and every point of this assigned subset, even though the number field varies with the point. The finite-place conditions apply to **every** place whose residue characteristic belongs to $V$. No condition is imposed here at finite places outside $V$. There is no degree bound in the definition of $S_{V,c}$ itself. Since $z$ and $z-1$ are nonzero, the logarithms in these membership conditions have positive arguments; negative values of $c$ are permitted as data, without an assumption that the assigned subset is nonempty.

The field `cbsSet` is this explicit membership construction from records to subsets; the record type is not defined as the collection of all topologically compact subsets. No topology, compactness proof, additional support set $Σ$, or proof of a correspondence with such a geometric notion is added by this declaration. The structure contains exactly the selected point and degree data, three functions, constant predicates, distinguished index, record type and subset map described above. Statements named `StatementI` or `StatementII` occur in an imported module as separate propositions; their presence does not turn this data constructor into a proof of either proposition.
