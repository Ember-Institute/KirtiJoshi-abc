#!/usr/bin/env python3
"""Bind actual source/native facts and receipts. No compilation, API or Git."""
from pathlib import Path
import argparse,json,hashlib
D=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def receipt(p,key,config):
 r=read(p);assert r['status']=='succeeded'and r['result']['exit_code']==0
 assert r['request']['exclusive']is True and r['result']['snapshot']['workspace_mode']=='exclusive_worktree'and r['result']['snapshot']['snapshot_id']is None
 cfg=Path(r['request']['environment'][key]);assert read(cfg)==config
 assert r['request']['worktree_manifest']['input_hashes'][str(cfg)]==sha(cfg)
 return {'path':str(Path(p).resolve()),'sha256':sha(p),'contents':r}
ap=argparse.ArgumentParser();ap.add_argument('--source-facts',required=True,type=Path);ap.add_argument('--source-receipt',required=True,type=Path);ap.add_argument('--native-facts',required=True,type=Path);ap.add_argument('--native-receipt',required=True,type=Path);ap.add_argument('--out',type=Path,default=D/'configs/comparison.bound.json');a=ap.parse_args()
s,n=read(a.source_facts),read(a.native_facts)
assert s['schema']=='Basic99-source-enriched/v63'and s['actualOwnedCount']==99 and s['sourceModule']==[[[[],'str','Iut'],'str','Tripod'],'str','Basic']
assert n['schema']=='Basic-native-actual-inventory/v63'
assert n['unresolvedCandidateTargets']==[]and n['proofSupportDiscoveryDeferredForUnresolvedMapping']is False, 'Native generated mapping remains pending; inspect actual owner index instead of guessing Names'
sr=receipt(a.source_receipt,'BASIC_SOURCE_ENRICH_CONFIG',s['configuration']);nr=receipt(a.native_receipt,'BASIC_NATIVE_INVENTORY_CONFIG',n['configuration'])
plan=read(D/'source99-coverage-plan.json');selected=[r for r in plan['rows']if r['role']in ['existing-native-correspondence-candidate','new-data-constructor-candidate']]
assert len(selected)==55
actual={json.dumps(r['sourceNameExpr']):r for r in n['actualNameMapCandidates']}
for r in selected:
 p=actual[json.dumps(r['sourceNameExpr'])];assert p['sourceName']==r['sourceName']and p['targetName']==r['targetNameCandidate']and p['targetOwner']==r['targetOwnerCandidate']
# Exact Name components from native index are mandatory. Candidate strings are never decoded as native Names.
assert all(isinstance(r['targetNameExpr'],list)for r in n['actualNameMapCandidates'])
known={json.dumps(r['sourceNameExpr'])for r in n['actualNameMapCandidates']}|{json.dumps(r['targetNameExpr'])for r in n['actualNameMapCandidates']}
sourceproofs={json.dumps(r['nameExpr'])for r in s['closedSourceProofSupport']};nativeproofs={json.dumps(r['nameExpr'])for r in n['closedNativeProofSupport']}
def nm(v):return ''if not v else nm(v[0])+('.'if v[0]else'')+str(v[2])
def used(e):
 result=[]
 def visit(x):
  if isinstance(x,dict):
   if x.get('kind')in ['const','proj']and nm(x['name']).startswith(('Iut.','Genl.','AbcAdaptation.','_private.')):result.append(x['name'])
   for y in x.values():visit(y)
  elif isinstance(x,list):
   for y in x:visit(y)
 visit(e);return result
for facts,proofs,roots in [(s,sourceproofs,{r['sourceName']for r in selected}),(n,nativeproofs,{actual[json.dumps(r['sourceNameExpr'])]['targetName']for r in selected})]:
 for r in facts['records']:
  if r['name']not in roots:continue
  for key in ['elaboratedExpr','valueExpr','recursorRuleRhs']:
   for dep in used(r[key]):assert json.dumps(dep)in known|proofs,('Unmapped selected Expr dependency',r['name'],nm(dep))
 for r in facts.get('closedSourceProofSupport',facts.get('closedNativeProofSupport',[])):
  assert r['isClosed']and r['isProposition']and r['levelParams']==[]
  for key in ['axioms','typeAxioms','proofAxioms']:assert set(r[key])<={'propext','Classical.choice','Quot.sound'}
  for key in ['actualTypeExpr','actualProofExpr']:
   for dep in used(r[key]):assert json.dumps(dep)in known|proofs,('Unmapped genuine proof support',r['name'],nm(dep))
c={'schema':'Basic-native-comparison-config/v63','sourceEnrichedFacts':str(a.source_facts.resolve()),'nativeInventoryFacts':str(a.native_facts.resolve()),'selectedSourceNames':[r['sourceNameExpr']for r in selected],'sourceFactsBinding':{'path':str(a.source_facts.resolve()),'sha256':sha(a.source_facts),'contents':s,'receipt':sr},'nativeFactsBinding':{'path':str(a.native_facts.resolve()),'sha256':sha(a.native_facts),'contents':n,'receipt':nr},'outputFile':str(D/'actual/comparison.json'),'full99IntegrationClaimed':False,'closedProofExpansionPermittedOnlyForActualClosedPropValues':True,'status':'Bound inputs only; actual kernel comparison must run through root CI.'}
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(a.out,sha(a.out))
