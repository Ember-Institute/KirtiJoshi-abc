# 单一 torsion Prop 证明归一化草稿 v97

本目录的 source query、source config、target patch、binder 已冻结；主智能体已接收 SHA。子智能体未编译、未调用 CI/API/Git、未修改主工作区。

## 范围

原四个 absNorm → cardQuot 完整表达式归一化保持。只有 `Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal` 的 TYPE，在 absNorm 归一化后，将唯一饱和的 `instIsTorsionFreeIntOfHasUniqueDiv` 应用替换为同一实际 `Module.IsTorsionFree` 命题的既有 `Module.Free.instIsTorsionFree` 证明。

这不映射新版 IsAddTorsionFree，不声称新 IsAddFG 与旧 AddMonoid.FG 的类 TYPE 相等，不接受未核验的库名迁移。此前 narrow-audit-v96 整类迁移方向已暂停，不能作为 55 项比较的映射输入。

## 源生产器

`QuerySourceAbsNormAndTorsionProofNormalization.lean` 复用原已成功 source query 的 codec、normalizeAbsNorm、certify、libraryRecord。配置环境仍为 `BASIC_ABSNORM_EXPORT_CONFIG`，配置 schema 仍 v85；输出 schema 明确为 `Basic-absNorm-and-torsionProp-normalization-actual/v97`，文件名全新。

构造候选时，从实际 Free theorem 的 telescope 创建 metavariables，并先以原 proof 的完整 inferred TYPE 固定 R、M 和现有结构参数。此后只允许合成唯一尚未解的 Module.Free instance 参数；拒绝额外 data 或其他 class 参数。候选完全实例化后再次确认 TYPE 一致。

Meta.transform 打开原有 binder。原 proof、候选 proof、它们的 inferred TYPE 和原实参都在实际局部上下文下通过 mkLambdaFVars 重新关闭，再提交 Kernel.check/Kernel.isDefEq；还构造完整关闭 proof 的 Eq.refl 证书。最终仍执行原有 `certify(raw, finalNormalized)`，证明原完整数学 TYPE 与最终完整 TYPE 内核定义相等。

输出仍有四条 reports 和原四条 libraryDeclarations。额外字段保留：

- 唯一 proof 替换的完整原/new proof、TYPE、三个原始实参、Free 应用的全部实参、同命题内核检查及显式 equality proof。
- 实际 Free theorem 和它实际调用的 Basis.isTorsionFree 的完整 TYPE/value、标准公理及源内核检查结果；二者 actual body 都检查不包含原三个 torsion API 常量。
- 原三个 torsion theorem 的完整 TYPE/value 和源内核检查，保留原始 API 证据。

Free theorem 两端源码相同：取实际 basis 后使用 b.isTorsionFree；后者通过 basis repr 的单射构造。源 NumberField.Basic 已有 Free ℤ (𝓞 K)。此归一化构造不合成 IsTorsionFree，也不以当前旧 torsion proof 作候选的前提。

## 绑定与目标消费

`bind_absnorm_and_torsionProp_comparison.py` 延续旧脚本的成功 receipt、exclusive 工作区、实际 lean 参数、输入 hashes、factsSHA 和内容绑定检查。它严格核对四个指定原字段、原 raw Expr、原四个 norm library 行，以及唯一 proof 替换法律证据；新增三个旧 API 在原 TYPE 各出现一次、最终 TYPE 各为零，而实际 Free theorem 恰出现一次。它将成功生产器输出作为精确 source binding，不改 source facts 或 55 项选择。

使用方法与旧 binder 相同，传 `--bound-config`、`--source-actual`、`--source-receipt`、`--output`；必须使用新输出 config，保留旧配置。

`target-sameProp-consumer-v97.patch` 明确接受新 v97 schema 并检查唯一 proof law。目标继续仅 live normalizeAbsNorm，并使用其原有完整 kernel TYPE/计算值、BinderInfo、structure、recursor、公理核验。源 normalized complete TYPE 中，旧三个名字必须全部消失，Free theorem 必须存在。完整 cross-kernel TYPE 比较利用 Lean 的证明无关性；没有第二次目标 proof 改写。

原三个 raw TYPE 风格合同的原始 Expr、binder diagnostics、源/目标事实 SHA、完整 public input TYPE 和显式 equality proof 检查不变。其余 52 项、39 个数据值和全部 55 TYPE 的检查也不变。

Python binder 已通过 py_compile；Lean 草稿的正确性与资源数据以主智能体的新 MCP-CI 回执为准。窄核验通过不代表完整数学父义务或整个项目已完成。
