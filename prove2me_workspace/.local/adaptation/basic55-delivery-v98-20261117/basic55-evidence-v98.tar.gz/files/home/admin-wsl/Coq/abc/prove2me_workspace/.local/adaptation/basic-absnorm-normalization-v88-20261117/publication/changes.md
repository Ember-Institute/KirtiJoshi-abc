# v85 三语定义 payload 修订记录

交付：[payload.json](/tmp/p2m-tripod-metadata-finish-v85-20261117/payload.json)。这是供主智能体后续实际 kernel gate 使用的纯定义草稿；本任务没有编译、调用 MCP-CI 或平台接口、执行 Git，也没有修改主工作区。门禁状态保存在 [metadata.json](/tmp/p2m-tripod-metadata-finish-v85-20261117/metadata.json:5)，不放进平台正文。

| 修订 | 可核对证据 |
| --- | --- |
| payload 仅含 `definition_name`、`definition_title`、`definition`、`natural_language_statement`、`source`、`env`、`private` 七个字段；移除本地控制字段 `status` 和重复的 `lean_code`。节点名、标题、环境与可见性沿用 v81。 | [文字与字节检查](/tmp/p2m-tripod-metadata-finish-v85-20261117/validation.json:3) |
| `definition` 直接读取当前目标的 UTF-8 字节，保留末尾换行；共 1439 字节，SHA-256 为 `a9e22491aabe84d68e3ea4c01b813dc0a2de106c85bf78d484b52b8dc668c5e6`。 | [目标字节证据](/tmp/p2m-tripod-metadata-finish-v85-20261117/metadata.json:27)；[实际目标](/home/admin-wsl/Coq/abc/prove2me_workspace/Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean:1) |
| 三语正文依据 v77 独立英文读回及其中文、日语译文编辑；不修改原件，不将编辑稿冒称新的独立审读。审读模型、译文角色、路径和哈希移入 metadata。 | [独立原始读回](/tmp/p2m-tripod-theory-blind-readback-v77-20261116/readback-en.md:1)；[原始输入清单](/tmp/p2m-tripod-theory-blind-readback-v77-20261116/manifest.json:1)；[当前编辑稿来源记录](/tmp/p2m-tripod-metadata-finish-v85-20261117/metadata.json:45) |
| 正文保留 `Unit`、`True`／`False`、点集、数域与次数、次数过滤恒等式，以及三个函数的定义域、陪域和精确公式。另补明 `n_x=n_z`，用统一记号 `H_{F_z}(g_z)` 展开原高度的乘积公式；三语完全采用同一高度公式。 | [英文数学定义](/tmp/p2m-tripod-metadata-finish-v85-20261117/natural-language-statement.md:3)；[中文数学定义](/tmp/p2m-tripod-metadata-finish-v85-20261117/natural-language-statement.md:90)；[日文数学定义](/tmp/p2m-tripod-metadata-finish-v85-20261117/natural-language-statement.md:169) |
| 子集公式明确写出有限处条件中蕴含号的作用范围，保留有限素数集含 2、任意实数界、所选素数上方的每个有限处、每个无限处、统一界、外部有限处无条件、无次数界及允许空集等全部条件。记录类型不是全体拓扑紧子集，也不附加几何构造、紧性证明或额外支撑参数。 | 同上三语数学定义；[逐项修订说明](/tmp/p2m-tripod-metadata-finish-v85-20261117/metadata.json:174) |
| 英文保留二〇〇九年二月版定理 2.1(ii) 第 11 页的完整原文分项，引文与既有 `quoteMarkdown` 完全一致；三语区分数学定义、论文来源及非严格直观解释。来源限制包括该分项是等价定理中的猜想条件，本定义不证明该条件或几何识别。没有重新宣称视觉核对。 | [英文来源及原文引文](/tmp/p2m-tripod-metadata-finish-v85-20261117/natural-language-statement.md:68)；[既有引文记录](/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/statementii-definition-v65-20261116/paper/context.json:1)；[版本、页序、PDF 及引文证据](/tmp/p2m-tripod-metadata-finish-v85-20261117/metadata.json:75) |
| 平台正文移除 CI、pending、55 kernel 进度、内部文件名和读者模型叙述；保留数学范围限制。中文沿用 `[术语待定：compactly bounded subset]`，不重新提问；日语沿用「コンパクト有界部分集合」，作者写作「望月新一」。 | [术语状态](/tmp/p2m-tripod-metadata-finish-v85-20261117/metadata.json:164)；[原有术语依据](/tmp/p2m-tripod-theory-blind-readback-v77-20261116/terminology-and-scope.md:1) |

核对结果：11 项文字／字节检查为真；三份本地形式输入、三份语义相关 Mathlib 源码、固定 PDF、原始文字提取件和第 11 页引文记录，共九项现行哈希与原记录一致。详见 [validation.json](/tmp/p2m-tripod-metadata-finish-v85-20261117/validation.json:1) 和 [input-hash-checks.json](/tmp/p2m-tripod-metadata-finish-v85-20261117/input-hash-checks.json:1)。这些检查不构成编译、内核比较或新的独立数学审查。

payload SHA-256：`60401b2435f271c53b55eb334942d755ee8d1869dc1f478e1d077a9ff1879f53`。
