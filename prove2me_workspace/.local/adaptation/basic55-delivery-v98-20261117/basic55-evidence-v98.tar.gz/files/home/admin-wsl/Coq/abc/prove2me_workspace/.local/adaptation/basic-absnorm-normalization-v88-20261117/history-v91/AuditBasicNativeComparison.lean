import Lean
import ArithmeticTeichmullerSpaces.Prologue.Audit.Checks
import ArithmeticTeichmullerSpaces.Prologue.Audit.ImportAudit
import ArithmeticTeichmullerSpaces.Act1Scene1
import ArithmeticTeichmullerSpaces.Prologue.Audit.AxiomAudit
import Definitions.Def_AbcTripod
import Definitions.Def_TripodStatementIIInputs
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_Theory
import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]

def validateSupport (maps : NameMap) (rows : Array Json) : MetaM Unit := do
  for p in rows do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) && (← checked (p.getObjValAs? Bool "isClosed")) && (← checked (arrayField p "levelParams")).isEmpty do
      throwError "Invalid actual closed proof support {n}"
    let t ← checked (relocateExpr maps rows #[] true (← checked (field p "actualTypeExpr")))
    let v ← checked (relocateExpr maps rows #[n] true (← checked (field p "actualProofExpr")))
    let vt ← kernelCheck s!"proof support {n}" v
    unless ← isProp vt do throwError "Support proof would replace data {n}"
    kernelEq s!"proof support TYPE {n}" vt t
    ensureStandard s!"expanded proof support {n}" (← expressionAxioms v)

-- Recognize only actual Nat-valued applications. No Infinite-to-Free translation.
-- Meta.transform opens binders before whnf / isDefEq and reabstracts them.
def normalizeAbsNorm (raw : Expr) : MetaM Expr := do
  let hits ← IO.mkRef (0 : Nat)
  let normalized ← Meta.transform raw (pre := fun e => do
    let args := e.getAppArgs
    if e.getAppFn.isConstOf ``DFunLike.coe && args.size == 6 then
      let hom := args[4]!
      if hom.getAppFn.isConstOf ``Ideal.absNorm && hom.getAppNumArgs == 4 then
        -- Delta-expand only the actual bundled norm. Reduce its coercion/projections
        -- under reducible+instances transparency, which leaves cardQuot opaque.
        -- Thus every original argument participates in real Lean reduction.
        let some expanded ← unfoldDefinition? hom (ignoreTransparency := true)
          | throwError "Cannot delta-expand actual absNorm"
        let projected := mkAppN e.getAppFn (args.set! 4 expanded)
        let candidate ← withReducibleAndInstances <| whnf projected
        unless candidate.getAppFn.isConstOf ``Submodule.cardQuot do
          throwError "absNorm projection did not reduce to cardQuot"
        unless ← isDefEq e candidate do
          throwError "absNorm projection is not definitionally cardQuot"
        hits.modify (· + 1)
        return .done candidate
    if e.getAppFn.isConstOf ``Ideal.absNorm then
      throwError "Unsupported unsaturated or whole-hom absNorm occurrence"
    return .continue)
  unless (← hits.get) == 1 do throwError "Expected exactly one saturated absNorm application"
  unless !(normalized.getUsedConstants.contains ``Ideal.absNorm) do
    throwError "absNorm remains in normalized Expr"
  requireClosed "normalized complete Expr" normalized
  return normalized

def certify (raw normalized : Expr) : MetaM Json := do
  kernelEq "complete original/normalized Expr" raw normalized
  let equality ← mkEq raw normalized
  let proof ← mkEqRefl raw
  let pt ← kernelCheck "complete normalization equality proof" proof
  kernelEq "complete normalization equality proposition" pt equality
  ensureStandard "complete normalization equality proof" (← expressionAxioms proof)
  return Json.mkObj [
    ("originalExpr",← checked (encodeExpr raw)),
    ("normalizedExpr",← checked (encodeExpr normalized)),
    ("equalityExpr",← checked (encodeExpr equality)),
    ("equalityProofExpr",← checked (encodeExpr proof)),
    ("completeExprKernelDefEq",toJson true),
    ("completeEqualityProofKernelChecked",toJson true),
    ("axioms",toJson ((← expressionAxioms proof).map Name.toString))]



-- The source normalization producer is accepted only after its own source4.35 CI
-- receipt. Bind that exact output in config; foreign raw equality proofs are
-- retained as evidence and are deliberately not relocated to target4.33.
def sourceNormalizedField (normalization : Json) (s : Name) (fld : String)
    (raw : Json) : MetaM Json := do
  let rows ← checked (arrayField normalization "reports")
  let rows := rows.filter fun r =>
    (field r "nameExpr").toOption == some (encodeName s) &&
    (field r "field").toOption == some (toJson fld)
  unless rows.size == 1 do throwError "Missing exact source normalization {s} {fld}"
  let cert ← checked (field rows[0]! "certificate")
  unless (← checked (field cert "originalExpr")) == raw do
    throwError "Source normalization raw Expr changed {s} {fld}"
  unless (← checked (cert.getObjValAs? Bool "completeExprKernelDefEq")) &&
      (← checked (cert.getObjValAs? Bool "completeEqualityProofKernelChecked")) &&
      (← checked (rows[0]!.getObjValAs? Nat "saturatedAbsNormUses")) == 1 do
    throwError "Missing source normalization certificate {s} {fld}"
  return ← checked (field cert "normalizedExpr")

def normalizeTypeName (s : Name) : Bool :=
  #[`Iut.Tripod.logCond_eq_sum, `Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal,
    `Iut.Tripod.one_le_absNorm_real].contains s

-- Each live target normalization and its complete kernel certificate receives
-- its own command heartbeat budget. The main audit reuses only an exact raw Expr.
private structure TargetNormalizationEntry where
  actualName : Name
  field : String
  originalExpr : Expr
  normalizedExpr : Expr
  certificate : Json

private initialize targetNormalizationCache : IO.Ref (Array TargetNormalizationEntry) ← IO.mkRef #[]

private def prepareTargetNormalization (actualName : Name) (fld : String) : MetaM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected target4.33.1"
  let ci ← getConstInfo actualName
  let raw ← match fld with
    | "elaboratedExpr" => pure ci.type
    | "valueExpr" => do
      let some value := ci.value? (allowOpaque := true)
        | throwError "Missing native data value {actualName}"
      pure value
    | _ => throwError "Unsupported target normalization field {fld}"
  let normalized ← normalizeAbsNorm raw
  let certificate ← certify raw normalized
  targetNormalizationCache.modify fun rows => rows.push {
    actualName := actualName, field := fld, originalExpr := raw,
    normalizedExpr := normalized, certificate := certificate }

private def cachedTargetNormalization (actualName : Name) (fld : String)
    (raw : Expr) : MetaM (Expr × Json) := do
  let some entry := (← targetNormalizationCache.get).find? fun entry =>
      entry.actualName == actualName && entry.field == fld
    | throwError "Missing live target normalization {actualName} {fld}"
  -- Expr's BEq ignores binder annotations. Use full structural equality here.
  unless Expr.equal raw entry.originalExpr do
    throwError "Live target normalization raw Expr changed {actualName} {fld}"
  return (entry.normalizedExpr, entry.certificate)

run_meta do
  prepareTargetNormalization ``AbcAdaptation.Tripod.logCond "valueExpr"

run_meta do
  prepareTargetNormalization ``AbcAdaptation.Tripod.logCond_eq_sum "elaboratedExpr"

run_meta do
  prepareTargetNormalization ``AbcAdaptation.Tripod.logDiff_eq_log_absNorm_differentIdeal "elaboratedExpr"

run_meta do
  prepareTargetNormalization ``AbcAdaptation.Tripod.one_le_absNorm_real "elaboratedExpr"

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected target4.33.1"
  let cfg ← jsonFile (← absoluteEnv "BASIC_NATIVE_COMPARE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "Basic-native-comparison-config/v63" do throwError "Wrong comparison config"
  let source ← jsonFile (← checked (stringField cfg "sourceEnrichedFacts"))
  let native ← jsonFile (← checked (stringField cfg "nativeInventoryFacts"))
  let sb ← checked (field cfg "sourceFactsBinding")
  let nb ← checked (field cfg "nativeFactsBinding")
  unless source == (← checked (field sb "contents")) && native == (← checked (field nb "contents")) do
    throwError "Bound actual facts changed"
  unless (← checked (arrayField native "unresolvedCandidateTargets")).isEmpty do
    throwError "Native actual Name map still has unresolved candidates"
  let sourceRows ← checked (arrayField source "records")
  let pairs ← checked (arrayField native "actualNameMapCandidates")
  let mut maps : NameMap := #[]
  for p in pairs do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    maps := maps.push (s,t)
    unless maps.any (·.1 == t) do maps := maps.push (t,t)
  let sourceProofs ← checked (arrayField source "closedSourceProofSupport")
  let nativeProofs ← checked (arrayField native "closedNativeProofSupport")
  validateSupport maps sourceProofs
  validateSupport maps nativeProofs
  let forward (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then throw s!"Unmapped structural name {n}"
    return n
  let normalizationBinding ← checked (field cfg "sourceAbsNormNormalizationBinding")
  let sourceNormalization ← jsonFile (← checked (stringField normalizationBinding "path"))
  unless sourceNormalization == (← checked (field normalizationBinding "contents")) do
    throwError "Bound source normalization changed"
  unless (← checked (stringField sourceNormalization "schema")) == "Basic-absNorm-normalization-actual/v85" &&
      (← checked (stringField sourceNormalization "compilerVersion")) == "4.35.0-rc3" &&
      (← checked (field sourceNormalization "factsSHA256")) == (← checked (field sb "sha256")) &&
      (← checked (arrayField sourceNormalization "reports")).size == 4 do
    throwError "Wrong source normalization binding"
  for row in ← checked (arrayField sourceNormalization "reports") do
    let n ← checked (decodeName (← checked (field row "nameExpr")))
    let fld ← checked (stringField row "field")
    unless (normalizeTypeName n && fld == "elaboratedExpr") ||
        (n == `Iut.Tripod.logCond && fld == "valueExpr") do
      throwError "Unexpected source normalization field {n} {fld}"
  let selected ← namesFromJson (← checked (field cfg "selectedSourceNames"))
  let mut reports : Array Json := #[]
  for s in selected do
    let sourceRowMatches := sourceRows.filter fun r => (field r "nameExpr").toOption == some (encodeName s)
    unless sourceRowMatches.size == 1 do throwError "Missing actual source row {s}"
    let r := sourceRowMatches[0]!
    let t ← checked (forward s)
    let ci ← getConstInfo t
    unless (← checked (stringField r "constantKind")) == kind ci do throwError "Constant kind differs {s}"
    let ps ← namesFromJson (← checked (field r "levelParams"))
    unless ps.length == ci.levelParams.length do throwError "Universe arity differs {s}"
    let us := (List.range ps.length).map fun i => Level.param (.num (.str .anonymous "_BasicComparisonUniverse") i)
    let decode (j : Json) (proofs : Array Json) (expand : Bool) := checked (relocateExpr maps proofs #[] expand j)
    let rawSourceType ← checked (field r "elaboratedExpr")
    let sourceType ← if normalizeTypeName s then
      sourceNormalizedField sourceNormalization s "elaboratedExpr" rawSourceType
      else pure rawSourceType
    let st ← decode sourceType sourceProofs true
    if normalizeTypeName s && st.getUsedConstants.contains ``Ideal.absNorm then
      throwError "Source normalized TYPE retains absNorm {s}"
    let mut targetTypeNormalization := Json.null
    let tt ←
      if normalizeTypeName s then do
        let (normalized, certificate) ← cachedTargetNormalization t "elaboratedExpr" ci.type
        targetTypeNormalization := certificate
        decode (← checked (encodeExpr normalized)) nativeProofs true
      else
        decode (← checked (encodeExpr ci.type)) nativeProofs true
    let st := st.instantiateLevelParams ps us
    let tt := tt.instantiateLevelParams ci.levelParams us
    kernelEq s!"complete source/native TYPE {s}" st tt
    let ss ← decode (← checked (field r "elaboratedExpr")) sourceProofs false
    let ts ← decode (← checked (encodeExpr ci.type)) nativeProofs false
    let signatureBinderInfoEqual :=
      binderInventory ss == binderInventory ts && binderPlacement ss == binderPlacement ts
    let mut supportTypeStyleCertificate := Json.null
    if !signatureBinderInfoEqual then
      -- Exact legacy support names only. New data roots and structure signatures stay strict.
      let allowed : Array Name := #[`Iut.Tripod.deg_eq_finrank,
        `Iut.Tripod.logCond_eq_sum, `Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal]
      unless allowed.contains s && kind ci == "theorem" && ps.isEmpty && ci.levelParams.isEmpty do
        throwError "Full signature BinderInfo differs {s}"
      unless (← isProp st) && (← isProp tt) do
        throwError "Support style certificate requires complete proposition TYPEs {s}"
      let certRows ← checked (arrayField cfg "supportTheoremTypeStyleCertificates")
      let certRows := certRows.filter fun c =>
        (field c "sourceNameExpr").toOption == some (encodeName s) &&
        (field c "targetNameExpr").toOption == some (encodeName t)
      unless certRows.size == 1 do throwError "Missing unique exact support TYPE-style contract {s}"
      let cert := certRows[0]!
      unless (← checked (stringField cert "scope")) ==
          "existing-support-theorem-type-instance-elaboration-only" do
        throwError "Wrong support TYPE-style scope {s}"
      unless (← checked (field cert "sourceFactsSHA256")) == (← checked (field sb "sha256")) &&
          (← checked (field cert "nativeFactsSHA256")) == (← checked (field nb "sha256")) do
        throwError "Support TYPE-style fact bindings changed {s}"
      let nativeRows ← checked (arrayField native "records")
      let nativeRows := nativeRows.filter fun nr =>
        (field nr "nameExpr").toOption == some (encodeName t)
      unless nativeRows.size == 1 do throwError "Missing unique bound native support record {s}"
      let boundNativeType ← checked (field nativeRows[0]! "elaboratedExpr")
      unless (← checked (field cert "sourceTypeExpr")) == (← checked (field r "elaboratedExpr")) &&
          (← checked (field cert "nativeTypeExpr")) == boundNativeType &&
          boundNativeType == (← checked (encodeExpr ci.type)) do
        throwError "Support TYPE-style actual raw Expr changed {s}"
      unless (← checked (cert.getObjValAs? (Array String) "sourceBinderInventory")) == binderInventory ss &&
          (← checked (cert.getObjValAs? (Array String) "nativeBinderInventory")) == binderInventory ts &&
          (← checked (cert.getObjValAs? (Array String) "sourceBinderPlacement")) == binderPlacement ss &&
          (← checked (cert.getObjValAs? (Array String) "nativeBinderPlacement")) == binderPlacement ts do
        throwError "Support TYPE-style raw BinderInfo diagnostics changed {s}"
      unless outerForallBinderInfo ss == #["default"] && outerForallBinderInfo ts == #["default"] do
        throwError "Support TYPE-style public quantifier signature changed {s}"
      for raw in #[ss, ts] do
        let inv := binderInventory raw
        unless (inv.filter (· == "forall:default")).size == 1 &&
            inv.all (fun bi => bi == "forall:default" || bi == "lambda:default") do
          throwError "Support TYPE-style difference is not exclusively internal default lambdas {s}"
      match st, tt with
      | .forallE _ sourceDomain _ sourceBinder, .forallE _ nativeDomain _ nativeBinder =>
        unless encodeBinder sourceBinder == encodeBinder nativeBinder do
          throwError "Support TYPE-style public BinderInfo changed {s}"
        kernelEq s!"support unchanged complete public input TYPE {s}" sourceDomain nativeDomain
      | _, _ => throwError "Support TYPE-style complete public quantifier shape changed {s}"
      -- The unchanged complete TYPE kernelEq gate has already checked st and tt above.
      -- Additionally check an explicit equality proof for those complete TYPE expressions.
      let equality ← mkEq st tt
      let equalityProof ← mkEqRefl st
      let proofType ← kernelCheck s!"support complete TYPE equality proof {s}" equalityProof
      kernelEq s!"support complete TYPE equality proposition {s}" proofType equality
      ensureStandard s!"support complete TYPE equality proof {s}" (← expressionAxioms equalityProof)
      supportTypeStyleCertificate := Json.mkObj [
        ("scope",toJson "existing-support-theorem-type-instance-elaboration-only"),
        ("source",toJson s.toString),("target",toJson t.toString),
        ("completeTypeKernelEqual",toJson true),("explicitEqualityProofKernelChecked",toJson true),
        ("completeTypeEqualityExpr",← checked (encodeExpr equality)),
        ("completeTypeEqualityProofExpr",← checked (encodeExpr equalityProof)),
        ("sourceProofValueIdentityClaimed",toJson false),
        ("rawSignatureBinderInfoEqual",toJson false),
        ("sourceBinderInventory",toJson (binderInventory ss)),
        ("nativeBinderInventory",toJson (binderInventory ts)),
        ("sourceBinderPlacement",toJson (binderPlacement ss)),
        ("nativeBinderPlacement",toJson (binderPlacement ts)),
        ("sourceOnlyBinderPaths",toJson ((binderPlacement ss).filter fun p => !(binderPlacement ts).contains p)),
        ("nativeOnlyBinderPaths",toJson ((binderPlacement ts).filter fun p => !(binderPlacement ss).contains p)),
        ("sourceFactsSHA256",← checked (field cert "sourceFactsSHA256")),
        ("nativeFactsSHA256",← checked (field cert "nativeFactsSHA256")),
        ("sourceTypeExprCanonicalSha256",← checked (field cert "sourceTypeExprCanonicalSha256")),
        ("nativeTypeExprCanonicalSha256",← checked (field cert "nativeTypeExprCanonicalSha256"))]
    unless (← checked (field r "computationShape")) == (← checked (computationShape ci (fun n => do
      if let some p := maps.find? (fun p => p.2 == n && p.1 != p.2) then return p.1
      if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then throw s!"Unmapped inverse structural name {n}"
      return n))) do throwError "Computation shape differs {s}"
    unless (← checked (r.getObjValAs? Bool "isInstance")) == Lean.Meta.isInstanceCore (← getEnv) t do throwError "Instance registration differs {s}"
    let axs ← collectAxioms t
    ensureStandard s!"target declaration {t}" axs
    ensureStandard s!"target TYPE {t}" (← expressionAxioms ci.type)
    let prop ← isProp ci.type
    unless prop == (← checked (r.getObjValAs? Bool "isProposition")) do throwError "Prop status differs {s}"
    let mut targetValueNormalization := Json.null
    let mut valueCompared := false
    let sourceValue ← checked (field r "valueExpr")
    let mut valueBinderEqual := true
    if !prop && sourceValue != Json.null then
      let some tv := ci.value? (allowOpaque := true) | throwError "Missing native data value {t}"
      let normalizedSourceValue ← if s == `Iut.Tripod.logCond then
        sourceNormalizedField sourceNormalization s "valueExpr" sourceValue
        else pure sourceValue
      let sv ← decode normalizedSourceValue sourceProofs true
      if s == `Iut.Tripod.logCond && sv.getUsedConstants.contains ``Ideal.absNorm then
        throwError "Source normalized data value retains absNorm {s}"
      let nv ←
        if s == `Iut.Tripod.logCond then do
          let (normalized, certificate) ← cachedTargetNormalization t "valueExpr" tv
          targetValueNormalization := certificate
          decode (← checked (encodeExpr normalized)) nativeProofs true
        else
          decode (← checked (encodeExpr tv)) nativeProofs true
      kernelEq s!"complete computational value {s}" (sv.instantiateLevelParams ps us) (nv.instantiateLevelParams ci.levelParams us)
      let ss ← decode sourceValue sourceProofs false
      let ns ← decode (← checked (encodeExpr tv)) nativeProofs false
      valueBinderEqual := binderInventory ss == binderInventory ns && binderPlacement ss == binderPlacement ns
      valueCompared := true
    let sourceRules ← checked (arrayField r "recursorRuleRhs")
    let mut rulesCompared := 0
    if let .recInfo ri := ci then
      unless sourceRules.size == ri.rules.length do throwError "Recursor rule count differs {s}"
      for i in [:sourceRules.size] do
        let sr ← decode sourceRules[i]! sourceProofs true
        let tr ← decode (← checked (encodeExpr ri.rules[i]!.rhs)) nativeProofs true
        kernelEq s!"recursor RHS {s}#{i}" (sr.instantiateLevelParams ps us) (tr.instantiateLevelParams ci.levelParams us)
        rulesCompared := rulesCompared + 1
    else unless sourceRules.isEmpty do throwError "Unexpected source recursor rules {s}"
    let struct ← checked (field r "structure")
    let mut structureCompared := false
    if struct != Json.null then
      let some info := getStructureInfo? (← getEnv) t | throwError "Missing target structure metadata {t}"
      let inverse (n : Name) : Except String Name := do
        if let some p := maps.find? (fun p => p.2 == n && p.1 != p.2) then return p.1
        if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then throw s!"Unmapped inverse structural name {n}"
        return n
      unless (← checked (field struct "completeMetadata")) == (← checked (structureShape info inverse)) do throwError "Complete structure metadata differs {s}"
      let aps ← checked (arrayField struct "fieldAutoParamExprs")
      unless aps.size == info.fieldInfo.size do throwError "AutoParam count differs {s}"
      for i in [:aps.size] do
        match aps[i]!, info.fieldInfo[i]!.autoParam? with
        | sj,some te =>
          if sj == Json.null then throwError "Missing source autoParam {s}"
          kernelEq s!"structure autoParam {s}#{i}" (← decode sj sourceProofs true) (← decode (← checked (encodeExpr te)) nativeProofs true)
        | sj,none => unless sj == Json.null do throwError "Missing target autoParam {s}"
      structureCompared := true
    else if (getStructureInfo? (← getEnv) t).isSome then throwError "Unexpected target structure {t}"
    reports := reports.push (Json.mkObj [
      ("source",toJson s.toString),("target",toJson t.toString),
      ("kernelTypeEqual",toJson true),("signatureBinderInfoEqual",toJson signatureBinderInfoEqual),
      ("sourceTypeNormalizationUsed",toJson (normalizeTypeName s)),
      ("sourceValueNormalizationUsed",toJson (s == `Iut.Tripod.logCond)),
      ("targetTypeNormalizationCertificate",targetTypeNormalization),
      ("targetValueNormalizationCertificate",targetValueNormalization),
      ("rawSignatureBinderDifferenceRetained",toJson (!signatureBinderInfoEqual)),
      ("supportTheoremTypeStyleCertificate",supportTypeStyleCertificate),
      ("computationalValueEqual",toJson valueCompared),("rawValueBinderInfoEqual",toJson valueBinderEqual),
      ("rawValueBinderDifferenceRetained",toJson (!valueBinderEqual)),
      ("fullValueKernelEqualityDespiteProofIrrelevance",toJson valueCompared),
      ("computationShapeEqual",toJson true),("recursorRulesCompared",toJson rulesCompared),
      ("completeStructureMetadataCompared",toJson structureCompared),
      ("axioms",toJson (axs.map Name.toString)),("hasSorryAx",toJson (axs.contains `sorryAx))])
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "Basic-existing-native-comparison/v63"),("configuration",cfg),
    ("selectedCount",toJson reports.size),("reports",Json.arr reports),
    ("sourceSupportProofsKernelChecked",toJson sourceProofs.size),
    ("nativeSupportProofsKernelChecked",toJson nativeProofs.size),
    ("all99SourceDeclarationsIntegratedClaimed",toJson false),
    ("sourceAndTargetDataReplacementUsed",toJson false),
    ("transportAssumptionsIntroduced",toJson false)]).pretty ++ "\n")
  logInfo "Selected actual source/native declarations compared; any raw computational BinderInfo differences retained explicitly"
end BasicNativeCompare

#print axioms AbcAdaptation.Tripod.tripodTheory
