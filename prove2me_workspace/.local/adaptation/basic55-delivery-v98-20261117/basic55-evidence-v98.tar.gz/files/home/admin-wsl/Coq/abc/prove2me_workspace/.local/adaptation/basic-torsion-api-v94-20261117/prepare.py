import json,hashlib
from pathlib import Path
D=Path('/tmp/p2m-torsion-api-v93-20261117'); W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation')
b=W/'basic-native-identity-v75-20261116'; cpath=b/'configs/comparison-absnorm.bound-v90.json'
c=json.loads(cpath.read_text()); sp=Path(c['sourceEnrichedFacts']);np=Path(c['nativeInventoryFacts']);zp=Path(c['sourceAbsNormNormalizationBinding']['path'])
s=json.loads(sp.read_text());n=json.loads(np.read_text());z=json.loads(zp.read_text())
def dump(p,x): (D/p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def key(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def name(x):return '' if not x else (name(x[0])+'.' if x[0] else '')+str(x[2])
def en(s):
 r=[]
 for p in s.split('.'):r=[r,'str',p]
 return r
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
selected={key(x) for x in c['selectedSourceNames']}; maps={key(x['sourceNameExpr']):x['targetNameExpr'] for x in n['actualNameMapCandidates']}
registry={}; occurrences=[]
def scan(x,scope,path,owner,parent=None):
 if isinstance(x,dict):
  if x.get('kind') in ('const','proj'):
   q=x['name'];k=key(q);r=registry.setdefault(k,{'sourceNameExpr':q,'sourceName':name(q),'targetNameExpr':maps.get(k,q),'targetName':name(maps.get(k,q)),'scopes':[]})
   if scope not in r['scopes']:r['scopes'].append(scope)
   if name(q)=='instIsTorsionFreeIntOfHasUniqueDiv':
    occurrences.append({'scope':scope,'owner':owner,'path':path,'constantExpr':x})
  if x.get('kind')=='app':
   args=[];h=x
   while h.get('kind')=='app':args.append(h['arg']);h=h['fn']
   if h.get('kind')=='const' and name(h['name'])=='instIsTorsionFreeIntOfHasUniqueDiv' and not(parent and parent.get('kind')=='app' and parent.get('fn') is x):
    occurrences.append({'scope':scope,'owner':owner,'path':path,'fullApplicationExpr':x,'argumentCount':len(args),'argumentsExpr':list(reversed(args))})
  for k,v in x.items():scan(v,scope,path+'.'+k,owner,x)
 elif isinstance(x,list):
  for i,v in enumerate(x):scan(v,scope,path+f'[{i}]',owner,x)
for i,r in enumerate(s['records']):scan(r,'source99Raw',f'records[{i}]',r['name'])
for i,r in enumerate(s['records']):
 if key(r['nameExpr']) in selected:scan(r,'selected55Raw',f'records[{i}]',r['name'])
for i,r in enumerate(s['closedSourceProofSupport']):scan(r,'closedSource9',f'support[{i}]',r['name'])
for i,r in enumerate(z['reports']):scan(r['certificate']['normalizedExpr'],'normalized4',f'reports[{i}].normalizedExpr',name(r['nameExpr'])+':'+r['field'])
# Native closed support is already expressed in target names: do not relocate it.
for i,r in enumerate(n['closedNativeProofSupport']):
 before=set(registry);scan(r,'closedNative8',f'nativeSupport[{i}]',r['name'])
 for k in set(registry)-before:
  registry[k]['targetNameExpr']=registry[k]['sourceNameExpr'];registry[k]['targetName']=registry[k]['sourceName']
normalizations={(key(r['nameExpr']),r['field']):r['certificate']['normalizedExpr'] for r in z['reports']}
for i,r in enumerate(s['records']):
 if key(r['nameExpr']) in selected:
  payload={'elaboratedExpr':normalizations.get((key(r['nameExpr']),'elaboratedExpr'),r['elaboratedExpr']), 'recursorRuleRhs':r['recursorRuleRhs'],'structure':r['structure']}
  if not r['isProposition']:payload['valueExpr']=normalizations.get((key(r['nameExpr']),'valueExpr'),r['valueExpr'])
  scan(payload,'effectiveSelected55',f'records[{i}]',r['name'])
support_names={key(r['nameExpr']) for r in s['closedSourceProofSupport']+n['closedNativeProofSupport']}
for k,r in registry.items():
 r['expandedClosedPropSupport']=k in support_names
 r['requiredForComparison']=not r['expandedClosedPropSupport'] and any(x in r['scopes'] for x in ['effectiveSelected55','closedSource9','closedNative8'])
rows=sorted(registry.values(),key=lambda r:r['sourceName'])
bindings=[{'path':str(p),'sha256':sha(p)} for p in [sp,np,zp,cpath]]
registry_doc={'schema':'Basic-constant-use-inventory-input/v93','inputs':bindings,'constantNames':rows,'source99Count':len(s['records']),'selectedCount':len(selected),'sourceSupportCount':len(s['closedSourceProofSupport']),'nativeSupportCount':len(n['closedNativeProofSupport']),'normalizedCount':len(z['reports'])}
dump('constant-use-input.json',registry_doc);dump('torsion-actual-occurrences.json',occurrences)
source_seeds=['HasUniqueDiv','IsAddTorsionFree','instIsTorsionFreeIntOfHasUniqueDiv','instIsTorsionFreeIntOfIsAddTorsionFree','HasUniqueDiv.to_isTorsionFree_nat','IsAddTorsionFree.to_isTorsionFree_nat','HasUniqueDiv.of_isTorsionFree','IsAddTorsionFree.of_isTorsionFree','IsAddTorsionFree.of_isDomain_charZero','instHasUniqueDivOfIsDomainOfCharZero','nsmul_right_injective','zsmul_right_injective']
target_seeds=['IsAddTorsionFree','HasUniqueDiv','instIsTorsionFreeIntOfIsAddTorsionFree','instIsTorsionFreeIntOfHasUniqueDiv','IsAddTorsionFree.to_isTorsionFree_nat','IsAddTorsionFree.of_isTorsionFree','IsAddTorsionFree.of_isDomain_charZero','nsmul_right_injective','zsmul_right_injective']
source_seeds += ['IsAffineAddMonoid.toHasUniqueDiv','IsAffineAddMonoid.toIsAddTorsionFree']
target_seeds += ['IsAffineAddMonoid.toHasUniqueDiv','IsAffineAddMonoid.toIsAddTorsionFree']
for which,version,seeds in [('source','4.35.0-rc3',source_seeds),('target','4.33.1',target_seeds)]:
 dump(which+'-api.config.json',{'schema':'Basic-torsion-api-export-config/v93','expectedCompilerVersion':version,'seeds':[en(x) for x in seeds],'prefixes':[en('HasUniqueDiv'),en('IsAddTorsionFree'),en('IsAffineAddMonoid')],'outputFile':str(D/(which+'-api.actual.json'))})
dump('target-inventory.config.json',{'schema':'Basic-target-constant-existence-config/v93','expectedCompilerVersion':'4.33.1','namesFile':str(D/'constant-use-input.json'),'namesFileSHA256':sha(D/'constant-use-input.json'),'namesFileBinding':registry_doc,'outputFile':str(D/'target-constant-existence.actual.json')})
codec=(W/'basic-absnorm-normalization-v88-20261117/target/AuditBasicNativeComparison.lean').read_text();codec=codec[codec.index('namespace FoundationAudit'):codec.index('end FoundationAudit')+len('end FoundationAudit')]
source_import='import Lean\nimport Iut.Tripod.Basic\n\n'
target_import=(W/'basic-absnorm-normalization-v88-20261117/target/AuditBasicNativeComparison.lean').read_text().split('/-!')[0]
api='''
namespace TorsionAPIExport
open Lean Elab Term Meta FoundationAudit

def exportOne (n : Name) : MetaM Json := do
  let env ← getEnv
  let some ci := env.find? n | return Json.mkObj [("requestedNameExpr",encodeName n),("requestedName",toJson n.toString),("exists",toJson false)]
  let val := ci.value? (allowOpaque := true)
  let axs ← collectAxioms n
  let va ← match val with | some v => expressionAxioms v | none => pure #[]
  let vj ← match val with | some v => checked (encodeExpr v) | none => pure Json.null
  let rules ← match ci with
    | .recInfo ri => ri.rules.toArray.mapM fun r => checked (encodeExpr r.rhs)
    | _ => pure #[]
  let shape ← match getStructureInfo? env n with
    | some info => checked (structureShape info pure)
    | none => pure Json.null
  let owner := (moduleOf env n).map Name.toString
  return Json.mkObj [
    ("requestedNameExpr",encodeName n),("actualNameExpr",encodeName ci.name),
    ("actualName",toJson ci.name.toString),("exists",toJson true),
    ("owner",toJson owner),("ownerNameExpr",((moduleOf env n).map encodeName).getD Json.null),
    ("constantKind",toJson (kind ci)),("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("actualTypeExpr",← checked (encodeExpr ci.type)),("actualValueExpr",vj),
    ("typeDisplay",toJson (← ppExpr ci.type).pretty),
    ("isProposition",toJson (← isProp ci.type)),("isInstance",toJson (Lean.Meta.isInstanceCore env n)),
    ("valueAvailable",toJson val.isSome),("axioms",toJson (axs.map Name.toString)),
    ("typeAxioms",toJson ((← expressionAxioms ci.type).map Name.toString)),
    ("valueAxioms",toJson (va.map Name.toString)),("hasSorryAx",toJson (axs.contains `sorryAx)),
    ("computationShape",← checked (computationShape ci pure)),("structure",shape),
    ("recursorRuleRhs",Json.arr rules)]

run_meta do
  let cfg ← jsonFile (← absoluteEnv "BASIC_TORSION_API_CONFIG")
  unless (← checked (stringField cfg "schema")) == "Basic-torsion-api-export-config/v93" do throwError "Wrong API config"
  unless Lean.versionString == (← checked (stringField cfg "expectedCompilerVersion")) do throwError "Compiler version mismatch"
  let seeds ← namesFromJson (← checked (field cfg "seeds"))
  let prefixes ← namesFromJson (← checked (field cfg "prefixes"))
  let env ← getEnv
  let family := env.constants.fold (fun acc n _ =>
    if prefixes.any (·.isPrefixOf n) then acc.push n else acc) (#[] : Array Name)
  let mut names := seeds.toArray
  for n in family do
    unless names.contains n do names := names.push n
  let rows ← (names.qsort Name.lt).mapM exportOne
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "Basic-torsion-api-actual/v93"),("compilerVersion",toJson Lean.versionString),
    ("configuration",cfg),("records",Json.arr rows),
    ("foreignExprDecoded",toJson false),("foreignExprKernelChecked",toJson false),
    ("renameOrSubstitutionAccepted",toJson false)]).pretty ++ "\\n")
end TorsionAPIExport
'''
for which,imports in [('source',source_import),('target',target_imports if False else target_import)]:
 (D/('Query'+which.title()+'TorsionAPI.lean')).write_text(imports+codec+'\n'+api)
inv='''
namespace TargetConstantExistence
open Lean Elab Term Meta FoundationAudit
run_meta do
  let cfg ← jsonFile (← absoluteEnv "BASIC_TARGET_CONSTANT_INVENTORY_CONFIG")
  unless (← checked (stringField cfg "schema")) == "Basic-target-constant-existence-config/v93" do throwError "Wrong inventory config"
  unless Lean.versionString == (← checked (stringField cfg "expectedCompilerVersion")) do throwError "Compiler version mismatch"
  let input ← jsonFile (← checked (stringField cfg "namesFile"))
  unless (← checked (stringField input "schema")) == "Basic-constant-use-inventory-input/v93" do throwError "Wrong inventory input"
  unless input == (← checked (field cfg "namesFileBinding")) do throwError "Bound inventory input changed"
  let env ← getEnv
  let mut rows := #[]
  let mut missing := #[]\n  let mut requiredMissing := #[]
  for r in ← checked (arrayField input "constantNames") do
    let n ← checked (decodeName (← checked (field r "targetNameExpr")))
    let exists := (env.find? n).isSome
    let out := Json.mkObj [("sourceNameExpr",← checked (field r "sourceNameExpr")),
      ("sourceName",← checked (field r "sourceName")),("targetNameExpr",encodeName n),
      ("targetName",toJson n.toString),("scopes",← checked (field r "scopes")),
      ("exists",toJson exists),("owner",toJson ((moduleOf env n).map Name.toString)),\n      ("expandedClosedPropSupport",← checked (field r "expandedClosedPropSupport")),\n      ("requiredForComparison",← checked (field r "requiredForComparison"))]
    rows := rows.push out
    unless exists do
      missing := missing.push out
      if ← checked (r.getObjValAs? Bool "requiredForComparison") then requiredMissing := requiredMissing.push out
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "Basic-target-constant-existence-actual/v93"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("inputs",← checked (field input "inputs")),("records",Json.arr rows),
    ("missing",Json.arr missing),("missingCount",toJson missing.size),\n    ("requiredMissing",Json.arr requiredMissing),("requiredMissingCount",toJson requiredMissing.size),
    ("foreignExprDecoded",toJson false),("foreignExprKernelChecked",toJson false),
    ("all55ComparedClaimed",toJson false)]).pretty ++ "\\n")
end TargetConstantExistence
'''
(D/'QueryTargetConstantExistence.lean').write_text(target_import+codec+'\n'+inv)
print('constants',len(rows),'occurrences',len(occurrences),'applications',sum('fullApplicationExpr' in r for r in occurrences))
for r in occurrences:
 if 'fullApplicationExpr' in r:print(r['scope'],r['owner'],r['argumentCount'],r['path'])
