import Lean
import Iut.Tripod.Basic

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  let m ← env.header.modules[index.toNat]?
  return m.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit

namespace AbsNormCardQuotExport
open Lean Elab Term Meta FoundationAudit

def closed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasFVar || e.hasMVar || e.hasLooseBVars then throwError "Open Expr {label}"

def kcheck (label : String) (e : Expr) : MetaM Expr := do
  closed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def keq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kcheck label e
  let ft ← kcheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

-- Recognize only actual Nat-valued applications. No Infinite-to-Free translation.
-- Meta.transform opens binders before whnf / isDefEq and reabstracts them.
def normalizeAbsNorm (raw : Expr) : MetaM Expr := do
  let hits ← IO.mkRef (0 : Nat)
  let normalized ← Meta.transform raw (pre := fun e => do
    let args := e.getAppArgs
    if e.getAppFn.isConstOf ``DFunLike.coe && args.size == 6 then
      let hom := args[4]!
      if hom.getAppFn.isConstOf ``Ideal.absNorm && hom.getAppNumArgs == 4 then
        -- Delta-expand only the actual bundled norm. Reduce its coercion/projections
        -- under reducible+instances transparency, which leaves cardQuot opaque.
        -- Thus every original argument participates in real Lean reduction.
        let some expanded ← unfoldDefinition? hom (ignoreTransparency := true)
          | throwError "Cannot delta-expand actual absNorm"
        let projected := mkAppN e.getAppFn (args.set! 4 expanded)
        let candidate ← withReducibleAndInstances <| whnf projected
        unless candidate.getAppFn.isConstOf ``Submodule.cardQuot do
          throwError "absNorm projection did not reduce to cardQuot"
        unless ← isDefEq e candidate do
          throwError "absNorm projection is not definitionally cardQuot"
        hits.modify (· + 1)
        return .done candidate
    if e.getAppFn.isConstOf ``Ideal.absNorm then
      throwError "Unsupported unsaturated or whole-hom absNorm occurrence"
    return .continue)
  unless (← hits.get) == 1 do throwError "Expected exactly one saturated absNorm application"
  unless !(normalized.getUsedConstants.contains ``Ideal.absNorm) do
    throwError "absNorm remains in normalized Expr"
  closed "normalized complete Expr" normalized
  return normalized

def certify (raw normalized : Expr) : MetaM Json := do
  keq "complete original/normalized Expr" raw normalized
  let equality ← mkEq raw normalized
  let proof ← mkEqRefl raw
  let pt ← kcheck "complete normalization equality proof" proof
  keq "complete normalization equality proposition" pt equality
  ensureStandard "complete normalization equality proof" (← expressionAxioms proof)
  return Json.mkObj [
    ("originalExpr",← checked (encodeExpr raw)),
    ("normalizedExpr",← checked (encodeExpr normalized)),
    ("equalityExpr",← checked (encodeExpr equality)),
    ("equalityProofExpr",← checked (encodeExpr proof)),
    ("completeExprKernelDefEq",toJson true),
    ("completeEqualityProofKernelChecked",toJson true),
    ("axioms",toJson ((← expressionAxioms proof).map Name.toString))]

def libraryRecord (n : Name) : MetaM Json := do
  let ci ← getConstInfo n
  let some v := ci.value? (allowOpaque := true) | throwError "Missing actual library value {n}"
  let vt ← kcheck s!"actual library value {n}" v
  keq s!"actual library value TYPE {n}" vt ci.type
  let axs ← collectAxioms n
  ensureStandard s!"actual library declaration {n}" axs
  ensureStandard s!"actual library TYPE {n}" (← expressionAxioms ci.type)
  ensureStandard s!"actual library value {n}" (← expressionAxioms v)
  return Json.mkObj [
    ("nameExpr",encodeName n), ("constantKind",toJson (kind ci)),
    ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("actualTypeExpr",← checked (encodeExpr ci.type)),
    ("actualValueExpr",← checked (encodeExpr v)),
    ("axioms",toJson (axs.map Name.toString)),
    ("actualTypeAndValueKernelChecked",toJson true)]

run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected actual source4.35.0-rc3"
  let cfg ← jsonFile (← absoluteEnv "BASIC_ABSNORM_EXPORT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "Basic-absNorm-normalization-export-config/v85" do
    throwError "Wrong absNorm normalization config"
  let facts ← jsonFile (← checked (stringField cfg "factsFile"))
  let rows ← checked (arrayField facts "records")
  let expected : Array (Name × String) := #[
    (``Iut.Tripod.logCond,"valueExpr"),
    (``Iut.Tripod.logCond_eq_sum,"elaboratedExpr"),
    (``Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal,"elaboratedExpr"),
    (``Iut.Tripod.one_le_absNorm_real,"elaboratedExpr")]
  let mut reports : Array Json := #[]
  for (n,fld) in expected do
    let ci ← getConstInfo n
    let factRows := rows.filter fun r => (field r "nameExpr").toOption == some (encodeName n)
    unless factRows.size == 1 do throwError "Missing unique bound fact {n}"
    let raw ← if fld == "elaboratedExpr" then pure ci.type else do
      let some v := ci.value? (allowOpaque := true) | throwError "Missing complete data value {n}"
      unless !(← isProp ci.type) do throwError "Expected computational data {n}"
      pure v
    unless (← checked (field factRows[0]! fld)) == (← checked (encodeExpr raw)) do
      throwError "Bound actual raw Expr differs {n} {fld}"
    let normalized ← normalizeAbsNorm raw
    reports := reports.push (Json.mkObj [
      ("nameExpr",encodeName n),("field",toJson fld),
      ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
      ("saturatedAbsNormUses",toJson (1 : Nat)),
      ("certificate",← certify raw normalized)])
  let library ← #[``Ideal.absNorm,``Ideal.absNorm_apply,
    ``Submodule.cardQuot,``Submodule.cardQuot_apply].mapM libraryRecord
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "Basic-absNorm-normalization-actual/v85"),
    ("compilerVersion",toJson Lean.versionString),
    ("factsSHA256",← checked (field cfg "factsSHA256")),
    ("configuration",cfg),
    ("libraryDeclarations",Json.arr library),("reports",Json.arr reports),
    ("wholeHomReplacementUsed",toJson false),
    ("instanceReplacementUsed",toJson false),
    ("sourceTheoremProofValueIdentityClaimed",toJson false)]).pretty ++ "\n")
  logInfo "Four actual complete Exprs normalized to cardQuot and certified in this environment"
end AbsNormCardQuotExport
