本包准备真实源 Basic99→既有规范载体的完整对应计划及最小 `tripodTheory` 数据构造，未编译、未运行 CI/API/Git、未改主区。

来源已使用主智能体完成的真实 `source-facts.json`：owner 是 `Iut.Tripod.Basic`，共99项（25 definition、1 inductive/constructor/recursor各一、71 theorem）。现事实未读 theorem 值。`source99-coverage-plan.json` 对全部99项逐一分类，逐项保留实际 source Name 组件、TYPE和是否有值；55项候选可对应既有规范定义/结构生成声明及新数据构造，其他44项不假称已整合。目标生成名尚无本轮编译事实，只是待 actual owner-index 唯一定位的显示候选。

`Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean` 是最小新数据包草稿：原AST选取完整 `tripodTheory` 命令，仅将高度理论类型移到已发布的 `AbcAdaptation.Reference.Genl.HeightTheory`，命名空间改为现 `AbcAdaptation.Tripod`，全部构造字段继续使用现规范 Pt/ptLE/htCan/logDiff/logCond/CompactlyBounded。文件无新 theorem、无新任意高度/点域/运输假设，不复制现规范所有证明。两个结构法律直接复用现 `ptLE_zero/ptLE_succ`，它们的来源TYPE须比较，不能声称source proof字节相同。原构造body及目标文件SHA见 `data-constructor-source-map.json`。

目前明确缺少九个 actual theorem proof values：两个源无名 instance theorem；`badPlaces._proof_1/2/3`、`htCan._proof_1`、`logCond._proof_1/2`；以及TYPE中出现的 `badPlaces_finite`。这些名称全部来自 actual99，没有按数字后缀猜测。`required-proof-values.json` 列出原始完整TYPE。它们是零宇宙、闭合Prop支持，编译器导出的真实证明才可在对应审查中展开，并须单独Kernel.check、核对实际命题和标准公理；遇到新的非Prop数据依赖必须添加精确具名map，不能把数据展开成任意替代。现71个source theorem body不全量复制。

顺序为：主智能体整合并独占验收最小 `tripodTheory` 数据包；在原4.35环境运行 `QuerySourceBasicEnrichment.lean`，对实际99清单补结构生成信息及九个proof值的真实递归闭包；在目标4.33环境运行 `QueryNativeBasicInventory.lean`，收集真实owner inventory和Name组件/TYPE/值/结构元数据，从索引匹配显示候选。未找到的生成名会作为 unresolved 明示输出，证明支持发现延后，binder拒绝过早比较；不能用source命名规则代填target Name。

随后用 `bind_comparison.py` 绑定两个实际facts及成功独占回执，校验facts配置、输入SHA、全部已选Expr和闭合proof依赖都有具名map或实际Prop支持。该脚本不接受数学结果。最后主智能体运行 `AuditBasicNativeComparison.lean`，比较完整TYPE、全表达式BinderInfo、完整数据值、归纳/构造/递归信息、recursor RHS、结构字段顺序/投影/父结构/自动参数、实例登记和标准公理。共享结构/Expr方法来自既有173项审查工具；新Basic绑定和查询仍未编译。比较不靠打印文本。

数据值若仅有绑定信息原始差异，query仍需完整kernel值相等，并原样保留 `rawValueBinderInfoEqual=false` 等诊断；不能把它报告成绑定信息完全一致。TYPE签名BinderInfo不匹配则直接失败。目标closure不得有sorry或自定义公理。闭合Prop证明项按实际值展开并核验是消除编译器表示差别，不产生新的数学假设。

现source `Pt/fieldOf/deg/gen/htCan/logDiff/logCond` 与规范层可经具名map比较；独立 `CompactlyBounded` 必须连同真实生成ctor/rec/field元数据验收，不先假定是一个Lean类型。source `NorthcottHyp` 可与现 `BoundedDegreeFiniteness` 的实际Prop定义比较（展开ptLE），不因此得到Northcott证明。source `statementI_iff` 依赖尚未由当前StatementII包提供的 `Genl.HeightTheory.StatementI`，单独保留pending。source `statementII_iff` / `statementII_iff'` 是后续真实桥梁根；不是新数据构造，本包不生成它们的 theorem 或默认读其proof值。

`handoff.json` 给出配置、环境键、真实来源/目标源码pin、缺门及资源约定。最小新data包通过后并不自动证明canonical C22、Joshi适配或S2-04完成。
