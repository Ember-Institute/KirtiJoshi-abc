#!/usr/bin/env python3
"""Bind one successful actual source normalization receipt into a new comparison config.
No CI, compiler, API, Git, source editing or JSON-expression rewriting.
"""
import argparse, hashlib, json
from pathlib import Path

def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def nm(v): return '' if not v else nm(v[0]) + ('.' if v[0] else '') + str(v[2])
def count_const(e, name):
    if isinstance(e, dict):
        return int(e.get('kind') == 'const' and nm(e['name']) == name) + sum(count_const(v, name) for v in e.values())
    if isinstance(e, list): return sum(count_const(v, name) for v in e)
    return 0

a = argparse.ArgumentParser()
a.add_argument('--bound-config', required=True, type=Path)
a.add_argument('--source-actual', required=True, type=Path)
a.add_argument('--source-receipt', required=True, type=Path)
a.add_argument('--output', required=True, type=Path)
x = a.parse_args()
assert x.output.resolve() != x.bound_config.resolve(), 'Preserve failed input; create a new config.'
c, n, r = read(x.bound_config), read(x.source_actual), read(x.source_receipt)
assert c['schema'] == 'Basic-native-comparison-config/v63'
assert r['status'] == 'succeeded' and r['result']['exit_code'] == 0
req, res = r['request'], r['result']
assert req['exclusive'] is True
assert res['snapshot']['workspace_mode'] == 'exclusive_worktree' and res['snapshot']['snapshot_id'] is None
workspace = Path(req['workspace']).resolve()
assert workspace == Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
query = Path(req['parameters']['source'])
if not query.is_absolute(): query = workspace / query
query = query.resolve()
assert res['actual_arguments'][0] == 'lean' and len(res['actual_arguments']) == 2
actual_query = Path(res['actual_arguments'][1])
if not actual_query.is_absolute(): actual_query = workspace / actual_query
assert actual_query.resolve() == query
cfg_path = Path(req['environment']['BASIC_ABSNORM_EXPORT_CONFIG']).resolve()
export_cfg = read(cfg_path)
assert export_cfg == n['configuration']
assert export_cfg['schema'] == 'Basic-absNorm-normalization-export-config/v85'
assert Path(export_cfg['outputFile']).resolve() == x.source_actual.resolve()
source_facts = Path(c['sourceEnrichedFacts']).resolve()
assert Path(export_cfg['factsFile']).resolve() == source_facts
assert sha(source_facts) == export_cfg['factsSHA256'] == c['sourceFactsBinding']['sha256'] == n['factsSHA256']
assert read(source_facts) == c['sourceFactsBinding']['contents']
input_hashes = req['worktree_manifest']['input_hashes']
for p in [query, cfg_path, source_facts]:
    assert input_hashes[str(p)] == sha(p), ('Producer input changed', str(p))
assert n['schema'] == 'Basic-absNorm-normalization-actual/v85' and n['compilerVersion'] == '4.35.0-rc3'
assert n['wholeHomReplacementUsed'] is False and n['instanceReplacementUsed'] is False
expected = {('Iut.Tripod.logCond', 'valueExpr'), ('Iut.Tripod.logCond_eq_sum', 'elaboratedExpr'),
            ('Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal', 'elaboratedExpr'),
            ('Iut.Tripod.one_le_absNorm_real', 'elaboratedExpr')}
assert len(n['reports']) == 4
assert {(nm(z['nameExpr']), z['field']) for z in n['reports']} == expected
facts = {nm(z['nameExpr']): z for z in c['sourceFactsBinding']['contents']['records']}
for z in n['reports']:
    cert = z['certificate']
    fact = facts[nm(z['nameExpr'])]
    assert z['levelParams'] == fact['levelParams'], ('Actual universe parameter Names changed', nm(z['nameExpr']))
    assert cert['originalExpr'] == fact[z['field']]
    assert z['saturatedAbsNormUses'] == 1
    assert count_const(cert['originalExpr'], 'Ideal.absNorm') == 1
    assert count_const(cert['normalizedExpr'], 'Ideal.absNorm') == 0
    assert count_const(cert['normalizedExpr'], 'Submodule.cardQuot') == 1
    assert cert['completeExprKernelDefEq'] is True and cert['completeEqualityProofKernelChecked'] is True
    assert cert['equalityExpr'] is not None and cert['equalityProofExpr'] is not None
    assert set(cert['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}
assert len(n['libraryDeclarations']) == 4
assert {nm(z['nameExpr']) for z in n['libraryDeclarations']} == {'Ideal.absNorm', 'Ideal.absNorm_apply', 'Submodule.cardQuot', 'Submodule.cardQuot_apply'}
for z in n['libraryDeclarations']:
    assert z['actualTypeExpr'] is not None and z['actualValueExpr'] is not None
    assert z['actualTypeAndValueKernelChecked'] is True
    assert set(z['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}
c['sourceAbsNormNormalizationBinding'] = {
    'path': str(x.source_actual.resolve()), 'sha256': sha(x.source_actual), 'contents': n,
    'receipt': {'path': str(x.source_receipt.resolve()), 'sha256': sha(x.source_receipt), 'contents': r},
    'producerQuery': {'path': str(query), 'sha256': sha(query)},
    'contract': 'exact-four-source-fields-kernel-normalized-in-successful-source4.35-job'}
x.output.parent.mkdir(parents=True, exist_ok=True)
x.output.write_text(json.dumps(c, ensure_ascii=False, separators=(',', ':')) + '\n')
print(x.output, sha(x.output))
