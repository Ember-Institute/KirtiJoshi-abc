from pathlib import Path
import hashlib
import json
import re

OUT = Path('/tmp/p2m-tripod-metadata-finish-v85-20261117')
ROOT = Path('/home/admin-wsl/Coq/abc')
OLD = Path('/tmp/p2m-tripod-theory-publication-v81-20261116')
RB = Path('/tmp/p2m-tripod-theory-blind-readback-v77-20261116')
TARGET = ROOT / 'prove2me_workspace/Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

old_payload = json.loads((OLD / 'payload.json').read_text())
old_metadata = json.loads((OLD / 'metadata.json').read_text())
context_path = Path(old_metadata['paper_source']['quote']['existing_context']['path'])
context = json.loads(context_path.read_text())
quote = context['quoteMarkdown']
assert quote == old_metadata['paper_source']['quote']['text']
quote_block = '\n'.join('> ' + line if line else '>' for line in quote.splitlines())

height_display = r'''$$
H_{F_z}(g_z)=
\prod_{w\in M_{F_z}^{\infty}}\max(w(g_z),1)^{m_w}
\prod_{v\in M_{F_z}^{\mathrm{fin}}}\max(v(g_z),1).
$$'''

subset_display = r'''$$
\begin{aligned}
S_{V,c}=\bigl\{x\in\mathcal P:\;&
\forall v\in M_{F_z}^{\mathrm{fin}},\quad
p_v\in V\Rightarrow
\bigl(|\log v(g_z)|\leq c\ \land\ |\log v(g_z-1)|\leq c\bigr);\\
&\forall w\in M_{F_z}^{\infty},\quad
|\log w(g_z)|\leq c\ \land\ |\log w(g_z-1)|\leq c
\bigr\}.
\end{aligned}
$$'''

def read_formal(language):
    s = (RB / f'readback-{language}.md').read_text()
    # The independent originals remain unchanged. Platform prose is an edited derivative.
    s = s.split('\n\n', 2)[2]
    s = s.replace(r'\mathrm{Height.logHeight}_1(g_z)', r'\log H_{F_z}(g_z)')
    a = s.index('$$\n\\begin{aligned}\nS_{V,c}=')
    b = s.index('\n$$', a + 3) + 3
    s = s[:a] + subset_display + s[b:]
    return s.strip()

en = read_formal('en')
en = en.replace(
    'The declaration is a fixed noncomputable object, with no explicit or implicit mathematical parameters and no external type-class hypotheses.',
    'The definition specifies a fixed, noncomputable height theory, with no explicit or implicit mathematical parameters and no external type-class hypotheses.')
en = en.replace('Its type is the height-theory structure at the universe of small types.',
                'The structure lies in the universe of small types.')
en = en.replace('the predicate `Hyperbolic` is the proposition True, and `DivisorFree` is the proposition False.',
                'the predicate `Hyperbolic` is `True`, and `DivisorFree` is `False`.')
en = en.replace('Thus the first predicate holds at the unique index by the proof of True.',
                'The first predicate therefore holds at the unique index.')
en = en.replace('The imported definitions provide $n_z>0$ and $n_z=[F_z:ℚ]$, and make $F_z$ a number field.',
                'The field $F_z$ is a number field, $n_z>0$, and $n_z=[F_z:ℚ]$. Write $n_x=n_z$ for the corresponding point $x$.')
en = en.replace("The structure's required identities are supplied by the existing proofs that the first subset is empty for $d=0$ and that", "The structure includes the identities that the first subset is empty for $d=0$ and that")
en = en.replace('The imported code establishes finiteness of $B_z$ for the points in $\\mathcal P$ and expresses its finite-support sum as the displayed finite sum.',
                'For every $x∈\\mathcal P$, the set $B_z$ is finite, so the displayed conductor sum is a finite sum.')
a = en.index('To specify the height normalization completely,')
b = en.index('\n\nThe type assigned to the field `CBS`', a)
en = en[:a] + '''The height normalization is given by

''' + height_display + '''

Here $M_{F_z}^{\\mathrm{fin}}$ and $M_{F_z}^{\\infty}$ are the finite and infinite places of $F_z$. The multiplicity $m_w$ is one at a real place and two at a complex place. The finite-place product has finite multiplicative support. Thus $h(x)=n_z^{-1}\\log H_{F_z}(g_z)$ uses the generator in its own number field and divides by the degree after taking the logarithm. The three functions $h,δ,κ$ are nonnegative; the definition includes their values as structure fields.''' + en[b:]
en = en.replace('These records are the objects labelled “compactly bounded subsets” in the code.',
                'These records form the chosen representation of “compactly bounded subsets”.')
en = en.replace('where $z$ represents $x$ and $p_v$ is the characteristic of the actual quotient',
                'Here $z$ represents $x$, and $p_v$ is the characteristic of the quotient')
en = en.replace('Statements named `StatementI` or `StatementII` occur in an imported module as separate propositions; their presence does not turn this data constructor into a proof of either proposition.',
                'This definition supplies data for height inequalities; it does not assert or prove such an inequality or an arithmetic conjecture.')

zh = read_formal('zh-CN')
zh = zh.replace('该声明是一个固定的不可计算对象，没有显式或隐式数学参数，也没有外部类型类假设。',
                '该定义给出一个固定的不可计算高度理论，没有显式或隐式数学参数，也没有外部类型类假设。')
zh = zh.replace('其类型是小类型宇宙中的高度理论结构。', '该结构位于小类型宇宙中。')
zh = zh.replace('谓词 `Hyperbolic` 都是真命题，谓词 `DivisorFree` 都是假命题。因此，第一个谓词在唯一指标处成立，由真命题的证明给出。',
                '谓词 `Hyperbolic` 都是恒真命题 `True`，谓词 `DivisorFree` 都是恒假命题 `False`。因此，第一个谓词在唯一指标处成立。')
zh = zh.replace('导入的定义给出 $n_z>0$ 和 $n_z=[F_z:ℚ]$，并将 $F_z$ 配备为数域。',
                '$F_z$ 是数域，$n_z>0$，并且 $n_z=[F_z:ℚ]$。对相应的点 $x$，记 $n_x=n_z$。')
zh = zh.replace('结构所需的恒等式由既有证明提供：', '该结构包含以下恒等式：')
zh = zh.replace('导入的代码为 $\\mathcal P$ 中的点给出 $B_z$ 的有限性，并将相应有限支撑和写成上式中的有限和。',
                '对每个 $x∈\\mathcal P$，集合 $B_z$ 都是有限集，因此上述导子公式中的和是有限和。')
a = zh.index('高度的规范化可具体描述如下：')
b = zh.index('\n\n赋给字段 `CBS`', a)
zh = zh[:a] + '''高度采用以下规范化：

''' + height_display + '''

其中 $M_{F_z}^{\\mathrm{fin}}$ 和 $M_{F_z}^{\\infty}$ 分别为 $F_z$ 的有限处集和无限处集。重数 $m_w$ 在实处取一，在复处取二。有限处乘积有有限乘性支撑。因此，$h(x)=n_z^{-1}\\log H_{F_z}(g_z)$ 使用生成元自身所在数域中的高度，并在取对数后除以次数。三个函数 $h,δ,κ$ 均非负；该定义将它们的取值用作结构字段。''' + zh[b:]
zh = zh.replace('代码将这些记录称为“[术语待定：compactly bounded subset]”。',
                '这些记录给出“[术语待定：compactly bounded subset]”的一种指定表示。')
zh = zh.replace('导入模块中名为 `StatementI` 和 `StatementII` 的陈述是另外的命题；它们的出现并未使这个数据构造成为任一命题的证明。',
                '该定义为高度不等式提供数据，本身不陈述或证明这种不等式或算术猜想。')

ja = read_formal('ja')
ja = ja.replace('この宣言は固定された非計算的な対象であり、', 'この定義は固定された非計算的な高さ理論を与え、')
ja = ja.replace('その型は小さい型の宇宙における高さ理論の構造である。', 'この構造は小さい型の宇宙に属する。')
ja = ja.replace('述語 `Hyperbolic` は真である命題、`DivisorFree` は偽である命題に定められる。したがって、唯一の添字における前者の証明には真である命題の証明が用いられる。',
                '述語 `Hyperbolic` は常に真となる命題 `True`、`DivisorFree` は常に偽となる命題 `False` に定められる。したがって、前者は唯一の添字で成り立つ。')
ja = ja.replace('導入された定義は $n_z>0$ と $n_z=[F_z:ℚ]$ を与え、$F_z$ を数体とする。',
                '$F_z$ は数体であり、$n_z>0$ および $n_z=[F_z:ℚ]$ が成り立つ。対応する点 $x$ に対して $n_x=n_z$ と書く。')
ja = ja.replace('構造が要求する恒等式には、$d=0$ のとき前者が空であること、および $\\mathrm{ptLE}(*,d+1)=\\mathrm{ptLE}(*,d)∪\\mathrm{ptEQ}(*,d+1)$ の既存の証明を用いる。',
                '構造には、$d=0$ のとき前者が空であること、および $\\mathrm{ptLE}(*,d+1)=\\mathrm{ptLE}(*,d)∪\\mathrm{ptEQ}(*,d+1)$ という恒等式が含まれる。')
ja = ja.replace('導入されたコードは $\\mathcal P$ の点について $B_z$ の有限性を与え、対応する有限台を持つ和を上の有限和として表す。',
                '各 $x∈\\mathcal P$ に対して $B_z$ は有限であるため、上の導手の式に現れる和は有限和である。')
a = ja.index('高さの正規化を完全に記述すると、')
b = ja.index('\n\nフィールド `CBS`', a)
ja = ja[:a] + '''高さの正規化は次の式で与えられる。

''' + height_display + '''

ここで $M_{F_z}^{\\mathrm{fin}}$ と $M_{F_z}^{\\infty}$ は、それぞれ $F_z$ の有限素点と無限素点の集合である。重複度 $m_w$ は実素点では一、複素素点では二である。有限素点上の積は有限の乗法的台を持つ。したがって、$h(x)=n_z^{-1}\\log H_{F_z}(g_z)$ は生成元が属する数体における高さを用い、対数を取った後に次数で割る。三つの関数 $h,δ,κ$ は非負であり、この定義はそれらの値を構造のフィールドに用いる。''' + ja[b:]
ja = ja.replace('コードではこれらの記録を「コンパクト有界部分集合（compactly bounded subset）」と呼ぶ。',
                'これらの記録は「コンパクト有界部分集合（compactly bounded subset）」の指定された表示を与える。')
ja = ja.replace('導入されたモジュールには `StatementI` と `StatementII` という別の命題があるが、それらが存在することによって、このデータの構成がいずれかの命題の証明になるわけではない。',
                'この定義は高さの不等式に用いるデータを与えるものであり、そのような不等式や数論的予想を述べたり証明したりするものではない。')

source_en = '''Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position*, February 2009, §1 and Theorem 2.1(ii). Definition 1.2(i), p. 5, introduces heights. Example 1.3(i)–(ii), pp. 5–6, treats degree restrictions and compactly bounded subsets. Definition 1.5(iii)–(iv), p. 8, defines the log-different and log-conductor. All page numbers are both printed pages and PDF file pages. [Author's original paper](https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf).

Theorem 2.1(ii), p. 11, states the following condition within an equivalence theorem:

''' + quote_block + '''

This quotation gives the mathematical context for the point, degree, height, and subset data. It states a conjectural condition in the equivalence theorem. The present definition packages selected data; it does not prove this condition or the equivalence theorem. The points correspond to the affine coordinates on $U_P$ in the quotation. The mathematical definition specifies the functions and subsets by their exact formulas. It does not prove a geometric identification of its height with $\\mathrm{ht}_{\\omega_P(C)}$. It also does not prove that its subset records represent every compact bounding domain of Example 1.3(ii). The support variable $\\Sigma$ belongs to the quoted condition and is not an additional parameter of this definition.'''

source_zh = '''数学来源为望月新一《Arithmetic Elliptic Curves in General Position》二〇〇九年二月版第 1 节及定理 2.1(ii)。定义 1.2(i) 在第 5 页引入高度；例 1.3(i)–(ii) 在第 5–6 页讨论次数限制与[术语待定：compactly bounded subset]；定义 1.5(iii)–(iv) 在第 8 页给出对数不同函数和对数导子函数。上述页码均同时对应印刷页码与文件页序。英文来源部分逐段引录第 11 页定理 2.1(ii) 的完整分项。

该引文提供点、次数、高度和子集数据的数学背景，其内容是等价定理中的一个猜想条件。本定义组织所选数据，不证明该条件或等价定理。点对应于引文中 $U_P$ 的仿射坐标，函数和子集则由前述数学定义中的精确公式指定。该定义没有证明所用高度与 $\\mathrm{ht}_{\\omega_P(C)}$ 的几何识别，也没有证明这些子集记录表示例 1.3(ii) 中的全部局部紧区域。支撑集变量 $\\Sigma$ 属于引文中的条件，不是本定义的额外参数。'''

source_ja = '''数学的な出典は、望月新一の *Arithmetic Elliptic Curves in General Position*、2009 年 2 月版の第 1 節と定理 2.1(ii) である。定義 1.2(i) は第 5 ページで高さを導入する。例 1.3(i)–(ii) は第 5–6 ページで次数の制限とコンパクト有界部分集合を扱う。定義 1.5(iii)–(iv) は第 8 ページで対数不同関数と対数導手関数を定義する。これらのページ番号は印刷ページと PDF のファイルページの両方に一致する。英語の出典説明には、第 11 ページの定理 2.1(ii) の全項を引用した。

引用は点、次数、高さ、および部分集合のデータの数学的背景を与え、その内容は同値定理に現れる予想に当たる条件である。この定義は選択したデータをまとめるものであり、その条件や同値定理を証明しない。点は引用中の $U_P$ のアフィン座標に対応し、関数と部分集合は上記の数学的定義にある正確な式で指定する。この定義は、用いる高さと $\\mathrm{ht}_{\\omega_P(C)}$ の幾何学的な同一視や、これらの記録が例 1.3(ii) のすべての局所的なコンパクト領域を表すことを証明しない。台の集合の変数 $\\Sigma$ は引用中の条件に属し、この定義の追加パラメータではない。'''

intuition_en = '''The data place the algebraic numbers other than $0$ and $1$ in one height-theory interface. Degree records the size of the point's number field; the three real functions measure height, discriminant, and bad finite places. The sets $S_{V,c}$ impose a common logarithmic bound at all infinite places and above a selected finite prime set. This interpretation does not add a height inequality or a geometric compactness theorem.'''
intuition_zh = '''这些数据把除 $0$、$1$ 外的代数数组织到同一个高度理论接口中。次数记录点所在数域的大小；三个实值函数分别衡量高度、判别式与坏有限处。子集 $S_{V,c}$ 在所有无限处及所选有限素数集上方的全部有限处施加统一的对数界。这一直观说明不附加高度不等式或几何紧性定理。'''
intuition_ja = '''このデータは、$0$ と $1$ 以外の代数的数を一つの高さ理論のインターフェースにまとめる。次数は点の数体の大きさを記録し、三つの実数値関数は高さ、判別式、および悪い有限素点を測る。集合 $S_{V,c}$ は、すべての無限素点と、選択した有限素数集合の上にあるすべての有限素点で共通の対数の上限を課す。この説明は高さの不等式や幾何学的なコンパクト性の定理を加えるものではない。'''

parts = [
    '# English\n\n## Mathematical definition\n\n' + en,
    '## Paper source and scope\n\n' + source_en,
    '## Intuition (non-rigorous)\n\n' + intuition_en,
    '---\n\n# 简体中文\n\n## 数学定义\n\n' + zh,
    '## 论文来源与范围\n\n' + source_zh,
    '## 直观解释（非严格）\n\n' + intuition_zh,
    '---\n\n# 日本語\n\n## 数学的定義\n\n' + ja,
    '## 論文の出典と範囲\n\n' + source_ja,
    '## 直観的説明（非厳密）\n\n' + intuition_ja,
]
statement = '\n\n'.join(parts) + '\n'
(OUT / 'natural-language-statement.md').write_text(statement)
payload = {k:old_payload[k] for k in [
    'definition_name','definition_title','definition','natural_language_statement','source','env','private']}
payload['definition'] = TARGET.read_bytes().decode('utf-8')
payload['natural_language_statement'] = statement
payload['source'] = (
    'Shinichi Mochizuki, Arithmetic Elliptic Curves in General Position, February 2009, '
    '§1: Definition 1.2(i), p. 5; Example 1.3(i)–(ii), pp. 5–6; Definition 1.5(iii)–(iv), p. 8; '
    'Theorem 2.1(ii), p. 11 (source context; the definition does not prove its conjectural condition). '
    'Printed page numbers and PDF file pages coincide. '
    'https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf')
(OUT / 'payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')

metadata = {
    'kind':'Edited publication payload draft for a pure definition',
    'version':'v85-20261117',
    'status':'pending_root55_actual_kernelgate',
    'status_note':'This editorial task does not claim a new kernel gate, compilation, audit acceptance, API submission, or publication.',
    'activity':{
        'mcp_ci_called':False,'compilation_performed':False,'application_api_called':False,
        'git_operations_performed':False,'main_workspace_modified':False,
        'writes_confined_to':str(OUT)},
    'payload_fields':list(payload),
    'removed_local_control_fields':['status','lean_code'],
    'definition_exact_bytes':{
        'source':str(TARGET),'sha256':sha(TARGET),'size_bytes':len(TARGET.read_bytes()),
        'match':payload['definition'].encode('utf-8')==TARGET.read_bytes()},
    'env':old_metadata['env'],
    'previous_payload':{'path':str(OLD/'payload.json'),'sha256':sha(OLD/'payload.json')},
    'previous_metadata':{'path':str(OLD/'metadata.json'),'sha256':sha(OLD/'metadata.json')},
    'independent_readback':{
        'original_directory':str(RB),'reader_model':'gpt-6.1-sol',
        'files':{n:{'path':str(RB/n),'sha256':sha(RB/n)} for n in [
            'readback-en.md','readback-zh-CN.md','readback-ja.md','manifest.json','terminology-and-scope.md']},
        'originals_modified':False,
        'platform_text_role':'Edited academic exposition based on the frozen independent English readback and its translations; not a new independent readback.',
        'translations_are_not_independent_audits':True,
        'new_independent_review_performed':False},
    'paper_source':old_metadata['paper_source'],
    'code_source':old_metadata['code_source'],
    'pending_terminology':old_metadata['pending_terminology'],
    'formal_scope':old_metadata['formal_scope'],
    'editorial_changes':[
        'Removed reader-model, translation-audit, local-file, status, CI and 55-kernel progress narration from platform prose; retained provenance and pending gate in this metadata.',
        'Preserved the one-element Unit index, distinguished tripod, constant True/False predicates, and lack of geometric constructions.',
        'Preserved the points, lack of quotients or added infinity, number fields, minimal-polynomial degrees, and both degree filtration identities.',
        'Wrote the existing multiplicative height as H_{F_z}(g_z) and replaced Height.logHeight_1(g_z) by log H_{F_z}(g_z); included its complete product formula in every language.',
        'Defined n_x=n_z explicitly and named the finite and infinite place sets M_{F_z}^{fin} and M_{F_z}^{infinity}.',
        'Kept the discriminant and bad-place conductor formulas, finite support, positivity of denominators, nonnegativity, and absence of extra ramification multiplicities.',
        'Made the subset membership implication scope explicit with parentheses; preserved all finite places above V, all infinite places, common bound c, 2 in V, arbitrary real c, no outside-V condition, and no degree bound.',
        'Kept the distinction between records and topologically compact subsets; retained the missing geometric correspondence, topology, compactness proof, and additional Sigma input.',
        'Retained the exact stored complete Theorem 2.1(ii) quotation and source page locators; separated paper context from mathematical definition.',
        'Added short, explicitly non-rigorous intuition in all three languages, without adding a theorem.',
        'Retained the existing Chinese compactly bounded subset placeholder and Japanese コンパクト有界部分集合; Japanese author is 望月新一.'
    ],
    'input_hash_checks':'input-hash-checks.json',
    'input_hash_checks_all_match':all(x['match'] for x in json.loads((OUT/'input-hash-checks.json').read_text()).values()),
    'style_skills':[
        {'name':'subagent-workspace','path':'/root/.codex/skills/subagent-workspace/SKILL.md'},
        {'name':'simplified-technical-english','path':'/root/.agents/skills/simplified-technical-english/SKILL.md',
         'scope':'Edited explanatory English; original paper quotation remains unchanged.'}],
    'artifacts_sha256':{n:sha(OUT/n) for n in ['payload.json','natural-language-statement.md','input-hash-checks.json']},
}
(OUT/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'payload_fields':list(payload),'definition_exact':metadata['definition_exact_bytes']['match'],
                  'statement_characters':len(statement),'input_hashes_match':metadata['input_hash_checks_all_match']},ensure_ascii=False))
