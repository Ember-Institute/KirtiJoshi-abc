# English

## Mathematical definition

The definition specifies a fixed, noncomputable height theory, with no explicit or implicit mathematical parameters and no external type-class hypotheses. The structure lies in the universe of small types. Its curve-index type is the one-element type `Unit`, whose unique element is denoted $*$. The distinguished index `tripod` is $*$. For every curve index, the predicate `Hyperbolic` is `True`, and `DivisorFree` is `False`. The first predicate therefore holds at the unique index. The definition does not construct a projective line, a divisor, or a geometric test for either predicate; the words used to name the fields do not add such data or tests.

Let $\overline{ℚ}$ denote the specified algebraic closure `AlgebraicClosure ℚ`. At the unique curve index, the point type is

$$
\mathcal P=\{z∈\overline{ℚ}:z≠0\text{ and }z≠1\}.
$$

A point is an algebraic-closure element together with witnesses of these two inequalities. No quotient by conjugacy or by a choice of field of definition is taken, and no extra point at infinity is adjoined. For such an element $z$, let $n_z$ be the degree of its minimal polynomial over $ℚ$, let $F_z=ℚ(z)⊆\overline{ℚ}$ be the simple intermediate field, and let $g_z∈F_z$ be its generator, whose image in $\overline{ℚ}$ is $z$. The field $F_z$ is a number field, $n_z>0$, and $n_z=[F_z:ℚ]$. Write $n_x=n_z$ for the corresponding point $x$.

For every natural number $d$, the subsets assigned to the unique index are

$$
\mathrm{ptLE}(*,d)=\{x∈\mathcal P:n_x≤d\},\qquad
\mathrm{ptEQ}(*,d)=\{x∈\mathcal P:n_x=d\}.
$$

The structure includes the identities that the first subset is empty for $d=0$ and that $\mathrm{ptLE}(*,d+1)=\mathrm{ptLE}(*,d)∪\mathrm{ptEQ}(*,d+1)$. Natural numbers here include zero; the use of a finite degree bound does not assert that the set of points with that bound is finite.

The three functions assigned at this same index have domain $\mathcal P$ and codomain $ℝ$. They are, for $x$ represented by $z$,

$$
h(x)=\frac{\log H_{F_z}(g_z)}{n_z},\qquad
δ(x)=\frac{\log|\operatorname{disc}(F_z)|}{n_z},\qquad
κ(x)=\frac{1}{n_z}\sum_{v∈B_z}\log N(\mathfrak p_v),
$$

and correspond respectively to the fields `htCan`, `logDiff`, and `logCond`. The discriminant is the number-field discriminant, cast from integers to reals before taking its absolute value. For a finite place $v$ of $F_z$, $\mathfrak p_v$ is its associated prime ideal in the ring of integers, and $N(\mathfrak p_v)$ is its absolute ideal norm, cast to a real number. The finite set of places used in the conductor formula is

$$
B_z=\{v:\ v(g_z)≠1\text{ or }v(g_z-1)≠1\}.
$$

Here finite places act as positive real multiplicative absolute values on nonzero elements, not as additive valuations. For every $x∈\mathcal P$, the set $B_z$ is finite, so the displayed conductor sum is a finite sum. Each bad place contributes its norm logarithm once; this formula does not attach an additional ramification multiplicity to that contribution. All three denominators are positive because $n_z>0$.

The height normalization is given by

$$
H_{F_z}(g_z)=
\prod_{w\in M_{F_z}^{\infty}}\max(w(g_z),1)^{m_w}
\prod_{v\in M_{F_z}^{\mathrm{fin}}}\max(v(g_z),1).
$$

Here $M_{F_z}^{\mathrm{fin}}$ and $M_{F_z}^{\infty}$ are the finite and infinite places of $F_z$. The multiplicity $m_w$ is one at a real place and two at a complex place. The finite-place product has finite multiplicative support. Thus $h(x)=n_z^{-1}\log H_{F_z}(g_z)$ uses the generator in its own number field and divides by the degree after taking the logarithm. The three functions $h,δ,κ$ are nonnegative; the definition includes their values as structure fields.

The type assigned to the field `CBS` consists of records $K=(V,c)$ together with proofs that $V$ is a finite set of natural primes and $2∈V$, where $c∈ℝ$. There is no requirement $c≥0$ or $c>0$. These records form the chosen representation of “compactly bounded subsets”. For each such record, the field `cbsSet` assigns the following subset of $\mathcal P$:

$$
\begin{aligned}
S_{V,c}=\bigl\{x\in\mathcal P:\;&
\forall v\in M_{F_z}^{\mathrm{fin}},\quad
p_v\in V\Rightarrow
\bigl(|\log v(g_z)|\leq c\ \land\ |\log v(g_z-1)|\leq c\bigr);\\
&\forall w\in M_{F_z}^{\infty},\quad
|\log w(g_z)|\leq c\ \land\ |\log w(g_z-1)|\leq c
\bigr\}.
\end{aligned}
$$

Here $z$ represents $x$, and $p_v$ is the characteristic of the quotient $\mathcal O_{F_z}/\mathfrak p_v$. Infinite places also act as multiplicative absolute values. The same $c$ applies to both expressions, all the indicated places, and every point of this assigned subset, even though the number field varies with the point. The finite-place conditions apply to **every** place whose residue characteristic belongs to $V$. No condition is imposed here at finite places outside $V$. There is no degree bound in the definition of $S_{V,c}$ itself. Since $z$ and $z-1$ are nonzero, the logarithms in these membership conditions have positive arguments; negative values of $c$ are permitted as data, without an assumption that the assigned subset is nonempty.

The field `cbsSet` is this explicit membership construction from records to subsets; the record type is not defined as the collection of all topologically compact subsets. No topology, compactness proof, additional support set $Σ$, or proof of a correspondence with such a geometric notion is added by this declaration. The structure contains exactly the selected point and degree data, three functions, constant predicates, distinguished index, record type and subset map described above. This definition supplies data for height inequalities; it does not assert or prove such an inequality or an arithmetic conjecture.

## Paper source and scope

Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position*, February 2009, §1 and Theorem 2.1(ii). Definition 1.2(i), p. 5, introduces heights. Example 1.3(i)–(ii), pp. 5–6, treats degree restrictions and compactly bounded subsets. Definition 1.5(iii)–(iv), p. 8, defines the log-different and log-conductor. All page numbers are both printed pages and PDF file pages. [Author's original paper](https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf).

Theorem 2.1(ii), p. 11, states the following condition within an equivalence theorem:

> (ii) (ABC Conjecture for $\Sigma$-Supported Compactly Bounded Subsets) Let $P\overset{\mathrm{def}}{=}\mathbb P^1_{\mathbb Q}$ be the projective line over $\mathbb Q$; $C\subseteq P$ the divisor consisting of the three points “0”, “1”, and “$\infty$”; $U_P\overset{\mathrm{def}}{=}P\setminus C$; $d$ a positive integer; $\epsilon\in\mathbb R_{>0}$ a positive real number; $\mathcal K_V\subseteq U_P(\overline{\mathbb Q})$ a compactly bounded subset [i.e., regarded as a subset of $P(\overline{\mathbb Q})$ — cf. Example 1.3, (ii)] whose support contains $\Sigma$. Write $\omega_P$ for the canonical sheaf on $P$. Then the inequality of BD-classes of functions
>
> $$\mathrm{ht}_{\omega_P(C)}\lesssim(1+\epsilon)(\log\text{-}\mathrm{diff}_P+\log\text{-}\mathrm{cond}_C)$$
>
> holds on $\mathcal K_V\cap U_P(\overline{\mathbb Q})^{\leq d}$.

This quotation gives the mathematical context for the point, degree, height, and subset data. It states a conjectural condition in the equivalence theorem. The present definition packages selected data; it does not prove this condition or the equivalence theorem. The points correspond to the affine coordinates on $U_P$ in the quotation. The mathematical definition specifies the functions and subsets by their exact formulas. It does not prove a geometric identification of its height with $\mathrm{ht}_{\omega_P(C)}$. It also does not prove that its subset records represent every compact bounding domain of Example 1.3(ii). The support variable $\Sigma$ belongs to the quoted condition and is not an additional parameter of this definition.

## Intuition (non-rigorous)

The data place the algebraic numbers other than $0$ and $1$ in one height-theory interface. Degree records the size of the point's number field; the three real functions measure height, discriminant, and bad finite places. The sets $S_{V,c}$ impose a common logarithmic bound at all infinite places and above a selected finite prime set. This interpretation does not add a height inequality or a geometric compactness theorem.

---

# 简体中文

## 数学定义

该定义给出一个固定的不可计算高度理论，没有显式或隐式数学参数，也没有外部类型类假设。该结构位于小类型宇宙中。曲线指标类型为只有一个元素的 `Unit`，以 $*$ 表示唯一元素。指定指标 `tripod` 就是 $*$。对每个曲线指标，谓词 `Hyperbolic` 都是恒真命题 `True`，谓词 `DivisorFree` 都是恒假命题 `False`。因此，第一个谓词在唯一指标处成立。该定义没有构造射影直线或除子，也没有给出对这两个谓词的几何判定；字段名称不附加这些数据或判定。

以 $\overline{ℚ}$ 表示指定的代数闭包 `AlgebraicClosure ℚ`。在唯一曲线指标处，点类型为

$$
\mathcal P=\{z∈\overline{ℚ}:z≠0\text{ 且 }z≠1\}.
$$

一个点由代数闭包中的元素及上述两个不等关系的见证组成。这里没有按共轭关系取商，也没有按定义体的选择取商，并且没有另添无穷远点。对这样的元素 $z$，令 $n_z$ 为它在 $ℚ$ 上的极小多项式次数，令 $F_z=ℚ(z)⊆\overline{ℚ}$ 为相应的单生成中间域，令 $g_z∈F_z$ 为其生成元，其在 $\overline{ℚ}$ 中的像就是 $z$。$F_z$ 是数域，$n_z>0$，并且 $n_z=[F_z:ℚ]$。对相应的点 $x$，记 $n_x=n_z$。

对每个自然数 $d$，唯一指标处的两个子集为

$$
\mathrm{ptLE}(*,d)=\{x∈\mathcal P:n_x≤d\},\qquad
\mathrm{ptEQ}(*,d)=\{x∈\mathcal P:n_x=d\}.
$$

该结构包含以下恒等式：$d=0$ 时第一个子集为空，并且 $\mathrm{ptLE}(*,d+1)=\mathrm{ptLE}(*,d)∪\mathrm{ptEQ}(*,d+1)$。这里的自然数包括零；使用有限次数界不表示满足该界的点集是有限集。

同一指标处的三个函数都以 $\mathcal P$ 为定义域、以 $ℝ$ 为陪域。若 $x$ 由 $z$ 表示，则三个函数为

$$
h(x)=\frac{\log H_{F_z}(g_z)}{n_z},\qquad
δ(x)=\frac{\log|\operatorname{disc}(F_z)|}{n_z},\qquad
κ(x)=\frac{1}{n_z}\sum_{v∈B_z}\log N(\mathfrak p_v),
$$

分别对应字段 `htCan`、`logDiff`、`logCond`。判别式为数域判别式，先从整数转为实数，再取绝对值。对 $F_z$ 的有限处 $v$，$\mathfrak p_v$ 为它所对应的整数环中的素理想，$N(\mathfrak p_v)$ 为其理想绝对范数，在公式中转为实数。最后一个公式所用的有限处集为

$$
B_z=\{v:\ v(g_z)≠1\text{ 或 }v(g_z-1)≠1\}.
$$

这里的有限处在非零元素上给出正实数值的乘性绝对值，不是加性赋值。对每个 $x∈\mathcal P$，集合 $B_z$ 都是有限集，因此上述导子公式中的和是有限和。每个坏处贡献一次其范数的对数；公式没有另给这项贡献附加分歧重数。三个分母均因 $n_z>0$ 而为正。

高度采用以下规范化：

$$
H_{F_z}(g_z)=
\prod_{w\in M_{F_z}^{\infty}}\max(w(g_z),1)^{m_w}
\prod_{v\in M_{F_z}^{\mathrm{fin}}}\max(v(g_z),1).
$$

其中 $M_{F_z}^{\mathrm{fin}}$ 和 $M_{F_z}^{\infty}$ 分别为 $F_z$ 的有限处集和无限处集。重数 $m_w$ 在实处取一，在复处取二。有限处乘积有有限乘性支撑。因此，$h(x)=n_z^{-1}\log H_{F_z}(g_z)$ 使用生成元自身所在数域中的高度，并在取对数后除以次数。三个函数 $h,δ,κ$ 均非负；该定义将它们的取值用作结构字段。

赋给字段 `CBS` 的类型由记录 $K=(V,c)$ 组成，并带有 $V$ 是自然素数的有限集合及 $2∈V$ 的证明，其中 $c∈ℝ$。不要求 $c≥0$ 或 $c>0$。这些记录给出“[术语待定：compactly bounded subset]”的一种指定表示。对每份记录，字段 `cbsSet` 给出 $\mathcal P$ 的如下子集：

$$
\begin{aligned}
S_{V,c}=\bigl\{x\in\mathcal P:\;&
\forall v\in M_{F_z}^{\mathrm{fin}},\quad
p_v\in V\Rightarrow
\bigl(|\log v(g_z)|\leq c\ \land\ |\log v(g_z-1)|\leq c\bigr);\\
&\forall w\in M_{F_z}^{\infty},\quad
|\log w(g_z)|\leq c\ \land\ |\log w(g_z-1)|\leq c
\bigr\}.
\end{aligned}
$$

其中 $z$ 表示 $x$，$p_v$ 是实际商环 $\mathcal O_{F_z}/\mathfrak p_v$ 的特征。无限处也作为乘性绝对值作用。即使数域随点变化，同一个 $c$ 仍同时适用于两项表达式、所有指定的处，以及该子集中的所有点。有限处条件适用于剩余特征属于 $V$ 的**每个**处。这里不对 $V$ 之外的有限处施加条件。$S_{V,c}$ 的定义本身没有次数界。由于 $z$ 和 $z-1$ 非零，成员条件中各对数的自变量都为正；数据允许 $c$ 为负，并没有假设所给子集非空。

字段 `cbsSet` 就是上述从记录到子集的显式成员条件构造；记录类型并未定义为所有拓扑紧子集组成的集合。该声明没有另添拓扑、紧性证明、额外支撑集 $Σ$，也没有给出其与这种几何概念对应的证明。结构包含的正是上述点和次数数据、三个函数、常值谓词、指定指标、记录类型及子集映射。该定义为高度不等式提供数据，本身不陈述或证明这种不等式或算术猜想。

## 论文来源与范围

数学来源为望月新一《Arithmetic Elliptic Curves in General Position》二〇〇九年二月版第 1 节及定理 2.1(ii)。定义 1.2(i) 在第 5 页引入高度；例 1.3(i)–(ii) 在第 5–6 页讨论次数限制与[术语待定：compactly bounded subset]；定义 1.5(iii)–(iv) 在第 8 页给出对数不同函数和对数导子函数。上述页码均同时对应印刷页码与文件页序。英文来源部分逐段引录第 11 页定理 2.1(ii) 的完整分项。

该引文提供点、次数、高度和子集数据的数学背景，其内容是等价定理中的一个猜想条件。本定义组织所选数据，不证明该条件或等价定理。点对应于引文中 $U_P$ 的仿射坐标，函数和子集则由前述数学定义中的精确公式指定。该定义没有证明所用高度与 $\mathrm{ht}_{\omega_P(C)}$ 的几何识别，也没有证明这些子集记录表示例 1.3(ii) 中的全部局部紧区域。支撑集变量 $\Sigma$ 属于引文中的条件，不是本定义的额外参数。

## 直观解释（非严格）

这些数据把除 $0$、$1$ 外的代数数组织到同一个高度理论接口中。次数记录点所在数域的大小；三个实值函数分别衡量高度、判别式与坏有限处。子集 $S_{V,c}$ 在所有无限处及所选有限素数集上方的全部有限处施加统一的对数界。这一直观说明不附加高度不等式或几何紧性定理。

---

# 日本語

## 数学的定義

この定義は固定された非計算的な高さ理論を与え、明示的・暗黙の数学的パラメータも、外部の型クラスの仮定も持たない。この構造は小さい型の宇宙に属する。曲線の添字型は唯一の元を持つ型 `Unit` であり、その元を $*$ と書く。指定された添字 `tripod` は $*$ である。各曲線の添字に対して、述語 `Hyperbolic` は常に真となる命題 `True`、`DivisorFree` は常に偽となる命題 `False` に定められる。したがって、前者は唯一の添字で成り立つ。この定義は射影直線や因子を構成せず、いずれの述語についても幾何学的な判定を与えない。フィールドの名称によって、そのようなデータや判定が加わるわけではない。

$\overline{ℚ}$ は指定された代数閉包 `AlgebraicClosure ℚ` を表す。唯一の曲線の添字における点の型は

$$
\mathcal P=\{z∈\overline{ℚ}:z≠0\text{ かつ }z≠1\}
$$

である。点は代数閉包の元と、これら二つの不等式の証明からなる。共役関係や定義体の選択による商は取らず、無限遠点も追加しない。このような元 $z$ に対して、$n_z$ を $ℚ$ 上の最小多項式の次数、$F_z=ℚ(z)⊆\overline{ℚ}$ を単純中間体とし、$g_z∈F_z$ をその生成元とする。$g_z$ の $\overline{ℚ}$ における像は $z$ である。$F_z$ は数体であり、$n_z>0$ および $n_z=[F_z:ℚ]$ が成り立つ。対応する点 $x$ に対して $n_x=n_z$ と書く。

各自然数 $d$ に対して、唯一の添字における部分集合は

$$
\mathrm{ptLE}(*,d)=\{x∈\mathcal P:n_x≤d\},\qquad
\mathrm{ptEQ}(*,d)=\{x∈\mathcal P:n_x=d\}
$$

である。構造には、$d=0$ のとき前者が空であること、および $\mathrm{ptLE}(*,d+1)=\mathrm{ptLE}(*,d)∪\mathrm{ptEQ}(*,d+1)$ という恒等式が含まれる。自然数は零を含む。有限の次数の上限を課すことは、その上限を満たす点の集合が有限であるという主張ではない。

同じ添字における三つの関数は、いずれも定義域が $\mathcal P$、終域が $ℝ$ である。$x$ が $z$ によって表されるとき、これらは

$$
h(x)=\frac{\log H_{F_z}(g_z)}{n_z},\qquad
δ(x)=\frac{\log|\operatorname{disc}(F_z)|}{n_z},\qquad
κ(x)=\frac{1}{n_z}\sum_{v∈B_z}\log N(\mathfrak p_v)
$$

であり、それぞれ `htCan`、`logDiff`、`logCond` に対応する。判別式は数体の判別式であり、整数から実数に移した後で絶対値を取る。$F_z$ の有限素点 $v$ に対し、$\mathfrak p_v$ は対応する整数環の素イデアル、$N(\mathfrak p_v)$ はその絶対イデアルノルムであり、式では実数に移される。最後の式に用いる有限素点の集合は

$$
B_z=\{v:\ v(g_z)≠1\text{ または }v(g_z-1)≠1\}
$$

である。ここで有限素点は、零でない元に対して正の実数値を取る乗法的絶対値として作用し、加法的付値ではない。各 $x∈\mathcal P$ に対して $B_z$ は有限であるため、上の導手の式に現れる和は有限和である。各素点はそのノルムの対数を一度寄与し、式ではその寄与に別の分岐の重複度を付けない。三つの分母はいずれも $n_z>0$ によって正である。

高さの正規化は次の式で与えられる。

$$
H_{F_z}(g_z)=
\prod_{w\in M_{F_z}^{\infty}}\max(w(g_z),1)^{m_w}
\prod_{v\in M_{F_z}^{\mathrm{fin}}}\max(v(g_z),1).
$$

ここで $M_{F_z}^{\mathrm{fin}}$ と $M_{F_z}^{\infty}$ は、それぞれ $F_z$ の有限素点と無限素点の集合である。重複度 $m_w$ は実素点では一、複素素点では二である。有限素点上の積は有限の乗法的台を持つ。したがって、$h(x)=n_z^{-1}\log H_{F_z}(g_z)$ は生成元が属する数体における高さを用い、対数を取った後に次数で割る。三つの関数 $h,δ,κ$ は非負であり、この定義はそれらの値を構造のフィールドに用いる。

フィールド `CBS` に割り当てる型は、記録 $K=(V,c)$ と、$V$ が自然数の素数からなる有限集合であり $2∈V$ であることの証明からなる。ここで $c∈ℝ$ であり、$c≥0$ も $c>0$ も要求されない。これらの記録は「コンパクト有界部分集合（compactly bounded subset）」の指定された表示を与える。各記録に対して、フィールド `cbsSet` は $\mathcal P$ の次の部分集合を与える。

$$
\begin{aligned}
S_{V,c}=\bigl\{x\in\mathcal P:\;&
\forall v\in M_{F_z}^{\mathrm{fin}},\quad
p_v\in V\Rightarrow
\bigl(|\log v(g_z)|\leq c\ \land\ |\log v(g_z-1)|\leq c\bigr);\\
&\forall w\in M_{F_z}^{\infty},\quad
|\log w(g_z)|\leq c\ \land\ |\log w(g_z-1)|\leq c
\bigr\}.
\end{aligned}
$$

ここで $z$ は $x$ を表し、$p_v$ は実際の商環 $\mathcal O_{F_z}/\mathfrak p_v$ の標数である。無限素点も乗法的絶対値として作用する。数体が点によって変わっても、同じ $c$ が二つの式、指定されたすべての素点、およびこの部分集合に属するすべての点に共通に用いられる。有限素点の条件は、剰余標数が $V$ に属する**すべての**素点に適用される。$V$ の外の有限素点には、ここでは条件を課さない。$S_{V,c}$ 自体の定義に次数の上限はない。$z$ と $z-1$ は零でないため、所属条件に現れる対数の引数は正である。$c$ が負である記録も許され、与えられた部分集合が空でないという仮定はない。

フィールド `cbsSet` は、この明示的な所属条件によって記録から部分集合を作る写像である。記録の型は、位相的にコンパクトな部分集合すべての集まりとして定義されているわけではない。この宣言は位相、コンパクト性の証明、追加の台の集合 $Σ$、あるいはそのような幾何学的概念との対応の証明を加えない。構造に含まれるのは、上述の点と次数のデータ、三つの関数、定数である述語、指定された添字、記録の型、および部分集合への写像である。この定義は高さの不等式に用いるデータを与えるものであり、そのような不等式や数論的予想を述べたり証明したりするものではない。

## 論文の出典と範囲

数学的な出典は、望月新一の *Arithmetic Elliptic Curves in General Position*、2009 年 2 月版の第 1 節と定理 2.1(ii) である。定義 1.2(i) は第 5 ページで高さを導入する。例 1.3(i)–(ii) は第 5–6 ページで次数の制限とコンパクト有界部分集合を扱う。定義 1.5(iii)–(iv) は第 8 ページで対数不同関数と対数導手関数を定義する。これらのページ番号は印刷ページと PDF のファイルページの両方に一致する。英語の出典説明には、第 11 ページの定理 2.1(ii) の全項を引用した。

引用は点、次数、高さ、および部分集合のデータの数学的背景を与え、その内容は同値定理に現れる予想に当たる条件である。この定義は選択したデータをまとめるものであり、その条件や同値定理を証明しない。点は引用中の $U_P$ のアフィン座標に対応し、関数と部分集合は上記の数学的定義にある正確な式で指定する。この定義は、用いる高さと $\mathrm{ht}_{\omega_P(C)}$ の幾何学的な同一視や、これらの記録が例 1.3(ii) のすべての局所的なコンパクト領域を表すことを証明しない。台の集合の変数 $\Sigma$ は引用中の条件に属し、この定義の追加パラメータではない。

## 直観的説明（非厳密）

このデータは、$0$ と $1$ 以外の代数的数を一つの高さ理論のインターフェースにまとめる。次数は点の数体の大きさを記録し、三つの実数値関数は高さ、判別式、および悪い有限素点を測る。集合 $S_{V,c}$ は、すべての無限素点と、選択した有限素数集合の上にあるすべての有限素点で共通の対数の上限を課す。この説明は高さの不等式や幾何学的なコンパクト性の定理を加えるものではない。
