#!/usr/bin/env python3
"""Read evidence; write only this task's /tmp directory. No CI, API, Git, cleanup."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tarfile
import time
import copy
import io
import re
from normalization_v97 import validate as validate_normalization_v97

TASK = Path('/tmp/p2m-archive-finish-v97-20261117')
HISTORY92 = Path('/tmp/p2m-archive-finish-v93-20261117/history-v92')
HISTORY90 = Path('/tmp/p2m-basic55-archive-v90-20261117/history-v90')
ROOT = Path('/home/admin-wsl/Coq/abc')
W = ROOT / 'prove2me_workspace'
A = W / '.local/adaptation'
CI = A / 'main-chain-open-20261116'
NATIVE = A / 'basic-native-identity-v75-20261116'
NORM = A / 'basic-absnorm-normalization-v88-20261117'
API = A / 'basic-torsion-api-v94-20261117'
CONFIG = NATIVE / 'configs/comparison-free-proof.bound-v98.json'
QUERY = NORM / 'target/AuditBasicNativeComparison.lean'
LABEL = 'basic-native-comparison-with-absnorm-v90'
PAYLOAD = Path('/tmp/p2m-tripod-metadata-finish-v85-20261117/payload.json')
READBACK = Path('/tmp/p2m-tripod-theory-blind-readback-v77-20261116')
SUPPORT = {'Iut.Tripod.deg_eq_finrank', 'Iut.Tripod.logCond_eq_sum',
           'Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal'}
STANDARD = {'propext', 'Classical.choice', 'Quot.sound'}
EXCLUDED = {'.git', '.lake', '__pycache__', 'node_modules'}
PREBUILT = {'.olean', '.ilean', '.ir', '.o', '.a', '.so'}


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(p):
    return json.loads(Path(p).read_text())


def write(p, d):
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')


def walk_json(x):
    if isinstance(x, dict):
        yield x
        for v in x.values():
            yield from walk_json(v)
    elif isinstance(x, list):
        for v in x:
            yield from walk_json(v)


def lean_name(x):
    if not x:
        return ''
    return '.'.join(filter(None, [lean_name(x[0]), str(x[2])]))


def checked_ci(p, review=False):
    d = read(p)
    r = d.get('result', {})
    q = d.get('request', {})
    snap = r.get('snapshot', {})
    assert d.get('status') == 'succeeded', 'CI is not succeeded'
    assert r.get('exit_code') == 0, 'CI exit code is not zero'
    assert Path(q['workspace']).resolve() == W.resolve(), 'wrong CI workspace'
    assert q.get('exclusive') is True, 'not exclusive'
    assert snap.get('workspace_mode') == 'exclusive_worktree', 'wrong workspace mode'
    assert snap.get('snapshot_id') is None, 'unexpected snapshot'
    peak = (d.get('resources') or r.get('resources') or {}).get('peak_rss_bytes')
    assert peak is None or peak <= 16 * 1024**3, 'leaf physical RSS exceeds 16 GiB; split required'
    if review:
        assert q.get('task_type') == 'review', 'not a review task'
        rev = r.get('review', {})
        assert rev.get('passed') is True, 'review not passed'
        assert rev.get('checks', {}).get('no_sorryAx') is True, 'sorryAx check missing'
        assert rev.get('checks', {}).get('assumptions_reported') is True, 'assumptions not reported'
        assert not rev.get('violations'), 'review violations'
        for line in rev.get('assumptions', []):
            if 'depends on axioms:' in line:
                names = line.split('depends on axioms:', 1)[1].strip()
                assert names.startswith('[') and names.endswith(']')
                assert set(x.strip() for x in names[1:-1].split(',') if x.strip()) <= STANDARD, 'review reported nonstandard axiom'
        stdout = r.get('stdout', '')
        assert "'AbcAdaptation.Tripod.tripodTheory' depends on axioms: [propext, Classical.choice, Quot.sound]" in stdout, 'tripodTheory axiom output missing'
    return d


def resources(d):
    r = d.get('resources') or d.get('result', {}).get('resources') or {}
    total, user, system = (r.get(k) for k in ('cpu_time_seconds', 'cpu_user_seconds', 'cpu_system_seconds'))
    consistent = None if None in (total, user, system) else abs(total - user - system) < 0.02
    return {**r, 'cpu_total_equals_user_plus_system': consistent,
            'memory_basis': 'MCP-CI process-tree physical RSS/PSS; bytes; missing values remain null',
            'peak_rss_GiB': r.get('peak_rss_bytes') / 1024**3 if r.get('peak_rss_bytes') is not None else None,
            'peak_pss_GiB': r.get('peak_pss_bytes') / 1024**3 if r.get('peak_pss_bytes') is not None else None,
            'resource_source': r.get('resource_source', r.get('source')),
            'resource_degraded': r.get('degraded'),
            'resource_source_missing_means_unknown': True}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--expected-metadata-heartbeats', type=int, choices=[1000000, 2000000, 4000000], default=1000000, help='Bounded per-run_meta audit budget; never a production proof budget')
    ap.add_argument('--label', default='v98', help='Final attempt label, e.g. v98; never implies success')
    ap.add_argument('--evidence-directory', type=Path, help='Intended persistent evidence directory, used in registration proposals only')
    ap.add_argument('--registry', type=Path, default=A / 'platform-node-registry.json')
    ap.add_argument('--duplicate-draft', type=Path, action='append', default=[], help='Explicit exact new-definition draft; only recorded as cleanup candidate, never deleted')
    ap.add_argument('--archive', action='store_true', help='Require every completion gate and write/reopen tar.gz')
    ap.add_argument('--output', type=Path, default=TASK / 'dryrun')
    ap.add_argument('--final-receipt', '--review-result', dest='review_result', type=Path, default=CI / 'basic-native-comparison-with-free-proof-v98-result.json', help='Exact final MCP-CI result (v90 is a failed historical attempt)')
    ap.add_argument('--config', type=Path, default=CONFIG, help='Exact final bound config')
    ap.add_argument('--query', type=Path, default=QUERY, help='Exact final query checked by receipt')
    ap.add_argument('--publication-readback', type=Path, default=NORM / 'publication/published-item.json')
    ap.add_argument('--publication-receipt', type=Path, default=NORM / 'publication/publish-result.json')
    ap.add_argument('--publication-journal', type=Path, default=NORM / 'publication/publish-intent.json')
    args = ap.parse_args()
    out = args.output.resolve()
    assert out != TASK and TASK in out.parents, 'output must be a child of the task /tmp directory'
    out.mkdir(parents=True, exist_ok=True)
    evidence = args.evidence_directory.resolve() if args.evidence_directory else out
    config_path, query_path = args.config.resolve(), args.query.resolve()
    cfg = read(config_path)
    selected = {lean_name(x) for x in cfg['selectedSourceNames']}
    source = cfg['sourceFactsBinding']['contents']
    native = cfg['nativeFactsBinding']['contents']
    actual_path = Path(cfg['outputFile'])
    gates, errors = {}, {}

    def gate(name, fn):
        try:
            result = fn()
            gates[name] = True
            return result
        except (OSError, ValueError, KeyError, TypeError, AssertionError) as e:
            gates[name] = False
            errors[name] = str(e)
            return None

    def bindings():
        assert len(selected) == 55
        assert len(cfg['selectedSourceNames']) == 55
        assert len({r['name'] for r in source['records']}) == 99
        assert cfg['full99IntegrationClaimed'] is False
        assert len(source['records']) == 99
        for row in source['records']:
            if row['name'] in selected:
                assert row['hasSorryAx'] is False
                for key in ('axioms', 'typeAxioms', 'valueAxioms'):
                    assert set(row[key]) <= STANDARD, 'selected source has nonstandard axioms'
                if row['name'] in SUPPORT:
                    assert row['theoremProofValueRead'] is False, 'support proof-body scope changed'
        for key in ('sourceFactsBinding', 'nativeFactsBinding', 'sourceAbsNormNormalizationBinding'):
            b = cfg[key]
            assert sha(b['path']) == b['sha256'], 'bound facts changed: ' + key
            assert read(b['path']) == b['contents'], 'embedded contents differ: ' + key
        return True
    gate('bound_facts_unchanged', bindings)

    def historical_v90():
        manifest = read(HISTORY90 / 'manifest.json')
        for row in manifest:
            assert sha(row['copy']) == row['sha256'], 'historical v90 copy changed: ' + row['copy']
        old = read(HISTORY90 / 'basic-native-comparison-with-absnorm-v90-result.json')
        assert old['job_id'] == 'ci-018235-32a3caf2' and old['status'] == 'failed'
        assert old['result']['exit_code'] != 0
        old_source = str(QUERY)
        assert old['request']['worktree_manifest']['input_hashes'][old_source] == sha(HISTORY90 / 'AuditBasicNativeComparison.lean')
        assert any('heartbeats' in x.get('message', '') for x in old['result']['diagnostics'])
        return True
    gate('failed_v90_input_and_receipt_preserved', historical_v90)

    def historical_v91():
        receipt = read(CI / 'basic-native-comparison-with-absnorm-v91-result.json')
        saved = NORM / 'history-v91/AuditBasicNativeComparison.lean'
        assert receipt['job_id'] == 'ci-018249-e155dbdd' and receipt['status'] == 'failed'
        assert receipt['result']['exit_code'] == -6
        assert 'cannot evaluate `[init]` declaration' in receipt['result']['stderr']
        assert 'in the same module' in receipt['result']['stderr']
        assert receipt['request']['worktree_manifest']['input_hashes'][str(QUERY)] == sha(saved)
        return True
    gate('failed_v91_cache_attempt_input_and_receipt_preserved', historical_v91)

    def historical_v92():
        receipt = read(HISTORY92 / 'basic-native-comparison-with-absnorm-v92-result.json')
        assert receipt['job_id'] == 'ci-018255-6b09f950' and receipt['status'] == 'failed'
        assert receipt['result']['exit_code'] != 0
        assert any("unknown constant 'instIsTorsionFreeIntOfHasUniqueDiv'" in row.get('message', '') for row in receipt['result']['diagnostics'])
        for row in read(HISTORY92 / 'manifest.json'):
            if row['copied']:
                assert sha(row['copy']) == row['sha256'], 'v92 saved input changed: ' + row['original']
                assert receipt['request']['worktree_manifest']['input_hashes'][row['original']] == row['sha256']
        assert receipt['request']['environment']['BASIC_NATIVE_COMPARE_CONFIG'] in receipt['request']['worktree_manifest']['input_hashes']
        return True
    gate('failed_v92_unknown_source_instance_name_input_and_receipt_preserved', historical_v92)

    def normalization():
        b = cfg['sourceAbsNormNormalizationBinding']
        actual_path = Path(b['path'])
        d = read(actual_path)
        assert sha(actual_path) == b['sha256'] and d == b['contents']
        receipt = b['receipt']
        assert sha(receipt['path']) == receipt['sha256']
        assert read(receipt['path']) == receipt['contents']
        checked_ci(receipt['path'])
        query = b['producerQuery']
        assert sha(query['path']) == query['sha256']
        assert b['contract'] == 'exact-four-source-fields-and-one-same-Prop-proof-kernel-normalized-in-successful-source4.35-job'
        law = validate_normalization_v97(cfg, d, receipt['contents'], actual_path)
        assert receipt['contents']['request']['worktree_manifest']['input_hashes'][str(Path(query['path']).resolve())] == query['sha256']
        write(out / 'source-normalization-law.json', law)
        return receipt['contents']
    normalization_receipt = gate('four_source_normalizations_and_exact_one_sameProp_proof_kernel_checked', normalization)

    def actual_api_and_overlap():
        source_receipt = checked_ci(CI / 'basic-torsion-source-api-v95-result.json')
        target_receipt = checked_ci(CI / 'basic-target-api-and-missing-inventory-v95-result.json')
        assert source_receipt['job_id'] == 'ci-018317-f80d293f'
        assert target_receipt['job_id'] == 'ci-018332-f836835f'
        for receipt, compiler, filename in [(source_receipt, '4.35.0-rc3', 'source-api.actual.json'),
                                             (target_receipt, '4.33.1', 'target-api.actual.json')]:
            d = read(API / filename)
            assert d['schema'] == 'Basic-torsion-api-actual/v93' and d['compilerVersion'] == compiler
            for flag in ['renameOrSubstitutionAccepted', 'foreignExprKernelChecked', 'foreignExprDecoded']:
                assert d[flag] is False
            q, r = receipt['request'], receipt['result']
            assert q['task_type'] == 'leaf' and q['target'] == 'file'
            assert r['actual_arguments'] == ['lean', q['parameters']['source']]
            api_cfg = Path(q['environment']['BASIC_TORSION_API_CONFIG'])
            assert d['configuration'] == read(api_cfg)
            assert Path(d['configuration']['outputFile']).resolve() == (API / filename).resolve()
            for path in (W / q['parameters']['source'], api_cfg):
                assert q['worktree_manifest']['input_hashes'][str(path)] == sha(path)
        inventory = read(API / 'target-constant-existence.actual.json')
        assert inventory['schema'] == 'Basic-target-constant-existence-actual/v93'
        assert inventory['compilerVersion'] == '4.33.1'
        assert inventory['all55ComparedClaimed'] is False
        assert inventory['foreignExprKernelChecked'] is False and inventory['foreignExprDecoded'] is False
        inventory_cfg = Path(target_receipt['request']['environment']['BASIC_TARGET_CONSTANT_INVENTORY_CONFIG'])
        assert inventory['configuration'] == read(inventory_cfg)
        assert target_receipt['request']['worktree_manifest']['input_hashes'][str(inventory_cfg)] == sha(inventory_cfg)
        old = {'instIsTorsionFreeIntOfHasUniqueDiv', 'IsAffineAddMonoid.toHasUniqueDiv', 'HasUniqueDiv.of_isCancelMulZero_charZero'}
        assert inventory['requiredMissingCount'] == 3
        assert {r['targetName'] for r in inventory['requiredMissing']} == old
        assert all(r['exists'] is False for r in inventory['requiredMissing'])
        source_api = read(API / 'source-api.actual.json')
        for name in old:
            assert len([r for r in source_api['records'] if r.get('actualName') == name and r['exists'] is True]) == 1
        summary = read(API / 'exclusive-overlap-v96/audit-summary.json')
        assert summary['schema'] == 'exclusive-task-overlap-audit/v96'
        assert summary['sameWorkspace'] is True and summary['mathematicalFailureClaimed'] is False
        observed = {r['jobId']: r for r in summary['observedJobs']}
        assert observed['ci-018332-f836835f']['status'] == 'succeeded'
        assert observed['ci-018336-3f4456fa']['status'] == 'cancelled'
        cancelled = read(Path(observed['ci-018336-3f4456fa']['receipt']))
        assert cancelled['job_id'] == 'ci-018336-3f4456fa' and cancelled['status'] == 'cancelled'
        assert observed['ci-018336-3f4456fa']['cancelledLaterJob'] is True
        assert observed['ci-018336-3f4456fa']['startedAt'] < observed['ci-018332-f836835f']['finishedAt']
        write(out / 'api-and-overlap-history.json', {
            'sourceAPIJob': source_receipt['job_id'], 'targetAPIJob': target_receipt['job_id'],
            'actualAPIIsEvidenceOnly': True, 'affineFGClassEquivalenceClaimed': False,
            'oldNewIsAddTorsionFreeMapped': False, 'missingTargetNames': sorted(old),
            'overlapSummary': summary, 'cancelledJob': cancelled['job_id'], 'cancelledJobMathematicalFailureClaimed': False})
        return True
    gate('actual_source_target_API_and_overlap_cancel_history_preserved', actual_api_and_overlap)
    gate('new_definition_leaf', lambda: checked_ci(CI / 'tripod-theory-leaf-v79-result.json'))
    gate('new_definition_artifact', lambda: checked_ci(CI / 'tripod-theory-artifact-v79-result.json'))

    def independent_readback():
        d = read(READBACK / 'manifest.json')
        for name, digest in d['artifacts_sha256'].items():
            assert sha(READBACK / name) == digest, 'readback artifact changed: ' + name
        for key in ['formal_inputs_read_in_full_sha256', 'mathlib_source_inputs_sha256',
                    'local_formal_inputs_direct_mathlib_import_hashes', 'rules_sha256',
                    'japanese_terminology_reference_sha256']:
            for name, digest in d[key].items():
                assert sha(name) == digest, 'readback source changed: ' + name
        return True
    gate('independent_trilingual_readback_integrity', independent_readback)

    def review():
        d = checked_ci(args.review_result, review=True)
        q, r = d['request'], d['result']
        assert (W / q['parameters']['source']).resolve() == query_path, 'wrong query'
        assert r['actual_arguments'] == ['lean', q['parameters']['source']], 'wrong actual arguments'
        m = q.get('worktree_manifest', {})
        for p in (query_path, config_path, Path(cfg['sourceEnrichedFacts']), Path(cfg['nativeInventoryFacts'])):
            assert m['input_hashes'][str(p)] == sha(p), 'review input changed: ' + str(p)
        text = query_path.read_text()
        assert Path(q['environment']['BASIC_NATIVE_COMPARE_CONFIG']).resolve() == config_path, 'review environment config binding differs'
        assert 'BASIC_NATIVE_COMPARE_CONFIG' in text, 'query config environment reader missing'
        assert not [x for x in r.get('diagnostics', []) if x.get('severity') == 'error'], 'review error diagnostic'
        assert not [x for x in r.get('review', {}).get('diagnostics', []) if x.get('severity') == 'error'], 'review scanner error diagnostic'
        for module in ['Checks', 'ImportAudit', 'Act1Scene1', 'AxiomAudit']:
            assert module in text, 'aggregate import missing: ' + module
        assert '#print axioms AbcAdaptation.Tripod.tripodTheory' in text
        for line in text.splitlines():
            if re.match(r'\s*set_option maxHeartbeats ', line):
                match = re.match(r'\s*set_option maxHeartbeats ([0-9_]+) in\s*$', line)
                assert match and int(match[1].replace('_', '')) == args.expected_metadata_heartbeats, 'only exact bounded local metadata budget is accepted'
        assert text.count('run_meta do') == 1, 'review metadata command structure changed; re-review archive gate'
        assert 'targetNormalizationCache' not in text, 'failed same-module cache attempt was retained'
        for token in ['Basic-absNorm-and-torsionProp-normalization-actual/v97',
                      'sameActualPropProofReplacementOnly', 'freeAndBasisActualBodiesAvoidOriginalTorsionAPI',
                      'sourceSamePropTorsionProofNormalizationUsed', 'sourceNewIsAddTorsionFreeMapped',
                      'affineFGClassEquivalenceClaimed', 'originalAndReplacementProofsKernelChecked']:
            assert token in text, 'v97 source-proof consumer guard missing: ' + token
        return d
    review_receipt = gate('real_55_review_success', review)

    def actual55():
        d = read(actual_path)
        assert d['schema'] == 'Basic-existing-native-comparison/v63'
        assert d['configuration'] == cfg, 'actual output belongs to other configuration'
        assert d['selectedCount'] == 55 and len(d['reports']) == 55
        assert {r['source'] for r in d['reports']} == selected
        assert d['sourceSupportProofsKernelChecked'] == 9 and d['nativeSupportProofsKernelChecked'] == 8
        assert d['all99SourceDeclarationsIntegratedClaimed'] is False
        assert d['sourceAndTargetDataReplacementUsed'] is False
        assert d['transportAssumptionsIntroduced'] is False
        differences = set()
        strict = 0
        target_certificates = {}
        source_by_name = {r['name']: r for r in source['records']}
        native_by_name = {lean_name(r['nameExpr']): r for r in native['records']}
        for row in d['reports']:
            sr = source_by_name[row['source']]
            expected_value_check = not sr['isProposition'] and sr['valueExpr'] is not None
            assert row['computationalValueEqual'] is expected_value_check
            assert row['fullValueKernelEqualityDespiteProofIrrelevance'] is expected_value_check
            assert row['recursorRulesCompared'] == len(sr['recursorRuleRhs'])
            assert row['completeStructureMetadataCompared'] == (sr['structure'] is not None)
            for field, key in [('elaboratedExpr', 'targetTypeNormalizationCertificate'), ('valueExpr', 'targetValueNormalizationCertificate')]:
                c = row[key]
                if c is not None:
                    assert c['originalExpr'] == native_by_name[row['target']][field], 'target certificate raw expression differs from bound inventory'
                    assert c['completeExprKernelDefEq'] is True
                    assert c['completeEqualityProofKernelChecked'] is True
                    assert set(c['axioms']) <= STANDARD
                    for k in ('originalExpr', 'normalizedExpr', 'equalityExpr', 'equalityProofExpr'):
                        assert isinstance(c[k], dict)
                    target_certificates[(row['source'], field)] = c
            assert row['kernelTypeEqual'] is True and row['computationShapeEqual'] is True
            assert row['sourceSamePropTorsionProofNormalizationUsed'] is (row['source'] == 'Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal'), 'wrong source same-Prop proof consumer scope'
            assert row['hasSorryAx'] is False and set(row['axioms']) <= STANDARD
            assert row['rawValueBinderDifferenceRetained'] == (not row['rawValueBinderInfoEqual'])
            assert row['rawSignatureBinderDifferenceRetained'] == (not row['signatureBinderInfoEqual'])
            assert isinstance(row['signatureBinderInfoEqual'], bool)
            if row['signatureBinderInfoEqual']:
                strict += 1
                assert row['supportTheoremTypeStyleCertificate'] is None
            if not row['signatureBinderInfoEqual']:
                differences.add(row['source'])
                c = row['supportTheoremTypeStyleCertificate']
                assert c['completeTypeKernelEqual'] is True and c['explicitEqualityProofKernelChecked'] is True
                assert c['sourceProofValueIdentityClaimed'] is False and c['rawSignatureBinderInfoEqual'] is False
                assert c['source'] == row['source'] and c['target'] == row['target']
                assert c['scope'] == 'existing-support-theorem-type-instance-elaboration-only'
                assert c['sourceFactsSHA256'] == cfg['sourceFactsBinding']['sha256']
                assert c['nativeFactsSHA256'] == cfg['nativeFactsBinding']['sha256']
                assert isinstance(c['completeTypeEqualityExpr'], dict) and isinstance(c['completeTypeEqualityProofExpr'], dict)
        assert strict == 52, 'expected exactly 52 strict raw signatures'
        assert sum(row['computationalValueEqual'] is True for row in d['reports']) == 25, 'expected actual 25 computational definition values'
        assert sum(row['fullValueKernelEqualityDespiteProofIrrelevance'] is True for row in d['reports']) == 25, 'all actual 25 complete data values must remain checked'
        assert sum(row['completeStructureMetadataCompared'] is True for row in d['reports']) == 1, 'expected actual one structure metadata comparison'
        assert sum(row['recursorRulesCompared'] for row in d['reports']) == 1, 'expected actual one recursive RHS comparison'
        assert {row['source'] for row in d['reports'] if row['rawValueBinderInfoEqual'] is False} == {'Iut.Tripod.NorthcottHyp'}, 'preserve the actual NorthcottHyp raw value BinderInfo difference'
        expected = {(n, 'elaboratedExpr') for n in ('Iut.Tripod.logCond_eq_sum', 'Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal', 'Iut.Tripod.one_le_absNorm_real')} | {('Iut.Tripod.logCond', 'valueExpr')}
        assert set(target_certificates) == expected, 'expected exactly four target normalization certificates'
        for row in d['reports']:
            assert row['sourceTypeNormalizationUsed'] == ((row['source'], 'elaboratedExpr') in expected)
            assert row['sourceValueNormalizationUsed'] == ((row['source'], 'valueExpr') in expected)
        assert differences == SUPPORT, 'expected exactly the three existing support TYPE differences'
        return d
    actual = gate('actual_55_correspondence_with_52_strict_3_exceptions_and_four_target_normalizations', actual55)

    payload = read(PAYLOAD)
    publication = None
    def publication_gate():
        node = read(args.publication_readback)
        # Exact observed API schema from statementii-definition-v65/publication.
        for k in ('definition_name', 'definition_title', 'definition', 'natural_language_statement', 'source'):
            assert node[k] == payload[k], 'published readback differs: ' + k
        assert node['visibility'] == 'private' and payload['private'] is True
        assert node['mathlib_rev'] == payload['env'], 'published environment differs'
        assert node['deprecated_at'] is None and node['deprecated_by'] is None
        definition_id = node['definition_id']
        assert definition_id, 'readback definition id missing'
        receipt = read(args.publication_receipt)
        assert receipt['status'] == 'PUBLISHED' and receipt['kind'] == 'definition'
        assert receipt['error_message'] == '' and receipt['formal_statement'] == ''
        assert receipt['theorem_id'] == definition_id and receipt['visibility'] == 'private'
        for key, expected in [('theorem_name', payload['definition_name']), ('theorem_title', payload['definition_title']),
                              ('definitions', payload['definition']), ('natural_language_statement', payload['natural_language_statement']), ('source', payload['source'])]:
            assert receipt[key] == expected, 'publish receipt field differs: ' + key
        assert read(args.publication_journal) == payload, 'publication intent differs from approved payload'
        submit = read(args.publication_receipt.parent / 'publish-submit.json')
        assert submit['job_id'] == receipt['id'] and submit['definition_name'] == payload['definition_name']
        assert submit['status'] == 'PENDING'
        assert len(set(payload)) == 7 and set(payload) == {'definition_name', 'definition_title', 'definition', 'natural_language_statement', 'source', 'env', 'private'}
        assert read(args.publication_receipt.parent / 'payload.json') == payload
        local = W / 'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean'
        assert payload['definition'] == local.read_text(), 'published definition differs from local accepted source'
        return {'id': definition_id, 'name': payload['definition_name'], 'status': 'PUBLISHED', 'visibility': 'private',
                'readback': str(args.publication_readback), 'receipt': str(args.publication_receipt),
                'journal': str(args.publication_journal), 'all_payload_fields_exact': True}
    publication = gate('actual_private_definition_publication_readback', publication_gate)

    complete = all(gates.values())
    state = {'schema': 'Basic55-archive-gates/v97', 'attempt_label': args.label, 'complete': complete,
             'gates': gates, 'errors': errors,
             'scope': '55 selected of 99 pending real target acceptance; 52 strict signatures and 3 exact legacy support TYPE certificates are required completion conditions, not current accepted results; 44 outside this selection remain pending',
             'main_workspace_written': False, 'compilation_or_api_or_git_executed': False,
             'publication': publication}
    write(out / 'completion-gates.json', state)
    prepublication_gates = {k: v for k, v in gates.items() if k != 'actual_private_definition_publication_readback'}
    write(out / 'publication-preconditions.json', {
        'schema': 'Tripod-definition-prepublication-gates/v97',
        'readyToPublish': all(prepublication_gates.values()), 'gates': prepublication_gates,
        'payload': str(PAYLOAD), 'payloadSHA256': sha(PAYLOAD),
        'canonical': str(W / 'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean'),
        'requiresRealBasic55ReviewAndActualOutput': True,
        'nameSearchIsAbsenceProof': False, 'publicationPerformedByThisScript': False,
        'definitionPublicationDoesNotCloseS2_04': True})
    query_text = query_path.read_text()
    write(out / 'metadata-budget-and-failed-attempts.json', {
        'current_query': str(query_path), 'current_query_sha256': sha(query_path),
        'local_metadata_heartbeat_options': re.findall(r'(?m)^\s*set_option maxHeartbeats ([0-9_]+) in\s*$', query_text),
        'scope': 'Only the run_meta audit computation; accepted production theorem/definition proof budgets are not changed',
        'v90': {'job_id': 'ci-018235-32a3caf2', 'status': 'failed', 'cause': 'default metadata heartbeat exhausted', 'source_copy': str(HISTORY90 / 'AuditBasicNativeComparison.lean')},
        'v91': {'job_id': 'ci-018249-e155dbdd', 'status': 'failed', 'exit_code': -6, 'cause': 'same-module initialize cache cannot be evaluated; split-cache proposal rejected by real compilation', 'source_copy': str(NORM / 'history-v91/AuditBasicNativeComparison.lean')},
        'v92': {'job_id': 'ci-018255-6b09f950', 'status': 'failed', 'cause': 'target4.33 has no source4.35 instIsTorsionFreeIntOfHasUniqueDiv; 1M local metadata query budget did not establish correspondence', 'saved_input_manifest': str(HISTORY92 / 'manifest.json')},
        'final_review_job': review_receipt.get('job_id') if review_receipt else None, 'final_attempt_label': args.label})

    # Explicit evidence roots only. Never traverse a .lake cache or another proof task.
    files, pins = {}, {}
    def add(p):
        p = Path(p).absolute()
        if not p.exists() or p.is_dir():
            return
        if p.is_symlink():
            pins[str(p)] = {'path': str(p), 'symlink_target': str(p.resolve()), 'copied': False}
            return
        meta = {'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}
        if p.suffix in PREBUILT or '.lake' in p.parts:
            pins[str(p)] = {**meta, 'copied': False}
        else:
            files[str(p)] = meta
    def tree(root):
        if not root.is_dir():
            return
        for folder, dirs, names in os.walk(root, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d not in EXCLUDED and not Path(folder, d).is_symlink())
            for name in sorted(names):
                if name not in ('credentials.json', '.env'):
                    add(Path(folder, name))
    for root in [NATIVE, NORM, A / 'basic-source-replay-v62-20261116', READBACK, PAYLOAD.parent, HISTORY90, HISTORY92, API]:
        tree(root)
    # Deliberately exclude basic-statementii-bridge-v86 and all other unfinished proofs.
    receipts = []
    for p in sorted(CI.iterdir()):
        if p.is_file() and ((p.name.startswith('basic-') and 'statementii' not in p.name) or p.name.startswith('tripod-theory-') or p.name == 'b1-nine-source-owner-parser-v96-result.json'):
            add(p)
            if p.name.endswith('-result.json'):
                receipts.append((p, read(p)))
    if args.review_result.is_file() and all(p != args.review_result for p, _ in receipts):
        add(args.review_result)
        receipts.append((args.review_result, read(args.review_result)))
    for p in [args.publication_readback, args.publication_receipt, args.publication_journal]:
        if p:
            add(p)
    for name in ('publish-submit.json', 'payload.json'):
        add(args.publication_receipt.parent / name)
    for key, value in read(READBACK / 'manifest.json').items():
        if key.endswith('sha256') or key.endswith('hashes'):
            if isinstance(value, dict):
                for path in value:
                    add(Path(path) if Path(path).is_absolute() else READBACK / path)
    command_map = read(A / 'basic-source-replay-v62-20261116/command-map.json')
    for key in ('source', 'coordinateSource', 'replaySource'):
        add(Path(command_map[key]))
    binding = cfg['sourceAbsNormNormalizationBinding']
    for field in ('producerQuery', 'receipt'):
        if field in binding:
            add(binding[field]['path'])
    add(binding['path'])
    add(config_path)
    add(query_path)
    add(actual_path)
    add(TASK / 'normalization_v97.py')
    add(TASK / 'README.md')
    add(TASK / 'v97-source-law-and-publication.md')
    add(Path('/tmp/p2m-archive-finish-v93-20261117/definition-publication-workflow.md'))
    add(Path(__file__).resolve())
    add(TASK / 'README.md')
    for p, d in receipts:
        q, r = d.get('request', {}), d.get('result', {})
        m = q.get('worktree_manifest', {})
        for path in m.get('input_hashes', {}):
            add(Path(path))
        # Artifact-store internals are accessed only through MCP-CI; raw receipts are retained.
        for artifact in r.get('artifacts', []):
            pins[str(artifact)] = {'path': str(artifact), 'copied': False, 'reason': 'MCP-CI artifact-store reference; raw scheduler receipt retained'}
    for name in ('lean-toolchain', 'lakefile.lean', 'lake-manifest.json'):
        add(W / name)
    for p in [A / 'platform-node-registry.json', ROOT / 'docs/开发计划.Prove2Me适配.md',
              A / 'reference-extraction-20261115/SOURCE_LEDGER.json',
              A / 'reference-extraction-20261115/paper-pdf-manifest.json',
              ROOT / 'docs/三语自然语言读回原则.md']:
        add(p)
    ci_history = [{'path': str(p), 'job_id': d.get('job_id'), 'attempt_id': d.get('attempt_id'), 'status': d.get('status'),
                   'request': d.get('request'), 'compiler': d.get('result', {}).get('compiler'),
                   'stdout': d.get('result', {}).get('stdout'), 'stderr': d.get('result', {}).get('stderr'),
                   'snapshot': d.get('result', {}).get('snapshot'), 'artifacts': d.get('result', {}).get('artifacts'),
                   'exit_code': d.get('result', {}).get('exit_code'),
                   'input_manifest': d.get('request', {}).get('worktree_manifest'),
                   'actual_arguments': d.get('result', {}).get('actual_arguments'),
                   'diagnostics': d.get('result', {}).get('diagnostics'),
                   'resources': resources(d)} for p, d in receipts]
    write(out / 'ci-history.json', ci_history)
    write(out / 'prebuilt-pins.json', list(pins.values()))

    by_name = {r['name']: r for r in source['records']}
    rows = {r['source']: r for r in actual['reports']} if actual else {}
    ledger = {'schema': 'Basic55-source-consumer-ledger/v97', 'status': 'accepted' if complete else 'pending_completion_gates',
              'source99_replay_job': 'ci-017982-9ada6a8c', 'selected_count': 55, 'source_count': 99,
              'source_facts': cfg['sourceFactsBinding']['path'], 'source_facts_sha256': cfg['sourceFactsBinding']['sha256'],
              'native_facts': cfg['nativeFactsBinding']['path'], 'native_facts_sha256': cfg['nativeFactsBinding']['sha256'],
              'actual_output': str(actual_path), 'actual_output_sha256': sha(actual_path) if actual_path.exists() else None,
              'review_job': review_receipt.get('job_id') if review_receipt else None,
              'source_normalization_job': normalization_receipt.get('job_id') if normalization_receipt else None,
              'source_normalization_law': str(evidence / 'source-normalization-law.json'),
              'source_same_Prop_proof_replacement_count': 1 if normalization_receipt else None,
              'nonPropositionalDataReplacementUsed': False, 'affineFGClassEquivalenceClaimed': False,
              'sourceNewIsAddTorsionFreeMapped': False, 'target_normalization_certificate_count': 4 if actual else None,
              'actual_computational_value_count': 25 if actual else None,
              'actual_complete_structure_metadata_count': 1 if actual else None,
              'actual_recursive_rhs_count': 1 if actual else None,
              'raw_value_binder_differences': ['Iut.Tripod.NorthcottHyp'] if actual else None,
              'raw_signature_strict_count': 52 if actual else None, 'raw_signature_false_exception_count': 3 if actual else None,
              'private_definition': publication,
              'paper_source': payload['source'], 'paper_original_quote_and_three_language_text': str(PAYLOAD),
              'independent_readback_manifest': str(READBACK / 'manifest.json'),
              'terminology_pending': {'english': 'compactly bounded subset', 'zh-CN': '[术语待定：compactly bounded subset]', 'status': 'pending; retain exact marker'},
              'all99_integrated': False, 'source_support_theorem_proof_body_identity_claimed': False,
              'pending44': sorted(set(by_name) - selected),
              'producer_consumers': [{'source': n, 'target': rows.get(n, {}).get('target'),
                    'kind': by_name[n]['constantKind'], 'source_module': by_name[n]['module'],
                    'source_type_expr_fact': str(config_path) + '#/sourceFactsBinding/contents/records/' + str(source['records'].index(by_name[n])) + '/elaboratedExpr',
                    'source_data_value_present': by_name[n].get('valueExpr') is not None,
                    'source_theorem_proof_value_read': by_name[n].get('theoremProofValueRead'),
                    'actual_checks': rows.get(n),
                    'fidelity': 'PENDING real target acceptance; no accepted correspondence claimed' if not actual else 'complete kernel TYPE; raw signature BinderInfo differs; exact certificate retained; source proof body not read' if n in SUPPORT else 'strict complete signature and available computational/structural checks; consult actual_checks'}
                    for n in sorted(selected)]}
    write(out / 'SOURCE_LEDGER.json', ledger)
    fragment = {'basic55_native_correspondence': {
        'status': 'ACCEPTED_NARROW_DATA_CORRESPONDENCE' if complete else 'PENDING_COMPLETION_GATES',
        'evidence_directory': str(evidence), 'selected_count': 55, 'source_count': 99, 'pending_source_count': 44,
        'strict_signature_count': 52 if actual else None, 'legacy_support_type_certificate_count': 3 if actual else None,
        'required_strict_signature_count': 52, 'required_legacy_support_type_certificate_count': 3,
        'actual_computational_value_count': 25 if actual else None,
        'required_computational_value_count': 25, 'actual_structure_count': 1 if actual else None,
        'actual_recursive_rhs_count': 1 if actual else None,
        'raw_value_binder_differences': ['Iut.Tripod.NorthcottHyp'] if actual else None,
        'source_proof_identity_claimed': False, 'mathematical_parent_closed': False,
        'source_normalization_schema': 'Basic-absNorm-and-torsionProp-normalization-actual/v97',
        'same_actual_Prop_proof_replacement_count': 1 if normalization_receipt else None,
        'nonPropositionalDataReplacementUsed': False, 'affineFGClassEquivalenceClaimed': False,
        'sourceNewIsAddTorsionFreeMapped': False,
        'root_graph_membership': False, 'private_definition': publication,
        'review_job': review_receipt.get('job_id') if review_receipt else None,
        'source_ledger': str(evidence / 'SOURCE_LEDGER.json'), 'completion_gates': gates}}
    unit = fragment['basic55_native_correspondence']
    unit.update(S2_04Completed=False, two_iff_target_bridges_accepted=False,
                source_support_proof_bodies_read=False, all99_integrated=False)
    definition_unit = {
        'name': payload['definition_name'], 'targetName': 'AbcAdaptation.Tripod.tripodTheory',
        'canonical': str(W / 'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean'),
        'canonicalSha256': sha(W / 'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean'),
        'publication': publication, 'status': 'ACCEPTED_DATA_DEFINITION' if complete else 'PENDING_COMPLETION_GATES',
        'standardAxiomsOnly': bool(review_receipt), 'independentReadback': str(READBACK / 'manifest.json'),
        'leafJob': 'ci-018046-08138ad2', 'artifactJob': 'ci-018050-c51863f6',
        'sourceConsumer': 'Iut.Tripod.tripodTheory', 'actualConsumer': 'AbcAdaptation.Tripod.tripodTheory',
        'mathematicalParentClosed': False, 'S2_04Completed': False, 'root_graph_membership': False}
    fragment = {'reference_source_preparation': {'basic55_native_correspondence': unit,
                'tripod_theory_definition_unit': definition_unit}}
    write(out / 'registry-merge-fragment.json', fragment)
    registry = read(args.registry)
    merged = copy.deepcopy(registry)
    prep = merged['reference_source_preparation']
    prep.update(fragment['reference_source_preparation'])
    appended = None
    if publication:
        appended = {'name': publication['name'], 'id': publication['id'], 'status': 'PUBLISHED',
                    'visibility': 'private', 'source_unit': str(evidence), 'root_graph_membership': False}
        existing = [r for r in prep['definitions'] if r['name'] == publication['name']]
        assert len(existing) <= 1, 'duplicate definition registry name'
        if existing:
            assert existing[0]['id'] == publication['id'], 'same definition name has another platform id'
        else:
            prep['definitions'].append(appended)
    write(out / 'platform-node-registry.merged.json', merged)
    write(out / 'registry-merge-preconditions.json', {
        'base_path': str(args.registry), 'base_sha256': sha(args.registry),
        'replace_exact_paths': ['/reference_source_preparation/basic55_native_correspondence',
                                '/reference_source_preparation/tripod_theory_definition_unit'],
        'append_unique_definition': appended,
        'merge_kind': 'Nested exact-key merge; append the verified definition by unique name/id; preserve all other keys, proof nodes, edges and graph counts',
        'may_apply': complete, 'source_schema_version': registry['schema_version']})
    write(out / 'terminology-status-proposal.json', {'term_en': 'compactly bounded subset', 'term_zh_CN': '[术语待定：compactly bounded subset]', 'status': 'OPEN_TERMINOLOGY_DECISION', 'action': '保留英文及精确待定标记；中文定译须另行有据确认', 'blocks_narrow_data_correspondence': False})
    target_ready = bool(review_receipt and actual and normalization_receipt and gates['bound_facts_unchanged'])
    if target_ready:
        plan = f"""
- [x] 完成本单元所选 Basic99 中 55 项已有原生声明的真实 target 对应验收：实际 25 项定义计算值、1 项结构元数据和 1 条递归 RHS 完整核验；NorthcottHyp 原值 BinderInfo 不同的标记保留为 false。52 项完整原始签名严格一致，3 项旧 support theorem 实例 default lambda 原差异保留并具完整 kernel TYPE 证书。四处 absNorm 及 logDiff TYPE 中恰一处同一命题证明项由 ci-018381 生成 source 完整表达式证书，并经 `{review_receipt['job_id']}` target review 核对；仅用既有 Module.Free.instIsTorsionFree，不替换非命题数据，不声称 FG/affine 类等价或新旧 torsion 类映射。逐项 actual 检查见 SOURCE_LEDGER。
"""
    else:
        plan = """
- [ ] 完成本单元所选 55 项的真实 target 对应验收。所需实际计数为 25 项定义计算值、1 项结构元数据、1 条递归 RHS、52 严格原签名、3 项精确 TYPE 例外和 4 份 target 归一化证书；NorthcottHyp 原值 BinderInfo 差异必须保留。Source v97 仅允许既有 Free 证明的恰一处 same-Prop 替换，不能用 source 成功代替 target 对应。
"""
    if complete:
        plan += """
- [x] 新数据定义 `AbcAdaptation.Tripod.tripodTheory` 的叶检查 ci-018046、产物 ci-018050、独立三语读回、Basic55 最终门及实际私有发布回读均通过。这仅是数据构造及窄范围对应。
"""
    else:
        plan += """
- [ ] 完成新数据定义 `AbcAdaptation.Tripod.tripodTheory` 的归档总门和实际私有发布回读。已有 leaf/artifact 与独立读回只覆盖各自范围；发布及最终归档仍须核对 publication-preconditions 和全部完成门。
"""
    plan += """
- [ ] 两个 iff 的实际 target 接合仍待验收；ci-018232 仅提供两个来源根及三个生成辅助的真实 TYPE/value。55 项之外的 44 项、3 项未读 support source proof body、Basic99 整体集成及 S2-04 均未因本单元闭合；初始数据存在性和无条件 abc 仍开放。
- [ ] 中文术语 `[术语待定：compactly bounded subset]` 保留，待按术语来源单独确定。
"""
    (out / 'plan-append-proposal.md').write_text(plan)
    duplicates = []
    local_definition = W / 'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean'
    protected_replay_paths = {str(Path(path).resolve()) for _, receipt in receipts
                              for path in receipt.get('request', {}).get('worktree_manifest', {}).get('input_hashes', {})}
    protected_replay_paths.update(str(Path(value).resolve()) for node in walk_json(cfg)
                                  for value in node.values() if isinstance(value, str) and value.startswith('/'))
    protected_replay_paths.update([str(query_path.resolve()), str(config_path.resolve())])
    readback_manifest = read(READBACK / 'manifest.json')
    for key, values in readback_manifest.items():
        if (key.endswith('sha256') or key.endswith('hashes')) and isinstance(values, dict):
            protected_replay_paths.update(str(Path(path).resolve()) for path in values if Path(path).is_absolute())
    for p in args.duplicate_draft:
        p = p.resolve()
        assert p != local_definition.resolve(), 'cannot clean integrated definition'
        assert str(p) not in protected_replay_paths, 'cannot clean hash-referenced or bound replay input: ' + str(p)
        assert 'query' not in p.name.lower() and 'queries' not in p.parts, 'cannot clean query inputs'
        assert p.suffix == '.lean' and p.read_text() == payload['definition'], 'cleanup candidate must be exact new-definition duplicate'
        duplicates.append({'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size})
        add(p)
    write(out / 'cleanup-whitelist.json', {'delete_paths': [], 'exact_duplicate_candidates': duplicates, 'hash_referenced_and_bound_inputs_protected': True, 'queries_and_configs_protected': True, 'eligible_only_after_archive_verified': True, 'reason': 'No deletion performed. Only explicitly supplied byte-exact drafts of the new definition can be separately removed after a successful archive re-open/SHA check. Keep integrated definition, iff materials and every other task.'})
    # Generated documents are included, then archive members are reopened and hashed.
    for p in list(out.iterdir()):
        if p.is_file() and p.suffix in ('.json', '.md') and p.name != 'archive-manifest.json':
            add(p)
    manifest = {'schema': 'Basic55-content-archive/v97', 'complete': complete,
                'archive_created': False, 'files': [dict(v, member='files/' + k.lstrip('/')) for k, v in sorted(files.items())],
                'prebuilt_pins_file': str(out / 'prebuilt-pins.json'),
                'policy': 'Copy evidence sources and raw API/CI receipts; pin prebuilt files only; no cache traversal, source deletion, API, CI, Git or main-workspace writes.'}
    write(out / 'archive-manifest.json', manifest)
    if args.archive:
        assert complete, 'completion gates failed; see completion-gates.json'
        archive = out / ('basic55-evidence-' + args.label + '.tar.gz')
        inventory_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
        with tarfile.open(archive, 'w:gz') as t:
            info = tarfile.TarInfo('archive-index.json')
            info.size = len(inventory_bytes)
            t.addfile(info, io.BytesIO(inventory_bytes))
            for item in manifest['files']:
                assert sha(item['path']) == item['sha256'], 'input changed while archiving'
                t.add(item['path'], arcname=item['member'], recursive=False)
        with tarfile.open(archive, 'r:gz') as t:
            assert len(t.getmembers()) == len(manifest['files']) + 1
            assert t.extractfile('archive-index.json').read() == inventory_bytes
            for item in manifest['files']:
                f = t.extractfile(item['member'])
                assert f is not None
                h = hashlib.sha256()
                for block in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(block)
                assert h.hexdigest() == item['sha256'], 'archive member mismatch'
                assert sha(item['path']) == item['sha256'], 'input changed after archive'
        manifest.update(archive_created=True, archive=str(archive), archive_sha256=sha(archive),
                        archive_bytes=archive.stat().st_size, all_members_reopened_sha256_verified=True)
        write(out / 'archive-manifest.json', manifest)
    print(json.dumps({'complete': complete, 'gates': gates, 'errors': errors,
                      'attempt_label': args.label, 'file_count': len(files), 'prebuilt_pin_count': len(pins), 'output': str(out)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
