"""Exact read-only acceptance contract for source v97 normalization evidence."""
import hashlib
import json
from pathlib import Path

STANDARD = {'propext', 'Classical.choice', 'Quot.sound'}
OLD = {'instIsTorsionFreeIntOfHasUniqueDiv', 'IsAffineAddMonoid.toHasUniqueDiv', 'HasUniqueDiv.of_isCancelMulZero_charZero'}
EXPECTED = {('Iut.Tripod.logCond', 'valueExpr'), ('Iut.Tripod.logCond_eq_sum', 'elaboratedExpr'),
            ('Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal', 'elaboratedExpr'), ('Iut.Tripod.one_le_absNorm_real', 'elaboratedExpr')}


def read(p):
    return json.loads(Path(p).read_text())


def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()


def nm(v):
    return '' if not v else nm(v[0]) + ('.' if v[0] else '') + str(v[2])


def count_const(e, name):
    if isinstance(e, dict):
        return int(e.get('kind') == 'const' and nm(e['name']) == name) + sum(count_const(v, name) for v in e.values())
    if isinstance(e, list):
        return sum(count_const(v, name) for v in e)
    return 0


def head_const(e):
    while isinstance(e, dict) and e.get('kind') == 'app':
        e = e['fn']
    return nm(e['name']) if isinstance(e, dict) and e.get('kind') == 'const' else None


def validate(c, n, receipt, actual_path):
    """Check the bounded law. This function never rewrites Expr JSON or invokes Lean."""
    assert c['schema'] == 'Basic-native-comparison-config/v63'
    assert n['schema'] == 'Basic-absNorm-and-torsionProp-normalization-actual/v97'
    assert n['compilerVersion'] == '4.35.0-rc3'
    req, res = receipt['request'], receipt['result']
    assert receipt['status'] == 'succeeded' and res['exit_code'] == 0
    assert req['language'] == 'lean' and req['task_type'] == 'leaf' and req['target'] == 'file'
    assert req['exclusive'] is True
    assert res['snapshot']['workspace_mode'] == 'exclusive_worktree' and res['snapshot']['snapshot_id'] is None
    workspace = Path(req['workspace']).resolve()
    assert workspace == Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
    query = (workspace / req['parameters']['source']).resolve()
    assert res['actual_arguments'] == ['lean', req['parameters']['source']]
    assert not [d for d in res.get('diagnostics', []) if d.get('severity') == 'error']
    export_path = Path(req['environment']['BASIC_ABSNORM_EXPORT_CONFIG']).resolve()
    export = read(export_path)
    assert export == n['configuration']
    assert export['schema'] == 'Basic-absNorm-normalization-export-config/v85'
    assert Path(export['outputFile']).resolve() == Path(actual_path).resolve()
    facts_path = Path(c['sourceEnrichedFacts']).resolve()
    assert Path(export['factsFile']).resolve() == facts_path
    assert sha(facts_path) == export['factsSHA256'] == c['sourceFactsBinding']['sha256'] == n['factsSHA256']
    assert read(facts_path) == c['sourceFactsBinding']['contents']
    for path in (query, export_path, facts_path):
        assert req['worktree_manifest']['input_hashes'][str(path)] == sha(path), 'source producer input changed: ' + str(path)
    assert n['wholeHomReplacementUsed'] is False and n['instanceReplacementUsed'] is True
    assert n['sameActualPropProofReplacementOnly'] is True
    assert n['nonPropositionalDataReplacementUsed'] is False
    assert n['freeAndBasisActualBodiesAvoidOriginalTorsionAPI'] is True
    assert n['sourceTheoremProofValueIdentityClaimed'] is False
    assert len(n['reports']) == 4 and {(nm(z['nameExpr']), z['field']) for z in n['reports']} == EXPECTED
    facts = {nm(z['nameExpr']): z for z in c['sourceFactsBinding']['contents']['records']}
    for z in n['reports']:
        cert, fact = z['certificate'], facts[nm(z['nameExpr'])]
        assert z['levelParams'] == fact['levelParams']
        assert cert['originalExpr'] == fact[z['field']]
        assert z['saturatedAbsNormUses'] == 1
        assert count_const(cert['originalExpr'], 'Ideal.absNorm') == 1
        assert count_const(cert['normalizedExpr'], 'Ideal.absNorm') == 0
        assert count_const(cert['normalizedExpr'], 'Submodule.cardQuot') == 1
        assert cert['completeExprKernelDefEq'] is True and cert['completeEqualityProofKernelChecked'] is True
        for key in ('originalExpr', 'normalizedExpr', 'equalityExpr', 'equalityProofExpr'):
            assert isinstance(cert[key], dict)
        assert head_const(cert['equalityExpr']) == 'Eq' and head_const(cert['equalityProofExpr']) == 'Eq.refl'
        assert set(cert['axioms']) <= STANDARD
        torsion = z['torsionPropProofNormalization']
        if nm(z['nameExpr']) == 'Iut.Tripod.logDiff_eq_log_absNorm_differentIdeal':
            assert z['field'] == 'elaboratedExpr'
            assert torsion['scope'] == 'one-actual-Module.IsTorsionFree-proof-in-existing-logDiff-TYPE'
            assert torsion['normalizedUses'] == 1 and len(torsion['proofApplications']) == 1
            assert torsion['sourceNewIsAddTorsionFreeMapped'] is False
            assert torsion['affineFGClassEquivalenceClaimed'] is False
            assert torsion['nonPropositionalDataReplacementUsed'] is False
            p = torsion['proofApplications'][0]
            for key in ('sameActualPropositionKernelChecked', 'originalAndReplacementProofsKernelChecked',
                        'replacementIsActualFreeTheorem', 'synthesizedOnlyExistingFreeInstance'):
                assert p[key] is True
            assert p['dataReplacementUsed'] is False
            assert len(p['originalActualArgumentsUnderContext']) == 3
            assert p['replacementActualArgumentsUnderContext']
            for key in ('originalProofApplicationUnderContext', 'replacementProofApplicationUnderContext',
                        'originalProofTypeUnderContext', 'replacementProofTypeUnderContext', 'equalityExpr', 'equalityProofExpr'):
                assert isinstance(p[key], dict)
            assert head_const(p['equalityExpr']) == 'Eq' and head_const(p['equalityProofExpr']) == 'Eq.refl'
            assert count_const(p['originalProofTypeUnderContext'], 'Module.IsTorsionFree') == 1
            assert count_const(p['replacementProofTypeUnderContext'], 'Module.IsTorsionFree') == 1
            assert set(p['axioms']) <= STANDARD
            for old in OLD:
                assert count_const(cert['originalExpr'], old) == 1
                assert count_const(cert['normalizedExpr'], old) == 0
                assert count_const(p['replacementProofApplicationUnderContext'], old) == 0
            assert count_const(cert['normalizedExpr'], 'Module.Free.instIsTorsionFree') == 1
            assert count_const(p['replacementProofApplicationUnderContext'], 'Module.Free.instIsTorsionFree') == 1
        else:
            assert torsion is None
    assert len(n['libraryDeclarations']) == 4
    assert {nm(z['nameExpr']) for z in n['libraryDeclarations']} == {'Ideal.absNorm', 'Ideal.absNorm_apply', 'Submodule.cardQuot', 'Submodule.cardQuot_apply'}
    free = n['freeProofLibraryDeclarations']
    assert len(free) == 2
    assert 'Module.Free.instIsTorsionFree' in {nm(z['nameExpr']) for z in free}
    basis = {nm(z['nameExpr']) for z in free} - {'Module.Free.instIsTorsionFree'}
    assert len(basis) == 1 and next(iter(basis)).endswith('.isTorsionFree')
    assert len(n['originalTorsionLibraryDeclarations']) == 3
    assert {nm(z['nameExpr']) for z in n['originalTorsionLibraryDeclarations']} == OLD
    for z in n['libraryDeclarations'] + free + n['originalTorsionLibraryDeclarations']:
        assert isinstance(z['actualTypeExpr'], dict) and isinstance(z['actualValueExpr'], dict)
        assert z['actualTypeAndValueKernelChecked'] is True
        assert set(z['axioms']) <= STANDARD
    for z in free:
        for old in OLD:
            for field in ('actualTypeExpr', 'actualValueExpr'):
                assert count_const(z[field], old) == 0
    return {'schema': n['schema'], 'sourceJob': receipt['job_id'], 'reportCount': 4,
            'samePropProofReplacementCount': 1, 'nonPropositionalDataReplacementUsed': False,
            'freeAndBasisLibraryCount': 2, 'oldAPIMapped': False, 'affineFGClassEquivalenceClaimed': False}
