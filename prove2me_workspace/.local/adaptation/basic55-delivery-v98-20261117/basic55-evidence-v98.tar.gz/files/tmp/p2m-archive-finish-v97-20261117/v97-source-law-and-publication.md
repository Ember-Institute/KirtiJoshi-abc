# 窄 source law 与发布门

这次只更换 source `logDiff_eq_log_absNorm_differentIdeal` 完整 TYPE 中恰一处 `Module.IsTorsionFree ℤ O` 的证明项。原实际命题的全部数据先固定，再调用已有 `Module.Free.instIsTorsionFree` 并仅合成现有 Free 实例。source 内核检查上下文闭包后的原／新证明、实际命题、完整原始 TYPE 到最终 TYPE 和 Eq.refl 等式证书。不能据此声称 HasUniqueDiv、IsAffineAddMonoid 或 FG 类已经迁移，不能把新旧 IsAddTorsionFree 当同义类。

归档门逐份检查四报告及 universe 参数、absNorm/cardQuot 使用次数、所有完整证书和标准公理；Free 与实际 Basis.isTorsionFree 两个库声明保留真实 TYPE/value、内核核验标记及原三 API 不依赖检查。原三 source API 库声明本身仍保留，作为证明转换的原证据，不删除其类型或证明值。

target review 除原合同外，须读取 v97 source scope／计数／真假标记／实际证明证据，确认归一化 source TYPE 不再含旧三 API，实际消费 Free 证明。target actual55 必须逐条记录 `sourceSamePropTorsionProofNormalizationUsed`，且只有 logDiff 项为 true。

`source-normalization-law.json` 记录已通过 source law。`api-and-overlap-history.json` 记录两端实际 API 及取消背景。这两项不替代 `real_55_review_success` 或 `actual_55_correspondence_with_52_strict_3_exceptions_and_four_target_normalizations`。`publication-preconditions.json.readyToPublish` 只有除发布回读外的所有门通过才为 true。

发布流程继续使用 v93 已审查的实见 schema：完整七字段 payload；精确保存 payload、publish-intent、publish-submit、publish-result、published-item。`publish-submit.job_id == publish-result.id` 是发布任务身份；`publish-result.theorem_id == published-item.definition_id` 是定义身份。`PENDING` 不算发布成功，终态须 `kind=definition`、`status=PUBLISHED`、`visibility=private`、无错误；definition/title/natural_language/source/env 的对应字段必须逐字段相等。未获得真实 target55 成功时不进入发布。

原 v93 发布 schema 全文：`/tmp/p2m-archive-finish-v93-20261117/definition-publication-workflow.md`。最终归档保留该文档，不推断新的 API 路由或字段别名。
