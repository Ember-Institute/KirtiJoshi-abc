# Basic55 v97 source-law / v98 target 归档草稿

本目录脚本只读证据，只在本目录子目录写草稿。不执行 CI、Lean、API、Git，不修改主区、不清理材料。

```bash
python3 /tmp/p2m-archive-finish-v97-20261117/prepare_archive.py \
  --label v98 \
  --final-receipt /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/main-chain-open-20261116/basic-native-comparison-with-free-proof-v98-result.json \
  --config /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/basic-native-identity-v75-20261116/configs/comparison-free-proof.bound-v98.json \
  --query /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/basic-absnorm-normalization-v88-20261117/target/AuditBasicNativeComparison.lean \
  --output /tmp/p2m-archive-finish-v97-20261117/dryrun-v98
```

`--final-receipt`、`--config`、`--query` 仍可参数化。发布文件路径参数保留。`--expected-metadata-heartbeats` 默认为单个局部 metadata run_meta 的 1M；不是生产证明预算。`--evidence-directory` 仅填写持久登记建议，不在该路径写文件。只有所有门通过，加 `--archive` 才生成并重开 SHA256 核验 tar。

`normalization_v97.py` 是归档所需的同目录 helper；应与主脚本一起保存。其实际成功输入：source `ci-018381-74bd67f3`，`source-absnorm-with-free-normalization.actual.json`，schema `Basic-absNorm-and-torsionProp-normalization-actual/v97`。它检查绑定 receipt/query/config/facts SHA；4 reports、4 absNorm library declarations；每份原始完整 Expr 到最终 Expr 的 kernelDefEq 与 Eq.refl 证书；logDiff TYPE 中恰一处 `Module.IsTorsionFree` 同一命题的既有 Free 证明替换；原证明实际参数及上下文闭包，Free＋Basis 两份 actual TYPE/value，原三 API 的 actual TYPE/value，以及旧常量在最终结果中消失。

这不是全局忽略 `instanceReplacementUsed`。新 law 强制其为 true，同时强制 `sameActualPropProofReplacementOnly=true`、`nonPropositionalDataReplacementUsed=false`、`wholeHomReplacementUsed=false`。其他三 report 不允许 torsion 替换。新旧 IsAddTorsionFree 映射与 affine/FG 类等价声明均为 false。细节见 `v97-source-law-and-publication.md`。

原 full55 合同仍要求：55 reports、25 项实际定义计算值、1 项结构、1 条递归 RHS、NorthcottHyp 原值 BinderInfo false、52 原签名严格一致、3 项旧 support theorem TYPE 风格证书、4 target normalization 证书、9 source/8 native support 检查、仅标准公理、无 sorryAx。新增每条 `sourceSamePropTorsionProofNormalizationUsed` 必须恰在 logDiff 那一条为 true。Definition 发布仍等待该真实 target review 和 actual55 成功，不能以 source producer 成功替代。

证据树同时纳入 source/target actual API（ci018317/018332）、target missing inventory、v94 timeout／parser 失败及 exclusive-overlap-v96 原始 status／取消 ci018336 记录。API exporter 明确没有接受重命名、foreign Expr 解码或 target 内核对应；overlap 取消不称数学失败。

v90 heartbeat fail、v91 same-module initialize abort、v92 unknownconstant 的 query/config/receipt 保留；v92 的精确非缓存输入来自 v93 已冻结 history-v92，主区另有对应 history-v92。原 source v89 query 保留在 `history-source-v89/`，不会把当前新 producer 误当旧输入。

生成的 SOURCE_LEDGER 是单元账本；registry 仍仅对 `reference_source_preparation` 指定键生成精确 merge 建议，base SHA 变化须重跑。计划待办不写“已齐备”。44 项、两个 iff target 接合、S2-04、初始数据存在性、无条件 abc 与中文 `[术语待定：compactly bounded subset]` 均保留开放。

清理仍不自动执行：`--duplicate-draft PATH` 仅登记 byte-exact 的新 tripodTheory `.lean` 副本，拒绝正式定义、query、配置绑定／CI manifest hash 引用和独立读回引用的输入。只有 archive 全成员重开 SHA 核验后，root 才可另行清理显式候选；不删除查询、配置、历史回放输入或缓存。
