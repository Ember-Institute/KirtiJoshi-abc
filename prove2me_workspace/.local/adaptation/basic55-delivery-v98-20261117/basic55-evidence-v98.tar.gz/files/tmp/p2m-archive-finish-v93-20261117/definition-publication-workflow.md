# 新 tripodTheory definition 的可审查发布流程

截至本次只读核对，新定义 `Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_Theory.lean` 已通过 leaf `ci-018046-08138ad2` 和 artifact `ci-018050-c51863f6`。三语 metadata 与本地定义逐字段绑定。`basic-absnorm-normalization-v88-20261117/publication/payload.json` 与 `/tmp/p2m-tripod-metadata-finish-v85-20261117/payload.json` 相同。尚未 POST，不能登记为 PUBLISHED。先前模糊 search 返回 6 项但没有同名；这不是完整唯一性证明。

发布须继续绑定真实 Basic55 最终验收：point／field／height／结构的实际对应尚待 target review 通过。`ci-018255-6b09f950` 为 failed，诊断 `(kernel) unknown constant 'instIsTorsionFreeIntOfHasUniqueDiv'`；1M 只作用于局部 metadata query，没有改变生产证明预算，更没有使该次检查成功。

## 主智能体执行顺序

1. 保持 accepted definition 与 payload 字节一致，完成真实 target review 和 55 条 actual 检查。向本目录 `prepare_archive.py` 显式传最终 `--final-receipt`、`--query`、`--config`。必要时传实际的 `--expected-metadata-heartbeats`。先只做 dry-run。
2. 读取 `publication-preconditions.json`。只有 `readyToPublish=true`，才能进入定义发布；该门排除“已发布”本身，因此不会形成循环。它仍包括 Basic55 真回执、actual55、四 source 规范化、leaf/artifact、独立读回及 v90/v91/v92 负证据完整性。最后还要核对 approved payload 的 SHA 与本地定义内容一致。
3. 用主智能体现有的 Definition 发布工具提交完整七字段 payload（沿用已确认的 API，不猜路由或别名）。提交前将精确 JSON 保存为 `publish-intent.json`；保留 `payload.json`。若已有本次 `publish-submit.json` 或 job_id，先查该 job，避免重复 POST。
4. 保存真实提交回执为 `publish-submit.json`，立即记 job_id。按回执提示查询 `GET /api/v1/publish-jobs/{job_id}`，保留终态为 `publish-result.json`；PENDING 不算通过，FAILED／ERROR 分别记真实错误，不重标成功。
5. 只有终态 PUBLISHED，才以真实返回的 definition id 做精确 item readback，保存 `published-item.json`。使用根智能体已验证的 item 查询工具／路由；不把发布 job_id 当 definition_id。
6. 重跑本目录 `prepare_archive.py`，默认读上述 publication 目录，或显式传 `--publication-readback`、`--publication-receipt`、`--publication-journal`。它将提交回执、终态回执、item readback、意图及 payload 五份 JSON 完整核对。全部门通过才加 `--archive`；重开 tar 核验后，主智能体审查并应用 registry、source ledger、计划，再执行主区所需验证及 Git 流程。

## 实见 API schema，不推断字段别名

schema 取自 `statementii-definition-v65-20261116/publication/` 真实成功记录。以下是脚本必须核对的字段关系。

| 文件 | 核对关系 |
| --- | --- |
| payload / publish-intent | 精确七键：`definition_name`, `definition_title`, `definition`, `natural_language_statement`, `source`, `env`, `private`；`private=true`；definition 与本地 accepted source 完全相同 |
| publish-submit | `job_id == publish-result.id`，`definition_name == payload.definition_name`，实见初态 `status=PENDING` |
| publish-result | `kind=definition`, `status=PUBLISHED`, `error_message=""`, `formal_statement=""`, `visibility=private`；`theorem_name ↔ definition_name`, `theorem_title ↔ definition_title`, `definitions ↔ definition`, `natural_language_statement`, `source` 均精确相等 |
| published-item | `definition_id == publish-result.theorem_id`；`definition_name`, `definition_title`, `definition`, `natural_language_statement`, `source` 与 payload 精确相等；`mathlib_rev == payload.env`, `visibility=private`, `deprecated_at=null`, `deprecated_by=null` |

`publish-result.id` 是发布 job id；`publish-result.theorem_id` 才对应 item 的 `definition_id`。实见 API 的发布终态沿用 theorem 字段，不能自行改成 `definition_id`。payload 的 `private` 与 item 的 `visibility` 使用不同字段名；payload 的 `env` 与 item 的 `mathlib_rev` 使用不同字段名。

## 登记、计划与中文术语

全部完成门通过后，可登记此新数据定义私有 PUBLISHED 及窄范围 Basic55 对应；仍不增加根图成员或宣称数学父义务闭合。SOURCE_LEDGER 应保留每个 producer 的实际消费者、来源 SHA、三条未读 source support proof body 以及 44 项 pending。`SOURCE_LEDGER.json` 是单元账本，不覆盖主区既有参考总账。

未通过时保持 `PENDING_COMPLETION_GATES`，52 严格签名／3 TYPE 例外／4 target 规范化是验收要求，不是已通过结果。计划必须写“待完成”，不能仅用未勾选框包住“已齐备”。中文精确保留 `[术语待定：compactly bounded subset]`；定译另行核对，不阻塞已明示范围的来源提取。

两个 iff 的 source2iff+aux 可以独立归档为 `sourceFactsOnly` 进展；目标 matching 双 false。它不发布桥，不关闭 Basic55、其余 44 项、S2-04、初始数据存在性或无条件 abc。
