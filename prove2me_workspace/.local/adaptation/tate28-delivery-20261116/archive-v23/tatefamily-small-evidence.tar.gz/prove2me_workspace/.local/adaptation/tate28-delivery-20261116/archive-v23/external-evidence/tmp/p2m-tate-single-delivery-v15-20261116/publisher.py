"""Reuse the existing one-Definition protocol. Import and check do not call an API.

Only deliver(api, ...) and reconcile(api, ...) call the API supplied by root.
This module does not load credentials, compile code, or invoke Git.
"""
import ast
import hashlib
import json
import time
import urllib.parse
from pathlib import Path

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
OUT = Path(__file__).resolve().parent
NAME = 'AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateFamily'
ENV = '0df444a360eaa60ab8c11dca51a86af692955474'
MISSION = 'eeb5193f-68c0-41d0-9263-4a5ff7c801ee'
ROOT = 'e33ff731-60a7-43ef-87ae-c12aeba23cb5'
CREATOR = '89966734-f388-427a-9ea1-983923ff28a1'
PROTOCOL = W/'.local/adaptation/reference-volume-tate-carriers-20261115/delivery.py'
GATES = {'new_leaf_modules', 'checks_axioms', 'wrapped_kernel_type_identity',
    'new_leaf_artifacts', 'import_audit', 'act1scene1', 'axiom_audit',
    'independent_readbacks', 'source_ledger_consumers', 'git_diff_check',
    'existing_mission_scope', 'final_frozen_review'}
COVERAGE = {'source':31,'resolved':31,'named':28,'proof':3,
    'standard_proof':0,'source_proof_standalone_aliases':0}

def require(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024**2),b''):
            digest.update(block)
    return digest.hexdigest()

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def check(packet_path, ready_path):
    """Consume root readiness. Do not create mathematical acceptance."""
    packet, ready = read(packet_path), read(ready_path)
    require(ready['passed'] is True and packet['publicationReady'] is True,
            'Root must complete the final readiness review.')
    require(ready['packet_sha256'] == sha(packet_path), 'The final packet hash changed.')
    require(set(ready['gates']) == GATES and all(v is True for v in ready['gates'].values())
            and ready['pending'] == [], 'A required delivery gate is pending.')
    require(ready['pending_bindings'] == {} or all(v is not None for v in ready['pending_bindings'].values()),
            'A final evidence binding is pending.')
    require(packet['workspace'] == str(W) and packet['mission_id'] == MISSION and
            packet['root_id'] == ROOT and packet['environment'] == ENV and
            packet['visibility'] == 'private' and packet['verification'] == [] and
            packet['publication_post_limit'] == 1, 'The private delivery scope changed.')
    require(packet['kernel_coverage'] == ready['kernel_coverage'] == COVERAGE,
            'Root must bind complete TateFamily coverage.')
    require(packet['required_owned_count'] == 29 and
            packet['target_only_compiler_helpers'] == ['AbcAdaptation.Reference.Iut.galK._proof_1'],
            'The compiler helper inventory changed.')
    require(packet['all200FormalAccepted'] is ready['all200FormalAccepted'] is False and
            packet['module_scope']['scopeAll200'] is False and
            packet['module_scope']['scopeAllFourModules'] is False and
            packet['root_graph_membership'] is False, 'Keep the single-module scope.')
    require(packet['actual_kernel_evidence'] is not None and
            packet['actual_46_leaf_results'] is not None and
            packet['actual_global_closure_result'] is not None,
            'Root must bind the actual declaration and closure evidence.')
    require(ready['axiom_audit']['sorryAx_found'] is False and
            ready['axiom_audit']['unexpected_axioms'] == [], 'The axiom review is pending.')
    for group in ready['ci_receipts'].values():
        require(bool(group), 'A required CI receipt is missing.')
        for path in group:
            require(path in ready['evidence_sha256'], 'A CI receipt lacks its final hash.')
    require(bool(ready['gate_evidence']['final_frozen_review']), 'The final frozen review is missing.')
    for path,digest in {**packet['metadata_sha256'],**ready['evidence_sha256']}.items():
        require(sha(path) == digest, 'Final evidence changed: ' + path)
    for path,digest in packet['source_sha256'].items():
        require(sha(W/path) == digest, 'The installed source changed: ' + path)
    row, = packet['publications']
    require(row['tag'] == NAME and row['endpoint'] == '/submit-definition' and
            row['payload']['definition_name'] == NAME and row['payload']['private'] is True and
            row['payload']['env'] == ENV, 'The publication payload scope changed.')
    require(row['payload']['definition'] == (W/('Definitions/Def_'+NAME+'.lean')).read_text(),
            'The publication source changed.')
    flags = packet['binder_info_scope']
    require(all(flags[key] is True for key in ['all28FaithfulReplaySignaturesAccepted',
            'all28ExactDataSlotAccountingAccepted', 'completeComputationalValuesSemanticReplayAccepted',
            'completeRecursorRulesSemanticReplayAccepted']), 'The complete replay evidence is pending.')
    require(flags['allOriginalRawSignatureBinderInfoEqual'] is False and
            flags['computationalValueRawBinderInfoIdentityTested'] is False and
            flags['recursorRuleRawBinderInfoIdentityTested'] is False and
            flags['rawComputationalAnnotationEqualityClaimed'] is False,
            'Do not convert semantic replay into raw annotation equality.')
    return packet

def _protocol():
    """Reuse the same four functions as the published Orbicurve packet."""
    names = {'check_scope','check_job','check_definition','poll'}
    nodes = [n for n in ast.parse(PROTOCOL.read_text()).body
        if isinstance(n,ast.FunctionDef) and n.name in names]
    require({n.name for n in nodes} == names, 'The existing publication protocol changed.')
    namespace = dict(Path=Path,read=read,save=save,require=require,ENV=ENV,MISSION=MISSION,
        ROOT=ROOT,CREATOR=CREATOR,time=time,urllib=urllib)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'<existing-definition-network-protocol>','exec'),namespace)
    return namespace

def _parents(api, packet, directory):
    parents = packet['parent_foundation_definitions']
    require(len(parents) == 6, 'Use the six published direct parents.')
    for parent in parents:
        prior = parent['registryEvidence']
        item = api.request('/definitions/'+urllib.parse.quote(prior['id'],safe=''))
        save(directory/('parent-'+prior['name']+'.json'),item)
        require(item['definition_id'] == prior['id'] and item['definition_name'] == prior['name'] and
                item['visibility'] == 'private' and item['mathlib_rev'] == ENV and
                item['deprecated_at'] is None, 'A published parent changed.')
        require(hashlib.sha256(item['definition'].encode()).hexdigest() == parent['currentDefinition']['sha256'],
                'A published parent source changed.')

def deliver(api, packet_path, ready_path, directory, timeout_seconds=900):
    """Publish only after root supplies final readiness and an explicit API object."""
    packet = check(packet_path,ready_path)
    directory = Path(directory)
    directory.mkdir(parents=True,exist_ok=True)
    protocol = _protocol()
    protocol['check_scope'](api,directory)
    _parents(api,packet,directory)
    before = api.request('/theorems/'+ROOT+'/graph')
    baseline = directory/'root-graph-before.json'
    if baseline.exists():
        require(read(baseline) == before, 'The original mission graph changed.')
    else:
        save(baseline,before)
    row, = packet['publications']
    binding = directory/'packet-binding.json'
    identity = {'packet_sha256':sha(packet_path),'names':[NAME]}
    if binding.exists():
        require(read(binding) == identity, 'The journal belongs to another packet.')
    else:
        save(binding,identity)
    intent, submitted = directory/(NAME+'-intent.json'), directory/(NAME+'-submit.json')
    if intent.exists():
        require(read(intent) == row and submitted.exists(),
                'Reconcile the original POST outcome before another submission.')
    else:
        require(not submitted.exists(), 'The original submission intent is missing.')
        save(intent,row)
        save(submitted,api.request('/submit-definition',row['payload'],'POST'))
    posted = read(submitted)
    require(posted.get('job_id') and not posted.get('errors'), 'The original POST receipt is invalid.')
    job = protocol['poll'](api,directory,row,posted['job_id'],timeout_seconds)
    protocol['check_definition'](api,directory,row,job['theorem_id'])
    after = api.request('/theorems/'+ROOT+'/graph')
    save(directory/'root-graph-after.json',after)
    require(before == after, 'Definition publication changed the mission graph.')
    ids = {NAME:job['theorem_id']}
    save(directory/'published-ids.json',ids)
    return ids

def reconcile(api, packet_path, ready_path, directory, job_id):
    """Read the nominated original job. Do not submit a new Definition."""
    packet = check(packet_path,ready_path)
    directory = Path(directory)
    row, = packet['publications']
    require(read(directory/(NAME+'-intent.json')) == row, 'The original submission intent changed.')
    protocol = _protocol()
    protocol['check_scope'](api,directory)
    job = api.request('/publish-jobs/'+urllib.parse.quote(job_id,safe=''))
    save(directory/(NAME+'-reconcile-readback.json'),job)
    protocol['check_job'](job,row)
    require(job['id'] == job_id and job['status'] == 'PUBLISHED', 'The original job has not published.')
    protocol['check_definition'](api,directory,row,job['theorem_id'])
    submitted = directory/(NAME+'-submit.json')
    if submitted.exists():
        require(read(submitted)['job_id'] == job_id, 'Another original job is already bound.')
    else:
        save(submitted,{'job_id':job_id,'reconciled_exact_readback':True})
    return job['theorem_id']
