#!/usr/bin/env python3
"""Prepare one TateFamily Definition offline. This script does not publish it."""
import argparse
import hashlib
import json
import sys
from pathlib import Path
sys.dont_write_bytecode = True

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
I = W / '.local/adaptation/reference-initial-theta-carriers-20261115'
ORB = W / '.local/adaptation/orbicurve70-delivery-20261116'
MODULE = 'Iut.Cor312.ThetaData.TateFamily'
NAME = 'AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateFamily'
TARGET = 'Definitions/Def_' + NAME + '.lean'
OUT = Path(__file__).resolve().parent
GATES = ['new_leaf_modules', 'checks_axioms', 'wrapped_kernel_type_identity',
         'new_leaf_artifacts', 'import_audit', 'act1scene1', 'axiom_audit',
         'independent_readbacks', 'source_ledger_consumers', 'git_diff_check',
         'existing_mission_scope', 'final_frozen_review']
CI_GATES = GATES[:7]
COVERAGE = {'source': 31, 'resolved': 31, 'named': 28, 'proof': 3,
            'standard_proof': 0, 'source_proof_standalone_aliases': 0}
PROOFS = ['Iut.curveK._proof_1', 'Iut.galK._proof_1', 'Iut.galK._proof_2']
SCOPE = {'module': MODULE, 'scopeAll200': False, 'scopeAllFourModules': False,
         'fourModuleCorrespondenceAccepted': False, 'sourceProofStandaloneAliases': [],
         'pendingModules': ['Iut.Cor312.ThetaData.LocalConditions', 'Iut.Cor312.ThetaData.Basic']}

def require(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    path = Path(path)
    require(path.stat().st_size < 100_000_000, 'Use the existing pin for large evidence files.')
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pin(path):
    return {'path': str(Path(path).resolve()), 'sha256': sha(path)}

def write(path, value):
    path = Path(path)
    require(path.resolve().is_relative_to(OUT), 'Write files only in this task directory.')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def freeze(path, directory):
    path = Path(path)
    target = OUT / directory / (sha(path)[:12] + '-' + path.name)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(path.read_bytes())
    return {'original': pin(path), 'frozenCopy': pin(target)}

def prepare():
    plan_path = I / 'tate-priority-v14/root-bound46-plan.json'
    plan = read(plan_path)
    require(plan['accounting']['remainingDeclarationLeaves'] == len(plan['leaves']) == 46,
            'Use the exact root plan with 46 leaves.')
    require(plan['all200FormalAccepted'] is False, 'Keep global acceptance false.')
    wrapper_path, blind_path = I/'generated-wrapped/foundation-wrapper-report.json', I/'blind-readbacks.json'
    wrappers, blind = read(wrapper_path), read(blind_path)
    bundles = {r['definitionName']: r for r in wrappers['bundles']}
    generated = bundles[NAME]
    protocol = I/'delivery.py'
    namespace = {'__name__': 'tate_static_readback_protocol', '__file__': str(protocol)}
    exec(compile(protocol.read_text(), str(protocol), 'exec'), namespace)
    reviews = namespace['validate_independent_readbacks'](blind, bundles)
    rb = next(r for r in blind['bundles'] if r['definition_name'] == NAME)
    code = (W/TARGET).read_text()
    require(sha(W/TARGET) == generated['sha256'] == rb['source_sha256'] ==
            '7a89b737af9759856eac31dfede79ed8f6e39a3adc5136e4b0af75fa11026ad4',
            'The installed TateFamily source changed.')
    require(Path(generated['path']).read_bytes() == (W/TARGET).read_bytes(), 'The wrapper bytes changed.')
    require(sha(generated['payload']) == generated['payloadSha256'] and
            read(generated['payload']) == {'definition_name': NAME, 'code': code}, 'The generated payload changed.')
    provenance = rb['provenance']
    require(rb['passed'] and provenance['fresh_context'] and provenance['input_only_formal_code'],
            'The independent readback did not pass.')
    require(sha(provenance['original_artifact']) == provenance['original_artifact_sha256'] and
            sha(generated['blindReadback']['path']) == provenance['input_sha256'] == generated['blindReadback']['sha256'],
            'The independent readback input changed.')
    original_rb = read(provenance['original_artifact'])['bundles'][provenance['original_bundle_index']]
    for key in ['en', 'zh-Hans', 'ja', 'pending_chinese_terms', 'declarations', 'ambiguities']:
        require(rb[key] == original_rb[key], 'The original readback changed: ' + key)
    require(len(rb['definition_title']) <= 200, 'The Definition title exceeds 200 characters.')
    context_path, ledger_path = I/'paper-context.json', I/'SOURCE_LEDGER.json'
    context, ledger = read(context_path), read(ledger_path)
    paper = next(r for r in context['bundles'] if r['module'] == MODULE)
    require(paper['blocks_definition_delivery'] is False, 'The paper context blocks delivery.')
    subset = {k:v for k,v in context.items() if k in ['schema','language','purpose']}
    subset['bundles'] = [paper]
    subset['quotations'] = [r for r in context['quotations'] if r['id'] in paper['quotation_ids']]
    used = {r['paper_id'] for r in subset['quotations']}
    subset['paper_sources'] = {k:v for k,v in context['paper_sources'].items() if k in used}
    require({r['id'] for r in subset['quotations']} == set(paper['quotation_ids']), 'A paper quotation is missing.')
    commands = [r for r in ledger['records'] if r['module'] == MODULE]
    require(len(commands) == 8 and {r['original'] for r in commands} == set(paper['selected_source_commands']),
            'The eight source commands changed.')
    selected = {d['name'] for r in commands for d in r['ownedSourceDeclarations'] if d['selected']}
    named = plan['namedCandidateIdentities']
    require(len(selected) == 31 and {r['original'] for r in named} | set(PROOFS) == selected,
            'The selected source declarations changed.')
    require(all(r['actualConsumers'] and r['fidelity'] for r in commands), 'A source consumer is missing.')
    sources = {TARGET: sha(W/TARGET)}
    for parent in plan['publishedDirectParents']:
        require(parent['registryEvidence']['status'] == 'PUBLISHED' and
                sha(parent['currentDefinition']['path']) == parent['currentDefinition']['sha256'],
                'A saved parent Definition changed.')
    require(len(plan['publishedDirectParents']) == 6, 'Use exactly six published parents.')
    write(OUT/'readback.TateFamily.json', rb)
    write(OUT/'paper-context.TateFamily.json', subset)
    frozen = []
    for path in {provenance['original_artifact'], generated['blindReadback']['path'],
                 *[r['original_artifact'] for r in reviews.values()]}:
        frozen.append(freeze(path, 'frozen-readbacks'))
    write(OUT/'readback-original-pins.json', {'originalStringsUnchanged': True,
        'twoContextFourInputValidatorReused': pin(protocol), 'artifacts': frozen})
    candidate_ledger = {'schema': 'tate28-source-consumers-and-audit-bindings-v1',
        'status': 'source consumer projection; formal receipt binding pending', 'module': MODULE,
        'sourceLedger': pin(ledger_path), 'sourceCommands': commands,
        'structures': [r for r in ledger['structures'] if r['module'] == MODULE],
        'bundle': next(r for r in ledger['bundles'] if r['module'] == MODULE),
        'requiredKernelCoverage': COVERAGE, 'kernelCoverage': None,
        'namedCorrespondence': [dict(r, accepted=False, actualEvidence=None) for r in named],
        'sourceProofValues': [dict(r, actualParentCompleteValueEvidence=None,
            actualOriginalProofReplayEvidence=None, accepted=False) for r in plan['genuineOriginalProofRequirements']],
        'sourceProofStandaloneAliases': [], 'actualOwnedRequired': 29,
        'targetOnlyCompilerDeclarations': [plan['compilerOnlyHelper']],
        'targetOnlyCompilerProvenanceAccepted': False,
        'consumerScope': 'The original graph supplies these consumer edges. This packet adds no mission root edges.',
        'scope': SCOPE, 'all200FormalAccepted': False}
    write(OUT/'source-ledger.TateFamily.candidate.json', candidate_ledger)
    payload = {'definition_name': NAME, 'definition_title': rb['definition_title'], 'definition': code,
        'natural_language_statement': namespace['publication_statement'](rb, paper),
        'source': rb['source'], 'env': namespace['ENV'], 'private': True}
    write(OUT/'payload.json', payload)
    (OUT/'Definition.lean').write_bytes((W/TARGET).read_bytes())
    raw_flags = [{ 'original': r['original'], **r['expectedLiteralRawFlags'] }
        for r in plan['leaves'] if r['mode'] == 'complete-existing']
    raw_flags += [{'original': n, 'sourceRawFlagsRemainFalse': True,
        'formalReplayAndExactDataSlotAccounting': 'pending'} for n in
        plan['exceptionalOriginals'] + ['Iut.TateFamily.S','Iut.TateFamily.graphLine_galPlace']]
    require(len(raw_flags) == 28, 'Keep all 28 signature flag records.')
    binder_scope = {'sourceSignatureRawFlags': raw_flags,
        'allOriginalRawSignatureBinderInfoEqual': False,
        'all28FaithfulReplaySignaturesAccepted': None,
        'all28ExactDataSlotAccountingAccepted': None,
        'completeComputationalValuesSemanticReplayAccepted': None,
        'completeRecursorRulesSemanticReplayAccepted': None,
        'computationalValueRawBinderInfoIdentityTested': False,
        'recursorRuleRawBinderInfoIdentityTested': False,
        'rawComputationalAnnotationEqualityClaimed': False,
        'genuineSourceProofInferredTypeBinderInfoAllEqual': False,
        'sourceProofInferredBinderInfoException': 'Iut.galK._proof_2',
        'sourceProofStandaloneAliases': [],
        'explanation': 'Original raw flags remain unchanged. Formal acceptance requires the complete replay signature and exact data slot evidence. '
            'Kernel equality of complete replay values does not establish raw BinderInfo or annotation identity.'}
    base_paths = [OUT/'prepare_tate.py', OUT/'publisher.py', wrapper_path, blind_path, context_path, ledger_path, protocol,
        I/'paper-context-validation.json', I/'accepted-prior-identity-map.json', I/'dependency-closure.json',
        I/'bound-inventory.json', I/'source-provenance-root-audit.json', plan_path,
        Path(generated['path']), Path(generated['payload']), Path(generated['blindReadback']['path']),
        ORB/'prepare_orbicurve70.py', ORB/'run_delivery.py',
        W/'.local/adaptation/supplier-carriers-delivery-20261116/tools/publisher.py',
        W/'.local/adaptation/reference-volume-tate-carriers-20261115/delivery.py']
    for r in plan['completedNamedEvidence']:
        base_paths += [Path(r['smallActualCorrespondenceSummary']['path'])]
        base_paths += [Path(s['receipt']['path']) for s in r['receipts']]
    for r in frozen:
        base_paths += [Path(r['original']['path']),Path(r['frozenCopy']['path'])]
    base_paths += [Path(r['currentDefinition']['path']) for r in plan['publishedDirectParents']]
    base_paths += [OUT/f for f in ['readback.TateFamily.json','paper-context.TateFamily.json',
        'readback-original-pins.json','source-ledger.TateFamily.candidate.json','payload.json','Definition.lean']]
    evidence = {str(p.resolve()):sha(p) for p in base_paths}
    packet = {'schema': 'reference-tate28-private-definition-delivery-v1',
        'workspace': str(W), 'mission_id': namespace['MISSION'], 'root_id': namespace['ROOT'],
        'environment': namespace['ENV'], 'scope': namespace['SCOPE'], 'root_graph_membership': False,
        'canonicalC22Connected': False, 'visibility': 'private', 'module_scope': SCOPE,
        'required_kernel_coverage': COVERAGE, 'kernel_coverage': None,
        'required_owned_count': 29, 'target_only_compiler_helpers': [plan['compilerOnlyHelper']],
        'source_sha256': sources, 'metadata_sha256': evidence,
        'actual_kernel_receipt': None, 'actual_kernel_job_id': None, 'actual_kernel_evidence': None,
        'actual_46_leaf_results': None, 'actual_global_closure_result': None,
        'binder_info_scope': binder_scope, 'parent_foundation_definitions': plan['publishedDirectParents'],
        'publications': [{'tag': NAME, 'endpoint': '/submit-definition', 'payload': payload}],
        'verification': [], 'publication_post_limit': 1, 'publicationReady': False,
        'all200FormalAccepted': False}
    write(OUT/'packet.json', packet)
    gates = {g: g == 'independent_readbacks' for g in GATES}
    ready = {'schema': 'reference-tate28-private-definition-ready-v1', 'passed': False,
        'packet_sha256': sha(OUT/'packet.json'), 'source_sha256': sources,
        'required_kernel_coverage': COVERAGE, 'kernel_coverage': None, 'module_scope': SCOPE,
        'gates': gates, 'ci_receipts': {g: [] for g in CI_GATES},
        'axiom_audit': {'sorryAx_found': None, 'unexpected_axioms': None, 'scope': 'pending Tate and production evidence'},
        'gate_evidence': {g: [str(blind_path),str(OUT/'readback.TateFamily.json')]
            if g == 'independent_readbacks' else [] for g in GATES if g not in CI_GATES},
        'evidence_sha256': evidence, 'pending': [g for g in GATES if not gates[g]],
        'pending_bindings': {'rootBound46Plan': pin(plan_path), 'actual46ReceiptsAndInnerGates': None,
            'existingFullGlobalClosureReceipt': None, 'finalLeafArtifactVersionSha': None,
            'allSixCurrentPublishedParentReadbacks': None, 'finalFrozenReview': None},
        'note': 'Bind actual results, exact artifact versions, and the final frozen review before publication.',
        'all200FormalAccepted': False}
    write(OUT/'ready.json', ready)
    return check()

def check():
    packet, ready = read(OUT/'packet.json'), read(OUT/'ready.json')
    require(ready['passed'] is False and packet['publicationReady'] is False, 'This check accepts draft readiness only.')
    require(packet['all200FormalAccepted'] is ready['all200FormalAccepted'] is False, 'Keep global acceptance false.')
    require(packet['required_kernel_coverage'] == ready['required_kernel_coverage'] == COVERAGE and
            packet['kernel_coverage'] is ready['kernel_coverage'] is None, 'Do not claim pending coverage.')
    require(ready['packet_sha256'] == sha(OUT/'packet.json'), 'The packet hash changed.')
    for path,digest in packet['metadata_sha256'].items():
        require(sha(path) == digest, 'A frozen input changed: ' + path)
    require(packet['source_sha256'] == {TARGET:sha(W/TARGET)}, 'The installed source changed.')
    row, = packet['publications']
    require(row['payload'] == read(OUT/'payload.json') and row['payload']['private'] is True,
            'The private payload changed.')
    require(row['payload']['definition'] == (W/TARGET).read_text(), 'The payload source changed.')
    require(set(ready['gates']) == set(GATES) and ready['pending'] == [g for g in GATES if not ready['gates'][g]],
            'The existing gate set changed.')
    return {'schema':'tate28-offline-packet-check-v1','passed':True,'publicationReady':False,
        'definitions':1,'requiredKernelCoverage':COVERAGE,'actualKernelCoverage':None,
        'exactOriginalReadbackReused':True,'independentReadbackGatePassed':True,
        'packet':pin(OUT/'packet.json'),'ready':pin(OUT/'ready.json'),'payload':pin(OUT/'payload.json'),
        'pendingGates':ready['pending'],'all200FormalAccepted':False,
        'apiCalls':0,'compilerCalls':0,'gitCalls':0}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare','check'])
    args = parser.parse_args()
    result = prepare() if args.command == 'prepare' else check()
    write(OUT/'offline-validation.json', result)
    print(json.dumps(result,ensure_ascii=False,indent=2))
