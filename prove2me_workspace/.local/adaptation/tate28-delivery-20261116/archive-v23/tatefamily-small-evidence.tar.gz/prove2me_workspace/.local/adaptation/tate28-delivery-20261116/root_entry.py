#!/usr/bin/env python3
"""Explicit root-only calls to the byte-identical v15 publisher; no automatic run."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['collect-scope', 'check', 'deliver', 'reconcile'])
    parser.add_argument('--job-id')
    args = parser.parse_args()
    publisher = load('tate_v15_unchanged_publisher', OUT / 'publisher.py')
    if args.command == 'check':
        publisher.check(OUT / 'packet.json', OUT / 'ready.final.json')
        print('Existing publisher check passed; no API invoked.')
        return
    # Credential/API loading happens only when root explicitly selects a
    # command that uses the existing protocol's API calls.
    api = load('existing_prove2me_api', W / '.local/abc-item/api.py')
    directory = OUT / 'platform'
    directory.mkdir(exist_ok=True)
    if args.command == 'collect-scope':
        packet = publisher.read(OUT / 'packet.template.json')
        publisher._protocol()['check_scope'](api, directory)
        publisher._parents(api, packet, directory)
        print('Existing private scope and six published parents read back; no POST.')
    elif args.command == 'deliver':
        result = publisher.deliver(api, OUT / 'packet.json', OUT / 'ready.final.json', directory)
        print(json.dumps(result, ensure_ascii=False))
    else:
        if not args.job_id:
            parser.error('reconcile requires the original --job-id')
        result = publisher.reconcile(api, OUT / 'packet.json', OUT / 'ready.final.json', directory, args.job_id)
        print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
