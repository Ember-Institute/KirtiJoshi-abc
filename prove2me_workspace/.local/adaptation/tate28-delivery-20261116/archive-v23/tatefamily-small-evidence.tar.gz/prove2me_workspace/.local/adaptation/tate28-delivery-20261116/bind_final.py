#!/usr/bin/env python3
"""Root-only offline binding of completed Tate results to the unchanged v15 publisher.
Writes only this task directory. Does not compile, call APIs, run Git, or edit W.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode = True

OUT = Path(__file__).resolve().parent
BASE = Path('/tmp/p2m-tate-single-delivery-v15-20261116')
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
I = W / '.local/adaptation/reference-initial-theta-carriers-20261115'
COVERAGE = {'source': 31, 'resolved': 31, 'named': 28, 'proof': 3,
            'standard_proof': 0, 'source_proof_standalone_aliases': 0}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    path = Path(path)
    if path.stat().st_size > 16 * 1024 ** 2:
        raise ValueError('Keep the existing pin for large evidence: ' + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path):
    return {'path': str(Path(path).resolve()), 'sha256': sha(path)}


def save(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(OUT), 'Task-local writes only'
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def bind(dossier_path, git_diff_check, scope_directory):
    dossier_path, git_diff_check, scope_directory = map(Path, [dossier_path, git_diff_check, scope_directory])
    dossier = read(dossier_path)
    assert sha(dossier_path) == read(OUT / 'actual-dossier-pin.json')['sha256']
    assert dossier['schema'] == 'tate28-actual-kernel-dossier-v23'
    assert dossier['kernelCoverage'] == COVERAGE
    assert len(dossier['namedCorrespondence']) == 28 and all(row['accepted'] for row in dossier['namedCorrespondence'])
    assert len(dossier['genuineSourceProofValues']) == 3 and all(row['accepted'] for row in dossier['genuineSourceProofValues'])
    assert len(dossier['actual46LeafResults']) == 46 and len(dossier['reusedPriorLeaves']) == 6
    assert len(dossier['actualReceipts']) == 53
    packet = read(OUT / 'packet.template.json')
    ready = read(OUT / 'ready.template.json')
    ledger = read(OUT / 'source-ledger.TateFamily.template.json')
    # Keep the exact one-module payload, namespace ownership, and frozen strings.
    assert packet['publications'][0]['payload'] == read(OUT / 'payload.json') == read(BASE / 'payload.json')
    for filename in ['publisher.py', 'Definition.lean', 'readback.TateFamily.json', 'paper-context.TateFamily.json']:
        assert (OUT / filename).read_bytes() == (BASE / filename).read_bytes(), filename
    assert packet['all200FormalAccepted'] is False and packet['canonicalC22Connected'] is False
    assert packet['module_scope']['scopeAll200'] is False and packet['module_scope']['scopeAllFourModules'] is False
    for relative, digest in packet['source_sha256'].items():
        assert sha(W / relative) == digest
    reuse = read(OUT / 'production-gate-reuse.json')
    for row in reuse['productionPinnedInputs']:
        assert sha(row['path']) == row['sha256'] == row['expectedFromReceipt']
    for row in reuse['existingTateLeafAndArtifact']:
        assert sha(row['path']) == row['sha256']
    receipts = dossier['actualReceipts']
    for receipt in receipts:
        assert sha(receipt['path']) == receipt['sha256']
        actual = read(receipt['path'])
        assert actual['job_id'] == receipt['job_id'] and actual['status'] == 'succeeded'
        assert actual['result']['exit_code'] == 0
    # These are the existing private-scope and six-parent protocol inputs.
    scope_paths = [scope_directory / 'mission-list-readback.json', scope_directory / 'mission-root-readback.json']
    parent_paths = [scope_directory / ('parent-' + parent['registryEvidence']['name'] + '.json')
                    for parent in packet['parent_foundation_definitions']]
    assert len(parent_paths) == 6
    for path in scope_paths + parent_paths:
        assert path.is_file(), 'Root may collect these with the unchanged publisher protocol: ' + str(path)
    # Root provides the actual diff receipt; this tool does not run Git.
    diff = read(git_diff_check)
    assert diff.get('passed') is True or diff.get('exit_code') == 0, 'The existing diff gate is not accepted'
    named = {row['original']: row for row in dossier['namedCorrespondence']}
    proofs = {row['original']: row for row in dossier['genuineSourceProofValues']}
    for row in ledger['namedCorrespondence']:
        actual = named[row['original']]
        assert actual['target'] == row['target']
        row.update(accepted=True, actualEvidence=actual['actualEvidence'])
        row['actualCorrespondence'] = actual
    for row in ledger['sourceProofValues']:
        actual = proofs[row['original']]
        row.update(accepted=True,
            actualParentCompleteValueEvidence=actual['actualParentCompleteValueEvidence'],
            actualOriginalProofReplayEvidence=actual['actualOriginalProofReplayEvidence'])
    ledger.update(status='Complete actual single TateFamily module correspondence accepted locally; private publication binding',
        kernelCoverage=COVERAGE, targetOnlyCompilerProvenanceAccepted=True,
        actualOwnedInventory=dossier['ownedInventory'], actualKernelDossier=pin(dossier_path),
        all200FormalAccepted=False)
    ledger_path = OUT / 'source-ledger.TateFamily.final.json'
    save(ledger_path, ledger)
    closure = dossier['actualGlobalClosureResult']
    closure_receipt = closure['receipt']['path']
    packet.update(kernel_coverage=COVERAGE, actual_kernel_receipt=closure_receipt,
        actual_kernel_job_id=read(closure_receipt)['job_id'], actual_kernel_evidence=pin(dossier_path),
        actual_46_leaf_results=dossier['actual46LeafResults'], actual_global_closure_result=closure,
        binder_info_scope=dossier['binderInfoScope'], publicationReady=True)
    # No payload/readback mutation, and no raw BinderInfo equality upgrade.
    assert packet['publications'][0]['payload'] == read(BASE / 'payload.json')
    frozen_review = {'schema': 'tate-single-final-frozen-review/v23', 'passed': True,
        'payloadExactlyV15': True, 'originalPublisherUnchanged': True,
        'readbackExactlyV15': True, 'paperContextExactlyV15': True,
        'actualDossier': pin(dossier_path), 'sourceSha256': packet['source_sha256'],
        'scope': 'Only the existing final_frozen_review delivery gate; no new mathematical review.',
        'canonicalC22Connected': False, 'all200FormalAccepted': False}
    save(OUT / 'final-frozen-review.json', frozen_review)
    added_paths = [dossier_path, ledger_path, OUT / 'production-gate-reuse.json',
        OUT / 'final-frozen-review.json', Path(__file__), OUT / 'publisher.py', OUT / 'payload.json']
    added_paths += [Path(row['path']) for row in receipts] + scope_paths + parent_paths + [git_diff_check]
    hashes = {str(path.resolve()): sha(path) for path in added_paths}
    packet['metadata_sha256'].update(hashes)
    save(OUT / 'packet.json', packet)
    ready['kernel_coverage'] = COVERAGE
    ready['packet_sha256'] = sha(OUT / 'packet.json')
    ready['source_sha256'] = packet['source_sha256']
    ready['evidence_sha256'].update(hashes)
    ready['ci_receipts']['new_leaf_modules'] = [str(I / 'platform-TateFamily-leaf-result.json')]
    ready['ci_receipts']['new_leaf_artifacts'] = [str(I / 'platform-TateFamily-artifact-result.json')]
    ready['ci_receipts']['wrapped_kernel_type_identity'] = [row['path'] for row in receipts]
    ready['ci_receipts']['checks_axioms'] = [closure_receipt]
    production_receipt = str(I / 'production-gates-v2-result.json')
    ready['ci_receipts']['import_audit'] = [production_receipt]
    ready['ci_receipts']['act1scene1'] = [production_receipt]
    ready['ci_receipts']['axiom_audit'] = [production_receipt, closure_receipt]
    for group in ready['ci_receipts'].values():
        for path in group:
            ready['evidence_sha256'][path] = sha(path)
    ready['axiom_audit'] = dossier['axiomAudit']
    ready['gate_evidence']['source_ledger_consumers'] = [str(ledger_path)]
    ready['gate_evidence']['git_diff_check'] = [str(git_diff_check)]
    ready['gate_evidence']['existing_mission_scope'] = [str(path) for path in scope_paths + parent_paths]
    ready['gate_evidence']['final_frozen_review'] = [str(OUT / 'final-frozen-review.json')]
    ready['pending_bindings'].update(actual46ReceiptsAndInnerGates=pin(dossier_path),
        existingFullGlobalClosureReceipt=pin(closure_receipt),
        finalLeafArtifactVersionSha=reuse['existingTateLeafAndArtifact'],
        allSixCurrentPublishedParentReadbacks=[pin(path) for path in parent_paths],
        finalFrozenReview=pin(OUT / 'final-frozen-review.json'))
    ready['gates'] = {gate: True for gate in ready['gates']}
    ready['pending'] = []
    ready['passed'] = True
    ready['note'] = 'Bound to completed actual Tate dossier and the unchanged v15 payload/protocol; single Tate scope only.'
    save(OUT / 'ready.final.json', ready)
    spec = importlib.util.spec_from_file_location('tate_original_final_publisher', OUT / 'publisher.py')
    publisher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(publisher)
    publisher.check(OUT / 'packet.json', OUT / 'ready.final.json')
    return {'packet': pin(OUT / 'packet.json'), 'ready': pin(OUT / 'ready.final.json'),
        'ledger': pin(ledger_path), 'unchangedPayload': pin(OUT / 'payload.json'),
        'canonicalC22Connected': False, 'all200FormalAccepted': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dossier', type=Path, default=OUT / 'final-kernel-dossier.json')
    parser.add_argument('--git-diff-check', type=Path, required=True)
    parser.add_argument('--scope-directory', type=Path, default=OUT / 'platform')
    args = parser.parse_args()
    print(json.dumps(bind(args.dossier, args.git_diff_check, args.scope_directory), ensure_ascii=False, indent=2))
