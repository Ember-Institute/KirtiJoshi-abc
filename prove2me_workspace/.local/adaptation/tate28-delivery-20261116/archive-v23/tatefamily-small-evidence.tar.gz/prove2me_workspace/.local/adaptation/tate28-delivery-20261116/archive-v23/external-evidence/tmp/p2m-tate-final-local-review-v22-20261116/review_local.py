#!/usr/bin/env python3
"""Read saved Tate receipts and reports; write a partial local review only."""
import hashlib
import json
import math
from pathlib import Path

HERE=Path(__file__).resolve().parent
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
B=W/'.local/adaptation/reference-initial-theta-carriers-20261115'
PLAN=B/'tate-priority-v14/root-bound46-plan.json'
ALLOWED={'propext','Classical.choice','Quot.sound'}
HASHES={}


def load(p):
    p=Path(p)
    if p.stat().st_size>32*1024**2:raise ValueError('Refusing large JSON '+str(p))
    return json.loads(p.read_text())


def pin(p):
    p=Path(p).resolve()
    if p not in HASHES:
        if p.stat().st_size>32*1024**2:raise ValueError('Refusing large hash '+str(p))
        HASHES[p]=hashlib.sha256(p.read_bytes()).hexdigest()
    return {'path':str(p),'sha256':HASHES[p]}


def need(x,label):
    if not x:raise ValueError(label)


def check_axioms(row):
    need(row.get('hasSorryAx') is False,'sorryAx status')
    for k in ('axioms','typeAxioms','valueAxioms'):
        need(k in row and set(row[k])<=ALLOWED,'unexpected/missing '+k)


def check_signature(row):
    for k in ('diagnosticPassed','faithfulReplaySignatureKernelEqual',
              'allOtherBinderInfoStrictlyEqual','exactExprEqualRoundTrip'):
        need(row.get(k) is True,'signature '+k)
    exposed=row['exposedDomains']
    need(exposed['allExposedBinderFlagsStrict'] and exposed['completeClosedResultKernelEqual'],'exposed result')
    need(all(r['completeClosedDomainKernelEqual'] for r in exposed['domains']),'all exposed domains')
    return {k:row[k] for k in ('rawSignatureBinderInventoryEqual','rawSignatureBinderPlacementEqual','rawFalseRemainsLiteral')}


def check_value(row,req):
    need(row['completeTypePreconditionKernelChecked'] is True,'whole type precondition')
    need(row['wholeTypeReplay']['allRequiredKernelChecksPassed'] is True,'whole type replay')
    v=row['wholeValueAndRules']
    need(v['completeComputationShapeEqual'] is True,'full computation shape')
    if req and req['fullComputationalValueRequired']:
        need(v['completeComputationalDataValueCompared'] is True,'complete data value')
    if req:need(v['completeRecursorRulesCompared']==req['recursorRuleCount'],'all recursor rules')
    return {k:v[k] for k in ('completeComputationalDataValueCompared','completeRecursorRulesCompared','proofValueComparisonOmittedForPropositions')}


def inspect_receipt(path,original,mode,req=None,cached_signature=None):
    r=load(path);q=r['request'];result=r.get('result') or {}
    need(r['status']=='succeeded' and result.get('exit_code')==0,'terminal success')
    need(q['workspace']==str(W) and q['exclusive'] is True,'stable actual workspace')
    need(q['language']=='lean' and q['target']=='file','language/target')
    need(result['actual_arguments']==['lean',q['parameters']['source']],'actual source arguments')
    need(result['snapshot']['workspace_mode']=='exclusive_worktree' and result['snapshot']['snapshot_id'] is None,'exclusive mode')
    resources=r['resources'];need(0<resources['peak_rss_bytes']<=16*1024**3,'physical RSS gate')
    need(math.isclose(resources['cpu_time_seconds'],resources['cpu_user_seconds']+resources['cpu_system_seconds'],abs_tol=1e-5),'CPU accounting')
    source=(W/q['parameters']['source']).resolve();sp=pin(source)
    manifest=q['worktree_manifest'];inputs=manifest['input_hashes']
    need(sp['sha256']==manifest['source_sha256']==inputs[str(source)],'actual source hash')
    cp=Path(q['environment']['NEXT_CARRIER_AUDIT_CONFIG']).resolve();cfg=load(cp);c=pin(cp)
    need(c['sha256']==inputs[str(cp)],'actual config hash')
    need(cfg['splitOriginal']==original and cfg['splitMode']==mode,'exact config declaration/mode')
    view=cfg['singleSourceDeclaration'];need(pin(view['path'])['sha256']==view['sha256'],'original complete record pin')
    output=Path(q['environment']['NEXT_CARRIER_SPLIT_DIAGNOSTIC_OUTPUT'])
    if cached_signature is not None:
        facts=cached_signature['facts'];need(facts['diagnosticPassed'] and facts['faithfulReplaySignatureKernelEqual'],'cached actual signature')
        dag=cached_signature['strictExpressionEvidence'];need(dag['allRootsStrictExprEqualRoundTrip'],'cached strict DAG')
        flags={k:facts[k] for k in ('rawSignatureBinderInventoryEqual','rawSignatureBinderPlacementEqual','rawFalseRemainsLiteral')}
        report_binding=cached_signature['report'];report_read=False;value=None
    else:
        x=load(output);need(x['original']==original and x['mode']==mode,'exact actual report')
        need(x['defaultLogicalCheckHeartbeatBudget']==200000,'default budget')
        dag=x['sharedLosslessExpressionEvidence'];need(dag['allRootsStrictExprEqualRoundTrip'] and dag['rootCount']>0,'all strict DAG roots')
        need(x['standardCompatibilityEvidence']['allRequiredKernelChecksPassed'],'standard compatibility')
        row=x['report'];flags=None;value=None
        if mode=='signature':flags=check_signature(row)
        elif mode=='value':value=check_value(row,req)
        elif mode=='axioms':check_axioms(row)
        elif mode=='complete-existing':
            need(row['completeSingleDeclarationChecksPassed'] is True,'complete declaration gate')
            flags=check_signature(row['signature']);value=check_value(row['wholeValueAndRules'],req)
            check_axioms(row['ownerAndAxiomClosure'])
            guards=row['sourceGuards']
            need(guards['constantKindUniverseOrderSourceAxiomsAndInstanceRegistryChecked'],'metadata/instance')
            need(guards['completeStructureMetadataAndAutoParamBinderPlacementChecked'],'full structure/autoParams')
            need(guards['exactSourceAndTargetOwnerChecked'],'exact owners')
        elif mode=='global-closure':
            need(row['actualNamedCount']==200 and row['actualOwnedCount']==201,'global counts')
            need(row['targetOnlyNames']==['AbcAdaptation.Reference.Iut.galK._proof_1'],'one helper')
            need(not row['namedDeclarationMathChecksClaimedFromInventory'],'inventory not mathematics')
            check_axioms(row['targetOnlyHelperOwnerAndAxiomClosure'])
        report_binding=pin(output);report_read=True
    return {'original':original,'mode':mode,'job_id':r['job_id'],'receipt':pin(path),
        'source':sp,'config':c,'sourceRecord':view,'report':report_binding,
        'currentSourceConfigAndRecordPinsMatch':True,'actualManifestInputHashCount':len(inputs),
        'sourceRecordExplicitlyInReceiptInputHashes':str(Path(view['path']).resolve()) in inputs,
        'reportReadAndHashedThisReview':report_read,'reusedLargeFormalSignatureSummary':cached_signature is not None,
        'innerGatesChecked':True,'rawFlags':flags,'wholeValueFacts':value,'resources':resources}


def main():
    plan=load(PLAN);requirements={r['original']:r for r in plan['completeSourceRecordRequirements']}
    cfgmap={str(Path(l['config']['path']).resolve()):(l['original'],l['mode']) for l in plan['leaves']}
    candidates={};history={};errors=[]
    # Fixed local-file scan; do not query running jobs or infer success from trace.
    receipts=sorted(B.glob('*-result.json'))
    for p in receipts:
        if p.stat().st_size>3*1024**2:continue
        r=load(p)
        if not isinstance(r,dict):continue
        q=r.get('request',{});c=q.get('environment',{}).get('NEXT_CARRIER_AUDIT_CONFIG')
        key=cfgmap.get(str(Path(c).resolve())) if c else None
        if not key:continue
        history.setdefault(key,[]).append({'job_id':r['job_id'],'status':r['status'],'receipt':pin(p)})
        if r['status']!='succeeded':continue
        try:e=inspect_receipt(p,*key,requirements.get(key[0]))
        except Exception as ex:errors.append({'receipt':str(p),'job_id':r['job_id'],'reason':str(ex)});continue
        if key not in candidates or e['job_id']>candidates[key]['job_id']:candidates[key]=e
    named=[]
    for n in plan['completeExistingOriginals']:
        e=candidates.get((n,'complete-existing'))
        named.append({'original':n,'requiredModes':['complete-existing'],'locallyReviewedComplete':e is not None,'leaves':[e] if e else []})
    for n in plan['exceptionalOriginals']:
        leaves=[candidates[n,m] for m in ('signature','value','axioms') if (n,m) in candidates]
        named.append({'original':n,'requiredModes':['signature','value','axioms'],
            'locallyReviewedComplete':len(leaves)==3,'leaves':leaves,
            'missingModes':[m for m in ('signature','value','axioms') if (n,m) not in candidates]})
    for old in plan['completedNamedEvidence']:
        summary=load(old['smallActualCorrespondenceSummary']['path'])
        need(pin(old['smallActualCorrespondenceSummary']['path'])['sha256']==old['smallActualCorrespondenceSummary']['sha256'],'cached summary pin')
        leaves=[]
        for row in old['receipts']:
            r=load(row['receipt']['path']);mode=load(r['request']['environment']['NEXT_CARRIER_AUDIT_CONFIG'])['splitMode']
            cached=None
            if old['original']=='Iut.TateFamily.S' and mode=='signature':cached=next(l for l in summary['leaves'] if l['mode']==mode)
            leaves.append(inspect_receipt(row['receipt']['path'],old['original'],mode,None,cached))
        named.append({'original':old['original'],'requiredModes':['signature','value','axioms'],
            'locallyReviewedComplete':True,'leaves':leaves,'cachedLargeSignatureReportNotReread':old['original']=='Iut.TateFamily.S'})
    global_receipt=B/'tate-thin-global-owned-closure-v14-result.json'
    global_review=inspect_receipt(global_receipt,'Iut.galK','global-closure')
    global_report=load(B/'tate-priority-v14/global-result.json')
    tate_row=next(r for r in global_report['report']['modules'] if r['sourceOwner']=='Iut.Cor312.ThetaData.TateFamily')
    expected_mapped={r['target'] for r in plan['namedCandidateIdentities']}
    need(set(tate_row['actualMappedNames'])==expected_mapped and len(expected_mapped)==28,'exact28 mapped names')
    need(set(tate_row['actualOwnedNames'])==expected_mapped|{'AbcAdaptation.Reference.Iut.galK._proof_1'},'exact29 owned names')
    need(tate_row['exactConfiguredImportsChecked'] is True,'Tate exact imports')
    proof_rows=[]
    for row in global_report['standardCompatibilityEvidence']['genuineOriginalProofValues']:
        if row['original'] not in {r['original'] for r in plan['genuineOriginalProofRequirements']}:continue
        for k in ('exactOriginalTypeKernelChecked','genuineOriginalValueInhabitsExactOriginalType',
                  'sourceAxiomInventoryMatchesAcceptedGraph','expandedDependenciesHaveAllowedOwners'):
            need(row[k] is True,'genuine proof '+k)
        need(row['standaloneTargetIdentity'] is None and row['hasSorryAx'] is False,'proof identity/axioms')
        need(set(row['expandedTypeAxioms'])<=ALLOWED and set(row['expandedValueAxioms'])<=ALLOWED,'proof standard axioms')
        parent=candidates[row['parentOriginal'],'complete-existing']
        need(parent['wholeValueFacts']['completeComputationalDataValueCompared'],'complete proof-parent value')
        proof_rows.append({'original':row['original'],'parentOriginal':row['parentOriginal'],
            'sourceTypeAndBodyKernelChecked':True,'sourceAxiomsAndOwnersChecked':True,
            'inferredInventoryEqual':row['inferredTypeFullBinderInfoInventoryEqual'],
            'inferredPlacementEqual':row['inferredTypeFullBinderInfoPlacementEqual'],
            'standaloneTargetIdentity':None,'genuineProofReport':global_review['report'],
            'parentCompleteValueJob':parent['job_id'],'parentCompleteValueReport':parent['report']})
    failed=[]
    for p in [B/'tate-Iut-TateFamily-mk-noConfusion-value-v14-result.json',
              B/'tate-Iut-TateFamily-mk-noConfusion-value-optimized-v18-result.json']:
        r=load(p);q=r['request'];failed.append({'job_id':r['job_id'],'status':r['status'],
            'receipt':pin(p),'source':{'path':str((W/q['parameters']['source']).resolve()),'sha256':q['worktree_manifest']['source_sha256']},
            'config':pin(q['environment']['NEXT_CARRIER_AUDIT_CONFIG']),
            'actualArguments':r['result']['actual_arguments'],
            'errors':[d['message'] for d in r['result']['diagnostics'] if d['severity']=='error'],
            'resources':r['resources']})
    missing=[{'original':r['original'],'mode':m} for r in named for m in r.get('missingModes',[])]
    slots=[{'original':l['original'],'mode':l['mode'],
            'actualEvidence':candidates.get((l['original'],l['mode'])),
            'locallyReviewedPassed':(l['original'],l['mode']) in candidates} for l in plan['leaves']]
    result={'status':'read-only saved-receipt review; publication readiness is separate',
        'plan':pin(PLAN),'namedCount':len(named),'locallyCompleteNamedCount':sum(r['locallyReviewedComplete'] for r in named),
        'named':named,'missingActualMathGates':missing,'sourceProofValues':proof_rows,
        'actual46LeafSlotMerge':slots,
        'genuineProofValuesWithPassedParentValues':len(proof_rows),'globalClosure':global_review,
        'actualOwnedTateCount':len(tate_row['actualOwnedNames']),'mappedNamedTateCount':len(tate_row['actualMappedNames']),
        'compilerOnlyHelper':'AbcAdaptation.Reference.Iut.galK._proof_1',
        'sourceSelectedCount':31,'standaloneProofAliases':0,
        'mkNoConfusionValueFailureHandoff':failed,'rejectedSucceededCandidates':errors,
        'savedReceiptHistoryByDeclarationMode':[{'original':n,'mode':m,'attempts':v} for (n,m),v in history.items()],
        'runningSignatureJobsAtParentRequest':['ci-016726','ci-016727','ci-016728'],
        'runningJobsQueried':False,'all200FormalAccepted':False,'TateModuleAccepted':False,
        'publicationReady':False,'compilerOrCIRun':False,'mainWorkspaceChanged':False}
    p=HERE/'partial-merge-review.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'review':pin(p),'namedComplete':result['locallyCompleteNamedCount'],
        'missingMathGates':missing,'proofValues':len(proof_rows),'rejectedSucceededCandidates':errors},ensure_ascii=False))


if __name__=='__main__':main()
