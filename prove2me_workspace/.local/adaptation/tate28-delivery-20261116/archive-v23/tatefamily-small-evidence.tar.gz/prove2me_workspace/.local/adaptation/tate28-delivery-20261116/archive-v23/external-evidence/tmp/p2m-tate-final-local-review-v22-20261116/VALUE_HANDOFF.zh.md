局部候选已准备。先执行ROOT_VALUE_COMMANDS.txt中的绑定，再提交，再按同tag收取；本子智能体没有执行这些命令。

候选source SHA dc0e18fce9b2a9e76d451860c639a82ccddae768451d72996eccbdae4c0a13d2。仅复用先前已成功取得的完整source value类型，避免kernelTermEq调用路径再次Kernel.check同一source value；target value实际Kernel.check、source-type前提、inferred-types与完整source/target values两次Kernel.isDefEq及原错误分支/顺序均保留。kernelTermEq定义、所有owner/axiom/recursor/DAG/default200000门完全未改。

这是可验证的机械减少重复计算，不保证它足以把原整体phase降到200000 heartbeat内。两次真实失败为ci-016378（源93432f...，169.6326s，CPU171.43s，RSS5447929856B）与ci-016558（源bf9d...，157.3633s，CPU161.11s，RSS5450653696B）；均明确在complete data value and available recursor/autoParam comparisons默认200000 heartbeat失败，而非调度wall timeout。完整配置相同，sourceRecord相同，不能靠延长wall timeout宣称修复。

命令使用旧实际源值峰约5.076GiB的依据申请6GiB、预估180s，不套用signature 15.61GiB峰，也不把本数学叶重算首次。原逻辑默认heartbeat仍200000，实际RSS门仍16GiB。当前是未编译草稿；root仍需检查终态、value内层完整type/value/shape与DAG门。
