#!/usr/bin/env python3
"""Persist completed small Tate math evidence; do not touch reports or sources."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
EXPECTED='9217c96b9cef35953c4e20afd99950faf33a53860d4ae748eb346e30e105caf3'
FILES=('partial-merge-review.json','review_local.py','finalize_dossier.py','README.zh.md','bind_math_dossier.py')


def pin(p):
    return {'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    out=parser.parse_args().out.resolve()
    if out.exists():raise ValueError('Refusing to overwrite existing evidence directory')
    original=HERE/'final-kernel-dossier.json'
    if pin(original)['sha256']!=EXPECTED:raise ValueError('Accepted frozen math dossier changed')
    dossier=json.loads(original.read_text())
    if not (dossier['all28NamedMathGatesPassed'] and dossier['all3OriginalProofsAndParentValuesPassed'] and
            dossier['all29OwnedAxiomAndOwnerClosuresPassed'] and len(dossier['actual46LeafResults'])==46 and
            len(dossier['actualReceipts'])==53 and dossier['all200FormalAccepted'] is False and
            dossier['publicationReady'] is False):
        raise ValueError('Completed mathematical coverage or scope differs')
    for key in ('readOnlyReview','mergeTool'):
        if pin(Path(dossier[key]['path']))!=dossier[key]:raise ValueError('Existing review/tool pin changed')
    out.mkdir(parents=True)
    for name in FILES:shutil.copyfile(HERE/name,out/name)
    rebound=copy.deepcopy(dossier)
    rebound['readOnlyReview']=pin(out/'partial-merge-review.json')
    rebound['mergeTool']=pin(out/'finalize_dossier.py')
    a={k:v for k,v in dossier.items() if k not in ('readOnlyReview','mergeTool')}
    b={k:v for k,v in rebound.items() if k not in ('readOnlyReview','mergeTool')}
    if a!=b:raise ValueError('Mathematical evidence changed')
    target=out/'final-kernel-dossier.json'
    target.write_text(json.dumps(rebound,ensure_ascii=False,indent=2)+'\n')
    manifest={'schema':'tate28-completed-math-binding-v23','sourceFrozenDossierSha256':EXPECTED,
        'boundDossier':pin(target),'copiedReviewFiles':[pin(out/name) for name in FILES],
        'onlyTwoLocalSelfReferencePathsRebound':True,'allMathematicalEvidenceFieldsUnchanged':True,
        'actualSourcesAndOriginalReportsModified':False,'compilerCiApiOrGitCalled':False,
        'publicationReadinessChanged':False}
    path=out/'binding-manifest.json';path.write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'dossier':pin(target),'bindingManifest':pin(path),'TateMathComplete':True,
        'publicationReady':False,'all200FormalAccepted':False}))


if __name__=='__main__':main()
