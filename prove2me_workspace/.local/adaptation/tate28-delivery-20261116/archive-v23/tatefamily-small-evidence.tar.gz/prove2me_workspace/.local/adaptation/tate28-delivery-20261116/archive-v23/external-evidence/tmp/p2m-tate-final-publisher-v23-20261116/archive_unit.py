#!/usr/bin/env python3
"""Root-only post-publication archive of small Tate evidence. No deletion or API.
Default reports; --apply writes one repo-relative tar and manifest to the long-term unit.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import tarfile

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = Path('/home/admin-wsl/Coq/abc')
W = ROOT / 'prove2me_workspace'
I = W / '.local/adaptation/reference-initial-theta-carriers-20261115'
DEFAULT_DELIVERY = W / '.local/adaptation/tate28-delivery-20261116'
LIMIT = 4 * 1024 ** 2
MATH_PIN_LIMIT = 2 * 1024 ** 2
TOTAL_LIMIT = 128 * 1024 ** 2


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--delivery', type=Path, default=DEFAULT_DELIVERY)
    parser.add_argument('--destination', type=Path)
    args = parser.parse_args()
    delivery = args.delivery.resolve()
    destination = (args.destination or delivery / 'archive-v23').resolve()
    assert destination.is_relative_to(W / '.local/adaptation')
    assert not destination.exists(), 'Inspect an existing archive rather than overwriting it'
    packet, ready = read(delivery / 'packet.json'), read(delivery / 'ready.final.json')
    assert ready['passed'] is True
    row, = packet['publications']
    published = read(delivery / 'platform' / (row['tag'] + '-published-item.json'))
    for key in ['definition_name', 'definition_title', 'definition', 'natural_language_statement', 'source']:
        assert published[key] == row['payload'][key]
    selected, excluded = {}, {}

    def add(path, expected=None, limit=LIMIT):
        path = Path(path)
        if not path.is_absolute():
            path = W / path
        if str(path) in selected:
            if expected is not None:
                assert selected[str(path)]['sha256'] == expected
            return
        if any(word in path.name.lower() for word in ['credentials', 'access_token', 'refresh_token']) or path.name == '.env':
            excluded[str(path)] = {'reason': 'credential input excluded'}
            return
        if not path.is_file() or path.is_symlink():
            excluded[str(path)] = {'reason': 'non-file/symlink reference', 'existingPin': expected}
            return
        size = path.stat().st_size
        if size > limit:
            excluded[str(path)] = {'reason': 'large pre-pinned source/report excluded without reading or hashing',
                'bytes': size, 'existingPin': expected, 'archiveSizeLimit': limit}
            return
        if path.is_relative_to(ROOT):
            member = path.relative_to(ROOT).as_posix()
        elif path.is_relative_to('/tmp'):
            member = (destination.relative_to(ROOT) / 'external-evidence/tmp' / path.relative_to('/tmp')).as_posix()
        else:
            excluded[str(path)] = {'reason': 'outside this repository and task temporary evidence', 'existingPin': expected}
            return
        assert not PurePosixPath(member).is_absolute() and '..' not in PurePosixPath(member).parts
        digest = sha(path)
        if expected is not None:
            assert digest == expected, 'A small pinned evidence file changed: ' + str(path)
        excluded.pop(str(path), None)
        selected[str(path)] = {'source': str(path), 'archive_path': member, 'bytes': size, 'sha256': digest}

    def pins(value):
        if isinstance(value, dict):
            if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
                add(value['path'], value['sha256'], limit=MATH_PIN_LIMIT)
            for child in value.values():
                pins(child)
        elif isinstance(value, list):
            for child in value:
                pins(child)

    for path in delivery.rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and not path.is_relative_to(destination):
            add(path)
    for path, digest in {**packet['metadata_sha256'], **ready['evidence_sha256']}.items():
        add(path, digest)
    dossier = read(delivery / 'final-kernel-dossier.json')
    pins(dossier)
    for receipt in dossier['actualReceipts']:
        add(receipt['path'], receipt['sha256'])
    # Preserve the unchanged dossier's original tool/self-reference locations.
    # Do not execute bind_math_dossier or change any frozen dossier field.
    math_tools = Path('/tmp/p2m-tate-final-local-review-v22-20261116')
    for path in math_tools.glob('*'):
        if path.is_file() and path.suffix in ['.py', '.json', '.md', '.txt']:
            add(path)
    add(Path(__file__).resolve())
    # Preserve this unit's retries/cancellations as small receipts, not complete
    # environment exports. Do not traverse the initial-theta unit recursively.
    for path in I.glob('*.json'):
        if path.name.startswith(('tate-', 'split-tatefamily-s-', 'graphline-')):
            add(path)
    for relative, digest in packet['source_sha256'].items():
        add(W / relative, digest)
    add(ROOT / 'refer/iut/LICENSE')
    add(ROOT / 'refer/iut/Iut/Cor312/ThetaData/TateFamily.lean')
    entries = sorted(selected.values(), key=lambda record: record['archive_path'])
    assert len({entry['archive_path'] for entry in entries}) == len(entries)
    size = sum(entry['bytes'] for entry in entries)
    assert size <= TOTAL_LIMIT, 'Small evidence selection grew beyond 128 MiB; inspect selection'
    manifest = {'schema': 'single-tate28-small-evidence-archive/v23', 'source': str(delivery),
        'publishedDefinition': published['definition_id'], 'input_bytes': size,
        'input_mib': size / 1024 ** 2, 'files': entries, 'excludedReferences': excluded,
        'scope': {'module': 'Iut.Cor312.ThetaData.TateFamily', 'canonicalC22Connected': False,
                  'scopeAllFourModules': False, 'all200FormalAccepted': False},
        'archiveNames': 'Uniform repo-relative keys, with /tmp evidence under a virtual external-evidence/tmp subtree.',
        'deletions': []}
    print(json.dumps({'apply': args.apply, 'destination': str(destination), 'files': len(entries),
        'input_bytes': size, 'input_mib': size / 1024 ** 2,
        'excluded_large_or_other_references': len(excluded), 'deletions': 0}, ensure_ascii=False, indent=2))
    if not args.apply:
        return
    destination.mkdir()
    archive_path = destination / 'tatefamily-small-evidence.tar.gz'
    with tarfile.open(archive_path, 'w:gz') as archive:
        for entry in entries:
            archive.add(entry['source'], arcname=entry['archive_path'], recursive=False)
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert {member.name for member in archive.getmembers()} == {entry['archive_path'] for entry in entries}
        for entry in entries:
            stream = archive.extractfile(entry['archive_path'])
            assert stream is not None and hashlib.sha256(stream.read()).hexdigest() == entry['sha256']
    manifest['archive_sha256'] = sha(archive_path)
    manifest['archive_bytes'] = archive_path.stat().st_size
    (destination / 'archive-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__':
    main()
