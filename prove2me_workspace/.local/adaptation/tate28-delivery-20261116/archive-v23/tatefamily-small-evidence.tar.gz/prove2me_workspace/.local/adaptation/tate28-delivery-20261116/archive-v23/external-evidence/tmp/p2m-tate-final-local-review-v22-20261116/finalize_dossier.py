#!/usr/bin/env python3
"""Merge actual saved Tate math receipts. No CI/API/Git or packet rewriting."""
import sys
sys.dont_write_bytecode=True
import json
from pathlib import Path
import review_local as review

HERE=Path(__file__).resolve().parent


def main():
    review.main()
    merged=review.load(HERE/'partial-merge-review.json')
    review.need(merged['namedCount']==merged['locallyCompleteNamedCount']==28,'all28 named math gates required')
    review.need(not merged['missingActualMathGates'],'math gate remains')
    review.need(merged['genuineProofValuesWithPassedParentValues']==3,'all3 genuine proof joins required')
    slots=merged['actual46LeafSlotMerge']
    review.need(len(slots)==46 and all(s['locallyReviewedPassed'] for s in slots),'all46 exact slots required')
    plan=review.load(review.PLAN)
    identities={r['original']:r for r in plan['namedCandidateIdentities']}
    rows=[];prior=[]
    for r in merged['named']:
        signature=next(l for l in r['leaves'] if l['mode'] in ('signature','complete-existing'))
        closure=next(l for l in r['leaves'] if l['mode'] in ('axioms','complete-existing'))
        rows.append({**identities[r['original']],'accepted':True,'actualEvidence':r['leaves'],
            'requiredModes':r['requiredModes'],'rawSignatureFlags':signature['rawFlags'],
            'actualOwnerTypeValueRecursorAxiomEvidence':closure['report']})
        if r['original'] in ('Iut.TateFamily.S','Iut.TateFamily.graphLine_galPlace'):prior+=r['leaves']
    global_evidence=merged['globalClosure']
    global_report=review.load(global_evidence['report']['path'])
    tate=next(r for r in global_report['report']['modules'] if r['sourceOwner']=='Iut.Cor312.ThetaData.TateFamily')
    proofs=[]
    for r in merged['sourceProofValues']:
        i=next(i for i,z in enumerate(global_report['standardCompatibilityEvidence']['genuineOriginalProofValues']) if z['original']==r['original'])
        actual=global_report['standardCompatibilityEvidence']['genuineOriginalProofValues'][i]
        record=actual['sourceRecord']
        review.need(record['elaboratedExpr'] is not None and record['valueExpr'] is not None,'full original proof type/body required')
        expected=(False,False) if r['original']=='Iut.galK._proof_2' else (True,True)
        review.need((r['inferredInventoryEqual'],r['inferredPlacementEqual'])==expected,'original inferred BinderInfo changed')
        parent=next(l for n in merged['named'] if n['original']==r['parentOriginal'] for l in n['leaves'] if l['mode']=='complete-existing')
        proofs.append({**r,'accepted':True,
            'actualOriginalProofReplayEvidence':{'receipt':global_evidence['receipt'],'report':global_evidence['report'],
                'jsonPointer':'/standardCompatibilityEvidence/genuineOriginalProofValues/'+str(i)},
            'actualParentCompleteValueEvidence':parent,
            'fullOriginalTypeAndBodyPresentInReferencedReport':True})
    leaves=[s['actualEvidence'] for s in slots]+prior+[global_evidence]
    receipts={l['job_id']:l['receipt'] for l in leaves}
    review.need(len(receipts)==53,'46 new +6 prior +1 global distinct receipts required')
    source=review.W/'Definitions/Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateFamily.lean'
    definition=review.pin(source)
    review.need(definition['sha256']=='7a89b737af9759856eac31dfede79ed8f6e39a3adc5136e4b0af75fa11026ad4','Definition changed')
    coverage={'source':31,'resolved':31,'named':28,'proof':3,'standard_proof':0,'source_proof_standalone_aliases':0}
    binder={'sourceSignatureRawFlags':[{'original':r['original'],**r['rawSignatureFlags']} for r in rows],
        'allOriginalRawSignatureBinderInfoEqual':False,
        'all28FaithfulReplaySignaturesAccepted':True,'all28ExactDataSlotAccountingAccepted':True,
        'completeComputationalValuesSemanticReplayAccepted':True,'completeRecursorRulesSemanticReplayAccepted':True,
        'computationalValueRawBinderInfoIdentityTested':False,'recursorRuleRawBinderInfoIdentityTested':False,
        'rawComputationalAnnotationEqualityClaimed':False,
        'genuineSourceProofInferredTypeBinderInfoAllEqual':False,
        'sourceProofInferredBinderInfoException':'Iut.galK._proof_2','sourceProofStandaloneAliases':[]}
    result={'schema':'tate28-actual-kernel-dossier-v23',
        'status':'all required Tate local math gates checked from actual saved terminal receipts',
        'module':'Iut.Cor312.ThetaData.TateFamily','kernelCoverage':coverage,
        'all28NamedMathGatesPassed':True,'all3OriginalProofsAndParentValuesPassed':True,
        'all29OwnedAxiomAndOwnerClosuresPassed':True,
        'sourceDefinition':definition,'sourcePlan':review.pin(review.PLAN),
        'namedCorrespondence':rows,'genuineSourceProofValues':proofs,
        'actual46LeafResults':[s['actualEvidence'] for s in slots],
        'reusedPriorLeaves':prior,'actualGlobalClosureResult':global_evidence,
        'actualReceipts':[{'job_id':k,**v} for k,v in sorted(receipts.items())],
        'ownedInventory':{'named':28,'owned':29,'actualMappedNames':tate['actualMappedNames'],
            'actualOwnedNames':tate['actualOwnedNames'],'exactConfiguredImportsChecked':tate['exactConfiguredImportsChecked'],
            'compilerOnlyHelpers':['AbcAdaptation.Reference.Iut.galK._proof_1'],
            'helperIsNamedSourceProofIdentity':False,
            'helperOwnerAndAxiomEvidence':{'report':global_evidence['report'],
                'jsonPointer':'/report/targetOnlyHelperOwnerAndAxiomClosure'}},
        'axiomAudit':{'sorryAx_found':False,'unexpected_axioms':[],
            'allowedStandardAxioms':sorted(review.ALLOWED),
            'scope':'all28 named actual closures,3 original proof type/body closures,1 compiler helper'},
        'binderInfoScope':binder,
        'largeEvidencePolicy':{'originalGBEnvironmentExportsReadOrRehashed':False,
            'S457MBSignatureReportReadOrRehashed':False,
            'existingAcceptedSFormalSummaryAndCachedFullReportPinReused':True},
        'sourceProofValuesAreAdditionalNamedTargets':False,
        'fullGlobalInventoryIsNotGlobal200MathAcceptance':True,
        'all200FormalAccepted':False,'root_graph_membership':False,'publicationReady':False,
        'deliveryGatesCompletedByThisMathMerge':False,'compilerOrCIRunByThisScript':False,
        'readOnlyReview':review.pin(HERE/'partial-merge-review.json'),'mergeTool':review.pin(Path(__file__))}
    path=HERE/'final-kernel-dossier.json';path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'dossier':review.pin(path),'kernelCoverage':coverage,'actualReceiptCount':53,
        'TateMathComplete':True,'publicationReady':False,'all200FormalAccepted':False}))


if __name__=='__main__':main()
