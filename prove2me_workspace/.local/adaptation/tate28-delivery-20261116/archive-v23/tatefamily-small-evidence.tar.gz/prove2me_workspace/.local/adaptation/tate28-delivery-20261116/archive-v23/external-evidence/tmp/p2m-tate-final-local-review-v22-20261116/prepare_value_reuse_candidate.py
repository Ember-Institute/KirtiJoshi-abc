#!/usr/bin/env python3
"""Optional local value-check inference reuse; not claimed to fix heartbeat failure.

Keep kernelTermEq itself unchanged, and keep its two conversions at this call site.
Only avoid rechecking the already checked complete source value a second time.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path

SOURCE=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/reference-initial-theta-carriers-20261115/exposed-row-reuse-v19/CheckOneDeclaration.lean')
SHA='3a0b751f04db3a88458bfd963e3bbf8e28ca764d91d408538ebda6aecac48703'
OLD='''    kernelTypeEq "complete replayed data value inhabits complete replayed source type"
      (← kernelCheck original.toString value) sourceType
    kernelTermEq "complete faithful replayed computational source/current value" value targetValue
'''
NEW='''    let inferredValueType ← kernelCheck original.toString value
    kernelTypeEq "complete replayed data value inhabits complete replayed source type"
      inferredValueType sourceType
    let inferredTargetType ← kernelCheck "complete faithful replayed computational source/current value" targetValue
    match Kernel.isDefEq (← getEnv) {} inferredValueType inferredTargetType with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inferred types differ: complete faithful replayed computational source/current value"
    | .error ex => throwKernelException ex
    match Kernel.isDefEq (← getEnv) {} value targetValue with
    | .ok true => pure ()
    | .ok false => throwError "Kernel values/types differ: complete faithful replayed computational source/current value"
    | .error ex => throwKernelException ex
'''


def pin(p):
    return {'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    out=parser.parse_args().out.resolve()
    if out.exists():raise ValueError('Output already exists')
    old=SOURCE.read_text()
    if hashlib.sha256(old.encode()).hexdigest()!=SHA or old.count(OLD)!=1:
        raise ValueError('Exact actual source or complete-value call site changed')
    new=old.replace(OLD,NEW,1)
    out.mkdir(parents=True)
    target=out/'CheckOneDeclaration.lean';target.write_text(new)
    (out/'value-inference-reuse-only.patch').write_text(''.join(difflib.unified_diff(
        old.splitlines(True),new.splitlines(True),fromfile='actual-row-v19/CheckOneDeclaration.lean',
        tofile='optional-value-reuse-v22/CheckOneDeclaration.lean')))
    manifest={'status':'optional uncompiled mechanical optimization; heartbeat success unknown',
        'source':pin(target),'baseline':pin(SOURCE),'tool':pin(Path(__file__)),
        'reverseOneBlockByteEqualsBaseline':new.replace(NEW,OLD,1)==old,
        'kernelTermEqDefinitionUnchanged':True,
        'sourceCompleteValueKernelInferenceCallsBefore':2,'sourceCompleteValueKernelInferenceCallsAfter':1,
        'actualTargetValueKernelChecked':True,'sourceValueTypePreconditionPreserved':True,
        'inferredTypeAndCompleteValueKernelConversionsPreserved':True,
        'originalLogicalErrorsAndTheirOrderPreserved':True,
        'valuesRulesGuardsBudgetsOwnersAxiomsDagReportSemanticsUnchanged':True,
        'defaultHeartbeatOption':200000,'noClaimOfResolvedFailure':True,
        'compilerOrCIRun':False,'acceptanceClaimed':False}
    p=out/'candidate-manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'manifest':pin(p),'source':pin(target),'compilerOrCIRun':False}))


if __name__=='__main__':main()
