#!/usr/bin/env python3
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,copy,shutil
D=Path('/tmp/p2m-main5-local-dossier-v27-20261116');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';B=A/'reference-main-bound-carriers-20261115'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'sha256':sha(p)}
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
manifestpath=B/'readback-tools-v8/formal-readback-manifest.json';manifest=load(manifestpath);historical={r['module']:r for r in manifest['files']}
def src(module):return W/Path(*module.split('.')).with_suffix('.lean')
def deps(module):
 p=src(module);out=[]
 for line in p.read_text().splitlines():
  if line.startswith('import '):
   out.extend(t for t in line[7:].split()if t.startswith('Definitions.'))
 return out
def closure(module,seen=None):
 seen=set()if seen is None else seen
 if module in seen:return seen
 seen.add(module)
 for d in deps(module):closure(d,seen)
 return seen
reuse=[]
for suffix,count,f in [('Iut_Cor312_LeftHandSide',25,'main5-relative-full-Iut-Cor312-LeftHandSide-v14-result.json'),('Iut_Cor312_RightHandSide',26,'main5-relative-full-Iut-Cor312-RightHandSide-v14-result.json'),('Iut_Cor312_Statement',19,'main5-relative-full-Iut-Cor312-Statement-v14-result.json')]:
 module='Definitions.Def_AbcAdaptation_Reference_'+suffix;cl=sorted(closure(module));sources=[];arts=[]
 for m in cl:
  p=src(m);assert m in historical,m;old=historical[m]['production'];assert sha(p)==old['sha256'],m
  sources.append({'module':m,'currentSource':pin(p),'historicalProductionPin':old,'sourceHashUnchanged':True})
  art=W/'.lake/build/lib/lean'/Path(*m.split('.')).with_suffix('.olean');assert art.exists();arts.append({'module':m,**pin(art)})
 assert not any('Implication_Invariants'in m or'Implication_LogVolumeBound'in m for m in cl)
 rp=B/f;r=load(rp);assert r['status']=='succeeded'and r['result']['exit_code']==0
 cp=Path(r['request']['environment']['MAIN_FIVE_IDENTITY_CONFIG']);cfg=load(cp);op=Path(cfg['outputFile']);inner=load(op)
 assert inner['allConfiguredRelativeChecksPassed']and inner['namedComparisons']==count and len(inner['targetAxiomAndOwnerAudits'])==count
 assert len(inner['genuineOwnSourceProofValues'])==0
 for comparison in inner['comparisons']:
  x=comparison['comparison'];assert x['allExpressionBinderInfoEqual']and x['binderInfoPlacementEqual']and x['kernelTypeEqual']
 for k,v in r['result']['snapshot']['manifest']['configuration_hashes'].items():assert sha(W/k)==v,k
 reuse.append({'module':module,'selected':count,'receipt':pin(rp),'job_id':r['job_id'],'passedConfiguration':pin(cp),'passedInnerReport':pin(op),'unchangedSourceClosure':sources,'currentArtifactPins':arts,
  'sourceRelativeReceiptReuseSupported':True,'changedInvariantsAndLogOutsideTransitiveImportClosure':True,'individualHistoricalOleanHashAvailable':False,
  'binaryIdentityToHistoricalArtifactsClaimed':False,'upstreamFormalAcceptanceClaimed':False,'note':'Current sources match historical production pins for every project dependency; current artifacts exist and are pinned. Source-level local evidence reuse only; upstream2 pending and no platform acceptance.'})
oldrp=B/'main5-selected173-fullowned176-facts-v17-result.json';r=load(oldrp);oldSource=W/r['request']['parameters']['source'];oldcfg=load(Path(r['request']['environment']['MAIN_FIVE_OWNED173_CONFIG']));source=D/'QueryCurrentSelected173AndOwned176.lean';shutil.copyfile(oldSource,source)
oldcfg['outputFile']=str(D/'results/current-selected173-owned176-facts.json');oldcfg['currentLocalSourceDossierEvidence']={'nativeSources':load(D/'next-log32-review-plan.json')['currentFiveNativeSources'],'initialUpstreamPending2':True,'platformAccepted':False,'publishAllowed':False}
querycfg=D/'current-owned176-config.json';save(querycfg,oldcfg)
privateRP=B/'main5-owned-private3-review-v19-result.json';pr=load(privateRP);pc=load(Path(pr['request']['environment']['MAIN_FIVE_PRIVATE3_CONFIG']));privateInner=Path(pc['outputFile']);pi=load(privateInner);assert pi['allConfiguredPrivateRelativeChecksPassed']and pi['unselectedPrivateComparisons']==3
privateSource=W/pr['request']['parameters']['source'];privateReplay=D/'AuditCurrentPrivateThreeCompleteIdentity.PENDING-FACT-JOB.lean';shutil.copyfile(privateSource,privateReplay)
save(D/'reuse-three-modules-and-private-plan.json',{'historicalSourcePinManifest':pin(manifestpath),'reusableModules':reuse,'reusedSelectedRecords':70,
 'privateHistoricalReceipt':pin(privateRP),'privateHistoricalInner':pin(privateInner),'privateHistoricalConfiguration':pin(Path(pr['request']['environment']['MAIN_FIVE_PRIVATE3_CONFIG'])),
 'privateFactsContainOldFiveNativeSourceShaBindings':False,'privateFactsConfigNativeShaFields':list(pc['actualNativeFacts']['contents']['configuration']),
 'privateReuseCondition':'Fresh selected173/owned176 query must show all3 complete native private types/values/kinds/universes/instances/axioms exactly identical to old private proof inputs. Current Log32 strict result must include placeBound.match_1; its source dependency is unchanged RationalPlace matcher. Otherwise replay existing private3 gate with fresh facts, no new proof policy.',
 'freshOwnedQuery':pin(source),'freshOwnedConfig':pin(querycfg),'freshOwnedEnvironment':{'MAIN_FIVE_OWNED173_CONFIG':str(querycfg)},
 'reasonForFreshOwnedQuery':'Old176 inventory includes changed Invariants declarations; refresh actual current imported selected173/wholeowned176 facts instead of relabelling old inventory. Existing query semantics unchanged.',
 'privateOptionalReplaySource':pin(privateReplay),'noAdditionalGateTypeIntroduced':True,'compilerRun':False,'CIInvoked':False,'mainWorkspaceWritten':False,'relativeOnly':True,'platformAccepted':False,'publishAllowed':False,'finalAcceptance':False})
print('unaffected source-relative selected',sum(x['selected']for x in reuse),'query',sha(source))
