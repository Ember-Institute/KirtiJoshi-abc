# Main5 完成后的最小归档

root 等待五包都真 PUBLISHED 后执行：

```bash
python3 -B /tmp/p2m-main5-archive-v34-20261116/archive_main5.py --apply
```

默认从 `A/main5-delivery-v33` 读取，写入新的 `A/main5-small-evidence-v34`。无 `--apply` 时只读规划，不写主区。归档成功、成员字节核对通过后，再由 root 统一把五个真实 ID 登记入 registry。

收录五 packet/ready/完整 Definitions/payload/原publisher/真实 platform journal 与父依赖读回；固定SHA的173 named+private3/176实际dossier、所有真实成功CI receipts、query源码、compact当前owned176事实；v28完整冻结27三语、18引文、源差异、完整源副本；proof计数说明、来源/资源回执和历史候选源码。

大型source DAG、导出、嵌入DAG的config/完整expanded math report、native binary只保留已验收pin。不对这些深层文件stat、读取、复制或rehash。没有128MiB或其他新大小验收门。此脚本只核对既有发布回执和归档字节，不新增数学门，不调用CI/API/Git，不改registry，不删除文件。

`exact-duplicate-candidates.json` 是逐字节比较后的清单：主区可考虑的精确候选为 candidate-v8 Definitions 中的Left/Right/Statement三文件，以及main-five-relative-v11 materialization中的Log一文件；另有相应/tmp四副本。没有找到current Invariants的精确candidate副本。9份历史不同候选单列保留。清单排除了frozen blind/readback、v28交付源、实际Definitions、真实发布源和尚未完成的theorem/proof drafts；只列不删。
