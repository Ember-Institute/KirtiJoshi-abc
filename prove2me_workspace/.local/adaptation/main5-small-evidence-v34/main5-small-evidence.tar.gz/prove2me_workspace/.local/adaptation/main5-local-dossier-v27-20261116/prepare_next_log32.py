#!/usr/bin/env python3
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,copy
D=Path('/tmp/p2m-main5-local-dossier-v27-20261116');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';B=A/'reference-main-bound-carriers-20261115'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'sha256':sha(p)}
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
new71=A/'main5-refresh-two-proofs-v26-20261116/results/fresh-two-certificate-exact71-result.json';fresh=load(new71);assert fresh['allConfiguredRelativeChecksPassed']and fresh['namedComparisons']==71
base=A/'main-five-173-named-v16-20261116/configs/Iut-Implication-LogVolumeBound.json';c=load(base);identity=fresh['configuration'];assert c['projectMap']==identity['projectMap']and len(c['records'])==32 and not c['proofValueResolutions']
c['outputFile']=str(D/'results/current-source-log32-result.json');(D/'results').mkdir(exist_ok=True)
mods=['Iut_Cor312_LeftHandSide','Iut_Cor312_RightHandSide','Iut_Cor312_Statement','Iut_Implication_Invariants','Iut_Implication_LogVolumeBound'];sources=[]
for m in mods:
 p=W/'Definitions'/('Def_AbcAdaptation_Reference_'+m+'.lean');sources.append(pin(p))
c['currentLocalSourceDossierEvidence']={'scope':'LOCAL SOURCE-relative only','nativeSourcePins':sources,'currentInvariants71':pin(new71),'currentInvariants71Receipt':pin(B/'main5-invariants71-current-source-two-proofs-v26-result.json'),'initialUpstreamPendingObligationsReportedByRoot':2,'platformAccepted':False,'publishAllowed':False,'finalAcceptance':False}
cp=D/'current-source-log32-config.json';save(cp,c);source=A/'main-five-relative-v14-20261116/ready/AuditMainFiveRelativeBounded.lean'
r=load(B/'main5-exact173-Iut-Implication-LogVolumeBound-v16-result.json')
arts=[]
for m in mods:
 p=W/'.lake/build/lib/lean/Definitions'/('Def_AbcAdaptation_Reference_'+m+'.olean')
 if p.exists():arts.append(pin(p))
save(D/'next-log32-review-plan.json',{'source':pin(source),'configuration':pin(cp),'environment':{'MAIN_FIVE_IDENTITY_CONFIG':str(cp)},'task_type':'review','target':'file','parameters':{'source':str(source)},'exclusive':True,
 'sourceHasSuccessfulCompilationHistory':True,'previousLog32Job':r['job_id'],'previousLog32Resources':r['resources'],
 'reasonForReplay':'LogVolumeBound was rebuilt against changed Invariants621ad6...; old Log32 receipt binds earlier input. Same32 declarations/maps/strict checker, no new mathematical obligation.',
 'currentFiveNativeSources':sources,'currentFiveNativeArtifacts':arts,'artifactHistoryLimit':'Current olean hashes are pinned now. Earlier review receipts did not pin individual olean hashes, so byte identity with old artifacts is not asserted.',
 'copyLivePathChanges':['Only current-source-log32-config.outputFile; environment points to actual copied config. Reuse existing actual strict auditor source path, no new checker source needed.'],
 'rootResourceEstimateBasis':'Existing Log32 completed73.372s peakRSS5293412352B; root chooses replay estimates using measured history, not reset-first60s. Invariants new71 completed79.96s peakRSS5224714240B.',
 'nextLocalDossierScope':'Five modules173 selected named +3 independently proved private compiler declarations =176 owned; upstreaminitialpending2, platformfalse.',
 'compilerRun':False,'CIInvoked':False,'mainWorkspaceWritten':False,'relativeOnly':True,'platformAccepted':False,'publishAllowed':False,'finalAcceptance':False})
print(cp,sha(cp))
