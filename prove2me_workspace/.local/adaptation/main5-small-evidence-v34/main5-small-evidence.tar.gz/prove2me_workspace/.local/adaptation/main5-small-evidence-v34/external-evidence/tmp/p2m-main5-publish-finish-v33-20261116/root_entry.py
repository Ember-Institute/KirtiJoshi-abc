#!/usr/bin/env python3
"""Explicit root invocation of the unchanged private one-Definition protocol. Never runs on import."""
import argparse
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import bind_ready as binding

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['collect-scope','check','deliver','reconcile']);p.add_argument('--module',choices=binding.MODULES,required=True);p.add_argument('--delivery-directory',type=Path);p.add_argument('--scope-directory',type=Path);p.add_argument('--registry',type=Path,default=binding.REGISTRY);p.add_argument('--published-readback',type=Path,action='append',default=[]);p.add_argument('--job-id');a=p.parse_args()
 if a.command=='collect-scope':
  if a.scope_directory is None:p.error('collect-scope requires --scope-directory')
  profile,packet,_,_,_=binding.foundation(a.module,a.registry,a.published_readback)
  binding.need(all(r['registryEvidence']['id'] for r in packet['parent_foundation_definitions']),'A real direct parent ID is pending')
  a.scope_directory.mkdir(parents=True,exist_ok=True);binding.save(a.scope_directory/'module-profile.json',profile)
  publisher=binding.load_module('original_scope_protocol',binding.HERE/'publisher-template.py');publisher.OUT=a.scope_directory
  api=binding.load_module('existing_api',binding.W/'.local/abc-item/api.py')
  publisher._protocol()['check_scope'](api,a.scope_directory);publisher._parents(api,packet,a.scope_directory)
  print(json.dumps({'savedScopeAndExactParents':True,'POSTPerformed':False}));return
 if a.delivery_directory is None:p.error('This command requires --delivery-directory')
 publisher=binding.load_module('original_publisher_'+a.module,a.delivery_directory/'publisher.py');packet=a.delivery_directory/'packet.json';ready=a.delivery_directory/'ready.final.json'
 if a.command=='check':
  publisher.check(packet,ready);print(json.dumps({'passed':True,'APIInvoked':False}));return
 api=binding.load_module('existing_api',binding.W/'.local/abc-item/api.py');journal=a.delivery_directory/'platform'
 if a.command=='deliver':result=publisher.deliver(api,packet,ready,journal)
 else:
  if not a.job_id:p.error('reconcile requires original --job-id')
  result=publisher.reconcile(api,packet,ready,journal,a.job_id)
 print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
