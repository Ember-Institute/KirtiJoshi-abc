# 五包私有publication元数据：最小重绑定草稿

入口：`rebind_private_metadata.py`。仅处理本目录元数据，读取现有registry/当前完整源码/已完成local dossier；不编译、不调用CI/API/Git、不改主区，也不启动数学检查。

五个candidate-v8平台草稿已经存在，原payload只有 `definition_name` 与 `code` 两字段。本目录继续同一schema，在 `payloads/`重绑当前五份完整Definitions源码。`metadata/`另存私有可见性、actual依赖ID状态、local来源证据和冻结读回trace，不向API payload擅加字段。

| 包 | 当前完整source SHA256 | 三语读回条数 |
| --- | --- | ---: |
| LeftHandSide |a0e53b47303140a6522725aab92acbd8f1c9679ac1da98e37b24ad31c24ae0ca|5|
| RightHandSide |0f760d8e8c8f68b554843f042fcaa6f26cf983d5d43b755cc7b431be15f1ba8c|3|
| Statement |124b1cde92438a098ba1216f32e67e5911f2bdc992acae39fb4ae9434205cc81|2|
| Invariants |621ad6f27db0a06be5b4746e156b99bb14e1978e2238bf21fce2007d21a27c38|13|
| LogVolumeBound |50d3b71d6a3838c85bf7a33624f80cfc6bd97d9e68027158f74cf4437c6be350|4|

具体读回计数以 `private-publication-rebinding-plan.json`为准；合计27条。五份完整源码复制到 `Definitions/`，每份payload.code与实际源码全文相同。`source-deltas/`保留原candidate-v8到当前源的精确diff：前三包不变；Invariants仅两处匿名section/local priority1000；Log仅三equation的local simp materialization。删除这些确切控制命令即可恢复原candidate源码字节，没有改声明字段、数学正文或读回。

## 冻结三语与Mochizuki上下文

`frozen/`逐字复制原三语读回JSON、两个原英文reader输出、a/b完整类型核对、实际旧compiler types文本、五个原blind代码、原paper context与paper/readback join。`frozen-bundles/`为五包提供原三语声明对象和原formal_contexts/paper_source_context的无改写分组。

`readback27-current-source-trace.json`逐声明绑定：冻结英文hash及三语对象hash、原reader/typeconfirmation、完整原lossless source DAG、当前五模块实际来源对应receipt、当前完整Definition源码SHA，以及对应Mochizuki上下文。27条英文逐条与两个原reader文本精确相等；中文/日文保持原对象，术语维持 packet=分量积包、shell region=壳区域。

旧读回已按完整类型核对；这里保留证据并用当前local source对应重绑，不伪称重新盲读，也不重做或冒称PDF视觉审查。18条Mochizuki原文/5包上下文保留原归属：论文背景不是Lean形式前提，原formal读回与论文意图分开。

## actual_dependencies与publication状态

读取主区现有 `platform-node-registry.json` 的 `reference_source_preparation.definitions(name,id)`，本轮实际26条。已发表依赖仅采用其中真实ID；LocalConditions、Basic当前为null/pending。五包内部依赖单独记录“等待前一私有Definition实际返回ID”，不使用module名或placeholder充当platform id。

每包 `actualDependencyRows`保留完整module→definition_name→实际ID/未解析状态。所有依赖ID齐全之前，`actual_dependencies=null`，同时`resolved_dependency_ids`只列已核实的实际ID，避免把不完整集合伪装最终依赖。Local/Basic实际ID入registry后，可复制本脚本到root实际任务目录重新运行同一入口；随后五包按Left、Right、Statement、Invariants、Log顺序，用真实已返回的内部ID再重绑。

本脚本始终保持 `publishReady=false`、`publishAllowed=false`、`platformAccepted=false`、`finalAcceptance=false`；它不会发布、发消息或修改registry，不从本地173+private3/176对应推导平台完成。Local由root优先完成，Basic的本地完成不等于平台ID已存在。

`private-publication-rebinding-plan.json`是最小重绑定入口清单；`frozen-inputs.json`记录逐字复制的原文件hash。main5本地证据绑定已完成的LOCAL SOURCE-relative dossier和freshowned ci017117；这一层是metadata only，不新加审查门。
