#!/usr/bin/env python3
"""Merge only real receipts into a LOCAL SOURCE-relative dossier. No compiler/API/Git calls."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,json,hashlib
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';B=A/'reference-main-bound-carriers-20261115'
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--owned-receipt',type=Path);p.add_argument('--owned-output',type=Path);a=p.parse_args();assert bool(a.owned_receipt)==bool(a.owned_output)
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p.resolve()),'sha256':sha(p)}
def jsonkey(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def resources(r):
 v=r['resources'];total=v.get('cpu_time_seconds');user=v.get('cpu_user_seconds');system=v.get('cpu_system_seconds')
 if all(z is not None for z in [total,user,system]):assert abs(total-user-system)<0.001
 return {k:v.get(k)for k in ['wall_time_seconds','cpu_time_seconds','cpu_user_seconds','cpu_system_seconds','peak_rss_bytes','peak_pss_bytes']}
def passed(rp,envkey):
 r=load(rp);assert r['status']=='succeeded'and r['result']['exit_code']==0,rp
 s=r['result']['snapshot'];assert s['workspace_mode']=='exclusive_worktree'and s['snapshot_id']is None
 cp=Path(r['request']['environment'][envkey]);c=load(cp);op=Path(c['outputFile']);o=load(op)
 query=W/r['request']['parameters']['source'];assert s['manifest']['source_sha256']==sha(query),query
 assert o['configuration']==c
 return r,c,o,{'receipt':pin(rp),'query':pin(query),'configuration':pin(cp),'innerReport':pin(op),'job_id':r['job_id'],'resources':resources(r)}
reuse=load(D/'reuse-three-modules-and-private-plan.json');modules=[];originals={};targetnames=set();standards={'propext','Classical.choice','Quot.sound'}
# Revalidate current source compatibility for the unaffected70, not just old receipts.
for item in reuse['reusableModules']:
 for s in item['unchangedSourceClosure']:
  q=Path(s['currentSource']['path']);assert sha(q)==s['currentSource']['sha256']==s['historicalProductionPin']['sha256']
 assert item['changedInvariantsAndLogOutsideTransitiveImportClosure']
module_receipts=[('Iut.Cor312.LeftHandSide',25,'main5-relative-full-Iut-Cor312-LeftHandSide-v14-result.json','reused unaffected source/import closure'),('Iut.Cor312.RightHandSide',26,'main5-relative-full-Iut-Cor312-RightHandSide-v14-result.json','reused unaffected source/import closure'),('Iut.Cor312.Statement',19,'main5-relative-full-Iut-Cor312-Statement-v14-result.json','reused unaffected source/import closure'),('Iut.Implication.Invariants',71,'main5-invariants71-current-source-two-proofs-v26-result.json','new current source621ad6... receipt'),('Iut.Implication.LogVolumeBound',32,'main5-log32-current-structure-source-v27-result.json','new receipt after rebuilt changed Invariants dependency')]
known={'Iut.Theorem110Certificate.casesOn':False,'Iut.Theorem110Certificate.recOn':True}
for module,count,file,why in module_receipts:
 r,c,o,ev=passed(B/file,'MAIN_FIVE_IDENTITY_CONFIG')
 assert o['allConfiguredRelativeChecksPassed']and o['selectedSourceObligations']==count and o['namedComparisons']==count
 assert len(o['comparisons'])==count and len(o['targetAxiomAndOwnerAudits'])==count and not o['genuineOwnSourceProofValues']
 assert c['scopeSourceModule']==module
 # Old unaffected module configs installed the global original dmod proof value,
 # but none of these selected complete records references any such proof Name.
 if c['proofValueResolutions']:
  assert module in ['Iut.Cor312.LeftHandSide','Iut.Cor312.RightHandSide','Iut.Cor312.Statement']
  proofnames={jsonkey(z['originalName'])for z in c['proofValueResolutions']}
  for selected_binding in c['records']:
   sv=load(Path(selected_binding['sourceView']['path']))
   assert not any(node['kind']in ['const','proj']and jsonkey(node['name'])in proofnames for node in sv['expressionDag']['nodes'])
 for key in ['standardRenames','dataValueSubstitutions','newAliases']:assert c[key]==[]
 assert o['relativeOnly']and not o['publishAllowed']and not o['finalAcceptance']
 auditby={r['name']:r for r in o['targetAxiomAndOwnerAudits']}
 for row in o['comparisons']:
  z=row['comparison'];n=z['original'];assert n not in originals
  assert z['kernelTypeEqual']and z['sourceTargetSignatureBinderInfoInventoryEqual']and z['sourceTargetSignatureBinderInfoPlacementEqual']
  assert z['completeStructureMetadataEqual']and z['computationShapeEqual']and z['instanceRegistryMatchesAcceptedGraph']and z['sourceAxiomInventoryMatchesAcceptedGraph']
  if n in known:
   assert not z['allExpressionBinderInfoEqual']and not z['binderInfoPlacementEqual']and z['kernelPropositionalValueEquality']and z['kernelValueEqual']is known[n]
   proof=z['propositionalValueEqualityEvidence'];assert proof['kernelCheckedExactCompleteFunctionEqualityProof']
  else:
   assert z['allExpressionBinderInfoEqual']and z['binderInfoPlacementEqual']and not z['kernelPropositionalValueEquality']
   if z['computationalValueEqualityChecked']:assert z['kernelValueEqual']
  ax=auditby[z['target']];assert not ax['hasSorryAx'];assert set(ax['axioms'])<=standards and set(ax['typeAxioms'])<=standards and set(ax['valueAxioms'])<=standards
  sv=row['sourceExpressionView'];assert sha(Path(sv['path']))==sv['sha256']
  assert jsonkey(z['targetName'])not in targetnames;targetnames.add(jsonkey(z['targetName']))
  originals[n]={'originalName':z['originalName'],'targetName':z['targetName'],'module':module,'sourceView':sv,'proofMethod':'exact whole-function Eq plus actual defeq evidence'if n in known else'original strict record checks','kernelDefeq':z['kernelValueEqual'],'rawBinderInfoEqual':z['allExpressionBinderInfoEqual']}
 if module.endswith('Invariants'):
  assert o['allOther69RecordsRetainStrictChecks']and o['namedWholeFunctionCertificatesChecked']==2 and o['casesOnCertificateUses']==o['recOnCertificateUses']==1
  for key,expectedjob in [('casesOnWholeFunctionCertificate','ci-017043-4b96e379'),('recOnWholeFunctionCertificate','ci-017054-b727644a')]:
   cp=Path(c[key]['path']);assert sha(cp)==c[key]['sha256'];certificate=load(cp);assert certificate['expectedProbeJobId']==expectedjob
   for b in certificate['passedProbeConfig']['contents']['actualNativeSources']:
    q=Path(b['path']);assert q.read_text()==b['contents']and sha(q)==b['sha256']
 ev.update({'sourceModule':module,'selectedNamed':count,'reuseOrReplayReason':why});modules.append(ev)
assert len(originals)==173 and len(targetnames)==173
# Reuse independently completed strict private3 evidence; it is outside selected173.
privateRP=B/'main5-owned-private3-review-v19-result.json';pr,pc,po,pev=passed(privateRP,'MAIN_FIVE_PRIVATE3_CONFIG');assert po['allConfiguredPrivateRelativeChecksPassed']and po['unselectedPrivateComparisons']==3
assert 'actualNativeSources'not in pc['actualNativeFacts']['contents']['configuration']
private=[]
for row in po['comparisons']:
 assert row['completePrivateTypeAndValueKernelEqual']and row['bothCompletePrivateBodiesIndividuallyKernelTyped']and row['proofBodiesAlsoComparedWithRawBinderInfo']and row['rawPrivateValueBinderInventoryEqual']and row['rawPrivateValueBinderPlacementEqual']
 z=row['originalGenericStrictComparison'];assert z['kernelTypeEqual']and z['allExpressionBinderInfoEqual']and z['binderInfoPlacementEqual'];assert z['sourceRecord']['selected']is False
 f=row['actualFullNativeFact'];ax=row['targetAxiomAndOwnerAudit'];assert not ax['hasSorryAx']and set(ax['axioms'])<=standards
 sv=row['sourceView'];assert sha(Path(sv['path']))==sv['sha256']
 assert z['original']not in originals and jsonkey(f['nameExpr'])not in targetnames;targetnames.add(jsonkey(f['nameExpr']))
 private.append({'original':z['original'],'originalName':z['originalName'],'target':f['name'],'targetName':f['nameExpr'],'sourceView':sv,'fullFact':f})
assert len(private)==3 and len(targetnames)==176
# Preserve an explicit boundary between the fresh selected-source proof coverage
# and an imported owned176 observation recorded under earlier native input.
oldFactsBinding=pc['actualNativeFacts'];oldfacts=load(Path(oldFactsBinding['path']));assert oldfacts==oldFactsBinding['contents']
owned={'freshCurrentInventoryConfirmed':False,'historicalActualFacts':{k:v for k,v in oldFactsBinding.items()if k!='contents'},'historicalJob':'ci-016686-5911b02b','selectedNames':173,'ownedNamesHistoricallyObserved':176,'privateThreeFullFactsFreshlyIdentical':None,'pendingAction':'Replay the existing owned query with current-owned176-config; no new gate or mathematics.'}
if a.owned_receipt:
 rr=load(a.owned_receipt);assert rr['status']=='succeeded'and rr['result']['exit_code']==0
 snap=rr['result']['snapshot'];assert snap['workspace_mode']=='exclusive_worktree'and snap['snapshot_id']is None
 q=W/rr['request']['parameters']['source'];assert sha(q)==snap['manifest']['source_sha256']
 cp=Path(rr['request']['environment']['MAIN_FIVE_OWNED173_CONFIG']);qc=load(cp);fresh=load(a.owned_output);assert fresh['configuration']==qc
 assert fresh['selectedSourceDeclarationCount']==173 and fresh['ownedDeclarationCount']==176 and fresh['additionalOwnedDeclarationCount']==3 and fresh['all173StructuralNamesOwnersKindsInstancesAndAxiomsChecked']
 assert {jsonkey(f['nameExpr'])for f in fresh['ownedDeclarations']}==targetnames
 by={jsonkey(f['nameExpr']):f for f in fresh['additionalOwnedDeclarations']}
 for r in private:
  cur=by[jsonkey(r['targetName'])];old=r['fullFact']
  # Exact current Expr identity validates historical private proof operand reuse;
  # the changed Invariants definitions cannot be silently substituted here.
  for k in ['nameExpr','module','constantKind','levelParams','elaboratedExpr','valueExpr','isProposition','isInstance','axioms','typeAxioms','valueAxioms','hasSorryAx']:assert cur[k]==old[k],(r['target'],k)
 for f in fresh['ownedDeclarations']:assert not f['hasSorryAx']and set(f['axioms'])<=standards
 matcher='Iut.Theorem110Invariants.LocalEstimate.placeBound.match_1';assert matcher in originals and originals[matcher]['module']=='Iut.Implication.LogVolumeBound'
 owned={'freshCurrentInventoryConfirmed':True,'actualFacts':pin(a.owned_output),'actualReceipt':pin(a.owned_receipt),'actualJob':rr['job_id'],'selectedNames':173,'ownedNamesObserved':176,'additionalPrivateNames':3,'privateThreeFullFactsFreshlyIdentical':True,'resources':resources(rr),'noPrivateGateRecompileRequired':'Historical private3 full typed operands/metadata/axioms exactly equal current actual facts; match_1 current source value is already strict-checked in fresh Log32. No old five-source SHA binding exists in the private fact/proof config.'}
# Current source/artifacts, historical binary identity is not fabricated.
modulesCurrent=[]
for r in load(D/'next-log32-review-plan.json')['currentFiveNativeSources']:
 q=Path(r['path']);assert sha(q)==r['sha256'];module='Definitions.'+q.stem;art=W/'.lake/build/lib/lean/Definitions'/(q.stem+'.olean');assert art.exists();modulesCurrent.append({'source':pin(q),'currentArtifact':pin(art)})
for r in reuse['reusableModules']:
 for x in r['currentArtifactPins']:
  # Keep current hashes, but never assert they were the old task's opaque bytes.
  q=Path(x['path']);assert q.exists()
summary={'schema':'main5-LOCAL-SOURCE-relative-173named-plus-private3-dossier/v1','scope':'LOCAL SOURCE-relative; not platform accepted','moduleReceipts':modules,'selectedNamedCount':173,'sourceSelectedProofValueResolutions':0,'sourceRecordCountOriginal197':197,'selectedSourceRecordCount':173,
 'selectedNamedRecords':originals,'private3Evidence':{**pev,'selectedOriginalRecords':False,'fullTypedPrivateProofsReused':True,'factsHaveNoOldFiveNativeSourceShaBinding':True,'records':[{k:v for k,v in r.items()if k!='fullFact'}for r in private]},
 'independentlyCheckedPrivateCount':3,'selectedPlusPrivateCount':176,'ownedInventory':owned,'unselectedPublicOriginalTheoremsOutsideThisDossier':21,
 'sourceReuseAnalysis':pin(D/'reuse-three-modules-and-private-plan.json'),'currentFiveNativeInputs':modulesCurrent,
 'rawFlags':{'ordinary171SelectedRecordsStrict':True,'Theorem110Certificate.casesOn':{'rawBinderInventoryEqual':False,'rawBinderPlacementEqual':False,'kernelDefeq':False,'wholeFunctionEquality':True},'Theorem110Certificate.recOn':{'rawBinderInventoryEqual':False,'rawBinderPlacementEqual':False,'kernelDefeq':True,'wholeFunctionEquality':True}},
 'currentSelected173LocalSourceEvidenceComplete':True,'currentPrivate3ImportedInventoryFreshlyConfirmed':owned['freshCurrentInventoryConfirmed'],
 'initialUpstreamPendingObligationCountReportedByRoot':2,'upstreamAcceptedByThisMerge':False,'dependencyFormalAcceptanceClaimed':False,'platformAccepted':False,'platformFinalAcceptance':False,
 'localSourceRelativeOnly':True,'newAliases':[],'dataValueSubstitutions':[],'newStandardRenames':[],'compilerRunByMerge':False,'CIInvokedByMerge':False,'APIInvokedByMerge':False,'GitInvokedByMerge':False,'publishAllowed':False,'finalAcceptance':False}
(D/'main5-local-source-relative-dossier.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'selectedNamed':173,'independentPrivate':3,'selectedPlusPrivate':176,'moduleJobs':[r['job_id']for r in modules],'currentOwnedInventoryFresh':owned['freshCurrentInventoryConfirmed'],'initialUpstreamPending':2,'platformAccepted':False,'output':str(D/'main5-local-source-relative-dossier.json')},indent=2))
