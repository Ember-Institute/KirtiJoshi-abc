#!/usr/bin/env python3
"""Root-only sequential entry: existing scope readback, offline binding, unchanged publication protocol."""
import argparse
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import bind_ready as b

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--git-diff-check',type=Path,required=True);p.add_argument('--out-root',type=Path,required=True);p.add_argument('--registry',type=Path,default=b.REGISTRY);a=p.parse_args()
 api=b.load_module('existing_api',b.W/'.local/abc-item/api.py');actual=[];ids={}
 for module in b.MODULES:
  directory=a.out_root/module;scope=a.out_root/(module+'-scope')
  if not (directory/'ready.final.json').exists():
   b.need(not directory.exists(),'Incomplete binding directory requires root inspection: '+str(directory))
   profile,packet,_,_,_=b.foundation(module,a.registry,actual);b.need(all(x['registryEvidence']['id'] for x in packet['parent_foundation_definitions']),'A real dependency ID is pending')
   scope.mkdir(parents=True,exist_ok=True);b.save(scope/'module-profile.json',profile)
   protocol=b.load_module('scope_'+module,b.HERE/'publisher-template.py');protocol.OUT=scope
   protocol._protocol()['check_scope'](api,scope);protocol._parents(api,packet,scope)
   b.bind(module,a.git_diff_check,scope,directory,a.registry,actual)
  publisher=b.load_module('unchanged_'+module,directory/'publisher.py')
  ids.update(publisher.deliver(api,directory/'packet.json',directory/'ready.final.json',directory/'platform'))
  name=b.read(directory/'module-profile.json')['definitionName'];actual.append(directory/'platform'/(name+'-published-item.json'))
  b.save(a.out_root/'published-ids.json',ids);print(json.dumps({'module':module,'actualPublishedIds':ids},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
