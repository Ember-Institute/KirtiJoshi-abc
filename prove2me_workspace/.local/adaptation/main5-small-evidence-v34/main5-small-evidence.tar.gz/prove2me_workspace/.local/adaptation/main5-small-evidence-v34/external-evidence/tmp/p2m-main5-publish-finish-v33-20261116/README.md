# 主界五模块：既有协议交付绑定

唯一发布顺序：LeftHandSide → RightHandSide → Statement → Invariants → LogVolumeBound。

最短 root 命令（root 已有真实 `git diff --check` JSON 回执；路径由 root 填入）：

```bash
python3 -B /tmp/p2m-main5-publish-finish-v33-20261116/run_main5.py --git-diff-check /absolute/path/to/actual-git-diff-check.json --out-root /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/main5-delivery-v33
```

registry28 已包含真实 LocalConditions 和 Basic ID。五包内部 ID 逐个由前包真实 `published-item.json` 注入下一包；不要求发布中途修改 registry。请保持 registry、源码、证据和此草稿目录稳定，最终再统一登记五个真实 ID。每个包保留一个 platform journal；重试使用原命令和同一目录。原始 POST 结果不明时，先用原 job ID reconcile，不新建 journal。

细分命令：

```bash
python3 -B /tmp/p2m-main5-publish-finish-v33-20261116/root_entry.py collect-scope --module LeftHandSide --scope-directory /absolute/path/LeftHandSide-scope
python3 -B /tmp/p2m-main5-publish-finish-v33-20261116/bind_ready.py --module LeftHandSide --scope-directory /absolute/path/LeftHandSide-scope --git-diff-check /absolute/path/actual-git-diff-check.json --out /absolute/path/LeftHandSide
python3 -B /tmp/p2m-main5-publish-finish-v33-20261116/root_entry.py check --module LeftHandSide --delivery-directory /absolute/path/LeftHandSide
python3 -B /tmp/p2m-main5-publish-finish-v33-20261116/root_entry.py deliver --module LeftHandSide --delivery-directory /absolute/path/LeftHandSide
```

`collect-scope` 和 `bind_ready` 均可重复指定 `--published-readback /absolute/path/earlier-published-item.json`，只采用真实 definition_id 并校验完整父源码读回。`root_entry.py reconcile` 另需 `--job-id ORIGINAL_JOB_ID`。

复用 v31 已冻结 one-Definition publisher，逐字复制，无新数学门。既有12门绑定已验收的真实173 named + private3/176 dossier（固定 SHA8921a39...）、五模块当前源码 leaf/artifact、Initial ProductionGatesV2 和 production pins、root真实 gitdiff、实际私有scope和依赖读回。生产receipt只覆盖原ProductionGatesV2；不声称主项目全量完成。

完整五源码和payload code不改；27条 en/zh-Hans/ja、formal parameter context和18条Mochizuki quotations均原文进入发布自然语言字段，保留论文上下文分离。packet=分量积包；shell region=壳区域。

离线验证：`offline-current-evidence.json` 记录全部五份当前source对应leaf/artifact；`offline-left-binding-result.json` 是用root已保存的真实Local/Basic scope、真实gitdiff和registry28完成的Left绑定及原publisher.check通过回执。没有CI、编译、API或Git调用。此处 `actual-left-bound-offline-v5/` 只是离线绑定检查，不是发布journal。root运行上述总入口会收集新scope并生成正式包。

proof字段语义已明确写入每包profile/packet：`proof=0`只计named以外的本模块proof-only resolution roots，dossier真实计数为0。173 named内已有59个theorem-kind声明、61个命题值记录；逐模块为8/8、8/8、3/3、25/27、15/15，完整名字列表见`named-proof-inventory.json`。Log另有source-mapped private3，原Name→目标Name及实际审查pin写入`sourceMappedPrivateProofs`，不算target-only helpers。完整说明和上游四proof-only roots证据见`proof-count-semantics.json`。上游四个名字为`Iut.OrbicurveDataSection.XK._proof_1`、`Iut.curveK._proof_1`、`Iut.galK._proof_1`、`Iut.galK._proof_2`，属于已验收Orbicurve1+Tate3，未纳入main5 own proof计数。原publisher不改、12门不增、数学不重审。
