#!/usr/bin/env python3
"""Bind accepted main5 evidence to the unchanged one-Definition protocol. No CI/API/Git."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace'); A=W/'.local/adaptation'
V28=A/'main5-private-publication-rebind-v28-20261116'
B=A/'reference-main-bound-carriers-20261115'
REGISTRY=A/'platform-node-registry.json'
DOSSIER=A/'main5-local-dossier-v27-20261116/main5-local-source-relative-dossier.json'
DOSSIER_SHA='8921a39bb3955c4b87ddec4fd24f15a1571b5b5632ddb5a08cdf2cff7445243d'
PRODUCTION=A/'reference-initial-theta-carriers-20261115/production-gates-v2-result.json'
PRODUCTION_REUSE=Path('/tmp/p2m-local-basic-ready-bind-v31-20261116/Basic-production-gate-reuse.json')
MODULES=['LeftHandSide','RightHandSide','Statement','Invariants','LogVolumeBound']
PREFIXES=['Iut.Cor312.']*3+['Iut.Implication.']*2
MODULE_MAP=dict(zip(MODULES,[p+m for p,m in zip(PREFIXES,MODULES)]))
LEAF_NAMES=['candidate-left-leaf-v1','candidate-right-leaf-v1','candidate-statement-leaf-v1','invariants-structure-priority-native-leaf-v24','log-volume-after-invariants-priority-leaf-v16']
ARTIFACT_NAMES=['candidate-left-artifact-v1','candidate-right-artifact-v1','candidate-statement-artifact-v1','invariants-structure-priority-native-artifact-v24','log-volume-dependent-artifact-structure-priority-v24']
ENV='0df444a360eaa60ab8c11dca51a86af692955474';MISSION='eeb5193f-68c0-41d0-9263-4a5ff7c801ee';ROOT='e33ff731-60a7-43ef-87ae-c12aeba23cb5';CREATOR='89966734-f388-427a-9ea1-983923ff28a1'

def need(v,m):
 if not v:raise ValueError(m)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):return {'path':str(Path(p).resolve()),'sha256':sha(p)}
def checked(x):
 need(sha(x['path'])==x['sha256'],'Pinned evidence changed: '+x['path']);return Path(x['path'])
def save(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def load_module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def language_values(value):
 if isinstance(value,str):return [value]
 if isinstance(value,dict):return [text for child in value.values() for text in language_values(child)]
 if isinstance(value,list):return [text for child in value for text in language_values(child)]
 return []

def foundation(module,registry=REGISTRY,published_readbacks=()):
 plan=read(V28/'private-publication-rebinding-plan.json'); row=next(r for r in plan['packages'] if r['module']==MODULE_MAP[module]);meta=read(checked(row['metadata'])); raw=read(checked(row['payload']))
 source=checked(meta['currentActualSource']);need(raw=={'definition_name':row['definition_name'],'code':source.read_text()},'Complete payload source differs')
 bundle=read(checked(meta['frozenTrilingualAndMochizukiBundle']))
 selected=next(r['selectedNamed'] for r in read(DOSSIER)['moduleReceipts'] if r['sourceModule']==row['module'])
 coverage={'source':selected,'resolved':selected,'named':selected,'proof':0,'standard_proof':0,'source_proof_standalone_aliases':0}
 profile={'requiredKernelCoverage':coverage,'requiredOwnedCount':selected+(3 if module=='LogVolumeBound' else 0),'coverageScope':'Selected source declarations only; audited extra private3 belong to LogVolumeBound', 'module':row['module'],'definitionName':row['definition_name'],'target':str(source.relative_to(W)),'sourceSha256':sha(source),'directImportedDefinitions':[r['definition_name'] for r in meta['actualDependencyRows']]}
 # Every language body is included literally, with declaration identity retained.
 rb={lang:'\n\n'.join(d['declaration']+'\n'+d['formal_readback'][lang] for d in bundle['declarations']) for lang in ['en','zh-Hans','ja']}
 context='\n\n'.join(language_values(bundle['formal_contexts']))
 paper=bundle['paper_source_context']['paper_source_context']['publication_markdown']
 statement='\n\n'.join(['**Formal-code readback (English)**',rb['en'],'**形式代码读回（简体中文）**',rb['zh-Hans'],'**形式コードの読解（日本語）**',rb['ja'],'**Frozen formal parameter context**',context,'**Paper source context (separate from formal-code readback)**',paper])
 payload={'definition_name':row['definition_name'],'definition_title':row['module'],'definition':raw['code'],'natural_language_statement':statement,'source':'https://github.com/lana-agents/iut/blob/07cb1da58f6d428a670dbb5dd6093d428bcbcdd8/'+row['module'].replace('.','/')+'.lean','env':ENV,'private':True}
 definitions=read(registry)['reference_source_preparation']['definitions'];ids={r['name']:r['id'] for r in definitions};need(len(ids)==len(definitions),'Duplicate registry names')
 supplied={}
 for p in published_readbacks:
  item=read(p);name=item['definition_name'];need(name not in supplied,'Duplicate supplied parent readbacks');supplied[name]=(item,Path(p))
 parents=[]
 for dep in meta['actualDependencyRows']:
  name=dep['definition_name'];id=ids.get(name);evidence={'registry':pin(registry)}
  if name in supplied:
   item,path=supplied[name];need(not id or id==item['definition_id'],'Registry/readback parent ID conflict');id=item['definition_id'];evidence['publishedReadback']=pin(path)
  current=W/'Definitions'/('Def_'+name+'.lean')
  parents.append({'definitionName':name,'registryEvidence':{'name':name,'id':id,'status':'PUBLISHED' if id else 'pending real publication ID'},'currentDefinition':pin(current),'savedPublicationEvidence':evidence})
 proof_scope=read(HERE/'proof-count-semantics.json'); named_proofs=read(HERE/'named-proof-inventory.json')[row['module']]
 need(named_proofs['named']==selected and named_proofs['genuineOwnSourceProofValues']==[] and proof_scope['main5OwnExtraProofOnlyResolutionCount']==0,'Accepted proof scope differs')
 checked(named_proofs['moduleReport'])
 private_proofs=proof_scope['sourceMappedPrivateProofs'] if module=='LogVolumeBound' else []
 profile.update(proofCountMeaning=proof_scope['proofCountMeaning'],targetOnlyHelpersMeaning=proof_scope['targetOnlyHelpersMeaning'],namedTheoremOriginalNames=named_proofs['namedTheoremOriginalNames'],namedPropositionOriginalNames=named_proofs['namedPropositionOriginalNames'],sourceMappedPrivateProofs=private_proofs,proofInventoryEvidence=pin(HERE/'named-proof-inventory.json'),proofCountSemanticsEvidence=pin(HERE/'proof-count-semantics.json'))
 packet={'kernel_coverage':coverage,'required_owned_count':profile['requiredOwnedCount'],'target_only_compiler_helpers':[],'visibility':'private','module_scope':{'scopeAllFourModules':False,'scopeAll200':False,'scope':'Selected module LOCAL SOURCE-relative only'},'source_proof_values':[],'source_proof_standalone_aliases':[],'pending_parent_bindings':[r['definitionName'] for r in parents if not r['registryEvidence']['id']],'schema':'main5-existing-one-definition-private-delivery-v33','workspace':str(W),'mission_id':MISSION,'root_id':ROOT,'environment':ENV,'scope':'detached-source-consumer-preparation-for-existing-private-mission','root_graph_membership':False,'canonicalC22Connected':False,'source_sha256':{profile['target']:sha(source)},'metadata_sha256':{},'parent_foundation_definitions':parents,'publications':[{'tag':row['definition_name'],'endpoint':'/submit-definition','payload':payload}],'verification':[],'publication_post_limit':1,'publicationReady':False,'all200FormalAccepted':False}
 packet.update(proof_count_meaning=proof_scope['proofCountMeaning'],named_theorem_original_names=named_proofs['namedTheoremOriginalNames'],named_proposition_original_names=named_proofs['namedPropositionOriginalNames'],sourceMappedPrivateProofs=private_proofs,sourceMappedPrivateProofEvidence=proof_scope['sourceMappedPrivateProofEvidence'] if private_proofs else None,upstreamProofOnlyRootsNotMain5Own=proof_scope['upstreamProofOnlyRootsNotMain5Own'],proofInventoryEvidence=pin(HERE/'named-proof-inventory.json'),proofCountSemanticsEvidence=pin(HERE/'proof-count-semantics.json'))
 return profile,packet,rb,bundle,meta

def accepted_receipt(path):
 r=read(path);need(r['status']=='succeeded' and r['result']['exit_code']==0,'Non-successful receipt: '+str(path));return r

def accepted_evidence(module):
 need(sha(DOSSIER)==DOSSIER_SHA,'Use the exact accepted main5 dossier');d=read(DOSSIER)
 need(d['currentSelected173LocalSourceEvidenceComplete'] and d['selectedNamedCount']==173 and d['selectedPlusPrivateCount']==176 and d['ownedInventory']['freshCurrentInventoryConfirmed'],'Actual main5 coverage changed')
 # Validate pins of the already accepted five full mathematical reports. Do not rerun a proof check.
 pins=[DOSSIER]; math=[]
 for row in d['moduleReceipts']+[d['private3Evidence']]:
  for key in ['receipt','query','configuration','innerReport']:pins.append(checked(row[key]))
  accepted_receipt(row['receipt']['path']);math.append(row['receipt']['path'])
 for key in ['actualFacts','actualReceipt']:
  pins.append(checked(d['ownedInventory'][key]))
 accepted_receipt(d['ownedInventory']['actualReceipt']['path']);math.append(d['ownedInventory']['actualReceipt']['path'])
 for row in d['currentFiveNativeInputs']:
  pins.extend([checked(row['source']),checked(row['currentArtifact'])])
 profile,_,_,_,_=foundation(module)
 i=MODULES.index(module);leaf=B/(LEAF_NAMES[i]+'-result.json');artifact=B/(ARTIFACT_NAMES[i]+'-result.json')
 for path in [leaf,artifact]:
  r=accepted_receipt(path);q=r['request'];args=q['parameters'].get('args',[q['parameters'].get('source')]);need(args[0]==profile['target'] and q['worktree_manifest']['source_sha256']==profile['sourceSha256'],'Native receipt source SHA differs: '+str(path));pins.append(path)
  need(q['workspace']==str(W) and q['exclusive'] is True,'Native receipt workspace differs')
 reuse=read(PRODUCTION_REUSE);pins.extend([PRODUCTION_REUSE,checked(reuse['productionReceipt'])]);accepted_receipt(PRODUCTION)
 for p in reuse['productionPinnedInputs']:
  need(p['sha256']==p['expectedFromReceipt'],'Production pin differs');pins.append(checked(p))
 return d,pins,math,leaf,artifact

def bind(module,git_diff_check,scope_directory,out,registry=REGISTRY,published_readbacks=()):
 out=Path(out);scope_directory=Path(scope_directory);need(not out.exists(),'Output already exists; keep the original delivery journal')
 profile,packet,rb,bundle,meta=foundation(module,registry,published_readbacks)
 need(all(p['registryEvidence']['id'] for p in packet['parent_foundation_definitions']),'A real direct parent ID is pending')
 d,pins,math,leaf,artifact=accepted_evidence(module)
 listing_path=scope_directory/'mission-list-readback.json';root_path=scope_directory/'mission-root-readback.json';listing,root=read(listing_path),read(root_path)
 matches=[m for m in listing['missions'] if m['id']==MISSION];need(len(matches)==1,'Existing mission missing or duplicated');mission=matches[0]
 need(mission['visibility']=='private' and mission['creator']['id']==CREATOR and mission['main_theorem']['theorem_id']==ROOT and root['visibility']=='private' and root['mathlib_rev']==ENV,'Existing private mission scope differs')
 scope_paths=[listing_path,root_path]
 for parent in packet['parent_foundation_definitions']:
  p=scope_directory/('parent-'+parent['definitionName']+'.json');item=read(p)
  need(item['definition_id']==parent['registryEvidence']['id'] and item['definition_name']==parent['definitionName'] and item['visibility']=='private' and item['mathlib_rev']==ENV and item['deprecated_at'] is None,'Direct published parent scope differs')
  need(hashlib.sha256(item['definition'].encode()).hexdigest()==parent['currentDefinition']['sha256'],'Direct published parent complete source differs');parent['savedPublicationEvidence']['publishedReadback']=pin(p);scope_paths.append(p);pins.append(checked(parent['currentDefinition']))
 diff=read(git_diff_check);need(diff.get('passed') is True or diff.get('exit_code')==0,'Actual root git diff check has not passed')
 out.mkdir(parents=True)
 shutil.copyfile(HERE/'publisher-template.py',out/'publisher.py');shutil.copyfile(meta['copiedCompleteDefinitionSource']['path'],out/'Definition.lean')
 save(out/'module-profile.json',profile);save(out/'payload.json',packet['publications'][0]['payload']);save(out/'readback.json',rb);save(out/'frozen-bundle.json',bundle)
 # The trace carries all 27 frozen texts, source correspondence, original consumers, and Mochizuki attribution.
 ledger={'schema':'main5-existing-source-ledger-delivery-binding-v33','module':profile['module'],'actualDossier':pin(DOSSIER),'frozen27Trace':pin(V28/'readback27-current-source-trace.json'),'moduleProof':next(r for r in d['moduleReceipts'] if r['sourceModule']==profile['module']),'namedCorrespondence':{n:r for n,r in d['selectedNamedRecords'].items() if r['module']==profile['module']},'consumerSourceLedger':pin(A/'reference-initial-theta-carriers-20261115/SOURCE_LEDGER.json'),'scope':'Accepted LOCAL SOURCE-relative correspondence and existing source consumers; publication binding only'}
 save(out/'source-ledger.final.json',ledger)
 review={'schema':'main5-final-frozen-delivery-binding-v33','passed':True,'actualDossier':pin(DOSSIER),'sourceSha256':profile['sourceSha256'],'frozen27ReadbackAnd18QuotationBodiesUnchanged':True,'scope':'Existing final_frozen_review binding; no new mathematical review','canonicalC22Connected':False,'all200FormalAccepted':False};save(out/'final-frozen-review.json',review)
 pins += [HERE/'named-proof-inventory.json',HERE/'proof-count-semantics.json']
 for upstream in read(HERE/'proof-count-semantics.json')['upstreamProofOnlyRootsNotMain5Own']:
  pins.append(checked(upstream['acceptedUpstreamDossier']))
 pins += [Path(registry),Path(git_diff_check),Path(__file__),HERE/'publisher-template.py',V28/'readback27-current-source-trace.json',V28/'frozen-inputs.json',V28/'private-publication-rebinding-plan.json',A/'reference-initial-theta-carriers-20261115/SOURCE_LEDGER.json']+scope_paths
 for entry in read(V28/'frozen-inputs.json')['files']:
  pins.append(checked(entry['frozen']))
 pins += [checked(meta[k]) for k in ['payload','currentActualSource','copiedCompleteDefinitionSource','legacyExistingPayload','sourceDelta','frozenTrilingualAndMochizukiBundle']]
 pins += list((V28/'frozen-bundles').glob('*.json'))
 pins += [out/f for f in ['publisher.py','Definition.lean','module-profile.json','payload.json','readback.json','frozen-bundle.json','source-ledger.final.json','final-frozen-review.json']]
 hashes={str(p.resolve()):sha(p) for p in pins}
 packet.update(metadata_sha256=hashes,publicationReady=True,actual_kernel_evidence=pin(DOSSIER),actual_leaf_results=d['moduleReceipts'],actual_global_closure_result=d['ownedInventory'],actual_dependency_ids=[p['registryEvidence']['id'] for p in packet['parent_foundation_definitions']]);save(out/'packet.json',packet)
 publisher=load_module('original_one_definition_'+module,out/'publisher.py')
 ci={'new_leaf_modules':[str(leaf)],'new_leaf_artifacts':[str(artifact)],'checks_axioms':math,'wrapped_kernel_type_identity':math,'import_audit':[str(PRODUCTION)],'act1scene1':[str(PRODUCTION)],'axiom_audit':[str(PRODUCTION)]+math}
 ready={'kernel_coverage':profile['requiredKernelCoverage'],'schema':'main5-existing-twelve-gates-ready-v33','passed':True,'packet_sha256':sha(out/'packet.json'),'source_sha256':packet['source_sha256'],'gates':{g:True for g in publisher.GATES},'ci_receipts':ci,'evidence_sha256':hashes,'axiom_audit':{'sorryAx_found':False,'unexpected_axioms':[],'scope':'Existing actual main5 named/private closure reports and accepted ProductionGatesV2 audit'},'gate_evidence':{'independent_readbacks':[str(V28/'readback27-current-source-trace.json')],'source_ledger_consumers':[str(out/'source-ledger.final.json')],'git_diff_check':[str(git_diff_check)],'existing_mission_scope':[str(p) for p in scope_paths],'final_frozen_review':[str(out/'final-frozen-review.json')]},'pending':[],'pending_bindings':{},'all200FormalAccepted':False,'note':'Bind accepted main5 evidence and existing twelve delivery gates only; no new proof obligation.'};save(out/'ready.final.json',ready)
 publisher.check(out/'packet.json',out/'ready.final.json')
 return {'packet':pin(out/'packet.json'),'ready':pin(out/'ready.final.json'),'publicationPOSTPerformed':False}

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--module',choices=MODULES,required=True);p.add_argument('--git-diff-check',type=Path,required=True);p.add_argument('--scope-directory',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--registry',type=Path,default=REGISTRY);p.add_argument('--published-readback',type=Path,action='append',default=[]);a=p.parse_args();print(json.dumps(bind(a.module,a.git_diff_check,a.scope_directory,a.out,a.registry,a.published_readback),ensure_ascii=False,indent=2))
