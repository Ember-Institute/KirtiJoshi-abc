#!/usr/bin/env python3
"""Metadata only: reuse five existing payload drafts, freeze27 readbacks, bind current actual source. Never publish."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,shutil,difflib
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';B=A/'reference-main-bound-carriers-20261115';G=B/'candidate-tools-v8/candidate-draft/generated-wrapped';R=A/'platform-node-registry.json'
def load(p):return json.loads(p.read_text())
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(p.read_bytes())
def pin(p):return {'path':str(p),'sha256':sha(p)}
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def freeze(p,rel=None):
 q=D/'frozen'/((rel or p.name));q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);assert q.read_bytes()==p.read_bytes();return {'original':pin(p),'frozen':pin(q)}
basicDossier=A/'reference-initial-theta-carriers-20261115/basic34-math-dossier-v27/final-kernel-dossier.json'
basic=load(basicDossier);assert basic['all34NamedMathGatesPassed'] and not basic['publicationReady']
registry=load(R);registryRows=registry['reference_source_preparation']['definitions'];ids={r['name']:r['id']for r in registryRows};assert len(ids)==len(registryRows)
trifile=B/'trilingual-readbacks.json';paperfile=B/'paper-readback-join-candidate.json';tri=load(trifile);paper=load(paperfile);wrapper=load(G/'candidate-wrapper-report.json')
assert tri['declaration_count']==27 and tri['bundle_count']==5 and len(tri['declarations'])==27 and paper['quotation_count']==18
ra=load(B/'blind-readbacks-a-original.json');rb=load(B/'blind-readbacks-b-original.json');english={**ra['declaration_readbacks'],**rb['readbacks']};assert len(english)==27
for d in tri['declarations']:
 assert d['formal_readback']['en']==english[d['declaration']]
 assert digest(d['formal_readback']['en'].encode())==d['english_text_sha256']
 assert set(d['formal_readback'])=={'en','zh-Hans','ja'}
confA=load(B/'readback-types-confirmation-a.json');confB=load(B/'readback-types-confirmation-b.json');assert confA['result']=='unchanged'and confB['status']=='unchanged'
confirmed=set(confA['declarations_checked'])|set(confB['declarations_checked']);assert confirmed==set(english)
localfile=A/'main5-local-dossier-v27-20261116/main5-local-source-relative-dossier.json';local=load(localfile)
assert local['selectedNamedCount']==173 and local['independentlyCheckedPrivateCount']==3 and local['selectedPlusPrivateCount']==176
assert local['currentSelected173LocalSourceEvidenceComplete']and local['ownedInventory']['freshCurrentInventoryConfirmed']and not local['platformAccepted']
actualowned=A/'main5-local-dossier-v27-20261116/actual-current-selected173-owned176.json';owned=load(actualowned);assert owned['ownedDeclarationCount']==176 and owned['selectedSourceDeclarationCount']==173
freshreceipt=B/'main5-current-source-owned176-facts-v27-result.json';receipt=load(freshreceipt);assert receipt['job_id']=='ci-017117-e744b85b'and receipt['status']=='succeeded'and receipt['result']['exit_code']==0
frozen=[]
for p in [trifile,paperfile,B/'blind-readbacks-a-original.json',B/'blind-readbacks-b-original.json',B/'readback-types-confirmation-a.json',B/'readback-types-confirmation-b.json',B/'readback-compiler-types.txt',B/'paper-materials-v1/paper-context.json']:
 frozen.append(freeze(p))
for b in wrapper['bundles']:frozen.append(freeze(Path(b['blindReadback']['path']),'blind/'+Path(b['blindReadback']['path']).name))
for p in [Path('/tmp/p2m-main-bound-trilingual-v8-20261115/user-confirmed-terminology-20261116.json')]:
 if p.exists():frozen.append(freeze(p))
moduleEvidence={r['sourceModule']:r for r in local['moduleReceipts']};mainNames={b['definitionName']for b in wrapper['bundles']};pendingPriorNames={'AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions','AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic'}
packages=[];trace=[];allMissingPrior=set()
for b in wrapper['bundles']:
 name=b['definitionName'];module=b['module'];source=W/'Definitions'/('Def_'+name+'.lean');code=source.read_text();legacy=Path(b['payload']);oldpayload=load(legacy);assert oldpayload['definition_name']==name
 oldcode=oldpayload['code'];delta=''.join(difflib.unified_diff(oldcode.splitlines(True),code.splitlines(True),fromfile='candidate-v8/'+name+'.lean',tofile='current/'+name+'.lean'))
 if name.endswith('_Invariants'):
  assert sha(source)=='621ad6f27db0a06be5b4746e156b99bb14e1978e2238bf21fce2007d21a27c38'
  token='section\n\nattribute [local instance 1000] AddSubmonoidClass.toAddCommMonoid\n\n';assert code.count(token)==2
  restored=code.replace(token,'').replace('\nend\n\nnamespace Corollary312VariantData','\nnamespace Corollary312VariantData',1).replace('\nend\n\n/-- `log(q_{v_ℚ})`','\n/-- `log(q_{v_ℚ})`',1)
  assert restored==oldcode;deltaScope='Only two anonymous declaration-local sections restoring source instance priority1000 around Theorem110Invariants structure and dmod; all original declarations/fields/bodies retained.'
 elif name.endswith('_LogVolumeBound'):
  assert sha(source)=='50d3b71d6a3838c85bf7a33624f80cfc6bd97d9e68027158f74cf4437c6be350'
  token='attribute [local simp] dstPlaces.eq_1 placeBound.eq_1 placeBound.eq_2\n\n';assert code.count(token)==1 and code.replace(token,'')==oldcode
  deltaScope='Only declaration-local materialization of the three original compiler equation theorems; original declarations/fields/bodies retained.'
 else:assert code==oldcode;deltaScope='Current complete source is byte-identical to existing candidate-v8 payload code.'
 sourceCopy=D/'Definitions'/source.name;sourceCopy.parent.mkdir(exist_ok=True);shutil.copyfile(source,sourceCopy);assert sourceCopy.read_bytes()==source.read_bytes()
 diffpath=D/'source-deltas'/(name+'.patch');diffpath.parent.mkdir(exist_ok=True);diffpath.write_text(delta)
 payload=D/'payloads'/(name+'.json');save(payload,{'definition_name':name,'code':code});assert load(payload)['code']==source.read_text()
 bundleRead=[d for d in tri['declarations']if d['bundle_module']==module];paperBundle=next(z for z in paper['bundles']if z['bundle_module']==module)
 frozenBundle=D/'frozen-bundles'/(name+'.json');save(frozenBundle,{'bundle_module':module,'declarations':bundleRead,'formal_contexts':tri['formal_contexts'],'paper_source_context':paperBundle,'readbackBodyUnchanged':True,'paperContextBodyUnchanged':True})
 deps=[];resolved=[]
 for imported in b['platformImports']:
  if not imported.startswith('Definitions.Def_'):continue
  dependencyName=imported.removeprefix('Definitions.Def_');id=ids.get(dependencyName)
  if id:
   status='actual-private-platform-id-from-registry';resolved.append(id)
  elif dependencyName in mainNames:status='same-five-package-id-pending-earlier-private-publication'
  else:
   assert dependencyName in pendingPriorNames,(name,dependencyName);status='Local-or-Basic-upstream-platform-id-pending';allMissingPrior.add(dependencyName)
  deps.append({'module':imported,'definition_name':dependencyName,'platform_definition_id':id,'status':status,'idEvidence':pin(R)if id else None,'placeholderPlatformIdCreated':False})
 for d in bundleRead:
  original=d['declaration'].removeprefix('AbcAdaptation.Reference.');exact=local['selectedNamedRecords'][original];assert exact['module']==module
  trace.append({'declaration':d['declaration'],'sourceOriginalName':original,'sourceModule':module,'currentCompleteSource':pin(source),'frozenOriginalBlindSource':b['blindReadback'],
   'unchangedFormalReadback':{'file':pin(trifile),'jsonSelector':{'declaration':d['declaration']},'frozenFormalReadbackObjectSha256':digest(canonical(d['formal_readback'])),'englishTextSha256':d['english_text_sha256'],'reader':d['reader']},
   'historicalActualTypeConfirmation':pin(B/('readback-types-confirmation-a.json'if d['reader']=='a'else'readback-types-confirmation-b.json')),
   'currentActualSourceFullTypeCorrespondence':{'moduleReceipt':moduleEvidence[module],'sourceDAG':exact['sourceView'],'sameSelectedDeclarationNameAndFullTypeRequired':True},
   'readbackNotRewrittenForSourceControlDelta':True,'typeEvidenceDoesNotAssertNewBlindReadbackOccurred':True,
   'MochizukiContext':{'frozenJoin':pin(paperfile),'bundle':module,'contextSeparationPreserved':True,'newPaperAuditPerformed':False}})
 metadata={'schema':'main5-private-publication-metadata-rebinding/v1','definition_name':name,'module':module,'visibility':'private','payload':pin(payload),'currentActualSource':pin(source),'copiedCompleteDefinitionSource':pin(sourceCopy),'legacyExistingPayload':pin(legacy),'legacyCodeSha256':digest(oldcode.encode()),'sourceDelta':pin(diffpath),'sourceDeltaScope':deltaScope,
  'frozenTrilingualAndMochizukiBundle':pin(frozenBundle),'frozenReadbackDeclarations':len(bundleRead),'frozenReadbackNames':[d['declaration']for d in bundleRead],
  'frozenTextPolicy':'Original en/zh-Hans/ja and formal contexts are preserved without editing; packet=分量积包, shell region=壳区域.',
  'MochizukiContextAttribution':'Existing18 quotations/5bundle contextual source evidence is retained; no new PDF audit and no promotion to formal premise.',
  'actual_dependencies':None,'resolved_dependency_ids':resolved,'actualDependencyRows':deps,'dependencyIdBindingComplete':all(r['platform_definition_id']is not None for r in deps),
  'dependencyBindingNote':'Only actual registry IDs are recorded. Local/Basic nulls remain pending. Internal five-package dependencies receive actual IDs only after earlier private definitions return real IDs; module names are never IDs.',
  'localSourceRelativeEvidence':{'dossier':pin(localfile),'moduleProof':moduleEvidence[module],'173namedPlusPrivate3':True,'freshOwned176Job':receipt['job_id']},
  'formalAcceptanceScope':'LOCAL SOURCE-relative; platform acceptance not claimed','publishReady':False,'publishAllowed':False,'platformAccepted':False,'finalAcceptance':False,'apiCalled':False}
 if metadata['dependencyIdBindingComplete']:metadata['actual_dependencies']=[r['platform_definition_id']for r in deps]
 mp=D/'metadata'/(name+'.json');save(mp,metadata);packages.append({'definition_name':name,'module':module,'payload':pin(payload),'metadata':pin(mp),'actualSourceSha256':sha(source),'readbacks':len(bundleRead),'missingUpstreamIds':[r['definition_name']for r in deps if r['status']=='Local-or-Basic-upstream-platform-id-pending'],'pendingInternalPackageIds':[r['definition_name']for r in deps if r['status']=='same-five-package-id-pending-earlier-private-publication'],'publishReady':False})
assert len(trace)==27 and len(packages)==5 and allMissingPrior<=pendingPriorNames
save(D/'readback27-current-source-trace.json',{'schema':'main5-frozen27-readback-current-actual-source-trace/v1','entries':trace,'count':27,'allOriginalReadbackBodiesPreserved':True,'newIndependentReadbackPerformed':False,'newMathematicalCheckPerformed':False,'localSourceDossier':pin(localfile),'publishReady':False})
save(D/'frozen-inputs.json',{'files':frozen,'allCopiesByteIdentical':True,'originalThreeLanguageReadbackCount':27,'MochizukiQuotationCount':18,'MochizukiBundleCount':5,'paperAuditAttributionUnchanged':True})
save(D/'private-publication-rebinding-plan.json',{'schema':'main5-five-existing-private-drafts-minimal-rebind-plan/v1','originalWrapperReport':pin(G/'candidate-wrapper-report.json'),'registrySnapshot':pin(R),'existingRegistryDefinitionCount':len(registryRows),'packages':packages,
 'publishedMain5IdsInvented':False,'BasicLocalMathEvidence':pin(basicDossier),'Basic34LocalMathComplete':True,'BasicPlatformIdStillPending':ids.get('AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic')is None,'pendingUpstreamPlatformDefinitionNames':sorted(allMissingPrior),'pendingUpstreamPlatformIds':{n:None for n in sorted(allMissingPrior)},'LocalAndBasicActualIdBindings':{n:ids.get(n)for n in sorted(pendingPriorNames)},
 'publicationOrder':['AbcAdaptation_Reference_Iut_Cor312_LeftHandSide','AbcAdaptation_Reference_Iut_Cor312_RightHandSide','AbcAdaptation_Reference_Iut_Cor312_Statement','AbcAdaptation_Reference_Iut_Implication_Invariants','AbcAdaptation_Reference_Iut_Implication_LogVolumeBound'],
 'nextMetadataStep':'After Local/Basic actual IDs enter the existing registry, rerun this same offline script to rebind exact IDs. Five-package internal dependencies are rebound after actual earlier package IDs exist. Script never sends API or opens publishReady.',
 'readback27Trace':pin(D/'readback27-current-source-trace.json'),'frozenInputs':pin(D/'frozen-inputs.json'),'sourceMapOrStatementsChanged':False,'readbackBodyChanged':False,'platformGate':'pending actual dependency IDs and existing platform publication flow; no new mathematics/checks introduced.',
 'compilerRun':False,'CIInvoked':False,'APIInvoked':False,'GitInvoked':False,'mainWorkspaceWritten':False,'metadataOnly':True,'visibility':'private','publishReady':False,'publishAllowed':False,'platformAccepted':False,'finalAcceptance':False})
print(json.dumps({'directory':str(D),'packages':len(packages),'readbacks':len(trace),'registryDefinitions':len(registryRows),'pendingLocalAndBasic':sorted(allMissingPrior),'publishReady':False},ensure_ascii=False,indent=2))
