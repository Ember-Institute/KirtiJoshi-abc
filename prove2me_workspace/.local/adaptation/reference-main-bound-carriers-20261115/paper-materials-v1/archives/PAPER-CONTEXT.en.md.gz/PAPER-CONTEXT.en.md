# Paper source context: main-bound carriers

Original Mochizuki paper background for exactly five bundles and 27 complete parser-selected source commands. This is author/source context, not a formal type readback or independent blind audit.

27 full source commands, grouped 5/3/2/13/4. Their 173 selected original compiler declarations include generated support items. No new compilation, adapted kernel acceptance, paper identity, or platform acceptance is asserted.

## Normalization distinctions

**source-positive-weights.** The source requires positive weights on its finite bad locus. It requires neither a total weight of one nor local-degree formulas.





Arithmetic degree is the intended interpretation. That interpretation is not a law of this record.

**paper-fiber-weights.** The paper fixes one rational place and normalizes products of positive local degrees by their sum over all tuples.

$$w_{\vec e}=\frac{\prod_{i=1}^n\lambda_{e_i}}{\sum_{\vec f\in E^n}\prod_{i=1}^n\lambda_{f_i}},\quad\sum_{\vec e\in E^n}w_{\vec e}=1$$

The sum-to-one equation is an editorial algebraic consequence of the displayed paper weights, not an additional verbatim quotation.

These are fixed-fiber packet weights. They are not supplied or derived by QPilotData.weight_pos.

**global-degree.** Global normalized degree divides the arithmetic degree by [F : Q].





A positive arbitrary QPilotData.weight does not establish this global arithmetic identity.

**fiber-degree.** Normalized E-degree uses the sum of local degrees over a fixed nonempty fiber E. This denominator differs from the global denominator.





logQAt groups source summands by residue characteristic. No selected command proves a conversion to the paper normalized fiber degree.

**q-root-normalization.** The paper distinguishes a local q-parameter from its 2l-th root. IUT IV relates the positive q-pilot quantity to log(q)/(2l).





The source defines absLogQ as logQ/(2ℓ). The name absLogQ does not apply the real absolute-value function.

**negative-q-side.** The q-side is negative: lhs = -logQ/(2ℓ). The theta-side is already the log-volume denoted -|log(Theta)|.





RHSData.rhs takes the procession volume directly. It does not add another minus sign.

**half-order.** The half-order ℓ* = (ℓ-1)/2 counts procession stages. It is distinct from the q-root denominator 2ℓ.





The source uses natural-number subtraction and division. RHSData.proc_standard supplies the standard procession law; it is an input field.

**local-capsule-size.** The paper uses n = j+1 for capsule size. The source coefficient ((n:ℝ)-1)^2/(2ℓ) follows this indexing.





This matching formula does not prove local field estimates, identify arbitrary packet volumes, or establish the fiber normalization bridge.

**prime-bound-factor.** The paper uses 4/3. The source certificate uses 3/2 and requires a threshold greater than one.





The selected command defines a certificate. It does not construct a prime-counting proof or establish that this change suffices downstream.

## Iut.Cor312.LeftHandSide

**Paper source context.** Mochizuki distinguishes local Tate q-parameters from the global q-pilot object. IUT IV expresses the positive q-pilot quantity as log(q)/(2l). The comparison uses its negative. Global arithmetic degree and local fiber degree use different denominators.

**Selected source interface and limits.** This bundle computes the q-side from supplied finite bad-place data and positive weights. It does not construct a q-pilot object. No selected command fixes the weights to local degrees, requires their sum to be one, or proves the arithmetic identity of logQ.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Example 3.2(iv), opening sentence and sentence beginning “Note that”; printed page(s) 71; PDF file page(s) 71. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf.

> Write $q_{\underline v}$ for the $q$-parameter of the elliptic curve $E_{\underline v}$ over $K_{\underline v}$. […] Note that it follows from our assumption concerning $2$-torsion [cf. Definition 3.1, (b)], together with the definition of “$K$” [cf. Definition 3.1, (c)], that $q_{\underline v}$ admits a $2l$-th root […].

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, sentence beginning “Write” after the theta-pilot definition; printed page(s) 174; PDF file page(s) 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> Write
> 
> $$-\lvert\log(\underline{\underline q})\rvert\in\mathbb R$$
> 
> for the procession-normalized mono-analytic log-volume of the image of a $q$-pilot object [cf. Definition 3.8, (i)], relative to the relevant Kummer isomorphisms [cf. Theorem 3.11, (ii)], in the multiradial representation of Theorem 3.11, (i), which we do not regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in Theorem 3.11, (i), (ii).

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Definition 1.9(i), sentence defining normalized degree and pullback equality; printed page(s) 21, 22; PDF file page(s) 21, 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> If $\mathfrak a\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall refer to
> 
> $$\underline{\deg}(\mathfrak a)\overset{\mathrm{def}}{=}\frac{1}{[F:\mathbb Q]}\cdot\deg_F(\mathfrak a)$$
> 
> as the normalized degree of $\mathfrak a$. Thus, for any finite extension $K$ of $F$, we have
> 
> $$\underline{\deg}(\mathfrak a|_K)=\underline{\deg}(\mathfrak a)$$
> 
> — where we write $\underline{\deg}(\mathfrak a|_K)$ for the normalized degree of the pull-back $\mathfrak a|_K\in\operatorname{ADiv}_{\mathbb R}(K)$ [defined in the evident fashion] of $\mathfrak a$ to $K$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Definition 1.9(ii), opening through the definition of normalized E-degree; printed page(s) 22; PDF file page(s) 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Let $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}\overset{\mathrm{def}}{=}\mathbb V(\mathbb Q)$, $E\subseteq\mathbb V(F)$ a nonempty set of elements lying over $v_{\mathbb Q}$. If $\mathfrak a=\sum_{v\in\mathbb V(F)}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall write
> 
> $$\mathfrak a_E\overset{\mathrm{def}}{=}\sum_{v\in E}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F);\qquad\underline{\deg}_E(\mathfrak a)\overset{\mathrm{def}}{=}\frac{\deg(\mathfrak a_E)}{\sum_{v\in E}[F_v:\mathbb Q_{v_{\mathbb Q}}]}$$
> 
> for the portion of $\mathfrak a$ supported in $E$ and the “normalized $E$-degree” of $\mathfrak a$, respectively.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Theorem 1.10 statement, sentence beginning “Here, we observe”; printed page(s) 23; PDF file page(s) 23. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Here, we observe that the various “$\log(q_{(-)})$”’s are independent of the choice of $F_{\square}$, and that the quantity “$\lvert\log(\underline{\underline q})\rvert\in\mathbb R_{>0}$” defined in [IUTchIII], Corollary 3.12, is equal to $\frac{1}{2l}\cdot\log(q)\in\mathbb R$ [cf. the definition of “$\underline q_{\underline v}$” in [IUTchI], Example 3.2, (iv)].

**Actual consumer.** QPilotData and its numerical definitions feed Corollary312VariantData, the comparison definition, and later logQ decomposition.

**Exact selected command coverage.**

- `Iut.QPilotData` (source lines 54–67, parser command 5): Supplies finite bad-place data for the intended arithmetic q-degree. The paper q-pilot object itself is not constructed.
- `Iut.QPilotData.mem_bad` (source lines 73–76, parser command 8): A local bookkeeping lemma connects finite enumeration to the chosen bad locus. It has no separate verbatim paper counterpart.
- `Iut.QPilotData.logQ` (source lines 78–84, parser command 9): The intended arithmetic background is the globally normalized degree of the q-divisor. Arbitrary positive source weights do not establish this identification.
- `Iut.QPilotData.absLogQ` (source lines 86–88, parser command 10): Uses the factor 1/(2ℓ) stated in IUT IV. Its name records a paper quantity, not an application of real absolute value.
- `Iut.QPilotData.lhs` (source lines 90–93, parser command 11): Uses the negative q-pilot side of the comparison. The minus sign is essential.

**All fields of selected structure commands.**

- `Iut.QPilotData`: `badFinset`, `badFinset_spec`, `weight`, `weight_pos`.

Source bytes, exact parser ranges, source provenance, actual consumers, and quotation references are stored in `paper-context.json`.

## Iut.Cor312.RightHandSide

**Paper source context.** Corollary 3.12 starts with the union of possible theta-pilot images under three indeterminacies. It takes a holomorphic hull and its procession-normalized mono-analytic log-volume. The paper defines this value in R ∪ {+∞} before asserting finiteness.

**Selected source interface and limits.** The source supplies the regions, their hull-admissibility, containment in log-shells, and compatibility with the standard procession. The selected commands apply the supplied hull and volume operations. They do not construct the paper multiradial representation. The source returns a real number under its interface assumptions.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, opening through the definition of the theta-pilot log-volume; printed page(s) 173, 174; PDF file page(s) 173, 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> Suppose that we are in the situation of Theorem 3.11. Write
> 
> $$-\lvert\log(\underline{\underline\Theta})\rvert\in\mathbb R\cup\{+\infty\}$$
> 
> for the procession-normalized mono-analytic log-volume [i.e., where the average is taken over $j\in\mathbb F_l^{\circledast}$ — cf. Remark 3.1.1, (ii), (iii), (iv); Proposition 3.9, (i), (ii); Theorem 3.11, (i), (a)] of the holomorphic hull [cf. Remark 3.9.5, (i)] of the union of the possible images of a $\Theta$-pilot object [cf. Definition 3.8, (i)], relative to the relevant Kummer isomorphisms [cf. Theorem 3.11, (ii)], in the multiradial representation of Theorem 3.11, (i), which we regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in Theorem 3.11, (i), (ii).

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, final two sentences; printed page(s) 174; PDF file page(s) 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> In particular, $\lvert\log(\underline{\underline q})\rvert>0$ is easily computed in terms of the various $q$-parameters of the elliptic curve $E_F$ [cf. [IUTchI], Definition 3.1, (b)] at $\underline v\in\underline{\mathbb V}^{\mathrm{bad}}\ (\ne\emptyset)$. Then it holds that $-\lvert\log(\underline{\underline\Theta})\rvert\in\mathbb R$, and
> 
> $$-\lvert\log(\underline{\underline\Theta})\rvert\geq-\lvert\log(\underline{\underline q})\rvert$$
> 
> — i.e., $C_{\Theta}\geq-1$ for any real number $C_{\Theta}\in\mathbb R$ such that $-\lvert\log(\underline{\underline\Theta})\rvert\leq C_{\Theta}\cdot\lvert\log(\underline{\underline q})\rvert$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Remark 1.7.1, paragraph beginning “Thus, in summary”; printed page(s) 18; PDF file page(s) 18. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Thus, in summary, when one works with normalized log-volumes as in Proposition 1.4, (i), the appropriate normalized weights are given by the expressions
> 
> $$\frac{\lambda_{\Pi\vec e^{\dagger}}}{\sum_{\vec e\in E^n}\lambda_{\Pi\vec e}}$$
> 
> [where $\vec e^{\dagger}\in E^n$] that appear in Proposition 1.7. Here, one takes “$E$” to be the set of elements of $\underline{\mathbb V}\xrightarrow{\sim}\mathbb V_{\mathrm{mod}}$ lying over a fixed $v_{\mathbb Q}$; one takes “$n$” to be the cardinality of $A$, so that one can write $A=\{\alpha_1,\ldots,\alpha_n\}$ [where the $\alpha_i$ are distinct]; if $e\in E$ corresponds to $\underline v\in\underline{\mathbb V}$, $v\in\mathbb V_{\mathrm{mod}}$, then one takes
> 
> $$\text{“}\lambda_e\text{”}\overset{\mathrm{def}}{=}[(F_{\mathrm{mod}})_v:\mathbb Q_{v_{\mathbb Q}}]\in\mathbb R_{>0}$$
> 
> and “$\beta_e$” to be a normalized log-volume of some compact open subset of $K_{\underline v}$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iv), opening sentence; printed page(s) 26; PDF file page(s) 26. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> In order to estimate the constant “$C_{\Theta}$” of [IUTchIII], Corollary 3.12, we must, according to the various definitions given in the statement of [IUTchIII], Corollary 3.12, compute an upper bound for the
> 
> procession-normalized mono-analytic log-volume of the holomorphic hull of the union of the possible images of a $\Theta$-pilot object, relative to the relevant Kummer isomorphisms [cf. [IUTchIII], Theorem 3.11, (ii)], in the multiradial representation of [IUTchIII], Theorem 3.11, (i), which we regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in [IUTchIII], Theorem 3.11, (i), (ii).

**Actual consumer.** RHSData and rhs feed the assembled comparison and the later LocalEstimate upper-bound argument.

**Exact selected command coverage.**

- `Iut.RHSData` (source lines 59–94, parser command 7): Organizes the paper sequence: possible theta-pilot images, holomorphic hull, and procession-normalized volume. Regions, containments, admissibility, and compatibility remain supplied fields.
- `Iut.RHSData.thetaHull` (source lines 100–102, parser command 10): Applies the supplied hull operation to the supplied regions. It does not construct the multiradial representation or its images.
- `Iut.RHSData.rhs` (source lines 104–109, parser command 11): Uses procession-normalized volume as the theta-side. The paper initially permits +∞, then asserts finiteness; the source interface returns a real value.

**All fields of selected structure commands.**

- `Iut.RHSData`: `container`, `proc_standard`, `toRational_finite`, `toRational_infinite`, `vol`, `hull`, `thetaPilot`, `thetaPilot_hullAdmissible`, `thetaPilot_le_shell`.

Source bytes, exact parser ranges, source provenance, actual consumers, and quotation references are stored in `paper-context.json`.

## Iut.Cor312.Statement

**Paper source context.** Mochizuki’s Corollary 3.12 compares the theta-side with the negative positive q-pilot quantity. Its inequality is -|log(Theta)| ≥ -|log(q)|. The statement also asserts finiteness and derives a lower bound on every upper-bound coefficient C_Theta.

**Selected source interface and limits.** The source collects supplied inputs and defines lhs ≤ rhs as a proposition. It supplies no proof of this proposition. The source variant does not establish correspondence with the paper construction or reproduce all paper hypotheses. The unselected corollary312Variant_iff is outside this 27-command packet.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, opening through the definition of the theta-pilot log-volume; printed page(s) 173, 174; PDF file page(s) 173, 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> Suppose that we are in the situation of Theorem 3.11. Write
> 
> $$-\lvert\log(\underline{\underline\Theta})\rvert\in\mathbb R\cup\{+\infty\}$$
> 
> for the procession-normalized mono-analytic log-volume [i.e., where the average is taken over $j\in\mathbb F_l^{\circledast}$ — cf. Remark 3.1.1, (ii), (iii), (iv); Proposition 3.9, (i), (ii); Theorem 3.11, (i), (a)] of the holomorphic hull [cf. Remark 3.9.5, (i)] of the union of the possible images of a $\Theta$-pilot object [cf. Definition 3.8, (i)], relative to the relevant Kummer isomorphisms [cf. Theorem 3.11, (ii)], in the multiradial representation of Theorem 3.11, (i), which we regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in Theorem 3.11, (i), (ii).

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, sentence beginning “Write” after the theta-pilot definition; printed page(s) 174; PDF file page(s) 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> Write
> 
> $$-\lvert\log(\underline{\underline q})\rvert\in\mathbb R$$
> 
> for the procession-normalized mono-analytic log-volume of the image of a $q$-pilot object [cf. Definition 3.8, (i)], relative to the relevant Kummer isomorphisms [cf. Theorem 3.11, (ii)], in the multiradial representation of Theorem 3.11, (i), which we do not regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in Theorem 3.11, (i), (ii).

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, final two sentences; printed page(s) 174; PDF file page(s) 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> In particular, $\lvert\log(\underline{\underline q})\rvert>0$ is easily computed in terms of the various $q$-parameters of the elliptic curve $E_F$ [cf. [IUTchI], Definition 3.1, (b)] at $\underline v\in\underline{\mathbb V}^{\mathrm{bad}}\ (\ne\emptyset)$. Then it holds that $-\lvert\log(\underline{\underline\Theta})\rvert\in\mathbb R$, and
> 
> $$-\lvert\log(\underline{\underline\Theta})\rvert\geq-\lvert\log(\underline{\underline q})\rvert$$
> 
> — i.e., $C_{\Theta}\geq-1$ for any real number $C_{\Theta}\in\mathbb R$ such that $-\lvert\log(\underline{\underline\Theta})\rvert\leq C_{\Theta}\cdot\lvert\log(\underline{\underline q})\rvert$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Theorem 1.10 statement, sentence beginning “Here, we observe”; printed page(s) 23; PDF file page(s) 23. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Here, we observe that the various “$\log(q_{(-)})$”’s are independent of the choice of $F_{\square}$, and that the quantity “$\lvert\log(\underline{\underline q})\rvert\in\mathbb R_{>0}$” defined in [IUTchIII], Corollary 3.12, is equal to $\frac{1}{2l}\cdot\log(q)\in\mathbb R$ [cf. the definition of “$\underline q_{\underline v}$” in [IUTchI], Example 3.2, (iv)].

**Actual consumer.** The assembled data and proposition serve later implication theorems. Their names do not provide a proof of the paper Corollary 3.12.

**Exact selected command coverage.**

- `Iut.Corollary312VariantData` (source lines 66–77, parser command 5): Collects the local implementation inputs for the comparison. This record does not establish that those inputs realize the paper objects.
- `Iut.Corollary312Variant` (source lines 81–94, parser command 7): Defines the local comparison with the paper direction: negative q-side ≤ theta-side. The command defines a proposition and supplies no proof.

**All fields of selected structure commands.**

- `Iut.Corollary312VariantData`: `data`, `qPilot`, `rhsData`.

Source bytes, exact parser ranges, source provenance, actual consumers, and quotation references are stored in `paper-context.json`.

## Iut.Implication.Invariants

**Paper source context.** IUT IV turns the theta-pilot estimate into explicit arithmetic bounds. Theorem 1.10 uses the field-of-moduli degree, maximal ramification, a tripodal field, different and conductor degrees. Steps (ii) and (iii) bound these quantities and introduce distinguished primes. Proposition 1.6 supplies prime-counting control.

**Selected source interface and limits.** The source derives dmod from its field of moduli and groups logQ summands as logQAt. Other arithmetic quantities and certificate bounds remain supplied data or hypotheses. PrimeCountingBound uses 3/2, while the paper uses 4/3. The selected bundle constructs no tripodal field, different ideal, ramification locus, prime-counting witness, or Theorem110Certificate witness.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Definition 1.9(i), sentence defining normalized degree and pullback equality; printed page(s) 21, 22; PDF file page(s) 21, 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> If $\mathfrak a\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall refer to
> 
> $$\underline{\deg}(\mathfrak a)\overset{\mathrm{def}}{=}\frac{1}{[F:\mathbb Q]}\cdot\deg_F(\mathfrak a)$$
> 
> as the normalized degree of $\mathfrak a$. Thus, for any finite extension $K$ of $F$, we have
> 
> $$\underline{\deg}(\mathfrak a|_K)=\underline{\deg}(\mathfrak a)$$
> 
> — where we write $\underline{\deg}(\mathfrak a|_K)$ for the normalized degree of the pull-back $\mathfrak a|_K\in\operatorname{ADiv}_{\mathbb R}(K)$ [defined in the evident fashion] of $\mathfrak a$ to $K$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Definition 1.9(ii), opening through the definition of normalized E-degree; printed page(s) 22; PDF file page(s) 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Let $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}\overset{\mathrm{def}}{=}\mathbb V(\mathbb Q)$, $E\subseteq\mathbb V(F)$ a nonempty set of elements lying over $v_{\mathbb Q}$. If $\mathfrak a=\sum_{v\in\mathbb V(F)}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall write
> 
> $$\mathfrak a_E\overset{\mathrm{def}}{=}\sum_{v\in E}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F);\qquad\underline{\deg}_E(\mathfrak a)\overset{\mathrm{def}}{=}\frac{\deg(\mathfrak a_E)}{\sum_{v\in E}[F_v:\mathbb Q_{v_{\mathbb Q}}]}$$
> 
> for the portion of $\mathfrak a$ supported in $E$ and the “normalized $E$-degree” of $\mathfrak a$, respectively.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Proposition 1.6, final sentence; printed page(s) 16; PDF file page(s) 16. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> In particular, there exists a positive real number $\eta_{\mathrm{prm}}$ such that
> 
> $$\sum_{p\leq\eta}1\leq\frac{4\eta}{3\cdot\log(\eta)}$$
> 
> — where the sum ranges over the prime numbers $p\leq\eta$ — for all positive real $\eta\geq\eta_{\mathrm{prm}}$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Theorem 1.10, opening through the definition of the tripodal field; printed page(s) 22; PDF file page(s) 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Fix a collection of initial $\Theta$-data as in [IUTchI], Definition 3.1. Suppose that we are in the situation of [IUTchIII], Corollary 3.12, and that the elliptic curve $E_F$ has good reduction at every valuation $\in\mathbb V(F)^{\mathrm{good}}\cap\mathbb V(F)^{\mathrm{non}}$ that does not divide $2l$. In the notation of [IUTchI], Definition 3.1, let us write $d_{\mathrm{mod}}\overset{\mathrm{def}}{=}[F_{\mathrm{mod}}:\mathbb Q]$, $(1\leq)\ e_{\mathrm{mod}}\ (\leq d_{\mathrm{mod}})$ for the maximal ramification index of $F_{\mathrm{mod}}$ [i.e., of valuations $\in\mathbb V_{\mathrm{mod}}^{\mathrm{non}}$] over $\mathbb Q$, $d_{\mathrm{mod}}^*\overset{\mathrm{def}}{=}2^{12}\cdot3^3\cdot5\cdot d_{\mathrm{mod}}$, $e_{\mathrm{mod}}^*\overset{\mathrm{def}}{=}2^{12}\cdot3^3\cdot5\cdot e_{\mathrm{mod}}\ (\leq d_{\mathrm{mod}}^*)$, and
> 
> $$F_{\mathrm{mod}}\subseteq F_{\mathrm{tpd}}\overset{\mathrm{def}}{=}F_{\mathrm{mod}}(E_{F_{\mathrm{mod}}}[2])\subseteq F$$
> 
> for the “tripodal” intermediate field obtained from $F_{\mathrm{mod}}$ by adjoining the fields of definition of the $2$-torsion points of any model of $E_F\times_F\overline F$ over $F_{\mathrm{mod}}$ [cf. Proposition 1.8, (ii), (iii)].

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iii), first sentence; printed page(s) 24; PDF file page(s) 24. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> If $F_{\mathrm{tpd}}\subseteq F_{\square}\subseteq K$ is any intermediate extension which is Galois over $F_{\mathrm{mod}}$, then we shall write
> 
> $$\mathbb V(F_{\square})^{\mathrm{dst}}\subseteq\mathbb V(F_{\square})^{\mathrm{non}}$$
> 
> for the set of “distinguished” nonarchimedean valuations $v\in\mathbb V(F_{\square})^{\mathrm{non}}$, i.e., $v$ that extend to a valuation $\in\mathbb V(K)^{\mathrm{non}}$ that ramifies over $\mathbb Q$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iii), clause defining iota after the s-divisors; printed page(s) 25; PDF file page(s) 25. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> we set $\iota_{w_{\mathbb Q}}\overset{\mathrm{def}}{=}1$ if $p_{w_{\mathbb Q}}\leq e_{\mathrm{mod}}^*\cdot l$, $\iota_{w_{\mathbb Q}}\overset{\mathrm{def}}{=}0$ if $p_{w_{\mathbb Q}}>e_{\mathrm{mod}}^*\cdot l$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (ii), displayed chain bounding the different of K; printed page(s) 24; PDF file page(s) 24. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> $$\log(\mathfrak d^K)\leq\log(\mathfrak d^K)+\log(\mathfrak f^K)\leq\log(\mathfrak d^F)+\log(\mathfrak f^F)+2\cdot\log(l)$$
> $$\leq\log(\mathfrak d^{F_{\mathrm{tpd}}})+\log(\mathfrak f^{F_{\mathrm{tpd}}})+2\cdot\log(l)+21$$

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iii), sentence beginning “In a similar vein”; printed page(s) 26; PDF file page(s) 26. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> In a similar vein, we conclude that
> 
> $$\log(s^{\mathbb Q})\leq2\cdot d_{\mathrm{mod}}\cdot(\log(\mathfrak d^{F_{\mathrm{tpd}}})+\log(\mathfrak f^{F_{\mathrm{tpd}}}))+\log(2\cdot3\cdot5\cdot l)$$
> $$\leq2\cdot d_{\mathrm{mod}}\cdot(\log(\mathfrak d^{F_{\mathrm{tpd}}})+\log(\mathfrak f^{F_{\mathrm{tpd}}}))+5+\log(l)$$
> 
> and hence that […]

**Actual consumer.** The supplied invariants and certificate feed the later local estimates and theorem110 argument. The selected definitions lstar and logSle have later numerical consumers.

**Exact selected command coverage.**

- `Iut.PrimeCountingBound` (source lines 54–65, parser command 6): Uses the prime-counting estimate as a supplied certificate, with 3/2 in place of the paper factor 4/3.
- `Iut.Theorem110Invariants` (source lines 69–101, parser command 8): Carries numbers intended to represent ramification, different, conductor, and distinguished-prime data. It does not construct these arithmetic objects.
- `Iut.Corollary312VariantData.ℓ` (source lines 107–108, parser command 11): Names the prime from the supplied initial theta-data. It does not supply additional paper hypotheses.
- `Iut.Corollary312VariantData.lstar` (source lines 110–111, parser command 12): Names the half-order (ℓ-1)/2 used for procession stages. This is separate from 1/(2ℓ).
- `Iut.Corollary312VariantData.dmod` (source lines 113–114, parser command 13): Takes the degree of the supplied field of moduli. Its intended paper notation is d_mod.
- `Iut.Corollary312VariantData.logQAt` (source lines 116–121, parser command 14): Groups the source logQ summands by residue characteristic. No selected theorem identifies this contribution with the paper normalized fiber quantity log(q_vQ).
- `Iut.Theorem110Invariants.eStar` (source lines 146–147, parser command 21): Uses the paper factor 2^12·3^3·5 = 552960 on the supplied ramification bound.
- `Iut.Theorem110Invariants.lmod` (source lines 152–153, parser command 23): Names log(eStar·ℓ), the l_mod* used in the local estimates. Its arithmetic meaning depends on the supplied invariant data.
- `Iut.Theorem110Invariants.ι` (source lines 155–156, parser command 24): Records the cutoff at e_mod*·ℓ used in Step (iii). The value is 1 at and below the cutoff.
- `Iut.Theorem110Invariants.logSQ` (source lines 158–160, parser command 25): Sums log p over the supplied distinguished primes, following the rational s-divisor in Step (iii). It does not prove that dst is the ramification locus.
- `Iut.Theorem110Invariants.logSle` (source lines 162–164, parser command 26): Counts supplied distinguished primes at and below the cutoff through the indicator sum. The arithmetic interpretation follows Step (iii).
- `Iut.Theorem110Invariants.logDKtot` (source lines 166–167, parser command 27): Sums supplied different contributions over dst. It does not compute a different ideal or its arithmetic degree.
- `Iut.Theorem110Certificate` (source lines 186–211, parser command 34): Carries ℓ≥7, coverage of bad places, and the Step (ii) and Step (iii) bounds as explicit hypotheses. It proves none of them.

**All fields of selected structure commands.**

- `Iut.PrimeCountingBound`: `η`, `one_lt_η`, `bound`.
- `Iut.Theorem110Invariants`: `emod`, `one_le_emod`, `emod_le_dmod`, `logDtpd`, `logDtpd_nonneg`, `logFtpd`, `logFtpd_nonneg`, `dst`, `dst_prime`, `logDK`, `logDK_nonneg`, `logDK_eq_zero`.
- `Iut.Theorem110Certificate`: `seven_le`, `bad_mem_dst`, `step_ii`, `step_iii`.

Source bytes, exact parser ranges, source provenance, actual consumers, and quotation references are stored in `paper-context.json`.

## Iut.Implication.LogVolumeBound

**Paper source context.** The proof of IUT IV, Theorem 1.10, estimates one rational place and one capsule at a time. Step (v) gives a weighted finite-place bound. Steps (vi) and (vii) give zero away from distinguished primes and (j+1)·log π at infinity. The proof then averages over the half-order procession.

**Selected source interface and limits.** The selected commands define capsuleBound, LocalEstimate, placeBound, and dstPlaces. Local containments, finite and infinite volume estimates, and monotonicity remain fields of LocalEstimate. This packet does not include rhs_le or its proof lemmas. A formula match alone does not identify source packet volumes or grouped q-contributions with the paper quantities.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Definition 1.9(ii), opening through the definition of normalized E-degree; printed page(s) 22; PDF file page(s) 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Let $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}\overset{\mathrm{def}}{=}\mathbb V(\mathbb Q)$, $E\subseteq\mathbb V(F)$ a nonempty set of elements lying over $v_{\mathbb Q}$. If $\mathfrak a=\sum_{v\in\mathbb V(F)}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall write
> 
> $$\mathfrak a_E\overset{\mathrm{def}}{=}\sum_{v\in E}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F);\qquad\underline{\deg}_E(\mathfrak a)\overset{\mathrm{def}}{=}\frac{\deg(\mathfrak a_E)}{\sum_{v\in E}[F_v:\mathbb Q_{v_{\mathbb Q}}]}$$
> 
> for the portion of $\mathfrak a$ supported in $E$ and the “normalized $E$-degree” of $\mathfrak a$, respectively.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Remark 1.7.1, paragraph beginning “Thus, in summary”; printed page(s) 18; PDF file page(s) 18. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Thus, in summary, when one works with normalized log-volumes as in Proposition 1.4, (i), the appropriate normalized weights are given by the expressions
> 
> $$\frac{\lambda_{\Pi\vec e^{\dagger}}}{\sum_{\vec e\in E^n}\lambda_{\Pi\vec e}}$$
> 
> [where $\vec e^{\dagger}\in E^n$] that appear in Proposition 1.7. Here, one takes “$E$” to be the set of elements of $\underline{\mathbb V}\xrightarrow{\sim}\mathbb V_{\mathrm{mod}}$ lying over a fixed $v_{\mathbb Q}$; one takes “$n$” to be the cardinality of $A$, so that one can write $A=\{\alpha_1,\ldots,\alpha_n\}$ [where the $\alpha_i$ are distinct]; if $e\in E$ corresponds to $\underline v\in\underline{\mathbb V}$, $v\in\mathbb V_{\mathrm{mod}}$, then one takes
> 
> $$\text{“}\lambda_e\text{”}\overset{\mathrm{def}}{=}[(F_{\mathrm{mod}})_v:\mathbb Q_{v_{\mathbb Q}}]\in\mathbb R_{>0}$$
> 
> and “$\beta_e$” to be a normalized log-volume of some compact open subset of $K_{\underline v}$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iv), opening sentence; printed page(s) 26; PDF file page(s) 26. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> In order to estimate the constant “$C_{\Theta}$” of [IUTchIII], Corollary 3.12, we must, according to the various definitions given in the statement of [IUTchIII], Corollary 3.12, compute an upper bound for the
> 
> procession-normalized mono-analytic log-volume of the holomorphic hull of the union of the possible images of a $\Theta$-pilot object, relative to the relevant Kummer isomorphisms [cf. [IUTchIII], Theorem 3.11, (ii)], in the multiradial representation of [IUTchIII], Theorem 3.11, (i), which we regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in [IUTchIII], Theorem 3.11, (i), (ii).

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (v), final sentences and display; printed page(s) 28; PDF file page(s) 28. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Here, we note that it follows immediately from the first equality of the first display of Proposition 1.7 that, after passing to weighted averages, the operation of symmetrizing with respect to the choice of “$i^{\dagger}\in I$” in $S_{j+1}^{\pm}$ does not affect the computation of the upper bound under consideration. Thus, by applying Proposition 1.7, we obtain that the resulting “weighted average upper bound” is given by
> 
> $$(j+1)\cdot\log(\mathfrak d^K_{v_{\mathbb Q}})-\frac{j^2}{2l}\cdot\log(q_{v_{\mathbb Q}})+\log(s^{\mathbb Q}_{v_{\mathbb Q}})+4(j+1)\cdot l_{\mathrm{mod}}^*\cdot\log(s^{\leq}_{v_{\mathbb Q}})$$

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (vi), final two sentences; printed page(s) 29; PDF file page(s) 29. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> One may then compute a “weighted average upper bound” and then a “procession-normalized upper bound”, as was done in Step (v). The resulting “procession-normalized upper bound” is clearly equal to $0$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (vii), sentences giving the archimedean bound; printed page(s) 30; PDF file page(s) 30. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Thus, an upper bound on the component of the log-volume under consideration may be obtained by computing an upper bound for the log-volume of this container. Such an upper bound
> 
> $$(j+1)\cdot\log(\pi)$$
> 
> follows immediately from the fact that [in order to ensure compatibility with arithmetic degrees of arithmetic line bundles — cf. [IUTchIII], Proposition 3.9, (iii) — one is obliged to adopt normalizations which imply that] the log-volume of $B_I$ is equal to $0$.

**Actual consumer.** These four commands serve the remaining source proof chain ending in LocalEstimate.rhs_le and the later theorem110 argument. Their source consumers are recorded per command.

**Exact selected command coverage.**

- `Iut.Theorem110Invariants.capsuleBound` (source lines 60–65, parser command 9): Follows the Step (v) formula with capsule size n=j+1. Identification of source logQAt with paper fiber degree remains open.
- `Iut.Theorem110Invariants.LocalEstimate` (source lines 67–104, parser command 10): Carries local containing regions, local volume bounds, and monotonicity as supplied fields. It does not derive the local-field estimates of Propositions 1.4 and 1.5.
- `Iut.Theorem110Invariants.LocalEstimate.placeBound` (source lines 110–115, parser command 13): Collects the three cases: distinguished finite bound, zero at other finite places, and n·log π at infinity. These numerical cases follow Steps (v)–(vii).
- `Iut.Theorem110Invariants.LocalEstimate.dstPlaces` (source lines 117–119, parser command 14): Converts the supplied finite set of distinguished primes into rational places for later finite summation. This is local implementation bookkeeping.

**All fields of selected structure commands.**

- `Iut.Theorem110Invariants.LocalEstimate`: `cont`, `cont_mem_hullRegions`, `thetaPilot_subset`, `cont_eq_integral`, `vol_finite`, `vol_infinite`, `packetVol_mono`.

Source bytes, exact parser ranges, source provenance, actual consumers, and quotation references are stored in `paper-context.json`.

## Use and proof status

Use bundle.publication_markdown as English author/source context after the independent readback is frozen. Keep normalization distinctions and open bridges with that context.

Do not use this packet as independent readback or place its source context in a blind audit.

This packet does not prove Corollary 3.12, Theorem 1.10, ABC, local arithmetic certificates, or correspondence between arbitrary source interfaces and paper objects.

Draft files written only under /tmp/p2m-main-bound-paper-context-v6-20261115. No compiler, MCP-CI call, network request, API submission, or Git operation.
