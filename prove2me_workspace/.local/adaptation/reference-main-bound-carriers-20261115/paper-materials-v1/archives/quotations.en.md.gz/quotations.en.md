## I-local-q-root

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Example 3.2(iv), opening sentence and sentence beginning “Note that”; printed page(s) 71; PDF file page(s) 71. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf.

> Write $q_{\underline v}$ for the $q$-parameter of the elliptic curve $E_{\underline v}$ over $K_{\underline v}$. […] Note that it follows from our assumption concerning $2$-torsion [cf. Definition 3.1, (b)], together with the definition of “$K$” [cf. Definition 3.1, (c)], that $q_{\underline v}$ admits a $2l$-th root […].

Scope: The opening sentence and the next-but-one sentence, with the intervening sentence and the ambient monoid after “root” explicitly omitted. The root-value formula below them is outside this excerpt.

## III-theta-volume

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, opening through the definition of the theta-pilot log-volume; printed page(s) 173, 174; PDF file page(s) 173, 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> Suppose that we are in the situation of Theorem 3.11. Write
> 
> $$-\lvert\log(\underline{\underline\Theta})\rvert\in\mathbb R\cup\{+\infty\}$$
> 
> for the procession-normalized mono-analytic log-volume [i.e., where the average is taken over $j\in\mathbb F_l^{\circledast}$ — cf. Remark 3.1.1, (ii), (iii), (iv); Proposition 3.9, (i), (ii); Theorem 3.11, (i), (a)] of the holomorphic hull [cf. Remark 3.9.5, (i)] of the union of the possible images of a $\Theta$-pilot object [cf. Definition 3.8, (i)], relative to the relevant Kummer isomorphisms [cf. Theorem 3.11, (ii)], in the multiradial representation of Theorem 3.11, (i), which we regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in Theorem 3.11, (i), (ii).

Scope: Complete sentence(s) at the cited location.

## III-q-volume

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, sentence beginning “Write” after the theta-pilot definition; printed page(s) 174; PDF file page(s) 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> Write
> 
> $$-\lvert\log(\underline{\underline q})\rvert\in\mathbb R$$
> 
> for the procession-normalized mono-analytic log-volume of the image of a $q$-pilot object [cf. Definition 3.8, (i)], relative to the relevant Kummer isomorphisms [cf. Theorem 3.11, (ii)], in the multiradial representation of Theorem 3.11, (i), which we do not regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in Theorem 3.11, (i), (ii).

Scope: Complete sentence(s) at the cited location.

## III-volume-inequality

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), §3, Corollary 3.12, final two sentences; printed page(s) 174; PDF file page(s) 174. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf.

> In particular, $\lvert\log(\underline{\underline q})\rvert>0$ is easily computed in terms of the various $q$-parameters of the elliptic curve $E_F$ [cf. [IUTchI], Definition 3.1, (b)] at $\underline v\in\underline{\mathbb V}^{\mathrm{bad}}\ (\ne\emptyset)$. Then it holds that $-\lvert\log(\underline{\underline\Theta})\rvert\in\mathbb R$, and
> 
> $$-\lvert\log(\underline{\underline\Theta})\rvert\geq-\lvert\log(\underline{\underline q})\rvert$$
> 
> — i.e., $C_{\Theta}\geq-1$ for any real number $C_{\Theta}\in\mathbb R$ such that $-\lvert\log(\underline{\underline\Theta})\rvert\leq C_{\Theta}\cdot\lvert\log(\underline{\underline q})\rvert$.

Scope: Complete sentence(s) at the cited location.

## IV-global-degree

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Definition 1.9(i), sentence defining normalized degree and pullback equality; printed page(s) 21, 22; PDF file page(s) 21, 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> If $\mathfrak a\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall refer to
> 
> $$\underline{\deg}(\mathfrak a)\overset{\mathrm{def}}{=}\frac{1}{[F:\mathbb Q]}\cdot\deg_F(\mathfrak a)$$
> 
> as the normalized degree of $\mathfrak a$. Thus, for any finite extension $K$ of $F$, we have
> 
> $$\underline{\deg}(\mathfrak a|_K)=\underline{\deg}(\mathfrak a)$$
> 
> — where we write $\underline{\deg}(\mathfrak a|_K)$ for the normalized degree of the pull-back $\mathfrak a|_K\in\operatorname{ADiv}_{\mathbb R}(K)$ [defined in the evident fashion] of $\mathfrak a$ to $K$.

Scope: Complete sentence(s) at the cited location.

## IV-fiber-degree

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Definition 1.9(ii), opening through the definition of normalized E-degree; printed page(s) 22; PDF file page(s) 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Let $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}\overset{\mathrm{def}}{=}\mathbb V(\mathbb Q)$, $E\subseteq\mathbb V(F)$ a nonempty set of elements lying over $v_{\mathbb Q}$. If $\mathfrak a=\sum_{v\in\mathbb V(F)}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall write
> 
> $$\mathfrak a_E\overset{\mathrm{def}}{=}\sum_{v\in E}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F);\qquad\underline{\deg}_E(\mathfrak a)\overset{\mathrm{def}}{=}\frac{\deg(\mathfrak a_E)}{\sum_{v\in E}[F_v:\mathbb Q_{v_{\mathbb Q}}]}$$
> 
> for the portion of $\mathfrak a$ supported in $E$ and the “normalized $E$-degree” of $\mathfrak a$, respectively.

Scope: Complete sentence(s) at the cited location.

## IV-q-normalization

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Theorem 1.10 statement, sentence beginning “Here, we observe”; printed page(s) 23; PDF file page(s) 23. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Here, we observe that the various “$\log(q_{(-)})$”’s are independent of the choice of $F_{\square}$, and that the quantity “$\lvert\log(\underline{\underline q})\rvert\in\mathbb R_{>0}$” defined in [IUTchIII], Corollary 3.12, is equal to $\frac{1}{2l}\cdot\log(q)\in\mathbb R$ [cf. the definition of “$\underline q_{\underline v}$” in [IUTchI], Example 3.2, (iv)].

Scope: Complete sentence(s) at the cited location.

## IV-prime-counting

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Proposition 1.6, final sentence; printed page(s) 16; PDF file page(s) 16. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> In particular, there exists a positive real number $\eta_{\mathrm{prm}}$ such that
> 
> $$\sum_{p\leq\eta}1\leq\frac{4\eta}{3\cdot\log(\eta)}$$
> 
> — where the sum ranges over the prime numbers $p\leq\eta$ — for all positive real $\eta\geq\eta_{\mathrm{prm}}$.

Scope: Complete sentence(s) at the cited location.

## IV-invariants

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Theorem 1.10, opening through the definition of the tripodal field; printed page(s) 22; PDF file page(s) 22. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Fix a collection of initial $\Theta$-data as in [IUTchI], Definition 3.1. Suppose that we are in the situation of [IUTchIII], Corollary 3.12, and that the elliptic curve $E_F$ has good reduction at every valuation $\in\mathbb V(F)^{\mathrm{good}}\cap\mathbb V(F)^{\mathrm{non}}$ that does not divide $2l$. In the notation of [IUTchI], Definition 3.1, let us write $d_{\mathrm{mod}}\overset{\mathrm{def}}{=}[F_{\mathrm{mod}}:\mathbb Q]$, $(1\leq)\ e_{\mathrm{mod}}\ (\leq d_{\mathrm{mod}})$ for the maximal ramification index of $F_{\mathrm{mod}}$ [i.e., of valuations $\in\mathbb V_{\mathrm{mod}}^{\mathrm{non}}$] over $\mathbb Q$, $d_{\mathrm{mod}}^*\overset{\mathrm{def}}{=}2^{12}\cdot3^3\cdot5\cdot d_{\mathrm{mod}}$, $e_{\mathrm{mod}}^*\overset{\mathrm{def}}{=}2^{12}\cdot3^3\cdot5\cdot e_{\mathrm{mod}}\ (\leq d_{\mathrm{mod}}^*)$, and
> 
> $$F_{\mathrm{mod}}\subseteq F_{\mathrm{tpd}}\overset{\mathrm{def}}{=}F_{\mathrm{mod}}(E_{F_{\mathrm{mod}}}[2])\subseteq F$$
> 
> for the “tripodal” intermediate field obtained from $F_{\mathrm{mod}}$ by adjoining the fields of definition of the $2$-torsion points of any model of $E_F\times_F\overline F$ over $F_{\mathrm{mod}}$ [cf. Proposition 1.8, (ii), (iii)].

Scope: The opening of the theorem. The further (3·5)-torsion and field-generation hypotheses follow on the same page and are outside this excerpt. They remain part of the paper theorem.

## IV-distinguished

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iii), first sentence; printed page(s) 24; PDF file page(s) 24. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> If $F_{\mathrm{tpd}}\subseteq F_{\square}\subseteq K$ is any intermediate extension which is Galois over $F_{\mathrm{mod}}$, then we shall write
> 
> $$\mathbb V(F_{\square})^{\mathrm{dst}}\subseteq\mathbb V(F_{\square})^{\mathrm{non}}$$
> 
> for the set of “distinguished” nonarchimedean valuations $v\in\mathbb V(F_{\square})^{\mathrm{non}}$, i.e., $v$ that extend to a valuation $\in\mathbb V(K)^{\mathrm{non}}$ that ramifies over $\mathbb Q$.

Scope: Complete sentence(s) at the cited location.

## IV-indicator

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iii), clause defining iota after the s-divisors; printed page(s) 25; PDF file page(s) 25. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> we set $\iota_{w_{\mathbb Q}}\overset{\mathrm{def}}{=}1$ if $p_{w_{\mathbb Q}}\leq e_{\mathrm{mod}}^*\cdot l$, $\iota_{w_{\mathbb Q}}\overset{\mathrm{def}}{=}0$ if $p_{w_{\mathbb Q}}>e_{\mathrm{mod}}^*\cdot l$.

Scope: A complete clause after a semicolon. The preceding clause fixes the fiber notation; its omission is identified here.

## IV-certificate-ii

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (ii), displayed chain bounding the different of K; printed page(s) 24; PDF file page(s) 24. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> $$\log(\mathfrak d^K)\leq\log(\mathfrak d^K)+\log(\mathfrak f^K)\leq\log(\mathfrak d^F)+\log(\mathfrak f^F)+2\cdot\log(l)$$
> $$\leq\log(\mathfrak d^{F_{\mathrm{tpd}}})+\log(\mathfrak f^{F_{\mathrm{tpd}}})+2\cdot\log(l)+21$$

Scope: A displayed inequality, not the surrounding proof paragraph. The preceding text invokes tame ramification and the Galois-group inclusion; the following text invokes Proposition 1.3(i),(ii).

## IV-certificate-iii

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iii), sentence beginning “In a similar vein”; printed page(s) 26; PDF file page(s) 26. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> In a similar vein, we conclude that
> 
> $$\log(s^{\mathbb Q})\leq2\cdot d_{\mathrm{mod}}\cdot(\log(\mathfrak d^{F_{\mathrm{tpd}}})+\log(\mathfrak f^{F_{\mathrm{tpd}}}))+\log(2\cdot3\cdot5\cdot l)$$
> $$\leq2\cdot d_{\mathrm{mod}}\cdot(\log(\mathfrak d^{F_{\mathrm{tpd}}})+\log(\mathfrak f^{F_{\mathrm{tpd}}}))+5+\log(l)$$
> 
> and hence that […]

Scope: Opening of a sentence through its first displayed chain; the next display is explicitly omitted.

## IV-normalized-weights

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Remark 1.7.1, paragraph beginning “Thus, in summary”; printed page(s) 18; PDF file page(s) 18. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Thus, in summary, when one works with normalized log-volumes as in Proposition 1.4, (i), the appropriate normalized weights are given by the expressions
> 
> $$\frac{\lambda_{\Pi\vec e^{\dagger}}}{\sum_{\vec e\in E^n}\lambda_{\Pi\vec e}}$$
> 
> [where $\vec e^{\dagger}\in E^n$] that appear in Proposition 1.7. Here, one takes “$E$” to be the set of elements of $\underline{\mathbb V}\xrightarrow{\sim}\mathbb V_{\mathrm{mod}}$ lying over a fixed $v_{\mathbb Q}$; one takes “$n$” to be the cardinality of $A$, so that one can write $A=\{\alpha_1,\ldots,\alpha_n\}$ [where the $\alpha_i$ are distinct]; if $e\in E$ corresponds to $\underline v\in\underline{\mathbb V}$, $v\in\mathbb V_{\mathrm{mod}}$, then one takes
> 
> $$\text{“}\lambda_e\text{”}\overset{\mathrm{def}}{=}[(F_{\mathrm{mod}})_v:\mathbb Q_{v_{\mathbb Q}}]\in\mathbb R_{>0}$$
> 
> and “$\beta_e$” to be a normalized log-volume of some compact open subset of $K_{\underline v}$.

Scope: Complete sentence(s) at the cited location.

## IV-local-objective

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (iv), opening sentence; printed page(s) 26; PDF file page(s) 26. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> In order to estimate the constant “$C_{\Theta}$” of [IUTchIII], Corollary 3.12, we must, according to the various definitions given in the statement of [IUTchIII], Corollary 3.12, compute an upper bound for the
> 
> procession-normalized mono-analytic log-volume of the holomorphic hull of the union of the possible images of a $\Theta$-pilot object, relative to the relevant Kummer isomorphisms [cf. [IUTchIII], Theorem 3.11, (ii)], in the multiradial representation of [IUTchIII], Theorem 3.11, (i), which we regard as subject to the indeterminacies (Ind1), (Ind2), (Ind3) described in [IUTchIII], Theorem 3.11, (i), (ii).

Scope: Complete sentence(s) at the cited location.

## IV-capsule-bound

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (v), final sentences and display; printed page(s) 28; PDF file page(s) 28. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Here, we note that it follows immediately from the first equality of the first display of Proposition 1.7 that, after passing to weighted averages, the operation of symmetrizing with respect to the choice of “$i^{\dagger}\in I$” in $S_{j+1}^{\pm}$ does not affect the computation of the upper bound under consideration. Thus, by applying Proposition 1.7, we obtain that the resulting “weighted average upper bound” is given by
> 
> $$(j+1)\cdot\log(\mathfrak d^K_{v_{\mathbb Q}})-\frac{j^2}{2l}\cdot\log(q_{v_{\mathbb Q}})+\log(s^{\mathbb Q}_{v_{\mathbb Q}})+4(j+1)\cdot l_{\mathrm{mod}}^*\cdot\log(s^{\leq}_{v_{\mathbb Q}})$$

Scope: Two sentences through the displayed bound. The continuation on page 29 recalls the notation of Step (iii).

## IV-zero-bound

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (vi), final two sentences; printed page(s) 29; PDF file page(s) 29. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> One may then compute a “weighted average upper bound” and then a “procession-normalized upper bound”, as was done in Step (v). The resulting “procession-normalized upper bound” is clearly equal to $0$.

Scope: Complete sentence(s) at the cited location.

## IV-infinite-bound

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (vii), sentences giving the archimedean bound; printed page(s) 30; PDF file page(s) 30. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf.

> Thus, an upper bound on the component of the log-volume under consideration may be obtained by computing an upper bound for the log-volume of this container. Such an upper bound
> 
> $$(j+1)\cdot\log(\pi)$$
> 
> follows immediately from the fact that [in order to ensure compatibility with arithmetic degrees of arithmetic line bundles — cf. [IUTchIII], Proposition 3.9, (iii) — one is obliged to adopt normalizations which imply that] the log-volume of $B_I$ is equal to $0$.

Scope: Complete sentence(s) at the cited location.
