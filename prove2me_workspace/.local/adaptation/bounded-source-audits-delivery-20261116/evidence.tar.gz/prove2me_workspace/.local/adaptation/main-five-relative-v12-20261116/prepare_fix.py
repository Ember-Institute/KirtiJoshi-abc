#!/usr/bin/env python3
"""Create only two syntax/name-resolution edits, retain original failure evidence."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,shutil,difflib,re
D=Path('/tmp/p2m-main5-fix-v12-20261116')
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A=W/'.local/adaptation/main-five-relative-v11-20261116'
B=W/'.local/adaptation/reference-main-bound-carriers-20261115'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p):return {'path':str(p),'sha256':sha(p)}
def once(s,a,b):assert s.count(a)==1,a;return s.replace(a,b)
reports=[]
for rel in ['AuditMainFiveRelativeBounded.lean','queries/QueryImportedEquationsBeforeRealization.lean']:
 p=A/rel;old=p.read_text();new=old
 if rel.startswith('Audit'):
  new=once(new,'    let e ← match ← stringField n "kind" with','    let e : Expr ← match ← stringField n "kind" with')
  start=new.index('def decodeRawDag (dag : Json)');end=new.index('-- Relocate shared nodes once.',start)
  body=new[start:end]
  # Join only constructor-argument continuation lines, preserving each token.
  body=re.sub(r'\n          (?=\()', ' ', body)
  new=new[:start]+body+new[end:]
  # Aside from the Expr annotation, the full file differs only in whitespace.
  assert re.sub(r'\s+','',old)==re.sub(r'\s+','',new.replace('let e : Expr ← match','let e ← match'))
  cut='-- Relocate shared nodes once.'
  assert old[old.index(cut):]==new[new.index(cut):]
  assert 'let e : Expr ← match' in new
 else:
  new=once(new,'    logInfo m!','    Lean.logInfo m!')
  assert new.replace('Lean.logInfo m!','logInfo m!')==old
  assert new.index('env.find?')<new.index('getModuleIdxFor?')<new.index('Lean.collectAxioms')<new.index('Lean.logInfo')<new.index('#check')
  assert 'getEqnsFor?'not in new and 'attribute ['not in new
 original=D/'originals'/rel;original.parent.mkdir(parents=True,exist_ok=True);original.write_text(old)
 fixed=D/'ready'/rel;fixed.parent.mkdir(parents=True,exist_ok=True);fixed.write_text(new)
 patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 patch_file=D/('identity-syntax.patch'if rel.startswith('Audit')else'imported-query-namespace.patch');patch_file.write_text(patch)
 reports.append({'actualIntegrationTarget':str(p),'before':pin(original),'after':pin(fixed),'patch':pin(patch_file)})
failed=[]
for stem in ['main5-first-three-relative-v11','main5-lazy-equations-imported-owner-v11']:
 p=B/(stem+'-result.json');dst=D/'failure-evidence'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
 x=json.loads(dst.read_text());r=x['result']
 out=dst.with_suffix('.stdout.txt');out.write_text(r.get('stdout',''))
 err=dst.with_suffix('.stderr.txt');err.write_text(r.get('stderr',''))
 errors=[line for line in r.get('stdout','').splitlines()if 'error' in line.lower() and (': error' in line or ': error('in line)]
 failed.append({'job_id':x['job_id'],'status':x['status'],'exit_code':r['exit_code'],'receipt':pin(dst),'fullStdout':pin(out),'fullStderr':pin(err),'errorsInOrder':errors,'resources':x['resources'],'compile_time_seconds':x['compile_time_seconds']})
refs=[
 Path('/tmp/p2m-initial-theta-batch-instance-20261115/split-v2-generated/value/CheckTateFamilyS.lean'),
 W/'.local/adaptation/c2-complete-inputs-20261116/AuditC2Final44WithExactlyTwoValueCertificates.lean',
 W/'.local/adaptation/c2-complete-inputs-20261116/QueryImportedLocalDataCongr.lean',
 Path('/root/.elan/toolchains/leanprover--lean4---v4.33.1/src/lean/Lean/Util/CollectAxioms.lean'),
 Path('/root/.elan/toolchains/leanprover--lean4---v4.33.1/src/lean/Lean/Log.lean')]
save(D/'fix-evidence.json',{'schema':'main5-v12-minimal-syntax-and-namespace-fix/v1','patches':reports,'originalFailures':failed,'referenceSources':[pin(p)for p in refs],
 'diagnosis':{'identity':'Missing Expr expected type at let e plus invalid constructor continuation indentation broke the match/do block before identity execution.',
 'query':'Only reported error is unknown unqualified logInfo. Lean.collectAxioms n already matches the locked4.33.1 API and passed C2 query; keep it unchanged.'},
 'checks':{'allExprConstructorTokensPreserved':True,'onlyAddedTypeAnnotation':'Expr','allPostDecoderCodeByteIdentical':True,'ownerTheoremAndExactAxiomGuardsByteIdentical':True,'guardBeforeAnyCheckOrPrint':True,'flagsRelaxed':False,'source560MBArtifactRead':False,'mainWorkspaceWritten':False},
 'nativeArtifactEvidenceProvidedByRoot':['ci-016234 leaf succeeded','ci-016235 artifact succeeded'],
 'nativeLogVolumeBoundSourceSha256':sha(W/'Definitions/Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound.lean'),
 'independentImportedEnvironmentAcceptancePending':True,'firstThreeIdentityAcceptancePending':True,
 'compilerRun':False,'CIInvoked':False,'APIInvoked':False,'GitInvoked':False,'relativeOnly':True,'publishAllowed':False,'finalAcceptance':False})
print(json.dumps(reports,ensure_ascii=False,indent=2))
