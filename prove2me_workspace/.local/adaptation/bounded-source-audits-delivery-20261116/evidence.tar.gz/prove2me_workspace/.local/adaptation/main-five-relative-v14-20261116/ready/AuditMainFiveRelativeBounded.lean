import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RightHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

structure Relocation where
  original : Name
  target : Name
  permutation : Option (Array Nat)
  expectedInstance : Option Bool
  expectedAxioms : Option (Array Name)

structure SourceProofValue where
  original : Name
  params : List Name
  value : Expr

structure Relocations where
  rows : Array Relocation
  proofs : Array SourceProofValue := #[]
  rawDag : Array Expr := #[]

def Relocations.find? (rs : Relocations) (p : Relocation → Bool) : Option Relocation := rs.rows.find? p
def Relocations.any (rs : Relocations) (p : Relocation → Bool) : Bool := rs.rows.any p

def projectName (n : Name) : Bool :=
  #[`Iut, `Genl, `TateCurvesTheta, `_private.Iut, `_private.TateCurvesTheta, `AbcAdaptation, `Definitions, `Theorems, `Solutions].any (·.isPrefixOf n)

def relocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.original == n) then return r.target
  if projectName n then throw s!"Unmapped project name {n}"
  return n

def inverseRelocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.target == n) then return r.original
  if projectName n then throw s!"Unmapped wrapped name {n}"
  return n

def reorder (indices : Array Nat) (us : Array α) : Except String (Array α) := do
  unless indices.size == us.size && indices.toList.eraseDups.length == us.size do
    throw "Universe permutation has incorrect size or repeated indices"
  indices.mapM fun i => match us[i]? with
    | some u => pure u
    | none => throw "Universe permutation index out of range"

def rawDagChild (earlier : Array Expr) (entry : Json) (key : String) : Except String Expr := do
  let ref ← (← field entry key).getNat?
  let some child := earlier[ref]? | throw s!"Non-topological source DAG child {key}/{ref}"
  return child

def decodeRawDag (dag : Json) : Except String (Array Expr) := do
  unless (← stringField dag "schema") == "foundation-expr-dag-v1" do throw "Wrong source DAG schema"
  let mut earlier : Array Expr := #[]
  for n in ← arrayField dag "nodes" do
    let e : Expr ← match ← stringField n "kind" with
      | "bvar" => pure <| .bvar (← (← field n "index").getNat?)
      | "sort" => pure <| .sort (← decodeLevel (← field n "level"))
      | "const" => pure <| .const (← decodeName (← field n "name")) ((← (← arrayField n "levels").mapM decodeLevel).toList)
      | "app" => pure <| .app (← rawDagChild earlier n "fn") (← rawDagChild earlier n "arg")
      | "lam" => pure <| .lam (← decodeName (← field n "name")) (← rawDagChild earlier n "type") (← rawDagChild earlier n "body") (← decodeBinder (← stringField n "binder"))
      | "forall" => pure <| .forallE (← decodeName (← field n "name")) (← rawDagChild earlier n "type") (← rawDagChild earlier n "body") (← decodeBinder (← stringField n "binder"))
      | "let" => pure <| .letE (← decodeName (← field n "name")) (← rawDagChild earlier n "type") (← rawDagChild earlier n "value") (← rawDagChild earlier n "body") (← (← field n "nondependent").getBool?)
      | "nat" => pure <| .lit (.natVal (← (← field n "value").getNat?))
      | "string" => pure <| .lit (.strVal (← stringField n "value"))
      | "proj" => pure <| .proj (← decodeName (← field n "name")) (← (← field n "index").getNat?) (← rawDagChild earlier n "body")
      | other => throw s!"Unsupported exact source DAG node {other}"
    earlier := earlier.push e
  for root in ← arrayField dag "roots" do
    unless (← root.getNat?) < earlier.size do throw "Invalid source DAG root"
  return earlier

-- Relocate shared nodes once. Constants remain constants except the individually
-- checked genuine original proof bodies; data constants such as source S are
-- never unfolded or serialized as a flattened expansion.
partial def relocateSharedAux (rs : Relocations) (e : Expr) :
    StateT (Lean.ExprStructMap Expr) (Except String) Expr := do
  if let some result := (← get)[(⟨e⟩ : ExprStructEq)]? then return result
  let result ← match e with
    | .const n us =>
      if let some proof := rs.proofs.find? (·.original == n) then
        unless us.length == proof.params.length do throw "Genuine source proof universe arity differs"
        pure <| proof.value.instantiateLevelParams proof.params us
      else
        let target ← liftM (relocated rs n)
        let levels ← match rs.find? (·.original == n) with
          | some r => match r.permutation with
            | some indices => pure (← liftM (reorder indices us.toArray)).toList
            | none => pure us
          | none => pure us
        pure <| .const target levels
    | .bvar i => pure <| .bvar i
    | .sort u => pure <| .sort u
    | .app f a => return .app (← relocateSharedAux rs f) (← relocateSharedAux rs a)
    | .lam n t b bi => return .lam n (← relocateSharedAux rs t) (← relocateSharedAux rs b) bi
    | .forallE n t b bi => return .forallE n (← relocateSharedAux rs t) (← relocateSharedAux rs b) bi
    | .letE n t v b nd => return .letE n (← relocateSharedAux rs t) (← relocateSharedAux rs v) (← relocateSharedAux rs b) nd
    | .proj n i b => return .proj (← liftM (relocated rs n)) i (← relocateSharedAux rs b)
    | .lit l => pure <| .lit l
    | _ => throw "Non-closed or non-metadata-erased source expression"
  modify fun cache => cache.insert (⟨e⟩ : ExprStructEq) result
  return result

def decodeRecordExpr (rs : Relocations) (j : Json) : Except String Expr := do
  unless (← stringField j "kind") == "dagRef" do throw "Expected lossless source DAG reference"
  let ref ← (← field j "ref").getNat?
  let some raw := rs.rawDag[ref]? | throw "Source DAG reference is outside bound record"
  return (← (relocateSharedAux rs raw).run {}).1


def decodeExpr (rs : Relocations) (j : Json) : Except String Expr :=
  decodeRecordExpr rs j

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No owner {name}"
  unless modules.contains owner do throwError "Forbidden dependency {name}, owner {owner}"
  if #[`Iut, `Genl].any (·.isPrefixOf name) then
    throwError "Pending unrelocated source dependency {name}"
  if (`AbcAdaptation).isPrefixOf name && !(rs.any (·.target == name)) then
    throwError "Pending unmapped target dependency {name}"

def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  if let .axiomInfo _ := ci then throwError "Carrier declares an axiom {name}"
  let axs ← collectAxioms name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"carrier {name}" axs
  ensureStandard s!"carrier type {name}" taxs
  let value? := ci.value? (allowOpaque := true)
  let vaxs ← match value? with
    | some v => expressionAxioms v
    | none => pure #[]
  ensureStandard s!"carrier value {name}" vaxs
  for expr in #[ci.type] ++ value?.toArray do
    for dep in expr.getUsedConstants do allowedOwner rs modules dep
  if let .recInfo r := ci then
    for rule in r.rules do
      for dep in rule.rhs.getUsedConstants do allowedOwner rs modules dep
      ensureStandard s!"recursor rule {name}" (← expressionAxioms rule.rhs)
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("hasValue", toJson value?.isSome),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name))]

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

def compareRecord (rs : Relocations) (allowedOwners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.eraseDups == sourceParams do throwError "Duplicate universe parameter {original}"
  unless sourceParams.length == target.levelParams.length do
    throwError "Universe parameter count differs for {original}"
  unless (← checked (stringField record "constantKind")) == kind target do
    throwError "ConstantInfo kind differs for {original}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original axiom for {original}"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "Missing map entry {original}"
  let some expectedAxioms := rel.expectedAxioms |
    throwError "Missing accepted-graph source axiom inventory {original}"
  let sourceAxiomNames := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxiomNames.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Original axiom closure differs from accepted compiler graph {original}"
  let some expectedInstance := rel.expectedInstance |
    throwError "Missing accepted-graph instance flag {original}"
  unless (← checked (record.getObjValAs? Bool "isInstance")) == expectedInstance do
    throwError "Exported original instance flag differs from accepted graph {original}"
  unless Lean.Meta.isInstanceCore (← getEnv) target.name == expectedInstance do
    throwError "Instance registry membership differs for {original}"
  let targetLevels ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let reordered ← checked (reorder indices canonical.toArray)
      pure reordered.toList
  let originalSignature ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let originalSignature := originalSignature.instantiateLevelParams sourceParams canonical
  let sourceTypeRaw ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams targetLevels
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory originalSignature do
    throwError "Unexpanded original signature BinderInfo serialization differs for {original}"
  unless binderInventory originalSignature == binderInventory targetType do
    throwError "Full unexpanded original/actual target signature BinderInfo inventory differs for {original}"
  unless binderPlacement originalSignature == binderPlacement targetType do
    throwError "Full unexpanded original/actual target signature BinderInfo placement differs for {original}"
  kernelTypeEq s!"original versus target type {original}" sourceType targetType
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do
    throwError "Inductive/constructor/recursor computation shape differs for {original}"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  unless sourceProp == (← isProp target.type) do throwError "Proposition status differs {original}"
  let mut comparedValue := false
  let mut definitionallyEqualValue := false
  let originalValueJson ← checked (field record "valueExpr")
  -- Proof declarations are audited by exact type and axiom closure. For a data
  -- value containing proof fields, Kernel.isDefEq itself uses proof irrelevance.
  if !sourceProp && originalValueJson != Json.null then
    let sourceValue := (← checked (decodeExpr rs originalValueJson)).instantiateLevelParams sourceParams canonical
    let some targetValue := target.value? (allowOpaque := true) |
      throwError "Target value missing for {original}"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq s!"original value inhabits original type {original}"
      (← kernelCheck s!"original value {original}" sourceValue) sourceType
    kernelTypeEq s!"target value inhabits target type {original}"
      (← kernelCheck s!"target value {original}" targetValue) targetType
    unless binderInventory sourceValue == binderInventory targetValue &&
        binderPlacement sourceValue == binderPlacement targetValue do
      throwError "Pending computational value BinderInfo inventory/placement difference {original}"
    kernelTermEq s!"original versus target computational value {original}" sourceValue targetValue
    definitionallyEqualValue := true
    comparedValue := true
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut comparedRules := 0
  if let .recInfo r := target then
    unless rules.size == r.rules.length do throwError "Recursor rule count differs {original}"
    for i in [:rules.size] do
      let sourceRhs := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let targetRhs := r.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      unless binderInventory sourceRhs == binderInventory targetRhs &&
          binderPlacement sourceRhs == binderPlacement targetRhs do
        throwError "Pending recursor RHS BinderInfo inventory/placement difference {original} #{i}"
      kernelTermEq s!"recursor rule {original} #{i}" sourceRhs targetRhs
      comparedRules := comparedRules + 1
  else
    unless rules.isEmpty do throwError "Unexpected original recursor rules {original}"
  let sourceStruct ← checked (field record "structure")
  unless (sourceStruct != Json.null) == (getStructureInfo? (← getEnv) target.name).isSome do
    throwError "Structure metadata presence differs {original}"
  if sourceStruct != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name |
      throwError "Target structure metadata missing {target.name}"
    unless (← checked (field sourceStruct "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do
      throwError "Complete structure field/parent metadata differs {original}"
    let autoParams ← checked (arrayField sourceStruct "fieldAutoParamExprs")
    unless autoParams.size == info.fieldInfo.size do
      throwError "Structure field autoParam count differs {original}"
    for i in [:autoParams.size] do
      match autoParams[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some targetExpr =>
        if sourceJson == Json.null then throwError "Missing source autoParam {original} #{i}"
        let sourceExpr := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let targetExpr := targetExpr.instantiateLevelParams target.levelParams targetLevels
        unless binderPlacement sourceExpr == binderPlacement targetExpr do
          throwError "Structure autoParam BinderInfo placement differs {original} #{i}"
        kernelTermEq s!"structure field autoParam {original} #{i}" sourceExpr targetExpr
      | sourceJson, none =>
        unless sourceJson == Json.null do throwError "Missing target autoParam {original} #{i}"
    unless (← checked (field sourceStruct "fieldsInConstructorOrder")) ==
        toJson (info.fieldNames.map Name.toString) do
      throwError "Structure field order differs {original}"
    let projections ← namesFromJson (← checked (field sourceStruct "projections"))
    let targetProjections ← projections.toArray.mapM fun n => checked (relocated rs n)
    unless targetProjections == info.fieldInfo.map (·.projFn) do
      throwError "Structure accessor identities/order differ {original}"
    for p in targetProjections do
      unless rs.any (·.target == p) do throwError "Unaudited structure accessor {p}"
  return Json.mkObj [("original", toJson original.toString), ("originalName", encodeName original),
    ("target", toJson target.name.toString), ("targetName", encodeName target.name),
    ("sourceRecord", record), ("kernelTypeEqual", toJson true),
    ("allExpressionBinderInfoEqual", toJson true),
    ("binderInfoPlacementEqual", toJson true),
    ("sourceSignatureBinderInfoSerializationValidated", toJson true),
    ("sourceTargetSignatureBinderInfoInventoryEqual", toJson true),
    ("sourceTargetSignatureBinderInfoPlacementEqual", toJson true),
    ("binderInfoComparisonScope", toJson "actual-exported-4.35-source-type-after-exact-name-relocation-vs-actual-4.33-target-type"),
    ("expandedOriginalTypeKernelEqual", toJson true),
    ("computationShapeEqual", toJson true), ("completeStructureMetadataEqual", toJson true),
    ("kernelValueEqual", toJson definitionallyEqualValue),
    ("computationalValueEqualityChecked", toJson comparedValue),
    ("kernelPropositionalValueEquality", toJson false),
    ("propositionalValueEqualityEvidence", Json.null),
    ("proofDeclaration", toJson sourceProp), ("recursorRulesCompared", toJson comparedRules),
    ("instanceRegistryMatchesAcceptedGraph", toJson true),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("expectedIsInstance", toJson expectedInstance),
    ("universeOriginalOrder", Json.arr (sourceParams.toArray.map encodeName)),
    ("universeTargetOrder", Json.arr (target.levelParams.toArray.map encodeName)),
    ("targetToSourceUniverseIndices", match rel.permutation with | none => Json.null | some a => toJson a)]

def loadMainRecord (binding : Json) : MetaM (Json × Array Expr) := do
  let view ← jsonFile (← checked (stringField binding "path"))
  unless (← checked (stringField view "schema")) == "main5-existing-original-record-lossless-dag-v1" &&
      (← checked (view.getObjValAs? Nat "completeOriginalRecordCount")) == 197 &&
      (← checked (view.getObjValAs? Nat "completeOriginalSelectedCount")) == 173 &&
      (← checked (view.getObjValAs? Bool "losslessTopologicalDagVerified")) &&
      !(← checked (view.getObjValAs? Bool "constantExpansionPerformed")) do
    throwError "Wrong existing-source DAG record view"
  let source ← checked (field view "sourceBinding")
  unless (← checked (stringField source "job_id")) == "ci-014995-7db3a096" &&
      (← checked (stringField source "sha256")) == "e16abf205bb8216d6cc0e9104d9cc924d34ab23b64900e55dad8a6d0537e7642" do
    throwError "Wrong actual original main5 source export"
  let record ← checked (field view "record")
  unless (← checked (record.getObjValAs? Bool "selected")) do throwError "Unselected original theorem in identity leaf"
  let nodes ← checked (decodeRawDag (← checked (field view "expressionDag")))
  return (record, nodes)

def readMainRelocations (config : Json) : MetaM Relocations := do
  let env ← getEnv
  let nativeNames := env.constants.fold (fun acc n _ =>
    if (`AbcAdaptation.Reference).isPrefixOf n then acc.push n else acc) (#[] : Array Name)
  let mut nameIndex : Std.HashMap String (Array Name) := {}
  for n in nativeNames do
    nameIndex := nameIndex.insert n.toString ((nameIndex[n.toString]?.getD #[]).push n)
  let mut rows := #[]
  for row in ← checked (arrayField config "projectMap") do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let targetDisplay ← checked (stringField row "target")
    let owner := (← checked (stringField row "targetOwner")).toName
    let resolvedNames := (nameIndex[targetDisplay]?.getD #[]).filter fun n => moduleOf env n == some owner
    unless resolvedNames.size == 1 do throwError "Missing/nonunique exact native Name {targetDisplay}, owner {owner}"
    let target := resolvedNames[0]!
    let targetNameJson ← checked (field row "targetName")
    if targetNameJson != Json.null then
      unless target == (← checked (decodeName targetNameJson)) do throwError "Actual structural target Name differs {target}"
    if rows.any (fun r : Relocation => r.original == original || r.target == target) then
      throwError "Duplicate structural source/target mapping {original}"
    let permutation ← match ← checked (field row "targetToSourceUniverseIndices") with
      | Json.null => pure none
      | other => pure (some (← checked (other.getArr? >>= Array.mapM Json.getNat?)))
    let selected ← checked (row.getObjValAs? Bool "currentSelectedNamed")
    let inst ← if selected then pure (some (← checked (row.getObjValAs? Bool "expectedIsInstance"))) else pure none
    let axs ← if selected then pure (some (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray) else pure none
    rows := rows.push ⟨original, target, permutation, inst, axs⟩
  return { rows }

def installMainOriginalProofValues (rs : Relocations) (owners : Array Name) (config : Json) :
    MetaM (Relocations × Array Json) := do
  let mut rs := rs
  let mut reports := #[]
  for binding in ← checked (arrayField config "proofValueResolutions") do
    let original ← checked (decodeName (← checked (field binding "originalName")))
    unless (← checked (field binding "standaloneTargetIdentity")) == Json.null &&
        !(rs.any (·.original == original)) do throwError "A genuine source proof acquired a target alias {original}"
    let (record, nodes) ← loadMainRecord (← checked (field binding "sourceView"))
    unless (← checked (decodeName (← checked (field record "nameExpr")))) == original &&
        (← checked (record.getObjValAs? Bool "isProposition")) &&
        (← checked (stringField record "constantKind")) == "theorem" do
      throwError "Wrong exact original proof record {original}"
    let params ← namesFromJson (← checked (field record "levelParams"))
    let localRs := {rs with rawDag := nodes}
    let type ← checked (decodeExpr localRs (← checked (field record "elaboratedExpr")))
    let valueJson ← checked (field record "valueExpr")
    if valueJson == Json.null then throwError "Missing genuine original proof body {original}"
    let value ← checked (decodeExpr localRs valueJson)
    unless (← isProp type) do throwError "Proof-value resolution is not proposition-valued {original}"
    kernelTypeEq s!"actual original proof value inhabits exact source type {original}"
      (← kernelCheck s!"genuine original proof body {original}" value) type
    for e in #[type, value] do
      ensureStandard s!"genuine original proof closure {original}" (← expressionAxioms e)
      for dep in e.getUsedConstants do allowedOwner rs owners dep
    let expected ← namesFromJson (← checked (field binding "expectedSourceAxioms"))
    let actual := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
    unless actual.qsort Name.lt == expected.toArray.qsort Name.lt do
      throwError "Original proof source axiom inventory differs {original}"
    rs := {rs with proofs := rs.proofs.push ⟨original, params, value⟩}
    reports := reports.push (Json.mkObj [
      ("originalName", encodeName original), ("standaloneTargetIdentity", Json.null),
      ("resolution", toJson "genuine-exported-original-proof-value"),
      ("sourceView", ← checked (field binding "sourceView")),
      ("genuineOriginalValueInhabitsExactOriginalType", toJson true),
      ("allProofTypeAndValueDependenciesHaveAllowedOwners", toJson true),
      ("parentOriginalName", ← checked (field binding "parentOriginalName")),
      ("parentWholeValueEqualityRequired", toJson true),
      ("newMathematicalAliasCreated", toJson false)])
  return (rs, reports)

def runMainFiveIdentity : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected locked target Lean4.33.1"
  let config ← jsonFile (← absoluteEnv "MAIN_FIVE_IDENTITY_CONFIG")
  unless (← checked (stringField config "schema")) == "main5-relative-existing-source-kernel-config/v1" &&
      !(← checked (config.getObjValAs? Bool "publishAllowed")) &&
      !(← checked (config.getObjValAs? Bool "finalAcceptance")) do throwError "Unexpected main5 relative config"
  unless (← checked (arrayField config "standardRenames")).isEmpty &&
      (← checked (arrayField config "dataValueSubstitutions")).isEmpty do
    throwError "No new standard rename or data substitution is admitted"
  let sourceReceiptBinding ← checked (field config "originalSourceReceipt")
  let receipt ← jsonFile (← checked (stringField sourceReceiptBinding "path"))
  unless receipt == (← checked (field sourceReceiptBinding "contents")) &&
      (← checked (stringField receipt "job_id")) == "ci-014995-7db3a096" &&
      (← checked (stringField receipt "status")) == "succeeded" do throwError "Original source receipt differs"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Original source export failed"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Source export workspace mode differs"
  let rs ← readMainRelocations config
  let env ← getEnv
  let projectOwners ← (← checked (config.getObjValAs? (Array String) "allowedNativeModules")).mapM fun s => pure s.toName
  let standard := #[`Init, `Lean, `Std, `Mathlib, `Batteries, `Aesop, `Qq, `Plausible,
    `ProofWidgets, `ImportGraph, `Cli, `LeanSearchClient]
  let owners := env.header.moduleNames.filter fun m => projectOwners.contains m || standard.any (·.isPrefixOf m)
  let (rs, proofReports) ← installMainOriginalProofValues rs owners config
  let mut comparisons := #[]
  let mut targetAudits := #[]
  let mut resolvedOwnProofs := #[]
  for binding in ← checked (arrayField config "records") do
    let (record, nodes) ← loadMainRecord (← checked (field binding "sourceView"))
    let original ← checked (decodeName (← checked (field record "nameExpr")))
    if rs.proofs.any (·.original == original) then
      let sourceProof := proofReports.find? fun row =>
        (field row "originalName").toOption == some (encodeName original)
      let some sourceProof := sourceProof | throwError "Missing genuine original proof certificate {original}"
      resolvedOwnProofs := resolvedOwnProofs.push sourceProof
    else
      let some rel := rs.find? (·.original == original) | throwError "Missing selected source mapping {original}"
      let target ← getConstInfo rel.target
      let localRs := {rs with rawDag := nodes}
      let comparison ← compareRecord localRs owners record target
      comparisons := comparisons.push (Json.mkObj [
        ("sourceExpressionView", ← checked (field binding "sourceView")), ("comparison", comparison)])
      targetAudits := targetAudits.push (← auditDeclaration localRs owners target.name)
  let expected ← checked (config.getObjValAs? Nat "expectedSelectedRecordCount")
  let named ← checked (config.getObjValAs? Nat "expectedNamedRecordCount")
  let proofs ← checked (config.getObjValAs? Nat "expectedSourceProofRecordCount")
  unless comparisons.size == named && resolvedOwnProofs.size == proofs && named + proofs == expected do
    throwError "Selected original source obligations were dropped"
  IO.FS.writeFile (← checked (stringField config "outputFile")) ((Json.mkObj [
    ("schema", toJson "main5-relative-existing-source-kernel-result/v1"),
    ("compilerVersion", toJson Lean.versionString), ("configuration", config),
    ("selectedSourceObligations", toJson expected), ("namedComparisons", toJson comparisons.size),
    ("genuineOwnSourceProofValues", Json.arr resolvedOwnProofs),
    ("comparisons", Json.arr comparisons), ("targetAxiomAndOwnerAudits", Json.arr targetAudits),
    ("allConfiguredRelativeChecksPassed", toJson true),
    ("dependencyFormalAcceptanceClaimed", toJson false), ("relativeOnly", toJson true),
    ("pendingInitialModules", ← checked (field config "pendingInitialModules")),
    ("sourceSExpanded", toJson false), ("newMathematicalAliases", Json.arr #[]),
    ("publishAllowed", toJson false), ("finalAcceptance", toJson false)]).compress ++ "\n")

end FoundationAudit
syntax (name := mainFiveIdentity) "audit_main_five_identity" : command
@[command_elab mainFiveIdentity] def elabMainFiveIdentity : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.runMainFiveIdentity

audit_main_five_identity
