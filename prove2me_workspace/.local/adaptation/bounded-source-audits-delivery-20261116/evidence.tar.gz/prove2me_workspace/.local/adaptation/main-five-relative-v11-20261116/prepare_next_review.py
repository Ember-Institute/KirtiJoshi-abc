#!/usr/bin/env python3
"""Offline preparation only. Read v9 shared DAG files, never original-exprs.json."""
import sys
sys.dont_write_bytecode = True
import copy, hashlib, json, shutil
from pathlib import Path
D = Path('/tmp/p2m-main5-next-identity-v11-20261116')
V = Path('/tmp/p2m-main-bound-five-identity-v9-20261116')
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
B = W / '.local/adaptation/reference-main-bound-carriers-20261115'
FIRST = ['Iut.QPilotData', 'Iut.QPilotData.mk', 'Iut.QPilotData.casesOn']
CASE = 'Iut.Theorem110Certificate.casesOn'
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p): return {'path': str(p), 'sha256': sha(p)}
def save(p, x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
idx = read(V / 'source-view-index.json')
profile = read(B / 'original-exprs-size-profile.json')
rows = {r['name']: r for r in idx['records']}
ranges = {r['name']: r for r in profile['records'] if r['selected']}
assert len(rows) == len(ranges) == 173
assert set(rows) == set(ranges)
source_inventory = []
for name, row in rows.items():
    p = Path(row['sourceView']['path'])
    assert sha(p) == row['sourceView']['sha256']
    dag = read(p)
    r = ranges[name]
    bind = dag['sourceBinding']
    assert bind['startOffset'] == r['offset'] and bind['endOffset'] == r['endOffset']
    assert dag['record']['sourceSha256'] == r['sourceSha256']
    assert dag['record']['normalizedSha256'] == r['normalizedSha256']
    assert dag['losslessTopologicalDagVerified'] and not dag['constantExpansionPerformed']
    assert not dag['sourceSExpansionPerformed']
    source_inventory.append({
        **row, 'sourceBinding': bind, 'originalFieldOffsets': r['fieldOffsets'],
        'originalFieldBytes': r['fieldBytes'], 'sourceRecordRootMerkleHashes': dag['sourceRecordRootMerkleHashes'],
        'preservedRecordKeys': list(dag['record']),
        'scopePolicy': 'Complete original record DAG, type/value/axioms/metadata; no field filtering.'})
assert sum(r['viewBytes'] for r in source_inventory) == 8813934
save(D / 'source173-scope-and-byte-ranges.json', {
    'schema': 'main5-next-review-full173-source-range-inventory/v1',
    'sourceIndex': pin(V / 'source-view-index.json'), 'sourceProfile': pin(B / 'original-exprs-size-profile.json'),
    'sourceExportRead': False, 'selectedRecordCount': 173, 'sourceRecordCount': 197,
    'sharedDagBytes': 8813934, 'records': source_inventory})
shutil.copyfile(V / 'AuditMainFiveRelative.lean', D / 'AuditMainFiveRelativeBounded.lean')
auditor = D / 'AuditMainFiveRelativeBounded.lean'
plans = []
full_by_module = {}
for variant in ['actual169-proof4', 'materialized172-proof1']:
    coverage = []
    for src in sorted((V / 'configs' / variant).glob('*.json')):
        cfg = read(src)
        cfg['outputFile'] = str(D / 'results' / 'full-plan' / variant / (src.stem + '.json'))
        Path(cfg['outputFile']).parent.mkdir(parents=True, exist_ok=True)
        dest = D / 'configs' / 'full-plan' / variant / src.name
        save(dest, cfg)
        coverage.extend(r['original'] for r in cfg['records'])
        full_by_module[variant, cfg['scopeSourceModule']] = dest
        plans.append({'variant': variant, 'module': cfg['scopeSourceModule'], 'config': pin(dest),
                      'selected': cfg['expectedSelectedRecordCount'], 'named': cfg['expectedNamedRecordCount'],
                      'proofValues': cfg['expectedSourceProofRecordCount']})
    assert len(coverage) == 173 and set(coverage) == set(rows)
source_base = full_by_module['actual169-proof4', 'Iut.Cor312.LeftHandSide']
batch_plans = []
for label, names in [('first-three', FIRST)] + [(n, [n]) for n in FIRST] + [('certificate-casesOn-pending', [CASE])]:
    module = rows[names[0]]['module']
    assert all(rows[n]['module'] == module for n in names)
    src = full_by_module['actual169-proof4', module]
    cfg = read(src)
    full = copy.deepcopy(cfg)
    cfg['records'] = [next(r for r in full['records'] if r['original'] == n) for n in names]
    cfg['expectedSelectedRecordCount'] = len(names)
    cfg['expectedNamedRecordCount'] = len(names)
    cfg['expectedSourceProofRecordCount'] = 0
    # No omitted original proof is referenced by these exact source DAG records.
    absent = {r['original'] for r in cfg['proofValueResolutions']}
    assert not absent.intersection(dep for n in names for dep in rows[n]['constantDependencies'])
    cfg['deferredProofValueResolutions'] = cfg['proofValueResolutions']
    cfg['proofValueResolutions'] = []
    cfg['boundedScope'] = {'selectedOriginalNames': names,
        'sourceRecordCountRemains': 197, 'selectedSourceCountRemains': 173,
        'actualNamedCountRemains': 169, 'genuineSourceProofCountRemains': 4,
        'fullModulePlan': pin(src), 'fullProjectScope': str(D / 'source173-scope-and-byte-ranges.json'),
        'proofResolutionPolicy': 'No absent-proof constant occurs in the selected exact source DAGs. All four original proof resolutions remain in full-module configs and deferredProofValueResolutions.',
        'omittedModuleRecords': [r['original'] for r in full['records'] if r['original'] not in names],
        'whole173AcceptanceClaimed': False, 'broaderScopeAcceptanceClaimed': False}
    cfg['outputFile'] = str(D / 'results' / 'bounded' / (label + '.json'))
    Path(cfg['outputFile']).parent.mkdir(parents=True, exist_ok=True)
    dest = D / 'configs' / 'bounded' / (label + '.json')
    save(dest, cfg)
    batch_plans.append({'label': label, 'source': pin(auditor), 'config': pin(dest),
        'selectedOriginalNames': names, 'environment': {'MAIN_FIVE_IDENTITY_CONFIG': str(dest)},
        'task_type': 'review', 'target': 'file', 'parameters': {'source': str(auditor)},
        'expected_duration': '60s', 'expected_memory': '16GiB',
        'firstAttemptOnlyResourceEstimate': True, 'exclusive': True,
        'actualKernelComparisonPending': True, 'publishAllowed': False, 'finalAcceptance': False})
save(D / 'review-plan.json', {'schema': 'main5-next-root-review-plan/v1',
    'defaultIdentityReview': 'first-three', 'identityReviews': batch_plans,
    'all173ModulePlans': plans, 'sourceScope': pin(D / 'source173-scope-and-byte-ranges.json'),
    'materializationSource': pin(D / 'materialization/Definitions/Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound.lean'),
    'preRealizationImportedQuery': pin(D / 'queries/QueryImportedEquationsBeforeRealization.lean'),
    'workflow': ['Root integrates exactly the single local-simp insertion into native LogVolumeBound source.',
                 'Root compiles native LogVolumeBound artifact through MCP-CI. Use existing job measurements when available.',
                 'Root separately runs the imported environment query before any realization command.',
                 'Root runs bounded first-three identity in actual169-proof4 mode; this gate does not depend on new equation names.',
                 'Only after native materialization and imported owner/axiom gates pass may root use materialized172-proof1 full plans.',
                 'Run certificate-casesOn-pending as a separate strict comparison; an actual difference remains pending.'],
    'rootSubmissionFieldsStillRequired': ['language', 'project', 'absolute workspace', 'session_id', 'agent_id', 'worktree_manifest', 'idempotency_key', 'environment.LEAN_PATH'],
    'resourcePolicy': 'The new identity/query first attempts use60s/16GiB. Existing native source attempts use measured history. If a review exceeds16GiB, split records while retaining the full173 inventory.',
    'pendingInitialNamed': 200, 'priorNamedMappings': 615, 'acceptedPriorNamed': 415,
    'relativeOnly': True, 'publishAllowed': False, 'finalAcceptance': False,
    'compilerRun': False, 'CIInvoked': False, 'APIInvoked': False, 'mainWorkspaceWritten': False})
# Byte-for-byte auditor preserves all existing strict source/value/metadata checks.
assert auditor.read_bytes() == (V / 'AuditMainFiveRelative.lean').read_bytes()
base = (W / 'Definitions/Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound.lean').read_bytes()
materialized = (D / 'materialization/Definitions/Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound.lean').read_bytes()
insert = b'attribute [local simp] dstPlaces.eq_1 placeBound.eq_1 placeBound.eq_2\n\n'
assert base.replace(b'variable {inv}\n\ninclude est', insert + b'variable {inv}\n\ninclude est') == materialized
query = (D / 'queries/QueryImportedEquationsBeforeRealization.lean').read_text()
assert query.index('env.find?') < query.index('#check')
assert query.index('getModuleIdxFor?') < query.index('#check')
assert query.index('collectAxioms') < query.index('#check')
assert 'getEqnsFor?' not in query and 'attribute [' not in query
save(D / 'offline-verification.json', {'schema': 'main5-next-root-review-offline-checks/v1',
    'full173RecordsVerifiedAgainstExistingDagAndByteProfile': True,
    'sharedDagBytes': 8813934, 'source560MBArtifactRead': False,
    'completeBothVariantCoverage': {'actual169-proof4': {'selected': 173, 'named': 169, 'originalProofs': 4},
                                  'materialized172-proof1': {'selected': 173, 'named': 172, 'originalProofs': 1}},
    'auditorCopiedByteForByte': pin(auditor),
    'nativeSourceOnlyExactLocalSimpInsertion': True,
    'preRealizationQueryOwnerAndAxiomsBeforeAnyCheck': True,
    'boundedFirstThreeDagBytes': sum(rows[n]['viewBytes'] for n in FIRST),
    'boundedFirstThreeNames': FIRST, 'allNamedRelocationsRetained': 784,
    'dmodProofStandaloneAlias': None, 'dmodProofBody': 'Original exported IsScalarTower.rat proof retained in complete configs.',
    'certificateCasesOnActualComparisonPending': True, 'strictFlagsRelaxed': False,
    'relativeOnly': True, 'publishAllowed': False, 'finalAcceptance': False,
    'compilerRun': False, 'CIInvoked': False})
print(json.dumps({'directory': str(D), 'source173': 173, 'sharedDagBytes': 8813934,
                  'boundedFirstThreeDagBytes': sum(rows[n]['viewBytes'] for n in FIRST),
                  'reviewPlan': str(D / 'review-plan.json'), 'noCompilation': True}, indent=2))
