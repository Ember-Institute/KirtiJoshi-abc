# main5 下一步 root 审查草稿

未编译；全部结论保持 relative。`publishAllowed=false`，`finalAcceptance=false`。initial200 尚未完整验收；现有615项 prior map 中415项有既有接受记录、200项仍 pending。本目录不把这200项提升为 accepted，不提供 publication 入口。

## 可立即审查的 materialization 文件

- 源：`materialization/Definitions/Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound.lean`
- 补丁：`materialization/materialize-three-equations.patch`
- 独立导入查询：`queries/QueryImportedEquationsBeforeRealization.lean`

源与当前 native LogVolumeBound 完全一致，仅在 `dstPlaces` 后插入：

```lean
attribute [local simp] dstPlaces.eq_1 placeBound.eq_1 placeBound.eq_2
```

当前原源 SHA256 为 `56a5ef14ddd38021ee0db99f3c22cb00612f86deb921faf9f8566c28b23683ee`；草稿 SHA256 为 `50d3b71d6a3838c85bf7a33624f80cfc6bd97d9e68027158f74cf4437c6be350`。root 整合这一条命令后，须通过 MCP-CI 编译实际 `Definitions/Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound.lean`，使导入的 native artifact 持久化三条 reserved equation。

独立查询只 import Lean 与 native LogVolumeBound。第一个 `run_meta` 用 `env.find?` 读取导入环境，要求三条名称已经是 theorem，真实 owner 必须为 native LogVolumeBound，`collectAxioms` 必须恰为 `propext`、`Classical.choice`、`Quot.sound`。所有检查位于任何 `#check`/`#print` 之前；查询没有 equation 生成 API 或 materialization 命令。旧 artifact 未持久化方程时，应在第一个环境检查失败，不能靠后面的显示命令生成它们。

## 第一批 bounded identity

入口：`AuditMainFiveRelativeBounded.lean`；配置：`configs/bounded/first-three.json`；环境变量：

```text
MAIN_FIVE_IDENTITY_CONFIG=/tmp/p2m-main5-next-identity-v11-20261116/configs/bounded/first-three.json
```

这一批恰好比较三个原声明：`Iut.QPilotData`、`Iut.QPilotData.mk`、`Iut.QPilotData.casesOn`。对应 DAG 总大小68,165 bytes，节点数分别12、155、246，依次覆盖结构 metadata、构造子、具有计算值的消去定义。它仍执行原审查器的完整 type、data value、BinderInfo inventory/placement、recursor RHS、结构 metadata/autoParam、instance、owner 与公理检查。入口逐字复制 v9 审查器，不增加 heartbeat 或兼容例外。

`review-plan.json` 也列出这三条各自的单声明配置，以便按实际资源需要进一步拆分。三条原 DAG 没有引用四个缺失 proof Name；因此 bounded 配置不安装无关证明值，四条原值在 `deferredProofValueResolutions` 和完整模块配置中完整保留。所有784条已有 relocation（169本单元 +615 prior）仍保留；bounded 只缩小被比较的 `records`。

新入口的第一次 MCP-CI review 估计为60s/16GiB；native LogVolumeBound 已有历史，root 应用历史实测估计。所有任务均由 root 补齐实际 workspace、manifest、session/agent、幂等键、LEAN_PATH 后以 `exclusive:true` 提交。准备计划没有伪造这些会话字段或资源通过结论。

## 完整173项范围

`source173-scope-and-byte-ranges.json` 逐项给出173条原记录的精确原文件字节范围、各字段偏移/字节数、完整 DAG 路径与 SHA、原记录 raw SHA、Merkle roots、type/value/recursor/metadata 字段清单。复用 v9 的8,813,934 bytes共享DAG；本次没有打开或重新散列560,278,999 bytes的 `original-exprs.json`，没有运行 exporter。

`configs/full-plan/actual169-proof4/` 完整保留当前169 named +4 genuine source proof values；`configs/full-plan/materialized172-proof1/` 完整保留172 named +1 genuine proof value。两组分别恰好覆盖全部173项且不重复。三方程没有通过 native 持久化、独立 imported owner/axioms 和完整类型审查之前，只能使用169模式。

| 原模块 | selected | 当前 named + proof values | materialization 后 named + proof values |
| --- | ---: | ---: | ---: |
| LeftHandSide |25|25 +0|25 +0|
| RightHandSide |26|26 +0|26 +0|
| Statement |19|19 +0|19 +0|
| Invariants |71|70 +1|70 +1|
| LogVolumeBound |32|29 +3|32 +0|
| 合计 |173|169 +4|172 +1|

`Iut.Corollary312VariantData.dmod._proof_5` 始终保留来源中的真实 `IsScalarTower.rat` 证明体，按完整原类型进行 kernel 检查，`standaloneTargetIdentity=null`，没有制造 alias。包含它的父定义仍须通过完整计算值比较。

另备 `configs/bounded/certificate-casesOn-pending.json`，专门对 `Iut.Theorem110Certificate.casesOn` 进行实际严格比较。来源采用4.35的 `minor (projection major)` 形状，目前不能推断4.33 target 会通过；若实际 BinderInfo/计算值不同则保持 pending。不启用 C2/annotation/data-value 例外，不放宽任何 flag。

`offline-verification.json` 只记录离线清单与字节一致性；它不是 kernel 或公理验收。`review-plan.json` 给出 root 需要执行的具体入口、配置和先后门。source DAG、依赖与 native artifact 在 root 独占任务终态之前必须保持稳定。
