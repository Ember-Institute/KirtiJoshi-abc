# main5 v12 最小编译修复

两份修复源在 `ready/`；对应 `identity-syntax.patch` 与 `imported-query-namespace.patch` 可直接审查。原文件在 `originals/`，原 MCP-CI 回执、完整 stdout、stderr 在 `failure-evidence/`。`fix-evidence.json` 记录精确路径、前后 SHA256、诊断顺序和实际资源。

| 实际整合目标（相对 main-five-relative-v11-20261116） | 修复后 SHA256 |
| --- | --- |
| AuditMainFiveRelativeBounded.lean | fcbc613f23d9e71ad0da8f850ddb917a3397367130c7436f38cdda4fe95da647 |
| queries/QueryImportedEquationsBeforeRealization.lean | a9e0cc4948251fff4e77a4e4bd2545537ebf30d429074ca2568743bbdbd64319 |

`ci-016238-e91cd573` 首个错误为 decoder 第242行 do result Unit/Array Expr 不匹配，随后有缺少预期 Expr 类型和第248行 unexpected `|`。补丁在 `let e` 上增加 `: Expr`，并把 const、lam、forall、let、proj 的构造参数合并到同一行。除这一类型注释之外，整个文件的非空白 token 完全相同；decoder 后的共享重定位、kernel、type/value/BinderInfo、recursor、metadata/autoParam、owner/axiom 检查和执行入口全部字节相同。

对比 initial 的 `decodeExprDagNode : Except String Expr`，每个分支原本就有明确 Expr 预期类型；本修复给内嵌 match 同样的类型信息。C2 decoder 的 lam/forall/let/proj 分支也使用单行完整构造应用。未引入任何 C2 兼容证书或开关。

`ci-016239-6de9e807` 完整 stdout 的第一个且唯一错误是第18行 `Unknown identifier logInfo`。补丁仅改为 `Lean.logInfo`。`Lean.collectAxioms n` 不改：锁定4.33.1源码给出的签名正是 `[Monad m] [MonadEnv m] (constName : Name) : m (Array Name)`；通过的 C2 imported-owner 查询采用同一个调用及 `Lean.logInfo`。

查询保留原 `env.find?`、theorem kind、真实 imported owner 与精确三项公理相等 guard；这些检查仍在任何 `#check`/`#print` 之前。失败任务末尾显示三条方程不代表本次独立 guard 已执行通过，因为整个 `run_meta` 在日志名称解析处失败。独立 imported environment 验收仍待 root 实际重跑。

| 失败任务 | 墙钟秒（resources） | CPU总秒 | user / system秒 | 峰值RSS bytes |
| --- | ---: | ---: | --- | ---: |
| ci-016238-e91cd573 |54.074468100006925|52.05|6.54 /45.51|4968103936|
| ci-016239-6de9e807 |51.18810660002055|48.290000000000006|2.84 /45.45|4787589120|

上述资源只覆盖失败运行；两次 PSS 均未知。identity 还没有进入实际比较，不能把失败耗时或内存当作完整 identity 成功资源。root 对同一源的重试应保留这些实测依据并使用新幂等键。

root 已告知 native LogVolumeBound 的 `ci-016234` 叶检查与 `ci-016235` 产物编译成功；当前源 SHA 为 `50d3b71d6a3838c85bf7a33624f80cfc6bd97d9e68027158f74cf4437c6be350`。本补丁不改 native 源或任何配置，也不要求重新 materialize。

本目录未编译、未调用 CI/API/Git、未修改主工作区。现有173完整范围及169+4／172+1计划不变；initial200 gate 未提升，main5 仍 relative，publication 和 finalAcceptance 关闭。`prepare_fix.py` 只在本目录产生同一修复及证据。
