import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound

run_meta do
  let env ← Lean.getEnv
  for n in #[`AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.dstPlaces.eq_1,
      `AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound.eq_1,
      `AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound.eq_2] do
    let some ci := env.find? n | throwError "Missing persisted equation: {n}"
    let .thmInfo _ := ci | throwError "Expected compiler equation theorem: {n}"
    let some idx := env.getModuleIdxFor? n | throwError "Missing actual owner: {n}"
    let some imported := env.header.modules[idx.toNat]? | throwError "Missing indexed owner: {n}"
    unless imported.module == `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound do
      throwError "Equation has unexpected owner: {n}"
    let axs ← Lean.collectAxioms n
    unless axs.qsort Lean.Name.lt == #[`propext, `Classical.choice, `Quot.sound].qsort Lean.Name.lt do
      throwError "Equation axiom inventory differs from actual source: {n}"
    Lean.logInfo m!"Persisted native compiler equation present: {n}"

set_option pp.fullNames true
set_option pp.explicit true
set_option pp.universes true
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.dstPlaces.eq_1
#print AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.dstPlaces.eq_1
#print axioms AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.dstPlaces.eq_1
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound.eq_1
#print AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound.eq_1
#print axioms AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound.eq_1
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound.eq_2
#print AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound.eq_2
#print axioms AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound.eq_2
