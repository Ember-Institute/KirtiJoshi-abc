#!/usr/bin/env python3
"""Offline strict JSON shape audit and one schema-correct source fix. No compilation."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,difflib,shutil,collections
D=Path('/tmp/p2m-main5-array-fix-v14-20261116')
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A=W/'.local/adaptation/main-five-relative-v11-20261116'
B=W/'.local/adaptation/reference-main-bound-carriers-20261115'
S=W/'.local/adaptation/main-five-relative-v12-20261116/ready/AuditMainFiveRelativeBounded.lean'
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'sha256':sha(p)}
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
old=S.read_text()
before='    let actual ← namesFromJson (← checked (field record "axioms"))\n    unless actual.toArray.qsort Name.lt == expected.toArray.qsort Name.lt do'
after='    let actual := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName\n    unless actual.qsort Name.lt == expected.toArray.qsort Name.lt do'
assert old.count(before)==1
new=old.replace(before,after)
(D/'originals').mkdir(exist_ok=True);(D/'originals'/S.name).write_text(old)
(D/'ready').mkdir(exist_ok=True);(D/'ready'/S.name).write_text(new)
(D/'source-axiom-schema.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+S.name,tofile='b/'+S.name)))
# Check that the accepted compareRecord already uses precisely this string-array schema.
assert '(record.getObjValAs? (Array String) "axioms")).map String.toName' in old
assert new.replace(after,before)==old
counts=collections.Counter();paths=[];errors=[]
def fail(path,expected,v):
 errors.append({'inputPath':path,'expected':expected,'actualType':type(v).__name__,'actualValue':v})
def arr(v,path):
 counts['arrayParses']+=1;paths.append(path)
 if not isinstance(v,list):fail(path,'JSON array',v);return []
 return v
def string(v,path):
 if not isinstance(v,str):fail(path,'JSON string',v)
def name(v,path):
 a=arr(v,path);counts['encodedNameNodes']+=1
 if not a:return
 if len(a)!=3:fail(path,'[] or [parent, str|num, component]',v);return
 name(a[0],path+'[0]')
 if a[1]=='str':string(a[2],path+'[2]')
 elif a[1]=='num':
  if type(a[2])is not int or a[2]<0:fail(path+'[2]','natural number',a[2])
 else:fail(path+'[1]','str or num',a[1])
def names(v,path):
 for i,n in enumerate(arr(v,path)):name(n,f'{path}[{i}]')
def strings(v,path):
 for i,n in enumerate(arr(v,path)):string(n,f'{path}[{i}]')
def level(v,path):
 k=v['kind']
 if k=='param':name(v['name'],path+'.name')
 elif k=='succ':level(v['arg'],path+'.arg')
 elif k in ('max','imax'):level(v['left'],path+'.left');level(v['right'],path+'.right')
 elif k!='zero':fail(path+'.kind','zero|param|succ|max|imax',k)
def dag(v,path):
 nodes=arr(v['nodes'],path+'.nodes')
 for i,n in enumerate(nodes):
  p=f'{path}.nodes[{i}]';k=n['kind']
  if k in ('const','lam','forall','let','proj'):name(n['name'],p+'.name')
  if k=='sort':level(n['level'],p+'.level')
  if k=='const':
   for j,l in enumerate(arr(n['levels'],p+'.levels')):level(l,f'{p}.levels[{j}]')
 roots=arr(v['roots'],path+'.roots')
 for i,r in enumerate(roots):
  if type(r)is not int or not 0<=r<len(nodes):fail(f'{path}.roots[{i}]','valid DAG node index',r)
source_views={};record_paths={};configs=[];simulated=[]
for p in [A/'bound-configs/first-three.json']+sorted((A/'bound-full-configs').glob('*.json')):
 c=load(p);root=str(p)+'#';start=len(paths)
 for key in ['standardRenames','dataValueSubstitutions','newAliases','proofValueResolutions','records','projectMap']:
  arr(c[key],root+'.'+key)
 strings(c['allowedNativeModules'],root+'.allowedNativeModules')
 for i,r in enumerate(c['projectMap']):
  pr=f'{root}.projectMap[{i}]'
  name(r['originalName'],pr+'.originalName')
  if r['targetName']is not None:name(r['targetName'],pr+'.targetName')
  if r['targetToSourceUniverseIndices']is not None:
   for j,n in enumerate(arr(r['targetToSourceUniverseIndices'],pr+'.targetToSourceUniverseIndices')):
    if type(n)is not int or n<0:fail(f'{pr}.targetToSourceUniverseIndices[{j}]','natural number',n)
  if r['currentSelectedNamed']:names(r['expectedSourceAxioms'],pr+'.expectedSourceAxioms')
 for i,r in enumerate(c['proofValueResolutions']):
  pr=f'{root}.proofValueResolutions[{i}]';name(r['originalName'],pr+'.originalName');name(r['parentOriginalName'],pr+'.parentOriginalName');names(r['expectedSourceAxioms'],pr+'.expectedSourceAxioms')
  sp=Path(r['sourceView']['path']);sv=load(sp);assert sha(sp)==r['sourceView']['sha256']
  assert r['originalName']==sv['record']['nameExpr']
  assert r['standaloneTargetIdentity']is None
  # The old Lean path: namesFromJson(record.axioms), then decodeName on each STRING.
  ax=sv['record']['axioms'];arr(ax,str(sp)+'#.record.axioms')
  if ax and not isinstance(ax[0],list):
   simulated.append({'config':str(p),'sourceProof':r['original'],'call':'installMainOriginalProofValues -> namesFromJson(record.axioms) -> decodeName(axioms[0]) -> Json.getArr?',
      'inputPath':str(sp)+'#.record.axioms[0]','actualValue':ax[0],'actualType':type(ax[0]).__name__,'originalError':'array expected',
      'correctSchema':'Array String; exactly the schema already used by compareRecord',
      'expectedEncodedNamePath':pr+'.expectedSourceAxioms[0]','expectedEncodedNameValue':r['expectedSourceAxioms'][0]})
  source_views[str(sp)]=sp
 for r in c['records']:source_views[r['sourceView']['path']]=Path(r['sourceView']['path'])
 configs.append({'config':pin(p),'variant':c['variant'],'selected':len(c['records']),'named':c['expectedNamedRecordCount'],'proofs':c['expectedSourceProofRecordCount'],'projectMapRows':len(c['projectMap']),'arrayPathsChecked':len(paths)-start,'configModified':False})
for path,p in sorted(source_views.items()):
 v=load(p);r=v['record'];root=path+'#.record'
 name(r['nameExpr'],root+'.nameExpr');names(r['levelParams'],root+'.levelParams')
 for key in ['axioms','typeAxioms','valueAxioms','binderInventory']:strings(r[key],root+'.'+key)
 arr(r['recursorRuleRhs'],root+'.recursorRuleRhs')
 if r['structure']is not None:
  for key in ['fieldAutoParamExprs','fieldsInConstructorOrder']:arr(r['structure'][key],root+'.structure.'+key)
  names(r['structure']['projections'],root+'.structure.projections')
 dag(v['expressionDag'],path+'#.expressionDag')
 record_paths[r['name']]={'sourceView':pin(p),'axiomSchema':'Array String','encodedNameSchema':'recursive [] or [parent,tag,component]'}
full=[c for c in configs if c['variant']=='materialized172-proof1']
assert sum(c['selected']for c in full)==173 and sum(c['named']for c in full)==172 and sum(c['proofs']for c in full)==1
assert len(record_paths)==173 and len(simulated)==5 and not errors
# One complete list provides a concrete JSON path for every offline checked array site.
(D/'array-input-paths.jsonl').write_text(''.join(json.dumps({'inputPath':p},ensure_ascii=False)+'\n'for p in paths))
save(D/'schema-diagnosis.json',{'schema':'main5-v14-exact-array-schema-diagnosis/v1','configs':configs,'originalRuntimeErrorReproducedByStaticSchemaTrace':simulated,
 'correctedSchemaErrors':errors,'strictShapeCounts':dict(counts),'sourceRecordsChecked':173,'sourceRecordBindings':record_paths,
 'arrayInputPathInventory':pin(D/'array-input-paths.jsonl'),
 'threeNewEquationNamesAndDmodNameEncodingValid':True,'emptyDmodOriginalName':False,'configurationRepairRequired':False,
 'fixedSource':pin(D/'ready'/S.name),'beforeSource':pin(S),'patch':pin(D/'source-axiom-schema.patch'),
 'source560MBArtifactRead':False,'compilerRun':False,'CIInvoked':False,'APIInvoked':False,'GitInvoked':False,'mainWorkspaceWritten':False,
 'relativeOnly':True,'publishAllowed':False,'finalAcceptance':False})
receipts=[]
for p in sorted(B.glob('main5-relative-full-*-v13-result.json')):
 dst=D/'failure-evidence'/p.name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(p,dst);x=load(p)
 out=dst.with_suffix('.stdout.txt');out.write_text(x['result'].get('stdout',''));err=dst.with_suffix('.stderr.txt');err.write_text(x['result'].get('stderr',''))
 receipts.append({'job_id':x['job_id'],'status':x['status'],'receipt':pin(dst),'fullStdout':pin(out),'fullStderr':pin(err),'resources':x['resources'],'exit_code':x['result']['exit_code']})
save(D/'original-failure-index.json',{'receipts':receipts})
print(json.dumps({'sourceBefore':pin(S),'sourceAfter':pin(D/'ready'/S.name),'configs':len(configs),'sourceRecords':len(record_paths),'originalShapeFailures':len(simulated),'correctedShapeFailures':len(errors),'arrayPaths':len(paths),'noConfigChanges':True},indent=2))
