## 论文来源与适配范围

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 1 节，命题 1.8 的开头设定及 (ii) 的首句，印刷页与文件页均为第 18 页；(v) 全文，印刷页与文件页均为第 19 页。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。精确英文引文见上方英文部分的三个独立引文块，中间未引内容已省略。

该命题提供源码注释所指的挠点与约化背景。应用这类判据时，原文的局部域 $k$ 对应所保存数域的某个完备化。引文保留了 $l$ 为素数、$l\geq3$ 且 $l$ 在局部整数环中可逆等前提。它给出半稳定约化的条件判据，并未陈述本十字段结构，也不构造该结构的实例。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页；定义 3.1(b) 跨第 61–62 页的末句。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。精确英文引文见上方两个独立引文块，(b) 中间部分已省略。

原文的 $F$、$\overline F$ 和 $E_F$ 分别对应所保存的域、选定代数闭包及曲线。接口将字段 `fieldOfModuli` 定义的数域写为 $F_0=\mathbb Q(j(E))\subseteq F$。原文末句针对一组初始 $\Theta$ 数据中选定的素数 $l$；本接口则要求对**每个不小于 7 的素数 $\ell$** 都满足 Galois 扩张与次数互素条件。该量词属于接口的实际内容，并非对原句的逐字引用。同样，原文的“$2\cdot3$ 阶挠点”在此对应所有被 6 杀死的点，包括零点，不限于恰好具有阶 6 的点。

望月新一，*Inter-universal Teichmüller Theory IV*，同版，第 1 节，定义 1.9 在 (i) 之前的开头段落，印刷页与文件页均为第 21 页。精确英文引文见上方英文部分。

形式定义 `inertDeg` 使用对应素理想处剩余域的维数；引文给出完备局部域中的 $f_v$ 记号。这是其解释背景，不是接口中正性或求和上界的证明。关于位于其上、剩余特征、有限性、正性以及对**所有自然数 $q$** 求和的字段，都是本适配明确列出的辅助义务，不称为命题 1.8 中的某个原文段落。

所保存的 `badAll` 包含具有乘法约化的**所有**有限位，可包含剩余特征为 2 的位，也允许为空。它不等同于原文定义 3.1(b) 中指定的、剩余特征为奇数的非空集合 $\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}$。例外条件 $p(v)\ne2$ 仅出现在第七字段的蕴含中。本结构不提供初始 $\Theta$ 数据、数据提供者存在性定理、高度比较或 abc 结论。

## 直观解释（非严格）

对一条固定的椭圆曲线，这个命题汇集后续构造所需的整体算术条件及有限位之间的对应关系。提供该命题的证明，就要提供全部十个条件；仅仅定义它，并没有给出任何条件的证明。

