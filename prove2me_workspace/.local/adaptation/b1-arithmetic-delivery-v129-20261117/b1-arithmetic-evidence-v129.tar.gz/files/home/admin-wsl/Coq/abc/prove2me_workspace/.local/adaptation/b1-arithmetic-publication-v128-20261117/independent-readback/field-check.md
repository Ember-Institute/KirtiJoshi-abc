# Field-by-field dependency and quantifier check

The English original, Simplified Chinese translation, and Japanese translation describe the same three declarations. The translations were prepared from the English original with the allowed formal definitions available for checking. They are translations, not two further independent audits. The model label supplied in the task's startup record is `gpt-6.1-sol`.

## Declaration parameters

| Declaration | Parameters and mathematical assumptions | Output |
|---|---|---|
| `inertDeg` | A type `K : Type u`, its field structure, and `NumberField K` (characteristic zero and finite dimension over the rationals); a finite place `w` of `K`. The declared universe `v` is unused and adds no mathematical parameter. | A noncomputably defined natural number, obtained by `Ideal.inertiaDeg` of the associated prime ideal over the integers. |
| `badAll` | `C : EllipticCurveData.{u}`. Its bundled inputs are `F : Type u`, a field and number-field structure on `F`, `Fbar : Type u`, a field structure and an `F`-algebra structure on `Fbar`, the algebraic-closure property (algebraicity and algebraic closedness), `E : WeierstrassCurve F`, and its ellipticity property (unit discriminant). | A set of finite places of `C.F`, not a finiteness or nonemptiness proof. Membership uses only `F`, `E`, and their associated structures, not the chosen algebraic closure. |
| `CurveArithmetic` | The same bundled `C`, including its chosen algebraic closure, although only the torsion field below refers to that closure. | A proposition-valued structure with ten proof fields. No constructor application or inhabitant of the structure is supplied here. |

## Structure fields

Here `F₀ = ℚ(j(E))`; `p(a)` is the characteristic of the quotient of the ring of integers by the prime associated with `a`; `M(w)` is the expanded multiplicative-reduction predicate; and `f(w)` is the expanded residue-degree definition. Each row has been checked against all three language versions.

| Field | Quantifier or connective, in order | Semantic inputs | Dependencies on earlier structure fields |
|---|---|---|---|
| `sqrt_neg_one` | There exists `a ∈ F` such that `-1 = a·a`. | The field `F`. No designated square root is stored as data. | None. |
| `stable_reduction` | For every finite `w` of `F`, `G(w) ∨ M(w)`. Each side contains its own existential change over `F`. | `F`, `E`, each completion and its valuation ring; minimality compares changes over the completion. | None. |
| `six_torsion_rational` | For every point `P` over `Fbar`, if `6P = 0`, then there exists an `F`-point with base-change image `P`. | `F`, `E`, `Fbar`, and the specified algebra map; points include infinity. The quantifier is over points killed by six, not only points of exact order six. | None. |
| `galois_deg_prime` | For every natural `ℓ`, primality implies `7 ≤ ℓ` implies the conjunction of Galoisness and coprimality of `[F:F₀]` with `ℓ`. | `F`, `E.j`, `F₀`, its inclusion in `F`, natural-number finite dimension. Galoisness is algebraic separability and normality. | None. |
| `exists_liesOver` | For every finite `w` of `F`, there exists a finite `v` of `F₀` with the specified lying-over relation. | `F`, `E.j`, the induced inclusion of rings of integers, prime ideals attached to the places. | None. No use of `galois_deg_prime` in the field type. |
| `residueChar_liesOver` | For every finite `v` of `F₀`, then every finite `w` of `F`, lying over implies `p(w) = p(v)`. | Same fields and prime ideals; quotient-ring characteristic. | None. |
| `mult_invariant` | For every finite `v` of `F₀`, `p(v) ≠ 2` implies: for every `w`, then `w'` of `F`, lying over `v` for `w`, then lying over `v` for `w'`, then `M(w)` imply `M(w')`. | `F`, `E`, `F₀`, prime ideals, completions, valuation rings, multiplicative-reduction predicates. | None. In particular, `stable_reduction` is a separate field, not an extra premise inside this implication. |
| `badAll_finite` | `B = {w : M(w)}` is finite. | `C.badAll`, hence `F`, `E` and the expanded reduction predicate. | None. |
| `inertDeg_pos` | For every finite `w` of `F`, `0 < f(w)`. | The prime ideal of `w`, its contraction to the integers, and the induced extension of residue fields. | None. Applies to every finite place, not just `B`. |
| `sum_inertDeg_le` | For every `q ∈ ℕ`, sum `f(w)` over the finite set of `w ∈ B` with `p(w) = q`, then compare by `≤` with `[F:ℚ]`. | `F`, `E` via `B`, quotient characteristics, residue degrees, and the rational vector-space dimension of `F`. | Its written type uses `badAll_finite.toFinset`. It does not use the other eight fields as hypotheses. |

## Edge cases and scope checks

- No field requires `B` to be nonempty or restricts every element of `B` to odd residue characteristic. The invariance condition alone excludes residue characteristic two at its base place.
- `w` and `w'` need not be distinct; the relation is a directed implication for every ordered pair.
- `exists_liesOver` asserts existence without uniqueness and in the direction from a place of `F` to one of `F₀`; it does not itself assert a place of `F` exists above each place of `F₀`.
- The prime parameter in `galois_deg_prime` is universally quantified and not a chosen prime stored in this structure. Its lower bound is seven, not five. Neither zero nor one nor a composite satisfies its primality premise.
- The parameter `q` in `sum_inertDeg_le` has no primality or positivity premise. Zero, one, and composites are included; an empty filtered set gives zero.
- The torsion condition includes points of order dividing six, including the identity; no basis, representation, uniqueness of a preimage, or cardinality statement is added.
- The global change for a reduction predicate is over `F`. A separate change can be used at each place and in each alternative. The local minimality comparison is over `F_w`.
- `HasMultiplicativeReduction` uses `c₄`, not the coefficient `a₄`: its two extra conditions are `valuation(Δ) < 1` and `valuation(c₄) = 1`.
- The fallback zero in the general `Ideal.inertiaDeg` definition applies to nonprime ideals. The input here is the prime ideal attached to a finite place.
- The structure's fields request proofs; a structure declaration alone does not furnish the requested proof fields. No conclusion about a paper, external record, publication, or compilation status is included in the read-back.

## Language and terminology

No unresolved Chinese term was required to express these declarations, so the Chinese translation contains no terminology placeholder. It uses complete Chinese terms for field extension, prime ideal, residue field, residue characteristic, vector-space dimension, and reduction; Latin personal names in `Weierstrass` and `Galois` are retained as names. No external terminology source was consulted under the restricted-reading task. Japanese mathematical terms are direct translations of the formal concepts, with no claim of verification against a paper or a Japanese reference. Identifiers are retained only for exact alignment with the code.

## Reading boundary and action boundary

Only the target source, relevant imported local formal definitions, the necessary Mathlib formal definitions, `mission_auditor.md`, and the supplied three-language principles were read. Source comments were not treated as mathematical premises. No paper, source explanation, platform record, or other agent's interpretation was used. No compilation, CI submission, external API operation, Git operation, or workspace mutation was performed. All produced artifacts are confined to this `/tmp` directory.
