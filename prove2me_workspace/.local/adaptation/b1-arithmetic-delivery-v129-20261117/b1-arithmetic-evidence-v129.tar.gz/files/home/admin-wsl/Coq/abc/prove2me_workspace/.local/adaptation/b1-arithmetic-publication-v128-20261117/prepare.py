from pathlib import Path
import hashlib,json,shutil
from datetime import datetime,timezone
O=Path('/tmp/p2m-b1-arithmetic-publication-v126-20261117')
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
F=Path('/tmp/p2m-b1-arithmetic-fresh-blind-v120-20261117')
S=W/'Definitions/Def_AbcAdaptation_Reference_Iut_Concrete_CurveArithmetic.lean'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p): return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
frozen={str(p):sha(p) for p in F.iterdir() if p.is_file()}
assert sha(S)=='0ee6e966ec9e59489d248ecfb50865b23955413db3bd3ded7c7398bfcda244df'
Iurl='https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf'
IVurl='https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf'
quotes=[
 {'id':'I-3.1a','paper':'I','locator':'§3, Definition 3.1(a), complete item','printed_pages':[61],'file_pages':[61],
 'quote':r'$F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.'},
 {'id':'I-3.1b-final','paper':'I','locator':'§3, Definition 3.1(b), final sentence spanning the page break','printed_pages':[61,62],'file_pages':[61,62],
 'quote':r'Here, we suppose further that the field extension $F/F_{\mathrm{mod}}$ is Galois of degree prime to $l$, and that the $2\cdot3$-torsion points of $E_F$ are rational over $F$.'},
 {'id':'IV-1.8-setting','paper':'IV','locator':'§1, Proposition 1.8, opening setup and first sentence of (ii); separate excerpts','printed_pages':[18],'file_pages':[18],
 'quote':r'Let $k$ be a perfect field, $\overline k$ an algebraic closure of $k$. Write $G_k\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline k/k)$.'},
 {'id':'IV-1.8ii-opening','paper':'IV','locator':'§1, Proposition 1.8(ii), first sentence','printed_pages':[18],'file_pages':[18],
 'quote':r'Let $E_{\overline k}$ be an elliptic curve over $\overline k$ with origin $\epsilon_E\in E(\overline k)$.'},
 {'id':'IV-1.8v','paper':'IV','locator':'§1, Proposition 1.8(v), complete item','printed_pages':[19],'file_pages':[19],
 'quote':r'In the situation of (ii), suppose further that $k$ is a complete discrete valuation field with ring of integers $\mathcal O_k$, that $l\geq3$ is a prime number that is invertible in $\mathcal O_k$, and that $E_{\overline k}$ descends to an elliptic curve $E_k$ over $k$, all of whose $l$-torsion points are rational over $k$. Then $E_k$ has semi-stable reduction over $\mathcal O_k$ [i.e., extends to a semi-abelian scheme over $\mathcal O_k$].'},
 {'id':'IV-1.9-opening','paper':'IV','locator':'§1, Definition 1.9, opening paragraph before (i)','printed_pages':[21],'file_pages':[21],
 'quote':r'Let $F$ be a number field [i.e., a finite extension of the rational number field $\mathbb Q$], whose set of valuations we denote by $\mathbb V(F)$. Thus, $\mathbb V(F)$ decomposes as a disjoint union $\mathbb V(F)=\mathbb V(F)^{\mathrm{non}}\bigcup\mathbb V(F)^{\mathrm{arc}}$ of nonarchimedean and archimedean valuations. If $v\in\mathbb V(F)$, then we shall write $F_v$ for the completion of $F$ at $v$; if $v\in\mathbb V(F)^{\mathrm{non}}$, then we shall write $e_v$ for the ramification index of $F_v$ over $\mathbb Q_{p_v}$, $f_v$ for the residue field degree of $F_v$ over $\mathbb Q_{p_v}$, and $q_v$ for the cardinality of the residue field of $F_v$.'}
]
# The typography is transcribed into renderable mathematics; each excerpt is separately located.
q={x['id']:x['quote'] for x in quotes}
quote_md='\n\n'.join('> '+q[k] for k in ['I-3.1a','I-3.1b-final'])
iv_md='\n\n'.join('> '+q[k] for k in ['IV-1.8-setting','IV-1.8ii-opening','IV-1.8v'])
source_en=r'''## Paper source and adaptation scope

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Proposition 1.8, opening setup and opening sentence of (ii), printed/PDF page 18; complete item (v), printed/PDF page 19. Official original: '''+IVurl+r'''. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`.

The following three blocks are separate excerpts. The first gives the proposition's base-field setup; the second identifies the curve in (ii); the third gives all of (v). Intervening material is omitted.

'''+iv_md+r'''

This proposition supplies the torsion-and-reduction background named in the source comment. Its local field $k$ corresponds to a completion of the stored number field when one applies such a criterion. The quoted item retains the assumptions that $l$ is prime, $l\geq3$, and $l$ is invertible in the local integer ring. It states a conditional criterion for semi-stable reduction; it does not state this ten-field record or construct its inhabitants.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61; Definition 3.1(b), final sentence spanning printed/PDF pages 61–62. Official original: '''+Iurl+r'''. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`.

These are separate excerpts; the intervening part of item (b) is omitted.

'''+quote_md+r'''

Here the paper's $F$, $\overline F$, and $E_F$ correspond to the stored field, selected closure, and curve. The interface writes $F_0=\mathbb Q(j(E))\subseteq F$ for its field of moduli. The paper's sentence uses the selected prime $l$ in a collection of initial $\Theta$-data. The interface instead requires the Galois and coprimality condition for **every prime $\ell\geq7$**. This quantifier is part of the actual interface; it is not a verbatim quotation of that sentence. Likewise, “$2\cdot3$-torsion” corresponds here to all points killed by 6, including zero, not only points of exact order 6.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV*, same edition, §1, Definition 1.9, opening paragraph before (i), printed/PDF page 21:

> '''+q['IV-1.9-opening']+r'''

The formal definition `inertDeg` uses residue-field dimension at the corresponding prime ideal; the quotation gives the completed-local-field notation $f_v$. It is background for that interpretation, not a proof of the interface's positivity or sum bound. The fields about lying over, residue characteristics, finiteness, positivity, and the sum over **all natural numbers $q$** are explicit supporting obligations in this adaptation. They are not asserted to be a paragraph of Proposition 1.8.

The stored `badAll` consists of **all** finite places with multiplicative reduction. It may include residue characteristic 2 and may be empty. It is not identified with the paper's designated nonempty set $\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}$ of odd residue characteristic in Definition 3.1(b). The exception $p(v)\ne2$ occurs only in the seventh field's implication. The structure provides no initial $\Theta$-data, provider-existence theorem, height comparison, or abc conclusion.

## Intuitive explanation (non-rigorous)

For one fixed elliptic curve, the proposition collects the global arithmetic conditions and finite-place bookkeeping needed by later constructions. Supplying it means supplying every one of the ten conditions. Merely defining the proposition supplies none of them.
'''
source_zh=r'''## 论文来源与适配范围

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 1 节，命题 1.8 的开头设定及 (ii) 的首句，印刷页与文件页均为第 18 页；(v) 全文，印刷页与文件页均为第 19 页。官方原文：'''+IVurl+r'''。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。精确英文引文见上方英文部分的三个独立引文块，中间未引内容已省略。

该命题提供源码注释所指的挠点与约化背景。应用这类判据时，原文的局部域 $k$ 对应所保存数域的某个完备化。引文保留了 $l$ 为素数、$l\geq3$ 且 $l$ 在局部整数环中可逆等前提。它给出半稳定约化的条件判据，并未陈述本十字段结构，也不构造该结构的实例。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页；定义 3.1(b) 跨第 61–62 页的末句。官方原文：'''+Iurl+r'''。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。精确英文引文见上方两个独立引文块，(b) 中间部分已省略。

原文的 $F$、$\overline F$ 和 $E_F$ 分别对应所保存的域、选定代数闭包及曲线。接口将字段 `fieldOfModuli` 定义的数域写为 $F_0=\mathbb Q(j(E))\subseteq F$。原文末句针对一组初始 $\Theta$ 数据中选定的素数 $l$；本接口则要求对**每个不小于 7 的素数 $\ell$** 都满足 Galois 扩张与次数互素条件。该量词属于接口的实际内容，并非对原句的逐字引用。同样，原文的“$2\cdot3$ 阶挠点”在此对应所有被 6 杀死的点，包括零点，不限于恰好具有阶 6 的点。

望月新一，*Inter-universal Teichmüller Theory IV*，同版，第 1 节，定义 1.9 在 (i) 之前的开头段落，印刷页与文件页均为第 21 页。精确英文引文见上方英文部分。

形式定义 `inertDeg` 使用对应素理想处剩余域的维数；引文给出完备局部域中的 $f_v$ 记号。这是其解释背景，不是接口中正性或求和上界的证明。关于位于其上、剩余特征、有限性、正性以及对**所有自然数 $q$** 求和的字段，都是本适配明确列出的辅助义务，不称为命题 1.8 中的某个原文段落。

所保存的 `badAll` 包含具有乘法约化的**所有**有限位，可包含剩余特征为 2 的位，也允许为空。它不等同于原文定义 3.1(b) 中指定的、剩余特征为奇数的非空集合 $\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}$。例外条件 $p(v)\ne2$ 仅出现在第七字段的蕴含中。本结构不提供初始 $\Theta$ 数据、数据提供者存在性定理、高度比较或 abc 结论。

## 直观解释（非严格）

对一条固定的椭圆曲线，这个命题汇集后续构造所需的整体算术条件及有限位之间的对应关系。提供该命题的证明，就要提供全部十个条件；仅仅定义它，并没有给出任何条件的证明。
'''
source_ja=r'''## 論文の出典と適用範囲

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 1 節、命題 1.8 の冒頭の設定と (ii) の最初の文、印刷・PDF ファイルページ 18、および (v) 全文、印刷・PDF ファイルページ 19。公式原文：'''+IVurl+r'''。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。正確な英文は上の三つの独立した引用ブロックに示した。間の部分は省略した。

この命題は、ソースの注釈が示す等分点と還元の背景を与える。この種の判定法を適用する際、論文の局所体 $k$ は、格納された数体の完備化に対応する。引用では、$l$ が素数であり、$l\geq3$ であり、局所整数環で可逆であるという前提を保つ。これは半安定還元の条件付き判定法であり、この十フィールドの構造を述べたり、その元を構成したりするものではない。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61、および定義 3.1(b) の最後の文、印刷・PDF ファイルページ 61–62。公式原文：'''+Iurl+r'''。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。正確な英文は上の二つの独立した引用ブロックに示した。(b) の中間部分は省略した。

論文の $F$、$\overline F$、$E_F$ は、格納される体、指定された代数閉包、曲線にそれぞれ対応する。このインターフェースでは、そのモジュライ体を $F_0=\mathbb Q(j(E))\subseteq F$ と書く。論文の最後の文は、初期 $\Theta$ データの一組で選んだ素数 $l$ に関するものである。一方、このインターフェースは、**7 以上のすべての素数 $\ell$** について、ガロア拡大と次数の互いに素という条件を要求する。この量化は実際のインターフェースの内容であり、原文の逐語引用ではない。また、ここで「$2\cdot3$ 等分点」は、零点を含めて 6 倍が零となるすべての点を表し、位数がちょうど 6 の点だけを表すものではない。

望月新一、*Inter-universal Teichmüller Theory IV*、同版、第 1 節、定義 1.9 の (i) より前の冒頭段落、印刷・PDF ファイルページ 21。正確な英文は上の英語部分に示した。

形式的定義 `inertDeg` は、対応する素イデアルにおける剰余体の次元を用いる。引用は、完備局所体での記号 $f_v$ を与える。これはその解釈の背景であり、インターフェースの正値性や和の上界の証明ではない。上にあるという関係、剰余標数、有限性、正値性、および**すべての自然数 $q$** に関する和のフィールドは、この移植で明示する補助的義務である。これらを命題 1.8 の一つの原文段落とはしない。

格納される `badAll` は、乗法的還元を持つ**すべての**有限素点を含む。剰余標数 2 の素点を含んでもよく、空でもよい。これは、論文の定義 3.1(b) で指定される、奇数剰余標数を持つ非空集合 $\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}$ と同一視しない。例外条件 $p(v)\ne2$ は第七フィールドの含意だけに現れる。この構造は、初期 $\Theta$ データ、データ供給者の存在定理、高さの比較、abc の結論を与えない。

## 直観的説明（非厳密）

一つの固定した楕円曲線について、この命題は後の構成に必要な大域的算術条件と有限素点の対応関係をまとめる。この命題を与えるには、十条件すべてを与える必要がある。命題を定義するだけでは、いずれの条件の証明も得られない。
'''
for lang,src in [('en',source_en),('zh-Hans',source_zh),('ja',source_ja)]:
 (O/f'source-editorial.{lang}.md').write_text(src+'\n')
# Exact frozen readback text is embedded unchanged, not edited or re-derived.
texts={lang:(F/f'readback.{lang}.md').read_text() for lang in ['en','zh-Hans','ja']}
statement='\n\n'.join([texts['en'].rstrip()+'\n\n'+source_en,texts['zh-Hans'].rstrip()+'\n\n'+source_zh,texts['ja'].rstrip()+'\n\n'+source_ja])+'\n'
(O/'natural-language-statement.md').write_text(statement)
payload={'definition_name':'AbcAdaptation_Reference_Iut_Concrete_CurveArithmetic','definition_title':'Arithmetic conditions on an elliptic curve and its finite places — 椭圆曲线及其有限位的算术条件 — 楕円曲線とその有限素点の算術条件','definition':S.read_text(),'natural_language_statement':statement,'source':'Shinichi Mochizuki, Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations, April 2020, §1, Proposition 1.8 (opening setup and opening of (ii), p. 18; complete (v), p. 19), and Definition 1.9 opening, p. 21. Supporting original context: Inter-universal Teichmüller Theory I: Construction of Hodge Theaters, May 2020, §3, Definition 3.1(a), p. 61, and final sentence of (b), pp. 61–62. Printed and PDF file pages agree. The ten-field interface includes explicit adaptation obligations, not a verbatim theorem of the paper. '+IVurl+' '+Iurl,'env':'0df444a360eaa60ab8c11dca51a86af692955474','private':True}
(O/'payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
# Copy frozen materials under their own names without changing the source directory.
(O/'independent-readback').mkdir(exist_ok=True)
for p in F.iterdir():
 if p.is_file():shutil.copyfile(p,O/'independent-readback'/p.name)
base=W/'.local/adaptation/reference-main-bound-carriers-20261115/paper-materials-v1'
existing=json.loads((base/'paper-context.json').read_text())
papers={k:existing['paper_sources'][k] for k in ['I','IV']}
for k,paper in papers.items(): assert sha(Path(paper['local_pdf']))==paper['sha256']
images=[(Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/foundation-reference-carriers-20261115/paper-context-evidence/I-page-061.png'),'I-061.png',61),(O/'paper-evidence/I-062.png','I-062.png',62),(O/'paper-evidence/IV-001.png','IV-018.png',18),(O/'paper-evidence/IV-002.png','IV-019.png',19),(base/'evidence/IV-021.png','IV-021.png',21),(base/'evidence/I-001.png','I-cover.png',1),(base/'evidence/IV-001.png','IV-cover.png',1)]
evidence=[]
for source,name,page in images:
 dest=O/'paper-evidence'/name
 if source!=dest:shutil.copyfile(source,dest)
 evidence.append(dict(file_page=page,printed_page=page,visual_checked_this_editorial_session=True,**rec(dest)))
pc={'schema':'B1-CurveArithmetic-paper-context/v126','author':{'english':'Shinichi Mochizuki','Chinese':'望月新一','Japanese':'望月新一'},'papers':papers,'quotations':quotes,'visual_evidence':evidence,'typography':'Line breaks, line-end hyphenation and ligatures normalized; mathematical typography transcribed to renderable LaTeX. Separate excerpts remain separate; no editorial scope text is inside quotation blocks.','source_context_inputs':[rec(base/'paper-context.json'),rec(W/'.local/adaptation/b1-elliptic-publication-v121-20261117/paper-context.json')],'retrieval':'Existing original PDFs only; no network or new download. Acquisition date remains as recorded in pre-existing paper context.','editorial_only_not_new_independent_readback':True}
(O/'paper-context.json').write_text(json.dumps(pc,ensure_ascii=False,indent=2)+'\n')
receipt=W/'.local/adaptation/main-chain-open-20261116/b1-curve-arithmetic-fifteen-review-v124-result.json'
rd=json.loads(receipt.read_text());assert rd['job_id']=='ci-018609-6872e8a5' and rd['status']=='succeeded' and rd['result']['exit_code']==0
fields=['sqrt_neg_one','stable_reduction','six_torsion_rational','galois_deg_prime','exists_liesOver','residueChar_liesOver','mult_invariant','badAll_finite','inertDeg_pos','sum_inertDeg_le']
metadata={'schema':'B1-CurveArithmetic-private-definition-publication-draft/v126','status':'DRAFT_NOT_POSTED','created_utc':datetime.now(timezone.utc).isoformat(),'editorial_model':'gpt-6.1-sol','editorial_statement_not_new_independent_readback':True,'source':rec(S),'declarations':['AbcAdaptation.Reference.Iut.inertDeg','AbcAdaptation.Reference.Iut.EllipticCurveData.badAll','AbcAdaptation.Reference.Iut.EllipticCurveData.CurveArithmetic'],'field_inventory':fields,'independent_readback':{'directory':str(F),'readback_model':'gpt-6.1-sol','all_input_hashes_before_editing':frozen,'original_files_unchanged':all(sha(Path(p))==v for p,v in frozen.items()),'readback_texts_reused_verbatim':True,'translations_are_translations_not_separate_audits':True},'paper_context':rec(O/'paper-context.json'),'payload':rec(O/'payload.json'),'payload_format_reference':rec(W/'.local/adaptation/b1-elliptic-publication-v121-20261117/payload.json'),'publication':{'env':payload['env'],'definition_name':payload['definition_name'],'private':True,'posted':False},'accepted_complete_structure_review':{'receipt':rec(receipt),'job_id':rd['job_id'],'status':rd['status'],'exit_code':rd['result']['exit_code'],'review':rd['result']['review'],'resources':rd['resources'],'reader_did_not_run_job':True},'scope_checks':{'complete_inertDeg_definition':True,'complete_badAll_definition':True,'all_ten_fields':True,'six_means_killed_by_six_including_zero':True,'galois_all_primes_at_least_seven':True,'sum_over_all_naturals_including_zero_one_composites':True,'empty_badAll_permitted':True,'residue_two_exception_only_seventh_field':True,'paper_fixed_prime_not_silently_equated_to_universal_interface_quantifier':True,'paper_designated_bad_set_not_identified_with_badAll':True,'additional_interface_fields_not_claimed_verbatim_paper':True},'operations':{'CI_or_compiler_executed':False,'API_executed':False,'Git_executed':False,'main_workspace_written':False,'original_blind_readbacks_changed':False,'publication_performed':False},'body_process_metadata_separated':True}
(O/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
assert payload['definition']==S.read_text()
assert all(texts[l].rstrip() in statement for l in texts)
assert payload['private'] is True and not payload['definition_name'].startswith('Def_')
assert all(sha(Path(p))==h for p,h in frozen.items())
print(json.dumps({'directory':str(O),'payload_sha256':sha(O/'payload.json'),'source_sha256':sha(S),'readback_originals_unchanged':True,'statement_characters':len(statement)},ensure_ascii=False,indent=2))
