## Paper source and adaptation scope

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, Proposition 1.8, opening setup and opening sentence of (ii), printed/PDF page 18; complete item (v), printed/PDF page 19. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`.

The following three blocks are separate excerpts. The first gives the proposition's base-field setup; the second identifies the curve in (ii); the third gives all of (v). Intervening material is omitted.

> Let $k$ be a perfect field, $\overline k$ an algebraic closure of $k$. Write $G_k\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline k/k)$.

> Let $E_{\overline k}$ be an elliptic curve over $\overline k$ with origin $\epsilon_E\in E(\overline k)$.

> In the situation of (ii), suppose further that $k$ is a complete discrete valuation field with ring of integers $\mathcal O_k$, that $l\geq3$ is a prime number that is invertible in $\mathcal O_k$, and that $E_{\overline k}$ descends to an elliptic curve $E_k$ over $k$, all of whose $l$-torsion points are rational over $k$. Then $E_k$ has semi-stable reduction over $\mathcal O_k$ [i.e., extends to a semi-abelian scheme over $\mathcal O_k$].

This proposition supplies the torsion-and-reduction background named in the source comment. Its local field $k$ corresponds to a completion of the stored number field when one applies such a criterion. The quoted item retains the assumptions that $l$ is prime, $l\geq3$, and $l$ is invertible in the local integer ring. It states a conditional criterion for semi-stable reduction; it does not state this ten-field record or construct its inhabitants.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61; Definition 3.1(b), final sentence spanning printed/PDF pages 61–62. Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`.

These are separate excerpts; the intervening part of item (b) is omitted.

> $F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.

> Here, we suppose further that the field extension $F/F_{\mathrm{mod}}$ is Galois of degree prime to $l$, and that the $2\cdot3$-torsion points of $E_F$ are rational over $F$.

Here the paper's $F$, $\overline F$, and $E_F$ correspond to the stored field, selected closure, and curve. The interface writes $F_0=\mathbb Q(j(E))\subseteq F$ for its field of moduli. The paper's sentence uses the selected prime $l$ in a collection of initial $\Theta$-data. The interface instead requires the Galois and coprimality condition for **every prime $\ell\geq7$**. This quantifier is part of the actual interface; it is not a verbatim quotation of that sentence. Likewise, “$2\cdot3$-torsion” corresponds here to all points killed by 6, including zero, not only points of exact order 6.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV*, same edition, §1, Definition 1.9, opening paragraph before (i), printed/PDF page 21:

> Let $F$ be a number field [i.e., a finite extension of the rational number field $\mathbb Q$], whose set of valuations we denote by $\mathbb V(F)$. Thus, $\mathbb V(F)$ decomposes as a disjoint union $\mathbb V(F)=\mathbb V(F)^{\mathrm{non}}\bigcup\mathbb V(F)^{\mathrm{arc}}$ of nonarchimedean and archimedean valuations. If $v\in\mathbb V(F)$, then we shall write $F_v$ for the completion of $F$ at $v$; if $v\in\mathbb V(F)^{\mathrm{non}}$, then we shall write $e_v$ for the ramification index of $F_v$ over $\mathbb Q_{p_v}$, $f_v$ for the residue field degree of $F_v$ over $\mathbb Q_{p_v}$, and $q_v$ for the cardinality of the residue field of $F_v$.

The formal definition `inertDeg` uses residue-field dimension at the corresponding prime ideal; the quotation gives the completed-local-field notation $f_v$. It is background for that interpretation, not a proof of the interface's positivity or sum bound. The fields about lying over, residue characteristics, finiteness, positivity, and the sum over **all natural numbers $q$** are explicit supporting obligations in this adaptation. They are not asserted to be a paragraph of Proposition 1.8.

The stored `badAll` consists of **all** finite places with multiplicative reduction. It may include residue characteristic 2 and may be empty. It is not identified with the paper's designated nonempty set $\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}$ of odd residue characteristic in Definition 3.1(b). The exception $p(v)\ne2$ occurs only in the seventh field's implication. The structure provides no initial $\Theta$-data, provider-existence theorem, height comparison, or abc conclusion.

## Intuitive explanation (non-rigorous)

For one fixed elliptic curve, the proposition collects the global arithmetic conditions and finite-place bookkeeping needed by later constructions. Supplying it means supplying every one of the ten conditions. Merely defining the proposition supplies none of them.

