#!/usr/bin/env python3
"""Arithmetic15 evidence delivery; writes only this task /tmp. No CI/API/Git/compiler."""
import argparse,hashlib,io,json,os,tarfile
from pathlib import Path
T=Path('/tmp/p2m-b1-arithmetic-delivery-v129-20261117');R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation';C=A/'main-chain-open-20261116';S={'propext','Classical.choice','Quot.sound'}
JOBS={'leaf':('018590','b1-curve-arithmetic-leaf-v120-result.json'),'artifact':('018601','b1-curve-arithmetic-artifact-v122-result.json'),'nativeFacts':('018602','b1-curve-arithmetic-native-fifteen-facts-v122-result.json'),'review':('018609','b1-curve-arithmetic-fifteen-review-v124-result.json')}
FIELDS=['sqrt_neg_one','stable_reduction','six_torsion_rational','galois_deg_prime','exists_liesOver','residueChar_liesOver','mult_invariant','badAll_finite','inertDeg_pos','sum_inertDeg_le']
def read(p):return json.loads(Path(p).read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def walk(x):
 if isinstance(x,dict):
  yield x
  for v in x.values():yield from walk(v)
 elif isinstance(x,list):
  for v in x:yield from walk(v)
def nm(n):return '' if not n else nm(n[0])+('.' if n[0] else '')+str(n[2])
def resources(d):
 r=d.get('resources') or d.get('result',{}).get('resources') or {};t,u,s=[r.get(k) for k in ['cpu_time_seconds','cpu_user_seconds','cpu_system_seconds']]
 return {**r,'cpu_total_equals_user_plus_system':None if None in (t,u,s) else abs(t-u-s)<.02,'peak_rss_GiB':r.get('peak_rss_bytes')/1024**3 if r.get('peak_rss_bytes') is not None else None,'peak_pss_GiB':r.get('peak_pss_bytes')/1024**3 if r.get('peak_pss_bytes') is not None else None,'resource_source':r.get('resource_source',r.get('source')),'resource_degraded':r.get('degraded'),'memory_basis':'MCP-CI process-tree physical RSS/PSS bytes; missing values unknown'}

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,default=T/'final');ap.add_argument('--archive',action='store_true');ap.add_argument('--evidence-directory',type=Path,default=A/'b1-arithmetic-delivery-v129-20261117');ap.add_argument('--prior-directory',type=Path,default=A/'b1-existing-and-elliptic-delivery-v123-20261117');x=ap.parse_args();out=x.output.resolve();assert T in out.parents;out.mkdir(parents=True,exist_ok=True)
 N=A/'b1-arithmetic-native15-v122-20261117';D=A/'b1-arithmetic-review-v124-20261117';P=A/'b1-arithmetic-publication-v128-20261117';code=W/'Definitions/Def_AbcAdaptation_Reference_Iut_Concrete_CurveArithmetic.lean';prior=read(x.prior_directory/'archive-manifest.json');priorfiles={r['path']:r for r in prior['files']};files={};pins={};refs={};scan={};gates={};errors={};checked=[]
 def add(p,parse=False):
  p=Path(p).absolute();assert p.is_file(),'missing evidence '+str(p)
  if '.lake' in p.parts or p.suffix in {'.olean','.ilean','.ir','.o','.a','.so'}:
   pins[str(p)]={'path':str(p),'copied':False,'reason':'prebuilt only, not read or copied'};return
  digest=sha(p)
  if str(p) in priorfiles and priorfiles[str(p)]['sha256']==digest:
   old=priorfiles[str(p)];refs[str(p)]={'path':str(p),'sha256':digest,'bytes':p.stat().st_size,'priorArchiveSHA256':prior['archiveSHA256'],'priorMember':old['member']};return
  if str(p) not in files:
   files[str(p)]={'path':str(p),'sha256':digest,'bytes':p.stat().st_size,'member':'files/'+str(p).lstrip('/')}
   if parse and p.suffix=='.json' and (any(root in p.parents for root in [N,D,P]) or p.name.startswith('arithmetic-')):scan[str(p)]=p
 def gate(k,f):
  try:f();gates[k]=True
  except (OSError,AssertionError,KeyError,TypeError,ValueError) as e:gates[k]=False;errors[k]=str(e)
 receipts={k:(C/n,read(C/n)) for k,(_,n) in JOBS.items()}
 def ci():
  assert prior['completeNarrowUnit'] is True and prior['allMembersReopenedSHA256Verified'] is True and sha(prior['archive'])==prior['archiveSHA256']
  for role,(p,d) in receipts.items():
   q,r=d['request'],d['result'];assert d['job_id'].startswith('ci-'+JOBS[role][0]) and d['status']=='succeeded' and r['exit_code']==0
   assert Path(q['workspace'])==W and q['exclusive'] is True and r['snapshot']['workspace_mode']=='exclusive_worktree' and r['snapshot']['snapshot_id'] is None
   assert resources(d)['cpu_total_equals_user_plus_system'] is True and resources(d)['peak_rss_bytes']<=16*1024**3
   assert not [z for z in r.get('diagnostics',[]) if z.get('severity')=='error']
   if role=='review':
    v=r['review'];assert v['passed'] is True and v['checks']['no_sorryAx'] is True and v['checks']['assumptions_reported'] is True and not v['violations']
   add(p)
   for tag in ['request','submit']:
    side=p.with_name(p.name.replace('-result.json','-'+tag+'.json'))
    if side.is_file():add(side)
   for path,digest in q['worktree_manifest']['input_hashes'].items():
    pp=Path(path)
    if '.lake' in pp.parts:pins[path]={'path':path,'sha256':digest,'copied':False};continue
    assert sha(pp)==digest,'actual input changed '+path;add(pp,True)
   for art in r.get('artifacts',[]):pins[str(art)]={'path':str(art),'copied':False,'reason':'MCP-CI artifact reference, raw receipt preserved'}
 gate('four_successful_actual_jobs_inputs_review_and_prior_archive',ci)
 for directory in [N,D,P]:
  for folder,sub,names in os.walk(directory):
   sub[:]=[n for n in sub if n not in ['.lake','.git','__pycache__']]
   for n in names:
    if n not in ['credentials.json','.env']:add(Path(folder,n),True)
 add(code)
 source47=A/'b1-curve-data-v116-20261117/source-A-full-actual-facts.jsonl';consumer_edges_path=A/'b1-curve-data-v116-20261117/source-actual-consumer-edges.json'
 for pp in [source47,consumer_edges_path]:
  assert str(pp) in priorfiles and sha(pp)==priorfiles[str(pp)]['sha256'];add(pp)
 consumer_edges=read(consumer_edges_path);assert consumer_edges['existenceClosureClaimed'] is False
 actual_consumers=[e for e in consumer_edges['edges'] if nm(e['to']).startswith('Iut.EllipticCurveData.CurveArithmetic') or nm(e['to']) in ['Iut.inertDeg','Iut.EllipticCurveData.badAll']]
 assert actual_consumers
 def bindings():
  seen=set()
  while scan:
   key,p=scan.popitem()
   if key in seen:continue
   seen.add(key);doc=read(p)
   for node in walk(doc):
    if isinstance(node.get('path'),str) and node['path'].startswith('/') and '\n' not in node['path'] and len(node['path'])<4096 and isinstance(node.get('sha256'),str):
     pp=Path(node['path'])
     if '.lake' in pp.parts:pins[str(pp)]={k:v for k,v in node.items() if k in ['path','sha256','bytes']};continue
     assert sha(pp)==node['sha256'],'bound input changed '+str(pp)
     if 'contents' in node:assert read(pp)==node['contents']
     add(pp,True);checked.append({'path':str(pp),'sha256':node['sha256'],'boundBy':str(p),'priorArchiveReference':str(pp) in refs})
    for key,value in node.items():
     if isinstance(value,str) and value.startswith('/') and '\n' not in value and len(value)<4096 and not value.startswith('/-') and key.lower().endswith(('file','path')) and Path(value).is_file():add(value,True)
 gate('current_raw_bindings_and_prior_source47_bare_references',bindings)
 actual=read(D/'actual/arithmetic-fifteen-correspondence-audit.json');native=read(N/'actual/native15-facts.json');inputs=read(D/'arithmetic-fifteen-native-inputs.json');oldbare=read(D/'arithmetic-prior-bare-accepted-selection.json');meta=read(P/'metadata.json');counts={}
 def correspondence():
  nonlocal counts
  assert actual['schema']=='B1-arithmetic-fifteen-correspondence-audit/v122' and actual['compilerVersion']=='4.33.1' and actual['status']=='accepted' and actual['correspondenceAccepted'] is True
  assert len(actual['reports'])==15 and len(actual['actualPairs'])==15 and len(actual['nativeActualFacts'])==15
  assert actual['newAssumptionsIntroduced'] is False and actual['extraUnreachableGeneratedDeclarationsClaimedCompared'] is False
  assert (actual['structureCount'],actual['projectionCount'],actual['constructorCount'],actual['recursorCount'],actual['recursorRuleCount'],actual['instanceProjectionCount'])==(1,10,1,1,1,0)
  for r in actual['reports']:
   for k in ['strictCompleteTYPEBinderInfoEqual','completeTYPEKernelEqual','completeComputationMetadataEqual','instanceRegistrationEqual']:assert r[k] is True
   assert r['rawValueBinderInfoEqual'] is True and r['rawValueBinderDifferenceRetained'] is False
   assert r['isInstance'] is False and r['hasSorryAx'] is False and set(r['axioms'])<=S
  assert sum(r['completeValueKernelEqual'] is True for r in actual['reports'])==12
  assert sum(r['recursorRulesCompared'] for r in actual['reports'])==1
  assert len(actual['acceptedBareActualMap'])==12 and actual['acceptedBareActualMap']==oldbare['actualPairs']
  assert oldbare['acceptedReviewJob']=='ci-018597-7df8415e' and oldbare['correspondenceAccepted'] is True
  assert len(actual['resolvedPriorSeventeenAcceptedEdges'])==17
  assert all(r['priorAcceptedJob'] for r in actual['resolvedPriorSeventeenAcceptedEdges'])
  assert meta['field_inventory']==FIELDS and inputs['newSourceFieldsCount']==10
  assert len(inputs['sourceRecords'])==15 and len(native['records'])==15
  counts={'TYPE':15,'values':12,'structure':1,'fields':10,'constructor':1,'recursor':1,'recursorRHS':1,'instances':0,'priorBareMap':12,'acceptedPriorEdges':17}
 gate('full_fifteen_TYPE_twelve_values_ten_fields_recursor_and_seventeen_edges',correspondence)
 publication={}
 def pub():
  nonlocal publication
  payload=read(P/'payload.json');item=read(P/'published-item.json');r=read(P/'publish-result.json');j=read(P/'publish-journal.json');submit=read(P/'publish-submit.json')
  assert set(payload)=={'definition_name','definition_title','definition','natural_language_statement','source','env','private'} and payload['private'] is True
  assert payload['definition']==code.read_text()
  assert r['status']=='PUBLISHED' and r['kind']=='definition' and r['error_message']=='' and r['visibility']=='private'
  assert r['id']==submit['job_id']==j['job_id']=='5790aad1-b08e-49f5-aecf-43f9ebcf372c'
  assert r['theorem_id']==item['definition_id']==j['definition_id']=='c265ffbb-68b1-45f5-aa27-bc5c2a23329a'
  for k in ['definition_name','definition_title','definition','natural_language_statement','source']:assert payload[k]==item[k]
  for k,p in [('theorem_name','definition_name'),('theorem_title','definition_title'),('definitions','definition'),('natural_language_statement','natural_language_statement'),('source','source')]:assert r[k]==payload[p]
  assert item['visibility']=='private' and item['mathlib_rev']==payload['env']=='0df444a360eaa60ab8c11dca51a86af692955474'
  assert item['deprecated_at'] is None and item['deprecated_by'] is None
  assert all(read(P/'publication-validation.json').values())
  manifest=read(P/'independent-readback/input.manifest.json')
  assert manifest['readback_model']=='gpt-6.1-sol'
  for pin in manifest['inputs']:assert sha(pin['path'])==pin['sha256']
  assert (P/'independent-readback/input.target.lean').read_bytes()==code.read_bytes()
  publication={'definitionId':item['definition_id'],'jobId':r['id'],'name':payload['definition_name'],'visibility':'private','allFieldsExact':True}
 gate('actual_private_publication_exact_readback_and_original_blind_inputs',pub)
 complete=all(gates.values());write(out/'completion-gates.json',{'schema':'B1-Arithmetic15-delivery-gates/v129','completeNarrowUnit':complete,'gates':gates,'errors':errors,'scope':'CurveArithmetic complete10 fields + inertDeg + badAll + exact reachable15 + private publication','TateAccepted':False,'ModRepAccepted':False,'extraUnreachableGeneratedDeclarationsCovered':False,'initialThetaDataExistenceProved':False,'Height603FirstClassOpen':True,'mathematicalParentClosed':False,'CICompilerAPIGitExecuted':False,'mainWorkspaceWritten':False})
 ci_history=[]
 for role,(p,d) in receipts.items():
  q,r=d['request'],d['result'];ci_history.append({'role':role,'jobId':d['job_id'],'attemptId':d.get('attempt_id'),'status':d['status'],'exitCode':r.get('exit_code'),'rawReceipt':str(p),'sha256':sha(p),'actualArguments':r.get('actual_arguments'),'workspaceMode':r['snapshot']['workspace_mode'],'snapshotId':r['snapshot']['snapshot_id'],'resources':resources(d),'diagnostics':r.get('diagnostics'),'inputManifestPointer':str(p)+'#/request/worktree_manifest'})
 write(out/'ci-history.json',ci_history);write(out/'prebuilt-pins.json',list(pins.values()));write(out/'bound-input-checks.json',checked)
 write(out/'prior-evidence-references.json',{'priorDirectory':str(x.prior_directory),'archive':prior['archive'],'archiveSHA256':prior['archiveSHA256'],'archiveBytes':prior['archiveBytes'],'policy':'References resolve to prior archive members by exact SHA; do not copy source47, bare12 or old large inputs again. Keep both archives for restoration.','members':list(refs.values())})
 ledger={'schema':'B1-Arithmetic15-compact-ledger/v129','status':'ACCEPTED_NARROW_UNIT' if complete else 'PENDING_GATES','counts':counts,'fields':FIELDS,'source':{'path':str(code),'sha256':sha(code)},'publication':publication,'actualRows':[{k:v for k,v in r.items() if k!='actualRuleReports'} for r in actual['reports']],'producerConsumers':[{'source':r['source'],'target':r['target']} for r in actual['actualPairs']],'acceptedBareActualMap':actual['acceptedBareActualMap'],'resolvedPriorSeventeenAcceptedEdges':actual['resolvedPriorSeventeenAcceptedEdges'],'actualB1SourceConsumerEdges':{'priorEvidencePath':str(consumer_edges_path),'sha256':sha(consumer_edges_path),'selectedActualEdges':actual_consumers,'existenceClosureClaimed':False},'source47PriorPin':{'path':str(source47),'sha256':sha(source47)},'consumerMeaning':'Actual B1 source dependencies resolved to the prior accepted declarations; no existence witness is supplied by the data structure.','priorArchiveSHA256':prior['archiveSHA256'],'rawEvidenceOutsideArchiveCopied':False,'source47RepeatedInThisArchive':False,'TateAccepted':False,'ModRepAccepted':False,'extraUnreachableGeneratedDeclarationsCovered':False,'initialThetaDataConstructed':False,'initialThetaDataExistenceProved':False,'Height603FirstClassOpen':True,'mathematicalParentClosed':False};write(out/'SOURCE_LEDGER.json',ledger)
 write(out/'root-application.json',{'evidenceDirectory':str(x.evidence_directory),'copyCompleteOutputDirectory':True,'keepPriorArchiveRequired':True,'overwriteOldLedger':False,'newMarkdownDocumentCreated':False,'cleanupDeletePaths':[],'scope':'Arithmetic15 unit only. Tate/ModRep and existence remain open.'})
 add(Path(__file__))
 for p in out.iterdir():
  if p.is_file() and p.suffix=='.json' and p.name!='archive-manifest.json':add(p)
 manifest={'schema':'B1-Arithmetic15-content-archive/v129','completeNarrowUnit':complete,'archiveCreated':False,'files':[files[k] for k in sorted(files)],'priorArchiveSHA256':prior['archiveSHA256'],'priorReferencesFile':'prior-evidence-references.json','restoreRequiresPriorArchive':True};write(out/'archive-manifest.json',manifest)
 if x.archive:
  assert complete,'completion gates failed';archive=out/'b1-arithmetic-evidence-v129.tar.gz';idx=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
  with tarfile.open(archive,'w:gz') as t:
   i=tarfile.TarInfo('archive-index.json');i.size=len(idx);t.addfile(i,io.BytesIO(idx))
   for row in manifest['files']:assert sha(row['path'])==row['sha256'];t.add(row['path'],arcname=row['member'],recursive=False)
  with tarfile.open(archive,'r:gz') as t:
   assert len(t.getmembers())==len(manifest['files'])+1 and t.extractfile('archive-index.json').read()==idx
   for row in manifest['files']:
    f=t.extractfile(row['member']);h=hashlib.sha256()
    for b in iter(lambda:f.read(1048576),b''):h.update(b)
    assert h.hexdigest()==row['sha256'] and sha(row['path'])==row['sha256']
  manifest.update(archiveCreated=True,archive=str(archive),archiveSHA256=sha(archive),archiveBytes=archive.stat().st_size,allMembersReopenedSHA256Verified=True);write(out/'archive-manifest.json',manifest)
 print(json.dumps({'completeNarrowUnit':complete,'gates':gates,'errors':errors,'counts':counts,'fileCount':len(files),'priorReferenceCount':len(refs),'output':str(out),'archiveCreated':manifest['archiveCreated']},ensure_ascii=False))
if __name__=='__main__':main()
