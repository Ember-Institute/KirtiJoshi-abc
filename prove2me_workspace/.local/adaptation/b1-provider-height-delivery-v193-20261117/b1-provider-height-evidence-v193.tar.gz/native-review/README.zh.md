# Provider4 / localHeightData 最小完整审查草稿 v186

所有写入限于本目录。未运行 Lean、MCP-CI、平台 API、Git；Lean 文件尚未验收。

- `queries/QueryProviderHeightNativeActualFactsV186.lean`：导入两个拟新增 canonical bundle，按真实 owner 枚举全部实际 constants；导出完整 `NameExpr`、TYPE、value、kind、universes、instance、structure/computation metadata、recursor RHS、标准公理。直接项目依赖仅一层 full facts，不重导出旧大库。配置 `queries/native-facts.config.json`；环境变量 `B1_PROVIDER_HEIGHT_NATIVE_FACTS_V186`。
- `prepare_review.py`：读取真实库存与 v184 完整 sourcefacts，构造最小直接项目边界并绑定完整输入；拒绝把未取得 fullproof 的 `residueChar_prime` 申报为旧边界。`--provider-only` 生成独立 Provider 审查；组合审查必须传 `--residue-source <actual-facts.json>`。
- `queries/AuditProviderHeightNativeCorrespondenceV186.lean`：配置环境变量 `B1_PROVIDER_HEIGHT_NATIVE_REVIEW_V186`。公开命名根按实际库存 `NameExpr/owner` 绑定；生成证明仅按完整 relocated TYPE 的唯一 kernelEq 候选定位，不使用 `_proof_N` 编号配对。随后独立检查原始完整 source/native value 的类型与 kernelEq，严格公开 binder、逐参数依赖域与结果、深层 binder 差异、ctor/recursor、完整 metadata、公理。source/native API 差异不改写，诊断保留原完整双方 facts。

示例（只是准备 JSON，不编译）：

```text
python3 prepare_review.py --native audit/native-actual-facts.json --provider-only
python3 prepare_review.py --native audit/native-actual-facts.json --residue-source <source4.35 actual-facts.json>
```

Provider 完整结构保留四字段 `torsionFinite3/torsionFinite5/arith/modRep`，核验一个 ctor、一个 recursor 和一个完整规则 RHS。Provider.curve 保留原 P/x 两参数及其真实 selector body。localHeightData 保留 C/CA/TI 三参数，核验原 `LocalHeightData.mk` 全部十一实参；每项抽象回原参数并逐项 `kernelEq`，无替代非命题 Data。

现有 ECD、CA、TI、ModRep、CurveOf、LHD/height 是明确已有边界。旧 v140 只接受十八数学对应、两 source-only、两不同命题 native proof 合法性；本稿不扩大为二十数学双射。旧 v182 torsionfree 整体 Prop 证书没有应用到本轮 lemma。本稿不做新的 whole-Prop 替换；原 proof 无法在 native API 下复核时必须报告失败，由主智能体决定下一合法证明步骤。

现有实际消费者来自 v184 `actual-consumer-edges.json`：四 Provider 字段供给 CurveProviders.curve / arith / modRep；curve 供给原 tate/localData；原 EllipticCurveData.localHeightData 供给原 CurveProviders.localData，继而经 LocalHeightData.height 到原 CurveProviders.h。Tate supplier 仍未提供，本稿没有新增参数或改变实际 height 定义。仅审查 Provider/条件 C/CA/TI 装配，不宣称 P.h 或 B1 完成。

主智能体统一从实际工作区 exclusive MCP-CI；每个首次新叶 `expected_duration: 60s`、`expected_memory: 16GiB`。本目录不包含任何编译成功声明。
