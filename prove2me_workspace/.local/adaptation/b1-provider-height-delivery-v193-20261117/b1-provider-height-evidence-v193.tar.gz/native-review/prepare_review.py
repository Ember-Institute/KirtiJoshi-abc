from pathlib import Path
import json, hashlib, argparse
D=Path('/tmp/p2m-b1-provider-height-native-audit-v186-20261117')
S=Path('/tmp/p2m-b1-provider-height-draft-v184-20261117')
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
def read(p): return json.loads(Path(p).read_text())
def save(p,x): Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def enc(s):
 n=[]
 for c in s.split('.'): n=[n,'str',c]
 return n
parser=argparse.ArgumentParser()
parser.add_argument('--native',type=Path,default=D/'audit/native-actual-facts.json')
parser.add_argument('--output-directory',type=Path,default=D/'audit')
parser.add_argument('--residue-source',type=Path)
parser.add_argument('--provider-only',action='store_true')
a=parser.parse_args()
provider_names=['Iut.Tripod.CurveProviders'+x for x in ['', '.torsionFinite3','.torsionFinite5','.arith','.modRep','.mk','.rec','.curve','.curve._proof_1','.curve._proof_2']]
height_names=['Iut.EllipticCurveData.localHeightData'+x for x in ['', '._proof_1','._proof_2','._proof_3','._proof_4']]
selected=provider_names if a.provider_only else provider_names+height_names
allrows={r['name']:r for r in [read(p) for p in (S/'source').glob('fact-*.json')]}
rows=[allrows[n] for n in selected]
prime_roots=[]
if not a.provider_only:
 if not a.residue_source: parser.error('combined review requires complete --residue-source; provider-only does not')
 prime=read(a.residue_source)
 if prime['schema']!='B1-residueChar-prime-complete-source-facts/v184' or prime['compilerVersion']!='4.35.0-rc3': raise ValueError('wrong original residueChar_prime facts')
 prime_roots=[r for r in prime['facts'] if r['record']=='fullActualFact']
 if not any(r['name']=='Iut.residueChar_prime' for r in prime_roots):raise ValueError('Missing actual residueChar_prime fullproof')
 rows+=prime_roots
native=read(a.native)
if native['schema']!='B1-provider-height-native-actual-facts/v186' or native['compilerVersion']!='4.33.1':raise ValueError('wrong actual native inventory')
native_rows={r['name']:r for r in native['facts']+native['directProjectBoundaries']}
def target(n):
 if n.startswith('Iut.Tripod.'):return n.replace('Iut.Tripod.','AbcAdaptation.Tripod.',1)
 if n.startswith('Iut.'):return n.replace('Iut.','AbcAdaptation.Reference.Iut.',1)
 if n.startswith('Genl.'):return n.replace('Genl.','AbcAdaptation.Reference.Genl.',1)
 raise ValueError(n)
def constants(e):
 if isinstance(e,dict):
  if e.get('kind') in ['const','proj']:yield e['name']
  for v in e.values():yield from constants(v)
 elif isinstance(e,list):
  for v in e:yield from constants(v)
def dec(n):return '' if n==[] else dec(n[0])+('.' if n[0] else '')+str(n[2])
new_names={r['name'] for r in rows}
used=set()
for r in rows:
 for e in [r['actualTypeExpr'],r['actualValueExpr'],r['metadata']]:
  used.update(dec(n) for n in constants(e) if dec(n).startswith(('Iut.','Genl.','AbcAdaptation.','_private.')))
boundary_src=read(S/'audit/ready-source-project-boundaries.json')['boundaryRecords']
boundary_rows={r['name']:r for r in boundary_src}
# Only project constants directly present in complete selected TYPE/value/metadata.
boundary_names=sorted(used-new_names)
missing=[n for n in boundary_names if n not in boundary_rows]
if missing:raise ValueError('Need additional original boundary facts: '+str(missing))
explicit=[]; generated=[]; boundaries=[]
for r in rows:
 if '._proof_' in r['name'] or (r['name'].startswith('Iut.residueChar_prime.') and r['isProposition']):
  generated.append(r['nameExpr']);continue
 t=target(r['name'])
 if t not in native_rows:raise ValueError('Actual new target missing '+t)
 nr=native_rows[t]
 explicit.append({'sourceNameExpr':r['nameExpr'],'targetNameExpr':nr['nameExpr'],'targetOwnerNameExpr':nr['ownerNameExpr']})
for n in boundary_names:
 t=target(n)
 if t not in native_rows:raise ValueError('Actual direct native boundary missing '+t)
 nr=native_rows[t]
 if n=='Iut.residueChar_prime':raise ValueError('residueChar_prime must never be accepted as old boundary')
 boundaries.append({'sourceNameExpr':boundary_rows[n]['nameExpr'],'targetNameExpr':nr['nameExpr'],'targetOwnerNameExpr':nr['ownerNameExpr'],'sourceBoundaryRecord':boundary_rows[n],'actualNativeBoundaryRecord':nr})
reg=read(W/'.local/adaptation/platform-node-registry.json')
# Preserve small exact registry acceptance entries, not the complete old source library.
def findkey(x,key):
 if isinstance(x,dict):
  if key in x:return x[key]
  for v in x.values():
   z=findkey(v,key)
   if z is not None:return z
 elif isinstance(x,list):
  for v in x:
   z=findkey(v,key)
   if z is not None:return z
 return None
keys=['b1_elliptic_curve_data_definition','b1_curve_arithmetic_definition','b1_curve_tate_modrep_data_definition','b1_curveof_fields_data_unit','b1_complete_conditional_curveof_unit']
reused={k:findkey(reg,k) for k in keys}
if any(v is None for v in reused.values()):raise ValueError('missing registered acceptance')
data={'schema':'B1-provider-height-source-native-bound-inputs/v186','providerOnly':a.provider_only,'sourceRecords':rows,'explicitActualPairs':explicit,'supportSourceNames':generated,'acceptedBoundaryPairs':boundaries,'nativeInventory':native,'reusedRegistryAcceptance':reused,'originalCompatibilityScope':read(S/'audit/existing-compatibility-scope.json'),'sourceFactsBinding':{'v184Directory':str(S),'residueFactsFile':str(a.residue_source) if a.residue_source else None,'residueFactsSHA256':hashlib.sha256(a.residue_source.read_bytes()).hexdigest() if a.residue_source else None},'proofNumbersUsedAsPairingEvidence':False}
suffix='provider-only' if a.provider_only else 'provider-height'
out=a.output_directory.resolve();out.mkdir(parents=True,exist_ok=True)
bound=out/f'{suffix}.bound-inputs.json';save(bound,data)
save(out/f'{suffix}.review.config.json',{'schema':'B1-provider-height-native-review-config/v186','boundInputsFile':str(bound),'boundInputsBinding':{'contents':data},'outputFile':str(out/f'{suffix}.correspondence-review.json')})
print(bound)
print('source rows',len(rows),'explicit roots',len(explicit),'Prop support candidates',len(generated),'minimal boundaries',len(boundaries))
