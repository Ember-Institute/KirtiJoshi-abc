import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveProviders
import Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_LocalHeightDataAssembly

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare

namespace ProviderHeightNativeReview
open Lean Elab Term Meta FoundationAudit BasicNativeCompare

def sameBound (label : String) (a b : Json) : MetaM Unit :=
  unless a == b do throwError "Bound actual fact differs {label}"

def writeOutput (path : String) (j : Json) : MetaM Unit := do
  unless path.startsWith "/" do throwError "Expected absolute output path"
  if let some parent := (System.FilePath.mk path).parent then IO.FS.createDirAll parent
  IO.FS.writeFile path (j.pretty ++ "\n")

def actualFactMatchesEnvironment (row : Json) : MetaM Unit := do
  let n ← checked (decodeName (← checked (field row "nameExpr")))
  let ci ← getConstInfo n
  unless moduleOf (← getEnv) n == some (← checked (decodeName (← checked (field row "ownerNameExpr")))) do
    throwError "Bound actual native inventory owner differs {n}"
  unless kind ci == (← checked (stringField row "kind")) &&
      ci.levelParams.toArray.map encodeName == (← checked (arrayField row "levelParams")) &&
      Lean.Meta.isInstanceCore (← getEnv) n == (← checked (row.getObjValAs? Bool "isInstance")) do
    throwError "Bound actual native metadata differs {n}"
  sameBound s!"native inventory complete TYPE {n}" (← checked (field row "actualTypeExpr")) (← checked (encodeExpr ci.type))
  let actualValue ← match ci.value? (allowOpaque := true) with
    | none => pure Json.null
    | some v => checked (encodeExpr v)
  sameBound s!"native inventory complete value {n}" (← checked (field row "actualValueExpr")) actualValue
  sameBound s!"native inventory computation metadata {n}"
    (← checked (field (← checked (field row "metadata")) "computationShape"))
    (← checked (computationShape ci pure))
  let inventoryAxioms ← collectAxioms n
  ensureStandard s!"native inventory {n}" inventoryAxioms
  sameBound s!"native inventory full declaration axioms {n}"
    (← checked (field row "axioms")) (toJson ((inventoryAxioms.qsort Name.lt).map Name.toString))
  let storedStructure ← checked (field (← checked (field row "metadata")) "structure")
  match getStructureInfo? (← getEnv) n with
  | none => unless storedStructure == Json.null do throwError "Unexpected inventory structure metadata {n}"
  | some si =>
    sameBound s!"native inventory complete structure metadata {n}"
      (← checked (field storedStructure "completeMetadata")) (← checked (structureShape si pure))
    let autoParams ← si.fieldInfo.mapM fun f => do
      match f.autoParam? with
      | none => pure Json.null
      | some e => checked (encodeExpr e)
    sameBound s!"native inventory autoParam Exprs {n}"
      (← checked (field storedStructure "fieldAutoParamExprs")) (Json.arr autoParams)
  if let .recInfo info := ci then
    let rules ← checked (arrayField (← checked (field row "metadata")) "recursorRules")
    unless rules.size == info.rules.length do throwError "Native inventory recursor rule count differs {n}"
    for k in [:rules.size] do
      sameBound s!"native inventory full recursor RHS {n}:{k}"
        (← checked (field rules[k]! "rhs")) (← checked (encodeExpr info.rules[k]!.rhs))

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]

def canonicalStructureMetadata (j : Json) : MetaM Json := do
  let fields ← (← checked (arrayField j "fieldsSortedByName")).mapM fun r => do
    return (← checked (decodeName (← checked (field r "fieldName"))),r)
  return Json.mkObj [
    ("structure",← checked (field j "structure")),
    ("fieldNamesInConstructorOrder",← checked (field j "fieldNamesInConstructorOrder")),
    ("fieldsSortedByName",Json.arr ((fields.qsort fun a b => Name.lt a.1 b.1).map (·.2))),
    ("parentsInExtendsOrder",← checked (field j "parentsInExtendsOrder"))]

def commonUniverses (ps : List Name) : List Level :=
  (List.range ps.length).map fun k => Level.param (.num (.str .anonymous "_B1ProviderHeightUniverse") k)

def publicDomains (label : String) (st tt : Expr) : MetaM (Array Json) :=
  forallTelescope st fun xs sourceResult => do
    let mut reports : Array Json := #[]
    let mut targetRest := tt
    let mut previous : Array Expr := #[]
    for k in [:xs.size] do
      let x := xs[k]!
      let decl ← x.fvarId!.getDecl
      match targetRest with
      | .forallE _ domain body bi =>
        unless decl.binderInfo == bi do throwError "Strict public BinderInfo differs {label}:{k}"
        let sd ← mkLambdaFVars previous decl.type
        let td ← mkLambdaFVars previous domain
        kernelEq s!"complete public parameter domain {label}:{k}" sd td
        reports := reports.push (Json.mkObj [
          ("index",toJson k),("binderInfo",toJson (encodeBinder bi)),
          ("completeDomainKernelEqual",toJson true),
          ("completeSourceDomain",← checked (encodeExpr sd)),
          ("completeNativeDomain",← checked (encodeExpr td))])
        targetRest := body.instantiate1 x
        previous := previous.push x
      | _ => throwError "Native telescope ended early {label}:{k}"
    unless outerForallBinderInfo targetRest == #[] do throwError "Extra native public parameters {label}"
    let sr ← mkLambdaFVars xs sourceResult
    let tr ← mkLambdaFVars xs targetRest
    kernelEq s!"complete public telescope result {label}" sr tr
    return reports

def projectName (n : Name) : Bool :=
  #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n)

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_PROVIDER_HEIGHT_NATIVE_REVIEW_V186")
  unless (← checked (stringField cfg "schema")) == "B1-provider-height-native-review-config/v186" do
    throwError "Wrong provider/height native review configuration"
  let data ← jsonFile (← checked (stringField cfg "boundInputsFile"))
  sameBound "complete bound input file" data (← checked (field (← checked (field cfg "boundInputsBinding")) "contents"))
  unless (← checked (stringField data "schema")) == "B1-provider-height-source-native-bound-inputs/v186" do
    throwError "Wrong complete bound input schema"
  let providerOnly ← checked (data.getObjValAs? Bool "providerOnly")
  let output ← checked (stringField cfg "outputFile")
  let rows ← checked (arrayField data "sourceRecords")
  let inventory ← checked (field data "nativeInventory")
  unless (← checked (stringField inventory "schema")) == "B1-provider-height-native-actual-facts/v186" &&
      (← checked (inventory.getObjValAs? Bool "allNewOwnerConstantsEnumerated")) do
    throwError "Missing complete actual new owner inventory"
  let nativeRows ← checked (arrayField inventory "facts")
  let nativeBoundaries ← checked (arrayField inventory "directProjectBoundaries")
  for r in nativeRows ++ nativeBoundaries do actualFactMatchesEnvironment r
  let selectedOwners ← namesFromJson (← checked (field inventory "selectedOwners"))
  let env ← getEnv
  let actualOwned := (env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any selectedOwners.contains then acc.push n else acc)
    (#[] : Array Name)).qsort Name.lt
  sameBound "all actual new owner names" (Json.arr (actualOwned.map encodeName)) (← checked (field inventory "actualNames"))
  unless actualOwned.size == nativeRows.size do throwError "Incomplete actual new owner inventory rows"
  let mut maps : NameMap := #[]
  let mut pairs ← checked (arrayField data "explicitActualPairs")
  let boundaries ← checked (arrayField data "acceptedBoundaryPairs")
  for p in boundaries ++ pairs do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    unless moduleOf env t == some (← checked (decodeName (← checked (field p "targetOwnerNameExpr")))) do
      throwError "Actual pair owner differs {t}"
    if maps.any (·.1 == s) then throwError "Duplicate actual source map {s}"
    maps := maps.push (s,t) |>.push (t,t)
  let supportNames ← namesFromJson (← checked (field data "supportSourceNames"))
  let mut pending := supportNames.toArray
  let mut resolutionReports : Array Json := #[]
  -- Resolve actual generated proof names only by complete relocated TYPE kernel equality.
  -- Capture and record every attempted native candidate; basename/._proof_N is not evidence.
  for _round in [:supportNames.length + 1] do
    let mut next : Array Name := #[]
    let mut progress := false
    for sourceName in pending do
      let matches := rows.filter fun r => (field r "nameExpr").toOption == some (encodeName sourceName)
      unless matches.size == 1 do throwError "Missing unique actual source support {sourceName}"
      let sr := matches[0]!
      let mut possible : Array Name := #[]
      let mut attempted : Array Json := #[]
      let sourceTypeResult := relocateExpr maps #[] #[] true (← checked (field sr "actualTypeExpr"))
      match sourceTypeResult with
      | .error msg =>
        attempted := attempted.push (Json.mkObj [("sourceTYPEUnmappedDependency",toJson msg)])
      | .ok rawTYPE =>
        let ps ← namesFromJson (← checked (field sr "levelParams"))
        let us := commonUniverses ps
        for nr in nativeRows do
          let t ← checked (decodeName (← checked (field nr "nameExpr")))
          let ci ← getConstInfo t
          if kind ci == "theorem" && ci.levelParams.length == ps.length && !maps.any (·.2 == t) then
            try
              unless (← isProp ci.type) && (← checked (sr.getObjValAs? Bool "isProposition")) do
                throwError "Generated support is not Prop"
              kernelEq s!"actual support TYPE candidate {sourceName}/{t}"
                (rawTYPE.instantiateLevelParams ps us)
                (ci.type.instantiateLevelParams ci.levelParams us)
              possible := possible.push t
              attempted := attempted.push (Json.mkObj [("targetNameExpr",encodeName t),("completeTYPEKernelEqual",toJson true)])
            catch ex =>
              attempted := attempted.push (Json.mkObj [("targetNameExpr",encodeName t),
                ("completeTYPEKernelEqual",toJson false),("diagnostic",toJson (← ex.toMessageData.toString))])
      resolutionReports := resolutionReports.push (Json.mkObj [
        ("sourceNameExpr",encodeName sourceName),("actualCandidateChecks",Json.arr attempted),
        ("exactCompleteTYPECandidateCount",toJson possible.size)])
      if possible.size == 1 then
        let t := possible[0]!
        maps := maps.push (sourceName,t) |>.push (t,t)
        pairs := pairs.push (Json.mkObj [("sourceNameExpr",encodeName sourceName),
          ("targetNameExpr",encodeName t),
          ("targetOwnerNameExpr",(moduleOf env t).map encodeName |>.getD Json.null),
          ("pairingEvidence",toJson "unique complete relocated actual TYPE kernel equality")])
        progress := true
      else next := next.push sourceName
    pending := next
    if pending.isEmpty || !progress then break
  unless pending.isEmpty do
    writeOutput output (Json.mkObj [("schema",toJson "B1-provider-height-native-correspondence-audit/v186"),
      ("status",toJson "generated-support-complete-TYPE-resolution-failed"),
      ("pendingSourceNameExprs",Json.arr (pending.map encodeName)),
      ("resolutionReports",Json.arr resolutionReports),("boundInputs",data),
      ("correspondenceAccepted",toJson false)])
    throwError "Actual support TYPE pairing failed; full differences preserved in output"
  let forward (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if projectName n then throw s!"Unmapped actual project Name {n}"
    return n
  let inverse (n : Name) : Except String Name := do
    if let some p := maps.find? (fun p => p.2 == n && p.1 != p.2) then return p.1
    if projectName n then throw s!"Unmapped inverse project Name {n}"
    return n
  let decode (j : Json) := checked (relocateExpr maps #[] #[] true j)
  let mut preflight : Array Json := #[]
  for sr in rows do
    let label ← checked (stringField sr "name")
    let mut exprs := #[(label ++ ":TYPE",← checked (field sr "actualTypeExpr"))]
    let value ← checked (field sr "actualValueExpr")
    if value != Json.null then exprs := exprs.push (label ++ ":value",value)
    for r in ← checked (arrayField (← checked (field sr "metadata")) "recursorRules") do
      exprs := exprs.push (label ++ ":recursor-RHS",← checked (field r "rhs"))
    for (whereUsed,j) in exprs do
      let e ← decode j
      for (n,k) in constantUses e do
        match env.find? n with
        | none => preflight := preflight.push (Json.mkObj [("nameExpr",encodeName n),
            ("actualSourceUse",toJson whereUsed),("diagnostic",toJson "missing actual native constant")])
        | some ci =>
          unless ci.levelParams.length == k do
            preflight := preflight.push (Json.mkObj [("nameExpr",encodeName n),("actualSourceUse",toJson whereUsed),
              ("sourceUniverseArgumentCount",toJson k),("nativeUniverseParameterCount",toJson ci.levelParams.length)])
  unless preflight.isEmpty do
    writeOutput output (Json.mkObj [("schema",toJson "B1-provider-height-native-correspondence-audit/v186"),
      ("status",toJson "actual-name-or-universe-preflight-failed"),("differences",Json.arr preflight),
      ("boundInputs",data),("actualPairs",Json.arr pairs),("correspondenceAccepted",toJson false)])
    throwError "Actual API/universe preflight failed; complete source/native facts retained"
  let mut reports : Array Json := #[]
  let mut failures : Array Json := #[]
  let mut ctorReports : Array Json := #[]
  let mut structureCount := 0
  let mut constructorCount := 0
  let mut recursorCount := 0
  let mut recursorRuleCount := 0
  for sr in rows do
    let s ← checked (decodeName (← checked (field sr "nameExpr")))
    let t ← checked (forward s)
    let ci ← getConstInfo t
    let nativeMatches := nativeRows.filter fun r => (field r "nameExpr").toOption == some (encodeName t)
    unless nativeMatches.size == 1 do throwError "Missing unique full native actual row {t}"
    let nr := nativeMatches[0]!
    try
      unless kind ci == (← checked (stringField sr "kind")) do throwError "Constant kind differs {s}"
      let ps ← namesFromJson (← checked (field sr "levelParams"))
      unless ps.length == ci.levelParams.length do throwError "Universe arity differs {s}"
      let us := commonUniverses ps
      let rawTYPE ← decode (← checked (field sr "actualTypeExpr"))
      let st := rawTYPE.instantiateLevelParams ps us
      let tt := ci.type.instantiateLevelParams ci.levelParams us
      kernelEq s!"complete original actual TYPE {s}" st tt
      unless outerForallBinderInfo rawTYPE == outerForallBinderInfo ci.type do
        throwError "Strict public forall BinderInfo differs {s}"
      let publicReports ← publicDomains s.toString st tt
      let sourceInstance ← checked (sr.getObjValAs? Bool "isInstance")
      unless sourceInstance == Lean.Meta.isInstanceCore env t do throwError "Instance registration differs {s}"
      unless (← isProp ci.type) == (← checked (sr.getObjValAs? Bool "isProposition")) do
        throwError "Prop/data kind differs {s}"
      let sourceValue ← checked (field sr "actualValueExpr")
      let mut valueCompared := false
      let mut valueBinderEqual := true
      if sourceValue != Json.null then
        unless (← checked (sr.getObjValAs? Bool "valueRead")) &&
            (← checked (sr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
          throwError "Source value is not the original full kernel-checked value {s}"
        let rawValue ← decode sourceValue
        let some nativeValue := ci.value? (allowOpaque := true) | throwError "Missing full native value {t}"
        let sv := rawValue.instantiateLevelParams ps us
        let nv := nativeValue.instantiateLevelParams ci.levelParams us
        kernelEq s!"complete source value TYPE {s}" (← kernelCheck s!"source value {s}" sv) st
        kernelEq s!"complete native value TYPE {t}" (← kernelCheck s!"native value {t}" nv) tt
        kernelEq s!"complete source/native value {s}" sv nv
        for e in #[sv,nv] do ensureStandard s!"complete value {s}" (← expressionAxioms e)
        valueCompared := true
        valueBinderEqual := binderPlacement rawValue == binderPlacement nativeValue
        if s == `Iut.EllipticCurveData.localHeightData || s == `Iut.Tripod.CurveProviders.curve then
          let freshReports ← forallTelescope tt fun xs _ => do
            let mut result : Array Json := #[]
            let sb ← whnf (mkAppN sv xs)
            let tb ← whnf (mkAppN nv xs)
            if s == `Iut.EllipticCurveData.localHeightData then
              unless xs.size == 3 do throwError "localHeightData must keep exactly C/CA/TI"
              let expected ← checked (forward `Iut.LocalHeightData.mk)
              unless sb.getAppFn.constName? == some expected && tb.getAppFn.constName? == some expected do
                throwError "Both actual values must expose original LocalHeightData.mk"
              let sa := sb.getAppArgs
              let ta := tb.getAppArgs
              unless sa.size == 11 && ta.size == 11 do throwError "Lost one of eleven actual constructor arguments"
              let labels := #["ι","bad","p","hv","f","deg","one_le_deg","p_prime","one_le_hv","one_le_f","sum_f_le"]
              for k in [:11] do
                let sc ← mkLambdaFVars xs sa[k]!
                let tc ← mkLambdaFVars xs ta[k]!
                kernelEq s!"actual LocalHeightData.mk argument {k}" sc tc
                for e in #[sc,tc] do ensureStandard s!"height argument {k}" (← expressionAxioms e)
                result := result.push (Json.mkObj [("constructor",encodeName expected),("index",toJson k),
                  ("field",toJson labels[k]!),("completeArgumentKernelEqual",toJson true),
                  ("completeSourceArgument",← checked (encodeExpr sc)),("completeNativeArgument",← checked (encodeExpr tc))])
            else
              unless xs.size == 2 do throwError "Provider.curve must keep exactly P/x"
              let sc ← mkLambdaFVars xs sb
              let tc ← mkLambdaFVars xs tb
              kernelEq "Provider.curve complete selector" sc tc
              result := result.push (Json.mkObj [("selector",encodeName t),
                ("completeSourceSelector",← checked (encodeExpr sc)),
                ("completeNativeSelector",← checked (encodeExpr tc)),("completeSelectorKernelEqual",toJson true)])
            return result
          ctorReports := ctorReports ++ freshReports
      else if (ci.value? (allowOpaque := true)).isSome then throwError "Unexpected native value {t}"
      let sm ← checked (field sr "metadata")
      sameBound s!"complete computation metadata {s}" (← checked (field sm "computationShape"))
        (← checked (computationShape ci inverse))
      let sourceStructure ← checked (field sm "structure")
      let mut structureCompared := false
      let mut rawFieldTraversalEqual := true
      if sourceStructure != Json.null then
        let some si := getStructureInfo? env t | throwError "Missing native structure metadata {s}"
        unless s == `Iut.Tripod.CurveProviders do throwError "Unexpected additional new structure {s}"
        let sourceShape ← checked (field sourceStructure "completeMetadata")
        let nativeShape ← checked (structureShape si inverse)
        rawFieldTraversalEqual := sourceShape == nativeShape
        sameBound "complete four-field Provider metadata" (← canonicalStructureMetadata sourceShape)
          (← canonicalStructureMetadata nativeShape)
        unless si.fieldNames == #[`torsionFinite3,`torsionFinite5,`arith,`modRep] do
          throwError "Provider four-field constructor order differs"
        let aps ← checked (arrayField sourceStructure "fieldAutoParamExprs")
        unless aps.size == 4 && si.fieldInfo.size == 4 && aps.all (· == Json.null) &&
            si.fieldInfo.all (fun f => f.autoParam?.isNone) && si.parentInfo.isEmpty do
          throwError "Provider complete field/autoparam/parent metadata differs"
        structureCompared := true
        structureCount := structureCount + 1
      else if (getStructureInfo? env t).isSome then throwError "Unexpected native structure metadata {s}"
      let sourceRules ← checked (arrayField sm "recursorRules")
      let mut ruleReports : Array Json := #[]
      if let .recInfo ri := ci then
        recursorCount := recursorCount + 1
        unless ri.rules.length == sourceRules.size do throwError "Recursor rule count differs {s}"
        for k in [:sourceRules.size] do
          let r := sourceRules[k]!
          let nrule := ri.rules[k]!
          unless (← checked (forward (← checked (decodeName (← checked (field r "constructor")))))) == nrule.ctor &&
              (← checked (r.getObjValAs? Nat "numFields")) == nrule.nfields do
            throwError "Recursor constructor/field count differs {s}"
          let rawRHS ← decode (← checked (field r "rhs"))
          kernelEq s!"complete recursor RHS {s}:{k}" (rawRHS.instantiateLevelParams ps us)
            (nrule.rhs.instantiateLevelParams ci.levelParams us)
          ensureStandard s!"recursor RHS {s}" (← expressionAxioms nrule.rhs)
          ruleReports := ruleReports.push (Json.mkObj [("constructor",encodeName nrule.ctor),
            ("numFields",toJson nrule.nfields),("completeRHSKernelEqual",toJson true),
            ("rawRHSBinderInfoEqual",toJson (binderPlacement rawRHS == binderPlacement nrule.rhs)),
            ("completeSourceRHS",← checked (encodeExpr rawRHS)),("completeNativeRHS",← checked (encodeExpr nrule.rhs))])
          recursorRuleCount := recursorRuleCount + 1
      else unless sourceRules.isEmpty do throwError "Unexpected source recursor metadata {s}"
      if let .ctorInfo c := ci then
        unless s == `Iut.Tripod.CurveProviders.mk && c.numFields == 4 do throwError "Provider constructor lost four dependent fields"
        constructorCount := constructorCount + 1
      for e in #[st,tt] do ensureStandard s!"complete TYPE {s}" (← expressionAxioms e)
      let axs ← collectAxioms t
      ensureStandard s!"actual declaration {t}" axs
      for key in #["axioms","typeAxioms","valueAxioms"] do
        for ax in ← checked (sr.getObjValAs? (Array String) key) do
          unless #["propext","Classical.choice","Quot.sound"].contains ax do throwError "Unexpected source axiom {s}: {ax}"
      let typeBinderEqual := binderPlacement rawTYPE == binderPlacement ci.type
      reports := reports.push (Json.mkObj [
        ("sourceNameExpr",encodeName s),("targetNameExpr",encodeName t),("kind",toJson (kind ci)),
        ("completeTYPEKernelEqual",toJson true),("strictPublicForallBinderInfoEqual",toJson true),
        ("strictDeepTYPEBinderInfoEqual",toJson typeBinderEqual),
        ("deepRawTYPEBinderDifferenceRetained",toJson (!typeBinderEqual)),
        ("publicParameterDomainReports",Json.arr publicReports),
        ("originalCompleteSourceTYPE",← checked (field sr "actualTypeExpr")),
        ("completeRelocatedSourceTYPE",← checked (encodeExpr rawTYPE)),
        ("completeNativeTYPE",← checked (encodeExpr ci.type)),
        ("originalCompleteSourceValue",sourceValue),("completeNativeValue",← checked (field nr "actualValueExpr")),
        ("completeValueKernelEqual",toJson valueCompared),("rawValueBinderInfoEqual",toJson valueBinderEqual),
        ("rawValueBinderDifferenceRetained",toJson (!valueBinderEqual)),
        ("completeComputationMetadataEqual",toJson true),("completeStructureMetadataEqual",toJson structureCompared),
        ("rawStructureFieldTraversalEqual",toJson rawFieldTraversalEqual),("actualRecursorRules",Json.arr ruleReports),
        ("instanceRegistrationEqual",toJson true),("axioms",toJson (axs.map Name.toString)),
        ("hasSorryAx",toJson (axs.contains `sorryAx))])
    catch ex =>
      failures := failures.push (Json.mkObj [("sourceNameExpr",encodeName s),("targetNameExpr",encodeName t),
        ("diagnostic",toJson (← ex.toMessageData.toString)),("originalCompleteSourceFact",sr),
        ("originalCompleteNativeFact",nr),("sourceASTEdited",toJson false),
        ("nonPropositionalDataReplaced",toJson false)])
  let expectedCtorReports := if providerOnly then 1 else 12
  let accepted := failures.isEmpty && structureCount == 1 && constructorCount == 1 &&
    recursorCount == 1 && recursorRuleCount == 1 && ctorReports.size == expectedCtorReports
  let unpaired := nativeRows.filter fun r =>
    !(pairs.any fun p => (field p "targetNameExpr").toOption == (field r "nameExpr").toOption)
  writeOutput output (Json.mkObj [("schema",toJson "B1-provider-height-native-correspondence-audit/v186"),
    ("status",toJson (if accepted then "accepted" else "actual-complete-source-native-review-failed")),
    ("compilerVersion",toJson Lean.versionString),("providerOnly",toJson providerOnly),
    ("actualPairs",Json.arr pairs),("actualGeneratedSupportResolution",Json.arr resolutionReports),
    ("reports",Json.arr reports),("failures",Json.arr failures),("constructorArgumentReports",Json.arr ctorReports),
    ("structureCount",toJson structureCount),("constructorCount",toJson constructorCount),
    ("recursorCount",toJson recursorCount),("recursorRuleCount",toJson recursorRuleCount),
    ("allActualNewOwnerNativeFacts",Json.arr nativeRows),
    ("unpairedNativeCompilerGeneratedFactsLegalityOnly",Json.arr unpaired),
    ("acceptedBoundaryPairs",Json.arr boundaries),
    ("reusedRegistryAcceptance",← checked (field data "reusedRegistryAcceptance")),
    ("originalCompatibilityScope",← checked (field data "originalCompatibilityScope")),
    ("oldTateTwentyToTwentyMathematicalBijectionClaimed",toJson false),
    ("oldTorsionFreeWholePropCertificateAppliedToNewLemma",toJson false),
    ("completeOriginalSourceProofValuesCheckedWithoutReplacement",toJson accepted),
    ("proofNumbersUsedAsCorrespondenceEvidence",toJson false),
    ("nonPropositionalDataReplaced",toJson false),("newProductionParametersAdded",toJson false),
    ("actualHeightDefinitionChanged",toJson false),("newAssumptionsIntroduced",toJson false),
    ("correspondenceAccepted",toJson accepted),("configuration",cfg)])
  unless accepted do throwError "Provider/height complete actual review failed; exact differences preserved in output"
  logInfo "Complete Provider4/curve and selected actual local height assembly review accepted"
end ProviderHeightNativeReview
