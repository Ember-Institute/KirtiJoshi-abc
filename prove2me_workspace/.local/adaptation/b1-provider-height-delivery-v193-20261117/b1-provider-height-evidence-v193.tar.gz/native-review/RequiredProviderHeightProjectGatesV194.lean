import Lean
import ArithmeticTeichmullerSpaces.Prologue.Audit.Checks
import ArithmeticTeichmullerSpaces.Prologue.Audit.ImportAudit
import ArithmeticTeichmullerSpaces.Act1Scene1
import ArithmeticTeichmullerSpaces.Prologue.Audit.AxiomAudit
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveProviders
import Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_LocalHeightDataAssembly

#print axioms AbcAdaptation.Tripod.CurveProviders.curve
#print axioms AbcAdaptation.Reference.Iut.residueChar_prime
#print axioms AbcAdaptation.Reference.Iut.EllipticCurveData.localHeightData

open Lean Elab Command Meta in
run_meta do
  let env ← getEnv
  let owners : Array Name := #[
    `Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveProviders,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_LocalHeightDataAssembly]
  let names := env.constants.fold (fun result name _ =>
    match env.getModuleIdxFor? name with
    | none => result
    | some index => if (env.header.moduleNames[index.toNat]?).any owners.contains then result.push name else result) (#[] : Array Name)
  unless names.size == 28 do throwError "Expected all twenty-eight actual new owned declarations"
  for name in names.qsort Name.lt do
    let axioms ← collectAxioms name
    for axiomName in axioms do
      unless #[`propext, `Classical.choice, `Quot.sound].contains axiomName do
        throwError "Unexpected axiom {axiomName} in {name}"
    logInfo m!"{name}: standard axioms {axioms}"
  logInfo "Checks, ImportAudit, Act1Scene1 and AxiomAudit imported; all twenty-eight new declarations have standard axioms only"
