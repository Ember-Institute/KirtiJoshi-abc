from pathlib import Path
import json,hashlib,importlib.util,sys,urllib.parse
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');D=W/'.local/adaptation/b1-provider-height-publication-v194-20261117';R=W/'.local/adaptation/b1-provider-height-native-review-v192-20261117/audit-shared-v206';A=W/'.local/adaptation/main-chain-open-20261116'
spec=importlib.util.spec_from_file_location('api',W/'.local/abc-item/api.py');api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
save=lambda p,j:p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mode,kind=sys.argv[1:3];assert kind in ['provider','assembly'];d=D/kind;p=json.loads((d/'payload-final.json').read_text())
def guard():
 r=json.loads((A/'b1-provider-height-shared-projection-native-review-v209-result.json').read_text());assert r['status']=='succeeded' and r['result']['exit_code']==0
 q=json.loads((R/'provider-height.correspondence-review.json').read_text());assert q['correspondenceAccepted'] and q['status']=='accepted' and not q['providerOnly'] and q['failures']==[]
 assert len(q['reports'])==16 and len(q['acceptedBoundaryPairs'])==21 and len(q['allActualNewOwnerNativeFacts'])==28 and len(q['unpairedNativeCompilerGeneratedFactsLegalityOnly'])==12
 assert len(q['constructorArgumentReports'])==12 and q['structureCount']==q['constructorCount']==q['recursorCount']==q['recursorRuleCount']==1
 for x in q['reports']:
  assert x['completeTYPEKernelEqual'] and x['strictPublicForallBinderInfoEqual'] and x['completeComputationMetadataEqual'] and not x['hasSorryAx'] and set(x['axioms'])<={'propext','Classical.choice','Quot.sound'}
  if x['kind'] in ['definition','theorem','opaque']:assert x['completeValueKernelEqual']
 for key in ['nonPropositionalDataReplaced','newProductionParametersAdded','actualHeightDefinitionChanged','newAssumptionsIntroduced']:assert not q[key]
 c=q['independentResidueCharPrimeSourceCertificate'];assert c['wholeProofKernelDefEq'] and c['wholeProofEqualityCertificateKernelChecked'] and c['sameWholePropTYPEKernelChecked'] and not c['nonPropositionalDataReplacementUsed']
 req=r.get('request',{});m=req.get('worktree_manifest',r['result']['snapshot']['manifest']);name='Tripod_CurveProviders'if kind=='provider'else'Concrete_LocalHeightDataAssembly';code=W/f'Definitions/Def_AbcAdaptation_Reference_Iut_{name}.lean'
 assert m['input_hashes'][str(code)]==sha(code) and p['definition']==code.read_text()
 assert p['private'] is True and p['env']=='0df444a360eaa60ab8c11dca51a86af692955474'
 mandatory=json.loads((A/'b1-provider-height-required-project-gates-v194-result.json').read_text());assert mandatory['status']=='succeeded' and mandatory['result']['exit_code']==0
if mode=='submit':
 guard();assert not(d/'publish-intent.json').exists() and not(d/'publish-submit.json').exists(),'Resolve existing publication intent before any new POST'
 hits=api.request('/definitions?q='+urllib.parse.quote(p['definition_name'])+'&limit=100');save(d/'prior-name-search.json',hits);assert not any(x['definition_name']==p['definition_name']for x in hits.get('definitions',[]))
 save(d/'publish-intent.json',{'stage':'intent-before-post','definitionName':p['definition_name'],'payloadSHA256':sha(d/'payload-final.json'),'private':True,'nativeReviewJob':'ci-019381-0a72a1e8'})
 v=api.request('/submit-definition',p,method='POST');save(d/'publish-submit.json',v);save(d/'publish-journal.json',{'job_id':v['job_id'],'status':v['status']});print(json.dumps({'kind':kind,'job_id':v['job_id'],'status':v['status']}))
elif mode=='poll':
 j=json.loads((d/'publish-journal.json').read_text());v=api.request('/publish-jobs/'+j['job_id']);save(d/'publish-result.json',v);j['status']=v['status'];save(d/'publish-journal.json',j);print(json.dumps({'kind':kind,'job_id':j['job_id'],'status':v['status'],'error_message':v.get('error_message')},ensure_ascii=False))
 if v['status']=='PUBLISHED':
  item=api.request('/definitions/'+(v.get('definition_id')or v['theorem_id']));save(d/'published-item.json',item)
  for key in ['definition_name','definition_title','definition','natural_language_statement','source']:assert item[key]==p[key],key
  assert item['visibility']=='private'and item['mathlib_rev']==p['env'];save(d/'publication-validation.json',{'allSubmittedFieldsExactlyReadBack':True,'private':True,'mathlib_rev':item['mathlib_rev']});print(json.dumps({'definition_id':item['definition_id'],'allFieldsExact':True}))
else:raise SystemExit('unknown mode')
