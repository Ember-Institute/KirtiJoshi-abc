import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_LocalHeightDataAssembly

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare
namespace ResidueCharPrimeNativeProofDelta
open Lean Elab Term Meta FoundationAudit BasicNativeCompare

structure ProofBody where
  name : Name
  params : List Name
  value : Expr

partial def selectedProofDelta (bodies : Array ProofBody) (visiting : Array Name) : Expr → MetaM Expr
  | .const n us => do
    match bodies.find? (·.name == n) with
    | none => return .const n us
    | some body =>
      if visiting.contains n then throwError "Cyclic selected proof delta {n}"
      unless body.params.length == us.length do throwError "Selected proof delta universe arity differs {n}"
      selectedProofDelta bodies (visiting.push n) (body.value.instantiateLevelParams body.params us)
  | .app f a => return .app (← selectedProofDelta bodies visiting f) (← selectedProofDelta bodies visiting a)
  | .lam n t b bi => return .lam n (← selectedProofDelta bodies visiting t) (← selectedProofDelta bodies visiting b) bi
  | .forallE n t b bi => return .forallE n (← selectedProofDelta bodies visiting t) (← selectedProofDelta bodies visiting b) bi
  | .letE n t v b nd => do
    let t ← selectedProofDelta bodies visiting t
    let v ← selectedProofDelta bodies visiting v
    let b ← selectedProofDelta bodies visiting b
    return .letE n t v b nd
  | .mdata md b => return .mdata md (← selectedProofDelta bodies visiting b)
  | .proj n i b => return .proj n i (← selectedProofDelta bodies visiting b)
  | .mvar _ => throwError "Metavariable in original actual proof"
  | .fvar _ => throwError "Free variable in original actual proof"
  | e => return e

-- Only literal beta computation and projections of literal Prop constructors.
-- No whnf/unfoldDefinition/synthInstance or delta of unselected constants is used.
partial def betaPropIota : Expr → MetaM Expr
  | .app f a => do
    let e := Expr.app (← betaPropIota f) (← betaPropIota a)
    if e.isHeadBetaTarget then betaPropIota e.headBeta else pure e
  | .lam n t b bi => return .lam n (← betaPropIota t) (← betaPropIota b) bi
  | .forallE n t b bi => return .forallE n (← betaPropIota t) (← betaPropIota b) bi
  | .letE n t v b nd => return .letE n (← betaPropIota t) (← betaPropIota v) (← betaPropIota b) nd
  | .mdata md b => return .mdata md (← betaPropIota b)
  | .proj n i b => do
    let b ← betaPropIota b
    match b.getAppFn with
    | .const ctor _ =>
      match (← getEnv).find? ctor with
      | some (.ctorInfo ci) =>
        let k := ci.numParams + i
        if ci.induct == n && k < b.getAppNumArgs && (← isProp ci.type) then
          betaPropIota (b.getArg! k)
        else pure (.proj n i b)
      | _ => pure (.proj n i b)
    | _ => pure (.proj n i b)
  | e => return e

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]

def outputJson (out : String) (j : Json) : MetaM Unit := do
  unless out.startsWith "/" do throwError "Expected absolute native delta output path"
  if let some parent := (System.FilePath.mk out).parent then IO.FS.createDirAll parent
  IO.FS.writeFile out (j.pretty ++ "\n")

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_RESIDUECHAR_PRIME_NATIVE_PROOF_DELTA_V198")
  unless (← checked (stringField cfg "schema")) == "B1-residueChar-prime-native-proof-delta-config/v198" do
    throwError "Wrong native selected proof delta configuration"
  let preflight ← jsonFile (← checked (stringField cfg "sourcePreflightFile"))
  unless preflight == (← checked (field cfg "sourcePreflightContents")) &&
      (← checked (stringField preflight "status")) == "actual-native-proof-source-preflight-failed" &&
      (← checked (arrayField preflight "actualNativeCandidateSourcePreflightUniverseArityDifferences")).isEmpty do
    throwError "Bound actual first source preflight differs"
  let receipt ← jsonFile (← checked (stringField cfg "sourcePreflightReceiptFile"))
  unless receipt == (← checked (field cfg "sourcePreflightReceiptContents")) &&
      (← checked (stringField receipt "job_id")) == "ci-019325-5b7b2637" &&
      (← checked (stringField receipt "status")) == "failed" do
    throwError "Wrong original source preflight failure receipt"
  let missing ← checked (arrayField preflight "actualNativeCandidateSourcePreflightMissingNames")
  let selected ← namesFromJson (← checked (field cfg "selectedProofNames"))
  let allowed := #[`IsDedekindDomainDvr.ring_dimensionLEOne,
    `IsDedekindDomain.isDedekindDomainDvr, `AddMonoid.fg_of_addGroup_fg]
  unless selected.length == 3 && missing.size == 3 &&
      selected.all allowed.contains && allowed.all selected.contains do
    throwError "Only the three actual confirmed missing proof names may be selected"
  for row in missing do
    unless selected.contains (← checked (decodeName (← checked (field row "nameExpr")))) &&
        (← checked (row.getObjValAs? Nat "universeArgumentCount")) == 1 do
      throwError "Selected proof is not an actual source missing name"
  let nr ← checked (field cfg "nativeRecord")
  let root := `AbcAdaptation.Reference.Iut.residueChar_prime
  let ci ← getConstInfo root
  unless (← checked (decodeName (← checked (field nr "nameExpr")))) == root &&
      moduleOf (← getEnv) root == some `Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_LocalHeightDataAssembly &&
      kind ci == "theorem" && (← isProp ci.type) && ci.levelParams.length == 1 do
    throwError "Wrong exact native original whole Prop proof"
  let some raw := ci.value? (allowOpaque := true) | throwError "Missing original complete native proof"
  unless (← checked (field nr "actualTypeExpr")) == (← checked (encodeExpr ci.type)) &&
      (← checked (field nr "actualValueExpr")) == (← checked (encodeExpr raw)) do
    throwError "Original complete native fact differs from successful inventory"
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let mut bodies : Array ProofBody := #[]
  let mut helperReports : Array Json := #[]
  for name in selected do
    let helper ← getConstInfo name
    unless ← isProp helper.type do throwError "Selected delta target is not a complete Prop proof {name}"
    let some value := helper.value? (allowOpaque := true) | throwError "Selected original Prop proof has no full value {name}"
    let inferred ← kernelCheck s!"selected original complete proof {name}" value
    kernelEq s!"selected original complete proof TYPE {name}" inferred helper.type
    let axs ← expressionAxioms cache value
    ensureStandard s!"selected original proof {name}" axs
    bodies := bodies.push ⟨name,helper.levelParams,value⟩
    helperReports := helperReports.push (Json.mkObj [
      ("nameExpr",encodeName name),("kind",toJson (kind helper)),
      ("ownerNameExpr",(moduleOf (← getEnv) name).map encodeName |>.getD Json.null),
      ("levelParams",Json.arr (helper.levelParams.toArray.map encodeName)),
      ("originalCompleteTYPE",← checked (encodeExpr helper.type)),
      ("originalCompleteValue",← checked (encodeExpr value)),
      ("originalValueKernelInferredTYPE",← checked (encodeExpr inferred)),
      ("completeTYPEIsProp",toJson true),("originalCompleteValueKernelChecked",toJson true),
      ("axioms",toJson (axs.map Name.toString))])
  let rawTYPE ← kernelCheck "original native whole proof" raw
  kernelEq "original native whole proof TYPE" rawTYPE ci.type
  let deltaOnly ← selectedProofDelta bodies #[] raw
  let deltaOnlyTYPE ← kernelCheck "selected Prop delta complete whole proof" deltaOnly
  kernelEq "selected Prop delta whole TYPE" deltaOnlyTYPE ci.type
  kernelEq "selected Prop delta whole proof" raw deltaOnly
  let portable ← betaPropIota deltaOnly
  let portableTYPE ← kernelCheck "selected Prop delta beta Prop-iota whole proof" portable
  kernelEq "portable whole proof complete TYPE" portableTYPE ci.type
  kernelEq "original/portable native whole proof" raw portable
  let equality ← mkEq raw portable
  let equalityProof ← mkEqRefl raw
  kernelEq "complete native wholeproof equality certificate TYPE"
    (← kernelCheck "native wholeproof equality certificate" equalityProof) equality
  let axs ← expressionAxioms cache portable
  ensureStandard "portable native whole proof" axs
  let mut uses : Array Json := #[]
  let mut newNames : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  let originalNames := raw.getUsedConstants
  for (n,k) in constantUses portable do
    unless seen.contains (n,k) do
      seen := seen.push (n,k)
      let info ← getConstInfo n
      let row := Json.mkObj [("nameExpr",encodeName n),("universeArgumentCount",toJson k),
        ("actualNativeUniverseParameterCount",toJson info.levelParams.length),
        ("kind",toJson (kind info)),("declarationTYPEIsProp",toJson (← isProp info.type)),
        ("fullValueAvailable",toJson (info.value? (allowOpaque := true)).isSome),
        ("actualNativeCompleteTYPE",← checked (encodeExpr info.type)),
        ("newRelativeToOriginalNativeWholeProof",toJson (!originalNames.contains n))]
      uses := uses.push row
      unless originalNames.contains n do newNames := newNames.push row
  let out ← checked (stringField cfg "outputFile")
  outputJson out (Json.mkObj [
    ("schema",toJson "B1-residueChar-prime-native-proof-delta/v198"),
    ("status",toJson "accepted-native-selected-Prop-delta-wholeproof-certificate"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("originalNativeRecord",nr),("selectedOriginalPropProofs",Json.arr helperReports),
    ("originalWholeTYPE",← checked (encodeExpr ci.type)),("originalWholeProof",← checked (encodeExpr raw)),
    ("deltaOnlyWholeProof",← checked (encodeExpr deltaOnly)),
    ("portableWholeTYPE",← checked (encodeExpr portableTYPE)),("portableWholeProof",← checked (encodeExpr portable)),
    ("wholeProofEqualityExpr",← checked (encodeExpr equality)),
    ("wholeProofEqualityProofExpr",← checked (encodeExpr equalityProof)),
    ("portableActualConstantUses",Json.arr uses),("newActualConstantNames",Json.arr newNames),
    ("nativeKernelOriginalAndExpandedFullTypesChecked",toJson true),
    ("nativeKernelWholeProofEqualityChecked",toJson true),("nativeKernelEqualityCertificateChecked",toJson true),
    ("onlyConfirmedMissingPropValuesDeltaExpanded",toJson true),
    ("onlyLiteralBetaAndPropConstructorIotaAfterDelta",toJson true),
    ("nonPropDeclarationDeltaExpanded",toJson false),("wholeTYPEChanged",toJson false),
    ("nonPropositionalDataReplaced",toJson false),("newMathematicalParametersAdded",toJson false),
    ("fallbackSynthesizedProofUsed",toJson false),("axioms",toJson (axs.map Name.toString)),
    ("sourcePortabilityAccepted",toJson false)])
  logInfo "Exact three confirmed missing native Prop proofs delta-certified; source portability remains to be checked"
end ResidueCharPrimeNativeProofDelta
