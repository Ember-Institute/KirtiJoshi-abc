import Lean
import B1SourceReplay

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  -- moduleNames maps the entire module array; use the indexed record directly.
  let imported ← env.header.modules[index.toNat]?
  return imported.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare
namespace ResidueCharPrimePortableWholePropSourceCertificate
open Lean Elab Term Meta FoundationAudit BasicNativeCompare
partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]

partial def projectionStructures : Expr → Array Name
  | .proj n _ e => #[n] ++ projectionStructures e
  | .app f a => projectionStructures f ++ projectionStructures a
  | .lam _ t b _ => projectionStructures t ++ projectionStructures b
  | .forallE _ t b _ => projectionStructures t ++ projectionStructures b
  | .letE _ t v b _ => projectionStructures t ++ projectionStructures v ++ projectionStructures b
  | .mdata _ e => projectionStructures e
  | _ => #[]

def outputJson (out : String) (j : Json) : MetaM Unit := do
  unless out.startsWith "/" do throwError "Expected absolute certificate output path"
  if let some parent := (System.FilePath.mk out).parent then IO.FS.createDirAll parent
  IO.FS.writeFile out (j.compress ++ "\n")

run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected source4.35.0-rc3"
  let cfg ← jsonFile (← absoluteEnv "B1_RESIDUECHAR_PRIME_PORTABLE_WHOLEPROP_SOURCE_CERTIFICATE_V201")
  unless (← checked (stringField cfg "schema")) == "B1-residueChar-prime-portable-wholeProp-source-certificate-config/v201" do
    throwError "Wrong single-lemma whole Prop source certificate config"
  let sr ← checked (field cfg "sourceRecord")
  let nr ← checked (field cfg "nativeRecord")
  for (key,expectedJob) in #[
      ("sourceSuccessfulReceiptBinding","ci-019283-b4f6ebda"),
      ("nativeSuccessfulReceiptBinding","ci-019296-a4235e56")] do
    let rb ← checked (field cfg key)
    let receipt ← jsonFile (← checked (stringField (← checked (field rb "pin")) "path"))
    unless receipt == (← checked (field rb "contents")) &&
        (← checked (stringField receipt "status")) == "succeeded" &&
        (← checked (stringField receipt "job_id")) == expectedJob do
      throwError "Bound actual source/native inventory successful receipt differs {key}"
  let sf ← jsonFile (← checked (stringField (← checked (field cfg "sourceFactsBinding")) "path"))
  let sourceMatches := (← checked (arrayField sf "facts")).filter fun r =>
    (field r "nameExpr").toOption == (field sr "nameExpr").toOption
  unless sourceMatches.size == 1 && sourceMatches[0]! == sr do
    throwError "Complete actual source row differs from successfully exported source facts"
  let nf ← jsonFile (← checked (stringField (← checked (field cfg "nativeInventoryBinding")) "path"))
  let nativeMatches := (← checked (arrayField nf "facts")).filter fun r =>
    (field r "nameExpr").toOption == (field nr "nameExpr").toOption
  unless nativeMatches.size == 1 && nativeMatches[0]! == nr do
    throwError "Complete actual native row differs from successfully exported native inventory"
  let nativeDelta ← jsonFile (← checked (stringField cfg "nativePortableInputFile"))
  unless (← checked (stringField nativeDelta "schema")) == "B1-residueChar-prime-native-portable-input/v200" &&
      (← checked (stringField nativeDelta "nativeCertificateSchema")) == "B1-residueChar-prime-native-proof-delta/v198" &&
      (← checked (stringField nativeDelta "nativeCertificateStatus")) == "accepted-native-selected-Prop-delta-wholeproof-certificate" &&
      (← checked (field nativeDelta "originalNativeRecord")) == nr do
    throwError "Native delta certificate is not bound to the original actual native whole proof"
  let extraction ← checked (field cfg "portableInputExtractionRecord")
  unless (← checked (extraction.getObjValAs? Bool "completeExprJSONEqualityChecked")) &&
      !(← checked (extraction.getObjValAs? Bool "mathematicalExpressionModified")) &&
      !(← checked (extraction.getObjValAs? Bool "kernelProofClaimed")) do
    throwError "Compact extraction must be exact engineering input binding only"
  unless (← checked (field nativeDelta "originalCompleteNativeCertificateBinding")) ==
      (← checked (field extraction "completeCertificateBinding")) do
    throwError "Compact portable input original certificate binding differs"
  let nativeDeltaReceipt ← jsonFile (← checked (stringField cfg "nativeDeltaReceiptFile"))
  unless nativeDeltaReceipt == (← checked (field cfg "nativeDeltaReceiptContents")) &&
      (← checked (stringField nativeDeltaReceipt "status")) == "succeeded" &&
      (← checked (stringField nativeDeltaReceipt "job_id")) == (← checked (stringField cfg "nativeDeltaJobId")) do
    throwError "Native selected proof delta receipt is not the actual successful result"
  for key in #["nativeKernelOriginalAndExpandedFullTypesChecked","nativeKernelWholeProofEqualityChecked",
      "nativeKernelEqualityCertificateChecked","onlyConfirmedMissingPropValuesDeltaExpanded", 
      "onlyLiteralBetaAndPropConstructorIotaAfterDelta"] do
    unless ← checked (nativeDelta.getObjValAs? Bool key) do throwError "Missing native delta certificate guard {key}"
  for key in #["nonPropDeclarationDeltaExpanded","wholeTYPEChanged","nonPropositionalDataReplaced",
      "newMathematicalParametersAdded","fallbackSynthesizedProofUsed"] do
    if ← checked (nativeDelta.getObjValAs? Bool key) then throwError "Forbidden native delta change {key}"
  let sourceName ← checked (decodeName (← checked (field sr "nameExpr")))
  unless sourceName == `Iut.residueChar_prime do throwError "Certificate must target only Iut.residueChar_prime"
  let ci ← getConstInfo sourceName
  unless moduleOf (← getEnv) sourceName == some `Iut.Cor312.ThetaData.Places && kind ci == "theorem" &&
      ci.levelParams.length == 1 && !(Lean.Meta.isInstanceCore (← getEnv) sourceName) do
    throwError "Original source single-lemma owner/kind/universes/instance differs"
  let some raw := ci.value? (allowOpaque := true) | throwError "Missing original full source proof"
  unless (← checked (field sr "actualTypeExpr")) == (← checked (encodeExpr ci.type)) &&
      (← checked (field sr "actualValueExpr")) == (← checked (encodeExpr raw)) do
    throwError "Original complete source TYPE/value differs from actual source fact"
  unless outerForallBinderInfo ci.type == #["implicit","instImplicit","instImplicit","default"] &&
      (← isProp ci.type) do throwError "Original complete source lemma telescope/whole Prop TYPE differs"
  let nativeName ← checked (decodeName (← checked (field nr "nameExpr")))
  unless nativeName == `AbcAdaptation.Reference.Iut.residueChar_prime &&
      (← checked (decodeName (← checked (field nr "ownerNameExpr")))) ==
        `Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_LocalHeightDataAssembly &&
      (← checked (stringField nr "kind")) == "theorem" &&
      !(← checked (nr.getObjValAs? Bool "isInstance")) &&
      (← checked (nr.getObjValAs? Bool "isProposition")) &&
      (← checked (nr.getObjValAs? Bool "valueRead")) &&
      (← checked (nr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
    throwError "Actual native record is not the exact complete new single-lemma proof"
  let nativeParams ← namesFromJson (← checked (field nr "levelParams"))
  unless nativeParams.length == ci.levelParams.length do throwError "Actual native/source universe arities differ"
  let reversedNative ← checked (decodeName (← checked (field cfg "nativeResidueCharNameExpr")))
  let reversedSource ← checked (decodeName (← checked (field cfg "sourceResidueCharNameExpr")))
  unless reversedNative == `AbcAdaptation.Reference.Iut.residueChar && reversedSource == `Iut.residueChar do
    throwError "Only actual accepted residueChar data boundary may be reversed"
  let maps : NameMap := #[(reversedNative,reversedSource),(reversedSource,reversedSource)]
  let candidateNativeTYPE ← checked (relocateExpr maps #[] #[] false (← checked (field nr "actualTypeExpr")))
  let candidateNativeValue ← checked (relocateExpr maps #[] #[] false (← checked (field nativeDelta "portableWholeProof")))
  let sourceLevels := ci.levelParams.map Level.param
  let candidateTYPE := candidateNativeTYPE.instantiateLevelParams nativeParams sourceLevels
  let candidate := candidateNativeValue.instantiateLevelParams nativeParams sourceLevels
  let out ← checked (stringField cfg "outputFile")
  -- Archive exact source name/universe metadata once, so later confirmed-missing
  -- decisions do not require another full cached-source import merely for lookup.
  let sourceNamesOut ← checked (stringField cfg "sourceNameArityOutputFile")
  let sourceNames := (← getEnv).constants.fold (fun acc n info =>
    acc.push (Json.mkObj [("nameExpr",encodeName n),
      ("declaredUniverseParameterCount",toJson info.levelParams.length)])) (#[] : Array Json)
  unless sourceNamesOut.startsWith "/" do throwError "Expected absolute source name inventory path"
  if let some parent := (System.FilePath.mk sourceNamesOut).parent then IO.FS.createDirAll parent
  IO.FS.writeFile sourceNamesOut ((Json.mkObj [
    ("schema",toJson "B1-actual-source-environment-name-arity-inventory/v201"),
    ("compilerVersion",toJson Lean.versionString),("actualNames",Json.arr sourceNames),
    ("actualSourceEnvironmentOnly",toJson true),("proofOrDataValuesExported",toJson false)]).compress ++ "\n")
  let mut missing : Array Json := #[]
  let mut arity : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  let mut candidateNames : Array Json := #[]
  for (label,e) in #[("actualNativeTYPEAfterOnlyResidueCharReverse",candidateTYPE),
      ("actualNativeValueAfterOnlyResidueCharReverse",candidate)] do
    for (n,k) in constantUses e do
      unless seen.contains (n,k) do
        seen := seen.push (n,k)
        candidateNames := candidateNames.push (Json.mkObj [("nameExpr",encodeName n),("universeArgumentCount",toJson k)])
        match (← getEnv).find? n with
        | none => missing := missing.push (Json.mkObj [("nameExpr",encodeName n),
            ("candidateExpression",toJson label),("universeArgumentCount",toJson k)])
        | some info => unless info.levelParams.length == k do
            arity := arity.push (Json.mkObj [("nameExpr",encodeName n),("candidateExpression",toJson label),
              ("actualNativeUniverseArguments",toJson k),("actualSourceUniverseParameters",toJson info.levelParams.length)])
  let mut seenProjectionNames : Array Name := #[]
  for e in #[candidateTYPE,candidate] do
    for n in projectionStructures e do
      unless seenProjectionNames.contains n do
        seenProjectionNames := seenProjectionNames.push n
        candidateNames := candidateNames.push (Json.mkObj [("nameExpr",encodeName n),
          ("expressionKind",toJson "kernel-projection-structure"),("universeArgumentCount",Json.null)])
        unless ((← getEnv).find? n).isSome do
          missing := missing.push (Json.mkObj [("nameExpr",encodeName n),
            ("candidateExpression",toJson "kernel-projection-structure"),("universeArgumentCount",Json.null)])
  unless missing.isEmpty && arity.isEmpty do
    outputJson out (Json.mkObj [
      ("schema",toJson "B1-residueChar-prime-portable-wholeProp-source-certificate/v201"),
      ("status",toJson "actual-native-proof-source-preflight-failed"),
      ("actualNativeCandidateSourcePreflightMissingNames",Json.arr missing),
      ("actualNativeCandidateSourcePreflightUniverseArityDifferences",Json.arr arity),
      ("configuration",cfg),("candidateNames",Json.arr candidateNames),
      ("sourceEnvironmentNameArityInventoryFile",toJson sourceNamesOut),
      ("nativeDeltaCertificate",nativeDelta),("nativeDeltaSuccessfulReceipt",nativeDeltaReceipt),
    ("portableInputExtractionRecord",extraction),
      ("sourceKernelNormalizationChecked",toJson false),
      ("fallbackSynthesizedProofUsed",toJson false),("nativeCorrespondenceAccepted",toJson false)])
    throwError "Exact actual native proof cannot be reflected in source; no fallback is permitted"
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let rawTYPE ← kernelCheck "original complete source residueChar_prime proof" raw
  kernelEq "original complete source proof TYPE" rawTYPE ci.type
  let _ ← kernelCheck "original complete source TYPE" ci.type
  let rawAxioms ← expressionAxioms cache raw
  ensureStandard "original complete source proof" rawAxioms
  ensureStandard "original complete source declaration" (← cachedAxioms cache sourceName)
  kernelEq "reflected complete actual native/source TYPE" candidateTYPE ci.type
  unless outerForallBinderInfo candidateTYPE == outerForallBinderInfo ci.type do
    throwError "Reflected public BinderInfo differs"
  let normalizedTYPE ← kernelCheck "complete reflected actual native proof" candidate
  kernelEq "complete original/reflected actual proof TYPE" normalizedTYPE ci.type
  unless ← isProp normalizedTYPE do throwError "Whole proof certificate would replace non-Propositional data"
  kernelEq "complete original/reflected actual whole proof" raw candidate
  let normalizedAxioms ← expressionAxioms cache candidate
  ensureStandard "complete reflected actual proof" normalizedAxioms
  let equality ← mkEq raw candidate
  let equalityProof ← mkEqRefl raw
  let equalityProofTYPE ← kernelCheck "complete single-lemma whole-proof equality certificate" equalityProof
  kernelEq "single-lemma complete equality certificate TYPE" equalityProofTYPE equality
  let equalityAxioms ← expressionAxioms cache equalityProof
  ensureStandard "single-lemma equality certificate" equalityAxioms
  let normalizedRow := sr
    |>.setObjVal! "actualValueExpr" (← checked (encodeExpr candidate))
    |>.setObjVal! "kernelInferredValueTypeExpr" (← checked (encodeExpr normalizedTYPE))
    |>.setObjVal! "directValueConstants" (Json.arr (candidate.getUsedConstants.qsort Name.lt |>.map encodeName))
    |>.setObjVal! "valueAxioms" (toJson (normalizedAxioms.map Name.toString))
    |>.setObjVal! "normalizationSource" (toJson "source4.35 residueChar_prime-only whole Prop certificate of native-certified portable proof; original source fact retained")
  outputJson out (Json.mkObj [
    ("schema",toJson "B1-residueChar-prime-portable-wholeProp-source-certificate/v201"),
    ("status",toJson "accepted-source-portable-single-lemma-whole-Prop-proof-certificate"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("sourceNameExpr",encodeName sourceName),("sourceOwnerNameExpr",encodeName `Iut.Cor312.ThetaData.Places),
    ("sourceRecord",sr),("normalizedSourceRecord",normalizedRow),
    ("actualNativeCandidateSourcePreflightMissingNames",Json.arr missing),
    ("actualNativeCandidateSourcePreflightUniverseArityDifferences",Json.arr arity),
    ("actualNativeCandidateAfterOnlyResidueCharReverseTYPE",← checked (encodeExpr candidateTYPE)),
    ("actualNativeCandidateAfterOnlyResidueCharReverseValue",← checked (encodeExpr candidate)),
    ("nativeDeltaCertificate",nativeDelta),("nativeDeltaSuccessfulReceipt",nativeDeltaReceipt),
    ("portableInputExtractionRecord",extraction),
    ("candidateNames",Json.arr candidateNames),("sourceEnvironmentNameArityInventoryFile",toJson sourceNamesOut),
    ("originalNativeWholeProofRetainedButNotDecodedInSource",← checked (field nr "actualValueExpr")),
    ("originalWholeProofTYPE",← checked (encodeExpr ci.type)),("originalWholeProofValue",← checked (encodeExpr raw)),
    ("normalizedWholeProofTYPE",← checked (encodeExpr normalizedTYPE)),
    ("normalizedWholeProofValue",← checked (encodeExpr candidate)),
    ("wholeProofEqualityExpr",← checked (encodeExpr equality)),
    ("wholeProofEqualityProofExpr",← checked (encodeExpr equalityProof)),
    ("originalWholeProofKernelChecked",toJson true),("sameWholePropTYPEKernelChecked",toJson true),
    ("wholeProofKernelDefEq",toJson true),("wholeProofEqualityCertificateKernelChecked",toJson true),
    ("rawAxioms",toJson (rawAxioms.map Name.toString)),
    ("normalizedAxioms",toJson (normalizedAxioms.map Name.toString)),
    ("certificateAxioms",toJson (equalityAxioms.map Name.toString)),
    ("rawSourceProofByteIdentityClaimed",toJson false),
    ("fallbackSynthesizedProofUsed",toJson false),("onlyActualNativeProofUsed",toJson false),("onlyNativeCertifiedSelectedPropDeltaPortableProofUsed",toJson true),
    ("oldWholePropCertificateReused",toJson false),("nonPropositionalDataReplacementUsed",toJson false),
    ("sourceASTOrBodyEdited",toJson false),("newAxiomsIntroduced",toJson false),
    ("sourceKernelNormalizationChecked",toJson true),("nativeCorrespondenceAccepted",toJson false)])
  logInfo "Single residueChar_prime native-certified portable whole proof certified in original source whole Prop"
end ResidueCharPrimePortableWholePropSourceCertificate
