import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_LocalHeightDataAssembly

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare
namespace ResidueCharPrimeNativeSharedProjection
open Lean Elab Term Meta FoundationAudit BasicNativeCompare

def jsonOutput (out : String) (j : Json) : MetaM Unit := do
  unless out.startsWith "/" do throwError "Expected absolute native shared-projection output path"
  if let some parent := (System.FilePath.mk out).parent then IO.FS.createDirAll parent
  IO.FS.writeFile out (j.compress ++ "\n")

partial def replaceDimension (xs : Array Expr) (e : Expr) (path : String) : MetaM (Expr × Array Json) := do
  if e.getAppFn.isConstOf `IsDedekindDomainDvr.ring_dimensionLEOne then
    let args := e.getAppArgs
    unless args.size == 4 do throwError "Expected exact saturated DimensionLEOne application at {path}"
    let nested := args[3]!
    unless nested.getAppFn.isConstOf `IsDedekindDomain.isDedekindDomainDvr do
      throwError "Original dimension proof does not use the exact existing Dedekind-domain term at {path}"
    let inner := nested.getAppArgs
    unless inner.size == 4 && (List.range 3).all (fun i => args[i]! == inner[i]!) do
      throwError "Original outer/inner data arguments differ at {path}"
    let .const _ us := e.getAppFn | throwError "Expected actual original universe arguments"
    let .const _ innerUs := nested.getAppFn | throwError "Expected original nested universe arguments"
    unless us == innerUs && us.length == 1 do throwError "Original universe arguments differ"
    let dd := inner[3]!
    -- Reuse the exact R/CommRing/dd expressions already present. No typeclass synthesis.
    let ringProof := mkAppN (.const `IsDedekindDomain.toIsDedekindRing us) #[args[0]!,args[1]!,dd]
    let replacement := mkAppN (.const `IsDedekindRing.toDimensionLEOne us) #[args[0]!,args[1]!,ringProof]
    let expected ← inferType e
    unless ← isProp expected do throwError "Dimension substitution would replace non-Prop data"
    let originalClosed ← mkLambdaFVars xs e
    let replacementClosed ← mkLambdaFVars xs replacement
    let ddClosed ← mkLambdaFVars xs dd
    let originalTYPE ← kernelCheck "original saturated dimension proof" originalClosed
    let replacementTYPE ← kernelCheck "shared primitive projection dimension proof" replacementClosed
    kernelEq "original/shared dimension complete TYPE" originalTYPE replacementTYPE
    kernelEq "original/shared dimension complete Prop proof" originalClosed replacementClosed
    let equality ← mkEq originalClosed replacementClosed
    let equalityProof ← mkEqRefl originalClosed
    kernelEq "per-occurrence dimension equality certificate TYPE"
      (← kernelCheck "per-occurrence dimension equality certificate" equalityProof) equality
    let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
    for term in #[originalClosed,replacementClosed,equalityProof] do
      ensureStandard "per-occurrence dimension proof" (← expressionAxioms cache term)
    return (replacement,#[Json.mkObj [
      ("originalExprPath",toJson path),("originalExactSaturatedArgumentCount",toJson args.size),
      ("originalCompleteProofAbstractedOverOriginalParameters",← checked (encodeExpr originalClosed)),
      ("replacementCompleteProofAbstractedOverOriginalParameters",← checked (encodeExpr replacementClosed)),
      ("originalCompleteTYPE",← checked (encodeExpr originalTYPE)),
      ("replacementCompleteTYPE",← checked (encodeExpr replacementTYPE)),
      ("exactExistingDedekindDomainTerm",← checked (encodeExpr ddClosed)),
      ("sameOriginalRCommRingAndDdArgumentsUsed",toJson true),
      ("wholePropTYPEKernelEqual",toJson true),("wholePropValuesKernelEqual",toJson true),
      ("equalityExpr",← checked (encodeExpr equality)),
      ("equalityProofExpr",← checked (encodeExpr equalityProof)),
      ("equalityProofKernelChecked",toJson true),("newDataArgumentOrAssumptionIntroduced",toJson false)]])
  match e with
  | .app f a =>
    let (f,fr) ← replaceDimension xs f (path ++ ".fn")
    let (a,ar) ← replaceDimension xs a (path ++ ".arg")
    return (.app f a,fr ++ ar)
  | .lam n t b bi =>
    let (t,tr) ← replaceDimension xs t (path ++ ".type")
    let (b,br) ← replaceDimension xs b (path ++ ".body")
    return (.lam n t b bi,tr ++ br)
  | .forallE n t b bi =>
    let (t,tr) ← replaceDimension xs t (path ++ ".type")
    let (b,br) ← replaceDimension xs b (path ++ ".body")
    return (.forallE n t b bi,tr ++ br)
  | .letE n t v b nd =>
    let (t,tr) ← replaceDimension xs t (path ++ ".type")
    let (v,vr) ← replaceDimension xs v (path ++ ".value")
    let (b,br) ← replaceDimension xs b (path ++ ".body")
    return (.letE n t v b nd,tr ++ vr ++ br)
  | .mdata md b =>
    let (b,br) ← replaceDimension xs b path
    return (.mdata md b,br)
  | .proj n i b =>
    let (b,br) ← replaceDimension xs b (path ++ ".body")
    return (.proj n i b,br)
  | _ => return (e,#[])

partial def deltaOnlyFG (value : Expr) (params : List Name) : Expr → Expr
  | .const n us => if n == `AddMonoid.fg_of_addGroup_fg then value.instantiateLevelParams params us else .const n us
  | .app f a => .app (deltaOnlyFG value params f) (deltaOnlyFG value params a)
  | .lam n t b bi => .lam n (deltaOnlyFG value params t) (deltaOnlyFG value params b) bi
  | .forallE n t b bi => .forallE n (deltaOnlyFG value params t) (deltaOnlyFG value params b) bi
  | .letE n t v b nd => .letE n (deltaOnlyFG value params t) (deltaOnlyFG value params v) (deltaOnlyFG value params b) nd
  | .mdata md b => .mdata md (deltaOnlyFG value params b)
  | .proj n i b => .proj n i (deltaOnlyFG value params b)
  | e => e

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_RESIDUECHAR_PRIME_NATIVE_SHARED_PROJECTION_V203")
  unless (← checked (stringField cfg "schema")) == "B1-residueChar-prime-native-shared-projection-config/v203" do
    throwError "Wrong native shared projection configuration"
  let nr ← checked (field cfg "originalNativeRecord")
  let root := `AbcAdaptation.Reference.Iut.residueChar_prime
  let ci ← getConstInfo root
  unless (← checked (decodeName (← checked (field nr "nameExpr")))) == root &&
      moduleOf (← getEnv) root == some `Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_LocalHeightDataAssembly &&
      kind ci == "theorem" && ci.levelParams.length == 1 && (← isProp ci.type) do
    throwError "Wrong exact original native whole Prop theorem"
  let some raw := ci.value? (allowOpaque := true) | throwError "Missing original native full proof"
  unless (← checked (field nr "actualTypeExpr")) == (← checked (encodeExpr ci.type)) &&
      (← checked (field nr "actualValueExpr")) == (← checked (encodeExpr raw)) do
    throwError "Original native full TYPE/value differs"
  let sourceRows ← checked (arrayField cfg "actualSourceSharedProjectionMetadata")
  let wanted := #[`IsDedekindDomain.toIsDedekindRing,`IsDedekindRing.toDimensionLEOne]
  unless sourceRows.size == 2 do throwError "Expected two actual source primitive projection metadata rows"
  let mut projectionFacts : Array Json := #[]
  for n in wanted do
    let rows := sourceRows.filter fun r => (field r "nameExpr").toOption == some (encodeName n)
    unless rows.size == 1 && (← checked (rows[0]!.getObjValAs? Nat "declaredUniverseParameterCount")) == 1 do
      throwError "Shared primitive projection is absent from actual source name/arity inventory {n}"
    let info ← getConstInfo n
    unless info.levelParams.length == 1 do throwError "Actual native primitive projection universe arity differs"
    projectionFacts := projectionFacts.push (Json.mkObj [("nameExpr",encodeName n),
      ("actualNativeCompleteTYPE",← checked (encodeExpr info.type)),("actualSourceMetadata",rows[0]!)])
  let fg ← getConstInfo `AddMonoid.fg_of_addGroup_fg
  unless ← isProp fg.type do throwError "FG delta target is not a complete Prop proof"
  let some fgValue := fg.value? (allowOpaque := true) | throwError "Missing original complete FG proof"
  kernelEq "original FG full value TYPE" (← kernelCheck "original FG full value" fgValue) fg.type
  let fgConstant := Lean.mkConst fg.name (fg.levelParams.map Level.param)
  kernelEq "original FG constant/value" fgConstant fgValue
  let fgEquality ← mkEq fgConstant fgValue
  let fgEqualityProof ← mkEqRefl fgConstant
  kernelEq "original FG constant/value equality certificate TYPE"
    (← kernelCheck "FG proof equality certificate" fgEqualityProof) fgEquality
  kernelEq "original native complete whole proof TYPE" (← kernelCheck "original native whole proof" raw) ci.type
  let (projected,occurrences) ← forallTelescope ci.type fun xs _ => do
    unless xs.size == 4 do throwError "Original whole Prop telescope must retain k/Field/NumberField/w"
    let body := raw.beta xs
    let (body,reports) ← replaceDimension xs body "originalWholeProof.body"
    let whole ← mkLambdaFVars xs body
    return (whole,reports)
  unless occurrences.size == 2 do throwError "Expected exactly the two actual saturated dimension-proof occurrences"
  kernelEq "shared projection whole TYPE" (← kernelCheck "shared projection whole proof" projected) ci.type
  kernelEq "original/shared projection whole proof" raw projected
  let portable ← Lean.Core.betaReduce (deltaOnlyFG fgValue fg.levelParams projected)
  kernelEq "portable complete whole proof TYPE" (← kernelCheck "portable full proof" portable) ci.type
  kernelEq "original/portable complete whole proof" raw portable
  let equality ← mkEq raw portable
  let equalityProof ← mkEqRefl raw
  kernelEq "complete whole-proof equality certificate TYPE"
    (← kernelCheck "complete whole-proof equality certificate" equalityProof) equality
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let axs ← expressionAxioms cache portable
  ensureStandard "portable whole proof" axs
  for n in portable.getUsedConstants do
    if (`IsDedekindDomainDvr).isPrefixOf n || n == `IsDedekindDomain.isDedekindDomainDvr ||
        n == `AddMonoid.fg_of_addGroup_fg then throwError "Obsolete proof path remains in portable proof {n}"
  let mut uses : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  for (label,e) in #[("portableWholeTYPE",ci.type),("portableWholeProof",portable)] do
    for (n,k) in constantUses e do
      unless seen.contains (n,k) do
        seen := seen.push (n,k)
        let info ← getConstInfo n
        uses := uses.push (Json.mkObj [("nameExpr",encodeName n),("universeArgumentCount",toJson k),
          ("firstActualUse",toJson label),("actualNativeDeclarationIsProp",toJson (← isProp info.type)),
          ("actualNativeUniverseParameterCount",toJson info.levelParams.length)])
  jsonOutput (← checked (stringField cfg "outputFile")) (Json.mkObj [
    ("schema",toJson "B1-residueChar-prime-native-shared-projection/v203"),
    ("status",toJson "accepted-native-shared-primitive-projection-wholeproof-certificate"),
    ("configuration",cfg),("compilerVersion",toJson Lean.versionString),
    ("originalNativeRecord",nr),("originalWholeTYPE",← checked (encodeExpr ci.type)),
    ("originalWholeProof",← checked (encodeExpr raw)),("sharedProjectionWholeProof",← checked (encodeExpr projected)),
    ("portableWholeTYPE",← checked (encodeExpr ci.type)),("portableWholeProof",← checked (encodeExpr portable)),
    ("dimensionReplacementOccurrences",Json.arr occurrences),("sharedPrimitiveProjectionFacts",Json.arr projectionFacts),
    ("originalFGCompleteTYPE",← checked (encodeExpr fg.type)),("originalFGCompleteValue",← checked (encodeExpr fgValue)),
    ("originalFGEqualityExpr",← checked (encodeExpr fgEquality)),("originalFGEqualityProof",← checked (encodeExpr fgEqualityProof)),
    ("wholeProofEqualityExpr",← checked (encodeExpr equality)),("wholeProofEqualityProof",← checked (encodeExpr equalityProof)),
    ("portableActualConstantUses",Json.arr uses),("axioms",toJson (axs.map Name.toString)),
    ("originalAndReplacementCompletePropTypesKernelChecked",toJson true),
    ("everyOccurrenceSamePropEqualityCertificateKernelChecked",toJson true),
    ("wholeProofEqualityCertificateKernelChecked",toJson true),("sourceActualProjectionNamesAndAritiesBound",toJson true),
    ("sameExactExistingDedekindDomainArgumentsUsed",toJson true),("onlyFGOriginalPropValueDeltaExpanded",toJson true),
    ("wholeTYPEChanged",toJson false),("nonPropositionalDataReplaced",toJson false),
    ("newMathematicalParametersAdded",toJson false),("synthInstanceUsed",toJson false),
    ("fallbackProofProduced",toJson false),("sourceKernelPortabilityAccepted",toJson false)])
  logInfo "Native whole Prop certified with exact existing Dedekind-domain primitive projections and original FG proof delta"
end ResidueCharPrimeNativeSharedProjection
