## Original paper background

Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position* (February 2009), §3, complete local-theory setup paragraph, printed/PDF pages 14–15:

> Next, we consider the local theory at nonarchimedean primes. Let $K$ be a finite extension of $\mathbb Q_p$ [where $p$ is a prime number] with residue field $k$, maximal ideal $\mathfrak m_K\subseteq\mathcal O_K$, and valuation map $v_K:K^\times\to\mathbb Z$ [which we normalize so that $v_K$ is surjective]; $\overline K$ an algebraic closure of $K$; $G_K\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline K/K)$; $E\to\operatorname{Spec}(\mathcal O_K)$ a one-dimensional semi-abelian scheme over $\mathcal O_K$ such that the generic fiber $E_K$ of $E$ is proper, while the special fiber $E_k$ of $E$ is isomorphic to $(\mathbb G_m)_k$, the multiplicative group over $k$.

Definition 3.3, complete definition, printed/PDF page 15:

> We shall refer to the positive integer $v_K(q_E)\in\mathbb Z_{>0}$ as the local height of $E$ [or $E_K$].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, proof of Corollary 2.2(ii), complete paragraph beginning “Next, let us write”, printed/PDF page 44:

> Next, let us write

> $$h\overset{\mathrm{def}}{=}\log(q^{\forall})=\frac{1}{[F:\mathbb Q]}\cdot\sum_{v\in\mathbb V(F)^{\mathrm{non}}}h_v\cdot f_v\cdot\log(p_v)$$

> — that is to say, $h_v=0$ for those $v$ at which $E_F$ has good reduction; $h_v\in\mathbb N_{\geq1}$ is the local height of $E_F$ [cf. [GenEll], Definition 3.3] for those $v$ at which $E_F$ has bad multiplicative reduction. Now it follows [by assertion (i); [GenEll], Proposition 1.4, (iv)] that the inequality $h^{1/2}<\xi_{\mathrm{prm}}$ [cf. the notation of Proposition 2.1, (ii)] implies that there is only a finite number of possibilities for the $j$-invariant of $E_F$. Thus, by possibly enlarging the finite set $\mathfrak{Exc}_d$ [in a fashion that depends only on $K_V$, $d$, and $\epsilon_d$ and in such a way that $h\leq H_{\mathrm{unif}}$ on $\mathfrak{Exc}_d$ for some positive real number $H_{\mathrm{unif}}$ that is independent of $K_V$], we may assume without loss of generality that the inequality

> $$h^{1/2}\geq\xi_{\mathrm{prm}}\geq5$$

> holds.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`.

These passages explain local Tate-parameter orders and the residue-degree-weighted height expression. The reference project assembles a finite record from a curve, its supplied arithmetic certificate, and its separately supplied Tate-input record. It uses the chosen norm-generator order at multiplicative places, the residue characteristic and inertia degree, and the field degree. The helper proves primality of every finite-place residue characteristic. This assembly does not construct either input certificate or identify its returned height with another named height. The threshold argument in the quoted paragraph gives context for later use; it is not an output of this definition.
