## 论文原文背景

望月新一，*Arithmetic Elliptic Curves in General Position*，2009 年 2 月版，第 3 节，局部理论设定的完整段落，印刷页与文件页均为第 14–15 页；定义 3.3 全文位于印刷页与文件页第 15 页。精确英文引文见英文部分。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`。

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2(ii) 的证明中以“Next, let us write”开头、至“holds.”结束的完整段落，印刷页与文件页均为第 44 页。精确英文引文见英文部分。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

这些段落说明局部 Tate 参数的阶以及以惯性度加权的高度表达式。参考工程接收曲线、已提供的算术证书，以及另行提供的 Tate 输入记录，将它们装配成有限记录。装配在乘性约化处采用所选范数生成元给出的阶，并使用剩余特征、惯性度和域的次数。辅助引理证明每个有限处的剩余特征都是素数。此装配未构造两项输入证书，也未将输出高度等同于其他已命名高度。引文中的阈值论证交代后续使用背景，并非此定义的输出。
