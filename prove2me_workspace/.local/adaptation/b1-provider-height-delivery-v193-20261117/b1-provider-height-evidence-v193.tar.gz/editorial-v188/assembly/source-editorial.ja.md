## 論文原文の背景

望月新一、*Arithmetic Elliptic Curves in General Position*、2009 年 2 月版、第 3 節、局所理論の設定を述べる完全な段落、印刷・PDF ファイルページ 14–15。定義 3.3 の全文は印刷・PDF ファイルページ 15 にある。正確な英文は英語部分に示す。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`。

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2(ii) の証明中の「Next, let us write」から「holds.」までの完全な段落、印刷・PDF ファイルページ 44。正確な英文は英語部分に示す。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

これらの段落は、局所的な Tate パラメータの位数と、惰性次数で重み付けした高さの式を説明する。参照プロジェクトは、曲線、与えられた算術的証明書、および別に与えられた Tate 入力レコードから有限のレコードを構成する。乗法的還元の場所では、選ばれたノルム生成元による位数を用い、剰余標数、惰性次数、および体の次数を格納する。補助補題は、すべての有限素点で剰余標数が素数であることを示す。この構成は二つの入力証明書を構成せず、出力の高さが他の名前付きの高さに等しいとも主張しない。引用段落の閾値の議論は後続の用途の背景であり、この定義の出力ではない。
