## Original paper background

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

> Suppose that $X=\mathbb P^1_{\mathbb Q}$ is the projective line over $\mathbb Q$, and that $D\subseteq X$ is the divisor consisting of the three points “$0$”, “$1$”, and “$\infty$”. We shall regard $X$ as the “$\lambda$-line” — i.e., we shall regard the standard coordinate on $X=\mathbb P^1_{\mathbb Q}$ as the “$\lambda$” in the Legendre form “$y^2=x(x-1)(x-\lambda)$” of the Weierstrass equation defining an elliptic curve — and hence as being equipped with a natural classifying morphism $U_X\to(\mathcal M_{\mathrm{ell}})_{\mathbb Q}$ [cf. the discussion preceding Proposition 1.8].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`. Later corollary material is omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

> $F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`.

These passages give the Legendre-family and algebraic-closure background. The reference project defines the four-field provider interface and the curve selector. Its two finiteness fields range over all algebraic parameters, including 0 and 1. Its arithmetic and representation fields refer to the curve assembled with those same finiteness fields. The representation field takes every natural-number prime as an argument. The interface asks for these records; it does not construct a provider or establish its existence.
