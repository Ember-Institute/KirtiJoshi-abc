## 論文原文の背景

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示す。系の後続部分は引用しない。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61。正確な英文は英語部分に示す。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

これらの段落は、ルジャンドル曲線族と代数閉包の背景を与える。四つのフィールドからなる供給インターフェースと曲線の選択関数は、参照プロジェクトの定義である。二つの有限性のフィールドは 0 と 1 を含むすべての代数的パラメータを対象とする。算術と表現のフィールドは、同じ有限性の証明から構成される曲線に依存する。表現のフィールドは、任意の自然数の素数を引数とする。このインターフェースはそれらのレコードを入力として要求するものであり、供給レコードを構成したり、その存在を証明したりするものではない。
