from pathlib import Path
import json,hashlib,shutil
from datetime import datetime,timezone
O=Path('/tmp/p2m-b1-provider-height-publication-v188-20261117');D=Path('/tmp/p2m-b1-provider-height-draft-v184-20261117');V=Path('/tmp/p2m-b1-curveof-assembly-publication-v177-20261117');R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def writejson(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
prev=json.loads((V/'paper-context.json').read_text());ctx={'schema':'B1-provider-local-height-original-paper-background/v188','created_utc':datetime.now(timezone.utc).isoformat(),'papers':prev['papers'],'reused_background':rec(V/'paper-context.json'),'quotations':prev['quotations'],'paper_scope':'Original paper background; local interfaces and conditional assembly are reference-project constructions. No existence of suppliers or height-comparison theorem is inferred.','network_or_download':False}
gen=R/'refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf'
ctx['papers']['GenEll']={'author':'Shinichi Mochizuki','title':'Arithmetic Elliptic Curves in General Position','version':'February 2009','official_url':'https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf','local_pdf':str(gen),'sha256':sha(gen),'acquired_date':'2026-11-12, according to docs/三语术语名词关键对照.md; reused local file, no download in this task','file_page_numbering':'Cited file pages 14 and 15 have identical printed page numbers.'}
qsetup=r'''Next, we consider the local theory at nonarchimedean primes. Let $K$ be a finite extension of $\mathbb Q_p$ [where $p$ is a prime number] with residue field $k$, maximal ideal $\mathfrak m_K\subseteq\mathcal O_K$, and valuation map $v_K:K^\times\to\mathbb Z$ [which we normalize so that $v_K$ is surjective]; $\overline K$ an algebraic closure of $K$; $G_K\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline K/K)$; $E\to\operatorname{Spec}(\mathcal O_K)$ a one-dimensional semi-abelian scheme over $\mathcal O_K$ such that the generic fiber $E_K$ of $E$ is proper, while the special fiber $E_k$ of $E$ is isomorphic to $(\mathbb G_m)_k$, the multiplicative group over $k$.'''
qdef=r'''We shall refer to the positive integer $v_K(q_E)\in\mathbb Z_{>0}$ as the local height of $E$ [or $E_K$].'''
qh=r'''Next, let us write

$$h\overset{\mathrm{def}}{=}\log(q^{\forall})=\frac{1}{[F:\mathbb Q]}\cdot\sum_{v\in\mathbb V(F)^{\mathrm{non}}}h_v\cdot f_v\cdot\log(p_v)$$

— that is to say, $h_v=0$ for those $v$ at which $E_F$ has good reduction; $h_v\in\mathbb N_{\geq1}$ is the local height of $E_F$ [cf. [GenEll], Definition 3.3] for those $v$ at which $E_F$ has bad multiplicative reduction. Now it follows [by assertion (i); [GenEll], Proposition 1.4, (iv)] that the inequality $h^{1/2}<\xi_{\mathrm{prm}}$ [cf. the notation of Proposition 2.1, (ii)] implies that there is only a finite number of possibilities for the $j$-invariant of $E_F$. Thus, by possibly enlarging the finite set $\mathfrak{Exc}_d$ [in a fashion that depends only on $K_V$, $d$, and $\epsilon_d$ and in such a way that $h\leq H_{\mathrm{unif}}$ on $\mathfrak{Exc}_d$ for some positive real number $H_{\mathrm{unif}}$ that is independent of $K_V$], we may assume without loss of generality that the inequality

$$h^{1/2}\geq\xi_{\mathrm{prm}}\geq5$$

holds.'''
for id,paper,loc,pages,q in [('GenEll-local-setup','GenEll','§3, complete local-theory setup paragraph before the mod-l Tate module',[14,15],qsetup),('GenEll-local-height','GenEll','§3, Definition 3.3, complete definition',[15],qdef),('IV-local-global-height','IV','§2, proof of Corollary 2.2(ii), complete paragraph from Next, let us write through holds.',[44],qh)]:ctx['quotations'].append({'id':id,'paper':paper,'locator':loc,'printed_pages':pages,'file_pages':pages,'quote_markdown':q,'typography':'Original PDF visually checked in v188. Line breaks, line-end hyphenation, and ligatures normalized; mathematical typography transcribed to renderable LaTeX. No prose splicing.'})
ctx['visual_evidence']=[rec(p) for p in (O/'paper-evidence').glob('*.png')];writejson(O/'paper-context.json',ctx)
shutil.copyfile(V/'source-LICENSE-Apache-2.0.txt',O/'source-LICENSE-Apache-2.0.txt');shutil.copyfile(D/'source-provenance.json',O/'source-provenance.v184.json')
quote=lambda x:'\n\n'.join('\n'.join('> '+line if line else '>' for line in p.splitlines()) for p in x.split('\n\n'))
iurl=ctx['papers']['I']['official_url'];ivurl=ctx['papers']['IV']['official_url'];gurl=ctx['papers']['GenEll']['official_url'];ilocal=ctx['papers']['I']['local_pdf'];ivlocal=ctx['papers']['IV']['local_pdf']
provider_en='''## Original paper background

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

'''+quote(prev['quotations'][0]['quote_markdown'])+f'''

Official original: {ivurl}. Local original: `{ivlocal}`. Later corollary material is omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

'''+quote(prev['quotations'][1]['quote_markdown'])+f'''

Official original: {iurl}. Local original: `{ilocal}`.

These passages give the Legendre-family and algebraic-closure background. The reference project defines the four-field provider interface and the curve selector. Its two finiteness fields range over all algebraic parameters, including 0 and 1. Its arithmetic and representation fields refer to the curve assembled with those same finiteness fields. The representation field takes every natural-number prime as an argument. The interface asks for these records; it does not construct a provider or establish its existence.
'''
provider_zh=f'''## 论文原文背景

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2 开头、“Let”之前的完整两句，印刷页与文件页均为第 41 页。精确英文引文见英文部分；推论后续内容未引用。官方原文：{ivurl}。本地原文：`{ivlocal}`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页。精确英文引文见英文部分。官方原文：{iurl}。本地原文：`{ilocal}`。

这些段落提供 Legendre 曲线族与代数闭包的背景。四字段供应接口及曲线选择函数由参考工程定义。两个有限性字段覆盖全部代数参数，包括 0 和 1；算术与表示字段依赖由同一组有限性证明组装的曲线。表示字段以任意自然数素数为参数。此接口要求提供这些记录，并未构造供应记录或证明其存在。
'''
provider_ja=f'''## 論文原文の背景

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示す。系の後続部分は引用しない。公式原文：{ivurl}。ローカル原文：`{ivlocal}`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61。正確な英文は英語部分に示す。公式原文：{iurl}。ローカル原文：`{ilocal}`。

これらの段落は、ルジャンドル曲線族と代数閉包の背景を与える。四つのフィールドからなる供給インターフェースと曲線の選択関数は、参照プロジェクトの定義である。二つの有限性のフィールドは 0 と 1 を含むすべての代数的パラメータを対象とする。算術と表現のフィールドは、同じ有限性の証明から構成される曲線に依存する。表現のフィールドは、任意の自然数の素数を引数とする。このインターフェースはそれらのレコードを入力として要求するものであり、供給レコードを構成したり、その存在を証明したりするものではない。
'''
assembly_en='''## Original paper background

Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position* (February 2009), §3, complete local-theory setup paragraph, printed/PDF pages 14–15:

'''+quote(qsetup)+'''

Definition 3.3, complete definition, printed/PDF page 15:

'''+quote(qdef)+f'''

Official original: {gurl}. Local original: `{gen}`.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, proof of Corollary 2.2(ii), complete paragraph beginning “Next, let us write”, printed/PDF page 44:

'''+quote(qh)+f'''

Official original: {ivurl}. Local original: `{ivlocal}`.

These passages explain local Tate-parameter orders and the residue-degree-weighted height expression. The reference project assembles a finite record from a curve, its supplied arithmetic certificate, and its separately supplied Tate-input record. It uses the chosen norm-generator order at multiplicative places, the residue characteristic and inertia degree, and the field degree. The helper proves primality of every finite-place residue characteristic. This assembly does not construct either input certificate or identify its returned height with another named height. The threshold argument in the quoted paragraph gives context for later use; it is not an output of this definition.
'''
assembly_zh=f'''## 论文原文背景

望月新一，*Arithmetic Elliptic Curves in General Position*，2009 年 2 月版，第 3 节，局部理论设定的完整段落，印刷页与文件页均为第 14–15 页；定义 3.3 全文位于印刷页与文件页第 15 页。精确英文引文见英文部分。官方原文：{gurl}。本地原文：`{gen}`。

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2(ii) 的证明中以“Next, let us write”开头、至“holds.”结束的完整段落，印刷页与文件页均为第 44 页。精确英文引文见英文部分。官方原文：{ivurl}。本地原文：`{ivlocal}`。

这些段落说明局部 Tate 参数的阶以及以惯性度加权的高度表达式。参考工程接收曲线、已提供的算术证书，以及另行提供的 Tate 输入记录，将它们装配成有限记录。装配在乘性约化处采用所选范数生成元给出的阶，并使用剩余特征、惯性度和域的次数。辅助引理证明每个有限处的剩余特征都是素数。此装配未构造两项输入证书，也未将输出高度等同于其他已命名高度。引文中的阈值论证交代后续使用背景，并非此定义的输出。
'''
assembly_ja=f'''## 論文原文の背景

望月新一、*Arithmetic Elliptic Curves in General Position*、2009 年 2 月版、第 3 節、局所理論の設定を述べる完全な段落、印刷・PDF ファイルページ 14–15。定義 3.3 の全文は印刷・PDF ファイルページ 15 にある。正確な英文は英語部分に示す。公式原文：{gurl}。ローカル原文：`{gen}`。

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2(ii) の証明中の「Next, let us write」から「holds.」までの完全な段落、印刷・PDF ファイルページ 44。正確な英文は英語部分に示す。公式原文：{ivurl}。ローカル原文：`{ivlocal}`。

これらの段落は、局所的な Tate パラメータの位数と、惰性次数で重み付けした高さの式を説明する。参照プロジェクトは、曲線、与えられた算術的証明書、および別に与えられた Tate 入力レコードから有限のレコードを構成する。乗法的還元の場所では、選ばれたノルム生成元による位数を用い、剰余標数、惰性次数、および体の次数を格納する。補助補題は、すべての有限素点で剰余標数が素数であることを示す。この構成は二つの入力証明書を構成せず、出力の高さが他の名前付きの高さに等しいとも主張しない。引用段落の閾値の議論は後続の用途の背景であり、この定義の出力ではない。
'''
editorials={'provider':{'en':provider_en,'zh-Hans':provider_zh,'ja':provider_ja},'assembly':{'en':assembly_en,'zh-Hans':assembly_zh,'ja':assembly_ja}}
intuitions={'provider':{'en':'A provider keeps the two torsion-finiteness families and the arithmetic and representation inputs for the resulting curves together. The selector returns the curve determined by a parameter point and those finiteness inputs.','zh-Hans':'供应记录将两族挠点有限性证明与相应曲线的算术、表示输入保存在一起。选择函数返回由参数点和这些有限性输入确定的曲线。','ja':'供給レコードは、二つの等分点有限性の族と、対応する曲線の算術および表現の入力をまとめる。選択関数は、パラメータ点とそれらの有限性の入力によって定まる曲線を返す。'},'assembly':{'en':'Once the arithmetic and Tate inputs are supplied, the assembly collects local orders, residue characteristics, and inertia degrees into one finite height record. The height then averages the weighted logarithmic local terms by the number-field degree.','zh-Hans':'给定算术输入与 Tate 输入后，装配将局部阶、剩余特征和惯性度汇集成一个有限高度记录。高度再按数域次数归一化这些带权的局部对数项。','ja':'算術入力と Tate 入力を与えると、この構成は局所的な位数、剰余標数、および惰性次数を一つの有限の高さレコードにまとめる。その高さは、重み付きの局所対数項を数体の次数で正規化する。'}}
commit='07cb1da58f6d428a670dbb5dd6093d428bcbcdd8';blob='https://github.com/lana-agents/iut/blob/'+commit+'/'
units=[('provider','Tripod_CurveProviders','Curve providers and their selected curve — 曲线供应记录及其选择的曲线 — 曲線供給レコードとその選択曲線',[('Iut/Tripod/CurveFacts.lean',361,377),('Iut/Tripod/CurveFacts.lean',383,385)]),('assembly','Concrete_LocalHeightDataAssembly','Local height data from arithmetic and Tate inputs — 由算术与 Tate 输入装配局部高度数据 — 算術入力と Tate 入力による局所高さデータの構成',[('Iut/Cor312/ThetaData/Places.lean',75,82),('Iut/Concrete/Existence.lean',194,213)])]
prov={'schema':'B1-provider-height-code-publication-provenance/v188','original_repository':'https://github.com/lana-agents/iut','original_commit':commit,'copyright':'Copyright (c) 2026 The iut contributors. All rights reserved.','license':'Apache-2.0','license_copy':rec(O/'source-LICENSE-Apache-2.0.txt'),'source_AST_provenance':rec(D/'source-provenance.json'),'units':[]}
for label,suffix,title,spans in units:
 for lang,s in editorials[label].items():(O/label/f'source-editorial.{lang}.md').write_text(s)
 writejson(O/label/'intuitions.json',intuitions[label])
 source='Original code: lana-agents/iut, commit '+commit+'; The iut contributors, Apache-2.0. '+' '.join(blob+path+f'#L{start}-L{end}' for path,start,end in spans)+'. '
 if label=='provider':source+='Original mathematical background: Shinichi Mochizuki, Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations (April 2020), §2, Corollary 2.2 opening, printed/PDF p.41; Inter-universal Teichmüller Theory I: Construction of Hodge Theaters (May 2020), §3, Definition 3.1(a), printed/PDF p.61. The provider interface and selector are reference-project constructions. '+ivurl+' '+iurl
 else:source+='Original mathematical background: Shinichi Mochizuki, Arithmetic Elliptic Curves in General Position (February 2009), §3, local-theory setup pp.14–15 and Definition 3.3 p.15; Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations (April 2020), §2, proof of Corollary 2.2(ii), p.44 (printed/PDF pages). The eleven-field conditional assembly is a reference-project construction. '+gurl+' '+ivurl
 fields={'name':'AbcAdaptation_Reference_Iut_'+suffix,'title':title,'source':source,'env':'0df444a360eaa60ab8c11dca51a86af692955474','private':True};assert len(title)<=200;writejson(O/label/'publication-fields.preliminary.json',fields)
 draft=D/'definitions'/('Def_'+fields['name']+'.lean');canonical=W/'Definitions'/draft.name
 prov['units'].append({'bundle':label,'draft_observed':rec(draft),'canonical_observed':rec(canonical) if canonical.exists() else None,'canonical_final_SHA_confirmation':'PENDING_MAIN_AGENT','source_spans':[{'source_path':p,'start_line':s,'end_line':e,'code_blob_url':blob+p+f'#L{s}-L{e}'} for p,s,e in spans]})
writejson(O/'code-provenance.json',prov)
writejson(O/'metadata.preliminary.json',{'schema':'B1-provider-height-publication-editorial/v188','status':'PREPARED_SOURCE_EDITORIAL_AWAITING_CANONICAL_SHA_AND_FROZEN_THREE_LANGUAGE_MANIFEST','created_utc':datetime.now(timezone.utc).isoformat(),'operations':{'main_workspace_written':False,'CI_compiler_API_Git_executed':False,'publication_performed':False},'frozen_readback_path':'/tmp/p2m-b1-provider-height-fresh-blind-v185-20261117','frozen_body_not_assembled':True,'source_editorial':{unit:{lang:rec(O/unit/f'source-editorial.{lang}.md') for lang in ['en','zh-Hans','ja']} for unit in editorials},'process_metadata_in_product_body':False})
print(json.dumps({'prepared':str(O),'titles':[u[2] for u in units],'final_payloads_not_yet_assembled':True},ensure_ascii=False,indent=2))
