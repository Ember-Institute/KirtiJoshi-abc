import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_EllipticCurveData

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]

def validateSupport (maps : NameMap) (rows : Array Json) : MetaM Unit := do
  for p in rows do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) && (← checked (p.getObjValAs? Bool "isClosed")) && (← checked (arrayField p "levelParams")).isEmpty do
      throwError "Invalid actual closed proof support {n}"
    let t ← checked (relocateExpr maps rows #[] true (← checked (field p "actualTypeExpr")))
    let v ← checked (relocateExpr maps rows #[n] true (← checked (field p "actualProofExpr")))
    let vt ← kernelCheck s!"proof support {n}" v
    unless ← isProp vt do throwError "Support proof would replace data {n}"
    kernelEq s!"proof support TYPE {n}" vt t
    ensureStandard s!"expanded proof support {n}" (← expressionAxioms v)


def sameBound (label : String) (a b : Json) : MetaM Unit :=
  unless a == b do throwError "Bound actual fact differs {label}"

def writeOutput (path : String) (j : Json) : MetaM Unit := do
  unless path.startsWith "/" do throwError "Expected absolute output path"
  if let some parent := (System.FilePath.mk path).parent then IO.FS.createDirAll parent
  IO.FS.writeFile path (j.pretty ++ "\n")

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]


def canonicalStructureMetadata (j : Json) : MetaM Json := do
  let rawFields ← checked (arrayField j "fieldsSortedByName")
  let fields ← rawFields.mapM fun r => do
    return (← checked (decodeName (← checked (field r "fieldName"))), r)
  let fields := (fields.qsort fun a b => Name.lt a.1 b.1).map (·.2)
  return Json.mkObj [
    ("structure",← checked (field j "structure")),
    ("fieldNamesInConstructorOrder",← checked (field j "fieldNamesInConstructorOrder")),
    ("fieldsSortedByName",Json.arr fields),
    ("parentsInExtendsOrder",← checked (field j "parentsInExtendsOrder"))]


def normalizedCertificate (certificates : Array Json) (nameExpr : Json) (label : String)
    (raw normalized : Json) : MetaM Json := do
  let selected := certificates.filter fun c =>
    (field c "nameExpr").toOption == some nameExpr &&
    (stringField c "label").toOption == some label
  unless selected.size == 1 do throwError "Missing unique source normalization certificate for {label}"
  let cert := selected[0]!
  sameBound "certificate complete raw Expr" raw (← checked (field cert "rawExpression"))
  sameBound "certificate complete normalized Expr" normalized (← checked (field cert "normalizedExpression"))
  unless (← checked (cert.getObjValAs? Bool "completeExprKernelDefEq")) &&
      (← checked (cert.getObjValAs? Bool "completeEqualityProofKernelChecked")) do
    throwError "Source complete normalization equality was not kernel checked"
  let uses ← checked (cert.getObjValAs? Nat "normalizedUses")
  unless (← checked (arrayField cert "proofApplications")).size == uses do
    throwError "Source normalization occurrence/context-proof evidence count differs"
  sameBound "source public quantifier BinderInfo unchanged by normalization"
    (← checked (field cert "rawOuterForallBinderInfo"))
    (← checked (field cert "normalizedOuterForallBinderInfo"))
  return cert

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native target4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_BARE_NORMALIZED_AUDIT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-bare-normalized-audit-config/v120" do
    throwError "Wrong normalized bare audit configuration"
  let norm ← jsonFile (← checked (stringField cfg "sourceNormalizationFile"))
  sameBound "complete source runtime normalization output" norm
    (← checked (field (← checked (field cfg "sourceNormalizationBinding")) "contents"))
  unless (← checked (stringField norm "schema")) == "B1-bare-source-Prop-proof-normalization/v118" &&
      (← checked (norm.getObjValAs? Bool "sourceKernelNormalizationChecked")) &&
      !(← checked (norm.getObjValAs? Bool "nonPropositionalDataReplacementUsed")) &&
      (← checked (norm.getObjValAs? Nat "totalNormalizedUses")) == 5 do
    throwError "Source same-Prop normalization producer is not fully checked"
  let sourceJob ← checked (stringField cfg "acceptedSourceNormalizationJob")
  unless sourceJob.startsWith "ci-" do throwError "Missing source normalization CI provenance"
  let native ← jsonFile (← checked (stringField cfg "nativeFactsFile"))
  sameBound "complete native actual twelve facts" native
    (← checked (field (← checked (field cfg "nativeFactsBinding")) "contents"))
  unless (← checked (stringField native "schema")) == "B1-bare-native-twelve-actual-facts/v119" &&
      (← checked (native.getObjValAs? Bool "actualKernelValuesAndRecursorRulesChecked")) &&
      (← checked (native.getObjValAs? Bool "standardAxiomAuditPassed")) do
    throwError "Native twelve full actual facts were not checked"
  let original ← jsonFile (← checked (stringField cfg "originalBareInputsFile"))
  sameBound "original bare source fact selection" original
    (← checked (field (← checked (field cfg "originalBareInputsBinding")) "contents"))
  let rawRows ← checked (arrayField norm "sourceRecords")
  let rows ← checked (arrayField norm "normalizedSourceRecords")
  sameBound "source runtime normalization bound raw twelve" (Json.arr rawRows)
    (← checked (field original "sourceRecords"))
  let certificates ← checked (arrayField norm "normalizationCertificates")
  let targetRows ← checked (arrayField native "records")
  let pairs ← checked (arrayField native "actualPairs")
  unless rawRows.size == 12 && rows.size == 12 && targetRows.size == 12 && pairs.size == 12 do
    throwError "Normalized bare audit requires twelve complete source/native records"
  let mut maps : NameMap := #[]
  for p in pairs do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    if maps.any (·.1 == s) then throwError "Duplicate actual bare source mapping {s}"
    maps := maps.push (s,t) |>.push (t,t)
  let forward (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual normalized bare project Name {n}"
    return n
  let inverse (n : Name) : Except String Name := do
    if let some p := maps.find? (fun p => p.2 == n && p.1 != p.2) then return p.1
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped inverse normalized bare Name {n}"
    return n
  let decode (j : Json) := checked (relocateExpr maps #[] #[] true j)
  let env ← getEnv
  for tr in targetRows do
    let n ← checked (decodeName (← checked (field tr "nameExpr")))
    let ci ← getConstInfo n
    sameBound "live native bare complete TYPE" (← checked (encodeExpr ci.type))
      (← checked (field tr "actualTypeExpr"))
    sameBound "live native bare owner" (toJson ((moduleOf env n).map Name.toString))
      (← checked (field tr "owner"))
    let liveValue ← match ci.value? (allowOpaque := true) with
      | none => pure Json.null
      | some v => checked (encodeExpr v)
    sameBound "live native bare complete value" liveValue (← checked (field tr "actualValueExpr"))
  let output ← checked (stringField cfg "outputFile")
  let mut allExpressions : Array (String × Expr) := #[]
  let mut certificateCount := 0
  let mut totalUses := 0
  for i in [:rows.size] do
    let sr := rows[i]!
    let raw := rawRows[i]!
    let nameJson ← checked (field sr "nameExpr")
    for key in #["name","nameExpr","owner","ownerNameExpr","kind","levelParams","isInstance","isProposition","valueRead"] do
      sameBound s!"unchanged source declaration identity {key}" (← checked (field sr key)) (← checked (field raw key))
    let label ← checked (stringField sr "name")
    for key in #["actualTypeExpr","actualValueExpr"] do
      let re ← checked (field raw key)
      let ne ← checked (field sr key)
      if re != Json.null then
        let cert ← normalizedCertificate certificates nameJson
          (if key == "actualTypeExpr" then "TYPE" else "value") re ne
        certificateCount := certificateCount + 1
        totalUses := totalUses + (← checked (cert.getObjValAs? Nat "normalizedUses"))
        allExpressions := allExpressions.push (label ++ ":" ++ key,← decode ne)
      else sameBound "null source value not replaced by data" re ne
    let rawMeta ← checked (field raw "metadata")
    let newMeta ← checked (field sr "metadata")
    for key in #["structure","computationShape"] do
      sameBound s!"unchanged complete source structural metadata {key}"
        (← checked (field rawMeta key)) (← checked (field newMeta key))
    let rr ← checked (arrayField rawMeta "recursorRules")
    let nr ← checked (arrayField newMeta "recursorRules")
    unless rr.size == nr.size do throwError "Source recursor rule count changed by proof normalization"
    for k in [:nr.size] do
      for key in #["constructor","numFields"] do
        sameBound "source recursor identity unchanged" (← checked (field rr[k]! key)) (← checked (field nr[k]! key))
      let cert ← normalizedCertificate certificates nameJson s!"recursorRHS:{k}"
        (← checked (field rr[k]! "rhs")) (← checked (field nr[k]! "rhs"))
      certificateCount := certificateCount + 1
      totalUses := totalUses + (← checked (cert.getObjValAs? Nat "normalizedUses"))
      allExpressions := allExpressions.push (label ++ s!":recursorRHS:{k}",← decode (← checked (field nr[k]! "rhs")))
  unless certificateCount == certificates.size && certificateCount == 22 && totalUses == 5 do
    throwError "Source full-expression normalization certificate coverage differs"
  let mut missing : Array Json := #[]
  let mut arity : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  for (label,e) in allExpressions do
    for (n,k) in constantUses e do
      unless seen.contains (n,k) do
        seen := seen.push (n,k)
        match env.find? n with
        | none => missing := missing.push (Json.mkObj [("name",toJson n.toString),
            ("nameExpr",encodeName n),("actualSourceUse",toJson label),("universeArgumentCount",toJson k)])
        | some ci => unless ci.levelParams.length == k do
            arity := arity.push (Json.mkObj [("name",toJson n.toString),("nameExpr",encodeName n),
              ("actualSourceUse",toJson label),("sourceUniverseArgumentCount",toJson k),
              ("actualNativeUniverseParameterCount",toJson ci.levelParams.length)])
  unless missing.isEmpty && arity.isEmpty do
    writeOutput output (Json.mkObj [
      ("schema",toJson "B1-bare-normalized-correspondence-audit/v120"),
      ("status",toJson "external-name-or-universe-preflight-failed"),
      ("actualPairs",Json.arr pairs),("missingActualNames",Json.arr missing),
      ("universeArityDifferences",Json.arr arity),("correspondenceAccepted",toJson false),
      ("sourceNormalizationJob",toJson sourceJob)])
    throwError "Actual normalized source4.35/native4.33 preflight failed; see output"
  let mut reports : Array Json := #[]
  let mut structureCount := 0
  let mut projectionCount := 0
  let mut instanceCount := 0
  let mut constructorCount := 0
  let mut recursorCount := 0
  let mut ruleCount := 0
  for i in [:rows.size] do
    let sr := rows[i]!
    let raw := rawRows[i]!
    let s ← checked (decodeName (← checked (field sr "nameExpr")))
    let t ← checked (forward s)
    let ci ← getConstInfo t
    unless (← checked (stringField sr "kind")) == kind ci do throwError "Actual constant kind differs {s}"
    let ps ← namesFromJson (← checked (field sr "levelParams"))
    unless ps.length == ci.levelParams.length do throwError "Actual universe arity differs {s}"
    let us := (List.range ps.length).map fun k => Level.param (.num (.str .anonymous "_B1BareNormalizedUniverse") k)
    let rawTYPE ← decode (← checked (field raw "actualTypeExpr"))
    let normalizedTYPE ← decode (← checked (field sr "actualTypeExpr"))
    let originalRawFullBinderEqual := binderInventory rawTYPE == binderInventory ci.type &&
      binderPlacement rawTYPE == binderPlacement ci.type
    let normalizedFullBinderEqual := binderInventory normalizedTYPE == binderInventory ci.type &&
      binderPlacement normalizedTYPE == binderPlacement ci.type
    unless normalizedFullBinderEqual do throwError "Strict normalized full TYPE BinderInfo differs {s}"
    unless outerForallBinderInfo rawTYPE == outerForallBinderInfo normalizedTYPE &&
        outerForallBinderInfo normalizedTYPE == outerForallBinderInfo ci.type do
      throwError "Original/normalized/native public quantifier BinderInfo differs {s}"
    let st := normalizedTYPE.instantiateLevelParams ps us
    let tt := ci.type.instantiateLevelParams ci.levelParams us
    kernelEq s!"bare normalized complete TYPE {s}" st tt
    let sourceIsInstance ← checked (sr.getObjValAs? Bool "isInstance")
    unless sourceIsInstance == Lean.Meta.isInstanceCore env t do throwError "Instance registration differs {s}"
    if sourceIsInstance then instanceCount := instanceCount + 1
    let prop ← isProp ci.type
    unless prop == (← checked (sr.getObjValAs? Bool "isProposition")) do throwError "Actual Prop/data status differs {s}"
    let value ← checked (field sr "actualValueExpr")
    let mut valueCompared := false
    let mut rawValueBinderEqual := true
    if value != Json.null then
      let some tv := ci.value? (allowOpaque := true) | throwError "Missing native complete actual value {s}"
      let normalizedValue ← decode value
      let rawValue ← decode (← checked (field raw "actualValueExpr"))
      let sv := normalizedValue.instantiateLevelParams ps us
      let nv := tv.instantiateLevelParams ci.levelParams us
      let svt ← kernelCheck s!"source normalized complete value {s}" sv
      kernelEq s!"source normalized complete value TYPE {s}" svt st
      kernelEq s!"source/native normalized complete value {s}" sv nv
      for e in #[sv,nv] do ensureStandard s!"bare complete value {s}" (← expressionAxioms e)
      rawValueBinderEqual := binderInventory rawValue == binderInventory tv &&
        binderPlacement rawValue == binderPlacement tv
      valueCompared := true
    let sourceMetadata ← checked (field sr "metadata")
    sameBound "bare complete computation metadata" (← checked (field sourceMetadata "computationShape"))
      (← checked (computationShape ci inverse))
    let sourceStructure ← checked (field sourceMetadata "structure")
    let mut structureCompared := false
    let mut rawStructureTraversalEqual := true
    if sourceStructure != Json.null then
      let some info := getStructureInfo? env t | throwError "Missing actual native structure metadata {s}"
      let sourceShape ← checked (field sourceStructure "completeMetadata")
      let nativeShape ← checked (structureShape info inverse)
      rawStructureTraversalEqual := sourceShape == nativeShape
      sameBound "canonical complete structure metadata" (← canonicalStructureMetadata sourceShape)
        (← canonicalStructureMetadata nativeShape)
      let fields ← checked (arrayField sourceShape "fieldNamesInConstructorOrder")
      unless fields.size == 9 && info.fieldNames.size == 9 do throwError "Full nine-field structure changed"
      let aps ← checked (arrayField sourceStructure "fieldAutoParamExprs")
      unless aps.size == 9 && info.fieldInfo.size == 9 && aps.all (· == Json.null) &&
          info.fieldInfo.all (fun p => p.autoParam?.isNone) do throwError "Bare autoParam metadata changed"
      unless (← checked (arrayField sourceShape "parentsInExtendsOrder")).isEmpty && info.parentInfo.isEmpty do
        throwError "Bare structure unexpectedly has parents"
      projectionCount := fields.size
      structureCount := structureCount + 1
      structureCompared := true
    else if (getStructureInfo? env t).isSome then throwError "Unexpected native structure metadata {s}"
    let sourceRules ← checked (arrayField sourceMetadata "recursorRules")
    let rawRules ← checked (arrayField (← checked (field raw "metadata")) "recursorRules")
    let mut rulesCompared := 0
    let mut ruleReports : Array Json := #[]
    if let .recInfo ri := ci then
      recursorCount := recursorCount + 1
      unless sourceRules.size == ri.rules.length do throwError "Complete recursor rule count differs {s}"
      for k in [:sourceRules.size] do
        let rule := sourceRules[k]!
        let rr := ri.rules[k]!
        let sourceCtor ← checked (decodeName (← checked (field rule "constructor")))
        unless (← checked (forward sourceCtor)) == rr.ctor &&
            (← checked (rule.getObjValAs? Nat "numFields")) == rr.nfields do
          throwError "Actual recursor constructor/field arity differs {s}"
        let normalizedRhs ← decode (← checked (field rule "rhs"))
        let rawRhs ← decode (← checked (field rawRules[k]! "rhs"))
        kernelEq s!"complete actual normalized recursor RHS {s}:{k}"
          (normalizedRhs.instantiateLevelParams ps us) (rr.rhs.instantiateLevelParams ci.levelParams us)
        ensureStandard s!"actual recursor RHS {s}" (← expressionAxioms rr.rhs)
        rulesCompared := rulesCompared + 1
        ruleCount := ruleCount + 1
        ruleReports := ruleReports.push (Json.mkObj [
          ("constructor",toJson rr.ctor.toString),("numFields",toJson rr.nfields),
          ("kernelCompleteNormalizedRHSEqual",toJson true),
          ("originalRawRHSBinderInfoEqual",toJson (binderPlacement rawRhs == binderPlacement rr.rhs)),
          ("normalizedRHSBinderInfoEqual",toJson (binderPlacement normalizedRhs == binderPlacement rr.rhs))])
    else unless sourceRules.isEmpty do throwError "Unexpected source recursor RHS on non-recursor {s}"
    if let .ctorInfo _ := ci then constructorCount := constructorCount + 1
    for e in #[st,tt] do ensureStandard s!"actual bare complete TYPE {s}" (← expressionAxioms e)
    let axs ← collectAxioms t
    ensureStandard s!"actual bare declaration {s}" axs
    reports := reports.push (Json.mkObj [
      ("source",toJson s.toString),("sourceNameExpr",encodeName s),
      ("target",toJson t.toString),("targetNameExpr",encodeName t),
      ("completeNormalizedTYPEKernelEqual",toJson true),
      ("strictNormalizedCompleteTYPEBinderInfoEqual",toJson normalizedFullBinderEqual),
      ("originalRawFullSignatureBinderInfoEqual",toJson originalRawFullBinderEqual),
      ("originalRawFullSignatureBinderDifferenceRetained",toJson (!originalRawFullBinderEqual)),
      ("originalNormalizedNativePublicBinderInfoEqual",toJson true),
      ("completeValueKernelEqual",toJson valueCompared),("rawValueBinderInfoEqual",toJson rawValueBinderEqual),
      ("rawValueBinderDifferenceRetained",toJson (!rawValueBinderEqual)),
      ("proofIrrelevanceAvailableBecauseCompleteTYPEIsProp",toJson prop),
      ("instanceRegistrationEqual",toJson true),("isInstance",toJson sourceIsInstance),
      ("completeComputationMetadataEqual",toJson true),("completeStructureMetadataEqual",toJson structureCompared),
      ("rawStructureFieldTraversalEqual",toJson rawStructureTraversalEqual),
      ("recursorRulesCompared",toJson rulesCompared),("actualRuleReports",Json.arr ruleReports),
      ("axioms",toJson (axs.map Name.toString)),("hasSorryAx",toJson (axs.contains `sorryAx))])
  unless structureCount == 1 && projectionCount == 9 && instanceCount == 6 &&
      constructorCount == 1 && recursorCount == 1 && ruleCount == 1 do
    throwError "Bare full structure/projections/instances/constructor/recursor coverage differs"
  writeOutput output (Json.mkObj [
    ("schema",toJson "B1-bare-normalized-correspondence-audit/v120"),
    ("status",toJson "accepted"),("compilerVersion",toJson Lean.versionString),
    ("actualPairs",Json.arr pairs),("reports",Json.arr reports),
    ("structureCount",toJson structureCount),("projectionCount",toJson projectionCount),
    ("instanceProjectionCount",toJson instanceCount),("constructorCount",toJson constructorCount),
    ("recursorCount",toJson recursorCount),("recursorRuleCount",toJson ruleCount),
    ("sourceNormalizationJob",toJson sourceJob),("sourceNormalizationCertificatesBound",toJson certificateCount),
    ("sourceSamePropOccurrencesNormalized",toJson totalUses),
    ("nativeRawProofHeadClaimedEqualToSourceFreeHead",toJson false),
    ("newAssumptionsIntroduced",toJson false),("correspondenceAccepted",toJson true),
    ("configuration",cfg)])
  logInfo "Bare full correspondence accepted after source-certified same-Prop normalization; raw diagnostics retained"
end BasicNativeCompare
