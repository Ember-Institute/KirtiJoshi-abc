import Lean
import B1SourceReplay

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  let m ← env.header.modules[index.toNat]?
  return m.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit

namespace B1BareSourceNormalization
open Lean Elab Term Meta FoundationAudit
def closed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasFVar || e.hasMVar || e.hasLooseBVars then throwError "Open Expr {label}"

def kcheck (label : String) (e : Expr) : MetaM Expr := do
  closed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def keq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kcheck label e
  let ft ← kcheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

def forbiddenFlatNames : Array Name := #[
  ``Module.Flat.isTorsionFree, ``Module.Flat.instOfIsDedekindDomainOfIsTorsionFree,
  ``IsDomain.of_isSimpleRing, ``IsPrincipalIdealRing.of_isSimpleRing,
  ``Module.FaithfullyFlat.toFlat, ``Module.FaithfullyFlat.instOfNontrivialOfFree,
  ``IsRegularLocalRing.toIsLocalRing,
  ``IsRegularLocalRing.instOfIsLocalRingOfIsDomainOfIsPrincipalIdealRing,
  ``HenselianLocalRing.toIsLocalRing, ``Field.henselian]

def forbidFlatProof (label : String) (e : Expr) : MetaM Unit := do
  for n in forbiddenFlatNames do
    if e.getUsedConstants.contains n then throwError "Obsolete flat proof dependency remains in {label}: {n}"

def freeProofFor (expectedType : Expr) : MetaM Expr := do
  unless ← isProp expectedType do throwError "Expected TYPE is not a proposition"
  unless expectedType.getAppFn.isConstOf ``Module.IsTorsionFree do
    throwError "Expected exact Module.IsTorsionFree proposition"
  let f ← mkConstWithFreshMVarLevels ``Module.Free.instIsTorsionFree
  let (xs,bis,result) ← forallMetaTelescopeReducing (← inferType f)
  unless ← isDefEq result expectedType do throwError "Free theorem result does not match original proof TYPE"
  let mut synthesizedFree := 0
  for i in [:xs.size] do
    let x ← instantiateMVars xs[i]!
    if x.isMVar then
      unless bis[i]! == .instImplicit do throwError "Unconstrained data argument in Free proof"
      let xt ← instantiateMVars (← inferType x)
      unless xt.getAppFn.isConstOf ``Module.Free do
        throwError "Only Module.Free may be synthesized after fixing the complete original TYPE"
      let instanceProof ← synthInstance xt
      forbidFlatProof "synthesized actual Free instance term" instanceProof
      x.mvarId!.assign instanceProof
      synthesizedFree := synthesizedFree + 1
  unless synthesizedFree == 1 do throwError "Expected exactly one existing Free instance argument"
  let candidate ← instantiateMVars (mkAppN f xs)
  if candidate.hasMVar then throwError "Unresolved metavariable in actual Free proof"
  unless ← isDefEq (← inferType candidate) expectedType do throwError "Replacement proof TYPE differs"
  forbidFlatProof "replacement Free proof term" candidate
  return candidate

def normalizeFlatProof (raw : Expr) : MetaM (Expr × Json) := do
  let evidence ← IO.mkRef (#[] : Array Json)
  let normalized ← Meta.transform raw (pre := fun e => do
    unless e.getAppFn.isConstOf ``Module.Flat.isTorsionFree do return .continue
    unless e.getAppNumArgs == 6 do throwError "Unexpected unsaturated Module.Flat.isTorsionFree application"
    let expectedType ← inferType e
    unless ← isProp expectedType do throwError "Original instance term would replace data"
    let candidate ← freeProofFor expectedType
    let candidateType ← inferType candidate
    unless ← isDefEq candidateType expectedType do throwError "Complete original/replacement proof TYPE differs"
    let locals := (← getLCtx).foldl (fun xs d => xs.push (mkFVar d.fvarId)) (#[] : Array Expr)
    let originalClosed ← mkLambdaFVars locals e
    let replacementClosed ← mkLambdaFVars locals candidate
    let expectedClosed ← mkLambdaFVars locals expectedType
    let candidateTypeClosed ← mkLambdaFVars locals candidateType
    let originalKernelType ← kcheck "context-closed original Prop proof" originalClosed
    let replacementKernelType ← kcheck "context-closed actual Free proof" replacementClosed
    keq "complete context-closed original/replacement proof TYPE" originalKernelType replacementKernelType
    keq "complete context-closed inferred proof propositions" expectedClosed candidateTypeClosed
    keq "complete context-closed original/replacement Prop proof" originalClosed replacementClosed
    ensureStandard "actual replacement Free proof" (← expressionAxioms replacementClosed)
    let equality ← mkEq originalClosed replacementClosed
    let equalityProof ← mkEqRefl originalClosed
    keq "complete context-closed Prop proof equality" (← kcheck "Prop proof equality witness" equalityProof) equality
    let args ← e.getAppArgs.mapM fun arg => do
      checked (encodeExpr (← mkLambdaFVars locals arg))
    let candidateArguments ← candidate.getAppArgs.mapM fun arg => do
      checked (encodeExpr (← mkLambdaFVars locals arg))
    let proofRecord := Json.mkObj [
      ("originalProofApplicationUnderContext",← checked (encodeExpr originalClosed)),
      ("replacementProofApplicationUnderContext",← checked (encodeExpr replacementClosed)),
      ("originalProofTypeUnderContext",← checked (encodeExpr expectedClosed)),
      ("replacementProofTypeUnderContext",← checked (encodeExpr candidateTypeClosed)),
      ("originalActualArgumentsUnderContext",Json.arr args),
      ("replacementActualArgumentsUnderContext",Json.arr candidateArguments),
      ("equalityExpr",← checked (encodeExpr equality)),
      ("equalityProofExpr",← checked (encodeExpr equalityProof)),
      ("sameActualPropositionKernelChecked",toJson true),
      ("originalAndReplacementProofsKernelChecked",toJson true),
      ("replacementIsActualFreeTheorem",toJson true),
      ("synthesizedOnlyExistingFreeInstance",toJson true),
      ("dataReplacementUsed",toJson false),
      ("axioms",toJson ((← expressionAxioms replacementClosed).map Name.toString))]
    evidence.modify (·.push proofRecord)
    return .done candidate)
  let uses ← evidence.get
  forbidFlatProof "complete normalized TYPE" normalized
  closed "complete torsion-proof-normalized TYPE" normalized
  return (normalized,Json.mkObj [
    ("scope",toJson "only-actual-Module.Flat.isTorsionFree-proof-applications"),
    ("normalizedUses",toJson uses.size),("proofApplications",Json.arr uses),
    ("sourceNewIsAddTorsionFreeMapped",toJson false),
    ("affineFGClassEquivalenceClaimed",toJson false),
    ("nonPropositionalDataReplacementUsed",toJson false)])
def certify (raw normalized : Expr) : MetaM Json := do
  keq "complete original/normalized Expr" raw normalized
  let equality ← mkEq raw normalized
  let proof ← mkEqRefl raw
  let pt ← kcheck "complete normalization equality proof" proof
  keq "complete normalization equality proposition" pt equality
  ensureStandard "complete normalization equality proof" (← expressionAxioms proof)
  return Json.mkObj [
    ("originalExpr",← checked (encodeExpr raw)),
    ("normalizedExpr",← checked (encodeExpr normalized)),
    ("equalityExpr",← checked (encodeExpr equality)),
    ("equalityProofExpr",← checked (encodeExpr proof)),
    ("completeExprKernelDefEq",toJson true),
    ("completeEqualityProofKernelChecked",toJson true),
    ("axioms",toJson ((← expressionAxioms proof).map Name.toString))]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ b bi => #[encodeBinder bi] ++ outerForallBinderInfo b
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]

def normalizeAndCertify (name : Name) (label : String) (raw : Expr) : MetaM (Expr × Json × Nat) := do
  let (normalized, evidence) ← normalizeFlatProof raw
  let count ← checked (evidence.getObjValAs? Nat "normalizedUses")
  let expected := if name == ``Iut.EllipticCurveData.isAlgClosure && label == "TYPE" then 1
    else if name == ``Iut.EllipticCurveData.mk && label == "TYPE" then 1
    else if name == ``Iut.EllipticCurveData.rec && label == "TYPE" then 1
    else if name == ``Iut.EllipticCurveData.rec && label == "recursorRHS:0" then 2 else 0
  unless count == expected do throwError "Actual normalization count differs {name}:{label}: {count} vs {expected}"
  let proof ← certify raw normalized
  unless outerForallBinderInfo raw == outerForallBinderInfo normalized do
    throwError "Normalization changed public outer forall BinderInfo {name}:{label}"
  let rawAxioms ← expressionAxioms raw
  let normalizedAxioms ← expressionAxioms normalized
  ensureStandard s!"raw actual Expr {name}:{label}" rawAxioms
  ensureStandard s!"normalized actual Expr {name}:{label}" normalizedAxioms
  let certificate := Json.mkObj [
    ("name",toJson name.toString),("nameExpr",encodeName name),("label",toJson label),
    ("rawExpression",← checked (field proof "originalExpr")),
    ("normalizedExpression",← checked (field proof "normalizedExpr")),
    ("equalityExpr",← checked (field proof "equalityExpr")),
    ("equalityProofExpr",← checked (field proof "equalityProofExpr")),
    ("completeExprKernelDefEq",toJson true),("completeEqualityProofKernelChecked",toJson true),
    ("normalizedUses",toJson count),
    ("proofApplications",← checked (field evidence "proofApplications")),
    ("rawBinderInventory",toJson (binderInventory raw)),
    ("normalizedBinderInventory",toJson (binderInventory normalized)),
    ("rawOuterForallBinderInfo",toJson (outerForallBinderInfo raw)),
    ("normalizedOuterForallBinderInfo",toJson (outerForallBinderInfo normalized)),
    ("rawAxioms",toJson (rawAxioms.map Name.toString)),
    ("normalizedAxioms",toJson (normalizedAxioms.map Name.toString)),
    ("nonPropositionalDataReplacementUsed",toJson false)]
  return (normalized,certificate,count)

run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected original source4.35 compiler"
  let cfg ← jsonFile (← absoluteEnv "B1_BARE_SOURCE_NORMALIZATION_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-bare-source-normalization-config/v118" do
    throwError "Wrong source normalization config"
  let data ← jsonFile (← checked (stringField cfg "boundInputsFile"))
  let rows ← checked (arrayField data "sourceRecords")
  let requested ← checked (arrayField cfg "bareNameExprs")
  unless rows.size == 12 && requested.size == 12 do throwError "Expected complete bare12 actual source records"
  let env ← getEnv
  let mut normalizedRows : Array Json := #[]
  let mut certificates : Array Json := #[]
  let mut totalUses := 0
  for sr in rows do
    let name ← checked (decodeName (← checked (field sr "nameExpr")))
    unless requested.contains (encodeName name) do throwError "Unexpected source bare Name {name}"
    unless moduleOf env name == some `B1SourceReplay do throwError "Wrong actual source owner {name}"
    let ci ← getConstInfo name
    unless (← checked (field sr "actualTypeExpr")) == (← checked (encodeExpr ci.type)) do
      throwError "Raw source TYPE differs from accepted actual47/bare12 {name}"
    unless (← checked (field sr "levelParams")) == Json.arr (ci.levelParams.toArray.map encodeName) do
      throwError "Raw source universe parameters differ {name}"
    let (normalizedType,typeCert,typeUses) ← normalizeAndCertify name "TYPE" ci.type
    certificates := certificates.push typeCert
    totalUses := totalUses+typeUses
    let mut normalizedValueJson := Json.null
    let mut normalizedValueDeps : Array Name := #[]
    let mut normalizedKernelValueType := Json.null
    let normalizedTypeAxioms ← expressionAxioms normalizedType
    let mut normalizedValueAxioms : Array Name := #[]
    match ci.value? (allowOpaque := true) with
    | none => unless (← checked (field sr "actualValueExpr")) == Json.null do
        throwError "Bound raw value exists but actual source constant has none {name}"
    | some rawValue =>
      unless (← checked (field sr "actualValueExpr")) == (← checked (encodeExpr rawValue)) do
        throwError "Raw source value differs from accepted actual47/bare12 {name}"
      let (normalizedValue,valueCert,valueUses) ← normalizeAndCertify name "value" rawValue
      let rawValueType ← kcheck s!"complete actual raw value {name}" rawValue
      keq s!"actual raw value TYPE {name}" rawValueType ci.type
      let normalizedValueType ← kcheck s!"complete actual normalized value {name}" normalizedValue
      keq s!"actual normalized value vs normalized TYPE {name}" normalizedValueType normalizedType
      normalizedKernelValueType := ← checked (encodeExpr normalizedValueType)
      normalizedValueJson := ← checked (encodeExpr normalizedValue)
      normalizedValueDeps := normalizedValue.getUsedConstants.qsort Name.lt
      normalizedValueAxioms := ← expressionAxioms normalizedValue
      certificates := certificates.push valueCert
      totalUses := totalUses+valueUses
    let metadata ← checked (field sr "metadata")
    let boundRules ← checked (arrayField metadata "recursorRules")
    let mut normalizedRules : Array Json := #[]
    match ci with
    | .recInfo recursor =>
      unless boundRules.size == recursor.rules.length do throwError "Bound recursor rule count differs {name}"
      for i in [:recursor.rules.length] do
        let actualRule := recursor.rules[i]!
        let boundRule := boundRules[i]!
        unless (← checked (field boundRule "constructor")) == encodeName actualRule.ctor &&
            (← checked (field boundRule "rhs")) == (← checked (encodeExpr actualRule.rhs)) do
          throwError "Raw actual recursor rule differs {name}:{i}"
        let (normalizedRhs,ruleCert,ruleUses) ← normalizeAndCertify name s!"recursorRHS:{i}" actualRule.rhs
        normalizedRules := normalizedRules.push (boundRule.setObjVal! "rhs" (← checked (encodeExpr normalizedRhs)))
        certificates := certificates.push ruleCert
        totalUses := totalUses+ruleUses
    | _ => unless boundRules.isEmpty do throwError "Non-recursor contains bound recursor rules {name}"
    let axs ← collectAxioms name
    ensureStandard s!"actual source declaration {name}" axs
    let normalizedMetadata := metadata.setObjVal! "recursorRules" (Json.arr normalizedRules)
    let normalizedRow := sr
      |>.setObjVal! "actualTypeExpr" (← checked (encodeExpr normalizedType))
      |>.setObjVal! "actualValueExpr" normalizedValueJson
      |>.setObjVal! "directTypeConstants" (Json.arr (normalizedType.getUsedConstants.qsort Name.lt |>.map encodeName))
      |>.setObjVal! "directValueConstants" (Json.arr (normalizedValueDeps.map encodeName))
      |>.setObjVal! "kernelInferredValueTypeExpr" normalizedKernelValueType
      |>.setObjVal! "typeAxioms" (toJson (normalizedTypeAxioms.map Name.toString))
      |>.setObjVal! "valueAxioms" (toJson (normalizedValueAxioms.map Name.toString))
      |>.setObjVal! "metadata" normalizedMetadata
      |>.setObjVal! "binderInventory" (toJson (binderInventory normalizedType))
      |>.setObjVal! "telescope" (← telescopeJson normalizedType)
      |>.setObjVal! "normalizationSource" (toJson "actual source4.35 same-Prop proof normalization; raw record retained separately")
    normalizedRows := normalizedRows.push normalizedRow
  unless totalUses == 5 do throwError "Expected five actual saturated Flat proof replacements"
  let output ← checked (stringField cfg "outputFile")
  if let some parent := (System.FilePath.mk output).parent then IO.FS.createDirAll parent
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "B1-bare-source-Prop-proof-normalization/v118"),
    ("configuration",cfg),("compilerVersion",toJson Lean.versionString),
    ("actualOwner",encodeName `B1SourceReplay),
    ("sourceRecords",Json.arr rows),("normalizedSourceRecords",Json.arr normalizedRows),
    ("candidatePairs",← checked (field data "candidatePairs")),
    ("normalizationCertificates",Json.arr certificates),
    ("totalNormalizedUses",toJson totalUses),
    ("sourceKernelNormalizationChecked",toJson true),
    ("rawActualFactsMatchedCurrentEnvironment",toJson true),
    ("nonPropositionalDataReplacementUsed",toJson false),
    ("newAxiomsIntroduced",toJson false),
    ("nativeCorrespondenceAccepted",toJson false)]).pretty ++ "\n")
  logInfo "Bare source12 same-Prop normalization exported; all five local substitutions and complete Expr equalities kernel checked"
end B1BareSourceNormalization
