import Lean
import Definitions.Def_TripodCanonicalHighHeightInputs

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]

def validateSupport (maps : NameMap) (rows : Array Json) : MetaM Unit := do
  for p in rows do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) && (← checked (p.getObjValAs? Bool "isClosed")) && (← checked (arrayField p "levelParams")).isEmpty do
      throwError "Invalid actual closed proof support {n}"
    let t ← checked (relocateExpr maps rows #[] true (← checked (field p "actualTypeExpr")))
    let v ← checked (relocateExpr maps rows #[n] true (← checked (field p "actualProofExpr")))
    let vt ← kernelCheck s!"proof support {n}" v
    unless ← isProp vt do throwError "Support proof would replace data {n}"
    kernelEq s!"proof support TYPE {n}" vt t
    ensureStandard s!"expanded proof support {n}" (← expressionAxioms v)


def sameBound (label : String) (a b : Json) : MetaM Unit :=
  unless a == b do throwError "Bound actual fact differs {label}"

def writeOutput (path : String) (j : Json) : MetaM Unit := do
  unless path.startsWith "/" do throwError "Expected absolute output path"
  if let some parent := (System.FilePath.mk path).parent then IO.FS.createDirAll parent
  IO.FS.writeFile path (j.pretty ++ "\n")

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]


partial def jsonAppSpine (j : Json) : Except String (Json × Array Json) := do
  if (← stringField j "kind") == "app" then
    let (f,args) ← jsonAppSpine (← field j "fn")
    return (f,args.push (← field j "arg"))
  return (j,#[])

def extractActualRhsLambda (root : Json) : MetaM (Json × Json) := do
  unless (← checked (stringField root "kind")) == "forall" do
    throwError "Actual source root must have first forall"
  unless (← checked (stringField root "binder")) == "default" do
    throwError "Actual source P binder is not explicit"
  let second ← checked (field root "body")
  unless (← checked (stringField second "kind")) == "forall" do
    throwError "Actual source root must have second forall"
  unless (← checked (stringField second "binder")) == "default" do
    throwError "Actual source x binder is not explicit"
  let result ← checked (field second "body")
  let (head,args) ← checked (jsonAppSpine result)
  unless (← checked (stringField head "kind")) == "const" &&
      (← checked (decodeName (← checked (field head "name")))) == ``Eq && args.size == 3 do
    throwError "Actual source result must be exact Eq spine with TYPE/lhs/rhs"
  let domain ← checked (field second "type")
  let rhs := args[2]!
  let lambda := node "lam" [("name",← checked (field second "name")),
    ("type",domain),("body",rhs),("binder",toJson "default")]
  return (lambda,Json.mkObj [
    ("outerBinderCount",toJson (2 : Nat)),("outerBinderInfo",toJson #["default","default"]),
    ("firstBinderNameExpr",← checked (field root "name")),
    ("firstBinderActualTYPE",← checked (field root "type")),
    ("pointBinderNameExpr",← checked (field second "name")),
    ("pointBinderActualTYPE",domain),("actualEqHead",head),
    ("actualEqTYPE",args[0]!),("actualEqLHS",args[1]!),
    ("actualEqRHS",rhs),("actualRhsLambdaExpr",lambda)])

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native target4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_AUXILIARY_FORMULA_AUDIT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-auxiliary-height-actual-rhs-audit-config/v115" do
    throwError "Wrong auxiliary formula audit configuration"
  let data ← jsonFile (← checked (stringField cfg "formulaInputsFile"))
  sameBound "complete actual formula facts" data
    (← checked (field (← checked (field cfg "formulaInputsBinding")) "contents"))
  let four ← jsonFile (← checked (stringField cfg "fourInputsFile"))
  sameBound "four complete correspondence inputs" four
    (← checked (field (← checked (field cfg "fourInputsBinding")) "contents"))
  let accepted ← jsonFile (← checked (stringField cfg "acceptedFourAuditResultFile"))
  unless (← checked (stringField accepted "schema")) == "B1-existing-four-correspondence-audit/v114" &&
      (← checked (stringField accepted "status")) == "accepted" &&
      (← checked (accepted.getObjValAs? Bool "sourceTargetCorrespondenceAccepted")) &&
      (← checked (accepted.getObjValAs? Nat "selectedCount")) == 4 do
    throwError "Four existing constant correspondence audit is not accepted"
  let acceptedCfg ← checked (field accepted "configuration")
  sameBound "accepted four input snapshot" four
    (← checked (field (← checked (field acceptedCfg "boundInputsBinding")) "contents"))
  unless (← checked (arrayField data "sourceRootLevelParams")).isEmpty do
    throwError "Actual source root has unexpected universes"
  let pairs := (← checked (arrayField four "priorActual69Pairs")) ++
    (← checked (arrayField four "newActualPairs"))
  let mut maps : NameMap := #[]
  for p in pairs do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    if maps.any (·.1 == s) then throwError "Duplicate actual source mapping {s}"
    maps := maps.push (s,t)
    unless maps.any (·.1 == t) do maps := maps.push (t,t)
  for p in ← checked (arrayField four "nativeActualIdentityBoundaries") do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless maps.any (·.1 == n) do maps := maps.push (n,n)
  let (sourceLambdaJson,extraction) ← extractActualRhsLambda
    (← checked (field data "sourceRootActualTYPE"))
  let sl ← checked (relocateExpr maps #[] #[] true sourceLambdaJson)
  -- The original source has binders P then x. Keeping only lambda x must be closed.
  -- Any actual dependency on the deleted P binder would remain a loose bvar and is rejected.
  requireClosed "actual source RHS lambda independent of P" sl
  let tr ← checked (field data "nativeAuxiliaryHeight")
  let t ← checked (decodeName (← checked (field tr "nameExpr")))
  let ci ← getConstInfo t
  sameBound "live native auxiliary TYPE" (← checked (encodeExpr ci.type))
    (← checked (field tr "actualTypeExpr"))
  let some tv := ci.value? (allowOpaque := true) | throwError "Missing actual native auxiliary value"
  sameBound "live native auxiliary value" (← checked (encodeExpr tv))
    (← checked (field tr "actualValueExpr"))
  sameBound "live native auxiliary owner"
    (toJson ((moduleOf (← getEnv) t).map Name.toString)) (← checked (field tr "owner"))
  unless ci.levelParams.isEmpty do throwError "Native auxiliary height has unexpected universes"
  unless kind ci == "definition" do throwError "Native auxiliary height is not a definition"
  let env ← getEnv
  let output ← checked (stringField cfg "outputFile")
  let mut missing : Array Json := #[]
  let mut arity : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  for (n,k) in constantUses sl do
    unless seen.contains (n,k) do
      seen := seen.push (n,k)
      match env.find? n with
      | none => missing := missing.push (Json.mkObj [("name",toJson n.toString),
          ("nameExpr",encodeName n),("actualUniverseArgumentCount",toJson k)])
      | some c => unless c.levelParams.length == k do
          arity := arity.push (Json.mkObj [("name",toJson n.toString),
            ("nameExpr",encodeName n),("sourceActualUniverseArgumentCount",toJson k),
            ("targetActualUniverseParameterCount",toJson c.levelParams.length)])
  unless missing.isEmpty && arity.isEmpty do
    writeOutput output (Json.mkObj [
      ("schema",toJson "B1-auxiliary-height-actual-rhs-audit/v115"),
      ("status",toJson "external-name-or-universe-preflight-failed"),
      ("missingActualNames",Json.arr missing),("universeArityDifferences",Json.arr arity),
      ("actualRhsExtraction",extraction),("formulaConsumerAccepted",toJson false)])
    throwError "Actual source RHS/native formula external preflight failed; see output"
  let inferred ← kernelCheck "complete relocated actual source RHS lambda" sl
  let publicTYPEEqual := binderInventory inferred == binderInventory ci.type &&
    binderPlacement inferred == binderPlacement ci.type
  unless publicTYPEEqual do throwError "Actual RHS consumer public TYPE BinderInfo differs"
  kernelEq "actual RHS consumer complete public TYPE" inferred ci.type
  kernelEq "actual RHS lambda/native auxiliary complete computational value" sl tv
  let equality ← mkEq sl tv
  let proof ← mkEqRefl sl
  let proofType ← kernelCheck "actual RHS/native auxiliary equality proof" proof
  kernelEq "actual RHS/native auxiliary complete equality proposition" proofType equality
  for e in #[sl,inferred,tv,ci.type,proof] do
    ensureStandard "actual RHS consumer" (← expressionAxioms e)
  let rawValueBinderEqual := binderInventory sl == binderInventory tv && binderPlacement sl == binderPlacement tv
  writeOutput output (Json.mkObj [
    ("schema",toJson "B1-auxiliary-height-actual-rhs-audit/v115"),
    ("status",toJson "accepted"),("compilerVersion",toJson Lean.versionString),
    ("sourceRoot",← checked (field data "sourceRootName")),
    ("targetConsumer",toJson t.toString),("targetConsumerNameExpr",encodeName t),
    ("actualRhsExtraction",extraction),
    ("completeRelocatedActualRhsLambda",← checked (encodeExpr sl)),
    ("completeRelocatedActualRhsLambdaTYPE",← checked (encodeExpr inferred)),
    ("completeNativeAuxiliaryValue",← checked (encodeExpr tv)),
    ("completeEqualityExpr",← checked (encodeExpr equality)),
    ("completeEqualityProofExpr",← checked (encodeExpr proof)),
    ("sourceRhsIndependentOfPVerifiedByClosedLambda",toJson true),
    ("strictCompletePublicTYPEBinderInfoEqual",toJson publicTYPEEqual),
    ("rawValueBinderInfoEqual",toJson rawValueBinderEqual),
    ("rawValueBinderDifferenceRetained",toJson (!rawValueBinderEqual)),
    ("wholeSourceAuxiliaryHeightConstantMappingClaimed",toJson false),
    ("transportAssumptionsIntroduced",toJson false),
    ("formulaConsumerAccepted",toJson true),("configuration",cfg)])
  logInfo "Actual source B1 RHS lambda equals existing auxiliaryHeight complete value; formula consumer accepted"
end BasicNativeCompare
