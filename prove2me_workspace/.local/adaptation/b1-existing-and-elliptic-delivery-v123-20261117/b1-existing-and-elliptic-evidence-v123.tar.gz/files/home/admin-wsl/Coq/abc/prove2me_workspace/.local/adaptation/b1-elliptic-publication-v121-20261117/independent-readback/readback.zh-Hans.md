# 简体中文译文

本译文依据 `readback.en.frozen.md` 中已冻结的英文独立读回，由同一审读者翻译；不构成第二次独立审计。

对任意宇宙层级 $u$，`AbcAdaptation.Reference.Iut.EllipticCurveData` 是位于 $\operatorname{Type}(u+1)$ 中的记录类型，其记录包含下列具有依赖关系的数据：一个位于 $\operatorname{Type}(u)$ 中的类型 $F$；$F$ 上指定的域结构；断言该域为数域的实例，即断言它具有零特征且作为 $\mathbb{Q}$ 上的向量空间为有限维；一个同样位于 $\operatorname{Type}(u)$ 中的类型 $\overline F$；$\overline F$ 上指定的域结构；$\overline F$ 上的 $F$-代数结构；相对于这些结构断言 $\overline F$ 为 $F$ 的代数闭包的实例，因此 $\overline F$ 是代数闭域且在 $F$ 上代数；一条定义在 $F$ 上的 Weierstrass 曲线 $E$，由系数 $a_1,a_2,a_3,a_4,a_6\in F$ 给出，其方程为 $y^2+a_1xy+a_3y=x^3+a_2x^2+a_4x+a_6$；以及断言 $E$ 是椭圆曲线的实例，即断言其 Weierstrass 判别式是 $F$ 中的单位，等价地，该判别式非零。该记录把域结构、数域实例、代数闭包实例和椭圆性实例作为字段保存，同时保存上述两个类型、代数结构和 Weierstrass 曲线。此声明定义这样的记录类型；它不宣称存在这样的记录，也不宣称这样的记录唯一。

在命名空间 `AbcAdaptation.Reference.Iut.EllipticCurveData` 内，投影 `fieldF`、`numberFieldF`、`fieldFbar`、`algebraFbar`、`isAlgClosure` 和 `isElliptic` 被登记用于类型类推断：对于前述类型的记录 $d$，这些投影依次提供记录中保存的 $d.F$ 上的域结构、$d.F$ 的数域实例、$d.Fbar$ 上的域结构、$d.Fbar$ 上的 $d.F$-代数结构、$d.Fbar$ 为 $d.F$ 的代数闭包的断言，以及 $d.E$ 的椭圆性断言。

文件声明了宇宙层级 $u$ 和 $v$，但该记录定义只使用 $u$；$v$ 没有为此定义引入参数、条件或额外的宇宙选择。两个载体类型都位于 $\operatorname{Type}(u)$ 中，而记录类型位于 $\operatorname{Type}(u+1)$ 中。
