# Exact declaration and field alignment

Reviewed source: `code-reviewed.lean` (byte-identical to the file actually read). All structure fields below have the prefix `AbcAdaptation.Reference.Iut.EllipticCurveData.` when named as projections. The record declaration is `AbcAdaptation.Reference.Iut.EllipticCurveData`.

| Source element | Exact Lean type / role | English meaning | 简体中文对应 | 日本語対応 |
| --- | --- | --- | --- | --- |
| `universe u v` | Universe declarations | Only $u$ occurs in the record; $v$ is unused here. | 记录只使用 $u$；$v$ 未使用。 | レコードで使われるのは $u$ のみで、$v$ は未使用である。 |
| `EllipticCurveData` | `Type (u + 1)` | A record type in $\operatorname{Type}(u+1)$. | 位于 $\operatorname{Type}(u+1)$ 的记录类型。 | $\operatorname{Type}(u+1)$ に属するレコード型。 |
| `F` | `Type u` | The carrier type $F$. | 载体类型 $F$。 | 台となる型 $F$。 |
| `fieldF` | `Field F` | A specified field structure on $F$. | $F$ 上指定的域结构。 | $F$ 上の指定された体構造。 |
| `numberFieldF` | `NumberField F` | $F$ has characteristic zero and is finite-dimensional over $\mathbb{Q}$, for the stored field structure. | 对所存域结构，$F$ 的特征为零且在 $\mathbb{Q}$ 上有限维。 | 格納された体構造について、$F$ は標数零で $\mathbb{Q}$ 上有限次元である。 |
| `Fbar` | `Type u` | The carrier type $\overline F$, at the same universe level as $F$. | 与 $F$ 位于同一宇宙层级的载体类型 $\overline F$。 | $F$ と同じ宇宙レベルに属する台となる型 $\overline F$。 |
| `fieldFbar` | `Field Fbar` | A specified field structure on $\overline F$. | $\overline F$ 上指定的域结构。 | $\overline F$ 上の指定された体構造。 |
| `algebraFbar` | `Algebra F Fbar` | An $F$-algebra structure on $\overline F$, for the stored field structures. | 对所存域结构，$\overline F$ 上的 $F$-代数结构。 | 格納された体構造に関する $\overline F$ 上の $F$-代数構造。 |
| `isAlgClosure` | `IsAlgClosure F Fbar` | $\overline F$ is algebraically closed and algebraic over $F$, relative to the stored structures. | 对所存结构，$\overline F$ 是代数闭域且在 $F$ 上代数。 | 格納された構造に関して、$\overline F$ は代数閉体であり $F$ 上代数的である。 |
| `E` | `WeierstrassCurve F` | Coefficients $a_1,a_2,a_3,a_4,a_6\in F$ defining $y^2+a_1xy+a_3y=x^3+a_2x^2+a_4x+a_6$. | $F$ 中五个系数所给出的同一 Weierstrass 方程。 | $F$ の五つの係数で与えられる同じワイエルシュトラス方程式。 |
| `isElliptic` | `E.IsElliptic` | The discriminant of this stored $E$ is a unit in $F$, equivalently nonzero. | 所存 $E$ 的判别式是 $F$ 中的单位，等价地非零。 | 格納された $E$ の判別式は $F$ の単元であり、同値な条件として零でない。 |
| `attribute [instance] ...` | Exactly `fieldF numberFieldF fieldFbar algebraFbar isAlgClosure isElliptic` | Registers exactly these six stored projections for typeclass inference. | 将这六个所存投影登记用于类型类推断。 | この六つの格納された射影を型クラス推論用に登録する。 |

The structure fields are dependent and occur in the source order shown above. The three read-backs preserve this dependency: the number-field property concerns the stored field on $F$; the algebra and algebraic-closure fields concern the stored fields and algebra; the ellipticity field concerns the stored curve $E$. No theorem, construction of a record, existence assertion, or uniqueness assertion is present in this source.

The imports are `Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass`, `Mathlib.NumberTheory.NumberField.Basic`, and `Mathlib.FieldTheory.IsAlgClosed.Basic`. They provide the standard mathematical notions used in the read-back. Their source files were not read. The namespaces and `open NumberField WeierstrassCurve` control naming; they add no mathematical hypotheses.
