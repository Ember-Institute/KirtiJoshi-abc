import Lean
import Definitions.Def_TripodCanonicalHighHeightInputs

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]

def validateSupport (maps : NameMap) (rows : Array Json) : MetaM Unit := do
  for p in rows do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) && (← checked (p.getObjValAs? Bool "isClosed")) && (← checked (arrayField p "levelParams")).isEmpty do
      throwError "Invalid actual closed proof support {n}"
    let t ← checked (relocateExpr maps rows #[] true (← checked (field p "actualTypeExpr")))
    let v ← checked (relocateExpr maps rows #[n] true (← checked (field p "actualProofExpr")))
    let vt ← kernelCheck s!"proof support {n}" v
    unless ← isProp vt do throwError "Support proof would replace data {n}"
    kernelEq s!"proof support TYPE {n}" vt t
    ensureStandard s!"expanded proof support {n}" (← expressionAxioms v)


def sameBound (label : String) (a b : Json) : MetaM Unit :=
  unless a == b do throwError "Bound actual fact differs {label}"

def writeOutput (path : String) (j : Json) : MetaM Unit := do
  unless path.startsWith "/" do throwError "Expected absolute output path"
  if let some parent := (System.FilePath.mk path).parent then IO.FS.createDirAll parent
  IO.FS.writeFile path (j.pretty ++ "\n")

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native target4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_EXISTING_FOUR_AUDIT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-existing-four-audit-config/v114" do
    throwError "Wrong existing-four audit configuration"
  let data ← jsonFile (← checked (stringField cfg "boundInputsFile"))
  sameBound "complete selected input bundle" data (← checked (field (← checked (field cfg "boundInputsBinding")) "contents"))
  unless (← checked (stringField data "schema")) == "B1-existing-four-bound-inputs/v114" do
    throwError "Wrong bound input schema"
  let sourceRows ← checked (arrayField data "sourceRecords")
  let targetRows ← checked (arrayField data "nativeRecords")
  unless sourceRows.size == 4 && targetRows.size == 4 do throwError "Expected exactly four source/native roots"
  let oldPairs ← checked (arrayField data "priorActual69Pairs")
  unless oldPairs.size == 69 do throwError "Actual prior map count changed"
  let newPairs ← checked (arrayField data "newActualPairs")
  unless newPairs.size == 4 do throwError "Expected exactly four new actual pairs"
  let mut maps : NameMap := #[]
  for p in oldPairs ++ newPairs do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    if maps.any (·.1 == s) then throwError "Duplicate actual source mapping {s}"
    maps := maps.push (s,t)
    unless maps.any (·.1 == t) do maps := maps.push (t,t)
  for p in ← checked (arrayField data "nativeActualIdentityBoundaries") do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless maps.any (·.1 == n) do maps := maps.push (n,n)
  for r in ← checked (arrayField data "priorBasicClosed9InstanceBindings") do
    unless (← checked (r.getObjValAs? Bool "actualTYPEAndProofExactlyMatchPriorBasicClosed9")) do
      throwError "Source closure proof differs from prior actual Basic support"
  let priorInstanceProofs ← checked (arrayField data "priorBasicSelectedInstanceProofs")
  unless priorInstanceProofs.size == 2 do throwError "Expected two selected source actual Basic9 proof records"
  for sr in sourceRows.extract 2 4 do
    let sourceName ← checked (field sr "nameExpr")
    let matches := priorInstanceProofs.filter fun p => (field p "nameExpr").toOption == some sourceName
    unless matches.size == 1 do throwError "Missing selected actual Basic9 proof record"
    sameBound "source closure/Basic9 complete TYPE" (← checked (field sr "actualTypeExpr"))
      (← checked (field matches[0]! "actualTypeExpr"))
    sameBound "source closure/Basic9 complete proof" (← checked (field sr "actualValueExpr"))
      (← checked (field matches[0]! "actualProofExpr"))
  let proofs ← checked (arrayField data "closedSourceProofSupport")
  let decode (j : Json) (expand := true) := checked (relocateExpr maps proofs #[] expand j)
  let output ← checked (stringField cfg "outputFile")
  let env ← getEnv
  let mut allExpressions : Array (String × Expr) := #[]
  for r in sourceRows do
    let label ← checked (stringField r "name")
    for key in #["actualTypeExpr","actualValueExpr"] do
      allExpressions := allExpressions.push (label ++ ":" ++ key, ← decode (← checked (field r key)))
  for p in proofs do
    let label ← checked (stringField p "name")
    for key in #["actualTypeExpr","actualProofExpr"] do
      allExpressions := allExpressions.push (label ++ ":" ++ key, ← decode (← checked (field p key)))
  let mut missing : Array Json := #[]
  let mut arity : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  for (label,e) in allExpressions do
    for (n,k) in constantUses e do
      unless seen.contains (n,k) do
        seen := seen.push (n,k)
        match env.find? n with
        | none => missing := missing.push (Json.mkObj [
            ("name",toJson n.toString),("nameExpr",encodeName n),
            ("sourceActualUse",toJson label),("actualUniverseArgumentCount",toJson k)])
        | some ci =>
          unless ci.levelParams.length == k do
            arity := arity.push (Json.mkObj [
              ("name",toJson n.toString),("nameExpr",encodeName n),
              ("sourceActualUse",toJson label),("sourceActualUniverseArgumentCount",toJson k),
              ("targetActualUniverseParameterCount",toJson ci.levelParams.length)])
  unless missing.isEmpty && arity.isEmpty do
    writeOutput output (Json.mkObj [
      ("schema",toJson "B1-existing-four-correspondence-audit/v114"),
      ("status",toJson "external-name-or-universe-preflight-failed"),
      ("missingActualNames",Json.arr missing),("universeArityDifferences",Json.arr arity),
      ("sourceTargetCorrespondenceAccepted",toJson false),("configuration",cfg)])
    throwError "Source4.35/native4.33 actual name/universe preflight failed; see output. No correspondence accepted."
  validateSupport maps proofs
  let mut reports : Array Json := #[]
  for i in [:sourceRows.size] do
    let sr := sourceRows[i]!
    let tr := targetRows[i]!
    let pair := newPairs[i]!
    let s ← checked (decodeName (← checked (field sr "nameExpr")))
    let t ← checked (decodeName (← checked (field tr "nameExpr")))
    sameBound "selected source pair" (encodeName s) (← checked (field pair "sourceNameExpr"))
    sameBound "selected target pair" (encodeName t) (← checked (field pair "targetNameExpr"))
    let ci ← getConstInfo t
    sameBound "actual live target TYPE" (← checked (encodeExpr ci.type)) (← checked (field tr "actualTypeExpr"))
    let some tv := ci.value? (allowOpaque := true) | throwError "Missing complete native value {t}"
    sameBound "actual live target value" (← checked (encodeExpr tv)) (← checked (field tr "actualValueExpr"))
    sameBound "actual live target owner" (toJson ((moduleOf env t).map Name.toString)) (← checked (field tr "owner"))
    unless (← checked (stringField sr "kind")) == kind ci &&
        (← checked (stringField tr "constantKind")) == kind ci do throwError "Constant kind differs {s}"
    unless (← checked (sr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) &&
        (← checked (tr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
      throwError "Pinned actual source/native value was not kernel checked {s}"
    unless (← checked (sr.getObjValAs? Bool "valueRead")) &&
        (← checked (tr.getObjValAs? Bool "actualValueRead")) do throwError "Missing complete actual value {s}"
    unless (← checked (sr.getObjValAs? Bool "isInstance")) == Lean.Meta.isInstanceCore env t do
      throwError "Instance registration differs {s}"
    let ps ← namesFromJson (← checked (field sr "levelParams"))
    unless ps.length == ci.levelParams.length do throwError "Public universe arity differs {s}"
    let us := (List.range ps.length).map fun k => Level.param (.num (.str .anonymous "_B1ExistingUniverse") k)
    let stRaw ← decode (← checked (field sr "actualTypeExpr")) false
    let ttRaw ← decode (← checked (field tr "actualTypeExpr")) false
    let signatureEqual := binderInventory stRaw == binderInventory ttRaw &&
      binderPlacement stRaw == binderPlacement ttRaw
    unless signatureEqual do throwError "Strict complete TYPE BinderInfo/placement differs {s}"
    let st := (← decode (← checked (field sr "actualTypeExpr"))).instantiateLevelParams ps us
    let tt := ci.type.instantiateLevelParams ci.levelParams us
    kernelEq s!"complete source/native TYPE {s}" st tt
    let svRaw ← decode (← checked (field sr "actualValueExpr")) false
    let nvRaw ← decode (← checked (field tr "actualValueExpr")) false
    let rawValueBinderEqual := binderInventory svRaw == binderInventory nvRaw &&
      binderPlacement svRaw == binderPlacement nvRaw
    let sv := (← decode (← checked (field sr "actualValueExpr"))).instantiateLevelParams ps us
    let nv := tv.instantiateLevelParams ci.levelParams us
    let svt ← kernelCheck s!"complete relocated source value {s}" sv
    kernelEq s!"complete relocated source value TYPE {s}" svt st
    kernelEq s!"complete source/native value {s}" sv nv
    let prop ← isProp tt
    unless prop == (← checked (sr.getObjValAs? Bool "isProposition")) do throwError "Prop/data status differs {s}"
    for e in #[st,tt,sv,nv] do ensureStandard s!"full actual expression {s}" (← expressionAxioms e)
    let axs ← collectAxioms t
    ensureStandard s!"actual target {t}" axs
    for key in #["axioms","typeAxioms","valueAxioms"] do
      for r in #[sr,tr] do
        let axNames ← checked (r.getObjValAs? (Array String) key)
        for ax in axNames do
          unless #["propext","Classical.choice","Quot.sound"].contains ax do
            throwError "Pinned source/native unexpected axiom {s}: {ax}"
    let sourceComputation ← checked (field (← checked (field sr "metadata")) "computationShape")
    sameBound "definition safety/computation shape" sourceComputation (← checked (computationShape ci pure))
    reports := reports.push (Json.mkObj [
      ("source",toJson s.toString),("sourceNameExpr",encodeName s),
      ("target",toJson t.toString),("targetNameExpr",encodeName t),
      ("sourceOwner",← checked (field sr "owner")),("targetOwner",← checked (field tr "owner")),
      ("universeArityEqual",toJson true),("sourceLevelParams",← checked (field sr "levelParams")),
      ("targetLevelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
      ("kernelCompleteTYPEEqual",toJson true),("strictCompleteTYPEBinderInfoEqual",toJson signatureEqual),
      ("sourceCompleteValueKernelCheckedAgainstTYPE",toJson true),("kernelCompleteValueEqual",toJson true),
      ("proofIrrelevanceAvailableBecauseCompleteTYPEIsProp",toJson prop),
      ("rawValueBinderInfoEqual",toJson rawValueBinderEqual),
      ("rawValueBinderDifferenceRetained",toJson (!rawValueBinderEqual)),
      ("rawSourceValueBinderInventory",toJson (binderInventory svRaw)),
      ("rawNativeValueBinderInventory",toJson (binderInventory nvRaw)),
      ("sourceProofBytesIdentityClaimed",toJson false),
      ("axioms",toJson (axs.map Name.toString)),("hasSorryAx",toJson (axs.contains `sorryAx))])
  writeOutput output (Json.mkObj [
    ("schema",toJson "B1-existing-four-correspondence-audit/v114"),
    ("status",toJson "accepted"),("compilerVersion",toJson Lean.versionString),
    ("selectedCount",toJson reports.size),("reports",Json.arr reports),
    ("closedActualSourceProofsExpandedAndKernelChecked",toJson proofs.size),
    ("priorActual69MapReused",toJson true),("priorBasicClosed9Available",← checked (field data "priorBasicClosed9Count")),
    ("sourceBasicTwoSelectedProofsMatchPriorClosed9",← checked (field data "priorBasicClosed9InstanceBindings")),
    ("sourceTargetCorrespondenceAccepted",toJson true),
    ("transportAssumptionsIntroduced",toJson false),("newMathematicalDeclarationsIntroduced",toJson false),
    ("auxiliaryHeightWholeSourceConstantMappingClaimed",toJson false),
    ("configuration",cfg)])
  logInfo "Four existing actual constants: complete TYPE/value/universes/BinderInfo/kernel/axiom correspondence accepted"
end BasicNativeCompare
