#!/usr/bin/env python3
"""Read-only evidence assembly; only this task's /tmp children are written. No CI/API/Git."""
import argparse,hashlib,io,json,os,tarfile
from pathlib import Path
T=Path('/tmp/p2m-b1-existing-and-elliptic-delivery-v123-20261117');R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation';C=A/'main-chain-open-20261116'
STEMS=['b1-existing-four-v115','b1-auxiliary-height-v118','b1-curve-data-v116','b1-bare-audit-v117','b1-bare-native12-v119','b1-bare-source-normalization-v120','b1-bare-normalized-review-v121','b1-elliptic-publication-v121']
JOBS={'018571':'failed','018574':'succeeded','018585':'succeeded','018583':'failed','018587':'succeeded','018593':'succeeded','018597':'succeeded','018579':'succeeded','018581':'succeeded'}
S={'propext','Classical.choice','Quot.sound'}
def read(p):return json.loads(Path(p).read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def walk(x):
 if isinstance(x,dict):
  yield x
  for v in x.values():yield from walk(v)
 elif isinstance(x,list):
  for v in x:yield from walk(v)
def nm(n):return '' if not n else nm(n[0])+('.' if n[0] else '')+str(n[2])
def resources(d):
 r=d.get('resources') or d.get('result',{}).get('resources') or {};t,u,s=[r.get(k) for k in ['cpu_time_seconds','cpu_user_seconds','cpu_system_seconds']]
 return {**r,'cpu_total_equals_user_plus_system':None if None in (t,u,s) else abs(t-u-s)<.02,'peak_rss_GiB':r.get('peak_rss_bytes')/1024**3 if r.get('peak_rss_bytes') is not None else None,'peak_pss_GiB':r.get('peak_pss_bytes')/1024**3 if r.get('peak_pss_bytes') is not None else None,'resource_source':r.get('resource_source',r.get('source')),'resource_degraded':r.get('degraded'),'memory_basis':'MCP-CI process-tree physical RSS/PSS in bytes; absent fields unknown, not zero'}

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,default=T/'dryrun');ap.add_argument('--archive',action='store_true');ap.add_argument('--evidence-directory',type=Path,default=A/'b1-existing-and-elliptic-delivery-v123-20261117');x=ap.parse_args();out=x.output.resolve();assert T in out.parents;out.mkdir(parents=True,exist_ok=True)
 dirs={s:next(p for p in A.iterdir() if p.name.startswith(s+'-')) for s in STEMS}
 files={};pins={};bound_checked=[];historical_pointer_changes=[];scan={};gates={};errors={}
 def add(p,parse=False):
  p=Path(p).absolute()
  if not p.is_file():raise AssertionError('missing raw evidence: '+str(p))
  if p.is_symlink() or '.lake' in p.parts or p.suffix in {'.olean','.ilean','.ir','.o','.a','.so'}:
   pins[str(p)]={'path':str(p),'copied':False,'reason':'prebuilt/cache reference only'};return
  if str(p) not in files:
   files[str(p)]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'member':'files/'+str(p).lstrip('/')}
   if parse and p.suffix=='.json':scan[str(p)]=p
 def gate(k,f):
  try:f();gates[k]=True
  except (OSError,AssertionError,KeyError,ValueError,TypeError) as e:gates[k]=False;errors[k]=str(e)
 receipts={}
 for p in C.glob('b1-*-result.json'):
  d=read(p);short=d['job_id'][3:9]
  if short in JOBS:receipts[short]=(p,d)
 def receipt_gate():
  assert set(receipts)==set(JOBS)
  for short,(p,d) in receipts.items():
   q,r=d['request'],d['result'];assert d['status']==JOBS[short]
   assert Path(q['workspace'])==W and q['exclusive'] is True
   assert r['snapshot']['workspace_mode']=='exclusive_worktree' and r['snapshot']['snapshot_id'] is None
   assert resources(d)['cpu_total_equals_user_plus_system'] is True
   assert resources(d)['peak_rss_bytes']<=16*1024**3
   if JOBS[short]=='succeeded':
    assert r['exit_code']==0
    if q['task_type']=='review':
     v=r['review'];assert v['passed'] is True and v['checks']['no_sorryAx'] is True and v['checks']['assumptions_reported'] is True and not v['violations']
   else:assert r['exit_code']!=0
   add(p)
   for tag in ['request','submit']:
    side=p.with_name(p.name.replace('-result.json','-'+tag+'.json'))
    if side.is_file():add(side)
   for path,digest in q['worktree_manifest'].get('input_hashes',{}).items():
    pp=Path(path)
    if '.lake' in pp.parts or pp.suffix in {'.olean','.ilean','.ir','.o','.a','.so'}:
     pins[path]={'path':path,'sha256':digest,'copied':False};continue
    assert sha(pp)==digest,'receipt input changed '+str(pp)
    add(pp,True)
   for art in r.get('artifacts',[]):pins[str(art)]={'path':str(art),'copied':False,'reason':'MCP-CI artifact-store reference; raw receipt retained, store not read'}
 gate('all_nine_actual_receipts_failures_retries_and_input_hashes',receipt_gate)
 for d in dirs.values():
  for folder,sub,names in os.walk(d):
   sub[:]=[s for s in sub if s not in ['.lake','.git','__pycache__']]
   for n in names:
    if n not in ['credentials.json','.env']:add(Path(folder,n),True)
 canonical=W/'Definitions/Def_AbcAdaptation_Reference_Iut_Concrete_EllipticCurveData.lean';add(canonical)
 def bindings():
  seen=set()
  while scan:
   key,p=scan.popitem()
   if key in seen:continue
   seen.add(key);d=read(p)
   for node in walk(d):
    if isinstance(node.get('path'),str) and node['path'].startswith('/') and isinstance(node.get('sha256'),str):
     pp=Path(node['path'])
     if '.lake' in pp.parts:continue
     actual_digest=sha(pp)
     if actual_digest!=node['sha256'] and p==dirs['b1-bare-source-normalization-v120']/'handoff-manifest.json' and str(pp).startswith('/tmp/p2m-b1-bare-source-normalization-v118-20261117/'):
      historical_pointer_changes.append({'historicalManifest':str(p),'path':str(pp),'historicalSHA256':node['sha256'],'currentSHA256':actual_digest,'kind':'uncompiled handoff draft changed before actual root submission','acceptedCIInputIdentityClaimed':False,'actualSuccessfulInputReceipt':'ci-018593-9e3321fb','oldManifestPreserved':True});add(pp,False);continue
     assert actual_digest==node['sha256'],'bound raw evidence changed: '+str(pp)
     if 'contents' in node:assert read(pp)==node['contents'],'bound contents differ: '+str(pp)
     add(pp,True);bound_checked.append({'path':str(pp),'sha256':node['sha256'],'boundBy':str(p)})
    for k,v in node.items():
     if isinstance(v,str) and v.startswith('/') and Path(v).is_file() and k.lower().endswith(('file','path')):add(v,True)
 gate('recursive_bound_raw_inputs_and_embedded_contents_unchanged',bindings)
 def bare_source_AST():
  spans_path=A/'b1-source-replay-v104-20261117/compat-v105/source-replay-spans-map.json';spans=read(spans_path);add(spans_path)
  source=A/'b1-source-replay-v104-20261117/source-project/B1SourceReplay.lean';raw=source.read_bytes();add(source)
  module=next(m for m in spans['modules'] if m['module']=='Iut.Concrete.Existence')
  for key in ['source','coordinateSource','AST']:
   pin=module[key];assert sha(pin['path'])==pin['sha256'];add(pin['path'])
  command=next(r for r in spans['commands'] if 'EllipticCurveData' in r['declIds'])
  original=Path(command['coordinateSource']).read_bytes()[command['originalRange']['start']['offset']:command['originalRange']['end']['offset']]
  emitted=raw[command['effectiveReplayRange']['start']['offset']:command['effectiveReplayRange']['end']['offset']]
  assert original==emitted and hashlib.sha256(original).hexdigest()==command['originalSHA256']
  assert b'structure EllipticCurveData' in original
  write(out/'bare-source-AST-check.json',{'module':command['sourceModule'],'commandIndex':command['originalCommandIndex'],'originalSHA256':command['originalSHA256'],'acceptedSourceBytesUnchanged':True,'AST':module['AST'],'source':module['source'],'Arithmetic15AcceptedInThisUnit':False})
 gate('bare_original_source_AST_and_accepted_source_span',bare_source_AST)
 four=read(dirs['b1-existing-four-v115']/'actual/existing-four-correspondence-audit.json');aux=read(dirs['b1-auxiliary-height-v118']/'actual/auxiliary-height-actual-rhs-audit.json');native=read(dirs['b1-bare-native12-v119']/'actual/native12-facts.json');norm=read(dirs['b1-bare-source-normalization-v120']/'actual/source-normalization.json');bare=read(dirs['b1-bare-normalized-review-v121']/'actual/bare-normalized-correspondence-audit.json')
 def existing():
  assert four['selectedCount']==4 and len(four['reports'])==4 and four['sourceTargetCorrespondenceAccepted'] is True and four['status']=='accepted'
  assert four['transportAssumptionsIntroduced'] is False and four['newMathematicalDeclarationsIntroduced'] is False
  for r in four['reports']:
   for k in ['universeArityEqual','strictCompleteTYPEBinderInfoEqual','sourceCompleteValueKernelCheckedAgainstTYPE','kernelCompleteValueEqual','kernelCompleteTYPEEqual']:assert r[k] is True
   assert r['hasSorryAx'] is False and set(r['axioms'])<=S
   assert r['sourceProofBytesIdentityClaimed'] is False
  assert aux['status']=='accepted' and aux['formulaConsumerAccepted'] is True and aux['sourceRhsIndependentOfPVerifiedByClosedLambda'] is True
  assert aux['strictCompletePublicTYPEBinderInfoEqual'] is True
  assert aux['rawValueBinderInfoEqual'] is False and aux['rawValueBinderDifferenceRetained'] is True
  assert aux['wholeSourceAuxiliaryHeightConstantMappingClaimed'] is False and aux['transportAssumptionsIntroduced'] is False
  for k in ['completeRelocatedActualRhsLambdaTYPE','completeRelocatedActualRhsLambda','completeNativeAuxiliaryValue','completeEqualityProofExpr','completeEqualityExpr']:assert isinstance(aux[k],dict)
 gate('four_existing_correspondences_and_actual_auxiliary_RHS_only',existing)
 def source_norm():
  assert norm['schema']=='B1-bare-source-Prop-proof-normalization/v118' and norm['compilerVersion']=='4.35.0-rc3'
  assert norm['totalNormalizedUses']==5 and len(norm['normalizationCertificates'])==22
  assert norm['sourceKernelNormalizationChecked'] is True and norm['rawActualFactsMatchedCurrentEnvironment'] is True
  assert norm['nonPropositionalDataReplacementUsed'] is False and norm['newAxiomsIntroduced'] is False and norm['nativeCorrespondenceAccepted'] is False
  assert len(norm['sourceRecords'])==len(norm['normalizedSourceRecords'])==12
  raw={r['name']:r for r in norm['sourceRecords']};nr={r['name']:r for r in norm['normalizedSourceRecords']}
  for n,r in raw.items():
   assert r['hasSorryAx'] is False and nr[n]['hasSorryAx'] is False
   for k in ['axioms','typeAxioms','valueAxioms']:assert r[k]==nr[n][k] and set(r[k])<=S,'raw/normalized row axioms differ'
  expected={'Iut.EllipticCurveData.rec:recursorRHS:0':2,'Iut.EllipticCurveData.rec:TYPE':1,'Iut.EllipticCurveData.mk:TYPE':1,'Iut.EllipticCurveData.isAlgClosure:TYPE':1}
  assert norm['configuration']['expectedPerExpressionUses']==expected
  for c in norm['normalizationCertificates']:
   assert c['normalizedUses']==expected.get(c['name']+':'+c['label'],0)
   assert c['completeExprKernelDefEq'] is True and c['completeEqualityProofKernelChecked'] is True
   assert c['nonPropositionalDataReplacementUsed'] is False and c['rawAxioms']==c['normalizedAxioms'] and set(c['rawAxioms'])<=S
   for k in ['rawExpression','normalizedExpression','equalityProofExpr','equalityExpr']:assert isinstance(c[k],dict)
   assert len(c['proofApplications'])==c['normalizedUses']
   for p in c['proofApplications']:
    for k in ['synthesizedOnlyExistingFreeInstance','sameActualPropositionKernelChecked','replacementIsActualFreeTheorem','originalAndReplacementProofsKernelChecked']:assert p[k] is True
    assert p['dataReplacementUsed'] is False and set(p['axioms'])<=S
    for k in ['replacementProofTypeUnderContext','replacementProofApplicationUnderContext','originalProofTypeUnderContext','originalProofApplicationUnderContext','equalityProofExpr','equalityExpr']:assert isinstance(p[k],dict)
 gate('exact_five_sameProp_source_uses_22_certificates_and_raw_axioms_retained',source_norm)
 def bare_correspondence():
  assert native['schema']=='B1-bare-native-twelve-actual-facts/v119' and len(native['records'])==12 and native['nativeSourceCorrespondenceAccepted'] is False
  assert native['actualKernelValuesAndRecursorRulesChecked'] is True and native['standardAxiomAuditPassed'] is True
  assert bare['schema']=='B1-bare-normalized-correspondence-audit/v120' and bare['correspondenceAccepted'] is True and len(bare['reports'])==12
  assert bare['sourceSamePropOccurrencesNormalized']==5 and bare['sourceNormalizationCertificatesBound']==22 and bare['sourceNormalizationJob']=='ci-018593-9e3321fb'
  assert bare['newAssumptionsIntroduced'] is False and bare['nativeRawProofHeadClaimedEqualToSourceFreeHead'] is False
  assert (bare['structureCount'],bare['recursorCount'],bare['recursorRuleCount'],bare['projectionCount'],bare['instanceProjectionCount'],bare['constructorCount'])==(1,1,1,9,6,1)
  assert sum(r['completeValueKernelEqual'] is True for r in bare['reports'])==9
  assert sum(r['recursorRulesCompared'] for r in bare['reports'])==1
  for r in bare['reports']:
   for k in ['strictNormalizedCompleteTYPEBinderInfoEqual','completeNormalizedTYPEKernelEqual','completeComputationMetadataEqual','instanceRegistrationEqual','originalNormalizedNativePublicBinderInfoEqual']:assert r[k] is True
   assert r['hasSorryAx'] is False and set(r['axioms'])<=S
   assert r['rawValueBinderDifferenceRetained'] is (not r['rawValueBinderInfoEqual'])
   assert r['originalRawFullSignatureBinderDifferenceRetained'] is (not r['originalRawFullSignatureBinderInfoEqual'])
  missing=read(dirs['b1-bare-audit-v117']/'actual/bare-correspondence-audit.json');assert missing['correspondenceAccepted'] is False and len(missing['missingActualNames'])==10
 gate('bare_reachable12_TYPE9values_one_recursor_RHS_and_six_instances',bare_correspondence)
 pub=dirs['b1-elliptic-publication-v121'];payload=read(pub/'payload.json');published=read(pub/'published-item.json');publication={}
 def publish():
  nonlocal publication
  item=published;receipt=read(pub/'publish-result.json');intent=read(pub/'publish-intent.json');submit=read(pub/'publish-submit.json');journal=read(pub/'publish-journal.json')
  assert set(payload)=={'definition_name','definition_title','definition','natural_language_statement','source','env','private'} and payload['private'] is True
  assert payload['definition']==canonical.read_text()
  assert intent['payloadSha256']==sha(pub/'payload.json') and intent['targetSourceSha256']==sha(canonical) and intent['acceptedLocalReview']=='ci-018597-7df8415e'
  assert receipt['status']=='PUBLISHED' and receipt['kind']=='definition' and receipt['error_message']=='' and receipt['visibility']=='private'
  assert submit['job_id']==receipt['id']==journal['job_id'] and receipt['theorem_id']==item['definition_id']==journal['definition_id']
  for k in ['definition_name','definition_title','definition','natural_language_statement','source']:assert item[k]==payload[k]
  for k,p in [('theorem_name','definition_name'),('theorem_title','definition_title'),('definitions','definition'),('natural_language_statement','natural_language_statement'),('source','source')]:assert receipt[k]==payload[p]
  assert item['mathlib_rev']==payload['env']=='0df444a360eaa60ab8c11dca51a86af692955474' and item['visibility']=='private'
  assert item['deprecated_at'] is None and item['deprecated_by'] is None
  assert journal['allPayloadFieldsExact'] is True and journal['localAcceptedJobId']=='ci-018597-7df8415e'
  for name,h in read(pub/'independent-readback/artifact-sha256.json').items():assert sha(pub/'independent-readback'/name)==h
  reviewed=(pub/'independent-readback/code-reviewed.lean').read_text();assert canonical.read_text()==reviewed.replace('open NumberField WeierstrassCurve  \n','open NumberField WeierstrassCurve\n')
  publication={'definitionId':item['definition_id'],'jobId':receipt['id'],'definitionName':payload['definition_name'],'visibility':'private','allFieldsExact':True}
 gate('actual_private_definition_publication_and_frozen_independent_readback',publish)
 complete=all(gates.values());write(out/'completion-gates.json',{'schema':'B1-existing-and-bare-delivery-gates/v123','completeNarrowUnit':complete,'gates':gates,'errors':errors,'scope':'four existing + actual auxiliary RHS + bare reachable12 + private bare definition','Arithmetic15Accepted':False,'allNativeGeneratedDeclarationsCovered':False,'Height603FirstClassOpen':True,'initialThetaDataExistenceProved':False,'mathematicalParentClosed':False,'CICompilerAPIGitExecuted':False,'mainWorkspaceWritten':False})
 ci=[]
 for short,(p,d) in sorted(receipts.items()):
  q,r=d['request'],d['result'];ci.append({'jobId':d['job_id'],'attemptId':d.get('attempt_id'),'status':d['status'],'exitCode':r.get('exit_code'),'rawReceipt':str(p),'sha256':sha(p),'workspace':q['workspace'],'taskType':q['task_type'],'parameters':q['parameters'],'actualArguments':r.get('actual_arguments'),'workspaceMode':r['snapshot']['workspace_mode'],'snapshotId':r['snapshot']['snapshot_id'],'resources':resources(d),'diagnostics':r.get('diagnostics'),'inputManifestPointer':str(p)+'#/request/worktree_manifest','stdoutStderrPreservedInRawReceipt':True})
 write(out/'ci-history.json',ci);write(out/'prebuilt-pins.json',list(pins.values()));write(out/'bound-input-checks.json',bound_checked);write(out/'historical-draft-pointer-changes.json',historical_pointer_changes)
 def pointer(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'archiveMember':'files/'+str(p).lstrip('/')}
 ledger={'schema':'B1-existing-and-bare-compact-ledger/v123','status':'ACCEPTED_NARROW_UNIT' if complete else 'PENDING_GATES','existingFour':{'job':'ci-018574-8f1900b3','failedPriorJob':'ci-018571-65748979','rows':four['reports']},'auxiliaryActualRHS':{'job':'ci-018585-68477f51','consumer':aux['targetConsumer'],'rawValueBinderInfoEqual':False,'rawValueBinderDifferenceRetained':True,'wholeSourceConstantMappingClaimed':False,'actualExtractionAndEqualityEvidence':pointer(dirs['b1-auxiliary-height-v118']/'actual/auxiliary-height-actual-rhs-audit.json')},'bare12':{'job':'ci-018597-7df8415e','TYPECount':12,'valueCount':9,'recursorRHSCount':1,'structureCount':1,'instanceProjectionCount':6,'rows':[{k:v for k,v in r.items() if k!='actualRuleReports'} for r in bare['reports']],'actualEvidence':pointer(dirs['b1-bare-normalized-review-v121']/'actual/bare-normalized-correspondence-audit.json')},'samePropNormalization':{'job':'ci-018593-9e3321fb','occurrences':5,'certificates':22,'rawNormalizedRowAxiomsEqual':True,'nonPropositionalDataReplacementUsed':False,'nativeRawProofHeadClaimedEqualToSourceFreeHead':False,'actualEvidence':pointer(dirs['b1-bare-source-normalization-v120']/'actual/source-normalization.json')},'publication':publication,'independentReadbackUnchanged':True,'canonicalVsBlindOnlyTwoTrailingSpaces':True,'Arithmetic15Accepted':False,'source47AndCandidateMapsAreBackgroundOnly':True,'sourceReachable12EqualsAllNativeGeneratedDeclarationsClaimed':False,'typeExportAloneClosesMathematicalObligation':False,'Height603FirstClassOpen':True,'initialThetaDataConstructed':False,'initialThetaDataExistenceProved':False,'mathematicalParentClosed':False,'producerConsumers':[{'source':r['source'],'target':r['target'],'unit':'existingFour'} for r in four['reports']]+[{'source':'actual RHS of Iut.Tripod.h_eq_finHeight_div','target':aux['targetConsumer'],'unit':'auxiliaryRHS'}]+[{'source':r['source'],'target':r['target'],'unit':'bare12'} for r in bare['reports']]};write(out/'SOURCE_LEDGER.json',ledger)
 write(out/'root-application.json',{'evidenceDirectory':str(x.evidence_directory),'copyCompleteOutputDirectory':True,'replaceOldSourceLedger':False,'newMarkdownDocumentsCreated':False,'cleanupDeletePaths':[],'scope':'root applies source/consumer progress and private bare definition only; Arithmetic15 and mathematical parent remain open'})
 add(Path(__file__))
 for p in out.iterdir():
  if p.is_file() and p.suffix=='.json' and p.name!='archive-manifest.json':add(p)
 manifest={'schema':'B1-existing-and-bare-content-archive/v123','completeNarrowUnit':complete,'archiveCreated':False,'files':[files[k] for k in sorted(files)],'policy':'Raw evidence sources/config/actual/failed+success receipts/publication/readback restored from tar members. Prebuilt caches pinned only; no source or query deletion.'};write(out/'archive-manifest.json',manifest)
 if x.archive:
  assert complete,'completion gates failed';tar=out/'b1-existing-and-elliptic-evidence-v123.tar.gz';idx=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
  with tarfile.open(tar,'w:gz') as t:
   i=tarfile.TarInfo('archive-index.json');i.size=len(idx);t.addfile(i,io.BytesIO(idx))
   for row in manifest['files']:assert sha(row['path'])==row['sha256'];t.add(row['path'],arcname=row['member'],recursive=False)
  with tarfile.open(tar,'r:gz') as t:
   assert len(t.getmembers())==len(manifest['files'])+1 and t.extractfile('archive-index.json').read()==idx
   for row in manifest['files']:
    h=hashlib.sha256();f=t.extractfile(row['member'])
    for block in iter(lambda:f.read(1048576),b''):h.update(block)
    assert h.hexdigest()==row['sha256'] and sha(row['path'])==row['sha256']
  manifest.update(archiveCreated=True,archive=str(tar),archiveSHA256=sha(tar),archiveBytes=tar.stat().st_size,allMembersReopenedSHA256Verified=True);write(out/'archive-manifest.json',manifest)
 print(json.dumps({'completeNarrowUnit':complete,'gates':gates,'errors':errors,'fileCount':len(files),'output':str(out),'archiveCreated':manifest['archiveCreated']},ensure_ascii=False))
if __name__=='__main__':main()
