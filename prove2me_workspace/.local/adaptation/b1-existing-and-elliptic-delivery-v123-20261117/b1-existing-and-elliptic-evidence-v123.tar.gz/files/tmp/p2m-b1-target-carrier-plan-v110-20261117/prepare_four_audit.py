from pathlib import Path
import json,hashlib,copy
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');O=Path('/tmp/p2m-b1-target-carrier-plan-v110-20261117');A=W/'.local/adaptation'
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
S=O/'source-four-plus-proof.actual.json';source=json.loads(S.read_text())
N=A/'b1-native-existing-v113-20261117/actual/native-existing-facts.json';native=json.loads(N.read_text())
B=A/'basic-native-identity-v75-20261116/actual/native-inventory.json';basic=json.loads(B.read_text())
E=A/'basic-native-identity-v75-20261116/actual/source-enriched.json';enriched=json.loads(E.read_text())
selected=source['records'];nr={r['name']:r for r in native['records']}
roots=[r['name'] for r in selected];targets=[native['records'][i] for i in [0,1,3,4]]
pairs=copy.deepcopy(basic['actualNameMapCandidates'])
newpairs=[]
for s,t in zip(selected,targets):
 p={'sourceName':s['name'],'sourceNameExpr':s['nameExpr'],'sourceOwner':s['owner'],'targetName':t['name'],'targetNameExpr':t['nameExpr'],'targetOwner':t['owner'],'provenance':'source closure fullActualFact + native five full actual facts; comparison pending'}
 assert not any(q['sourceNameExpr']==p['sourceNameExpr'] for q in pairs)
 pairs.append(p);newpairs.append(p)
proof9=enriched['closedSourceProofSupport'];proof9index={r['name']:r for r in proof9}
instancebindings=[]
for r in selected[2:]:
 old=proof9index[r['name']]
 matches=old['actualTypeExpr']==r['actualTypeExpr'] and old['actualProofExpr']==r['actualValueExpr']
 instancebindings.append({'name':r['name'],'actualTYPEAndProofExactlyMatchPriorBasicClosed9':matches})
 assert matches,r['name']
# Only reachable unmapped closed proof support is expanded for this four-root audit.
leg=source['additionalActualClosedProofs'][0]
assert leg['isProposition'] and leg['levelParams']==[] and leg['valueRead'] and leg['kernelValueTypeMatchesActualTYPE'] and not leg['hasSorryAx']
proof={'name':leg['name'],'nameExpr':leg['nameExpr'],'actualTypeExpr':leg['actualTypeExpr'],'actualProofExpr':leg['actualValueExpr'],'levelParams':leg['levelParams'],'isProposition':True,'isClosed':True,'sourceActualFullRow':leg}
identities={}
for r in basic['records']:
 identities[json.dumps(r['nameExpr'])]={'name':r['name'],'nameExpr':r['nameExpr'],'owner':r['module'],'provenance':'prior actual native owner inventory'}
for r in native['records']:
 identities[json.dumps(r['nameExpr'])]={'name':r['name'],'nameExpr':r['nameExpr'],'owner':r['owner'],'provenance':'five native actual record'}
 for k in ['directTypeConstants','directValueConstants']:
  for n in r[k]:
   def nm(x):return nm(x[0])+('.' if x[0] else '')+str(x[2]) if x else ''
   if nm(n).startswith(('AbcAdaptation.','_private.')):
    identities.setdefault(json.dumps(n),{'name':nm(n),'nameExpr':n,'provenance':'actual native five direct used constant'})
bundle={'schema':'B1-existing-four-bound-inputs/v114','sourceCompiler':'4.35.0-rc3','nativeCompiler':'4.33.1','sourceRecords':selected,'nativeRecords':targets,'priorActual69Pairs':basic['actualNameMapCandidates'],'newActualPairs':newpairs,'nativeActualIdentityBoundaries':list(identities.values()),'closedSourceProofSupport':[proof],'priorBasicSelectedInstanceProofs':[proof9index[r['name']] for r in selected[2:]],'priorBasicClosed9Count':len(proof9),'priorBasicClosed9InstanceBindings':instancebindings,'priorBasicClosed9Binding':pin(E),'sourceClosureSummaryBinding':pin(A/'b1-source-replay-v104-20261117/actual/closure-v111/summary.json'),'sourceClosureFactsBinding':pin(A/'b1-source-replay-v104-20261117/actual/closure-v111/actual-facts.jsonl'),'nativeFiveBinding':pin(N),'priorNativeInventoryBinding':pin(B),'correspondenceAccepted':False,'availableBasicProof9OnlyReachableSupportExpanded':True}
P=O/'existing-four-bound-inputs.json';P.write_text(json.dumps(bundle,ensure_ascii=False,indent=2)+'\n')
cfg={'schema':'B1-existing-four-audit-config/v114','boundInputsFile':str(P),'boundInputsBinding':{**pin(P),'contents':bundle},'outputFile':str(O/'actual/existing-four-correspondence-audit.json'),'status':'uncompiled draft; root stage files and update paths before exclusive MCP-CI','firstLeafEstimate':{'expected_duration':'60s','expected_memory':'16GiB'}}
(O/'existing-four-audit.config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
base=(A/'basic-native-identity-v75-20261116/queries/AuditBasicNativeComparison.lean').read_text();b=base.index('namespace FoundationAudit');e=base.index('run_meta do',b)
query='import Lean\nimport Definitions.Def_TripodCanonicalHighHeightInputs\n\n'+base[b:e]
query+='''
def sameBound (label : String) (a b : Json) : MetaM Unit :=
  unless a == b do throwError "Bound actual fact differs {label}"

def writeOutput (path : String) (j : Json) : MetaM Unit := do
  unless path.startsWith "/" do throwError "Expected absolute output path"
  if let some parent := (System.FilePath.mk path).parent then IO.FS.createDirAll parent
  IO.FS.writeFile path (j.pretty ++ "\\n")

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native target4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_EXISTING_FOUR_AUDIT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-existing-four-audit-config/v114" do
    throwError "Wrong existing-four audit configuration"
  let data ← jsonFile (← checked (stringField cfg "boundInputsFile"))
  sameBound "complete selected input bundle" data (← checked (field (← checked (field cfg "boundInputsBinding")) "contents"))
  unless (← checked (stringField data "schema")) == "B1-existing-four-bound-inputs/v114" do
    throwError "Wrong bound input schema"
  let sourceRows ← checked (arrayField data "sourceRecords")
  let targetRows ← checked (arrayField data "nativeRecords")
  unless sourceRows.size == 4 && targetRows.size == 4 do throwError "Expected exactly four source/native roots"
  let oldPairs ← checked (arrayField data "priorActual69Pairs")
  unless oldPairs.size == 69 do throwError "Actual prior map count changed"
  let newPairs ← checked (arrayField data "newActualPairs")
  unless newPairs.size == 4 do throwError "Expected exactly four new actual pairs"
  let mut maps : NameMap := #[]
  for p in oldPairs ++ newPairs do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    if maps.any (·.1 == s) then throwError "Duplicate actual source mapping {s}"
    maps := maps.push (s,t)
    unless maps.any (·.1 == t) do maps := maps.push (t,t)
  for p in ← checked (arrayField data "nativeActualIdentityBoundaries") do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless maps.any (·.1 == n) do maps := maps.push (n,n)
  for r in ← checked (arrayField data "priorBasicClosed9InstanceBindings") do
    unless (← checked (r.getObjValAs? Bool "actualTYPEAndProofExactlyMatchPriorBasicClosed9")) do
      throwError "Source closure proof differs from prior actual Basic support"
  let priorInstanceProofs ← checked (arrayField data "priorBasicSelectedInstanceProofs")
  unless priorInstanceProofs.size == 2 do throwError "Expected two selected source actual Basic9 proof records"
  for sr in sourceRows.extract 2 4 do
    let sourceName ← checked (field sr "nameExpr")
    let matches := priorInstanceProofs.filter fun p => (field p "nameExpr").toOption == some sourceName
    unless matches.size == 1 do throwError "Missing selected actual Basic9 proof record"
    sameBound "source closure/Basic9 complete TYPE" (← checked (field sr "actualTypeExpr"))
      (← checked (field matches[0]! "actualTypeExpr"))
    sameBound "source closure/Basic9 complete proof" (← checked (field sr "actualValueExpr"))
      (← checked (field matches[0]! "actualProofExpr"))
  let proofs ← checked (arrayField data "closedSourceProofSupport")
  let decode (j : Json) (expand := true) := checked (relocateExpr maps proofs #[] expand j)
  let output ← checked (stringField cfg "outputFile")
  let env ← getEnv
  let mut allExpressions : Array (String × Expr) := #[]
  for r in sourceRows do
    let label ← checked (stringField r "name")
    for key in #["actualTypeExpr","actualValueExpr"] do
      allExpressions := allExpressions.push (label ++ ":" ++ key, ← decode (← checked (field r key)))
  for p in proofs do
    let label ← checked (stringField p "name")
    for key in #["actualTypeExpr","actualProofExpr"] do
      allExpressions := allExpressions.push (label ++ ":" ++ key, ← decode (← checked (field p key)))
  let mut missing : Array Json := #[]
  let mut arity : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  for (label,e) in allExpressions do
    for (n,k) in constantUses e do
      unless seen.contains (n,k) do
        seen := seen.push (n,k)
        match env.find? n with
        | none => missing := missing.push (Json.mkObj [
            ("name",toJson n.toString),("nameExpr",encodeName n),
            ("sourceActualUse",toJson label),("actualUniverseArgumentCount",toJson k)])
        | some ci =>
          unless ci.levelParams.length == k do
            arity := arity.push (Json.mkObj [
              ("name",toJson n.toString),("nameExpr",encodeName n),
              ("sourceActualUse",toJson label),("sourceActualUniverseArgumentCount",toJson k),
              ("targetActualUniverseParameterCount",toJson ci.levelParams.length)])
  unless missing.isEmpty && arity.isEmpty do
    writeOutput output (Json.mkObj [
      ("schema",toJson "B1-existing-four-correspondence-audit/v114"),
      ("status",toJson "external-name-or-universe-preflight-failed"),
      ("missingActualNames",Json.arr missing),("universeArityDifferences",Json.arr arity),
      ("sourceTargetCorrespondenceAccepted",toJson false),("configuration",cfg)])
    throwError "Source4.35/native4.33 actual name/universe preflight failed; see output. No correspondence accepted."
  validateSupport maps proofs
  let mut reports : Array Json := #[]
  for i in [:sourceRows.size] do
    let sr := sourceRows[i]!
    let tr := targetRows[i]!
    let pair := newPairs[i]!
    let s ← checked (decodeName (← checked (field sr "nameExpr")))
    let t ← checked (decodeName (← checked (field tr "nameExpr")))
    sameBound "selected source pair" (encodeName s) (← checked (field pair "sourceNameExpr"))
    sameBound "selected target pair" (encodeName t) (← checked (field pair "targetNameExpr"))
    let ci ← getConstInfo t
    sameBound "actual live target TYPE" (← checked (encodeExpr ci.type)) (← checked (field tr "actualTypeExpr"))
    let some tv := ci.value? (allowOpaque := true) | throwError "Missing complete native value {t}"
    sameBound "actual live target value" (← checked (encodeExpr tv)) (← checked (field tr "actualValueExpr"))
    sameBound "actual live target owner" (toJson ((moduleOf env t).map Name.toString)) (← checked (field tr "owner"))
    unless (← checked (stringField sr "kind")) == kind ci &&
        (← checked (stringField tr "constantKind")) == kind ci do throwError "Constant kind differs {s}"
    unless (← checked (sr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) &&
        (← checked (tr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
      throwError "Pinned actual source/native value was not kernel checked {s}"
    unless (← checked (sr.getObjValAs? Bool "valueRead")) &&
        (← checked (tr.getObjValAs? Bool "actualValueRead")) do throwError "Missing complete actual value {s}"
    unless (← checked (sr.getObjValAs? Bool "isInstance")) == Lean.Meta.isInstanceCore env t do
      throwError "Instance registration differs {s}"
    let ps ← namesFromJson (← checked (field sr "levelParams"))
    unless ps.length == ci.levelParams.length do throwError "Public universe arity differs {s}"
    let us := (List.range ps.length).map fun k => Level.param (.num (.str .anonymous "_B1ExistingUniverse") k)
    let stRaw ← decode (← checked (field sr "actualTypeExpr")) false
    let ttRaw ← decode (← checked (field tr "actualTypeExpr")) false
    let signatureEqual := binderInventory stRaw == binderInventory ttRaw &&
      binderPlacement stRaw == binderPlacement ttRaw
    unless signatureEqual do throwError "Strict complete TYPE BinderInfo/placement differs {s}"
    let st := (← decode (← checked (field sr "actualTypeExpr"))).instantiateLevelParams ps us
    let tt := ci.type.instantiateLevelParams ci.levelParams us
    kernelEq s!"complete source/native TYPE {s}" st tt
    let svRaw ← decode (← checked (field sr "actualValueExpr")) false
    let nvRaw ← decode (← checked (field tr "actualValueExpr")) false
    let rawValueBinderEqual := binderInventory svRaw == binderInventory nvRaw &&
      binderPlacement svRaw == binderPlacement nvRaw
    let sv := (← decode (← checked (field sr "actualValueExpr"))).instantiateLevelParams ps us
    let nv := tv.instantiateLevelParams ci.levelParams us
    let svt ← kernelCheck s!"complete relocated source value {s}" sv
    kernelEq s!"complete relocated source value TYPE {s}" svt st
    kernelEq s!"complete source/native value {s}" sv nv
    let prop ← isProp tt
    unless prop == (← checked (sr.getObjValAs? Bool "isProposition")) do throwError "Prop/data status differs {s}"
    for e in #[st,tt,sv,nv] do ensureStandard s!"full actual expression {s}" (← expressionAxioms e)
    let axs ← collectAxioms t
    ensureStandard s!"actual target {t}" axs
    for key in #["axioms","typeAxioms","valueAxioms"] do
      for r in #[sr,tr] do
        let axNames ← checked (r.getObjValAs? (Array String) key)
        for ax in axNames do
          unless #["propext","Classical.choice","Quot.sound"].contains ax do
            throwError "Pinned source/native unexpected axiom {s}: {ax}"
    let sourceComputation ← checked (field (← checked (field sr "metadata")) "computationShape")
    sameBound "definition safety/computation shape" sourceComputation (← checked (computationShape ci pure))
    reports := reports.push (Json.mkObj [
      ("source",toJson s.toString),("sourceNameExpr",encodeName s),
      ("target",toJson t.toString),("targetNameExpr",encodeName t),
      ("sourceOwner",← checked (field sr "owner")),("targetOwner",← checked (field tr "owner")),
      ("universeArityEqual",toJson true),("sourceLevelParams",← checked (field sr "levelParams")),
      ("targetLevelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
      ("kernelCompleteTYPEEqual",toJson true),("strictCompleteTYPEBinderInfoEqual",toJson signatureEqual),
      ("sourceCompleteValueKernelCheckedAgainstTYPE",toJson true),("kernelCompleteValueEqual",toJson true),
      ("proofIrrelevanceAvailableBecauseCompleteTYPEIsProp",toJson prop),
      ("rawValueBinderInfoEqual",toJson rawValueBinderEqual),
      ("rawValueBinderDifferenceRetained",toJson (!rawValueBinderEqual)),
      ("rawSourceValueBinderInventory",toJson (binderInventory svRaw)),
      ("rawNativeValueBinderInventory",toJson (binderInventory nvRaw)),
      ("sourceProofBytesIdentityClaimed",toJson false),
      ("axioms",toJson (axs.map Name.toString)),("hasSorryAx",toJson (axs.contains `sorryAx))])
  writeOutput output (Json.mkObj [
    ("schema",toJson "B1-existing-four-correspondence-audit/v114"),
    ("status",toJson "accepted"),("compilerVersion",toJson Lean.versionString),
    ("selectedCount",toJson reports.size),("reports",Json.arr reports),
    ("closedActualSourceProofsExpandedAndKernelChecked",toJson proofs.size),
    ("priorActual69MapReused",toJson true),("priorBasicClosed9Available",← checked (field data "priorBasicClosed9Count")),
    ("sourceBasicTwoSelectedProofsMatchPriorClosed9",← checked (field data "priorBasicClosed9InstanceBindings")),
    ("sourceTargetCorrespondenceAccepted",toJson true),
    ("transportAssumptionsIntroduced",toJson false),("newMathematicalDeclarationsIntroduced",toJson false),
    ("auxiliaryHeightWholeSourceConstantMappingClaimed",toJson false),
    ("configuration",cfg)])
  logInfo "Four existing actual constants: complete TYPE/value/universes/BinderInfo/kernel/axiom correspondence accepted"
end BasicNativeCompare
'''
Q=O/'AuditB1ExistingFourCorrespondence.lean';Q.write_text(query)
print('query',len(query.encode()),'bundle',P.stat().st_size,'config',(O/'existing-four-audit.config.json').stat().st_size,'expanded closed proofs',len(bundle['closedSourceProofSupport']))
