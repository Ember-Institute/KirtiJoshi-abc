from pathlib import Path
import json,hashlib
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');O=Path('/tmp/p2m-b1-target-carrier-plan-v110-20261117');P=Path('/tmp/p2m-b1-curve-data-draft-v114-20261117')
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
M=P/'split-producer-actualNamedMap.candidate.json';mp=json.loads(M.read_text());owner='Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_EllipticCurveData'
pairs=[x for x in mp['namedPairs'] if x['targetOwnerCandidate']==owner]
F=P/'source-A-full-actual-facts.jsonl';allrows=[json.loads(x) for x in F.open()];ri={json.dumps(x['nameExpr']):x for x in allrows}
rows=[ri[json.dumps(x['originalName'])] for x in pairs]
assert len(rows)==12
for r in rows:assert r['record']=='fullActualFact' and not r['hasSorryAx'] and r['owner']=='B1SourceReplay'
struct=next(x for x in rows if x['name']=='Iut.EllipticCurveData');meta=struct['metadata']['structure']['completeMetadata'];assert len(meta['fieldNamesInConstructorOrder'])==9
bundle={'schema':'B1-bare-EllipticCurveData-bound-inputs/v117','sourceCompiler':'4.35.0-rc3','targetCompiler':'4.33.1','targetOwner':owner,'sourceRecords':rows,'candidatePairs':pairs,'sourceActual47Binding':pin(F),'sourceCandidateMapBinding':pin(M),'targetSourceBinding':pin(W/'Definitions/Def_AbcAdaptation_Reference_Iut_Concrete_EllipticCurveData.lean'),'scope':'one full structure; nine actual field projections; six instance registrations; one constructor; one recursor and all its actual RHS rules','actualSourceFieldCount':9,'actualSourceInstanceProjectionCount':sum(x['isInstance'] for x in rows),'nativeNamesMustResolveAtRuntime':True,'correspondenceAccepted':False}
B=O/'bare-curve-data-bound-inputs.json';B.write_text(json.dumps(bundle,ensure_ascii=False,indent=2)+'\n')
cfg={'schema':'B1-bare-EllipticCurveData-audit-config/v117','boundInputsFile':str(B),'boundInputsBinding':{**pin(B),'contents':bundle},'outputFile':str(O/'actual/bare-curve-data-correspondence-audit.json'),'firstLeafEstimate':{'expected_duration':'60s','expected_memory':'16GiB'},'status':'uncompiled draft; actual target Names resolved by unique display/owner match, no guessed generated Name admitted'}
C=O/'bare-curve-data-audit.config.json';C.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
base=(O/'AuditB1ExistingFourCorrespondence.lean').read_text();base=base[:base.index('run_meta do')];base=base.replace('import Definitions.Def_TripodCanonicalHighHeightInputs','import Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_EllipticCurveData')
query=base+'''
def canonicalStructureMetadata (j : Json) : MetaM Json := do
  let rawFields ← checked (arrayField j "fieldsSortedByName")
  let fields ← rawFields.mapM fun r => do
    return (← checked (decodeName (← checked (field r "fieldName"))), r)
  let fields := (fields.qsort fun a b => Name.lt a.1 b.1).map (·.2)
  return Json.mkObj [
    ("structure",← checked (field j "structure")),
    ("fieldNamesInConstructorOrder",← checked (field j "fieldNamesInConstructorOrder")),
    ("fieldsSortedByName",Json.arr fields),
    ("parentsInExtendsOrder",← checked (field j "parentsInExtendsOrder"))]

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native target4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_BARE_CURVE_DATA_AUDIT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-bare-EllipticCurveData-audit-config/v117" do
    throwError "Wrong bare curve-data audit configuration"
  let data ← jsonFile (← checked (stringField cfg "boundInputsFile"))
  sameBound "complete source bare actual input" data
    (← checked (field (← checked (field cfg "boundInputsBinding")) "contents"))
  let rows ← checked (arrayField data "sourceRecords")
  let candidates ← checked (arrayField data "candidatePairs")
  unless rows.size == 12 && candidates.size == 12 do throwError "Expected source structure+9 fields+constructor+recursor"
  let env ← getEnv
  let ownerText ← checked (stringField data "targetOwner")
  let mut maps : NameMap := #[]
  let mut actualPairs : Array Json := #[]
  for c in candidates do
    let s ← checked (decodeName (← checked (field c "originalName")))
    let display ← checked (stringField c "target")
    unless (← checked (stringField c "targetOwnerCandidate")) == ownerText do
      throwError "Target owner candidate differs from requested bare module"
    let found := env.constants.fold (fun acc n _ =>
      if n.toString == display && ((moduleOf env n).map Name.toString == some ownerText)
      then acc.push n else acc) (#[] : Array Name)
    unless found.size == 1 do throwError "Missing or duplicate actual bare target {ownerText}: {display}"
    let t := found[0]!
    if maps.any (·.1 == s) then throwError "Duplicate actual source mapping {s}"
    maps := maps.push (s,t) |>.push (t,t)
    actualPairs := actualPairs.push (Json.mkObj [
      ("source",toJson s.toString),("sourceNameExpr",encodeName s),
      ("target",toJson t.toString),("targetNameExpr",encodeName t),("targetOwner",toJson ownerText),
      ("resolution",toJson "unique actual compiler environment Name at exact owner; no generated-name guess")])
  let forward (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual bare project Name {n}"
    return n
  let inverse (n : Name) : Except String Name := do
    if let some p := maps.find? (fun p => p.2 == n && p.1 != p.2) then return p.1
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual inverse bare Name {n}"
    return n
  let decode (j : Json) := checked (relocateExpr maps #[] #[] true j)
  let mut allExpressions : Array (String × Expr) := #[]
  for sr in rows do
    let label ← checked (stringField sr "name")
    allExpressions := allExpressions.push (label ++ ":TYPE",← decode (← checked (field sr "actualTypeExpr")))
    let value ← checked (field sr "actualValueExpr")
    if value != Json.null then allExpressions := allExpressions.push (label ++ ":value",← decode value)
    let metadata ← checked (field sr "metadata")
    for r in ← checked (arrayField metadata "recursorRules") do
      allExpressions := allExpressions.push (label ++ ":recursor-RHS",← decode (← checked (field r "rhs")))
  let output ← checked (stringField cfg "outputFile")
  let mut missing : Array Json := #[]
  let mut arity : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  for (label,e) in allExpressions do
    for (n,k) in constantUses e do
      unless seen.contains (n,k) do
        seen := seen.push (n,k)
        match env.find? n with
        | none => missing := missing.push (Json.mkObj [("name",toJson n.toString),
            ("nameExpr",encodeName n),("actualSourceUse",toJson label),("universeArgumentCount",toJson k)])
        | some ci => unless ci.levelParams.length == k do
            arity := arity.push (Json.mkObj [("name",toJson n.toString),("nameExpr",encodeName n),
              ("actualSourceUse",toJson label),("sourceUniverseArgumentCount",toJson k),
              ("actualNativeUniverseParameterCount",toJson ci.levelParams.length)])
  unless missing.isEmpty && arity.isEmpty do
    writeOutput output (Json.mkObj [
      ("schema",toJson "B1-bare-EllipticCurveData-correspondence-audit/v117"),
      ("status",toJson "external-name-or-universe-preflight-failed"),
      ("actualPairs",Json.arr actualPairs),("missingActualNames",Json.arr missing),
      ("universeArityDifferences",Json.arr arity),("correspondenceAccepted",toJson false)])
    throwError "Actual source4.35/native4.33 bare metadata preflight failed; see output"
  let mut reports : Array Json := #[]
  let mut structureCount := 0
  let mut projectionCount := 0
  let mut instanceCount := 0
  let mut constructorCount := 0
  let mut recursorCount := 0
  let mut ruleCount := 0
  let mut nativeFacts : Array Json := #[]
  for sr in rows do
    let s ← checked (decodeName (← checked (field sr "nameExpr")))
    let t ← checked (forward s)
    let ci ← getConstInfo t
    unless (← checked (stringField sr "kind")) == kind ci do throwError "Actual constant kind differs {s}"
    unless (moduleOf env t).map Name.toString == some ownerText do throwError "Actual owner differs {t}"
    let ps ← namesFromJson (← checked (field sr "levelParams"))
    unless ps.length == ci.levelParams.length do throwError "Actual universe arity differs {s}"
    let us := (List.range ps.length).map fun k => Level.param (.num (.str .anonymous "_B1BareUniverse") k)
    let rawTYPE ← decode (← checked (field sr "actualTypeExpr"))
    let strictTYPEBinderEqual := binderInventory rawTYPE == binderInventory ci.type &&
      binderPlacement rawTYPE == binderPlacement ci.type
    unless strictTYPEBinderEqual do throwError "Strict full signature BinderInfo differs {s}"
    let st := rawTYPE.instantiateLevelParams ps us
    let tt := ci.type.instantiateLevelParams ci.levelParams us
    kernelEq s!"bare complete TYPE {s}" st tt
    let sourceIsInstance ← checked (sr.getObjValAs? Bool "isInstance")
    unless sourceIsInstance == Lean.Meta.isInstanceCore env t do throwError "Instance registration differs {s}"
    if sourceIsInstance then instanceCount := instanceCount + 1
    let prop ← isProp ci.type
    unless prop == (← checked (sr.getObjValAs? Bool "isProposition")) do throwError "Actual Prop/data kind differs {s}"
    let value ← checked (field sr "actualValueExpr")
    let mut valueCompared := false
    let mut rawValueBinderEqual := true
    let mut nativeValue := Json.null
    if value != Json.null then
      unless (← checked (sr.getObjValAs? Bool "valueRead")) &&
          (← checked (sr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
        throwError "Source complete actual value was not checked {s}"
      let some tv := ci.value? (allowOpaque := true) | throwError "Missing native complete actual value {s}"
      let rawValue ← decode value
      let sv := rawValue.instantiateLevelParams ps us
      let nv := tv.instantiateLevelParams ci.levelParams us
      let svt ← kernelCheck s!"source bare complete value {s}" sv
      kernelEq s!"source bare complete value TYPE {s}" svt st
      kernelEq s!"source/native bare complete value {s}" sv nv
      for e in #[sv,nv] do ensureStandard s!"bare complete value {s}" (← expressionAxioms e)
      rawValueBinderEqual := binderInventory rawValue == binderInventory tv &&
        binderPlacement rawValue == binderPlacement tv
      nativeValue ← checked (encodeExpr tv)
      valueCompared := true
    else
      if ci.value? (allowOpaque := true) |>.isSome then throwError "Unexpected native value without source counterpart {s}"
    let sourceMetadata ← checked (field sr "metadata")
    sameBound "bare complete computation metadata" (← checked (field sourceMetadata "computationShape"))
      (← checked (computationShape ci inverse))
    let sourceStructure ← checked (field sourceMetadata "structure")
    let mut structureCompared := false
    let mut rawStructureFieldTraversalEqual := true
    let mut nativeStructure := Json.null
    if sourceStructure != Json.null then
      let some info := getStructureInfo? env t | throwError "Missing actual native structure metadata {s}"
      let sourceShape ← checked (field sourceStructure "completeMetadata")
      let nativeShape ← checked (structureShape info inverse)
      rawStructureFieldTraversalEqual := sourceShape == nativeShape
      sameBound "canonical complete structure metadata" (← canonicalStructureMetadata sourceShape)
        (← canonicalStructureMetadata nativeShape)
      let fields ← checked (arrayField sourceShape "fieldNamesInConstructorOrder")
      unless fields.size == 9 && info.fieldNames.size == 9 do throwError "Full nine-field structure changed"
      let aps ← checked (arrayField sourceStructure "fieldAutoParamExprs")
      unless aps.size == info.fieldInfo.size && aps.size == 9 do throwError "Bare structure autoParam metadata size differs"
      unless aps.all (· == Json.null) && info.fieldInfo.all (fun p => p.autoParam?.isNone) do
        throwError "Bare structure unexpected autoParam; complete matching needs explicit audit"
      unless (← checked (arrayField sourceShape "parentsInExtendsOrder")).isEmpty && info.parentInfo.isEmpty do
        throwError "Bare structure unexpectedly has parents"
      projectionCount := fields.size
      structureCount := structureCount + 1
      structureCompared := true
      nativeStructure := nativeShape
    else if (getStructureInfo? env t).isSome then throwError "Unexpected native structure metadata {s}"
    let sourceRules ← checked (arrayField sourceMetadata "recursorRules")
    let mut rulesCompared := 0
    let mut ruleReports : Array Json := #[]
    if let .recInfo ri := ci then
      recursorCount := recursorCount + 1
      unless sourceRules.size == ri.rules.length do throwError "Complete recursor rule count differs {s}"
      for k in [:sourceRules.size] do
        let rule := sourceRules[k]!
        let rr := ri.rules[k]!
        let sourceCtor ← checked (decodeName (← checked (field rule "constructor")))
        unless (← checked (forward sourceCtor)) == rr.ctor &&
            (← checked (rule.getObjValAs? Nat "numFields")) == rr.nfields do
          throwError "Actual recursor constructor/field arity differs {s}"
        let rawRhs ← decode (← checked (field rule "rhs"))
        kernelEq s!"complete actual recursor RHS {s}:{k}" (rawRhs.instantiateLevelParams ps us)
          (rr.rhs.instantiateLevelParams ci.levelParams us)
        ensureStandard s!"actual recursor RHS {s}" (← expressionAxioms rr.rhs)
        rulesCompared := rulesCompared + 1
        ruleCount := ruleCount + 1
        ruleReports := ruleReports.push (Json.mkObj [
          ("constructor",toJson rr.ctor.toString),("numFields",toJson rr.nfields),
          ("kernelCompleteRHSEqual",toJson true),
          ("rawRHSBinderInfoEqual",toJson (binderPlacement rawRhs == binderPlacement rr.rhs)),
          ("nativeActualRHSExpr",← checked (encodeExpr rr.rhs))])
    else unless sourceRules.isEmpty do throwError "Unexpected source recursor RHS on non-recursor {s}"
    if let .ctorInfo _ := ci then constructorCount := constructorCount + 1
    for e in #[st,tt] do ensureStandard s!"actual bare TYPE {s}" (← expressionAxioms e)
    let axs ← collectAxioms t
    ensureStandard s!"actual bare declaration {s}" axs
    for key in #["axioms","typeAxioms","valueAxioms"] do
      let axNames ← checked (sr.getObjValAs? (Array String) key)
      for ax in axNames do unless #["propext","Classical.choice","Quot.sound"].contains ax do
        throwError "Unexpected pinned actual source axiom {s}: {ax}"
    reports := reports.push (Json.mkObj [
      ("source",toJson s.toString),("target",toJson t.toString),("kind",toJson (kind ci)),
      ("completeTYPEKernelEqual",toJson true),("strictCompleteTYPEBinderInfoEqual",toJson strictTYPEBinderEqual),
      ("completeValueKernelEqual",toJson valueCompared),("rawValueBinderInfoEqual",toJson rawValueBinderEqual),
      ("rawValueBinderDifferenceRetained",toJson (!rawValueBinderEqual)),
      ("proofIrrelevanceAvailableBecauseCompleteTYPEIsProp",toJson prop),
      ("instanceRegistrationEqual",toJson true),("isInstance",toJson sourceIsInstance),
      ("completeComputationMetadataEqual",toJson true),("completeStructureMetadataEqual",toJson structureCompared),
      ("rawStructureFieldTraversalEqual",toJson rawStructureFieldTraversalEqual),
      ("structureFieldMetadataCanonicalizedByActualFieldName",toJson structureCompared),
      ("recursorRulesCompared",toJson rulesCompared),("actualRuleReports",Json.arr ruleReports),
      ("axioms",toJson (axs.map Name.toString)),("hasSorryAx",toJson (axs.contains `sorryAx))])
    nativeFacts := nativeFacts.push (Json.mkObj [
      ("name",toJson t.toString),("nameExpr",encodeName t),("owner",toJson ownerText),
      ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
      ("actualTYPE",← checked (encodeExpr ci.type)),("actualValue",nativeValue),
      ("structureMetadataInSourceNames",nativeStructure)])
  unless structureCount == 1 && projectionCount == 9 && instanceCount == 6 &&
      constructorCount == 1 && recursorCount == 1 && ruleCount == 1 do
    throwError "Bare full structure/projections/instances/constructor/recursor coverage differs"
  writeOutput output (Json.mkObj [
    ("schema",toJson "B1-bare-EllipticCurveData-correspondence-audit/v117"),
    ("status",toJson "accepted"),("compilerVersion",toJson Lean.versionString),
    ("actualPairs",Json.arr actualPairs),("reports",Json.arr reports),("nativeActualFacts",Json.arr nativeFacts),
    ("structureCount",toJson structureCount),("projectionCount",toJson projectionCount),
    ("instanceProjectionCount",toJson instanceCount),("constructorCount",toJson constructorCount),
    ("recursorCount",toJson recursorCount),("recursorRuleCount",toJson ruleCount),
    ("extraUnreachableGeneratedDeclarationsClaimedCompared",toJson false),
    ("newAssumptionsIntroduced",toJson false),("correspondenceAccepted",toJson true),
    ("configuration",cfg)])
  logInfo "Bare EllipticCurveData: actual complete structure/projections/instances/constructor/recursor correspondence accepted"
end BasicNativeCompare
'''
Q=O/'AuditB1BareEllipticCurveData.lean';Q.write_text(query)
print('query',Q.stat().st_size,'bundle',B.stat().st_size,'config',C.stat().st_size,'source roots',len(rows),'instances',sum(x['isInstance'] for x in rows))
