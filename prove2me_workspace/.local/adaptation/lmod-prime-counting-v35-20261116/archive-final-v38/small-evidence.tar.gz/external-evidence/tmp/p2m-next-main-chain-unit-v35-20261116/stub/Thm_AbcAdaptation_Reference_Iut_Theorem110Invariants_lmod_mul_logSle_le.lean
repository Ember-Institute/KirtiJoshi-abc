/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Candidate only; no compilation or publication is claimed. Source command and
proof body are retained. Imports and the enclosing adaptation namespace change.
Original source: Iut/Implication/Theorem110.lean, lines 174-231.
Original commit: 07cb1da58f6d428a670dbb5dd6093d428bcbcdd8.
-/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.NumberTheory.PrimeCounting
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
namespace AbcAdaptation.Reference
namespace Iut
universe u v
open NumberField
variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
namespace Theorem110Invariants
variable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)

/-- Step (viii), the Proposition 1.6 input: `l*_mod·log(s^≤) ≤ (3/2)·(e*_mod·ℓ + η_prm)`
(the printed proof has `4/3`, from the printed factor of Proposition 1.6). Proved from the
prime-counting certificate: `log(s^≤)` counts distinguished primes `≤ e*_mod·ℓ`, hence is
at most `π(e*_mod·ℓ)`. -/
lemma lmod_mul_logSle_le (pnt : PrimeCountingBound) :
    inv.lmod * inv.logSle ≤ 3 / 2 * ((inv.eStar : ℝ) * X.ℓ + pnt.η) := by
  sorry

end Theorem110Invariants
end Iut
end AbcAdaptation.Reference
