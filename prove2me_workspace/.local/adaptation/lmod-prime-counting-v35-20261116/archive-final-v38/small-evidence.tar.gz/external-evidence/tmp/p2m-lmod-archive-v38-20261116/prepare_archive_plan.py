"""Inventory exact lmod duplicate sources. Writes only this new /tmp task directory."""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';F=A/'lmod-prime-counting-v35-20261116';N='AbcAdaptation.Reference.Iut.Theorem110Invariants.lmod_mul_logSle_le';stem=N.replace('.','_');rows=[]
scopes=[(F/'integrated-v38',['original-stub.lean.txt']),(F/'native',['*.lean']),(F/'stub',['*.lean']),(F/'solution',['*.lean','proof.lean.txt']),(F/'roles-v36/Theorems',['*.lean']),(F/'roles-v36/Solutions',['*.lean']),(F/'roles-v36',['proof.lean.txt']),(F/'publication-v37/staging/Theorems',['*.lean']),(F/'publication-v37/staging/Solutions',['*.lean']),(Path('/tmp/p2m-next-main-chain-unit-v35-20261116/native'),['*.lean']),(Path('/tmp/p2m-next-main-chain-unit-v35-20261116/stub'),['*.lean']),(Path('/tmp/p2m-next-main-chain-unit-v35-20261116/solution'),['*.lean','proof.lean.txt']),(Path('/tmp/p2m-lmod-global-solution-v36-20261116/Theorems'),['*.lean']),(Path('/tmp/p2m-lmod-global-solution-v36-20261116/Solutions'),['*.lean']),(Path('/tmp/p2m-lmod-global-solution-v36-20261116'),['proof.lean.txt']),(Path('/tmp/p2m-lmod-single-publisher-v37-20261116/staging/Theorems'),['*.lean']),(Path('/tmp/p2m-lmod-single-publisher-v37-20261116/staging/Solutions'),['*.lean'])]
paths={W/'Solutions'/f'Sol_{stem}.lean'}
for parent,patterns in scopes:
 for pattern in patterns:paths.update(parent.glob(pattern))
for p in sorted(paths,key=str):
 if not p.is_file():continue
 assert not p.is_symlink();assert p.name!='credentials.json';b=p.read_bytes();assert b'lmod_mul_logSle_le'in b or b'inv.eStar'in b
 rows.append({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'category':'accepted-and-canonically-integrated temporary native/solution/stub source; delete only after verified archive'})
canonical=W/'Theorems'/f'Thm_{stem}.lean';assert str(canonical)not in{r['path']for r in rows}
(D/'delete-whitelist.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(D/'plan-state.json').write_text(json.dumps({'schema':'lmod-final-archive-plan/v38','ready':False,'requiresThreeRealFinalReceipts':['canonical-leaf','canonical-artifact','final-axiom-review'],'target':N,'protectedCanonical':str(canonical),'preservedReferenceScopes':[str(F/'OriginalCommands'),str(F/'SourceProbes'),str(F/'actual'),str(F/'roles-v36/queries'),str(F/'publication-v37/platform')],'deletionCandidates':len(rows),'deleteBytes':sum(r['bytes']for r in rows),'APIInvoked':False,'CIInvoked':False,'GitInvoked':False,'mainWorkspaceModified':False,'archiveCreated':False,'filesDeleted':0},ensure_ascii=False,indent=2)+'\n')
print('Exact duplicate candidates:',len(rows),'bytes:',sum(r['bytes']for r in rows),'; canonical and oracle evidence protected.')
