这是 root 后续运行的精简归档与精确重复稿清理草稿。所有新文件仅写在本 `/tmp` 目录；没有编译、CI、API、Git 或主区写入。

`archive_cleanup.py` 默认只读预览，必须提供三份真实 final 回执：canonical leaf、canonical artifact、最终 axiom review。
不会用平台 ACCEPTED、先前 native/global leaf 或四角色通过替代 canonical 最终三回执。

```text
python3 archive_cleanup.py \
  --leaf-receipt A/main-chain-open-20261116/<canonical-leaf-result.json> \
  --artifact-receipt A/main-chain-open-20261116/<canonical-artifact-result.json> \
  --axiom-receipt A/main-chain-open-20261116/<final-axioms-result.json>
```

真实预览通过后，root在同一命令后加 `--apply --cleanup`：写入 `A/lmod-prime-counting-v35-20261116/archive-final-v38/small-evidence.tar.gz`，重开tar核验每个member SHA，再记录整tar SHA，重新核对源hash，最后才删除白名单重复角色源。
指定 `--apply` 而不加 `--cleanup` 只归档，不删除。已有输出目录不会被覆盖；中断或已有归档由root先检查现有manifest，避免重做未知删除。
本子智能体没有运行这两个变更选项。

三回执逐份核验 succeeded/exit0、实际lean参数、exclusive/null、canonical文件hash及manifest绑定；最终axiom review还须passed/no_sorryAx/无violations。
canonical provenance头注以实际root版本为准，不假定它与global solution只差名字。实际声明名及原53行proof/body SHA必须一致：
`499d0410c10e8c12f53355dc06192f7af8433f6d55937bbec1c4c62795389be8`。
平台publish/verify记录、完整精确readback以及root graph before/after也重新核对。

归档内容：

- 本lmod完整单元中的真实source TYPE、source proof InfoTree/normalized/source/diagnostic、所有旧/修正版query和config、四角色facts与最终回执。
- 所有 `main-chain-open-20261116/lmod-*.json` 历史，包括错environment key取消 `ci-017434`、旧discard语法失败 `ci-017451`、其后所有成功；原始diagnostics/resources保留，不把失败改成通过。
- 当前34个已注册Definition接口源快照、实际10项TYPE dataMap及原有map文件；不重跑数据identity、不展开上游巨型DAG。
- 冻结B三语、已有Mochizuki Proposition1.6/父Theorem1.10 quotes、PNG/raw证据、完整platform mutation journal和verify上传源副本。
- 当前真正canonical theorem、实际FinalAxioms源及三份final request/submit/result。
- 旧receipt/config记录中的热缓存、Mathlib和深层已接受依赖产物仅保留原hash pins；不复制或清理缓存。

`delete-whitelist.json` 是当前22份精确路径/hash/字节数的重复稿名单，约68 KB。包括W/Solutions临时global solution、F的native/stub/solution角色副本、roles-v36角色副本、publication staging、root保存的original-stub，以及三个已知旧/tmp目录中的相同角色稿。
只按此白名单逐项删文件；任一字节有变化即停止。白名单来源通过有限明确目录生成，不对全仓库或全/tmp做内容搜索。

始终保留真正W/Theorems canonical、F/OriginalCommands、F/SourceProbes、F/actual、真实审查query/config和完整publication/platform journal。不会删任何.olean/cache或未完成数学义务。
归档manifest逐项记录被删稿的archive member、原SHA与cleanup journal。canonicalC22、S2-04完成仍为false。
