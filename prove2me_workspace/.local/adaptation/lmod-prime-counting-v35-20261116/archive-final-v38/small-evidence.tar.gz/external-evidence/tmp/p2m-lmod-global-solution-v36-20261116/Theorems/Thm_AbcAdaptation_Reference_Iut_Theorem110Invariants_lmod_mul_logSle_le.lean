/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Candidate only; no compilation or publication is claimed. Source command and
proof body are retained. Imports and the enclosing adaptation namespace change.
Original source: Iut/Implication/Theorem110.lean, lines 174-231.
Original commit: 07cb1da58f6d428a670dbb5dd6093d428bcbcdd8.
-/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.NumberTheory.PrimeCounting
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
open NumberField
open AbcAdaptation.Reference.Iut
open AbcAdaptation.Reference.Iut.Theorem110Invariants
universe u v

theorem AbcAdaptation.Reference.Iut.Theorem110Invariants.lmod_mul_logSle_le
    {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
    {X : Corollary312VariantData.{u, v} AG TG}
    (inv : Theorem110Invariants X) (pnt : PrimeCountingBound) :
    inv.lmod * inv.logSle ≤ 3 / 2 * ((inv.eStar : ℝ) * X.ℓ + pnt.η) := by sorry
