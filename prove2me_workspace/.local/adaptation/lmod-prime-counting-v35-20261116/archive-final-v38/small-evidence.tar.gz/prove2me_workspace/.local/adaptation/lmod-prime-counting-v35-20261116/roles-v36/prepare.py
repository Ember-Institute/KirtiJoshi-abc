from pathlib import Path
import sys
sys.dont_write_bytecode=True
import json,hashlib,shutil
D=Path(__file__).resolve().parent
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';F=A/'lmod-prime-counting-v35-20261116';T=A/'independent-two-four-role-v25-20261116';C=A/'main-chain-open-20261116'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();pin=lambda p:{'path':str(p),'sha256':sha(p)}
def save(p,j):
 p=Path(p);assert p.resolve().is_relative_to(D);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def en(s):
 o=[]
 for part in s.split('.'):o=[o,'str',part]
 return o
def encode_parts(parts):
 o=[]
 for part in parts:o=[o,'str',part]
 return o
def module_import(parts):return '.'.join(p if p.replace('_','').isalnum() and not p[0].isdigit() else '«'+p+'»' for p in parts)
def nm(n):return ''if not n else nm(n[0])+('.'if n[0]else'')+str(n[2])
def constants(j):
 out=set()
 def visit(x):
  if isinstance(x,dict):
   if x.get('kind')=='const':out.add(nm(x['name']))
   if x.get('kind')=='proj':out.add(nm(x['name']))
   for v in x.values():visit(v)
  elif isinstance(x,list):
   for v in x:visit(v)
 visit(j);return out
N='Iut.Theorem110Invariants.lmod_mul_logSle_le';target='AbcAdaptation.Reference.'+N;slug=N.replace('.','_');stem='Thm_AbcAdaptation_Reference_'+slug
original=(F/'OriginalCommands'/f'{slug}.lean').read_bytes();short=N.split('.')[-1];name_end=original.index(('lemma '+short).encode())+len(('lemma '+short).encode());value_start=original.index(b':= by',name_end);signature=original[name_end:value_start];proof=original[value_start:].rstrip(b'\n');assert hashlib.sha256(proof).hexdigest()=='499d0410c10e8c12f53355dc06192f7af8433f6d55937bbec1c4c62795389be8'
native=F/'native'/f'{stem}_NativeAuditProof.lean';native_text=native.read_text();preamble=native_text[:native_text.index('set_option relaxedAutoImplicit false')];preamble+='''set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
open NumberField
open AbcAdaptation.Reference.Iut
open AbcAdaptation.Reference.Iut.Theorem110Invariants
universe u v

'''
binders='''
    {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
    {X : Corollary312VariantData.{u, v} AG TG}
    (inv : Theorem110Invariants X)'''
formal=('theorem '+target+binders).encode()+signature+b':= by sorry\n';solution=preamble.encode()+b'theorem solution'+binders.encode()+signature+proof+b'\n';stub=preamble.encode()+formal
for k in ['Solutions','Theorems','queries','configs','bound','actual']: (D/k).mkdir(exist_ok=True)
solution_rel='Solutions/Sol_AbcAdaptation_Reference_'+slug+'.lean';stub_rel='Theorems/'+stem+'.lean';native_rel=str(native.relative_to(W));native_parts=list(Path(native_rel).with_suffix('').parts);native_import=module_import(native_parts)
(D/solution_rel).write_bytes(solution);(D/stub_rel).write_bytes(stub);(D/'preamble.lean.txt').write_text(preamble);(D/'formal-statement.lean.txt').write_bytes(formal);(D/'proof.lean.txt').write_bytes(b'by'+proof[len(b':= by'):]+b'\n')
assert b'\nnamespace 'not in solution and b'\nend 'not in solution
assert solution.count(proof)==1 and stub.count(signature)==1 and solution.count(signature)==1
sourcefacts=F/'actual/source-type.json';sf=read(sourcefacts);record,=sf['records'];assert record['name']==N and not sf['closedTypeProofValues'] and not sf['rootTheoremProofsRead'];needed=sorted(n for n in constants(record['elaboratedExpr'])if n.startswith(('Iut.','_private')));assert len(needed)==10 and not any(n.startswith('_private')for n in needed)
mainmap=A/'main5-local-dossier-v27-20261116/current-owned176-config.json';upmap=A/'main5-local-dossier-v27-20261116/current-source-log32-config.json';m1={r['original']:r for r in read(mainmap)['projectMap']};m2={r['original']:r for r in read(upmap)['projectMap']};regpath=A/'platform-node-registry.json';registry=read(regpath)['reference_source_preparation'];defs={r['name']:r for r in registry['definitions']};rows=[]
for n in needed:
 source=mainmap if n in m1 else upmap;r=(m1 if n in m1 else m2)[n];assert r.get('targetToSourceUniverseIndices')is None
 package=r['targetOwner'].removeprefix('Definitions.Def_');pub=defs[package];current=W/Path(r['targetOwner'].replace('.','/')+'.lean');assert current.is_file();rows.append({'original':n,'originalName':r['originalName'],'target':r['target'],'targetName':r['targetName'],'targetOwner':r['targetOwner'],'targetToSourceUniverseIndices':None,'existingMap':pin(source),'existingMapRow':r,'currentPublishedDefinition':pub,'currentInstalledSource':pin(current),'note':'Historical map statuses retained verbatim; current publication is bound separately.'})
map_evidence={'sourceTypeFacts':pin(sourcefacts),'sourceTypeJob':'ci-017435-6c0edd5d','requiredSourceTypeProjectConstants':needed,'dataMappings':rows,'privateNameMappingCount':0,'newDataIdentityGate':False,'registry':pin(regpath),'scope':'Exact ten actual source TYPE constants; existing accepted declaration identity/publication evidence reused. Native/source type equality still needs the four-role job.'};save(D/'typedata-map-evidence.json',map_evidence)
pairs=[]
for r in rows:pairs.extend([(r['original'],r['target']),(r['target'],r['target'])])
maplean='def nativeDataNames : TypeNames := #[\n'+',\n'.join('  (`'+a+', `'+b+')'for a,b in pairs)+']'
(D/'nativeDataNames.lean.txt').write_text(maplean+'\n')
common_src=(A/'main-pure-type-identity-20261116/AuditP5GlobalSolution.lean').read_text();common=common_src[common_src.index('/-! Stable JSON'):common_src.index('def pureArithmeticTypeAudit :')];extra=(T/'common-extra.lean.txt').read_text();start=extra.index('def nativeDataNames :');end=extra.index('\n\ndef typeProofRows',start);extra=extra[:start]+maplean+extra[end:];extra=extra.replace('n != `AbcAdaptation.Reference.Iut.epsilonE && ','!nativeDataNames.any (·.2 == n) && ');extra=extra.replace('dep != `AbcAdaptation.Reference.Iut.epsilonE && ','!nativeDataNames.any (·.2 == dep) && ')
old='#["Iut." ++ short,"AbcAdaptation.Reference.Iut." ++ short,"Iut.Corollary22Inputs.c2","Iut.c2_final","Iut.assembly"]';new='#[(← checked (stringField cfg "sourceName")),(← checked (stringField cfg "targetName")),(← checked (stringField cfg "nativeName")),"Iut.Corollary22Inputs.c2","Iut.c2_final","Iut.assembly"]';assert old in extra;extra=extra.replace(old,new);common+=extra
native_body=(T/'native-body.lean.txt').read_text().replace('field cfg "targetNameExpr"','field cfg "nativeNameExpr"').replace('field cfg "theoremModule"','field cfg "nativeModule"');native_body=native_body.replace('("targetName", toJson n.toString), ("owner", encodeName owner),','("targetName", ← checked (field cfg "targetName")), ("nativeName", toJson n.toString), ("owner", encodeName owner),');final_body=(T/'final-body.lean.txt').read_text();line='  requireReceipts (← checked (field cfg "dependencyReceiptBindings"))';guard='  if !(← checked (cfg.getObjValAs? (Array String) "registeredDependencyNames")).isEmpty then\n    requireReceipts (← checked (field cfg "dependencyReceiptBindings"))';assert line in native_body and line in final_body;native_body=native_body.replace(line,guard);final_body=final_body.replace(line,guard)
(D/'queries/NativeFacts.lean').write_text('import Lean\nimport '+native_import+'\n\n'+common+native_body);(D/'queries/FourRoles.lean').write_text('import Lean\nimport '+stub_rel[:-5].replace('/','.')+'\nimport '+solution_rel[:-5].replace('/','.')+'\n\n'+common+final_body)
def bound(p):return {**pin(p),'contents':read(p)}
def receipt(p):
 b=bound(p);r=b['contents'];assert r['status']=='succeeded'and r['result']['exit_code']==0;assert r['result']['snapshot']['workspace_mode']=='exclusive_worktree'and r['result']['snapshot']['snapshot_id']is None;return b
def unique(data,x):
 assert data.count(x)==1;start=data.index(x);return[start,start+len(x)]
# The original binder/assertion bytes are still an exact suffix of the explicit global telescope.
byte={'sourceName':N,'targetName':target,'nativeName':target+'_NativeAuditProof','sourceProofSha256':hashlib.sha256(proof).hexdigest(),'signatureSha256':hashlib.sha256(signature).hexdigest(),'nativeSignatureByteRange':unique(native.read_bytes(),signature),'nativeProofByteRange':unique(native.read_bytes(),proof),'solutionSignatureByteRange':unique(solution,signature),'solutionProofByteRange':unique(solution,proof),'originalCommand':pin(F/'OriginalCommands'/f'{slug}.lean')}
cfg={'schema':'pure-four-role-config/v13','publish':False,'short':short,'sourceName':N,'targetName':target,'nativeName':target+'_NativeAuditProof','targetNameExpr':en(target),'nativeNameExpr':en(target+'_NativeAuditProof'),'nativeModule':encode_parts(native_parts),'theoremModule':en(stub_rel[:-5].replace('/','.')),'solutionModule':en(solution_rel[:-5].replace('/','.')),'sourceFacts':pin(sourcefacts),'sourceTypeReceipt':receipt(C/'lmod-original-type-correct-env-v36-result.json'),'sourceTypeFactsBinding':bound(sourcefacts),'nativeInstalledSource':str(W/native_rel),'stubInstalledSource':str(W/stub_rel),'solutionInstalledSource':str(W/solution_rel),'expectedNativeSource':pin(native),'expectedStubSource':pin(D/stub_rel),'expectedSolutionSource':pin(D/solution_rel),'expectedNativeText':native.read_text(),'expectedStubText':stub.decode(),'expectedSolutionText':solution.decode(),'proofByteEvidence':byte,'registeredDependencyNames':[],'registeredDependencySourcePins':[],'dependencyReceiptBindings':[],'nativeReceiptBindings':[receipt(C/'lmod-native-proof-leaf-v35-result.json'),receipt(C/'lmod-native-proof-artifact-v36-result.json')],'nativeFactsBinding':None,'stubReceiptBindings':None,'solutionReceiptBindings':None,'nativeFactsOutput':str(D/'actual/native-facts.json'),'finalOutput':str(D/'actual/four-role-audit.json'),'typedataMapEvidence':pin(D/'typedata-map-evidence.json'),'sourceBinding':None,'pending':'Native-facts and final four-role audits not run. Stub/global solution leaf and artifact receipts not yet provided.'}
# Reuse exact receipt/InfoTree binder from accepted predecessor, without invoking its CLI or external tools.
import importlib.util
spec=importlib.util.spec_from_file_location('previous_bind_roles',T/'bind_roles.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);cfg['sourceBinding']=module.source_binding(cfg,C/'lmod-source-proof-v35-result.json',F/'actual/source-proof/index.json')
assert cfg['sourceBinding']['sourceProofText'].encode()==proof
save(D/'configs/four-role.template.json',cfg)
save(D/'draft-state.json',{'sourceProofJob':'ci-017433-8866e8c9','sourceTypeJob':'ci-017435-6c0edd5d','nativeLeafJob':'ci-017432-1ba53ddc','nativeArtifactJob':'ci-017436-f27d2c17','sourceFactsRead':True,'actualSourceTypeProjectConstants':len(needed),'closedSourceTypeProofs':0,'completeSignatureBinderInfo':record['binderInventory'],'sourceSignatureBytesRetained':True,'wholeProofBytesRetained':True,'globalSolutionIsTopLevel':True,'stubIsTopLevel':True,'stubCompiled':False,'globalSolutionCompiled':False,'nativeFactsAuditPassed':False,'fourRoleAuditPassed':False,'CIInvoked':False,'GitInvoked':False,'APIInvoked':False,'mainWorkspaceModified':False})
print('Prepared top-level solution/stub and bound source/native inputs; all pending target gates remain false.')
