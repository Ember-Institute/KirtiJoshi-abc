#!/usr/bin/env python3
"""Bind actual root receipts to the frozen lmod four-role draft. No compilation or API."""
from pathlib import Path
import argparse,json,hashlib
D=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def binding(p):
 p=Path(p).resolve();return {'path':str(p),'sha256':sha(p),'contents':read(p)}
def receipt(p,source=None,expected=None):
 b=binding(p);j=b['contents'];assert j['status']=='succeeded'and j['result']['exit_code']==0
 assert j['result']['snapshot']['workspace_mode']=='exclusive_worktree'and j['result']['snapshot']['snapshot_id']is None
 if source is not None:assert j['request']['worktree_manifest']['input_hashes'].get(str(source))==expected
 return b
ap=argparse.ArgumentParser(description=__doc__)
for n in ['native-facts','native-facts-receipt','stub-leaf','stub-artifact','solution-leaf','solution-artifact']:ap.add_argument('--'+n,type=Path,required=True)
ap.add_argument('--out',type=Path,default=D/'bound/final.json');a=ap.parse_args();c=read(D/'configs/four-role.template.json')
for role in ['stub','solution']:
 p=Path(c[role+'InstalledSource']);expected=c['expected'+role.title()+'Text'].encode();assert p.read_bytes()==expected
 c[role+'ReceiptBindings']=[receipt(getattr(a,role+'_'+k),p,hashlib.sha256(expected).hexdigest())for k in ['leaf','artifact']]
n=binding(a.native_facts);j=n['contents'];assert j['schema']=='pure-historical-native-type-facts/v13'and j['targetName']==c['targetName']and j['nativeName']==c['nativeName'];assert j['kernelOriginalNativeTypeEqual']and j['fullBinderInfoEqual'];assert not j['nativeBodyDirectSorryAx']and not j['nativeHasTransitiveSorryAx'];assert j['typeProofValues']==[]
n['receipt']=receipt(a.native_facts_receipt);nr=n['receipt']['contents'];np=Path(nr['request']['environment']['PURE_FOUR_ROLE_CONFIG']);assert read(np)==j['configuration'];assert nr['request']['worktree_manifest']['input_hashes'].get(str(np))==sha(np)
assert j['configuration']['sourceTypeFactsBinding']==c['sourceTypeFactsBinding'];assert j['configuration']['proofByteEvidence']==c['proofByteEvidence'];assert j['configuration']['typedataMapEvidence']==c['typedataMapEvidence'];assert j['nativeSourceText']==c['expectedNativeText'];c['nativeFactsBinding']=n;c['pending']='Only final four-role review is pending; no final passed flag is inferred from binding.'
out=a.out.resolve();assert out.is_relative_to(D);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(str(out),sha(out))
