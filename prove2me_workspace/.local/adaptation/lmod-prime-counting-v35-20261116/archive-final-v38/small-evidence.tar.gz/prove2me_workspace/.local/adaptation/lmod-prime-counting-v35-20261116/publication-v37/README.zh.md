本目录是 lmod 单节点的 not-ready 私有 problem+proof 发布草稿。没有调用 CI、API 或 Git，也没有修改 W 或正在运行的源/config/query。

主入口：`payload.json`、`packet.json`、`ready.not-ready.json`、`publisher.py`、`bind_ready.py`。
`packet.allGatesAccepted=false`，`ready.not-ready.passed=false`，14个gate均为null。现有若干角色成功没有被提升成单元总验收。

协议直接复用 Procession 已验收的 `final-publisher-v33/{publisher.py,delivery_with_proved_parent.py}`。
仅更改单节点名、当前4个data-owner源pin，以及精确readback的输出文件名。仍是 `/submit-problem` 后 multipart `/verify`，保留原mutation journal、幂等重放禁止、private existing-mission和root graph前后核对。
没有使用upload-full-project或创建新mission；solution无Theorems imports，使用已发布Definitions。

数学与语言材料：

- 真实 `theorem solution` 与stub复制自已安装W/Solutions、W/Theorems；staging字节相同。
- proof body SHA256仍为 `499d0410c10e8c12f53355dc06192f7af8433f6d55937bbec1c4c62795389be8`。
- 冻结B英文/中文/日文按原字节保留，含旧statement-stub的`by sorry`历史描述；没有改写成已证读回。
- 既有视觉核验论文材料直接复用 Proposition1.6(p16)、父Theorem1.10开头(p22)、父proof Step(iii)指标定义(p25)，页面PNG/raw evidence的hash重新静态核对。
- 论文 Proposition1.6 原文因子为4/3；实际Lean证书与helper是3/2。payload明确区分。
- Theorem1.10引文是父上下文，未冒称本helper有独立原纸GenericLemma编号或逐字同一纸面命题。
- upstream真实源链接为 `Theorem110.lean#L168-L225`；normalized parser坐标174–231单列记录，不混成GitHub行号。
- 源实际消费者仍是 `Iut.Theorem110Invariants.theorem110`。canonicalC22、root_graph_membership、S2-04完成均为false。

`registered-dependencies.json`逐字复制roles-v36已绑定10项dataMap；所需原型常量均为普通命名，不增private猜测或数据identity门。
四个源pin是Orbicurve、LocalConditions、Statement、Invariants当前已发布Definition，publisher检查文件hash。

root在真实四角色final通过之后再运行：

```text
python3 bind_ready.py \
  --four-role-audit <真实four-role-audit.json> \
  --four-role-receipt <对应成功result.json> \
  --shared-acceptance <root填写的shared-acceptance.json>
```

`shared-acceptance.template.json`只给出待填结构。root需提供真实生产Checks/Axioms、ImportAudit、Act1Scene1、AxiomAudit、git diff和现有private mission证据，或者明确成立的现行pin复用记录。
不能直接把模板的null改true而缺证据；binder要求六个shared gate的逐项evidence。
`production-gate-reuse.existing.json`是此前已验收的原记录，未自动声明它覆盖本单元；是否适用由root确认。
`existing-private-mission.json`是既有mission记录；实际delivery仍按原协议实时核对private mission/root/environment。

ready binder读取真实final audit的configuration，重核原TYPE、sourceproof InfoTree、原proof hash、native/stub/solution 6份leaf/artifact回执、source hash和终态exclusive/null，直接从真实configuration抽取路径；不依赖失败query或预猜后续job ID。
它要求12项audit flag为true、5项sorry flag为false、六对TYPE/BinderInfo及标准公理输出，再与现行源/冻结语言/消费者ledger核对。
成功只生成新`packet.ready.json`和`ready.final.json`，原not-ready草稿保留；随后调用publisher的只读preflight，仍不触网。

root完成具体审查与授权范围核对后，原协议的显式入口才是：

```python
publisher.deliver(packet_path, ready_path, platform_directory)
```

本子智能体没有调用该入口。不得在本地四角色尚未验收时运行delivery。
旧NativeFacts discard语法失败是历史query/receipt，发布binder只绑定最终实际成功回执，未删除或覆盖失败证据。
