#!/usr/bin/env python3
"""Root-only ready binder for actual final lmod receipts. No API, compiler, or Git."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import argparse,json,hashlib,importlib.util
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,j):
 p=Path(p).resolve();assert p.is_relative_to(D);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def validate_receipt(path):
 p=Path(path).resolve();r=read(p);assert r['status']=='succeeded'and r['result']['exit_code']==0
 assert r['request']['workspace']==str(W)and r['request']['exclusive']is True
 assert r['result']['snapshot']['workspace_mode']=='exclusive_worktree'and r['result']['snapshot']['snapshot_id']is None
 return r
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--four-role-audit',type=Path,required=True);ap.add_argument('--four-role-receipt',type=Path,required=True);ap.add_argument('--shared-acceptance',type=Path,required=True);a=ap.parse_args()
spec=importlib.util.spec_from_file_location('lmod_ready_publisher',D/'publisher.py');pub=importlib.util.module_from_spec(spec);spec.loader.exec_module(pub)
packet=read(D/'packet.json');name=packet['publications'][0]['payload']['theorem_name'];audit=read(a.four_role_audit);assert audit['targetName']==name and audit['sourceName']=='Iut.Theorem110Invariants.lmod_mul_logSle_le'
for flag in pub.AUDIT_FLAGS:assert audit[flag]is True,(flag,'not passed')
for flag in pub.NO_SORRY_FLAGS:assert audit[flag]is False,(flag,'not excluded')
for key in ['nativeAxioms','solutionAxioms','registeredDependencyAxioms']:assert set(audit[key])<={'propext','Classical.choice','Quot.sound'}
assert audit['sourceProofSha256']=='499d0410c10e8c12f53355dc06192f7af8433f6d55937bbec1c4c62795389be8';assert len(audit['sixPairComparisons'])==6
receipt=validate_receipt(a.four_role_receipt);cfg=audit['configuration'];cp=Path(receipt['request']['environment']['PURE_FOUR_ROLE_CONFIG']);assert read(cp)==cfg;assert receipt['request']['worktree_manifest']['input_hashes'][str(cp)]==sha(cp);assert Path(cfg['finalOutput']).resolve()==a.four_role_audit.resolve()
for key in ['sourceTypeFactsBinding','nativeFactsBinding']:
 b=cfg[key];assert read(b['path'])==b['contents']and sha(b['path'])==b['sha256']
source=cfg['sourceBinding'];sp=source['oracleReceipt']['path'];sr=validate_receipt(sp);assert sr['job_id']==audit['sourceOracleJob'];assert source['oracleIndex']['contents']['complete']is True and source['oracleDiagnostics']['contents']['hasErrors']is False
required={'source_proof_oracle':sp,'source_native_stub_solution_kernel_audit':str(a.four_role_receipt.resolve()),'recursive_axiom_audit':str(a.four_role_receipt.resolve()),'registered_dependency_closure_audit':str(a.four_role_receipt.resolve())}
receipts=[]
for role in ['native','stub','solution']:
 rows=cfg[role+'ReceiptBindings'];assert len(rows)==2
 for item,kind in zip(rows,['leaf','artifact']):
  p=item['path'];r=validate_receipt(p);assert r==item['contents']and sha(p)==item['sha256'];required[role+'_'+kind]=p;receipts.append(p)
 installed=Path(cfg[role+'InstalledSource']);assert installed.read_text()==cfg['expected'+role.title()+'Text']
 for item in rows:assert item['contents']['request']['worktree_manifest']['input_hashes'][str(installed)]==sha(installed)
assert set(required)==pub.REQUIRED_PER_NODE
receipts.append(str(a.four_role_receipt.resolve()))
shared=read(a.shared_acceptance);assert shared['passed']is True;needed={'checks_axioms','import_audit','act1scene1','axiom_audit','git_diff_check','existing_mission_scope'};assert set(shared['gates'])==needed and all(v is True for v in shared['gates'].values());assert set(shared['shared_required_inputs'])=={'production_checks','import_audit','git_diff_check','existing_private_mission'}
assert set(shared['gateEvidence'])==needed and all(isinstance(v,list)and v for v in shared['gateEvidence'].values());evidence_paths={str(a.four_role_audit.resolve()),str(a.four_role_receipt.resolve()),str(a.shared_acceptance.resolve()),str(cp)}
for p in shared['shared_required_inputs'].values():assert p and Path(p).is_file();evidence_paths.add(str(Path(p).resolve()))
for rows in shared['gateEvidence'].values():
 for p in rows:assert Path(p).is_file();evidence_paths.add(str(Path(p).resolve()))
# Reuse frozen languages and recorded actual consumer edges without changing their historical open-proof descriptions.
for path,digest in packet['metadata_sha256'].items():assert sha(path)==digest
for rel,digest in packet['source_sha256'].items():assert sha(W/rel)==digest
for rel,digest in packet['dependency_source_sha256'].items():assert sha(W/rel)==digest
ledger=read(D/'SOURCE_LEDGER.json')['entries'];assert len(ledger)==1 and ledger[0]['producer']==name and ledger[0]['actualConsumers']==[{'consumer':'Iut.Theorem110Invariants.theorem110','module':'Iut.Implication.Theorem110','edge':'value'}]
rb=packet['frozenReadbacks'][name];assert rb['readbacks']['en']==rb['originalEnglish'];assert all(t in packet['publications'][0]['payload']['natural_language_statement']for t in rb['readbacks'].values());assert sha(cfg['typedataMapEvidence']['path'])==cfg['typedataMapEvidence']['sha256'];assert read(cfg['typedataMapEvidence']['path'])['requiredSourceTypeProjectConstants']==read(D/'registered-dependencies.json')['requiredSourceTypeProjectConstants']
for key in ['sourceTypeFactsBinding','nativeFactsBinding']:
 b=cfg[key];evidence_paths.add(b['path'])
 if 'receipt'in b:evidence_paths.add(b['receipt']['path'])
evidence_paths.update([sp,cfg['sourceTypeReceipt']['path'],source['oracleIndex']['path'],source['oracleDiagnostics']['path'],source['oracleFactsPath'],source['oracleCoordinateSource'],cfg['typedataMapEvidence']['path']]);evidence_paths.update(receipts)
evidence_paths.update(packet['metadata_sha256']);gates={k:True for k in pub.old.GATES};assert len(gates)==14
gates.update(shared['gates']);packet['allGatesAccepted']=True;packet['schema']='single-lmod-private-problem-proof-ready/v37';save(D/'packet.ready.json',packet)
ready={'passed':True,'packet_sha256':sha(D/'packet.ready.json'),'source_sha256':packet['source_sha256'],'gates':gates,'ci_receipts':list(dict.fromkeys(receipts)),'evidence_sha256':{str(Path(p).resolve()):sha(p)for p in evidence_paths},'explanations':packet['explanations'],'kernel_audits':{name:str(a.four_role_audit.resolve())},'source_oracle_receipts':{name:sp},'source_type_receipts':{name:cfg['sourceTypeReceipt']['path']},'source_type_facts':{name:cfg['sourceTypeFactsBinding']['path']},'dependency_source_sha256':packet['dependency_source_sha256'],'required_inputs':{name:required},'shared_required_inputs':shared['shared_required_inputs'],'note':'Only actual final audit acceptance and explicit root shared-gate evidence were bound. Mathematical parent theorem110/c2/S2-04 remain open.'};save(D/'ready.final.json',ready);pub.preflight(D/'packet.ready.json',D/'ready.final.json');print('Ready binding validated. No network call was made.')
