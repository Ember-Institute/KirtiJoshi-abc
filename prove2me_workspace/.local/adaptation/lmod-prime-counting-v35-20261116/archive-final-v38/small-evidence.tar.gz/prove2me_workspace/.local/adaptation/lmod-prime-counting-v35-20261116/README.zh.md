推荐下一单元：`AbcAdaptation.Reference.Iut.Theorem110Invariants.lmod_mul_logSle_le`。

这是实际来源 `Iut.Implication.Theorem110` 中的 Step (viii) 素数计数桥梁。
`theorem110` 直接调用 `inv.lmod_mul_logSle_le pnt`，再交给已经发布的 `assembly`。
本单元没有尚未发布的来源 theorem helper；依赖是已经验收的 Invariants 数据结构及 Mathlib。
相比 `LocalEstimate.rhs_le`，它不需要先整合多层局部体积 helper。
原证明体有 53 行，保留一整个定理；没有新增可发布小 helper，也没有将数学输入换成任意 Prop。

已先核对 `platform-node-registry.json` 的 `reference_source_preparation`：33 Definition 包、17 proved helpers。
`assembly`（theorem id `0b590c9f-4db2-4fc6-a880-59c223ef8178`）和 `c2_final` 均已发布，故排除。
所选 `lmod_mul_logSle_le` 尚未注册。顶层旧 published_nodes 不是来源包完整清单。

完整原型（`u v` 是宇宙参数）：

```lean
{AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
{X : Corollary312VariantData.{u, v} AG TG}
(inv : Theorem110Invariants X) (pnt : PrimeCountingBound) :
  inv.lmod * inv.logSle ≤ 3 / 2 * ((inv.eStar : ℝ) * X.ℓ + pnt.η)
```

`inv` 和 `pnt` 是显式参数；`AG`、`TG`、`X` 是隐式参数，没有额外实例参数。
`pnt` 保留全部字段：`η : ℝ`、`1 < η`、对任意实数 `x ≥ η` 的自然数 floor 素数计数界。
`inv` 保留整个原结构；`eStar = 552960 * emod`，`lmod = log(eStar * ℓ)`，
`logSle` 是在自然数闭区间截断下的 distinguished-prime 指标和。
原型用 `3/2`，不替换成论文 `4/3`；这项来源差异必须在最终说明中保留。

产物：

- `native/Thm_....lean`：完整目标声明，原证明体逐字复制，只有 outer namespace / imports 适配。
- `native/*_NativeAuditProof.lean`：独立命名的原 proof，供同时导入 stub 的四角色审查；完整 proof body 不变。
- `stub/Thm_....lean`：同原型的 `sorry` 占位；仅供平台目标陈述与四角色比较。
- `solution/Solution.lean`：同 proof 的 `_SolutionAuditProof` 命名声明；不是平台已验收解。
- `solution/proof.lean.txt`：可插入全局 solution 环境的原 `by` term。
- `OriginalCommands/`、`SourceProbes/`：直接复制已有 accepted-AST 生成产物。
- `source-proof-oracle.config.json`：复用已有原证明 oracle config，仅输出和输入副本路径改到此临时目录。
- `source-type-oracle.config.json`、`QueryLmodOriginalTypeFacts.lean`：复用原 exporter；只读缓存目标 TYPE，完整 proof 仍独立从 SourceProbe 编译。
- `source-difference-metadata.json`：图边、原来源路径/范围/hash、proof hash、未编译状态与原 metadata。
- `readbacks/`：逐字冻结原 B 读回/三语/术语/coverage；`selected-lmod-trilingual.json` 只是选择原记录，未改写其中旧 `sorry` 状态。

复用来源：

`A/main-chain-open-20261116/tools/generated/{OriginalCommands,OracleSourceProbes,OracleConfigs,metadata,OpenSourceDrafts}/Iut_Theorem110Invariants_lmod_mul_logSle_le.*`

`A/main-chain-open-20261116/independent-readbacks-v9/{readback-b-en,trilingual-b,terminology-b,coverage}.json`

原 parser 回执 `ci-014817-8a1bb50d` 证明源码语法提取；不代替原定理 proof 编译。
当前 metadata 的 `graphCompilerType` / `graphCompilerTelescope` 仍是 null。
不能借用 carrier-only facts 当此 proof 的 compiler facts。
原 normalized 文件与 upstream 整文件不同；所选整个原 command 同时逐字出现在 upstream 中，选定 proof body 无差异。
proof body（包含 `:= by`）SHA256：`499d0410c10e8c12f53355dc06192f7af8433f6d55937bbec1c4c62795389be8`。

主智能体最少 CI 流程：

1. 审查后将固定草稿复制到实际 W 的任务专属路径。先复用本地热依赖和已有 exporter。
   原 SourceProbe 只 import `Iut.Implication.LogVolumeBound`，不 import 自己 `Theorem110` 目标模块。
   首次来源 proof 任务保留 `60s` / `16GiB`，`exclusive: true`；只跑现有原证明 oracle 配置。
   同一来源版本再运行缓存 TYPE exporter（可以复用已接受模板）；允许的数据名来自 graphTypeDependencies。
   不把 TYPE exporter 的 cached goal import 当独立 proof oracle。
2. 原 facts 确认完整 telescope / refs 后，核对 native 精确 imports。对 native、stub、global solution 各做叶检查与所需 artifact/facts 导出。
   每个新叶首次都是 `60s` / `16GiB`。当前 native imports 仅静态核实存在，尚未编译验证。
3. 复用 `independent-two-four-role-v25-20261116/{bind_roles,prepare_audits,prepare_packets}.py` 的四角色方法，
   用本单元真实 source type/source proof/native proof/stub/global solution facts 绑定，做一个定点四角色及公理 review。
   旧纯实数 helper 没有项目数据依赖；本单元必须显式映射原 Invariants 及上游数据，不能照抄空 allowedDataNames。
4. 命名证明整合后统一检查实际消费者连通、所属 Checks/Axioms、ImportAudit、Act1Scene1、AxiomAudit、`git diff --check`。
   复用已验收稳定依赖，避免重验全部 200/173 声明。最后才生成具体平台 payload 并发布。

每个提交仍由 root 填真实 manifest、绝对 workspace、session/agent、幂等键；本子智能体没有发 CI、编译、API 或 Git。
叶和 exporter 具体任务类型按 root 已验收模板：叶是 `leaf/file/parameters.source`，结构化 exporter 使用既有 `--run` 工作流。
提交后保持输入稳定直到终态，读 result 核实 RSS/PSS、CPU 与公理；原 proof 超过 16GiB 必须拆小声明验收。
本交付不声称 theorem110、c2、S2-04 或 Act2 数学输入已完成。

原 TYPE exporter 保留 `4.35.0-rc3` guard，必须在已有 original-source4.35 环境运行；native 叶则用项目锁定4.33.1。
