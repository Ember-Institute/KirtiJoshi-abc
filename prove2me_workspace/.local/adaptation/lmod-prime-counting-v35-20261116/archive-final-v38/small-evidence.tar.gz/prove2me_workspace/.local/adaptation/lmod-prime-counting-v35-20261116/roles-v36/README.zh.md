本次只交付顶层 `theorem solution`、同原型目标 stub 和最小四角色入口，全部文件位于本任务 `/tmp`。未改主区或已冻结 v35 目录，未调用 CI/API/Git。

安装到 W 的两份文件：

- `Solutions/Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_lmod_mul_logSle_le.lean`
- `Theorems/Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_lmod_mul_logSle_le.lean`

solution 顶层声明名是 `solution`，目标 stub 顶层名为完整的 `AbcAdaptation.Reference.Iut.Theorem110Invariants.lmod_mul_logSle_le`。
两者显式写出 `{AG} {TG} {X} (inv) (pnt)`。`open AbcAdaptation.Reference.Iut` 和 `open AbcAdaptation.Reference.Iut.Theorem110Invariants` 恢复原来源上下文中裸写的 `eStar`、`lmod`、`logSle`、`ι`、`Corollary312VariantData.ℓ`；没有 namespace 包裹，也没有替代数据 alias。
原 ` (pnt : PrimeCountingBound) : ...` 的完整尾部签名字节仍逐字存在。全量 telescope 将由真实四角色 TYPE/BinderInfo 比较确认。
原53行 `:= by` 证明体未改，SHA256 为 `499d0410c10e8c12f53355dc06192f7af8433f6d55937bbec1c4c62795389be8`。

已读取和绑定的真实证据：

- 原 proof `ci-017433-8866e8c9`；InfoTree 一条声明、124条 references，成功无 error。
- 原 TYPE `ci-017435-6c0edd5d`；`u,v`、三个 implicit、`inv,pnt` 两个 default，TYPE proof values 为0。
- native leaf `ci-017432-1ba53ddc` 与 artifact `ci-017436-f27d2c17`。

四份终态回执均核验 succeeded/exit0/exclusive/null，并绑定实际 JSON 内容。native输入hash还核对到回执 manifest。
这四项已有成功不代表新的 stub/global solution 或四角色审查成功。

`typedata-map-evidence.json` 从真实 source TYPE Expr 提取10个 Iut data constants。
其中8项映射逐字取自 `main5-local-dossier-v27-20261116/current-owned176-config.json` 的 projectMap；
`AnabelianGeometry`、`TemperedGeometry` 两项取自 `current-source-log32-config.json` 的既有 projectMap。
所有映射再绑定当前已发布的 Orbicurve、LocalConditions、Statement、Invariants Definition ID和当前主区源码hash。
旧map内 `candidate-only` 历史状态保留原文，当前发布状态单列，未篡改历史证据。
没有 private TYPE 常量、private数字猜测、TYPE proof expansion 或新的数据 identity 门。
`nativeDataNames.lean.txt` 是这10项 source→native 与native→native 的20对映射。

最少下一步：

1. root安装上述两份文件，在 W/Solutions 与 W/Theorems 分别 leaf/artifact；新叶首次仍60s/16GiB，exclusive，真实manifest。
2. 运行 `queries/NativeFacts.lean`，环境 `PURE_FOUR_ROLE_CONFIG` 指向 `configs/four-role.template.json`。
   此入口直接 import `«.local».adaptation.«lmod-prime-counting-v35-20261116».native.<NativeAuditProof stem>`，复用ci017436现有olean。
   名称用实际路径分量编码，`.local` 是一个Name component，hyphen目录使用quoted identifier。
   实际 module owner由既有 `moduleOf/getModuleIdxFor?` 检验；不为改名重编native。
   template里source facts、source proof、native receipts均已绑定；此阶段不读取尚不存在的stub/solution receipt。
3. `bind_final.py --native-facts <actual-native-facts.json> --native-facts-receipt <result.json> --stub-leaf <result.json> --stub-artifact <result.json> --solution-leaf <result.json> --solution-artifact <result.json>`。
   脚本仅绑定真实回执、实际源码hash和nativefacts；缺项直接停止，不填passed。
4. 运行 `queries/FourRoles.lean`，同环境键指向 `bound/final.json`。入口比较 source/native/stub/global solution 全型的6对 kernel equality和BinderInfo，核验完整 proof字节及标准公理/sorry closure。
   只有该真实review终态通过才形成四角色验收。随后按项目要求整合Checks/Axioms、ImportAudit、Act1Scene1、AxiomAudit、diff check。

查询只复用已有 accepted four-role实现，改动为：精确native module/name、10项dataMap、让typeProofRows跳过明确映射的data、无注册theorem helper时不要求虚构dependency receipt。
本定理没有未发布 theorem helper；项目数据identity复用既有接受证据，最终实际type/kernel比较仍必须执行。
`registeredDependencyNames=[]` 只表示无额外 theorem proof节点；不表示10个数据依赖不存在。

此目录尚未提交 CI。新stub、顶层solution、nativefacts和fourroles的状态见 `draft-state.json`，全部待root实际验收。
