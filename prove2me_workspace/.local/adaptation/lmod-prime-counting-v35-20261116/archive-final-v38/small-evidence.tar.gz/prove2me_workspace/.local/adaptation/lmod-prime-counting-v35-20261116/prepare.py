import pathlib,json,hashlib,shutil
W=pathlib.Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';G=A/'main-chain-open-20261116/tools/generated';O=pathlib.Path('/tmp/p2m-next-main-chain-unit-v35-20261116');N='Iut.Theorem110Invariants.lmod_mul_logSle_le';slug=N.replace('.','_');target='AbcAdaptation.Reference.'+N
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
pin=lambda p:{'path':str(p),'sha256':sha(p)}
save=lambda p,x:pathlib.Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
m=json.loads((G/'metadata'/f'{slug}.json').read_text());raw=(G/'OriginalCommands'/f'{slug}.lean').read_text();sig,body=raw.split(':= by',1);proof=':= by'+body
registry=json.loads((A/'platform-node-registry.json').read_text())['reference_source_preparation'];names=[r['name'] for r in registry['proved_nodes']];assert target not in names;assert 'AbcAdaptation.Reference.Iut.assembly' in names
imports='''import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.NumberTheory.PrimeCounting
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
'''
notice='''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Candidate only; no compilation or publication is claimed. Source command and
proof body are retained. Imports and the enclosing adaptation namespace change.
Original source: Iut/Implication/Theorem110.lean, lines 174-231.
Original commit: 07cb1da58f6d428a670dbb5dd6093d428bcbcdd8.
-/
'''
ctx='''
set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
namespace AbcAdaptation.Reference
namespace Iut
universe u v
open NumberField
variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
namespace Theorem110Invariants
variable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)

''';close='\nend Theorem110Invariants\nend Iut\nend AbcAdaptation.Reference\n'
for folder in ['native','stub','solution','OriginalCommands','SourceProbes','readbacks']: (O/folder).mkdir(exist_ok=True)
name=f'Thm_AbcAdaptation_Reference_{slug}.lean'
(O/'native'/name).write_text(notice+imports+ctx+raw+close)
(O/'stub'/name).write_text(notice+imports+ctx+sig+':= by\n  sorry\n'+close)
(O/'native'/name.replace('.lean','_NativeAuditProof.lean')).write_text(notice+imports+ctx+raw.replace('lemma lmod_mul_logSle_le','lemma lmod_mul_logSle_le_NativeAuditProof',1)+close)
(O/'solution'/'Solution.lean').write_text(notice+imports+ctx+raw.replace('lemma lmod_mul_logSle_le','lemma lmod_mul_logSle_le_SolutionAuditProof',1)+close)
(O/'solution'/'proof.lean.txt').write_text('by'+body)
shutil.copyfile(G/'OriginalCommands'/f'{slug}.lean',O/'OriginalCommands'/f'{slug}.lean')
shutil.copyfile(m['oracleProbe']['path'],O/'SourceProbes'/f'{slug}.lean')
fulltype='''universe u v
{AG : AbcAdaptation.Reference.Iut.AnabelianGeometry.{u}}
{TG : AbcAdaptation.Reference.Iut.TemperedGeometry AG}
{X : AbcAdaptation.Reference.Iut.Corollary312VariantData.{u,v} AG TG}
(inv : AbcAdaptation.Reference.Iut.Theorem110Invariants X)
(pnt : AbcAdaptation.Reference.Iut.PrimeCountingBound) :
  inv.lmod * inv.logSle ≤ 3 / 2 * ((inv.eStar : ℝ) * X.ℓ + pnt.η)
'''
(O/'complete-source-signature.txt').write_text(fulltype)
R=A/'main-chain-open-20261116/independent-readbacks-v9';refs=[]
for f in ['readback-b-en.json','trilingual-b.json','terminology-b.json','coverage.json']:
 src=R/f;dest=O/'readbacks'/f;shutil.copyfile(src,dest);refs.append({'original':pin(src),'frozenCopy':pin(dest)})
tr=json.loads((R/'trilingual-b.json').read_text());row=next(r for r in tr['nodes'] if r['sourceName']==N);save(O/'readbacks'/'selected-lmod-trilingual.json',row)
config=json.loads(pathlib.Path(m['oracleConfig']['path']).read_text());config['outputDir']=str(O/'actual/source-proof');config['files'][0]['source']=str(O/'SourceProbes'/f'{slug}.lean');save(O/'source-proof-oracle.config.json',config)
save(O/'source-difference-metadata.json',{
 'schema':'next-main-chain-unit-candidate-v35','status':'draft-only-uncompiled','sourceName':N,'targetName':target,
 'selectionReason':'Direct proof dependency of theorem110; no unpublished theorem dependencies; retains complete original PrimeCountingBound and invariant records.',
 'registry':{'source':pin(A/'platform-node-registry.json'),'referenceDefinitionCount':len(registry['definitions']),'provedHelperCount':len(names),'selectedAlreadyPublished':target in names,'excludedAlreadyPublished':['AbcAdaptation.Reference.Iut.assembly','AbcAdaptation.Reference.Iut.c2_final']},
 'sourceMetadata':pin(G/'metadata'/f'{slug}.json'),'sourceMetadataRetained':m,
 'completeSourceTypeText':fulltype,'compilerTypeExpr':None,'compilerTelescope':None,'compilerFactsStatus':'pending root MCP-CI; not inferred from carrier proof facts',
 'sourceSourceProofBytes':{'sourceCommand':pin(G/'OriginalCommands'/f'{slug}.lean'),'copiedCommand':pin(O/'OriginalCommands'/f'{slug}.lean'),'bodySha256':hashlib.sha256(proof.rstrip('\n').encode()).hexdigest(),'recordedParserBodySha256':m['originalBodyHashes'][0]},
 'nativeAdaptationChanges':['Add AbcAdaptation.Reference outer namespace','Replace import Iut.Implication.LogVolumeBound with accepted Invariants module and precise Mathlib proof imports','NativeAuditProof and SolutionAuditProof only: change own declaration binding'],
 'proofBodyChanged':False,'sourceSignatureChanged':False,'newHypotheses':[],'shortPrivateHelpersAdded':[],
 'nativeSource':pin(O/'native'/name),'stubSource':pin(O/'stub'/name),'solutionAuditSource':pin(O/'solution/Solution.lean'),'solutionTerm':pin(O/'solution/proof.lean.txt'),
 'actualConsumerEdges':m['actualConsumerEdges'],'frozenReadbacks':refs,
 'frozenReadbackScope':'Exact reuse of pre-existing open-statement readback. The text correctly described the old sorry stub; it is not edited to claim proof completion.',
 'scopeLimits':{'theorem110Proved':False,'canonicalC22Connected':False,'S2-04Completed':False,'platformReady':False},
 'ciPolicy':{'exclusive':True,'sourceWorkspace':str(W),'firstLeafExpectedDuration':'60s','firstLeafExpectedMemory':'16GiB','subagentCalledCI':False,'subagentCompiled':False}})
shutil.copyfile(A/'independent-two-four-role-v25-20261116/LICENSE.iut.Apache-2.0',O/'LICENSE.iut.Apache-2.0')
print('Prepared',O);print('source proof body SHA',hashlib.sha256(proof.rstrip('\n').encode()).hexdigest()); print('expected',m['originalBodyHashes'][0]);print('native proof line count',len(body.splitlines()))
