/- Adaptation source oracle candidate. The original notice follows. Retained original commands, binding Names, bodies, and contexts are unchanged. Additional source helper imports, if present, contain no selected goal. No oracle acceptance is claimed. -/
/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Iut.Implication.LogVolumeBound

set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3

/-!
# IUT IV, Theorem 1.10 from the Corollary 3.12 variant (taxis #3, #1453)

**Theorem 1.10 (Log-volume estimates for Θ-pilot objects).** In the situation of
Corollary 3.12, with the arithmetic invariants of `Theorem110Invariants`,

`(1/6)·log(q) ≤ (1 + 20·d_mod/ℓ)·(log(d_{F_tpd}) + log(f_{F_tpd})) + 20·(e*_mod·ℓ + η_prm)`.

This file proves it (`Theorem110Invariants.theorem110`) from:

* the Corollary 3.12 variant `Iut.Corollary312Variant X`, i.e. `−|log(q)| ≤ −|log(Θ)|`
  — the **only** IUT I–III input;
* the local estimates of Steps (iv)–(vii) (`LocalEstimate`, Propositions 1.4, 1.5, 1.7);
* the arithmetic certificate of Steps (ii)–(iii) (`Theorem110Certificate`,
  Propositions 1.3, 1.8);
* the prime-counting bound of Proposition 1.6 (`PrimeCountingBound`).

What is proved here, following the printed proof step by step:

* Step (v)/(vii), the procession average: the capsule-wise bounds are averaged over the
  standard procession of length `ℓ* = (ℓ−1)/2` using the identities (E1), (E2)
  (`sum_affine_quadratic`), giving the "procession-normalized upper bound"
  `((ℓ+5)/4)·log(d^K_{v_ℚ}) − ((ℓ+1)/24)·log(q_{v_ℚ}) + log(s^ℚ_{v_ℚ}) +
  (ℓ+5)·l*_mod·log(s^≤_{v_ℚ})` at distinguished primes and `((ℓ+5)/4)·log π` at the
  archimedean place;
* Step (viii): the sum over `v_ℚ`, the substitution of Corollary 3.12, the estimate
  `l*_mod·log(s^≤) ≤ (3/2)·(e*_mod·ℓ + η_prm)` from Proposition 1.6
  (`lmod_mul_logSle_le`; the printed proof has the factor `4/3`, and the slack of the
  number tracking absorbs the factor `3/2` of `PrimeCountingBound`), the combination with
  Steps (ii)–(iii), and the final number tracking (`assembly`).
-/

namespace Iut

universe u v

open NumberField

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}

/-! ### Elementary identities (E1), (E2) and real-arithmetic lemmas -/

namespace Theorem110Invariants

variable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)

/-- Step (viii), the Proposition 1.6 input: `l*_mod·log(s^≤) ≤ (3/2)·(e*_mod·ℓ + η_prm)`
(the printed proof has `4/3`, from the printed factor of Proposition 1.6). Proved from the
prime-counting certificate: `log(s^≤)` counts distinguished primes `≤ e*_mod·ℓ`, hence is
at most `π(e*_mod·ℓ)`. -/
lemma lmod_mul_logSle_le (pnt : PrimeCountingBound) :
    inv.lmod * inv.logSle ≤ 3 / 2 * ((inv.eStar : ℝ) * X.ℓ + pnt.η) := by
  set N : ℕ := inv.eStar * X.ℓ with hN
  have hN1 : 2 ≤ N := by
    have h1 := inv.one_le_emod
    have h2 := X.data.prime.five_le
    have h3 : 1 * 5 ≤ inv.emod * X.data.ℓ := Nat.mul_le_mul h1 h2
    simp only [hN, eStar, Corollary312VariantData.ℓ]
    calc 2 ≤ 552960 * (1 * 5) := by norm_num
      _ ≤ 552960 * (inv.emod * X.data.ℓ) := Nat.mul_le_mul_left _ h3
      _ = 552960 * inv.emod * X.data.ℓ := by ring
  have hNr : (2 : ℝ) ≤ N := by exact_mod_cast hN1
  have hNcast : ((inv.eStar : ℝ) * X.ℓ) = N := by simp [hN]
  -- `log(s^≤) ≤ π(N)`
  have hcount : inv.logSle ≤ (Nat.primeCounting N : ℝ) := by
    unfold logSle ι
    rw [Finset.sum_boole]
    have hsub : (inv.dst.filter fun p => p ≤ N) ⊆ Nat.primesLE N := by
      intro p hp
      rw [Finset.mem_filter] at hp
      change p ∈ Nat.primesBelow (N + 1)
      rw [Nat.mem_primesBelow]
      exact ⟨by omega, inv.dst_prime p hp.1⟩
    rw [← Nat.primesLE_card_eq_primeCounting]
    exact_mod_cast Finset.card_le_card hsub
  have hlmod : inv.lmod = Real.log N := by rw [lmod, hNcast]
  have hlogN : 0 < Real.log N := Real.log_pos (by linarith)
  have hη : 0 < pnt.η := by linarith [pnt.one_lt_η]
  have hlogη : 0 < Real.log pnt.η := Real.log_pos pnt.one_lt_η
  rw [hlmod, hNcast]
  rcases le_or_gt pnt.η N with hle | hlt
  · -- `N ≥ η_prm`: apply the bound at `x = N`
    have hb := pnt.bound N hle
    rw [Nat.floor_natCast] at hb
    calc Real.log N * inv.logSle ≤ Real.log N * (Nat.primeCounting N : ℝ) :=
          mul_le_mul_of_nonneg_left hcount hlogN.le
      _ ≤ Real.log N * (3 * N / (2 * Real.log N)) :=
          mul_le_mul_of_nonneg_left hb hlogN.le
      _ = 3 / 2 * (N : ℝ) := by field_simp
      _ ≤ 3 / 2 * ((N : ℝ) + pnt.η) := by linarith
  · -- `N < η_prm`: `π(N) ≤ π(⌊η_prm⌋)` and apply the bound at `x = η_prm`
    have hb := pnt.bound pnt.η le_rfl
    have hmono : (Nat.primeCounting N : ℝ) ≤ Nat.primeCounting ⌊pnt.η⌋₊ := by
      exact_mod_cast Nat.monotone_primeCounting (Nat.le_floor hlt.le)
    have hlogle : Real.log N ≤ Real.log pnt.η := Real.log_le_log (by linarith) hlt.le
    have hcnt0 : (0 : ℝ) ≤ Nat.primeCounting ⌊pnt.η⌋₊ := by positivity
    calc Real.log N * inv.logSle ≤ Real.log N * (Nat.primeCounting N : ℝ) :=
          mul_le_mul_of_nonneg_left hcount hlogN.le
      _ ≤ Real.log pnt.η * (Nat.primeCounting ⌊pnt.η⌋₊ : ℝ) :=
          mul_le_mul hlogle hmono (by positivity) hlogη.le
      _ ≤ Real.log pnt.η * (3 * pnt.η / (2 * Real.log pnt.η)) :=
          mul_le_mul_of_nonneg_left hb hlogη.le
      _ = 3 / 2 * pnt.η := by field_simp
      _ ≤ 3 / 2 * ((N : ℝ) + pnt.η) := by linarith

end Theorem110Invariants

end Iut
