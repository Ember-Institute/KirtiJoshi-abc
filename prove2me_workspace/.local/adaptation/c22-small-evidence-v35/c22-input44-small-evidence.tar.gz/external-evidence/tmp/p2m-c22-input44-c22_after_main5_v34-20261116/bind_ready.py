"""Bind the existing C22 Definition protocol to actual current evidence; offline only."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re, shutil
O=Path(__file__).resolve().parent
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace'); A=W/'.local/adaptation'; C=A/'c2-complete-inputs-20261116'
NAME='AbcAdaptation_Reference_Iut_Implication_Corollary22'; TARGET='Definitions/Def_'+NAME+'.lean'
TEMPLATE=Path('/tmp/p2m-main5-publish-finish-v33-20261116/publisher-template.py')
GATES={'new_leaf_modules','new_leaf_artifacts','checks_axioms','wrapped_kernel_type_identity','import_audit','act1scene1','axiom_audit','independent_readbacks','source_ledger_consumers','git_diff_check','existing_mission_scope','final_frozen_review'}
ENV='0df444a360eaa60ab8c11dca51a86af692955474'; MISSION='eeb5193f-68c0-41d0-9263-4a5ff7c801ee'; ROOT='e33ff731-60a7-43ef-87ae-c12aeba23cb5'
def need(v,m):
 if not v:raise ValueError(m)
def read(p):return json.loads(Path(p).read_text())
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n")
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):return {'path':str(Path(p).resolve()),'sha256':sha(p)}
def save(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def checked(v):need(sha(v['path'])==v['sha256'],'Changed pin '+v['path']);return Path(v['path'])
def strings(v):
 if isinstance(v,str):return [v]
 if isinstance(v,list):return [s for x in v for s in strings(x)]
 if isinstance(v,dict):return [s for x in v.values() for s in strings(x)]
 return []
def receipt(p):
 r=read(p);need(r['status']=='succeeded' and r['result']['exit_code']==0,'Actual successful receipt required '+str(p))
 need(r['request']['workspace']==str(W) and r['request']['exclusive'] is True,'Actual exclusive workspace required')
 return r

def validate_report(actual,report_path):
 r=receipt(actual); report=read(report_path)
 need(r['request']['parameters']['source']=='.local/adaptation/c2-complete-inputs-20261116/AuditC2Final44WithExactlyTwoValueCertificates.lean','Use original unmodified full44 query')
 cfgpath=r['request']['environment']['PACKAGE_IDENTITY_AUDIT_CONFIG']; cfg=read(cfgpath)
 need(Path(cfg['outputFile']).resolve()==Path(report_path).resolve() and report['configuration']==cfg,'Receipt/report/configuration binding differs')
 need(report['comparedRecordCount']==report['sourceGeneratedClosureCount']==44 and report['targetGeneratedClosureCount']==46,'Actual44/46 coverage differs')
 need(not report['hasSorryAx'] and report['unresolvedTargetNames']==[] and report['dataValueSubstitutions']==[] and report['compatibilitySubstitutions']==[],'Actual identity or axiom gate failed')
 need(report['sourceBackedWholeValueEqualityCertificateCount']==2 and report['rawNamespacePrefixIdentity'] is False and report['rawAllComputationalValueBinderInfoEqual'] is False,'Retain actual two certificates and raw differences')
 oldcfg=read(C/'final44-two-value-config-v5.json')
 need({k:v for k,v in cfg.items() if k!='outputFile'}=={k:v for k,v in oldcfg.items() if k!='outputFile'},'This metadata binder requires original mathematical44 config')
 manifest=r['request']['worktree_manifest']; hashes=manifest.get('input_hashes',{})
 for p in [W/TARGET,Path(cfgpath),C/'AuditC2Final44WithExactlyTwoValueCertificates.lean']:
  need(hashes.get(str(p))==sha(p),'Current full44 receipt must pin actual source/query/config '+str(p))
 for path,digest in hashes.items():
  if path.startswith(str(W/'Definitions')) or path.startswith(str(W/'.lake/build/lib/lean/Definitions')):
   need(sha(path)==digest,'Current full44 native input differs '+path)
 for row in report['comparisons']:
  for gate in ['completeStructureMetadataEqual','computationShapeEqual','expandedOriginalTypeKernelEqual','instanceRegistryMatchesAcceptedGraph','sourceSignatureBinderInfoSerializationValidated']:
   need(row[gate],'Actual44 inner gate failed '+row['original']+' '+gate)
  if row['computationalValueEqualityChecked'] and row['original'] not in ['Iut.ThetaDataExistence.casesOn','Iut.ThetaDataExistence.recOn']:need(row['kernelValueEqual'],'Strict computational value gate failed '+row['original'])
  need(row['kernelTypeEqual'] and row['sourceTargetSignatureBinderInfoInventoryEqual'] and row['sourceTargetSignatureBinderInfoPlacementEqual'] and row['sourceAxiomInventoryMatchesAcceptedGraph'],'Failed actual public comparison '+row['original'])
  if row['original'] in ['Iut.ThetaDataExistence.casesOn','Iut.ThetaDataExistence.recOn']:
   need(row['kernelPropositionalValueEquality'] and row['computationalValueEqualityChecked'] and row['allExpressionBinderInfoEqual'] is False and row['rawComputationalValueBinderInventoryEqual'] is False and row['rawComputationalValueBinderPlacementEqual'] is False,'Exact whole-function certificate or retained raw difference failed')
  else:need(row['allExpressionBinderInfoEqual'] and row['binderInfoPlacementEqual'],'Strict BinderInfo gate failed '+row['original'])
  if row['original'] in ['Iut.ThetaDataExistence.casesOn','Iut.ThetaDataExistence.recOn']:
   eq=row['propositionalValueEqualityEvidence']
   need(all(eq[k] for k in ['kernelCheckedExactCompleteValueEqualityProof','sourceValueUnmodified','targetValueUnmodified','allProofAndWholeValueDependenciesHaveAllowedOwners']) and eq['dataValueSubstitutions']==[] and eq['newAliases']==[],'Complete function equality recheck failed')
 for row in report['targetAxiomAudits']:
  need(not row['hasSorryAx'] and set(row['axioms'])<= {'propext','Classical.choice','Quot.sound'},'Nonstandard actual axiom')
 extra=report['sourceBackedTargetOnlyGeneratedProofs'];need(len(extra)==2,'Keep two target-only source-backed compiler proofs')
 for x in extra:need(x['kernelTypeEqual'] and x['axiomClosuresEqual'] and x['signatureBinderInfoEqual'] and not x['dataValueSubstitution'],'Generated proof mismatch')
 return r,report,cfgpath

def bind(args):
 out=args.out;need(not out.exists(),'Use a fresh output directory to preserve journals')
 r,report,cfgpath=validate_report(args.actual_receipt,args.report)
 leaf,artifact=receipt(args.leaf_receipt),receipt(args.artifact_receipt)
 for rr in [leaf,artifact]:
  pp=rr['request']['parameters']; src=pp.get('source',pp.get('args',[None])[0]);need(src==TARGET,'C22 leaf/artifact target differs')
  need(rr['request']['worktree_manifest']['source_sha256']==sha(W/TARGET),'C22 leaf/artifact source pin differs')
 # Reuse already accepted production audit only after checking every current input pin.
 reuse=read(args.production_reuse);checked(reuse['productionReceipt']); production=receipt(reuse['productionReceipt']['path'])
 for x in reuse['productionPinnedInputs']:need(x['sha256']==x['expectedFromReceipt'],'Production history pin differs');checked(x)
 frozen=read(O/'metadata-rebind-plan.json')['frozenMaterials']
 for x in frozen:checked(x)
 tri=read(frozen[0]['path']); blind=read(frozen[1]['path']); supplement=read(frozen[2]['path']); paper=read(frozen[3]['path'])
 candidate=Path(next(x['path'] for x in blind['inputs'] if x['role']=='candidate' and 'Corollary22' in x['path']))
 need(candidate.read_text().replace('end Corollary22Inputs\n\nend Iut','end Corollary22Inputs\n\nattribute [local congr] Corollary22Inputs.localData.congr_simp\n\nend Iut')==(W/TARGET).read_text(),'Frozen candidate differs beyond the previously accepted local congr attribute')
 selected=[x for x in tri['declarations'] if '.Iut.' in x['name']]
 need(len(selected)==3,'Keep exactly the three C22 mathematical roots')
 original={x['name']:x for x in blind['declarations']}
 for x in selected:need(x['original_en']==original[x['name']],'Frozen English object changed')
 rb={'en':'\n\n'.join('\n'.join(strings(x['original_en'])) for x in selected)}
 rb.update({lang:'\n\n'.join(x['name']+'\n'+x['readbacks'][lang] for x in selected) for lang in ['zh-Hans','ja']})
 context='\n\n'.join(strings({k:tri[k] for k in ['shared_context','witness_and_bound_context','edge_cases_and_logical_limits','missing_or_unverified_formal_context']}))
 paper_text='\n\n'.join(strings(next(x for x in paper if x['declaration']=='Iut.ThetaDataExistence')))
 statement='\n\n'.join(['**Formal-code readback (English)**',rb['en'],'**形式代码读回（简体中文）**',rb['zh-Hans'],'**形式コードの読解（日本語）**',rb['ja'],context,'**Compiled-types supplement**','\n\n'.join(strings(supplement)),'**Paper source context**',paper_text])
 payload={'definition_name':NAME,'definition_title':'Iut.Implication.Corollary22 — complete inputs, P7, and threshold','definition':(W/TARGET).read_text(),'natural_language_statement':statement,'source':'https://github.com/lana-agents/iut/blob/07cb1da58f6d428a670dbb5dd6093d428bcbcdd8/Iut/Implication/Corollary22.lean','env':ENV,'private':True}
 source=(W/TARGET).read_text()
 imports=re.findall(r'^import (Definitions\.\S+)',source,re.M);names=[x.removeprefix('Definitions.Def_') for x in imports]
 registry=read(args.registry)['reference_source_preparation']['definitions'];ids={x['name']:x['id'] for x in registry}
 supplied={}
 for p in args.published_readback:
  x=read(p);need(x['definition_name'] not in supplied,'Duplicate parent readback');supplied[x['definition_name']]=x
 scope=args.scope_directory; parents=[];scopefiles=[scope/'mission-list-readback.json',scope/'mission-root-readback.json']
 listing,root=map(read,scopefiles);mission=next(x for x in listing['missions'] if x['id']==MISSION)
 need(mission['visibility']=='private' and mission['main_theorem']['theorem_id']==ROOT and root['visibility']=='private' and root['mathlib_rev']==ENV,'Existing mission scope differs')
 for name in names:
  p=scope/('parent-'+name+'.json');item=read(p);id=ids.get(name)
  if name in supplied:need(not id or id==supplied[name]['definition_id'],'Registry/readback conflict');id=supplied[name]['definition_id']
  current=W/'Definitions'/('Def_'+name+'.lean')
  need(id and item['definition_id']==id and item['definition_name']==name and item['visibility']=='private' and item['mathlib_rev']==ENV and item['deprecated_at'] is None,'Actual parent scope differs '+name)
  need(hashlib.sha256(item['definition'].encode()).hexdigest()==sha(current),'Parent complete source mismatch '+name)
  parents.append({'definitionName':name,'registryEvidence':{'name':name,'id':id,'status':'PUBLISHED'},'currentDefinition':pin(current),'savedPublicationEvidence':{'registry':pin(args.registry),'publishedReadback':pin(p)}});scopefiles.append(p)
 diff=read(args.git_diff_check);need(diff.get('passed') is True or diff.get('exit_code')==0,'Actual diff check required')
 dossier=read(args.main5_dossier);need(dossier['currentSelected173LocalSourceEvidenceComplete'],'Current main5 actual dossier required')
 # Derive coverage directly from the actual source report. Own named proof declarations remain named.
 coverage={'source':report['sourceGeneratedClosureCount'],'resolved':len(report['comparisons']),'named':len(report['comparisons']),'proof':0,'standard_proof':0,'source_proof_standalone_aliases':0}
 upstream=read(O/'metadata-rebind-plan.json')['upstreamFourSourceProofRoots']
 for x in upstream:checked(x['acceptedUpstreamDossier'])
 profile={'definitionName':NAME,'target':TARGET,'sourceSha256':sha(W/TARGET),'requiredKernelCoverage':coverage,'requiredOwnedCount':report['targetGeneratedClosureCount'],'directImportedDefinitions':names,'sourceBackedTargetOnlyGeneratedProofs':report['sourceBackedTargetOnlyGeneratedProofs'],'exactSourceGeneratedProofRename':report['sourceBackedGeneratedProofRename'],'source44NamedNames':[x['original'] for x in report['comparisons']]}
 out.mkdir(parents=True)
 shutil.copyfile(O/'publisher-template.py',out/'publisher.py')
 shutil.copyfile(W/TARGET,out/'Definition.lean')
 save(out/'module-profile.json',profile);save(out/'payload.json',payload);save(out/'readback.json',rb)
 save(out/'source-ledger.final.json',{'actualReceipt':pin(args.actual_receipt),'actualReport':pin(args.report),'actualConfiguration':pin(cfgpath),'sourceExport':pin(C/'source-original-exprs.json'),'originalConsumers':pin(C/'identity-handoff/actual-ast-closure-plan.json'),'historicalMappingEvidence':pin(C/'identity-handoff/dependency-map-evidence.json'),'currentMain5Dossier':pin(args.main5_dossier),'upstreamFourSourceProofRoots':upstream,'c2TheoremAccepted':False,'act2ConstructionClosed':False})
 save(out/'final-frozen-review.json',{'passed':True,'scope':'Existing frozen readback and quotation preservation, current whole44 identity, metadata-only publication binding','frozenMaterials':frozen,'readbackToCurrentSourceDelta':'only accepted local congr attribute; no declaration text changes','actual44Receipt':pin(args.actual_receipt),'actual44Report':pin(args.report)})
 pins=[args.actual_receipt,args.report,Path(cfgpath),args.leaf_receipt,args.artifact_receipt,args.production_reuse,Path(reuse['productionReceipt']['path']),args.registry,args.git_diff_check,args.main5_dossier,O/'metadata-rebind-plan.json',TEMPLATE,Path(__file__),O/'publisher-template.py',candidate]+scopefiles+[Path(x['path']) for x in frozen]+[Path(x['acceptedUpstreamDossier']['path']) for x in upstream]+[checked(x) for x in reuse['productionPinnedInputs']]+[Path(x['currentDefinition']['path']) for x in parents]+list(out.iterdir())
 hashes={str(p.resolve()):sha(p) for p in pins}
 packet={'kernel_coverage':coverage,'required_owned_count':profile['requiredOwnedCount'],'schema':'c22-input44-one-definition-private-delivery/v1','workspace':str(W),'mission_id':MISSION,'root_id':ROOT,'environment':ENV,'visibility':'private','root_graph_membership':False,'publication_post_limit':1,'verification':[],'publicationReady':True,'source_sha256':{TARGET:sha(W/TARGET)},'metadata_sha256':hashes,'parent_foundation_definitions':parents,'pending_parent_bindings':[],'publications':[{'tag':NAME,'endpoint':'/submit-definition','payload':payload}],'source_proof_values':[],'source_proof_standalone_aliases':[],'sourceBackedTargetOnlyGeneratedProofs':report['sourceBackedTargetOnlyGeneratedProofs'],'upstreamFourSourceProofRoots':upstream,'actualCurrent44Receipt':pin(args.actual_receipt),'actualCurrent44Report':pin(args.report),'act2ConstructionClosed':False}
 save(out/'packet.json',packet)
 ci={'new_leaf_modules':[str(args.leaf_receipt)],'new_leaf_artifacts':[str(args.artifact_receipt)],'checks_axioms':[str(args.actual_receipt)],'wrapped_kernel_type_identity':[str(args.actual_receipt)],'import_audit':[reuse['productionReceipt']['path']],'act1scene1':[reuse['productionReceipt']['path']],'axiom_audit':[reuse['productionReceipt']['path'],str(args.actual_receipt)]}
 ready={'schema':'c22-existing-twelve-gates-ready/v1','passed':True,'kernel_coverage':coverage,'packet_sha256':sha(out/'packet.json'),'source_sha256':packet['source_sha256'],'gates':{g:True for g in GATES},'ci_receipts':ci,'gate_evidence':{'independent_readbacks':[x['path'] for x in frozen[:3]],'source_ledger_consumers':[str(out/'source-ledger.final.json')],'git_diff_check':[str(args.git_diff_check)],'existing_mission_scope':[str(p) for p in scopefiles],'final_frozen_review':[str(out/'final-frozen-review.json')]},'evidence_sha256':hashes,'axiom_audit':{'sorryAx_found':False,'unexpected_axioms':[]},'pending':[],'pending_bindings':{}}
 save(out/'ready.final.json',ready)
 spec=importlib.util.spec_from_file_location('c22_bound_publisher',out/'publisher.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.check(out/'packet.json',out/'ready.final.json')
 return {'packet':pin(out/'packet.json'),'ready':pin(out/'ready.final.json'),'publicationPOSTPerformed':False}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 for n in ['actual-receipt','report','leaf-receipt','artifact-receipt','scope-directory','git-diff-check','out']:p.add_argument('--'+n,type=Path,required=True)
 p.add_argument('--production-reuse',type=Path,default=Path('/tmp/p2m-local-basic-ready-bind-v31-20261116/Basic-production-gate-reuse.json'))
 p.add_argument('--main5-dossier',type=Path,default=A/'main5-local-dossier-v27-20261116/main5-local-source-relative-dossier.json')
 p.add_argument('--registry',type=Path,default=A/'platform-node-registry.json');p.add_argument('--published-readback',type=Path,action='append',default=[])
 print(json.dumps(bind(p.parse_args()),ensure_ascii=False,indent=2))
