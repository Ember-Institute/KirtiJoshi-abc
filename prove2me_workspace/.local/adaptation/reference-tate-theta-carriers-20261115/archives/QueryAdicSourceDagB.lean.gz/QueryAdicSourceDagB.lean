import Lean
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace
import Mathlib.RingTheory.Ideal.Quotient.HasFiniteQuotients

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

-- Insert inside namespace FoundationAudit, after checked and the existing
-- Name/Level/Binder codecs. Roots must already be metadata-erased.

structure ExprDagEncoder where
  nodes : Array Json := #[]
  index : Lean.ExprStructMap Nat := {}
  deriving Inhabited

abbrev ExprDagM := StateT ExprDagEncoder MetaM

/-- Intern by Expr.equal, which preserves binder Names and BinderInfo. -/
partial def addExpr (e : Expr) : ExprDagM Nat := do
  let initial ← get
  if let some ref := initial.index[(⟨e⟩ : ExprStructEq)]? then
    return ref
  let payload : Json ← match e with
    | .bvar i => pure (node "bvar" [("index", toJson i)])
    | .sort u => do
        let encoded ← liftM (checked (encodeLevel u))
        pure (node "sort" [("level", encoded)])
    | .const n us => do
        let levels ← liftM (checked (us.toArray.mapM encodeLevel))
        pure (node "const" [("name", encodeName n), ("levels", Json.arr levels)])
    | .app f a => do
        let fnRef ← addExpr f
        let argRef ← addExpr a
        pure (node "app" [("fn", toJson fnRef), ("arg", toJson argRef)])
    | .lam n t b bi => do
        let typeRef ← addExpr t
        let bodyRef ← addExpr b
        pure (node "lam" [("name", encodeName n), ("type", toJson typeRef),
          ("body", toJson bodyRef), ("binder", toJson (encodeBinder bi))])
    | .forallE n t b bi => do
        let typeRef ← addExpr t
        let bodyRef ← addExpr b
        pure (node "forall" [("name", encodeName n), ("type", toJson typeRef),
          ("body", toJson bodyRef), ("binder", toJson (encodeBinder bi))])
    | .letE n t v b nd => do
        let typeRef ← addExpr t
        let valueRef ← addExpr v
        let bodyRef ← addExpr b
        pure (node "let" [("name", encodeName n), ("type", toJson typeRef),
          ("value", toJson valueRef), ("body", toJson bodyRef), ("nondependent", toJson nd)])
    | .lit (.natVal n) => pure (node "nat" [("value", toJson n)])
    | .lit (.strVal s) => pure (node "string" [("value", toJson s)])
    | .proj n i b => do
        let bodyRef ← addExpr b
        pure (node "proj" [("name", encodeName n), ("index", toJson i), ("body", toJson bodyRef)])
    | .mdata _ _ => throwError "Expr DAG requires metadata-erased roots; metadata was not discarded"
    | .fvar _ => throwError "Free variable in Expr DAG input"
    | .mvar _ => throwError "Expression metavariable in Expr DAG input"
  let current ← get
  let ref := current.nodes.size
  set { current with nodes := current.nodes.push payload,
                     index := current.index.insert (⟨e⟩ : ExprStructEq) ref }
  return ref

/-- A child must refer to an already decoded node, never itself or a future node. -/
def exprDagChild (earlier : Array Expr) (entry : Json) (key : String) : Except String Expr := do
  let ref ← (← field entry key).getNat?
  match earlier[ref]? with
  | some e => pure e
  | none => throw s!"Expr DAG {key} reference {ref} is not earlier than node {earlier.size}"

/-- Decode one node using only the completed topological prefix. -/
def decodeExprDagNode (earlier : Array Expr) (entry : Json) : Except String Expr := do
  match ← stringField entry "kind" with
  | "bvar" => return .bvar (← (← field entry "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field entry "level"))
  | "const" =>
      let levels ← (← arrayField entry "levels").mapM decodeLevel
      return .const (← decodeName (← field entry "name")) levels.toList
  | "app" => return .app (← exprDagChild earlier entry "fn") (← exprDagChild earlier entry "arg")
  | "lam" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let body ← exprDagChild earlier entry "body"
      let binder ← decodeBinder (← stringField entry "binder")
      return .lam binderName ty body binder
  | "forall" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let body ← exprDagChild earlier entry "body"
      let binder ← decodeBinder (← stringField entry "binder")
      return .forallE binderName ty body binder
  | "let" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let value ← exprDagChild earlier entry "value"
      let body ← exprDagChild earlier entry "body"
      let nondependent ← (← field entry "nondependent").getBool?
      return .letE binderName ty value body nondependent
  | "nat" => return .lit (.natVal (← (← field entry "value").getNat?))
  | "string" => return .lit (.strVal (← (← field entry "value").getStr?))
  | "proj" =>
      let projectionName ← decodeName (← field entry "name")
      let index ← (← field entry "index").getNat?
      let body ← exprDagChild earlier entry "body"
      return .proj projectionName index body
  | other => throw s!"Unsupported Expr DAG node kind: {other}"

/-- Build the shared Expr table once and validate every declared root reference. -/
def decodeExprDag (dag : Json) : Except String (Array Expr) := do
  unless (← stringField dag "schema") == "foundation-expr-dag-v1" do
    throw "Unexpected Expr DAG schema"
  let entries ← arrayField dag "nodes"
  let mut decoded : Array Expr := #[]
  for entry in entries do
    decoded := decoded.push (← decodeExprDagNode decoded entry)
  for root in ← arrayField dag "roots" do
    let ref ← root.getNat?
    unless ref < decoded.size do
      throw s!"Expr DAG root reference {ref} is outside {decoded.size} nodes"
  return decoded

/-- Finalize only after one strict round trip for every original root. -/
def finishExprDag (encoder : ExprDagEncoder) (rootRefs : Array Nat)
    (originalRoots : Array Expr) : MetaM Json := do
  unless rootRefs.size == originalRoots.size do
    throwError "Expr DAG root references and original roots differ in count"
  let dag := Json.mkObj [("schema", toJson "foundation-expr-dag-v1"),
    ("nodes", Json.arr encoder.nodes), ("roots", toJson rootRefs)]
  let decoded ← checked (decodeExprDag dag)
  for i in [:rootRefs.size] do
    let ref := rootRefs[i]!
    let some actual := decoded[ref]? | throwError "Expr DAG root {i} is absent"
    unless Expr.equal originalRoots[i]! actual do
      throwError "Expr DAG strict Expr.equal round trip failed at root {i} (node {ref})"
  return dag

end FoundationAudit

namespace AdicCompletionPlatformFacts
open Lean Elab Term Meta FoundationAudit

def actualFacts (cache : AxiomCache) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  let value := ci.value? (allowOpaque := true)
  let axs ← cachedAxioms cache name
  let taxs ← expressionAxioms cache ci.type
  let vaxs ← match value with
    | none => pure #[] | some expr => expressionAxioms cache expr
  let shape ← match getStructureInfo? (← getEnv) name with
    | none => pure Json.null
    | some info => checked (structureShape info pure)
  let ruleRhs ← match ci with
    | .recInfo info => info.rules.toArray.mapM fun rule => checked (encodeExpr rule.rhs)
    | _ => pure #[]
  return Json.mkObj [
    ("name", toJson name.toString), ("nameExpr", encodeName name),
    ("module", match moduleOf (← getEnv) name with
      | none => Json.null | some owner => toJson owner.toString),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("valueExpr", ← match value with | none => pure Json.null | some expr => checked (encodeExpr expr)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("isProposition", toJson (← isProp ci.type)),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name)),
    ("isClass", toJson (Lean.isClass (← getEnv) name)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("typeUsedConstants", Json.arr (ci.type.getUsedConstants.map encodeName)),
    ("valueUsedConstants", Json.arr (match value with
      | none => #[] | some expr => expr.getUsedConstants.map encodeName)),
    ("computationShape", ← checked (computationShape ci pure)),
    ("recursorRuleRhs", Json.arr ruleRhs), ("structure", shape),
    ("hasSorryAx", toJson (axs.contains `sorryAx))]


partial def decodeExpandedExpr (entries : Array (Name × (List Name × Expr))) (j : Json) : Except String Expr := do
  let recur := decodeExpandedExpr entries
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let name ← decodeName (← field j "name")
    let levels ← (← arrayField j "levels").mapM decodeLevel
    if let some entry := entries.find? (·.1 == name) then
      unless levels.size == entry.2.1.length do throw "Original data closure universe arity differs"
      return entry.2.2.instantiateLevelParams entry.2.1 levels.toList
    return .const name levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← decodeName (← field j "name")) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | kind => throw s!"Unknown standard Expr kind {kind}"

def checkKernel (label : String) (expr : Expr) : MetaM Expr := do
  if expr.hasMVar || expr.hasFVar || expr.hasLooseBVars then throwError "Open query expression: {label}"
  match Kernel.check (← getEnv) {} expr with
  | .ok type => pure type | .error ex => throwKernelException ex

def checkExactType (label : String) (inferred expected : Expr) : MetaM Unit := do
  for type in #[inferred, expected] do
    match ← checkKernel label type with
    | .sort _ => pure () | _ => throwError "Expected a checked type: {label}"
  match Kernel.isDefEq (← getEnv) {} inferred expected with
  | .ok true => pure ()
  | .ok false => throwError "Query proof does not inhabit exact source type: {label}"
  | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]


def query : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected platform compiler4.33.1"
  let source ← jsonFile (← absoluteEnv "NEXT_CARRIER_ADIC_SOURCE_FACTS")
  unless (← checked (stringField source "schema")) == "tate-theta-adic-completion-original-facts-v1" do
    throwError "Expected actual original adic-completion data facts"
  let env ← getEnv
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let support ← jsonFile (← absoluteEnv "NEXT_CARRIER_ADIC_SUPPORT_SOURCE_FACTS")
  unless (← checked (stringField support "schema")) == "tate-theta-adic-completion-support-original-facts-v1" do
    throwError "Expected actual original adic support/absolute-norm facts"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field source key)) == (← checked (field support key)) do
      throwError "Original adic/support provenance differs: {key}"
  let helper ← jsonFile (← absoluteEnv "NEXT_CARRIER_ADIC_HELPER_SOURCE_FACTS")
  unless (← checked (stringField helper "schema")) == "tate-theta-adic-two-helper-original-facts-v1" do
    throwError "Expected the two actual source helper body records"
  let candidates := (← checked (arrayField source "facts")) ++ (← checked (arrayField support "facts")) ++ (← checked (arrayField helper "facts"))
  let candidateNames ← candidates.mapM fun row => do
    checked (decodeName (← checked (field row "nameExpr")))
  unless candidates.size == 50 && candidateNames.toList.eraseDups.length == 50 do
    throwError "Expected all50 archived actual original candidates"
  let cardPowRows := candidates.filter fun row =>
    (stringField row "name").toOption == some "cardQuot_pow_of_prime"
  unless cardPowRows.size == 1 do throwError "Expected one actual cardQuot power theorem record"
  let cardPowName ← checked (decodeName (← checked (field cardPowRows[0]! "nameExpr")))
  let mut requiredQueue := (← namesFromJson (← checked (field source "roots"))).toArray
  requiredQueue := requiredQueue ++ (← namesFromJson (← checked (field support "absNormRoots"))).toArray
  requiredQueue := requiredQueue ++ (← namesFromJson (← checked (field support "exactSupportNames"))).toArray
  let mut closureNames : Array Name := #[]
  let mut position := 0
  while position < requiredQueue.size do
    let name := requiredQueue[position]!
    position := position + 1
    if closureNames.contains name then continue
    closureNames := closureNames.push name
    let rows := candidates.filter fun row => (field row "nameExpr").toOption == some (encodeName name)
    unless rows.size == 1 do throwError "Required original candidate record missing: {name}"
    let typeDeps ← namesFromJson (← checked (field rows[0]! "typeUsedConstants"))
    let bodyDeps ← if name == cardPowName then pure [] else namesFromJson (← checked (field rows[0]! "valueUsedConstants"))
    for used in typeDeps ++ bodyDeps do
      if candidateNames.contains used && !requiredQueue.contains used then requiredQueue := requiredQueue.push used
  let allRecords := candidates.filter fun row =>
    ((field row "nameExpr").toOption.map fun j => (decodeName j).toOption.any closureNames.contains).getD false
  let unusedCandidates := candidateNames.filter fun name => !closureNames.contains name
  unless closureNames.size == 35 do throwError "Expected the exact35 active source records"
  let finitePlaceNames ← (← checked (arrayField source "facts")).mapM fun row => do
    checked (decodeName (← checked (field row "nameExpr")))
  let stage := "finite-place"
  let stageNames := closureNames.filter fun name =>
    if stage == "absnorm-support" then !finitePlaceNames.contains name else finitePlaceNames.contains name
  unless stageNames.size == (if stage == "absnorm-support" then 19 else 16) do
    throwError "Wrong exact A19/B16 source partition"
  let records := allRecords.filter fun row =>
    ((field row "nameExpr").toOption.map fun j => (decodeName j).toOption.any stageNames.contains).getD false
  let mut missingUsed : Array Name := #[]
  let allUsed := (← checked (arrayField source "usedStandardNames")) ++ (← checked (arrayField support "usedStandardNames")) ++ (← checked (arrayField helper "usedStandardNames"))
  for row in allUsed do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    unless env.contains name || missingUsed.contains name do missingUsed := missingUsed.push name
  -- Reuse only the exact standard proposition-valued proof already accepted by
  -- the v4 installer. No native data value is used as an expansion.
  let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
  let compatibility ← checked (field config "standardProofCompatibility")
  let evidence ← checked (field compatibility "evidence")
  let sourceBinding ← checked (field evidence "sourceFacts")
  let originalStandardFacts ← checked (field sourceBinding "contents")
  let platformBinding ← checked (field evidence "platformFacts")
  let nativeStandardFacts ← checked (field platformBinding "contents")
  let standardName := `NumberField.RingOfIntegers.instHasFiniteQuotients
  let sourceRows := (← checked (arrayField originalStandardFacts "facts")).filter fun row =>
    (stringField row "name").toOption == some standardName.toString
  unless sourceRows.size == 1 do throwError "Missing exact already accepted standard source proof"
  let sourceRecord := sourceRows[0]!
  let params ← namesFromJson (← checked (field sourceRecord "levelParams"))
  let nativeParams ← namesFromJson (← checked (field compatibility "nativeLevelParams"))
  unless params.length == 1 && nativeParams == [Name.num (Name.str .anonymous "_finiteQuotientsQueryUniverse") 0] do
    throwError "Changed exact accepted standard proof universe restoration"
  let native ← checked (field nativeStandardFacts "nativeProofAttempt")
  let originalType ← checked (decodeExpandedExpr #[] (← checked (field sourceRecord "elaboratedExpr")))
  let nativeType ← checked (decodeExpandedExpr #[] (← checked (field native "type")))
  let nativeValue ← checked (decodeExpandedExpr #[] (← checked (field native "value")))
  let restoredType := nativeType.instantiateLevelParams nativeParams (params.map Level.param)
  let standardValue := nativeValue.instantiateLevelParams nativeParams (params.map Level.param)
  checkExactType "accepted standard seed universe/type" restoredType originalType
  checkExactType "accepted standard seed proof" (← checkKernel "accepted standard seed proof" standardValue) originalType
  unless (← isProp originalType) do throwError "Accepted standard seed is not a proof"
  let standardAxs ← expressionAxioms cache standardValue
  ensureStandard "accepted standard proof seed" standardAxs
  let standardSeed := Json.mkObj [
    ("name", toJson standardName.toString), ("nameExpr", encodeName standardName),
    ("kind", toJson "exact previously checked proposition-valued native proof"),
    ("kernelCheckedExactSourceType", toJson true),
    ("nativeUniversesRestoredToOriginal", toJson true),
    ("axioms", toJson (standardAxs.map Name.toString))]
  let mut entries : Array (Name × (List Name × Expr)) := #[(standardName, (params, standardValue))]
  let mut encoder : ExprDagEncoder := {}
  let mut rootRefs : Array Nat := #[]
  let mut originalRoots : Array Expr := #[]
  let mut serializedEntries : Array Json := #[]
  let seedPair : ExprDagM (Nat × Nat) := do
    let typeRoot ← addExpr originalType
    let valueRoot ← addExpr standardValue
    return (typeRoot, valueRoot)
  let ((seedTypeRoot, seedValueRoot), seedEncoder) ← seedPair.run encoder
  encoder := seedEncoder
  rootRefs := (rootRefs.push seedTypeRoot).push seedValueRoot
  originalRoots := (originalRoots.push originalType).push standardValue
  serializedEntries := serializedEntries.push (Json.mkObj [
    ("name", toJson standardName.toString), ("nameExpr", encodeName standardName),
    ("levelParams", Json.arr (params.toArray.map encodeName)),
    ("typeRoot", toJson seedTypeRoot), ("valueRoot", toJson seedValueRoot),
    ("resolution", toJson "known-standard-native-proof"), ("isProposition", toJson true)])
  if stage == "finite-place" then
    let bindingA ← jsonFile (← absoluteEnv "NEXT_CARRIER_ADIC_DAG_A_BINDING")
    unless (← checked (stringField bindingA "schema")) == "tate-theta-adic-dag-a-actual-binding-v1" &&
        (← checked (stringField bindingA "job_id")) == "ci-014497-4264b653" do
      throwError "Expected the exact accepted A artifact binding"
    let outputBindingA ← checked (field bindingA "output")
    let receiptBindingA ← checked (field bindingA "receipt")
    let sourceBindingA ← checked (field bindingA "source")
    let inputA ← jsonFile (← checked (stringField outputBindingA "path"))
    let receiptA ← jsonFile (← checked (stringField receiptBindingA "path"))
    unless inputA == (← checked (field outputBindingA "contents")) &&
        receiptA == (← checked (field receiptBindingA "contents")) &&
        (← checked (stringField outputBindingA "sha256")).length == 64 &&
        (← checked (stringField receiptBindingA "sha256")).length == 64 &&
        (← checked (stringField receiptA "job_id")) == "ci-014497-4264b653" do
      throwError "Exact accepted A output/receipt contents changed after binding"
    let requestA ← checked (field receiptA "request")
    let manifestA ← checked (field requestA "worktree_manifest")
    unless (← checked (requestA.getObjValAs? Bool "exclusive")) &&
        (← checked (stringField manifestA "source_sha256")) == (← checked (stringField sourceBindingA "sha256")) do
      throwError "Exact accepted A source/exclusive request binding differs"
    unless (← checked (stringField inputA "schema")) == "tate-theta-adic-split-expr-dag-v1" &&
        (← checked (stringField inputA "stage")) == "absnorm-support" &&
        (← checked (stringField receiptA "status")) == "succeeded" do
      throwError "Expected actual successful A DAG and receipt"
    let resultA ← checked (field receiptA "result")
    unless (← checked (resultA.getObjValAs? Nat "exit_code")) == 0 do throwError "A did not exit zero"
    let snapshotA ← checked (field resultA "snapshot")
    unless (← checked (stringField snapshotA "workspace_mode")) == "exclusive_worktree" && (← checked (field snapshotA "snapshot_id")) == Json.null do
      throwError "Exact accepted A workspace mode differs"
    let resourceA ← checked (field receiptA "resources")
    let peakA ← checked (resourceA.getObjValAs? Nat "peak_rss_bytes")
    unless peakA ≤ 17179869184 do throwError "A exceeds16GiB and is not an admissible dependency"
    let decodedA ← checked (decodeExprDag (← checked (field inputA "exprDag")))
    let rowsA ← checked (arrayField inputA "entries")
    unless rowsA.size == 20 do throwError "Expected A19 plus known standard proof dependency"
    let namesA ← rowsA.mapM fun row => do
      checked (decodeName (← checked (field row "nameExpr")))
    let expectedNamesA := #[standardName] ++ (closureNames.filter fun name => !stageNames.contains name)
    unless namesA.toList.eraseDups.length == 20 && namesA.size == expectedNamesA.size && expectedNamesA.all namesA.contains do
      throwError "Exact accepted A declaration set is not Ring plus the full19 support nodes"
    for row in rowsA do
      let name ← checked (decodeName (← checked (field row "nameExpr")))
      let inheritedParams ← namesFromJson (← checked (field row "levelParams"))
      let typeRef ← checked ((← checked (field row "typeRoot")).getNat?)
      let valueRef ← checked ((← checked (field row "valueRoot")).getNat?)
      let some inheritedType := decodedA[typeRef]? | throwError "A type reference missing"
      let some inheritedValue := decodedA[valueRef]? | throwError "A value reference missing"
      checkExactType "complete A dependency type/value" (← checkKernel "complete A dependency value" inheritedValue) inheritedType
      let inheritedAxs ← expressionAxioms cache inheritedValue
      ensureStandard "complete A dependency" inheritedAxs
      if name == standardName then
        unless inheritedParams == params do throwError "A known standard proof universe parameters changed"
        unless Expr.equal inheritedType originalType && Expr.equal inheritedValue standardValue do
          throwError "A known standard proof differs from the exact checked seed"
      else
        unless closureNames.contains name && !stageNames.contains name && !(entries.any (·.1 == name)) do
          throwError "A dependency is duplicated or outside exact support partition: {name}"
        let sourceRows := allRecords.filter fun record => (field record "nameExpr").toOption == some (encodeName name)
        unless sourceRows.size == 1 do throwError "A original body recipe missing: {name}"
        let recipe := sourceRows[0]!
        let expectedParams ← namesFromJson (← checked (field recipe "levelParams"))
        unless inheritedParams == expectedParams do throwError "A original universe parameters/order changed: {name}"
        let expectedType ← checked (decodeExpandedExpr entries (← checked (field recipe "elaboratedExpr")))
        let expectedValue ← if name == cardPowName then pure (Lean.mkConst name (inheritedParams.map Level.param))
          else checked (decodeExpandedExpr entries (← checked (field recipe "valueExpr")))
        unless Expr.equal inheritedType expectedType && Expr.equal inheritedValue expectedValue do
          throwError "A dependency DAG does not preserve its complete original/native proof recipe: {name}"
        entries := entries.push (name, (inheritedParams, inheritedValue))
  let mut nativeOverrides : Array Json := #[standardSeed]
  if stage == "finite-place" then
    nativeOverrides := nativeOverrides.push (Json.mkObj [("name", toJson cardPowName.toString),
      ("kind", toJson "inherited A exact original-type native theorem proof")])
  let mut attempts : Array Json := #[]
  let mut processed : Array Name := #[]
  let mut progress := true
  while progress do
    progress := false
    for record in records do
      let name ← checked (decodeName (← checked (field record "nameExpr")))
      if processed.contains name then continue
      let typeUsed ← namesFromJson (← checked (field record "typeUsedConstants"))
      let valueUsed ← if name == cardPowName then pure [] else namesFromJson (← checked (field record "valueUsedConstants"))
      let needed := (typeUsed ++ valueUsed).toArray.filter fun used => used != name && closureNames.contains used
      unless needed.all (fun used => entries.any (·.1 == used)) do continue
      processed := processed.push name
      progress := true
      let result ← try
        let params ← namesFromJson (← checked (field record "levelParams"))
        let type ← checked (decodeExpandedExpr entries (← checked (field record "elaboratedExpr")))
        let nativeOverride := name == cardPowName
        let value ← if nativeOverride then do
          unless (← checked (stringField record "constantKind")) == "theorem" && (← checked (record.getObjValAs? Bool "isProposition")) do
            throwError "The exact cardQuot override is not a genuine proposition-valued theorem"
          let current ← getConstInfo name
          unless kind current == "theorem" && params.length == current.levelParams.length do
            throwError "Actual native cardQuot theorem kind/universes differ"
          let rawType ← checked (decodeExpandedExpr #[] (← checked (field record "elaboratedExpr")))
          let nativeType := current.type.instantiateLevelParams current.levelParams (params.map Level.param)
          unless binderInventory rawType == (← checked (record.getObjValAs? (Array String) "binderInventory")) && binderInventory rawType == binderInventory nativeType && binderPlacement rawType == binderPlacement nativeType do
            throwError "Full unexpanded original/native cardQuot type BinderInfo differs"
          pure (Lean.mkConst name (params.map Level.param))
        else do
          let valueJson ← checked (field record "valueExpr")
          unless valueJson != Json.null do throwError "No genuine original value available for exact expansion"
          checked (decodeExpandedExpr entries valueJson)
        checkExactType "exact original expanded body/proof type" (← checkKernel "original body or precise native theorem proof" value) type
        unless (← isProp type) == (← checked (record.getObjValAs? Bool "isProposition")) do
          throwError "Original source proposition/data status differs after exact expansion"
        let axs ← expressionAxioms cache value
        let taxs ← expressionAxioms cache type
        ensureStandard "genuine original expanded body" axs
        ensureStandard "complete original expanded type" taxs
        for term in #[type, value] do
          for used in term.getUsedConstants do
            let some owner := moduleOf env used | throwError "Expanded source dependency has no imported owner: {used}"
            unless #[`Init, `Lean, `Std, `Mathlib, `Batteries, `Aesop, `Qq, `Plausible, `ProofWidgets, `ImportGraph, `Cli, `LeanSearchClient].any (·.isPrefixOf owner) do
              throwError "Nonstandard dependency in complete source body: {used}"
        let rawType ← checked (decodeExpandedExpr #[] (← checked (field record "elaboratedExpr")))
        unless binderInventory rawType == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
          throwError "Raw original source type BinderInfo serialization differs"
        if nativeOverride then
          nativeOverrides := nativeOverrides.push (Json.mkObj [
            ("name", toJson name.toString), ("nameExpr", encodeName name),
            ("kind", toJson "actual current theorem proof at exact original expanded proposition type"),
            ("originalBodyReplayed", toJson false), ("kernelCheckedExactSourceType", toJson true),
            ("rawOriginalNativeTypeBinderInfoEqual", toJson true),
            ("axioms", toJson (axs.map Name.toString))])
        entries := entries.push (name, (params, value))
        let encodePair : ExprDagM (Nat × Nat) := do
          let typeRoot ← addExpr type
          let valueRoot ← addExpr value
          return (typeRoot, valueRoot)
        let ((typeRoot, valueRoot), nextEncoder) ← encodePair.run encoder
        encoder := nextEncoder
        rootRefs := (rootRefs.push typeRoot).push valueRoot
        originalRoots := (originalRoots.push type).push value
        serializedEntries := serializedEntries.push (Json.mkObj [
          ("name", toJson name.toString), ("nameExpr", encodeName name),
          ("levelParams", Json.arr (params.toArray.map encodeName)),
          ("typeRoot", toJson typeRoot), ("valueRoot", toJson valueRoot),
          ("resolution", toJson (if nativeOverride then "exact-original-type-native-theorem-proof" else "genuine-original-complete-body")),
          ("isProposition", ← checked (field record "isProposition")),
          ("axioms", toJson (axs.map Name.toString))])
        pure (Json.mkObj [
          ("name", toJson name.toString), ("nameExpr", encodeName name), ("succeeded", toJson true),
          ("isProposition", ← checked (field record "isProposition")),
          ("genuineOriginalBodyKernelCheckedAtExactOriginalType", toJson (!nativeOverride)),
          ("kernelCheckedExactOriginalType", toJson true),
          ("nativeTheoremProofOverride", toJson nativeOverride),
          ("axioms", toJson (axs.map Name.toString)),
          ("typeAxioms", toJson (taxs.map Name.toString)),
          ("rawOriginalTypeBinderInfoSerializationChecked", toJson true),
          ("rawOriginalTypeBinderInventory", toJson (binderInventory rawType)),
          ("rawOriginalTypeBinderPlacement", toJson (binderPlacement rawType)),
          ("expandedTypeBinderInventory", toJson (binderInventory type)),
          ("expandedTypeBinderPlacement", toJson (binderPlacement type)),
          ("identityPolicy", toJson "No current data identity asserted when generic types differ; complete project consumer kernel equality remains mandatory.")])
      catch ex =>
        pure (Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
          ("succeeded", toJson false), ("error", toJson (← ex.toMessageData.toString))])
      attempts := attempts.push result
  let blocked := stageNames.filter fun name => !(processed.contains name)
  let mut missingNeeded : Array Name := #[]
  for record in records do
    let name ← checked (decodeName (← checked (field record "nameExpr")))
    let typeUsed ← namesFromJson (← checked (field record "typeUsedConstants"))
    let valueUsed ← if name == cardPowName then pure [] else namesFromJson (← checked (field record "valueUsedConstants"))
    for used in typeUsed ++ valueUsed do
      unless env.contains used || closureNames.contains used || used == standardName || missingNeeded.contains used do
        missingNeeded := missingNeeded.push used
  unless blocked.isEmpty && attempts.size == stageNames.size do
    throwError "Stage has failed or dependency-blocked source records"
  for attempt in attempts do
    unless (← checked (attempt.getObjValAs? Bool "succeeded")) do
      throwError "Stage contains a failed exact source type/value check"
  unless nativeOverrides.size == 2 do throwError "Expected exactly Ring+CardPow standard proof cases"
  let exprDag ← finishExprDag encoder rootRefs originalRoots
  let output ← absoluteEnv "NEXT_CARRIER_ADIC_DAG_OUTPUT"
  IO.FS.writeFile output ((Json.mkObj [
    ("schema", toJson "tate-theta-adic-split-expr-dag-v1"),
    ("compilerVersion", toJson Lean.versionString), ("stage", toJson stage),
    ("inventorySha256", ← checked (field source "inventorySha256")),
    ("graphSha256", ← checked (field source "graphSha256")),
    ("candidateOriginalRecordCount", toJson candidates.size),
    ("allActiveOriginalRecordCount", toJson closureNames.size),
    ("stageOriginalRecordCount", toJson stageNames.size),
    ("stageOriginalRecordNames", Json.arr (stageNames.map encodeName)),
    ("unusedArchivedCandidateNames", Json.arr (unusedCandidates.map encodeName)),
    ("standardProofOverrideCount", toJson nativeOverrides.size),
    ("standardProofOverrides", Json.arr nativeOverrides),
    ("completeOriginalBodyAttempts", Json.arr attempts),
    ("entries", Json.arr serializedEntries), ("exprDag", exprDag),
    ("allCompleteTypeValueKernelChecksPassed", toJson true),
    ("allExprDagRootsStrictExprEqualRoundTrip", toJson true),
    ("roundTripIncludesBinderNamesBinderInfoAndNumericNames", toJson true),
    ("policy", toJson "Actual A19/B16 split. Complete source types/values retained in a shared exact DAG; every root strictly round-tripped. No data replacement or equality waiver.")]).compress ++ "\n")
  logInfo s!"Adic source DAG {stage}: {attempts.size} complete exact type/value checks, {encoder.nodes.size} shared nodes, {rootRefs.size} strict Expr.equal roots"

end AdicCompletionPlatformFacts
syntax (name := queryAdicCompletionPlatformFacts) "query_adic_completion_platform_facts" : command
@[command_elab queryAdicCompletionPlatformFacts]
def elabQueryAdicCompletionPlatformFacts : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM AdicCompletionPlatformFacts.query
query_adic_completion_platform_facts
