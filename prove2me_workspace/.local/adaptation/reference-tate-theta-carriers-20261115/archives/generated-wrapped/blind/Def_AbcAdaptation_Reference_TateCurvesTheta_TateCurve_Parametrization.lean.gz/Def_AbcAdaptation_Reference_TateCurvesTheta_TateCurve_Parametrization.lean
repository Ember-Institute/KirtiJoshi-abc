import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Units.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Analysis.Normed.Field.Basic
import Mathlib.Analysis.Normed.Ring.Basic
import Mathlib.Data.Int.Cast.Defs
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Data.Nat.Init
import Mathlib.Topology.Algebra.InfiniteSum.Defs
import Mathlib.Topology.Algebra.InfiniteSum.SummationFilter
import Mathlib.Topology.MetricSpace.Pseudo.Defs
import Mathlib.Topology.UniformSpace.Defs
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Weierstrass
import Mathlib.Topology.MetricSpace.Ultra.Basic

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



open Filter Topology

noncomputable section

namespace TateCurvesTheta

namespace TateParameter

variable {K : Type*} [NormedField K]

variable (t : TateParameter K)


def Xterm (u : Kˣ) (n : ℤ) : K :=
  (t.q : K) ^ n * (u : K) / (1 - (t.q : K) ^ n * (u : K)) ^ 2


def Yterm (u : Kˣ) (n : ℤ) : K :=
  ((t.q : K) ^ n * (u : K)) ^ 2 / (1 - (t.q : K) ^ n * (u : K)) ^ 3


def X (u : Kˣ) : K := (∑' n : ℤ, t.Xterm u n) - 2 * t.eisenstein 1


def Y (u : Kˣ) : K := (∑' n : ℤ, t.Yterm u n) + t.eisenstein 1

section Nonarchimedean

variable [IsUltrametricDist K]

variable [CompleteSpace K]

end Nonarchimedean

end TateParameter

end TateCurvesTheta

end

end AbcAdaptation.Reference
