def platform_helper_evidence(args, export, records):
    proof = 'TateCurvesTheta.TateParameter.tateJ.eq_1'
    parent = 'TateCurvesTheta.TateParameter.tateJ'
    if not args.platform_facts or not args.platform_receipt or not args.platform_query_config:
        raise ValueError('Exact source equation proof requires --platform-facts, --platform-receipt, and --platform-query-config')
    receipt = verify_receipt(args.platform_receipt, 'ci-014164-c01e488c')
    facts = load(args.platform_facts)
    assert facts['schema'] == 'tate-theta-platform-helper-facts-v1' and facts['compilerVersion'] == '4.33.1'
    for key in ['inventorySha256', 'graphSha256']:
        assert facts[key] == export[key]
    assert facts['sourceRecordCount'] == 117 and facts['publicSourceCandidateCount'] == 111
    assert facts['selectedSourceCount'] == 78 and facts['selectedMissingCount'] == 1
    assert facts['ownedDeclarationCount'] == len(facts['ownedDeclarations']) == 77
    assert facts['targetOnlyNames'] == []
    req = receipt['request']
    manifest = req['worktree_manifest']
    query_source = W / req['parameters']['source']
    assert req['task_type'] == 'leaf' and req['target'] == 'file'
    assert sha(query_source) == manifest['source_sha256']
    assert manifest['input_hashes'][str(query_source)] == sha(query_source)
    queried_config = Path(req['environment']['NEXT_CARRIER_AUDIT_CONFIG'])
    assert sha(args.platform_query_config) == manifest['input_hashes'][str(queried_config)]
    assert load(args.platform_query_config) == facts['sourceAuditConfiguration']
    coverage = facts['expectedCurrentCandidates']
    assert len(coverage) == 111 and len({r['original'] for r in coverage}) == 111
    selected = [r for r in coverage if r['selected']]
    assert len(selected) == 78
    missing = [r for r in selected if not r['present']]
    assert len(missing) == 1 and missing[0]['original'] == proof
    for row in coverage:
        source = records[row['original']]
        assert source['nameExpr'] == row['originalName'] and source['selected'] == row['selected']
    owned = {r['name']: r for r in facts['ownedDeclarations']}
    assert len(owned) == 77 and set(owned) == {r['candidateTarget'] for r in coverage if r['present']}
    assert set(owned) == {r['candidateTarget'] for r in selected if r['present']}
    for row in facts['ownedDeclarations']:
        assert not row['hasSorryAx'] and display_name(row['nameExpr']) == row['name']
        for key in ['axioms', 'typeAxioms', 'valueAxioms']:
            assert set(row[key]) <= ALLOWED_AXIOMS
    for row in coverage:
        if row['present']:
            target = owned[row['candidateTarget']]
            assert target['nameExpr'] == row['candidateTargetName']
            assert target['module'] == target_module(records[row['original']]['module'])
            assert target['constantKind'] == row['actualConstantKind']
            assert target['levelParams'] == row['actualLevelParams']
    parent_target = 'AbcAdaptation.Reference.' + parent
    parent_facts = [r for r in facts['helperFacts'] if r['name'] == parent_target]
    assert len(parent_facts) == 1
    actual_parent = parent_facts[0]
    assert actual_parent['constantKind'] == 'definition' and not actual_parent['isProposition']
    assert actual_parent['valueExpr'] is not None and not actual_parent['hasSorryAx']
    assert records[parent]['selected'] and not records[parent]['isProposition']
    assert records[parent]['constantKind'] == 'definition' and records[parent]['valueExpr'] is not None
    evidence_paths = [args.platform_facts, args.platform_receipt, args.platform_query_config, query_source]
    binding = {
        'facts': {'path': str(args.platform_facts.resolve()), 'sha256': sha(args.platform_facts), 'contents': facts},
        'receipt': {'path': str(args.platform_receipt.resolve()), 'sha256': sha(args.platform_receipt), 'contents': receipt},
        'querySource': {'path': str(query_source.resolve()), 'sha256': sha(query_source)},
        'queryConfiguration': {'path': str(args.platform_query_config.resolve()), 'sha256': sha(args.platform_query_config)},
        'policy': 'Only actual platform query evidence; exactly one absent selected equation theorem and77 actual owned named constants.'}
    return binding, actual_parent, evidence_paths


