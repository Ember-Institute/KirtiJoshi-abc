-- These facts establish actual platform absence and inventory, not a theorem alias.
def boundPlatformHelperEvidence (config : Json) (key : String) : MetaM Json := do
  let evidence ← checked (field config "platformHelperEvidence")
  let binding ← checked (field evidence key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do
    throwError "Platform helper evidence changed after hash binding: {key}"
  unless (← checked (stringField binding "sha256")).length == 64 do
    throwError "Missing external SHA256 binding for platform helper evidence: {key}"
  return actual

def verifyPlatformHelperFacts (config : Json) : MetaM Json := do
  let facts ← boundPlatformHelperEvidence config "facts"
  let receipt ← boundPlatformHelperEvidence config "receipt"
  unless (← checked (stringField receipt "job_id")) == "ci-014164-c01e488c" &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Expected successful actual platform helper query receipt"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
    throwError "Actual platform helper query exit code is not zero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do
    throwError "Wrong actual platform helper query workspace mode"
  unless (← checked (stringField facts "schema")) == "tate-theta-platform-helper-facts-v1" &&
      (← checked (stringField facts "compilerVersion")) == Lean.versionString &&
      (← checked (facts.getObjValAs? Nat "sourceRecordCount")) == 117 &&
      (← checked (facts.getObjValAs? Nat "selectedSourceCount")) == 78 &&
      (← checked (facts.getObjValAs? Nat "selectedMissingCount")) == 1 &&
      (← checked (facts.getObjValAs? Nat "ownedDeclarationCount")) == 77 do
    throwError "Unexpected actual platform helper query dimensions/compiler"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field facts key)) == (← checked (field config key)) do
      throwError "Actual platform helper query provenance changed: {key}"
  unless (← checked (arrayField facts "targetOnlyNames")).isEmpty do
    throwError "This exact equation-proof treatment expects no target-only declaration"
  let env ← getEnv
  let moduleRows ← checked (arrayField config "modules")
  let modules ← moduleRows.mapM fun row => do
    return (← checked (stringField row "target")).toName
  let actualOwned := env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)
  let ownedRows ← checked (arrayField facts "ownedDeclarations")
  let ownedNames ← ownedRows.mapM fun row => do
    checked (decodeName (← checked (field row "nameExpr")))
  unless ownedNames.size == 77 && ownedNames.toList.eraseDups.length == ownedNames.size &&
      actualOwned.size == ownedNames.size && actualOwned.all ownedNames.contains do
    throwError "Actual current owned declaration set changed after platform query"
  for row in ownedRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    let ci ← getConstInfo name
    unless name.toString == (← checked (stringField row "name")) &&
        moduleOf env name == some (← checked (stringField row "module")).toName &&
        kind ci == (← checked (stringField row "constantKind")) &&
        Json.arr (ci.levelParams.toArray.map encodeName) == (← checked (field row "levelParams")) &&
        Lean.Meta.isInstanceCore env name == (← checked (row.getObjValAs? Bool "isInstance")) do
      throwError "Actual owned declaration identity/owner/kind/universes/instance changed: {name}"
    unless !(← checked (row.getObjValAs? Bool "hasSorryAx")) do
      throwError "Actual platform query contains sorryAx: {name}"
    for key in #["axioms", "typeAxioms", "valueAxioms"] do
      for ax in ← checked (arrayField row key) do
        unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
          throwError "Unexpected actual platform query axiom: {name}"
  let helperRows ← checked (arrayField facts "helperFacts")
  for row in helperRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    unless ownedNames.contains name do throwError "Unowned actual helper fact {name}"
    let ci ← getConstInfo name
    unless (← checked (encodeExpr ci.type)) == (← checked (field row "elaboratedExpr")) do
      throwError "Actual platform helper type changed: {name}"
    let value ← match ci.value? (allowOpaque := true) with
      | none => pure Json.null | some expr => checked (encodeExpr expr)
    unless value == (← checked (field row "valueExpr")) do
      throwError "Actual platform helper value changed: {name}"
  let candidates ← checked (arrayField facts "expectedCurrentCandidates")
  unless candidates.size == 111 do throwError "Wrong actual public source candidate count"
  let mut selectedCount := 0
  let mut missingCount := 0
  for row in candidates do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let target ← checked (decodeName (← checked (field row "candidateTargetName")))
    let selected ← checked (row.getObjValAs? Bool "selected")
    let present ← checked (row.getObjValAs? Bool "present")
    unless env.contains target == present do
      throwError "Actual source candidate presence changed: {original}"
    if selected then
      selectedCount := selectedCount + 1
      if !present then
        missingCount := missingCount + 1
        unless original == `TateCurvesTheta.TateParameter.tateJ.eq_1 do
          throwError "Unapproved missing selected declaration {original}"
  unless selectedCount == 78 && missingCount == 1 do
    throwError "Expected the exact single absent tateJ equation theorem"
  return facts

def installExactTateJEquationProof (rs : Relocations) (allowedOwners : Array Name)
    (source config facts : Json) : MetaM (Relocations × Array Json) := do
  let original := `TateCurvesTheta.TateParameter.tateJ.eq_1
  let parent := `TateCurvesTheta.TateParameter.tateJ
  let candidate := `AbcAdaptation.Reference.TateCurvesTheta.TateParameter.tateJ.eq_1
  let parentTarget := `AbcAdaptation.Reference.TateCurvesTheta.TateParameter.tateJ
  let env ← getEnv
  unless !(rs.any (·.original == original)) && rs.sourceProofValues.isEmpty &&
      !(env.contains candidate) do
    throwError "Equation proof value must have no named target identity"
  let configured ← checked (arrayField config "proofValueResolutions")
  let records ← checked (arrayField source "records")
  let originalRows := records.filter fun row => (stringField row "name").toOption == some original.toString
  unless configured.size == 1 && originalRows.size == 1 do
    throwError "Only the exact single tateJ equation proof may use a source value"
  let binding := configured[0]!
  let record := originalRows[0]!
  unless (← checked (decodeName (← checked (field binding "originalName")))) == original &&
      record == (← checked (field binding "sourceRecord")) &&
      (← checked (field binding "standaloneTargetIdentity")) == Json.null &&
      (← checked (stringField binding "parentOriginal")) == parent.toString do
    throwError "Exact tateJ source proof/configuration binding differs"
  unless (← checked (decodeName (← checked (field record "nameExpr")))) == original &&
      (← checked (stringField record "module")) == "TateCurvesTheta.TateCurve.JInvariant" &&
      (← checked (stringField record "constantKind")) == "theorem" &&
      (← checked (record.getObjValAs? Bool "selected")) &&
      (← checked (record.getObjValAs? Bool "isProposition")) &&
      !(← checked (record.getObjValAs? Bool "isInstance")) do
    throwError "Exact equation source record is not a selected non-instance theorem"
  let parentRows := records.filter fun row => (stringField row "name").toOption == some parent.toString
  unless parentRows.size == 1 &&
      (← checked (parentRows[0]!.getObjValAs? Bool "selected")) &&
      !(← checked (parentRows[0]!.getObjValAs? Bool "isProposition")) &&
      (← checked (stringField parentRows[0]! "constantKind")) == "definition" &&
      (← checked (field parentRows[0]! "valueExpr")) != Json.null do
    throwError "Exact equation proof requires a complete selected parent data definition"
  let parentFacts := (← checked (arrayField facts "helperFacts")).filter fun row =>
    (stringField row "name").toOption == some parentTarget.toString
  unless parentFacts.size == 1 && parentFacts[0]! == (← checked (field binding "actualParentFact")) do
    throwError "Missing exact actual target parent value evidence"
  let some parentRelocation := rs.find? (·.original == parent) |
    throwError "Missing ordinary named parent relocation"
  unless parentRelocation.target == parentTarget do throwError "Wrong exact parent target"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected genuine equation source axiom"
  let expectedAxiomList ← namesFromJson (← checked (field binding "expectedSourceAxioms"))
  let expectedAxioms := expectedAxiomList.toArray
  let sourceAxioms := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxioms.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Exact equation proof source axiom closure differs from accepted graph"
  let params ← namesFromJson (← checked (field record "levelParams"))
  unless params.eraseDups == params do throwError "Repeated exact source proof universe parameter"
  let type ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let valueJson ← checked (field record "valueExpr")
  unless valueJson != Json.null do throwError "Genuine equation source proof value is missing"
  let value ← checked (decodeExpr rs valueJson)
  unless binderInventory type == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
    throwError "Genuine equation source type BinderInfo inventory changed"
  let levels := (canonicalLevels params.length).map Level.param
  let canonicalType := type.instantiateLevelParams params levels
  let canonicalValue := value.instantiateLevelParams params levels
  unless (← isProp canonicalType) do throwError "Genuine equation source type is not a proposition"
  let inferredType ← kernelCheck "genuine tateJ equation source proof" canonicalValue
  kernelTypeEq "genuine tateJ equation proof inhabits exact relocated source type" inferredType canonicalType
  unless binderPlacement inferredType == binderPlacement canonicalType do
    throwError "Genuine equation proof inferred type BinderInfo placement differs"
  let taxs ← expressionAxioms canonicalType
  let vaxs ← expressionAxioms canonicalValue
  ensureStandard "exact genuine tateJ equation source type" taxs
  ensureStandard "exact genuine tateJ equation source value" vaxs
  for term in #[canonicalType, canonicalValue] do
    for dependency in term.getUsedConstants do allowedOwner rs allowedOwners dependency
  let rs := { rs with sourceProofValues := #[(original, (params, value))] }
  return (rs, #[Json.mkObj [
    ("original", toJson original.toString), ("originalName", encodeName original),
    ("resolution", toJson "genuine-exported-original-proof-value"),
    ("standaloneTargetIdentity", Json.null), ("sourceRecord", record),
    ("originalTypeBinderInfoPreserved", toJson true),
    ("inferredTypeBinderInfoPlacementPreserved", toJson true),
    ("exactOriginalTypeKernelChecked", toJson true),
    ("genuineOriginalValueInhabitsExactOriginalType", toJson true),
    ("expandedType", ← checked (encodeExpr type)), ("expandedValue", ← checked (encodeExpr value)),
    ("expandedTypeAxioms", toJson (taxs.map Name.toString)),
    ("expandedValueAxioms", toJson (vaxs.map Name.toString)),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("parentOriginal", toJson parent.toString), ("parentTarget", encodeName parentTarget),
    ("parentWholeValueEqualityRequired", toJson true),
    ("parentKernelDefinitionalValueEqualityRequired", toJson true),
    ("actualPlatformAbsenceEvidenceVerified", toJson true),
    ("actualPlatformQueryJob", toJson "ci-014164-c01e488c"),
    ("expandedDependenciesHaveAllowedOwners", toJson true), ("hasSorryAx", toJson false)]])

