import Lean
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_JInvariant
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Parametrization
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateStructure

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FiniteQuotientsPlatformFacts
open Lean Elab Term Meta FoundationAudit

def actualFacts (cache : AxiomCache) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  let value := ci.value? (allowOpaque := true)
  let axs ← cachedAxioms cache name
  let taxs ← expressionAxioms cache ci.type
  let vaxs ← match value with
    | none => pure #[] | some expr => expressionAxioms cache expr
  let shape ← match getStructureInfo? (← getEnv) name with
    | none => pure Json.null
    | some info => checked (structureShape info pure)
  let ruleRhs ← match ci with
    | .recInfo info => info.rules.toArray.mapM fun rule => checked (encodeExpr rule.rhs)
    | _ => pure #[]
  return Json.mkObj [
    ("name", toJson name.toString), ("nameExpr", encodeName name),
    ("module", match moduleOf (← getEnv) name with
      | none => Json.null | some owner => toJson owner.toString),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("valueExpr", ← match value with | none => pure Json.null | some expr => checked (encodeExpr expr)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("isProposition", toJson (← isProp ci.type)),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name)),
    ("isClass", toJson (Lean.isClass (← getEnv) name)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("typeUsedConstants", Json.arr (ci.type.getUsedConstants.map encodeName)),
    ("valueUsedConstants", Json.arr (match value with
      | none => #[] | some expr => expr.getUsedConstants.map encodeName)),
    ("computationShape", ← checked (computationShape ci pure)),
    ("recursorRuleRhs", Json.arr ruleRhs), ("structure", shape),
    ("hasSorryAx", toJson (axs.contains `sorryAx))]


-- Identity decoder for standard facts only. No aliases or source-proof transport.
partial def decodeStandardExpr (j : Json) : Except String Expr := do
  let recur := decodeStandardExpr
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" => return .const (← decodeName (← field j "name"))
      ((← (← arrayField j "levels").mapM decodeLevel).toList)
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type"))
      (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type"))
      (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type"))
      (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← decodeName (← field j "name")) (← (← field j "index").getNat?)
      (← recur (← field j "body"))
  | kind => throw s!"Unknown standard Expr kind {kind}"

def checkKernel (label : String) (expr : Expr) : MetaM Expr := do
  if expr.hasMVar || expr.hasFVar || expr.hasLooseBVars then throwError "Open query expression: {label}"
  match Kernel.check (← getEnv) {} expr with
  | .ok type => pure type | .error ex => throwKernelException ex

def checkExactType (label : String) (inferred expected : Expr) : MetaM Unit := do
  for type in #[inferred, expected] do
    match ← checkKernel label type with
    | .sort _ => pure () | _ => throwError "Expected a checked type: {label}"
  match Kernel.isDefEq (← getEnv) {} inferred expected with
  | .ok true => pure ()
  | .ok false => throwError "Query proof does not inhabit exact source type: {label}"
  | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def compareStandardShape (record : Json) : MetaM Json := do
  let name ← checked (decodeName (← checked (field record "nameExpr")))
  let ci ← getConstInfo name
  unless kind ci == (← checked (stringField record "constantKind")) do
    throwError "Actual standard declaration kind differs: {name}"
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.length == ci.levelParams.length do throwError "Standard universe arity differs: {name}"
  let levels := (List.range sourceParams.length).map fun index =>
    Level.param (Name.num (Name.str .anonymous "_finiteQuotientsShapeUniverse") index)
  let rawType ← checked (decodeStandardExpr (← checked (field record "elaboratedExpr")))
  let sourceType := rawType.instantiateLevelParams sourceParams levels
  let targetType := ci.type.instantiateLevelParams ci.levelParams levels
  checkExactType s!"original/current standard API type {name}" sourceType targetType
  unless binderInventory sourceType == binderInventory targetType &&
      binderPlacement sourceType == binderPlacement targetType do
    throwError "Original/current standard API type BinderInfo differs: {name}"
  unless (← checked (field record "computationShape")) == (← checked (computationShape ci pure)) do
    throwError "Original/current standard computation metadata differs: {name}"
  let targetStructure ← match getStructureInfo? (← getEnv) name with
    | none => pure Json.null | some info => checked (structureShape info pure)
  unless targetStructure == (← checked (field record "structure")) do
    throwError "Original/current standard class field/parent metadata differs: {name}"
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut compared := 0
  if let .recInfo info := ci then
    unless rules.size == info.rules.length do throwError "Standard recursor rule count differs: {name}"
    for index in [:rules.size] do
      let rhs ← checked (decodeStandardExpr rules[index]!)
      let sourceRhs := rhs.instantiateLevelParams sourceParams levels
      let targetRhs := info.rules[index]!.rhs.instantiateLevelParams ci.levelParams levels
      checkExactType "standard recursor rule types" (← checkKernel "source standard recursor rule" sourceRhs)
        (← checkKernel "target standard recursor rule" targetRhs)
      match Kernel.isDefEq (← getEnv) {} sourceRhs targetRhs with
      | .ok true => pure ()
      | .ok false => throwError "Standard recursor computation differs: {name}"
      | .error ex => throwKernelException ex
      compared := compared + 1
  else
    unless rules.isEmpty do throwError "Unexpected standard recursor rules: {name}"
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("succeeded", toJson true), ("kernelTypeEqual", toJson true),
    ("binderInfoPlacementEqual", toJson true), ("computationShapeEqual", toJson true),
    ("structureMetadataEqual", toJson true), ("recursorRulesCompared", toJson compared)]

def proofAttempt (cache : AxiomCache) (type value : Expr) : MetaM Json := do
  let value ← instantiateMVars value
  checkExactType "standard instance proof" (← checkKernel "standard instance proof" value) type
  unless (← isProp type) do throwError "Expected exact proposition-valued source instance type"
  let axs ← expressionAxioms cache value
  ensureStandard "queried exact standard instance proof" axs
  let env ← getEnv
  let standardPrefixes := #[`Init, `Lean, `Std, `Mathlib, `Batteries, `Aesop, `Qq, `Plausible,
    `ProofWidgets, `ImportGraph, `Cli, `LeanSearchClient]
  for name in value.getUsedConstants do
    let some owner := moduleOf env name | throwError "No imported standard proof owner {name}"
    unless standardPrefixes.any (·.isPrefixOf owner) do throwError "Nonstandard proof dependency {name}: {owner}"
  return Json.mkObj [
    ("succeeded", toJson true), ("kernelCheckedExactSourceType", toJson true),
    ("type", ← checked (encodeExpr type)), ("value", ← checked (encodeExpr value)),
    ("axioms", toJson (axs.map Name.toString)), ("hasSorryAx", toJson false),
    ("usedConstants", Json.arr (value.getUsedConstants.map encodeName)),
    ("dependencyOwnersStandardOnly", toJson true)]

def query : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected platform compiler4.33.1"
  let source ← jsonFile (← absoluteEnv "NEXT_CARRIER_STANDARD_SOURCE_FACTS")
  unless (← checked (stringField source "schema")) == "tate-theta-exact-standard-source-facts-v1" &&
      (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" do
    throwError "Expected actual original standard facts"
  let env ← getEnv
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let sourceNames ← namesFromJson (← checked (field source "focusedNames"))
  let mut presentFacts : Array Json := #[]
  let mut focusedPresence : Array Json := #[]
  for name in sourceNames do
    let present := env.contains name
    focusedPresence := focusedPresence.push (Json.mkObj [
      ("name", toJson name.toString), ("nameExpr", encodeName name), ("present", toJson present)])
    if present then presentFacts := presentFacts.push (← actualFacts cache name)
  let relevant ← checked (arrayField source "relevantStandardNames")
  let mut standardPresence : Array Json := #[]
  let mut missing : Array Name := #[]
  for row in relevant do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    let present := env.contains name
    if !present then missing := missing.push name
    standardPresence := standardPresence.push (Json.mkObj [
      ("name", toJson name.toString), ("nameExpr", encodeName name), ("present", toJson present),
      ("actualOwner", match moduleOf env name with | none => Json.null | some owner => toJson owner.toString)])
  let className := `Ring.HasFiniteQuotients
  let candidateNames := env.constants.fold (fun acc name _ =>
    if className.isPrefixOf name && Lean.Meta.isInstanceCore env name then acc.push name else acc) (#[] : Array Name)
  let mut nativeCandidates : Array Json := #[]
  for name in candidateNames do
    let ci ← getConstInfo name
    let sameResult ← forallTelescope ci.type fun _ result => pure (result.getAppFn.isConstOf className)
    if sameResult then nativeCandidates := nativeCandidates.push (← actualFacts cache name)
  let instanceName := `NumberField.RingOfIntegers.instHasFiniteQuotients
  let mut standardShapeChecks : Array Json := #[]
  for row in ← checked (arrayField source "facts") do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    if env.contains name && name != instanceName then
      let report ← try
        compareStandardShape row
      catch ex =>
        pure (Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
          ("succeeded", toJson false), ("error", toJson (← ex.toMessageData.toString))])
      standardShapeChecks := standardShapeChecks.push report
  let originalRows := (← checked (arrayField source "facts")).filter fun row =>
    (stringField row "name").toOption == some instanceName.toString
  unless originalRows.size == 1 do throwError "Missing exact genuine source instance fact"
  let record := originalRows[0]!
  let params ← namesFromJson (← checked (field record "levelParams"))
  let levels := (List.range params.length).map fun index =>
    Level.param (Name.num (Name.str .anonymous "_finiteQuotientsQueryUniverse") index)
  let sourceType ← checked (decodeStandardExpr (← checked (field record "elaboratedExpr")))
  let exactType := sourceType.instantiateLevelParams params levels
  let sourceBodyAttempt ← try
    let body ← checked (decodeStandardExpr (← checked (field record "valueExpr")))
    proofAttempt cache exactType (body.instantiateLevelParams params levels)
  catch ex =>
    pure (Json.mkObj [("succeeded", toJson false), ("error", toJson (← ex.toMessageData.toString))])
  let nativeProofAttempt ← try
    let proof ← forallTelescope exactType fun args result => do
      let proof ← synthInstance result
      mkLambdaFVars args proof
    proofAttempt cache exactType proof
  catch ex =>
    pure (Json.mkObj [("succeeded", toJson false), ("error", toJson (← ex.toMessageData.toString))])
  let output ← absoluteEnv "NEXT_CARRIER_STANDARD_PLATFORM_FACTS_OUTPUT"
  IO.FS.writeFile output ((Json.mkObj [
    ("schema", toJson "tate-theta-exact-standard-platform-facts-v1"),
    ("compilerVersion", toJson Lean.versionString),
    ("inventorySha256", ← checked (field source "inventorySha256")),
    ("graphSha256", ← checked (field source "graphSha256")),
    ("focusedPresence", Json.arr focusedPresence), ("facts", Json.arr presentFacts),
    ("relevantStandardNameCount", toJson relevant.size),
    ("standardPresence", Json.arr standardPresence),
    ("missingRelevantStandardNames", Json.arr (missing.map encodeName)),
    ("actualNativeInstanceCandidates", Json.arr nativeCandidates),
    ("originalCurrentStandardShapeChecks", Json.arr standardShapeChecks),
    ("genuineSourceBodyAttempt", sourceBodyAttempt), ("nativeProofAttempt", nativeProofAttempt),
    ("policy", toJson "Diagnostic actual facts and exact kernel proof attempts only. No name alias, type replacement, or compatibility permission is installed.")]).compress ++ "\n")
  logInfo s!"Platform standard facts: {missing.size}/{relevant.size} relevant Names absent; {nativeCandidates.size} actual native candidate instances"

end FiniteQuotientsPlatformFacts
syntax (name := queryFiniteQuotientsPlatformFacts) "query_finite_quotients_platform_facts" : command
@[command_elab queryFiniteQuotientsPlatformFacts]
def elabQueryFiniteQuotientsPlatformFacts : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FiniteQuotientsPlatformFacts.query
query_finite_quotients_platform_facts
