import Lean
namespace FoundationAudit
open Lean Meta

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

-- Insert inside namespace FoundationAudit, after checked and the existing
-- Name/Level/Binder codecs. Roots must already be metadata-erased.

structure ExprDagEncoder where
  nodes : Array Json := #[]
  index : Lean.ExprStructMap Nat := {}
  deriving Inhabited

abbrev ExprDagM := StateT ExprDagEncoder MetaM

/-- Intern by Expr.equal, which preserves binder Names and BinderInfo. -/
partial def addExpr (e : Expr) : ExprDagM Nat := do
  let initial ← get
  if let some ref := initial.index[(⟨e⟩ : ExprStructEq)]? then
    return ref
  let payload : Json ← match e with
    | .bvar i => pure (node "bvar" [("index", toJson i)])
    | .sort u => do
        let encoded ← liftM (checked (encodeLevel u))
        pure (node "sort" [("level", encoded)])
    | .const n us => do
        let levels ← liftM (checked (us.toArray.mapM encodeLevel))
        pure (node "const" [("name", encodeName n), ("levels", Json.arr levels)])
    | .app f a => do
        let fnRef ← addExpr f
        let argRef ← addExpr a
        pure (node "app" [("fn", toJson fnRef), ("arg", toJson argRef)])
    | .lam n t b bi => do
        let typeRef ← addExpr t
        let bodyRef ← addExpr b
        pure (node "lam" [("name", encodeName n), ("type", toJson typeRef),
          ("body", toJson bodyRef), ("binder", toJson (encodeBinder bi))])
    | .forallE n t b bi => do
        let typeRef ← addExpr t
        let bodyRef ← addExpr b
        pure (node "forall" [("name", encodeName n), ("type", toJson typeRef),
          ("body", toJson bodyRef), ("binder", toJson (encodeBinder bi))])
    | .letE n t v b nd => do
        let typeRef ← addExpr t
        let valueRef ← addExpr v
        let bodyRef ← addExpr b
        pure (node "let" [("name", encodeName n), ("type", toJson typeRef),
          ("value", toJson valueRef), ("body", toJson bodyRef), ("nondependent", toJson nd)])
    | .lit (.natVal n) => pure (node "nat" [("value", toJson n)])
    | .lit (.strVal s) => pure (node "string" [("value", toJson s)])
    | .proj n i b => do
        let bodyRef ← addExpr b
        pure (node "proj" [("name", encodeName n), ("index", toJson i), ("body", toJson bodyRef)])
    | .mdata _ _ => throwError "Expr DAG requires metadata-erased roots; metadata was not discarded"
    | .fvar _ => throwError "Free variable in Expr DAG input"
    | .mvar _ => throwError "Expression metavariable in Expr DAG input"
  let current ← get
  let ref := current.nodes.size
  set { current with nodes := current.nodes.push payload,
                     index := current.index.insert (⟨e⟩ : ExprStructEq) ref }
  return ref

/-- A child must refer to an already decoded node, never itself or a future node. -/
def exprDagChild (earlier : Array Expr) (entry : Json) (key : String) : Except String Expr := do
  let ref ← (← field entry key).getNat?
  match earlier[ref]? with
  | some e => pure e
  | none => throw s!"Expr DAG {key} reference {ref} is not earlier than node {earlier.size}"

/-- Decode one node using only the completed topological prefix. -/
def decodeExprDagNode (earlier : Array Expr) (entry : Json) : Except String Expr := do
  match ← stringField entry "kind" with
  | "bvar" => return .bvar (← (← field entry "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field entry "level"))
  | "const" =>
      let levels ← (← arrayField entry "levels").mapM decodeLevel
      return .const (← decodeName (← field entry "name")) levels.toList
  | "app" => return .app (← exprDagChild earlier entry "fn") (← exprDagChild earlier entry "arg")
  | "lam" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let body ← exprDagChild earlier entry "body"
      let binder ← decodeBinder (← stringField entry "binder")
      return .lam binderName ty body binder
  | "forall" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let body ← exprDagChild earlier entry "body"
      let binder ← decodeBinder (← stringField entry "binder")
      return .forallE binderName ty body binder
  | "let" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let value ← exprDagChild earlier entry "value"
      let body ← exprDagChild earlier entry "body"
      let nondependent ← (← field entry "nondependent").getBool?
      return .letE binderName ty value body nondependent
  | "nat" => return .lit (.natVal (← (← field entry "value").getNat?))
  | "string" => return .lit (.strVal (← (← field entry "value").getStr?))
  | "proj" =>
      let projectionName ← decodeName (← field entry "name")
      let index ← (← field entry "index").getNat?
      let body ← exprDagChild earlier entry "body"
      return .proj projectionName index body
  | other => throw s!"Unsupported Expr DAG node kind: {other}"

/-- Build the shared Expr table once and validate every declared root reference. -/
def decodeExprDag (dag : Json) : Except String (Array Expr) := do
  unless (← stringField dag "schema") == "foundation-expr-dag-v1" do
    throw "Unexpected Expr DAG schema"
  let entries ← arrayField dag "nodes"
  let mut decoded : Array Expr := #[]
  for entry in entries do
    decoded := decoded.push (← decodeExprDagNode decoded entry)
  for root in ← arrayField dag "roots" do
    let ref ← root.getNat?
    unless ref < decoded.size do
      throw s!"Expr DAG root reference {ref} is outside {decoded.size} nodes"
  return decoded

/-- Finalize only after one strict round trip for every original root. -/
def finishExprDag (encoder : ExprDagEncoder) (rootRefs : Array Nat)
    (originalRoots : Array Expr) : MetaM Json := do
  unless rootRefs.size == originalRoots.size do
    throwError "Expr DAG root references and original roots differ in count"
  let dag := Json.mkObj [("schema", toJson "foundation-expr-dag-v1"),
    ("nodes", Json.arr encoder.nodes), ("roots", toJson rootRefs)]
  let decoded ← checked (decodeExprDag dag)
  for i in [:rootRefs.size] do
    let ref := rootRefs[i]!
    let some actual := decoded[ref]? | throwError "Expr DAG root {i} is absent"
    unless Expr.equal originalRoots[i]! actual do
      throwError "Expr DAG strict Expr.equal round trip failed at root {i} (node {ref})"
  return dag

end FoundationAudit

namespace FoundationAudit
run_meta do
  let numericName := Name.num (.str .anonymous "dagName") 0
  let numericLevel := Level.param (Name.num (.str .anonymous "dagLevel") 0)
  let natType := Expr.const `Nat []
  let bound := Expr.bvar 0
  let ordinary := Expr.lam `x natType bound .default
  let implicit := Expr.lam `x natType bound .implicit
  let renamed := Expr.lam `y natType bound .default
  let roots : Array Expr := #[
    .sort (.max (.succ .zero) (.imax numericLevel .zero)),
    .const numericName [numericLevel, .succ numericLevel],
    .app (.const `Nat.succ []) (.lit (.natVal 7)),
    ordinary, implicit, renamed, .lam numericName natType bound .instImplicit,
    .forallE numericName natType natType .strictImplicit,
    .letE numericName natType (.lit (.natVal 7)) natType false,
    .letE numericName natType (.lit (.natVal 7)) natType true,
    .proj numericName 2 (.const numericName []),
    .lit (.natVal 12345), .lit (.strVal "DAG numeric Name and BinderInfo"), ordinary]
  let collect : ExprDagM (Array Nat) := do
    let mut refs : Array Nat := #[]
    for e in roots do
      refs := refs.push (← addExpr e)
    return refs
  let (refs, encoder) ← collect.run {}
  unless refs[3]! == refs[13]! do throwError "Repeated exact root was not interned"
  unless refs[3]! != refs[4]! && refs[3]! != refs[5]! do
    throwError "ExprStructMap merged distinct BinderInfo or binder Names"
  unless refs[8]! != refs[9]! do
    throwError "ExprStructMap merged distinct let nondependent flags"
  let dag ← finishExprDag encoder refs roots
  let decoded ← checked (decodeExprDag dag)
  unless Expr.equal decoded[refs[6]!]! roots[6]! do
    throwError "Numeric Name lambda did not survive strict round trip"
  logInfo s!"Expr DAG codec checked {roots.size} roots with {encoder.nodes.size} shared nodes"
end FoundationAudit
