import Lean
import Mathlib.RingTheory.Ideal.Quotient.HasFiniteQuotients
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_PrimeToOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Weierstrass
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_NormalizedOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_JInvariant
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Parametrization
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateStructure

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

structure Relocation where
  original : Name
  target : Name
  permutation : Option (Array Nat)
  expectedInstance : Option Bool
  expectedAxioms : Option (Array Name)

structure Relocations where
  rows : Array Relocation
  projectPrefixes : Array Name
  sourcePrefixes : Array Name
  targetPrefix : Name
  excludedSourceNames : Array Name
  sourceProofValues : Array (Name × (List Name × Expr))
  standardProofValues : Array (Name × (List Name × Expr))

def Relocations.find? (rs : Relocations) (p : Relocation → Bool) : Option Relocation := rs.rows.find? p
def Relocations.any (rs : Relocations) (p : Relocation → Bool) : Bool := rs.rows.any p

def projectName (rs : Relocations) (n : Name) : Bool :=
  rs.projectPrefixes.any (·.isPrefixOf n) || rs.excludedSourceNames.contains n

def relocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.original == n) then return r.target
  if projectName rs n then throw s!"Unmapped project name {n}"
  return n

def inverseRelocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.target == n) then return r.original
  if projectName rs n then throw s!"Unmapped wrapped name {n}"
  return n

def reorder (indices : Array Nat) (us : Array α) : Except String (Array α) := do
  unless indices.size == us.size && indices.toList.eraseDups.length == us.size do
    throw "Universe permutation has incorrect size or repeated indices"
  indices.mapM fun i => match us[i]? with
    | some u => pure u
    | none => throw "Universe permutation index out of range"

partial def decodeExpr (rs : Relocations) (j : Json) : Except String Expr := do
  let recur := decodeExpr rs
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    if let some proof := rs.standardProofValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == proof.2.1.length do
        throw "Universe arity differs for the exact standard proposition-valued instance proof"
      return proof.2.2.instantiateLevelParams proof.2.1 levels.toList
    if let some proof := rs.sourceProofValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == proof.2.1.length do
        throw "Universe arity differs for exact genuine equation source proof value"
      return proof.2.2.instantiateLevelParams proof.2.1 levels.toList
    let target ← relocated rs original
    let mut levels ← (← arrayField j "levels").mapM decodeLevel
    if let some r := rs.find? (·.original == original) then
      if let some indices := r.permutation then levels ← reorder indices levels
    return .const target levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocated rs (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unknown Expr kind {k}"

def readRelocations (config : Json) : MetaM Relocations := do
  let projectPrefixes := (← namesFromJson (← checked (field config "projectPrefixes"))).toArray
  let sourcePrefixes := (← namesFromJson (← checked (field config "originalProjectPrefixes"))).toArray
  let targetPrefix ← checked (decodeName (← checked (field config "targetProjectPrefix")))
  unless !projectPrefixes.isEmpty && !sourcePrefixes.isEmpty && targetPrefix != .anonymous do
    throwError "Empty project-prefix policy"
  let mut result : Array Relocation := #[]
  for key in #["projectMap", "standardRenames"] do
    for row in ← checked (arrayField config key) do
      let original ← checked (decodeName (← checked (field row "originalName")))
      let targetJson ← checked (field row "targetName")
      let target ← if targetJson == Json.null then do
        unless key == "projectMap" && (← checked (stringField row "mappingRole")) == "prior-accepted-required" do
          throwError "Only accepted legacy prior identities may need platform Name resolution"
        let display ← checked (stringField row "target")
        let owner := (← checked (stringField row "targetOwner")).toName
        let env ← getEnv
        let matchingTargets := env.constants.fold (fun acc n _ =>
          if n.toString == display && moduleOf env n == some owner then acc.push n else acc) (#[] : Array Name)
        unless matchingTargets.size == 1 do
          throwError "Accepted prior target Name is not unique at expected owner: {display}"
        pure matchingTargets[0]!
      else checked (decodeName targetJson)
      unless original.toString == (← checked (stringField row "original")) &&
        target.toString == (← checked (stringField row "target")) do
        throwError "Structural relocation name mismatch"
      if key == "standardRenames" then
        if projectPrefixes.any (·.isPrefixOf original) || projectPrefixes.any (·.isPrefixOf target) then
          throwError "Standard relocation contains project name"
        unless (← checked (stringField row "evidence")).length > 0 do
          throwError "Standard rename requires reviewed compiler/source evidence"
      else
        unless sourcePrefixes.any (·.isPrefixOf original) && target == targetPrefix ++ original do
          throwError "Unexpected project relocation {original} -> {target}"
      if result.any (fun r => r.original == original || r.target == target) then
        throwError "Duplicate or non-injective relocation {original} -> {target}"
      let indicesJson ← checked (field row "targetToSourceUniverseIndices")
      let permutation ← if indicesJson == Json.null then pure none else
        pure (some (← checked ((← checked indicesJson.getArr?).mapM Json.getNat?)))
      let expectedInstance ← if key == "projectMap" then
        pure (some (← checked (row.getObjValAs? Bool "expectedIsInstance"))) else pure none
      let expectedAxioms ← if key == "projectMap" then
        pure (some (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray) else pure none
      result := result.push ⟨original, target, permutation, expectedInstance, expectedAxioms⟩
  let excludedRows ← checked (arrayField config "excludedOriginalDeclarations")
  let excludedSourceNames ← excludedRows.mapM fun row => do
    checked (decodeName (← checked (field row "originalName")))
  unless excludedSourceNames.size == excludedSourceNames.toList.eraseDups.length &&
      excludedSourceNames.all (fun n => (`_private).isPrefixOf n && !(result.any (·.original == n))) do
    throwError "Excluded original-private identities overlap relocation map or are not private"
  return ⟨result, projectPrefixes, sourcePrefixes, targetPrefix, excludedSourceNames, #[], #[]⟩

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No imported owner for {name}"
  unless modules.contains owner do
    throwError "Forbidden dependency {name}, owner {owner}"
  if rs.sourcePrefixes.any (·.isPrefixOf name) || rs.excludedSourceNames.contains name then
    throwError "Unrelocated original project dependency {name}"

def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  if let .axiomInfo _ := ci then throwError "Carrier declares an axiom {name}"
  let axs ← collectAxioms name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"carrier {name}" axs
  ensureStandard s!"carrier type {name}" taxs
  let value? := ci.value? (allowOpaque := true)
  let vaxs ← match value? with
    | some v => expressionAxioms v
    | none => pure #[]
  ensureStandard s!"carrier value {name}" vaxs
  for expr in #[ci.type] ++ value?.toArray do
    for dep in expr.getUsedConstants do allowedOwner rs modules dep
  if let .recInfo r := ci then
    for rule in r.rules do
      for dep in rule.rhs.getUsedConstants do allowedOwner rs modules dep
      ensureStandard s!"recursor rule {name}" (← expressionAxioms rule.rhs)
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("hasValue", toJson value?.isSome),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name))]

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

-- These facts establish actual platform absence and inventory, not a theorem alias.
def boundPlatformHelperEvidence (config : Json) (key : String) : MetaM Json := do
  let evidence ← checked (field config "platformHelperEvidence")
  let binding ← checked (field evidence key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do
    throwError "Platform helper evidence changed after hash binding: {key}"
  unless (← checked (stringField binding "sha256")).length == 64 do
    throwError "Missing external SHA256 binding for platform helper evidence: {key}"
  return actual

def verifyPlatformHelperFacts (config : Json) : MetaM Json := do
  let facts ← boundPlatformHelperEvidence config "facts"
  let receipt ← boundPlatformHelperEvidence config "receipt"
  unless (← checked (stringField receipt "job_id")) == "ci-014164-c01e488c" &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Expected successful actual platform helper query receipt"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
    throwError "Actual platform helper query exit code is not zero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do
    throwError "Wrong actual platform helper query workspace mode"
  unless (← checked (stringField facts "schema")) == "tate-theta-platform-helper-facts-v1" &&
      (← checked (stringField facts "compilerVersion")) == Lean.versionString &&
      (← checked (facts.getObjValAs? Nat "sourceRecordCount")) == 117 &&
      (← checked (facts.getObjValAs? Nat "selectedSourceCount")) == 78 &&
      (← checked (facts.getObjValAs? Nat "selectedMissingCount")) == 1 &&
      (← checked (facts.getObjValAs? Nat "ownedDeclarationCount")) == 77 do
    throwError "Unexpected actual platform helper query dimensions/compiler"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field facts key)) == (← checked (field config key)) do
      throwError "Actual platform helper query provenance changed: {key}"
  unless (← checked (arrayField facts "targetOnlyNames")).isEmpty do
    throwError "This exact equation-proof treatment expects no target-only declaration"
  let env ← getEnv
  let moduleRows ← checked (arrayField config "modules")
  let modules ← moduleRows.mapM fun row => do
    return (← checked (stringField row "target")).toName
  let actualOwned := env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)
  let ownedRows ← checked (arrayField facts "ownedDeclarations")
  let ownedNames ← ownedRows.mapM fun row => do
    checked (decodeName (← checked (field row "nameExpr")))
  unless ownedNames.size == 77 && ownedNames.toList.eraseDups.length == ownedNames.size &&
      actualOwned.size == ownedNames.size && actualOwned.all ownedNames.contains do
    throwError "Actual current owned declaration set changed after platform query"
  for row in ownedRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    let ci ← getConstInfo name
    unless name.toString == (← checked (stringField row "name")) &&
        moduleOf env name == some (← checked (stringField row "module")).toName &&
        kind ci == (← checked (stringField row "constantKind")) &&
        Json.arr (ci.levelParams.toArray.map encodeName) == (← checked (field row "levelParams")) &&
        Lean.Meta.isInstanceCore env name == (← checked (row.getObjValAs? Bool "isInstance")) do
      throwError "Actual owned declaration identity/owner/kind/universes/instance changed: {name}"
    unless !(← checked (row.getObjValAs? Bool "hasSorryAx")) do
      throwError "Actual platform query contains sorryAx: {name}"
    for key in #["axioms", "typeAxioms", "valueAxioms"] do
      for ax in ← checked (arrayField row key) do
        unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
          throwError "Unexpected actual platform query axiom: {name}"
  let helperRows ← checked (arrayField facts "helperFacts")
  for row in helperRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    unless ownedNames.contains name do throwError "Unowned actual helper fact {name}"
    let ci ← getConstInfo name
    unless (← checked (encodeExpr ci.type)) == (← checked (field row "elaboratedExpr")) do
      throwError "Actual platform helper type changed: {name}"
    let value ← match ci.value? (allowOpaque := true) with
      | none => pure Json.null | some expr => checked (encodeExpr expr)
    unless value == (← checked (field row "valueExpr")) do
      throwError "Actual platform helper value changed: {name}"
  let candidates ← checked (arrayField facts "expectedCurrentCandidates")
  unless candidates.size == 111 do throwError "Wrong actual public source candidate count"
  let mut selectedCount := 0
  let mut missingCount := 0
  for row in candidates do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let target ← checked (decodeName (← checked (field row "candidateTargetName")))
    let selected ← checked (row.getObjValAs? Bool "selected")
    let present ← checked (row.getObjValAs? Bool "present")
    unless env.contains target == present do
      throwError "Actual source candidate presence changed: {original}"
    if selected then
      selectedCount := selectedCount + 1
      if !present then
        missingCount := missingCount + 1
        unless original == `TateCurvesTheta.TateParameter.tateJ.eq_1 do
          throwError "Unapproved missing selected declaration {original}"
  unless selectedCount == 78 && missingCount == 1 do
    throwError "Expected the exact single absent tateJ equation theorem"
  return facts

def installExactTateJEquationProof (rs : Relocations) (allowedOwners : Array Name)
    (source config facts : Json) : MetaM (Relocations × Array Json) := do
  let original := `TateCurvesTheta.TateParameter.tateJ.eq_1
  let parent := `TateCurvesTheta.TateParameter.tateJ
  let candidate := `AbcAdaptation.Reference.TateCurvesTheta.TateParameter.tateJ.eq_1
  let parentTarget := `AbcAdaptation.Reference.TateCurvesTheta.TateParameter.tateJ
  let env ← getEnv
  unless !(rs.any (·.original == original)) && rs.sourceProofValues.isEmpty &&
      !(env.contains candidate) do
    throwError "Equation proof value must have no named target identity"
  let configured ← checked (arrayField config "proofValueResolutions")
  let records ← checked (arrayField source "records")
  let originalRows := records.filter fun row => (stringField row "name").toOption == some original.toString
  unless configured.size == 1 && originalRows.size == 1 do
    throwError "Only the exact single tateJ equation proof may use a source value"
  let binding := configured[0]!
  let record := originalRows[0]!
  unless (← checked (decodeName (← checked (field binding "originalName")))) == original &&
      record == (← checked (field binding "sourceRecord")) &&
      (← checked (field binding "standaloneTargetIdentity")) == Json.null &&
      (← checked (stringField binding "parentOriginal")) == parent.toString do
    throwError "Exact tateJ source proof/configuration binding differs"
  unless (← checked (decodeName (← checked (field record "nameExpr")))) == original &&
      (← checked (stringField record "module")) == "TateCurvesTheta.TateCurve.JInvariant" &&
      (← checked (stringField record "constantKind")) == "theorem" &&
      (← checked (record.getObjValAs? Bool "selected")) &&
      (← checked (record.getObjValAs? Bool "isProposition")) &&
      !(← checked (record.getObjValAs? Bool "isInstance")) do
    throwError "Exact equation source record is not a selected non-instance theorem"
  let parentRows := records.filter fun row => (stringField row "name").toOption == some parent.toString
  unless parentRows.size == 1 &&
      (← checked (parentRows[0]!.getObjValAs? Bool "selected")) &&
      !(← checked (parentRows[0]!.getObjValAs? Bool "isProposition")) &&
      (← checked (stringField parentRows[0]! "constantKind")) == "definition" &&
      (← checked (field parentRows[0]! "valueExpr")) != Json.null do
    throwError "Exact equation proof requires a complete selected parent data definition"
  let parentFacts := (← checked (arrayField facts "helperFacts")).filter fun row =>
    (stringField row "name").toOption == some parentTarget.toString
  unless parentFacts.size == 1 && parentFacts[0]! == (← checked (field binding "actualParentFact")) do
    throwError "Missing exact actual target parent value evidence"
  let some parentRelocation := rs.find? (·.original == parent) |
    throwError "Missing ordinary named parent relocation"
  unless parentRelocation.target == parentTarget do throwError "Wrong exact parent target"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected genuine equation source axiom"
  let expectedAxiomList ← namesFromJson (← checked (field binding "expectedSourceAxioms"))
  let expectedAxioms := expectedAxiomList.toArray
  let sourceAxioms := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxioms.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Exact equation proof source axiom closure differs from accepted graph"
  let params ← namesFromJson (← checked (field record "levelParams"))
  unless params.eraseDups == params do throwError "Repeated exact source proof universe parameter"
  let type ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let valueJson ← checked (field record "valueExpr")
  unless valueJson != Json.null do throwError "Genuine equation source proof value is missing"
  let value ← checked (decodeExpr rs valueJson)
  unless binderInventory type == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
    throwError "Genuine equation source type BinderInfo inventory changed"
  let levels := (canonicalLevels params.length).map Level.param
  let canonicalType := type.instantiateLevelParams params levels
  let canonicalValue := value.instantiateLevelParams params levels
  unless (← isProp canonicalType) do throwError "Genuine equation source type is not a proposition"
  let inferredType ← kernelCheck "genuine tateJ equation source proof" canonicalValue
  kernelTypeEq "genuine tateJ equation proof inhabits exact relocated source type" inferredType canonicalType
  unless binderPlacement inferredType == binderPlacement canonicalType do
    throwError "Genuine equation proof inferred type BinderInfo placement differs"
  let taxs ← expressionAxioms canonicalType
  let vaxs ← expressionAxioms canonicalValue
  ensureStandard "exact genuine tateJ equation source type" taxs
  ensureStandard "exact genuine tateJ equation source value" vaxs
  for term in #[canonicalType, canonicalValue] do
    for dependency in term.getUsedConstants do allowedOwner rs allowedOwners dependency
  let rs := { rs with sourceProofValues := #[(original, (params, value))] }
  return (rs, #[Json.mkObj [
    ("original", toJson original.toString), ("originalName", encodeName original),
    ("resolution", toJson "genuine-exported-original-proof-value"),
    ("standaloneTargetIdentity", Json.null), ("sourceRecord", record),
    ("originalTypeBinderInfoPreserved", toJson true),
    ("inferredTypeBinderInfoPlacementPreserved", toJson true),
    ("exactOriginalTypeKernelChecked", toJson true),
    ("genuineOriginalValueInhabitsExactOriginalType", toJson true),
    ("expandedType", ← checked (encodeExpr type)), ("expandedValue", ← checked (encodeExpr value)),
    ("expandedTypeAxioms", toJson (taxs.map Name.toString)),
    ("expandedValueAxioms", toJson (vaxs.map Name.toString)),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("parentOriginal", toJson parent.toString), ("parentTarget", encodeName parentTarget),
    ("parentWholeValueEqualityRequired", toJson true),
    ("parentKernelDefinitionalValueEqualityRequired", toJson true),
    ("actualPlatformAbsenceEvidenceVerified", toJson true),
    ("actualPlatformQueryJob", toJson "ci-014164-c01e488c"),
    ("expandedDependenciesHaveAllowedOwners", toJson true), ("hasSorryAx", toJson false)]])

def boundStandardProofEvidence (config : Json) (key : String) : MetaM Json := do
  let compatibility ← checked (field config "standardProofCompatibility")
  let evidence ← checked (field compatibility "evidence")
  let binding ← checked (field evidence key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do
    throwError "Exact standard proof evidence changed after binding: {key}"
  unless (← checked (stringField binding "sha256")).length == 64 do
    throwError "Missing external SHA256 binding for exact standard proof evidence: {key}"
  return actual

def installExactFiniteQuotientsProof (rs : Relocations) (allowedOwners : Array Name)
    (config : Json) : MetaM (Relocations × Json) := do
  let original := `NumberField.RingOfIntegers.instHasFiniteQuotients
  let className := `Ring.HasFiniteQuotients
  let compatibility ← checked (field config "standardProofCompatibility")
  unless (← checked (stringField compatibility "schema")) == "tate-theta-exact-standard-proof-compatibility-v1" do
    throwError "Wrong exact standard proof compatibility schema"
  let source ← boundStandardProofEvidence config "sourceFacts"
  let sourceReceipt ← boundStandardProofEvidence config "sourceReceipt"
  let platform ← boundStandardProofEvidence config "platformFacts"
  let platformReceipt ← boundStandardProofEvidence config "platformReceipt"
  unless (← checked (stringField sourceReceipt "job_id")) == "ci-014215-2414b895" &&
      (← checked (stringField sourceReceipt "status")) == "succeeded" &&
      (← checked (stringField platformReceipt "job_id")) == (← checked (stringField compatibility "platformJob")) &&
      (← checked (stringField platformReceipt "status")) == "succeeded" do
    throwError "Expected successful exact source/current standard proof query receipts"
  for receipt in #[sourceReceipt, platformReceipt] do
    let result ← checked (field receipt "result")
    unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
      throwError "Exact standard proof query exit code is not zero"
    let snapshot ← checked (field result "snapshot")
    unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
        (← checked (field snapshot "snapshot_id")) == Json.null do
      throwError "Wrong exact standard proof query workspace mode"
  unless (← checked (stringField source "schema")) == "tate-theta-exact-standard-source-facts-v1" &&
      (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" &&
      (← checked (stringField platform "schema")) == "tate-theta-exact-standard-platform-facts-v1" &&
      (← checked (stringField platform "compilerVersion")) == Lean.versionString &&
      (← checked (source.getObjValAs? Nat "selectedOriginalScopeCount")) == 78 &&
      (← checked (source.getObjValAs? Nat "relevantStandardNameCount")) == 270 &&
      (← checked (platform.getObjValAs? Nat "relevantStandardNameCount")) == 270 do
    throwError "Wrong exact standard proof query scope/compiler"
  for facts in #[source, platform] do
    for key in #["inventorySha256", "graphSha256"] do
      unless (← checked (field facts key)) == (← checked (field config key)) do
        throwError "Exact standard proof query provenance changed: {key}"
  let missingList ← namesFromJson (← checked (field platform "missingRelevantStandardNames"))
  let missing := missingList.toArray
  unless missing == #[original] do
    throwError "Unexpected missing standard API beyond the exact finite-quotients wrapper"
  let env ← getEnv
  unless !(env.contains original) && rs.standardProofValues.isEmpty &&
      !(rs.any (·.original == original)) && Lean.isClass env className do
    throwError "Exact standard proof wrapper absence/class registration changed"
  let presence ← checked (arrayField platform "standardPresence")
  unless presence.size == 270 do throwError "Wrong actual relevant standard presence inventory"
  for row in presence do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    unless env.contains name == (← checked (row.getObjValAs? Bool "present")) do
      throwError "Actual standard name presence changed after exact query: {name}"
  let sourceBodyAttempt ← checked (field platform "genuineSourceBodyAttempt")
  unless !(← checked (sourceBodyAttempt.getObjValAs? Bool "succeeded")) do
    throwError "Expected the recorded original AddGroup.FG/AddMonoid.FG API failure"
  let nativeAttempt ← checked (field platform "nativeProofAttempt")
  unless (← checked (nativeAttempt.getObjValAs? Bool "succeeded")) &&
      (← checked (nativeAttempt.getObjValAs? Bool "kernelCheckedExactSourceType")) &&
      (← checked (nativeAttempt.getObjValAs? Bool "dependencyOwnersStandardOnly")) &&
      !(← checked (nativeAttempt.getObjValAs? Bool "hasSorryAx")) do
    throwError "The actual native standard proof has no successful exact original-type kernel check"
  let shapeChecks ← checked (arrayField platform "originalCurrentStandardShapeChecks")
  unless shapeChecks.size == 7 do throwError "Expected all7 actual original/current class API checks"
  for row in shapeChecks do
    unless (← checked (row.getObjValAs? Bool "succeeded")) do
      throwError "Original/current standard class API check did not pass"
  let records ← checked (arrayField source "facts")
  unless records.size == 8 do throwError "Expected8 focused actual original standard records"
  let sourceRows := records.filter fun row => (stringField row "name").toOption == some original.toString
  unless sourceRows.size == 1 do throwError "Missing exact actual original standard wrapper record"
  let record := sourceRows[0]!
  unless (← checked (stringField record "constantKind")) == "theorem" &&
      (← checked (record.getObjValAs? Bool "isProposition")) &&
      (← checked (record.getObjValAs? Bool "isInstance")) &&
      !(← checked (record.getObjValAs? Bool "hasSorryAx")) do
    throwError "The exact original standard wrapper is not a proposition-valued theorem instance"
  let actualRows ← checked (arrayField platform "facts")
  unless actualRows.size == 7 do throwError "Expected7 exact actual current class API records"
  for originalRecord in records do
    let name ← checked (decodeName (← checked (field originalRecord "nameExpr")))
    if name != original then
      let matching := actualRows.filter fun row => (field row "nameExpr").toOption == some (encodeName name)
      unless matching.size == 1 do throwError "Missing actual current standard API fact {name}"
      let ci ← getConstInfo name
      unless (← checked (encodeExpr ci.type)) == (← checked (field matching[0]! "elaboratedExpr")) do
        throwError "Actual current standard API type changed: {name}"
      let value ← match ci.value? (allowOpaque := true) with
        | none => pure Json.null | some value => checked (encodeExpr value)
      unless value == (← checked (field matching[0]! "valueExpr")) do
        throwError "Actual current standard API value changed: {name}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original standard wrapper axiom"
  let params ← namesFromJson (← checked (field record "levelParams"))
  unless params.eraseDups == params do throwError "Duplicate exact standard proof universe parameter"
  let type ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let nativeParams ← namesFromJson (← checked (field compatibility "nativeLevelParams"))
  unless params.length == 1 && nativeParams == [Name.num (Name.str .anonymous "_finiteQuotientsQueryUniverse") 0] do
    throwError "Unexpected actual native/original standard proof universe mapping"
  let nativeType ← checked (decodeExpr rs (← checked (field nativeAttempt "type")))
  let nativeValue ← checked (decodeExpr rs (← checked (field nativeAttempt "value")))
  let originalLevels := params.map Level.param
  let restoredType := nativeType.instantiateLevelParams nativeParams originalLevels
  let value := nativeValue.instantiateLevelParams nativeParams originalLevels
  kernelTypeEq "actual native proof type restored to exact original universes" restoredType type
  unless binderPlacement restoredType == binderPlacement type && binderInventory restoredType == binderInventory type do
    throwError "Actual native/original standard proof type BinderInfo differs"
  let levels := (canonicalLevels params.length).map Level.param
  let canonicalType := type.instantiateLevelParams params levels
  let canonicalValue := value.instantiateLevelParams params levels
  unless (← isProp canonicalType) &&
      binderInventory type == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
    throwError "Exact original standard proof proposition/type BinderInfo changed"
  let inferredType ← kernelCheck "actual native finite-quotients proof" canonicalValue
  kernelTypeEq "actual native finite-quotients proof inhabits exact original type" inferredType canonicalType
  unless binderPlacement inferredType == binderPlacement canonicalType && binderInventory inferredType == binderInventory canonicalType do
    throwError "Actual native standard proof inferred type BinderInfo differs"
  let taxs ← expressionAxioms canonicalType
  let vaxs ← expressionAxioms canonicalValue
  ensureStandard "exact original finite-quotients proof type" taxs
  ensureStandard "exact original finite-quotients proof value" vaxs
  let standardPrefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
  for term in #[canonicalType, canonicalValue] do
    for name in term.getUsedConstants do
      allowedOwner rs allowedOwners name
      let some owner := moduleOf env name | throwError "Missing exact standard proof dependency owner {name}"
      unless standardPrefixes.any (·.isPrefixOf owner) do
        throwError "Nonstandard owner in exact standard proof {name}: {owner}"
  let rs := { rs with standardProofValues := #[(original, (params, value))] }
  return (rs, Json.mkObj [
    ("schema", toJson "tate-theta-exact-standard-proof-resolution-v1"),
    ("resolution", toJson "kernel-checked-native-proof-at-exact-original-type"),
    ("original", toJson original.toString), ("originalName", encodeName original),
    ("standaloneTargetIdentity", Json.null),
    ("method", toJson "inline actual kernel-checked native proof at the exact original proposition-valued instance type"),
    ("originalSourceBodyAttempt", sourceBodyAttempt),
    ("actualNativeProofAttempt", nativeAttempt),
    ("nativeLevelParams", Json.arr (nativeParams.toArray.map encodeName)),
    ("restoredSourceLevelParams", Json.arr (params.toArray.map encodeName)),
    ("nativeUniversesRestoredToOriginal", toJson true),
    ("sourceRecord", record), ("kernelCheckedExactSourceType", toJson true),
    ("originalTypeBinderInfoPreserved", toJson true),
    ("inferredTypeBinderInfoPreserved", toJson true),
    ("originalCurrentClassAPIChecked", toJson true),
    ("expandedType", ← checked (encodeExpr type)), ("expandedValue", ← checked (encodeExpr value)),
    ("expandedTypeAxioms", toJson (taxs.map Name.toString)),
    ("expandedValueAxioms", toJson (vaxs.map Name.toString)),
    ("dependencyOwnersStandardOnly", toJson true), ("hasSorryAx", toJson false),
    ("requiredDataConsumers", ← checked (field compatibility "requiredDataConsumers")),
    ("allConsumerWholeDataKernelDefinitionalEqualitiesRequired", toJson true)])

def compareRecord (rs : Relocations) (allowedOwners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.eraseDups == sourceParams do throwError "Duplicate universe parameter {original}"
  unless sourceParams.length == target.levelParams.length do
    throwError "Universe parameter count differs for {original}"
  unless (← checked (stringField record "constantKind")) == kind target do
    throwError "ConstantInfo kind differs for {original}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original axiom for {original}"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "Missing map entry {original}"
  let some expectedAxioms := rel.expectedAxioms |
    throwError "Missing accepted-graph source axiom inventory {original}"
  let sourceAxiomNames := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxiomNames.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Original axiom closure differs from accepted compiler graph {original}"
  let some expectedInstance := rel.expectedInstance |
    throwError "Missing accepted-graph instance flag {original}"
  unless (← checked (record.getObjValAs? Bool "isInstance")) == expectedInstance do
    throwError "Exported original instance flag differs from accepted graph {original}"
  unless Lean.Meta.isInstanceCore (← getEnv) target.name == expectedInstance do
    throwError "Instance registry membership differs for {original}"
  let targetLevels ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let reordered ← checked (reorder indices canonical.toArray)
      pure reordered.toList
  let sourceTypeRaw ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams targetLevels
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory sourceType do
    throwError "Source serialization BinderInfo inventory differs for {original}"
  unless binderInventory sourceType == binderInventory targetType do
    throwError "Full type BinderInfo inventory differs for {original}"
  unless binderPlacement sourceType == binderPlacement targetType do
    throwError "BinderInfo placement inside the type differs for {original}"
  kernelTypeEq s!"original versus target type {original}" sourceType targetType
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do
    throwError "Inductive/constructor/recursor computation shape differs for {original}"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  unless sourceProp == (← isProp target.type) do throwError "Proposition status differs {original}"
  let mut comparedValue := false
  let mut definitionallyEqualValue := false
  let originalValueJson ← checked (field record "valueExpr")
  -- Proof declarations are audited by exact type and axiom closure. For a data
  -- value containing proof fields, Kernel.isDefEq itself uses proof irrelevance.
  if !sourceProp && originalValueJson != Json.null then
    let sourceValue := (← checked (decodeExpr rs originalValueJson)).instantiateLevelParams sourceParams canonical
    let some targetValue := target.value? (allowOpaque := true) |
      throwError "Target value missing for {original}"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq s!"original value inhabits original type {original}"
      (← kernelCheck s!"original value {original}" sourceValue) sourceType
    kernelTypeEq s!"target value inhabits target type {original}"
      (← kernelCheck s!"target value {original}" targetValue) targetType
    kernelTermEq s!"original versus target computational value {original}" sourceValue targetValue
    definitionallyEqualValue := true
    comparedValue := true
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut comparedRules := 0
  if let .recInfo r := target then
    unless rules.size == r.rules.length do throwError "Recursor rule count differs {original}"
    for i in [:rules.size] do
      let sourceRhs := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let targetRhs := r.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      kernelTermEq s!"recursor rule {original} #{i}" sourceRhs targetRhs
      comparedRules := comparedRules + 1
  else
    unless rules.isEmpty do throwError "Unexpected original recursor rules {original}"
  let sourceStruct ← checked (field record "structure")
  unless (sourceStruct != Json.null) == (getStructureInfo? (← getEnv) target.name).isSome do
    throwError "Structure metadata presence differs {original}"
  if sourceStruct != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name |
      throwError "Target structure metadata missing {target.name}"
    unless (← checked (field sourceStruct "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do
      throwError "Complete structure field/parent metadata differs {original}"
    let autoParams ← checked (arrayField sourceStruct "fieldAutoParamExprs")
    unless autoParams.size == info.fieldInfo.size do
      throwError "Structure field autoParam count differs {original}"
    for i in [:autoParams.size] do
      match autoParams[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some targetExpr =>
        if sourceJson == Json.null then throwError "Missing source autoParam {original} #{i}"
        let sourceExpr := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let targetExpr := targetExpr.instantiateLevelParams target.levelParams targetLevels
        unless binderPlacement sourceExpr == binderPlacement targetExpr do
          throwError "Structure autoParam BinderInfo placement differs {original} #{i}"
        kernelTermEq s!"structure field autoParam {original} #{i}" sourceExpr targetExpr
      | sourceJson, none =>
        unless sourceJson == Json.null do throwError "Missing target autoParam {original} #{i}"
    unless (← checked (field sourceStruct "fieldsInConstructorOrder")) ==
        toJson (info.fieldNames.map Name.toString) do
      throwError "Structure field order differs {original}"
    let projections ← namesFromJson (← checked (field sourceStruct "projections"))
    let targetProjections ← projections.toArray.mapM fun n => checked (relocated rs n)
    unless targetProjections == info.fieldInfo.map (·.projFn) do
      throwError "Structure accessor identities/order differ {original}"
    for p in targetProjections do
      unless rs.any (·.target == p) do throwError "Unaudited structure accessor {p}"
  return Json.mkObj [("original", toJson original.toString), ("originalName", encodeName original),
    ("target", toJson target.name.toString), ("targetName", encodeName target.name),
    ("sourceRecord", record), ("kernelTypeEqual", toJson true),
    ("allExpressionBinderInfoEqual", toJson true),
    ("binderInfoPlacementEqual", toJson true),
    ("computationShapeEqual", toJson true), ("completeStructureMetadataEqual", toJson true),
    ("kernelValueEqual", toJson definitionallyEqualValue),
    ("computationalValueEqualityChecked", toJson comparedValue),
    ("kernelPropositionalValueEquality", toJson false),
    ("propositionalValueEqualityEvidence", Json.null),
    ("proofDeclaration", toJson sourceProp), ("recursorRulesCompared", toJson comparedRules),
    ("instanceRegistryMatchesAcceptedGraph", toJson true),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("expectedIsInstance", toJson expectedInstance),
    ("universeOriginalOrder", Json.arr (sourceParams.toArray.map encodeName)),
    ("universeTargetOrder", Json.arr (target.levelParams.toArray.map encodeName)),
    ("targetToSourceUniverseIndices", match rel.permutation with | none => Json.null | some a => toJson a)]

def audit : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected platform4.33.1, got {Lean.versionString}"
  let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
  unless (← checked (stringField config "schema")) == "next-carrier-kernel-audit-config-v3" do
    throwError "Wrong config schema"
  let source ← jsonFile (← checked (stringField config "originalExprFile"))
  unless (← checked (stringField source "schema")) == "foundation-original-exprs-v2" &&
      (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" do
    throwError "Wrong original compiler/schema"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field source key)) == (← checked (field config key)) do
      throwError "Input provenance hash differs: {key}"
  let records ← checked (arrayField source "records")
  let expectedRecordCount ← checked (config.getObjValAs? Nat "expectedRecordCount")
  let expectedSelectedCount ← checked (config.getObjValAs? Nat "expectedSelectedCount")
  unless records.size == expectedRecordCount do throwError "Original record count differs from config"
  unless (← checked (source.getObjValAs? Nat "recordCount")) == expectedRecordCount do
    throwError "Exporter record count differs from config"
  unless (← checked (source.getObjValAs? Nat "selectedCount")) == expectedSelectedCount do
    throwError "Exporter selected count differs from config"
  let moduleRows ← checked (arrayField config "modules")
  unless moduleRows.size == (← checked (config.getObjValAs? Nat "expectedModuleCount")) do
    throwError "Module count differs from config"
  let modules ← moduleRows.mapM fun row => return (← checked (stringField row "target")).toName
  let rs ← readRelocations config
  let env ← getEnv
  let dependencyModules := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
  let standardPrefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
  let allowedProjectModules := modules ++ dependencyModules
  unless allowedProjectModules.size == allowedProjectModules.toList.eraseDups.length do
    throwError "Duplicate allowed project modules"
  let mut allowedOwners := #[]
  for imported in env.header.moduleNames do
    unless standardPrefixes.any (·.isPrefixOf imported) || allowedProjectModules.contains imported do
      throwError "Forbidden imported module {imported}"
    allowedOwners := allowedOwners.push imported
  let (rs, standardProofReport) ← installExactFiniteQuotientsProof rs allowedOwners config
  let platformFacts ← verifyPlatformHelperFacts config
  let (rs, proofResolutionReports) ← installExactTateJEquationProof rs allowedOwners source config platformFacts
  let directImports := ((env.header.imports.map (·.module)).toList.eraseDups).toArray.filter (· != `Init)
  let reviewedStandardImports := (← checked (config.getObjValAs? (Array String) "auditorStandardImports")).map String.toName
  unless reviewedStandardImports == #[`Mathlib.RingTheory.Ideal.Quotient.HasFiniteQuotients] do
    throwError "Unexpected auditor-only standard import"
  let expectedDirectImports := #[`Lean] ++ reviewedStandardImports ++ allowedProjectModules
  unless directImports.size == expectedDirectImports.size && expectedDirectImports.all directImports.contains do
    throwError "Auditor direct imports differ from exact reviewed standard and Def-module set"
  let mut directImportReports : Array Json := #[]
  for row in moduleRows do
    let owner := (← checked (stringField row "target")).toName
    let expected := (← checked (row.getObjValAs? (Array String) "allowedDirectImports")).map String.toName
    unless expected.size == expected.toList.eraseDups.length do throwError "Duplicate direct imports {owner}"
    let mut actual : Array Name := #[]
    let mut ownerFound := false
    for i in [:env.header.moduleNames.size] do
      if env.header.moduleNames[i]! == owner then
        let some data := env.header.moduleData[i]? | throwError "Module data missing {owner}"
        actual := ((data.imports.map (·.module)).toList.eraseDups).toArray.filter (· != `Init)
        ownerFound := true
    unless ownerFound && actual.size == expected.size && actual.all expected.contains do
      throwError "Target direct imports differ from precise configured imports {owner}"
    if actual.contains `Mathlib then throwError "Broad Mathlib import forbidden {owner}"
    directImportReports := directImportReports.push (Json.mkObj [
      ("module", toJson owner.toString), ("actual", toJson (actual.map Name.toString)),
      ("exactConfiguredImportSet", toJson true)])
  let declarations := env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)
  unless declarations.size > 0 do throwError "No carrier declarations"
  let mut ownedReports := #[]
  let mut comparisons := #[]
  let mut seenOriginal : Array Name := #[]
  let mut requiredCount := 0
  let mut requiredNamedCount := 0
  let mut resolvedProofNames : Array Name := #[]
  let excludedRows ← checked (arrayField config "excludedOriginalDeclarations")
  let mut excludedSeen : Array Name := #[]
  let mut missingOptional := #[]
  for record in records do
    let original ← checked (decodeName (← checked (field record "nameExpr")))
    if seenOriginal.contains original then throwError "Duplicate original record {original}"
    seenOriginal := seenOriginal.push original
    unless original.toString == (← checked (stringField record "name")) do
      throwError "Original name identity differs"
    let sourceOwner ← checked (stringField record "module")
    let ownerRows := moduleRows.filter fun row => (stringField row "original").toOption == some sourceOwner
    unless ownerRows.size == 1 do throwError "Original module not configured: {sourceOwner}"
    for key in #["sourceSha256", "normalizedSha256"] do
      unless (← checked (field record key)) == (← checked (field ownerRows[0]! key)) do
        throwError "Original source provenance differs: {key}"
    let selected ← checked (record.getObjValAs? Bool "selected")
    let excluded := excludedRows.filter fun row => (field row "originalName").toOption == some (encodeName original)
    unless excluded.size <= 1 do throwError "Duplicate excluded original {original}"
    if !excluded.isEmpty then
      unless !selected && !(rs.any (·.original == original)) && (`_private).isPrefixOf original do
        throwError "Invalid unselected-private exclusion {original}"
      unless (← checked (field excluded[0]! "target")) == Json.null do
        throwError "Excluded private declaration must have no target identity {original}"
      excludedSeen := excludedSeen.push original
      missingOptional := missingOptional.push (toJson original.toString)
      continue
    if original == `TateCurvesTheta.TateParameter.tateJ.eq_1 then
      unless selected && proofResolutionReports.size == 1 &&
          (← checked (stringField proofResolutionReports[0]! "original")) == original.toString do
        throwError "Unvalidated exact mandatory source equation proof"
      requiredCount := requiredCount + 1
      resolvedProofNames := resolvedProofNames.push original
      continue
    let targetName ← checked (relocated rs original)
    if selected then requiredCount := requiredCount + 1
    unless env.contains targetName do
      if selected then throwError "Required generated/source declaration missing: {original} -> {targetName}"
      missingOptional := missingOptional.push (toJson original.toString)
      continue
    unless moduleOf env targetName == some (← checked (stringField ownerRows[0]! "target")).toName do
      throwError "Wrong target artifact owner {targetName}"
    comparisons := comparisons.push (← compareRecord rs allowedOwners record (← getConstInfo targetName))
    if selected then requiredNamedCount := requiredNamedCount + 1
  unless requiredCount == expectedSelectedCount do throwError "Mandatory selected count differs from config"
  unless excludedSeen.size == excludedRows.size do
    throwError "Excluded original declaration set differs from actual source records"
  unless requiredNamedCount == 77 &&
      requiredNamedCount == (← checked (config.getObjValAs? Nat "expectedNamedSelectedCount")) &&
      proofResolutionReports.size == 1 && resolvedProofNames.size == 1 &&
      proofResolutionReports.size == (← checked (config.getObjValAs? Nat "expectedProofValueResolutionCount")) &&
      requiredNamedCount + proofResolutionReports.size == expectedSelectedCount do
    throwError "Exact77 named plus1 genuine source proof dimensions differ"
  let parentRows := comparisons.filter fun row =>
    (stringField row "original").toOption == some "TateCurvesTheta.TateParameter.tateJ"
  unless parentRows.size == 1 &&
      !(← checked (parentRows[0]!.getObjValAs? Bool "proofDeclaration")) &&
      (← checked (parentRows[0]!.getObjValAs? Bool "computationalValueEqualityChecked")) &&
      (← checked (parentRows[0]!.getObjValAs? Bool "kernelValueEqual")) &&
      !(← checked (parentRows[0]!.getObjValAs? Bool "kernelPropositionalValueEquality")) do
    throwError "Exact source equation proof requires the full named parent data value to be kernel definitionally equal"
  let standardCompatibility ← checked (field config "standardProofCompatibility")
  let requiredDataConsumers ← checked (standardCompatibility.getObjValAs? (Array String) "requiredDataConsumers")
  unless requiredDataConsumers.size == 9 && requiredDataConsumers.toList.eraseDups.length == 9 do
    throwError "Expected the exact9 selected computational consumers of the standard proof"
  for original in requiredDataConsumers do
    let rows := comparisons.filter fun row => (stringField row "original").toOption == some original
    unless rows.size == 1 && !(← checked (rows[0]!.getObjValAs? Bool "proofDeclaration")) &&
        (← checked (rows[0]!.getObjValAs? Bool "computationalValueEqualityChecked")) &&
        (← checked (rows[0]!.getObjValAs? Bool "kernelValueEqual")) &&
        !(← checked (rows[0]!.getObjValAs? Bool "kernelPropositionalValueEquality")) do
      throwError "Exact standard proof consumer lacks full computational kernel definitional equality: {original}"
  let mut targetOnly := #[]
  for name in declarations.qsort Name.lt do
    ownedReports := ownedReports.push (← auditDeclaration rs allowedOwners name)
    if !(rs.any fun r => r.target == name && seenOriginal.contains r.original) then
      targetOnly := targetOnly.push (toJson name.toString)
  let expectedTargetOnly ← checked (arrayField config "expectedTargetOnlyCompilerDeclarations")
  unless targetOnly.size == expectedTargetOnly.size && targetOnly.all expectedTargetOnly.contains do
    throwError "Actual target-only compiler declarations differ from genuine platform facts"
  let output ← checked (stringField config "outputDir")
  IO.FS.createDirAll output
  IO.FS.writeFile (output ++ "/next-carrier-kernel-audit.json") ((Json.mkObj [
    ("schema", toJson "next-carrier-kernel-audit-v3"), ("compilerVersion", toJson Lean.versionString),
    ("originalCompilerVersion", toJson "4.35.0-rc3"),
    ("configuration", config),
    ("standardProofCompatibility", standardProofReport),
    ("standardProofValueResolutionCount", toJson (1 : Nat)),
    ("requiredComparedCount", toJson requiredCount),
    ("requiredSourceDeclarationCount", toJson requiredCount),
    ("requiredResolvedCount", toJson (requiredNamedCount + proofResolutionReports.size)),
    ("requiredEliminatedInternalProofCount", toJson proofResolutionReports.size),
    ("requiredNamedComparedCount", toJson requiredNamedCount),
    ("requiredProofValueResolutionCount", toJson proofResolutionReports.size),
    ("proofValueResolutions", Json.arr proofResolutionReports),
    ("actualPlatformHelperEvidenceVerified", toJson true),
    ("actualPlatformHelperQueryJob", toJson "ci-014164-c01e488c"),
    ("comparisons", Json.arr comparisons), ("ownedDeclarations", Json.arr ownedReports),
    ("directImportReports", Json.arr directImportReports),
    ("previouslyAcceptedDependencyModules", Json.arr (dependencyModules.map encodeName)),
    ("missingUnselectedOriginalDeclarations", Json.arr missingOptional),
    ("targetOnlyCompilerDeclarations", Json.arr targetOnly),
    ("allOwnedTypeValueClosuresStandardAxiomsOnly", toJson true),
    ("hasSorryAx", toJson false),
    ("targetOnlyPolicy", toJson "all reported and axiom audited; review source-command generation provenance before acceptance")]).compress ++ "\n")
  logInfo s!"Next carrier audit: {requiredCount} mandatory exact types; {comparisons.size} total original/target pairs; {ownedReports.size} artifact-owned axiom closures"

end FoundationAudit

syntax (name := auditNextCarrier) "audit_next_carriers" : command
@[command_elab auditNextCarrier] def elabAuditNextCarrier : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.audit

audit_next_carriers
