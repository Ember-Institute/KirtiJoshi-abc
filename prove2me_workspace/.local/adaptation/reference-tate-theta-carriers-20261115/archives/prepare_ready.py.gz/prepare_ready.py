#!/usr/bin/env python3
"""Bind reviewed actual evidence; no compilation, API or publication occurs."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import argparse
import importlib.util
import json
import subprocess
import hashlib
import mmap
import re
from common import UNIT, WORKSPACE, ROOT, MODULES, NAMES, exact_path, require

B = UNIT
spec = importlib.util.spec_from_file_location('tate_theta_delivery', Path(__file__).with_name('delivery.py'))
delivery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(delivery)
STANDARD_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}
PROJECT_PROOF = 'TateCurvesTheta.TateParameter.tateJ.eq_1'
PROJECT_PARENT = 'TateCurvesTheta.TateParameter.tateJ'
QORDER_PROOF = 'Iut.AdmissiblePrimeData.qOrder._proof_1'
QORDER_PARENT = 'Iut.AdmissiblePrimeData.qOrder'
QORDER_TARGET = 'AbcAdaptation.Reference.' + QORDER_PROOF
PROJECT_PROOFS = {PROJECT_PROOF, QORDER_PROOF}
PLATFORM_QUERY_JOB = 'ci-014164-c01e488c'


def validate_kernel_coverage(audit, declarations):
    """Derive coverage from this inventory and the strict auditor's emitted schema."""
    selected = {d['name'] for d in declarations if d['selected'] is True}
    require(len(selected) == sum(d['selected'] is True for d in declarations), 'Duplicate selected originals')
    config = audit['configuration']
    require(audit['schema'] == 'next-carrier-kernel-audit-v3', 'Unexpected actual kernel schema')
    require(len(selected) == 78 and PROJECT_PROOF in selected and
            all(audit[k] == len(selected) for k in ['requiredSourceDeclarationCount',
                'requiredComparedCount', 'requiredResolvedCount']) and
            audit['requiredNamedComparedCount'] == 76,
            'Actual kernel source78/named76 coverage differs from inventory')
    require(audit['requiredProofValueResolutionCount'] == audit['requiredEliminatedInternalProofCount'] == 2
            and len(audit['proofValueResolutions']) == 2,
            'Exactly two genuine source proof values must retain null target identities')
    require(config['expectedNamedSelectedCount'] == 76 and config['expectedProofValueResolutionCount'] == 2,
            'Kernel configured project named/proof coverage differs')
    comparisons = audit['comparisons']
    names = [r['original'] for r in comparisons]
    require(len(names) == len(set(names)), 'Duplicate actual named comparisons')
    require({r['original'] for r in comparisons if r['sourceRecord']['selected'] is True} == selected - PROJECT_PROOFS and
            len(comparisons) == 76 and not PROJECT_PROOFS & set(names),
            'Actual selected named comparison set differs')
    for row in comparisons:
        record = row['sourceRecord']
        require(record['name'] == row['original'] and all(row[k] is True for k in [
            'kernelTypeEqual', 'allExpressionBinderInfoEqual', 'binderInfoPlacementEqual',
            'sourceSignatureBinderInfoSerializationValidated', 'sourceTargetSignatureBinderInfoInventoryEqual',
            'sourceTargetSignatureBinderInfoPlacementEqual', 'expandedOriginalTypeKernelEqual',
            'computationShapeEqual', 'completeStructureMetadataEqual',
            'instanceRegistryMatchesAcceptedGraph', 'sourceAxiomInventoryMatchesAcceptedGraph']),
            'Type, binder, metadata, instance or source-axiom comparison failed: ' + row['original'])
        require(row['binderInfoComparisonScope'] ==
                'unexpanded-original-exported-signature-after-named-relocation-vs-actual-target-type',
                'Public BinderInfo comparison is not scoped to the unexpanded original signature')
        require(row['kernelPropositionalValueEquality'] is False and
                row['propositionalValueEqualityEvidence'] is None,
                'Unexpected propositional-value fallback')
        if record.get('valueExpr') is not None and row['proofDeclaration'] is False:
            require(row['kernelValueEqual'] is True and row['computationalValueEqualityChecked'] is True,
                    'Computational body lacks strict kernel value equality: ' + row['original'])
        rules, compared_rules = record['recursorRuleRhs'], row['recursorRulesCompared']
        require(isinstance(rules, list) and type(compared_rules) is int and
                compared_rules >= 0 and compared_rules == len(rules),
                'Recursor compared-rule count differs from actual source rules: ' + row['original'])
        if record.get('constantKind') != 'recursor':
            require(compared_rules == 0, 'Non-recursor has recursor rules: ' + row['original'])
    owned = audit['ownedDeclarations']
    require(len(owned) == 77 and len({r['name'] for r in owned}) == len(owned), 'Owned axiom closure set is empty or duplicated')
    require({r['target'] for r in comparisons} <= {r['name'] for r in owned},
            'Compared target lacks its own axiom closure')
    for row in owned:
        require(row['hasSorryAx'] is False and row['constantKind'] != 'axiom' and
                all(set(row[k]) <= STANDARD_AXIOMS for k in ['axioms', 'typeAxioms', 'valueAxioms']),
                'Owned declaration has sorry or an unapproved axiom: ' + row['name'])
    targets = audit['targetOnlyCompilerDeclarations']
    require(targets == config['expectedTargetOnlyCompilerDeclarations'] == [QORDER_TARGET] and
            set(targets) == {r['name'] for r in owned} - {r['target'] for r in comparisons},
            'Actual target-only declaration inventory differs')
    require(audit['hasSorryAx'] is False and audit['allOwnedTypeValueClosuresStandardAxiomsOnly'] is True,
            'Kernel axiom closure not accepted')
    validate_exact_project_proof(audit)
    validate_exact_qorder_proof(audit)
    return {'source': len(selected), 'resolved': len(selected), 'named': 76, 'proof': 2,
            'historical_requiredComparedCount': audit['requiredComparedCount']}


def encoded_name(text):
    result = []
    for part in text.split('.'):
        result = [result, 'str', part]
    return result


def validate_exact_project_proof(audit):
    """Validate only the actual absent tateJ equation theorem; retain its parent data equality."""
    config = audit['configuration']
    require({r['original'] for r in audit['proofValueResolutions']} ==
            {r['original'] for r in config['proofValueResolutions']} == PROJECT_PROOFS,
            'Exact two genuine source proof identities differ')
    rows = [r for r in audit['proofValueResolutions'] if r['original'] == PROJECT_PROOF]
    configured = [r for r in config['proofValueResolutions'] if r['original'] == PROJECT_PROOF]
    require(len(rows) == len(configured) == 1 and
            rows[0]['original'] == configured[0]['original'] == PROJECT_PROOF,
            'Project proof resolution is not the exact single tateJ equation')
    row, binding = rows[0], configured[0]
    require(row['collisionClassification'] == 'absent-generated-proof', 'tateJ absence classification changed')
    record = row['sourceRecord']
    require(row['resolution'] == 'genuine-exported-original-proof-value' and
            row['standaloneTargetIdentity'] is binding['standaloneTargetIdentity'] is None and
            row['originalName'] == binding['originalName'] == encoded_name(PROJECT_PROOF) and
            record == binding['sourceRecord'] and record['name'] == PROJECT_PROOF and
            record['nameExpr'] == encoded_name(PROJECT_PROOF) and
            record['module'] == 'TateCurvesTheta.TateCurve.JInvariant' and
            record['constantKind'] == 'theorem' and record['selected'] is True and
            record['isProposition'] is True and record['isInstance'] is False,
            'Exact project source proof type/identity binding differs')
    require(all(row[k] is True for k in ['originalTypeBinderInfoPreserved',
            'inferredTypeBinderInfoPlacementPreserved', 'exactOriginalTypeKernelChecked',
            'genuineOriginalValueInhabitsExactOriginalType', 'sourceAxiomInventoryMatchesAcceptedGraph',
            'parentWholeValueEqualityRequired', 'parentKernelDefinitionalValueEqualityRequired',
            'actualPlatformAbsenceEvidenceVerified', 'expandedDependenciesHaveAllowedOwners']) and
            row['hasSorryAx'] is False and row['actualPlatformQueryJob'] == PLATFORM_QUERY_JOB,
            'Exact genuine source equation proof kernel evidence is incomplete')
    require(all(isinstance(value, dict) and bool(value) for value in [record['elaboratedExpr'],
            record['valueExpr'], row['expandedType'], row['expandedValue']]) and
            all(set(record[k]) <= STANDARD_AXIOMS for k in ['axioms', 'typeAxioms', 'valueAxioms']) and
            all(set(row[k]) <= STANDARD_AXIOMS for k in ['expandedTypeAxioms', 'expandedValueAxioms']),
            'Genuine source equation expressions or axiom closures are missing')
    require(sorted(binding['expectedSourceAxioms'], key=repr) ==
            sorted([encoded_name(ax) for ax in record['axioms']], key=repr),
            'Genuine source equation axiom inventory differs')
    require(row['parentOriginal'] == binding['parentOriginal'] == PROJECT_PARENT and
            row['parentTarget'] == encoded_name('AbcAdaptation.Reference.' + PROJECT_PARENT) and
            binding['parentWholeValueEqualityRequired'] is True and
            binding['parentKernelDefinitionalValueEqualityRequired'] is True,
            'Genuine source equation parent binding differs')
    parents = [r for r in audit['comparisons'] if r['original'] == PROJECT_PARENT]
    require(len(parents) == 1, 'Exact tateJ parent comparison is missing')
    parent = parents[0]
    require(parent['sourceRecord']['constantKind'] == 'definition' and
            parent['sourceRecord']['selected'] is True and parent['sourceRecord']['isProposition'] is False and
            isinstance(parent['sourceRecord']['valueExpr'], dict) and bool(parent['sourceRecord']['valueExpr']) and
            parent['proofDeclaration'] is False and parent['computationalValueEqualityChecked'] is True and
            parent['kernelValueEqual'] is True and parent['kernelPropositionalValueEquality'] is False and
            parent['propositionalValueEqualityEvidence'] is None,
            'Exact tateJ proof requires full parent data kernel definitional equality')
    validate_platform_helper_evidence(audit, binding)


def validate_platform_helper_evidence(audit, proof_binding):
    config, evidence = audit['configuration'], audit['configuration']['platformHelperEvidence']
    require(audit['actualPlatformHelperEvidenceVerified'] is True and
            audit['actualPlatformHelperQueryJob'] == PLATFORM_QUERY_JOB,
            'Actual platform helper evidence was not kernel verified')
    inputs = {r['path']: r['sha256'] for r in config['inputEvidence']}
    for key in ['facts', 'receipt', 'querySource', 'queryConfiguration']:
        binding = evidence[key]
        require(delivery.sha(binding['path']) == binding['sha256'] == inputs.get(binding['path']),
                'Platform helper evidence is changed or absent from actual kernel inputs: ' + key)
        if 'contents' in binding:
            require(delivery.read(binding['path']) == binding['contents'], 'Bound platform helper contents changed: ' + key)
    facts, receipt = evidence['facts']['contents'], evidence['receipt']['contents']
    require(receipt['job_id'] == PLATFORM_QUERY_JOB and receipt['status'] == 'succeeded' and
            (receipt.get('result') or {}).get('exit_code') == 0,
            'Expected the genuine successful platform helper query')
    request, result = receipt['request'], receipt['result']
    require(request['language'] == 'lean' and request['workspace'] == str(WORKSPACE) and
            request['exclusive'] is True and request['task_type'] == 'leaf' and request['target'] == 'file' and
            result['snapshot']['workspace_mode'] == 'exclusive_worktree' and result['snapshot']['snapshot_id'] is None,
            'Platform helper query workspace/mode differs')
    source = WORKSPACE / request['parameters']['source']
    manifest = request['worktree_manifest']
    require(source.resolve() == Path(evidence['querySource']['path']).resolve() and
            delivery.sha(source) == manifest['source_sha256'] == manifest['input_hashes'].get(str(source)) and
            manifest['input_hashes'].get(request['environment']['NEXT_CARRIER_AUDIT_CONFIG']) ==
                evidence['queryConfiguration']['sha256'] and
            delivery.read(evidence['queryConfiguration']['path']) == facts['sourceAuditConfiguration'],
            'Platform query does not bind the exact actual source/configuration')
    require(facts['schema'] == 'tate-theta-platform-helper-facts-v1' and facts['compilerVersion'] == '4.33.1' and
            facts['inventorySha256'] == config['inventorySha256'] and facts['graphSha256'] == config['graphSha256'] and
            (facts['sourceRecordCount'], facts['publicSourceCandidateCount'], facts['selectedSourceCount'],
             facts['selectedMissingCount'], facts['ownedDeclarationCount']) == (117, 111, 78, 1, 77) and
            facts['targetOnlyNames'] == [], 'Actual platform source/owned/absence dimensions differ')
    candidates = facts['expectedCurrentCandidates']
    require(len(candidates) == len({r['original'] for r in candidates}) == 111,
            'Actual platform candidate inventory is incomplete or duplicated')
    selected = [r for r in candidates if r['selected'] is True]
    missing = [r for r in selected if r['present'] is False]
    require(len(selected) == 78 and len(missing) == 1 and missing[0]['original'] == PROJECT_PROOF and
            {r['original'] for r in selected if r['present'] is True} ==
                {r['original'] for r in audit['comparisons']} | {QORDER_PROOF},
            'Actual platform evidence does not establish the exact single missing source equation')
    owned = facts['ownedDeclarations']
    owned_names = {r['name'] for r in owned}
    require(len(owned) == len(owned_names) == 77 and owned_names == {r['name'] for r in audit['ownedDeclarations']} and
            owned_names == {r['candidateTarget'] for r in candidates if r['present'] is True},
            'Actual queried/current owned declaration sets differ')
    for row in owned:
        require(row['hasSorryAx'] is False and row['constantKind'] != 'axiom' and
                all(set(row[k]) <= STANDARD_AXIOMS for k in ['axioms', 'typeAxioms', 'valueAxioms']),
                'Actual platform owned axiom closure is not allowed')
    parents = [r for r in facts['helperFacts'] if r['name'] == 'AbcAdaptation.Reference.' + PROJECT_PARENT]
    require(len(parents) == 1 and parents[0] == proof_binding['actualParentFact'] and
            parents[0]['constantKind'] == 'definition' and parents[0]['isProposition'] is False and
            isinstance(parents[0]['valueExpr'], dict) and bool(parents[0]['valueExpr']),
            'Exact actual parent data fact differs from source-proof configuration')


def expression_head_name(expr):
    while expr.get('kind') in {'forall', 'lam'}:
        expr = expr['body']
    while expr.get('kind') == 'app':
        expr = expr['fn']
    return display_encoded_name(expr['name']) if expr.get('kind') == 'const' else None


def validate_exact_qorder_proof(audit):
    config = audit['configuration']
    row = next(r for r in audit['proofValueResolutions'] if r['original'] == QORDER_PROOF)
    binding = next(r for r in config['proofValueResolutions'] if r['original'] == QORDER_PROOF)
    source = row['sourceRecord']
    require(source == binding['sourceRecord'] and source['name'] == QORDER_PROOF and
            source['nameExpr'] == row['originalName'] == encoded_name(QORDER_PROOF) and
            source['module'] == 'Iut.Cor312.ThetaData.AdmissiblePrime' and source['constantKind'] == 'theorem' and
            source['selected'] is source['isProposition'] is True and source['isInstance'] is False and
            row['resolution'] == 'genuine-exported-original-proof-value' and
            row['standaloneTargetIdentity'] is binding['standaloneTargetIdentity'] is None and
            row['collisionClassification'] == binding['collisionClassification'] == 'present-type-incompatible-generated-proof',
            'Exact genuine qOrder Infinite source proof identity/classification differs')
    require(all(row[key] is True for key in ['sourceOriginalEnvironmentKernelChecked',
            'sourceAxiomInventoryMatchesAcceptedGraph', 'actualSourceAndTargetProofTypesKernelDistinct',
            'originalTypeBinderInfoPreserved', 'inferredTypeBinderInfoPlacementPreserved', 'exactOriginalTypeKernelChecked',
            'genuineOriginalValueInhabitsExactOriginalType', 'parentWholeValueEqualityRequired',
            'parentKernelDefinitionalValueEqualityRequired', 'expandedDependenciesHaveAllowedOwners']) and
            row['hasSorryAx'] is False and row['expandedType'] == source['elaboratedExpr'] and
            row['expandedValue'] == source['valueExpr'] and isinstance(source['valueExpr'], dict) and bool(source['valueExpr']) and
            all(set(row[key]) <= STANDARD_AXIOMS for key in ['expandedTypeAxioms', 'expandedValueAxioms']) and
            all(set(source[key]) <= STANDARD_AXIOMS for key in ['axioms', 'typeAxioms', 'valueAxioms']) and
            sorted(binding['expectedSourceAxioms'], key=repr) == sorted([encoded_name(a) for a in source['axioms']], key=repr),
            'Genuine qOrder Infinite proof type/value/BinderInfo/axiom/owner checks are incomplete')
    parent = next(r for r in audit['comparisons'] if r['original'] == QORDER_PARENT)
    require(row['parentOriginal'] == binding['parentOriginal'] == QORDER_PARENT and
            binding['parentWholeValueEqualityRequired'] is binding['parentKernelDefinitionalValueEqualityRequired'] is True and
            parent['proofDeclaration'] is False and parent['computationalValueEqualityChecked'] is True and
            parent['kernelValueEqual'] is True and parent['kernelPropositionalValueEquality'] is False,
            'Genuine Infinite proof requires full qOrder parent data kernel definitional equality')
    current = next(r for r in config['platformHelperEvidence']['facts']['contents']['helperFacts'] if r['name'] == QORDER_TARGET)
    require(current == row['actualCurrentIncompatibleProofFact'] == binding['actualCurrentIncompatibleProofFact'] and
            expression_head_name(source['elaboratedExpr']) == 'Infinite' and expression_head_name(current['elaboratedExpr']) == 'Module.Finite' and
            current['constantKind'] == 'theorem' and current['isProposition'] is True and current['isInstance'] is False and
            current['hasSorryAx'] is False and isinstance(current['valueExpr'], dict) and bool(current['valueExpr']) and
            current['module'] == 'Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime',
            'Actual same-named Module.Finite compiler helper must remain distinct from the source Infinite proof')
    owned = next(r for r in audit['ownedDeclarations'] if r['name'] == QORDER_TARGET)
    require(owned['constantKind'] == 'theorem' and owned['hasValue'] is True and owned['isInstance'] is False and
            all(owned[key] == current[key] for key in ['elaboratedExpr', 'binderInventory', 'nameExpr']) and
            all(set(owned[key]) == set(current[key]) <= STANDARD_AXIOMS for key in ['axioms', 'typeAxioms', 'valueAxioms']),
            'Actual compiler-only Module.Finite helper lacks its exact complete owner/type/value axiom audit')
    provenance = {'target': QORDER_TARGET, 'sourceParentOriginal': QORDER_PARENT, 'qOrderSourceHelperOriginal': QORDER_PROOF,
        'targetIdentityForSourceProof': False, 'ownerAxiomAuditRequired': True, 'wholeParentValueEqualityRequired': True,
        'collisionClassification': 'present-type-incompatible-generated-proof',
        'generationKind': 'current compiler-generated Module.Finite proof from unchanged qOrder source command', 'actualCompilerRecord': current}
    require(config['targetOnlyCompilerProvenance'] == audit['targetOnlyCompilerProvenance'] == [provenance],
            'Only the actual qOrder compiler-only helper can appear in target-only provenance')
    diagnostic = config['qOrderOriginalKernelDiagnostic']
    inputs = {r['path']: r['sha256'] for r in config['inputEvidence']}
    for path, digest, contents in [(diagnostic['path'], diagnostic['sha256'], diagnostic['contents']),
            (diagnostic['receiptPath'], diagnostic['receiptSha256'], diagnostic['receiptContents'])]:
        require(delivery.sha(path) == digest == inputs.get(path) and delivery.read(path) == contents,
                'Original-environment qOrder diagnostic or receipt is changed/unbound')
    facts, receipt = diagnostic['contents'], diagnostic['receiptContents']
    require(row['originalEnvironmentKernelDiagnosticJob'] == diagnostic['job_id'] == receipt['job_id'] == 'ci-014644-6cff0e0c' and
            receipt['status'] == 'succeeded' and receipt['result']['exit_code'] == 0 and
            receipt['request']['exclusive'] is True and receipt['result']['snapshot']['workspace_mode'] == 'exclusive_worktree' and
            receipt['result']['snapshot']['snapshot_id'] is None and
            receipt['resources']['peak_rss_bytes'] is not None and receipt['resources']['peak_rss_bytes'] <= 16 * 1024**3,
            'Original source4.35 qOrder kernel diagnostic did not pass in its actual exclusive leaf')
    names = {QORDER_PARENT, QORDER_PROOF, 'NumberField.HeightOneSpectrum.instNormedFieldValuedAdicCompletion'}
    require(facts['schema'] == 'tate-theta-qorder-original-kernel-diagnostic-v1' and facts['compilerVersion'] == '4.35.0-rc3' and
            len(facts['checks']) == len(facts['facts']) == 3 and {r['name'] for r in facts['checks']} ==
                {r['name'] for r in facts['facts']} == names and
            all(r['originalEnvironmentKernelCheckedTypeAndValue'] is True for r in facts['checks']),
            'Exactly three complete original-environment qOrder kernel checks are required')
    originals = {r['name']: r for r in facts['facts']}
    for name, record in [(QORDER_PROOF, source), (QORDER_PARENT, parent['sourceRecord'])]:
        require(all(originals[name][key] == record[key] for key in ['nameExpr', 'levelParams', 'elaboratedExpr',
                'valueExpr', 'binderInventory', 'constantKind', 'isProposition', 'isInstance', 'axioms']),
                'Fresh original diagnostic differs from the accepted original complete source export')
    request = receipt['request']; query = WORKSPACE / request['parameters']['source']
    require(delivery.sha(query) == request['worktree_manifest']['source_sha256'] == inputs.get(str(query)) and
            receipt['result']['actual_arguments'] == ['lean', request['parameters']['source']], 'Original qOrder diagnostic source/arguments changed')
    for path, digest in request['worktree_manifest']['input_hashes'].items():
        require(delivery.sha(path) == digest, 'Original qOrder diagnostic dependency changed: ' + path)


def validate_main_manifest(receipt, config_path):
    require(receipt['status'] == 'succeeded' and receipt['result']['exit_code'] == 0 and
            receipt['result']['review']['passed'] is True and
            receipt['result']['review']['checks']['no_sorryAx'] is True and
            receipt['result']['review']['checks']['assumptions_reported'] is True,
            'Successful main kernel compilation and actual axiom review are both required')
    request = receipt['request']; source = WORKSPACE / request['parameters']['source']
    require(request['language'] == 'lean' and request['workspace'] == str(WORKSPACE) and request['exclusive'] is True and
            request['task_type'] == 'review' and request['target'] == 'file' and
            receipt['result']['snapshot']['workspace_mode'] == 'exclusive_worktree' and receipt['result']['snapshot']['snapshot_id'] is None and
            receipt['result']['actual_arguments'] == ['lean', request['parameters']['source']] and
            request['environment']['NEXT_CARRIER_AUDIT_CONFIG'] == str(Path(config_path).resolve()),
            'Main receipt source, workspace, actual arguments or exact configuration differs')
    manifest = request['worktree_manifest']; hashes = manifest['input_hashes']
    require(delivery.sha(source) == manifest['source_sha256'] == hashes.get(str(source)) and
            delivery.sha(config_path) == hashes.get(str(Path(config_path).resolve())), 'Actual main source/configuration hash changed')
    config = delivery.read(config_path)
    require(all(hashes.get(row['path']) == row['sha256'] for row in config['inputEvidence']),
            'The actual main manifest omits configured source/evidence inputs')
    for path, digest in hashes.items():
        require(delivery.sha(path) == digest, 'Actual main source/dependency/cache input changed: ' + path)
    return {'job_id': receipt['job_id'], 'input_hash_count': len(hashes), 'source_sha256': manifest['source_sha256']}


def restore_native_universe(value, native_name, original_name):
    if isinstance(value, dict):
        require(value.get('kind') not in {'fvar', 'mvar'}, 'Standard native proof contains a free or metavariable')
        if value.get('kind') == 'param' and value.get('name') == native_name:
            return {**value, 'name': original_name}
        return {k: restore_native_universe(v, native_name, original_name) for k, v in value.items()}
    if isinstance(value, list):
        return [restore_native_universe(v, native_name, original_name) for v in value]
    return value


def validate_standard_proof_compatibility(audit, declarations):
    """Validate the singleton standard proof separately from project78=77+1."""
    original = 'NumberField.RingOfIntegers.instHasFiniteQuotients'
    standard_import = 'Mathlib.RingTheory.Ideal.Quotient.HasFiniteQuotients'
    config, report = audit['configuration'], audit['standardProofCompatibility']
    compatibility = config['standardProofCompatibility']
    require(type(audit['standardProofValueResolutionCount']) is int and
            audit['standardProofValueResolutionCount'] == 2 and
            compatibility['schema'] == 'tate-theta-exact-standard-proof-compatibility-v1' and
            report['schema'] == 'tate-theta-exact-standard-proof-resolution-v1' and
            compatibility['original'] == report['original'] == original and
            report['originalName'] == encoded_name(original) and
            report['resolution'] == 'kernel-checked-native-proof-at-exact-original-type' and
            report['standaloneTargetIdentity'] is compatibility['standaloneTargetIdentity'] is None,
            'Expected only the exact singleton standard native proof, separate from project obligations')
    require(config['auditorStandardImports'] == [standard_import] and
            len(config['modules']) == 4 and
            all(standard_import not in row['allowedDirectImports'] for row in config['modules']),
            'Standard finite-quotients import must remain exact and auditor-only')
    evidence = compatibility['evidence']
    inputs = {r['path']: r['sha256'] for r in config['inputEvidence']}
    for key in ['sourceFacts', 'sourceReceipt', 'platformFacts', 'platformReceipt', 'sourceQueryConfiguration']:
        binding = evidence[key]
        require(delivery.sha(binding['path']) == binding['sha256'] == inputs.get(binding['path']),
                'Standard proof evidence changed or missing from actual kernel input hashes: ' + key)
        if 'contents' in binding:
            require(delivery.read(binding['path']) == binding['contents'], 'Standard proof bound contents changed: ' + key)
    source, platform = evidence['sourceFacts']['contents'], evidence['platformFacts']['contents']
    source_receipt, platform_receipt = evidence['sourceReceipt']['contents'], evidence['platformReceipt']['contents']
    require(compatibility['platformJob'] == 'ci-014243-25ac457f', 'Wrong final actual platform standard query')
    for receipt, job in [(source_receipt, 'ci-014215-2414b895'), (platform_receipt, compatibility['platformJob'])]:
        request, result = receipt['request'], receipt.get('result') or {}
        require(receipt['job_id'] == job and receipt['status'] == 'succeeded' and result.get('exit_code') == 0 and
                request['language'] == 'lean' and request['workspace'] == str(WORKSPACE) and
                request['exclusive'] is True and request['task_type'] == 'leaf' and request['target'] == 'file' and
                result['snapshot']['workspace_mode'] == 'exclusive_worktree' and result['snapshot']['snapshot_id'] is None,
                'Standard source/platform evidence does not have its actual successful exclusive leaf receipt')
        query_source = WORKSPACE / request['parameters']['source']
        manifest = request['worktree_manifest']
        require(delivery.sha(query_source) == manifest['source_sha256'] ==
                manifest['input_hashes'].get(str(query_source)) == inputs.get(str(query_source)),
                'Standard query source is changed or absent from actual kernel evidence')
        require(result['actual_arguments'] == ['lean', request['parameters']['source']], 'Standard query compiler arguments differ')
        rss = (receipt.get('resources') or {}).get('peak_rss_bytes')
        require(rss is not None and rss <= 16 * 1024**3, 'Standard query lacks acceptable physical RSS evidence')
    historical = evidence['sourceQueryConfiguration']
    require(historical['historicalRequestInputPath'] == source_receipt['request']['environment']['NEXT_CARRIER_AUDIT_CONFIG'] and
            source_receipt['request']['worktree_manifest']['input_hashes'].get(historical['historicalRequestInputPath']) == historical['sha256'],
            'Original standard query historical configuration binding differs')
    source_facts_input = platform_receipt['request']['environment']['NEXT_CARRIER_STANDARD_SOURCE_FACTS']
    require(platform_receipt['request']['worktree_manifest']['input_hashes'].get(source_facts_input) == evidence['sourceFacts']['sha256'],
            'Current standard query does not bind the exact genuine source facts')
    require(source['schema'] == 'tate-theta-exact-standard-source-facts-v1' and source['compilerVersion'] == '4.35.0-rc3' and
            platform['schema'] == 'tate-theta-exact-standard-platform-facts-v1' and platform['compilerVersion'] == '4.33.1' and
            source['selectedOriginalScopeCount'] == 78 and
            source['relevantStandardNameCount'] == platform['relevantStandardNameCount'] == 270,
            'Standard source/platform facts scope or compiler differs')
    for facts in [source, platform]:
        require(all(facts[k] == config[k] for k in ['inventorySha256', 'graphSha256']), 'Standard query provenance differs')
    presence = platform['standardPresence']
    require(len(presence) == len({r['name'] for r in presence}) == 270 and
            platform['missingRelevantStandardNames'] == [encoded_name(original)] and
            [r['name'] for r in presence if r['present'] is False] == [original] and
            {json.dumps(r['nameExpr']) for r in presence} == {json.dumps(r['nameExpr']) for r in source['relevantStandardNames']},
            'Actual270-name standard presence inventory has another missing or substituted constant')
    source_records = {r['name']: r for r in source['facts']}
    current_records = {r['name']: r for r in platform['facts']}
    require(len(source_records) == len(source['facts']) == 8 and
            len(current_records) == len(platform['facts']) == 7 and
            set(current_records) == set(source_records) - {original}, 'Focused original/current standard API set differs')
    record = source_records[original]
    require(report['sourceRecord'] == record and record['nameExpr'] == encoded_name(original) and
            record['constantKind'] == 'theorem' and record['isProposition'] is True and record['isInstance'] is True and
            record['hasSorryAx'] is False and record['levelParams'] == [encoded_name('u_1')] and
            all(isinstance(record[k], dict) and bool(record[k]) for k in ['elaboratedExpr', 'valueExpr']) and
            all(set(record[k]) <= STANDARD_AXIOMS for k in ['axioms', 'typeAxioms', 'valueAxioms']),
            'Standard resolution is not bound to the exact genuine original proposition-valued instance')
    checks = platform['originalCurrentStandardShapeChecks']
    require(len(checks) == len({r['name'] for r in checks}) == 7 and {r['name'] for r in checks} == set(current_records),
            'Seven actual standard class/API shape checks are incomplete or duplicated')
    for row in checks:
        require(all(row[k] is True for k in ['succeeded', 'kernelTypeEqual', 'binderInfoPlacementEqual',
                'computationShapeEqual', 'structureMetadataEqual']) and
                type(row['recursorRulesCompared']) is int and
                row['recursorRulesCompared'] == len(source_records[row['name']]['recursorRuleRhs']),
                'Actual standard API type/binder/metadata/recursor check failed')
    failure, native = platform['genuineSourceBodyAttempt'], platform['nativeProofAttempt']
    require(failure['succeeded'] is False and isinstance(failure['error'], str) and bool(failure['error']) and
            compatibility['sourceBodyFailure'] == report['originalSourceBodyAttempt'] == failure and
            report['actualNativeProofAttempt'] == native and
            all(native[k] is True for k in ['succeeded', 'kernelCheckedExactSourceType', 'dependencyOwnersStandardOnly']) and
            native['hasSorryAx'] is False and set(native['axioms']) <= STANDARD_AXIOMS and
            all(isinstance(native[k], dict) and bool(native[k]) for k in ['type', 'value']),
            'Original-body failure or actual native exact-type proof provenance was changed')
    native_name = [encoded_name('_finiteQuotientsQueryUniverse'), 'num', 0]
    require(compatibility['nativeLevelParams'] == report['nativeLevelParams'] == [native_name] and
            type(report['nativeLevelParams'][0][2]) is int and
            compatibility['sourceLevelParams'] == report['restoredSourceLevelParams'] == record['levelParams'] and
            report['nativeUniversesRestoredToOriginal'] is True,
            'Actual numeric native universe was not restored to the exact original source universe')
    require(report['expandedType'] == record['elaboratedExpr'] and
            report['expandedValue'] == restore_native_universe(native['value'], native_name, record['levelParams'][0]) and
            restore_native_universe(native['type'], native_name, record['levelParams'][0]) == record['elaboratedExpr'],
            'Expanded standard type/value does not preserve the actual native proof and original universe restoration')
    require(all(report[k] is True for k in ['kernelCheckedExactSourceType', 'originalTypeBinderInfoPreserved',
            'inferredTypeBinderInfoPreserved', 'originalCurrentClassAPIChecked', 'dependencyOwnersStandardOnly',
            'allConsumerWholeDataKernelDefinitionalEqualitiesRequired']) and report['hasSorryAx'] is False and
            all(set(report[k]) <= STANDARD_AXIOMS for k in ['expandedTypeAxioms', 'expandedValueAxioms']),
            'Final standard proof kernel/type/binder/owner/axiom checks are incomplete')
    comparisons = {r['original']: r for r in audit['comparisons']}
    consumers = sorted(d['name'] for d in declarations if d['selected'] is True and
        original in set(d['directTypeDeps']) | set(d['directValueDeps']) and d['name'] in comparisons and
        comparisons[d['name']]['sourceRecord']['isProposition'] is False and
        comparisons[d['name']]['sourceRecord']['valueExpr'] is not None)
    require(len(consumers) == 9 and compatibility['requiredDataConsumers'] == report['requiredDataConsumers'] == consumers,
            'Exact nine original standard-proof data consumers differ')
    for name in consumers:
        row = comparisons[name]
        require(row['proofDeclaration'] is False and row['computationalValueEqualityChecked'] is True and
                row['kernelValueEqual'] is True and row['kernelPropositionalValueEquality'] is False and
                row['propositionalValueEqualityEvidence'] is None,
                'Standard proof consumer lost whole-data kernel definitional equality: ' + name)
    return {'standard_proof_value_resolution_count': 2, 'ring_native_proof_resolution_count': 1, 'original': original,
            'resolution': report['resolution'], 'standalone_target_identity': None,
            'source_query_job': source_receipt['job_id'], 'platform_query_job': platform_receipt['job_id'],
            'native_universes_restored_to_original': True, 'required_data_consumers': consumers}


def display_encoded_name(name):
    if name == []:
        return ''
    require(isinstance(name, list) and len(name) == 3 and name[1] in {'str', 'num'}, 'Malformed actual structural Name')
    require((name[1] == 'str' and isinstance(name[2], str)) or
            (name[1] == 'num' and type(name[2]) is int and name[2] >= 0), 'Structural Name lost its actual string/numeric component')
    parent = display_encoded_name(name[0])
    return (parent + '.' if parent else '') + str(name[2])


def original_top_field_ranges(data):
    token = re.compile(rb'"(?:[^"\\]|\\.)*"|[{}\[\]]')
    depth, current, starts, ends = 0, None, {}, {}
    for match in token.finditer(data):
        char = data[match.start()]
        if char == 34:
            if depth == 1 and data[match.end():match.end()+1] == b':':
                if current is not None:
                    end = match.start()
                    while end and data[end-1] in b' \r\n\t':
                        end -= 1
                    if data[end-1] == 44:
                        end -= 1
                    ends[current] = end
                current = json.loads(match[0])
                require(current not in starts, 'Duplicate top-level original DAG artifact field')
                starts[current] = match.end() + 1
            continue
        if char in (123, 91):
            depth += 1
        else:
            depth -= 1
            if depth == 0:
                if current is not None:
                    ends[current] = match.start()
                break
    return {key: (starts[key], ends[key]) for key in starts}


DAG_CHILDREN = {'app': ('fn', 'arg'), 'lam': ('type', 'body'), 'forall': ('type', 'body'),
                'let': ('type', 'value', 'body'), 'proj': ('body',)}


def validate_exact_expr_dag(dag, entries):
    require(dag['schema'] == 'foundation-expr-dag-v1' and isinstance(dag['nodes'], list) and bool(dag['nodes']),
            'Complete original Expr DAG is missing')
    nodes = dag['nodes']
    for index, node in enumerate(nodes):
        require(isinstance(node, dict) and node.get('kind') in
                {'app', 'lam', 'forall', 'let', 'proj', 'bvar', 'sort', 'const', 'nat', 'string'},
                'Original Expr DAG contains an unsupported/free/metavariable node')
        for key in DAG_CHILDREN.get(node['kind'], ()):
            require(type(node[key]) is int and 0 <= node[key] < index, 'Expr DAG child is not a complete earlier node')
    roots = [root for row in entries for root in [row['typeRoot'], row['valueRoot']]]
    require(dag['roots'] == roots and all(type(root) is int and 0 <= root < len(nodes) for root in roots),
            'Complete Expr DAG roots do not bind all original type/value pairs')
    return nodes


def dag_matches_tree(nodes, root, tree):
    node = nodes[root]
    if not isinstance(tree, dict) or set(node) != set(tree) or node['kind'] != tree.get('kind'):
        return False
    children = DAG_CHILDREN.get(node['kind'], ())
    return all(dag_matches_tree(nodes, node[key], value) if key in children else value == node[key]
               for key, value in tree.items())


def validate_adic_source_compatibility(audit, historical_config):
    config, result = audit['configuration'], audit['adicSourceCompatibility']
    binding = config['adicSourceCompatibility']
    counts = {'sourceDataCount': 8, 'genuineOriginalProofBodyCount': 26, 'nativeCardPowProofCount': 1,
              'standardNativeProofCountIncludingRing': 2, 'unusedOriginalProofArchiveCount': 15}
    require(binding['schema'] == 'tate-theta-adic-two-leaf-compatibility-v1' and
            result['schema'] == 'tate-theta-adic-source-dag-compatibility-result-v1' and
            all(type(binding[key]) is int and binding[key] == value for key, value in counts.items()) and
            result['requiredOriginalRecordCount'] == 35 and result['genuineOriginalDataCount'] == 8 and
            all(type(result[key]) is int and result[key] == value for key, value in counts.items() if key != 'sourceDataCount') and
            result['completeTypeValueChecksPassed'] is True and
            result['publicRawSignatureBinderGuardsAndFullDataEqualityRemainRequired'] is True,
            'Exact35 source DAG data8/proof26/CardPow1/global-native2/unused15 accounting differs')
    required = binding['requiredOriginalNames']
    required_keys = {json.dumps(name) for name in required}
    require(len(required) == len(required_keys) == 35 and len(binding['leaves']) == 2,
            'Exact two-leaf35 structural Name coverage differs')
    for name in required:
        display_encoded_name(name)
    inputs = {row['path']: row['sha256'] for row in config['inputEvidence']}
    historical_config = Path(historical_config).resolve()
    historical_hash = delivery.sha(historical_config)
    require(inputs.get(str(historical_config)) == historical_hash, 'Exact A/B historical source configuration is not hash bound')
    field_names = {'schema', 'stage', 'inventorySha256', 'graphSha256', 'candidateOriginalRecordCount',
        'allActiveOriginalRecordCount', 'stageOriginalRecordCount', 'stageOriginalRecordNames', 'unusedArchivedCandidateNames',
        'standardProofOverrideCount', 'entries', 'exprDag', 'allCompleteTypeValueKernelChecksPassed',
        'allExprDagRootsStrictExprEqualRoundTrip', 'roundTripIncludesBinderNamesBinderInfoAndNumericNames'}
    ring_name = 'NumberField.RingOfIntegers.instHasFiniteQuotients'
    ring_report = audit['standardProofCompatibility']
    actual_entries, unused_keys, leaf_summaries = {}, None, []
    for leaf, job, stage, count in zip(binding['leaves'], ['ci-014497-4264b653', 'ci-014507-f12c827f'],
            ['absnorm-support', 'finite-place'], [19, 16]):
        view_path, receipt_path = Path(leaf['viewPath']), Path(leaf['receiptPath'])
        require(delivery.sha(view_path) == leaf['viewSha256'] == inputs.get(str(view_path)) and
                delivery.sha(receipt_path) == leaf['receiptSha256'] == inputs.get(str(receipt_path)),
                'Accepted A/B view or receipt hash differs from actual kernel input evidence')
        view, receipt = delivery.read(view_path), delivery.read(receipt_path)
        require(view == leaf['viewContents'] and receipt == leaf['receiptContents'] and
                view['schema'] == 'tate-theta-adic-receipt-bound-dag-view-v1' and
                receipt['job_id'] == view['receipt']['job_id'] == job and
                view['receipt']['path'] == str(receipt_path) and view['receipt']['sha256'] == leaf['receiptSha256'],
                'Only the actual A19/B16 successful receipt-bound views can supply compatibility')
        request, compiler = receipt['request'], receipt.get('result') or {}
        rss = (receipt.get('resources') or {}).get('peak_rss_bytes')
        require(receipt['status'] == 'succeeded' and compiler.get('exit_code') == 0 and
                request['language'] == 'lean' and request['workspace'] == str(WORKSPACE) and request['exclusive'] is True and
                request['task_type'] == 'leaf' and request['target'] == 'file' and
                compiler['snapshot']['workspace_mode'] == 'exclusive_worktree' and compiler['snapshot']['snapshot_id'] is None and
                rss is not None and rss <= 16 * 1024**3,
                'A/B source DAG acceptance requires each actual exclusive leaf below16GiB physical RSS')
        query_source = WORKSPACE / request['parameters']['source']
        manifest = request['worktree_manifest']
        require(compiler['actual_arguments'] == ['lean', request['parameters']['source']] and
                delivery.sha(query_source) == manifest['source_sha256'] == manifest['input_hashes'].get(str(query_source)),
                'A/B actual source or compiler arguments changed')
        old_config_path = request['environment']['NEXT_CARRIER_AUDIT_CONFIG']
        require(manifest['input_hashes'].get(old_config_path) == historical_hash, 'A/B historical configuration hash differs')
        for path, digest in manifest['input_hashes'].items():
            actual = historical_config if path == old_config_path else Path(path)
            require(delivery.sha(actual) == digest == inputs.get(str(actual.resolve())),
                    'A/B original source/dependency is changed or unbound: ' + str(actual))
        original = Path(view['originalArtifact']['path'])
        require(request['environment']['NEXT_CARRIER_ADIC_DAG_OUTPUT'] == str(original) and
                delivery.sha(original) == view['originalArtifact']['sha256'] == inputs.get(str(original)),
                'Complete original A/B artifact, including historical diagnostic arrays, is not preserved')
        fields, spans = view['sourceFields'], view['exactFieldByteSpans']
        require(set(fields) == set(spans) == field_names, 'Lossless view omits an exact required original DAG field')
        with original.open('rb') as handle, mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_READ) as data:
            locations = original_top_field_ranges(data)
            for key in field_names:
                span = spans[key]
                require(type(span['start']) is int and type(span['end']) is int and
                        (span['start'], span['end']) == locations.get(key), 'View range is not the exact original top-level field: ' + key)
                raw = data[span['start']:span['end']]
                require(hashlib.sha256(raw).hexdigest() == span['sha256'] and json.loads(raw) == fields[key],
                        'Lossless view changed original field bytes or parsed value: ' + key)
        require(fields['schema'] == 'tate-theta-adic-split-expr-dag-v1' and fields['stage'] == stage and
                fields['stageOriginalRecordCount'] == count and fields['allActiveOriginalRecordCount'] == 35 and
                fields['candidateOriginalRecordCount'] == 50 and fields['standardProofOverrideCount'] == 2 and
                all(fields[key] == config[key] for key in ['inventorySha256', 'graphSha256']) and
                all(fields[key] is True for key in ['allCompleteTypeValueKernelChecksPassed',
                    'allExprDagRootsStrictExprEqualRoundTrip', 'roundTripIncludesBinderNamesBinderInfoAndNumericNames']),
                'Exact A/B stage provenance, dimensions or complete Expr/Name/BinderInfo checks differ')
        unused = {json.dumps(name) for name in fields['unusedArchivedCandidateNames']}
        require(len(fields['unusedArchivedCandidateNames']) == len(unused) == 15 and not unused & required_keys and
                (unused_keys is None or unused_keys == unused), 'Unused15 original proof archive was changed, dropped or accepted as active')
        unused_keys = unused
        entries = fields['entries']
        nodes = validate_exact_expr_dag(fields['exprDag'], entries)
        stage_names = {json.dumps(name) for name in fields['stageOriginalRecordNames']}
        require(len(stage_names) == len(fields['stageOriginalRecordNames']) == count and len(entries) == count + 1,
                'A/B stage entries do not retain complete19/16 source records plus Ring seed')
        found_stage, ring_seeds = set(), 0
        for row in entries:
            name = display_encoded_name(row['nameExpr'])
            require(name == row['name'] and len({json.dumps(n) for n in row['levelParams']}) == len(row['levelParams']),
                    'DAG entry structural Name or universe parameters changed')
            if name == ring_name:
                ring_seeds += 1
                require(row['isProposition'] is True and row['resolution'] == 'known-standard-native-proof' and
                        row['levelParams'] == ring_report['restoredSourceLevelParams'] and
                        dag_matches_tree(nodes, row['typeRoot'], ring_report['expandedType']) and
                        dag_matches_tree(nodes, row['valueRoot'], ring_report['expandedValue']),
                        'Complete A/B duplicate Ring seed differs from the actual exact-source-type standard proof')
                continue
            name_key = json.dumps(row['nameExpr'])
            require(name_key in required_keys and name not in actual_entries, 'Unapproved or duplicate active DAG source Name')
            found_stage.add(name_key)
            require(set(row.get('axioms', [])) <= STANDARD_AXIOMS, 'Source DAG entry has an unapproved original axiom')
            if name == 'cardQuot_pow_of_prime':
                expected_value = {'kind': 'const', 'name': row['nameExpr'],
                    'levels': [{'kind': 'param', 'name': param} for param in row['levelParams']]}
                require(row['isProposition'] is True and row['resolution'] == 'exact-original-type-native-theorem-proof' and
                        dag_matches_tree(nodes, row['valueRoot'], expected_value),
                        'Only the exact original-type CardPow native theorem proof can replace an archived proof body')
            else:
                require(row['resolution'] == 'genuine-original-complete-body', 'A genuine original data/proof body was replaced by native data')
            actual_entries[name] = (row, job, str(view_path))
        require(ring_seeds == 1 and found_stage == stage_names, 'A/B stage Names or exact duplicate Ring seed coverage differ')
        leaf_summaries.append({'job_id': job, 'view': str(view_path), 'original_artifact': str(original), 'peak_rss_bytes': rss})
    reports = result['entries']
    require(len(reports) == len({row['original'] for row in reports}) == len(actual_entries) == 35 and
            {json.dumps(row[0]['nameExpr']) for row in actual_entries.values()} == required_keys,
            'Final source DAG report does not cover the exact35 active original Names')
    data_count = proof_count = card_count = 0
    for row in reports:
        require(row['original'] in actual_entries, 'Final DAG report invents an active source identity')
        source, job, view_path = actual_entries[row['original']]
        require(row['originalName'] == source['nameExpr'] and row['levelParams'] == source['levelParams'] and
                row['resolution'] == source['resolution'] and row['isProposition'] is source['isProposition'] and
                row['standaloneTargetIdentity'] is None and row['leafJob'] == job and row['viewPath'] == view_path and
                row['typeRoot'] == source['typeRoot'] and row['valueRoot'] == source['valueRoot'] and
                all(row[key] is True for key in ['completeTypeAndValueRetainedInExactExprDag', 'exactOriginalTypeKernelChecked',
                    'completeValueKernelCheckedAtExactOriginalType', 'publicConsumerFullKernelEqualityRequired']) and
                all(set(row[key]) <= STANDARD_AXIOMS for key in ['typeAxioms', 'valueAxioms']),
                'Final complete source DAG type/value/owner/axiom/consumer evidence differs')
        if row['original'] == 'cardQuot_pow_of_prime':
            card_count += 1
        elif row['isProposition'] is True:
            proof_count += 1
        else:
            require(row['isProposition'] is False, 'Source DAG proof/data classification is not exact')
            data_count += 1
    require((data_count, proof_count, card_count) == (8, 26, 1), 'Actual source DAG proof/data/native classification changed')
    return {'required_original_record_count': 35, 'genuine_original_data_count': 8, 'genuine_original_proof_body_count': 26,
            'native_card_pow_proof_count': 1, 'standard_native_proof_count_including_ring': 2,
            'unused_original_proof_archive_count': 15, 'historical_config': str(historical_config), 'leaves': leaf_summaries,
            'public_raw_signature_binder_guards_and_full_data_equality_required': True}


def validate_ledger(ledger, inventory, wrapper_path, audit_path, kernel_path, audit):
    require(ledger['schema'] == 'reference-tate-theta-source-ledger-v1' and
            ledger['status'] == 'accepted-compiler-identities', 'Accepted current source ledger is required')
    require(ledger['wrapperReport'] == {'path': str(wrapper_path.resolve()), 'sha256': delivery.sha(wrapper_path)},
            'Ledger does not bind this exact wrapper report')
    entries = {e['originalModule']: e for e in ledger['entries']}
    require(len(ledger['entries']) == 4 and set(entries) == set(MODULES), 'Ledger bundle set differs')
    require(ledger['sourceCommandCount'] == sum(len(m['selectedSourceCommandCandidates']) for m in inventory['modules']) and
            ledger['selectedDeclarationCount'] == sum(d['selected'] is True for m in inventory['modules'] for d in m['declarations']) and
            ledger['selectedNamedCount'] == 76 and
            ledger['selectedProofValueResolutionCount'] == 2 and ledger['selectedDeclarationCount'] == 78, 'Ledger selected command/declaration coverage differs')
    require(ledger['priorRequiredCount'] == len(ledger['requiredPriorActualPairs']) == 42,
            'Ledger prior supplier identity set differs')
    required_prior = audit['configuration']['priorBundleEvidence']['requiredActualPairs']
    require(len(required_prior) == 42 and audit['configuration']['priorBundleEvidence']['actualAcceptedNamedConstants'] == 339 and
            {(r['original'], r['target']) for r in required_prior} ==
                {(r['original'], r['target']) for r in ledger['requiredPriorActualPairs']},
            'The exact42 actual prior suppliers or339 available identities changed')
    require(ledger['productionUpstreamDependenciesAdded'] is False and ledger['rootGraphMembership'] is False and
            ledger['canonicalC22Connected'] is False and ledger['mathematicalParentObligationCompleted'] is False,
            'Ledger scope changed')
    correspondence_binding = ledger['acceptedCompilerCorrespondence']
    correspondence_path = Path(correspondence_binding['path'])
    require(delivery.sha(correspondence_path) == correspondence_binding['sha256'], 'Accepted correspondence changed')
    correspondence = delivery.read(correspondence_path)
    require(correspondence['status'] == 'accepted-kernel-audit' and
            correspondence['audit'] == str(audit_path.resolve()) and
            correspondence['auditSha256'] == delivery.sha(audit_path) and
            correspondence['receipt'] == str(kernel_path.resolve()) and
            correspondence['receiptSha256'] == delivery.sha(kernel_path) and
            correspondence['job_id'] == delivery.read(kernel_path)['job_id'] and
            correspondence['proofValueResolutions'] == audit['proofValueResolutions'] and
            correspondence['standardProofCompatibility'] == audit['standardProofCompatibility'] and
            correspondence['standardProofValueResolutionCount'] == audit['standardProofValueResolutionCount'] == 2 and
            ledger['auditExpressionStandardProofCompatibility'] == audit['standardProofCompatibility'],
            'Ledger correspondence does not bind the actual current successful kernel receipt')
    wrapper_report = delivery.read(wrapper_path)
    qbundle = next(r for r in wrapper_report['bundles'] if r['module'] == 'Iut.Cor312.ThetaData.AdmissiblePrime')
    commands = [r for r in qbundle['commandMaps'] if QORDER_PARENT in r['selectedCompilerDeclarations']]
    require(len(commands) == 1 and commands[0]['originalCommandIndex'] == 21 and commands[0]['role'] == 'selected-declaration' and
            commands[0]['sha256'] == 'b00e2de211ff32ba04c0fbe9038d7804e7890f8767e96ffe8fd6de0dfe8b33df',
            'Compiler-only Module.Finite helper must retain the exact whole original qOrder command')
    policy = {'schema': 'tate-theta-qorder-proof-identity-policy-v1', 'sourceProofOriginal': QORDER_PROOF,
        'sourceStandaloneTargetIdentity': None, 'sourceProofClassification': 'present-type-incompatible-generated-proof',
        'actualCurrentCompilerOnlyTarget': QORDER_TARGET, 'sourceOriginalKernelJob': 'ci-014644-6cff0e0c',
        'sourceSelectedCount': 78, 'namedSelectedCount': 76, 'genuineSourceProofValueCount': 2, 'actualOwnedCount': 77,
        'actualCompilerOnlyProofCount': 1, 'nativeStandardProofCount': 2, 'historicalPresenceQueryUnchanged': True,
        'requiredWholeDataParent': QORDER_PARENT, 'requiredWholeCommandSha256': commands[0]['sha256']}
    require(correspondence['qOrderProofIdentityPolicy'] == ledger['qOrderProofIdentityPolicy'] == policy and
            correspondence['targetOnlyCompilerDeclarations'] == ledger['targetOnlyCompilerDeclarations'] ==
                audit['targetOnlyCompilerDeclarations'] == [QORDER_TARGET] and
            correspondence['targetOnlyCompilerProvenance'] == ledger['targetOnlyCompilerProvenance'] ==
                audit['targetOnlyCompilerProvenance'], 'Exact76+2 policy or compiler-only helper provenance changed')
    scope = 'unexpanded-original-exported-signature-after-named-relocation-vs-actual-target-type'
    require(correspondence['adicSourceCompatibility'] == ledger['auditExpressionAdicSourceCompatibility'] ==
                audit['adicSourceCompatibility'] and
            correspondence['adicSourceCompatibilityEvidence'] == ledger['auditExpressionAdicSourceCompatibilityEvidence'] and
            ledger['auditExpressionStandardProofValueResolutionCount'] == 2 and
            correspondence['binderInfoComparisonScope'] == ledger['binderInfoComparisonScope'] == scope,
            'Ledger/correspondence DAG evidence, separate proof accounting or raw signature scope changed')
    independent = correspondence['adicSourceCompatibilityEvidence']
    require(independent['schema'] == 'tate-theta-independent-accepted-adic-dag-evidence-v1' and
            (independent['completeSourceRecordCount'], independent['genuineDataCount'], independent['genuineProofCount'],
             independent['nativeCardPowProofCount'], independent['uniqueNativeStandardProofCountIncludingRing']) == (35, 8, 26, 1, 2) and
            len(independent['leaves']) == 2, 'Independent exact A/B DAG evidence is incomplete')
    for row, binding in zip(independent['leaves'], audit['configuration']['adicSourceCompatibility']['leaves']):
        require(row['job_id'] == binding['receiptContents']['job_id'] and row['viewPath'] == binding['viewPath'] and
                row['viewSha256'] == binding['viewSha256'] and row['receiptPath'] == binding['receiptPath'] and
                row['receiptSha256'] == binding['receiptSha256'] and
                row['originalArtifact'] == binding['viewContents']['originalArtifact'] and
                row['resources'] == binding['receiptContents']['resources'] and
                row['exactFieldByteSpans'] == binding['viewContents']['exactFieldByteSpans'],
                'Independent source ledger changed A/B receipt, resources or exact original byte spans')
    for module in inventory['modules']:
        entry = entries[module['module']]
        require(entry['producer'] == NAMES[MODULES.index(module['module'])] and
                entry['sourceCommandsPreserved'] is True and entry['definitionBodyProofsPreserved'] is True and
                entry['selectedSourceCommands'] == module['selectedSourceCommandCandidates'],
                'Ledger producer/command preservation differs')
        rows = {r['original']: r for r in entry['selectedDeclarations']}
        selected = {d['name']: d for d in module['declarations'] if d['selected'] is True}
        require(len(rows) == len(entry['selectedDeclarations']) and set(rows) == set(selected),
                'Ledger selected declaration set differs')
        require(entry['consumerEvidence']['inventorySha256'] == delivery.sha(B / 'inventory.json') and
                entry['consumerEvidence']['graphSha256'] == inventory['graphSha256'] and
                entry['actualSourceConsumer'] == 'Iut.Theorem110Invariants.theorem110',
                'Ledger graph or final source consumer differs')
        for name, row in rows.items():
            require(row['actualOriginalConsumers'] == selected[name]['actualConsumers'] and
                    row['originalConsumerPathToMainTheorem'] == selected[name]['consumerPathToMainTheorem'],
                    'Ledger actual consumer edge differs: ' + name)
            if name in PROJECT_PROOFS:
                require(row['wrapped'] is None and row['actualCompilerPair'] is None and
                        row['targetIdentityStatus'] == 'accepted-internal-proof-value-no-standalone-identity' and
                        row['internalProofValueResolution'] == next(r for r in audit['proofValueResolutions'] if r['original'] == name),
                        'Ledger invents a target identity or loses the exact genuine source proof')
            else:
                signature_checks = {key: True for key in ['sourceSignatureBinderInfoSerializationValidated',
                    'sourceTargetSignatureBinderInfoInventoryEqual', 'sourceTargetSignatureBinderInfoPlacementEqual',
                    'expandedOriginalTypeKernelEqual']}
                signature_checks['binderInfoComparisonScope'] = scope
                require(row['targetIdentityStatus'] == 'accepted-actual-named-comparison' and
                        isinstance(row['wrapped'], str) and bool(row['wrapped']) and
                        row['actualCompilerPair']['original'] == name and
                        row['actualCompilerPair']['target'] == row['wrapped'] and
                        row['actualCompilerPair']['signatureBinderChecks'] == signature_checks,
                        'Ledger actual named identity differs: ' + name)
    return correspondence_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', required=True, type=Path, help='Completed reviewed ready-inputs JSON')
    parser.add_argument('--kernel-receipt', required=True, help='Actual successful unit-relative kernel receipt')
    parser.add_argument('--kernel-audit', required=True, help='Actual successful unit-relative emitted kernel JSON')
    args = parser.parse_args()
    load, sha = delivery.read, delivery.sha
    config = load(args.inputs)
    require(config['reviewed'] is True, 'Ready input selection is not reviewed')
    path = lambda n: exact_path(B, n)
    audit_path, kernel = path(args.kernel_audit), path(args.kernel_receipt)
    audit, kernel_receipt = load(audit_path), load(kernel)
    require(kernel_receipt['status'] == 'succeeded' and
            (kernel_receipt.get('result') or {}).get('exit_code') == 0,
            'A genuine successful final kernel receipt is required before readiness')
    inv_path = path(config['inventory'])
    inv = load(inv_path)
    require([m['module'] for m in inv['modules']] == MODULES, 'Inventory exact ordered module set differs')
    declarations = [d for m in inv['modules'] for d in m['declarations']]
    selected_count = sum(d['selected'] is True for d in declarations)
    require((len(declarations), selected_count, sum(len(m['selectedSourceCommandCandidates']) for m in inv['modules'])) == (117, 78, 20),
            'Reviewed inventory declaration/selection/command counts changed')
    coverage = validate_kernel_coverage(audit, declarations)
    standard_compatibility = validate_standard_proof_compatibility(audit, declarations)
    adic_compatibility = validate_adic_source_compatibility(audit, path(config['adic_historical_config']))
    require(audit['configuration']['inventorySha256'] == sha(inv_path), 'Kernel inventory is stale')
    require(audit['configuration']['expectedRecordCount'] == len(declarations) and
            audit['configuration']['expectedSelectedCount'] == selected_count, 'Kernel inventory configuration differs')
    kernel_config_path = path(config['kernel_config'])
    main_manifest = validate_main_manifest(kernel_receipt, kernel_config_path)
    require(load(kernel_config_path) == audit['configuration'], 'Audit emitted configuration differs from actual config')
    kernel_inputs = audit['configuration']['inputEvidence']
    require(bool(kernel_inputs) and len({r['path'] for r in kernel_inputs}) == len(kernel_inputs),
            'Kernel actual input evidence is empty or duplicated')
    for row in kernel_inputs:
        require(sha(row['path']) == row['sha256'], 'Kernel actual input changed: ' + row['path'])
    input_paths = {Path(r['path']).resolve() for r in kernel_inputs}
    original_exprs = Path(audit['configuration']['originalExprFile']).resolve()
    require(original_exprs in input_paths, 'Actual original Expr input is not hash bound')
    view = audit['configuration'].get('originalExprSerializationView')
    if view is not None:
        require(view['schema'] == 'tate-theta-lossless-original-exprs-compact-view-v1' and
                Path(view['compact']['path']).resolve() == original_exprs and
                sha(original_exprs) == view['compact']['sha256'] and
                (view['recordCount'], view['selectedCount']) == (len(declarations), selected_count) and
                all(view['preservation'][k] is True for k in ['completeLexicalTokenStreamsCompared',
                    'onlyWhitespaceOutsideJsonStringsRemoved',
                    'allExprNameBinderMetadataAndRecordValuesUnchanged', 'parsedJsonEquality']),
                'Compact original Expr view lacks exact raw-token preservation evidence')
        acceptance_path = Path(view['sourceAcceptance']['path'])
        acceptance = load(acceptance_path)
        source_receipt_path = Path(acceptance['compilerReceiptPath'])
        source_receipt = load(source_receipt_path)
        require(sha(acceptance_path) == view['sourceAcceptance']['sha256'] and
                acceptance['status'] == 'accepted' and acceptance['originalExprsSha256'] == view['raw']['sha256'] and
                sha(view['raw']['path']) == view['raw']['sha256'] and
                sha(source_receipt_path) == acceptance['compilerReceiptSha256'] and
                source_receipt['job_id'] == acceptance['job_id'] and
                source_receipt['status'] == 'succeeded' and source_receipt['result']['exit_code'] == 0,
                'Compact view is not bound to the genuine successful raw compiler acceptance')
        view_path = path(config['original_view_evidence'])
        require({Path(view['raw']['path']).resolve(), acceptance_path.resolve(), source_receipt_path.resolve(),
                 view_path.resolve()} <= input_paths and load(view_path) == view,
                'Kernel input evidence omits raw source, acceptance, successful receipt or exact token report')
    require(kernel_receipt['request']['environment']['NEXT_CARRIER_AUDIT_CONFIG'] == str(kernel_config_path.resolve()),
            'Kernel receipt did not use this actual emitted configuration')
    manifest_inputs = kernel_receipt['request']['worktree_manifest'].get('input_hashes', {})
    require(manifest_inputs.get(str(kernel_config_path.resolve())) == sha(kernel_config_path) and
            manifest_inputs.get(str(original_exprs)) == sha(original_exprs),
            'Kernel receipt does not hash the exact actual config and original Expr input')
    output_path = Path(audit['configuration']['outputDir']) / 'next-carrier-kernel-audit.json'
    require(output_path.resolve() == audit_path.resolve(), 'Kernel output path does not match this emitted audit')
    wrapper_path, ledger_path = path(config['wrapper_report']), path(config['source_ledger'])
    accepted_ledger = load(ledger_path)
    correspondence_path = validate_ledger(accepted_ledger, inv, wrapper_path, audit_path, kernel, audit)
    blind_path = path(config['blind_readbacks'])
    require(load(blind_path)['passed'] is True, 'Actual independent blind readback is incomplete')
    paper_path, paper_check_path = path(config['paper_context']), path(config['paper_validation'])
    paper, paper_check = load(paper_path), load(paper_check_path)
    require(paper_check['status'] == 'passed' and bool(paper_check['checks']) and
            all(c['passed'] is True for c in paper_check['checks']), 'Paper consistency review is incomplete')
    require(paper['validation'] == paper_check, 'Paper validation and context differ')
    production = path(config['production_receipt'])
    leaves = [path(n) for n in config['leaf_receipts']]
    artifacts = [path(n) for n in config['artifact_receipts']]
    receipts = {'new_leaf_modules': leaves, 'new_leaf_artifacts': artifacts,
        'checks_axioms': [kernel, production], 'wrapped_kernel_type_identity': [kernel],
        'import_audit': [production], 'act1scene1': [production], 'axiom_audit': [production]}
    require(set(config['gate_evidence']) == {'independent_readbacks', 'source_ledger_consumers', 'existing_mission_scope'},
            'Unexpected non-CI gate set')
    gates = {key: [path(n) for n in names] for key, names in config['gate_evidence'].items()}
    require(all(gates.values()), 'Missing reviewed non-CI evidence')
    review_path = path(config['prepublication_review'])
    review = load(review_path)
    require(review['blocking_findings'] == [] and review['status'] == 'passed' and review['frozen'] is True,
            'Final frozen prepublication review is incomplete')
    frozen = review['frozen_evidence_sha256']
    require(bool(frozen) and all(sha(p) == digest for p, digest in frozen.items()), 'Frozen evidence is empty or changed')
    minimum_frozen = {audit_path, kernel_config_path, inv_path, wrapper_path, ledger_path, correspondence_path,
                      blind_path, paper_path, paper_check_path, *input_paths}
    minimum_frozen.update(p for group in [*receipts.values(), *gates.values()] for p in group)
    require({str(p.resolve()) for p in minimum_frozen} <= set(frozen), 'Frozen review does not bind every actual ready input')
    destination = B / 'delivery'
    packet = delivery.prepare(wrapper_path, blind_path, paper_path, ledger_path, destination)
    require(review['definitions_sha256'] == packet['source_sha256'], 'Reviewed Definition hashes differ')
    require(set(packet['metadata_sha256']) <= set(frozen), 'Frozen review does not bind every formal readback original/input')
    diff = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True, text=True)
    require(diff.returncode == 0, diff.stdout + diff.stderr)
    for name in packet['source_sha256']:
        check = subprocess.run(['git', 'diff', '--no-index', '--check', '/dev/null', str(WORKSPACE / name)],
                               cwd=ROOT, capture_output=True, text=True)
        require(check.returncode in [0, 1] and not (check.stdout or check.stderr), check.stdout + check.stderr)
    diff_path = B / 'git-diff-check.json'
    delivery.save(diff_path, {'passed': True, 'tracked_diff_exit': diff.returncode,
        'new_definition_whitespace_checked': list(packet['source_sha256']), 'source_sha256': packet['source_sha256']})
    gates['independent_readbacks'] += [blind_path, review_path, paper_check_path]
    gates['source_ledger_consumers'] += [ledger_path, correspondence_path]
    gates['git_diff_check'] = [diff_path]
    evidence = minimum_frozen | {args.inputs.resolve(), review_path, diff_path}
    ready = {'passed': True, 'packet_sha256': sha(destination / 'packet.json'), 'kernel_coverage': coverage, 'standard_compatibility': standard_compatibility, 'adic_source_compatibility': adic_compatibility, 'main_manifest': main_manifest,
        'qorder_proof_identity_policy': accepted_ledger['qOrderProofIdentityPolicy'],
        'source_sha256': packet['source_sha256'], 'gates': dict.fromkeys(delivery.GATES, True),
        'ci_receipts': {key: list(map(str, value)) for key, value in receipts.items()},
        'axiom_audit': {'sorryAx_found': False, 'unexpected_axioms': []},
        'gate_evidence': {key: list(map(str, value)) for key, value in gates.items()},
        'evidence_sha256': delivery.path_hashes(evidence)}
    candidate = destination / 'ready.candidate.json'
    delivery.save(candidate, ready)
    try:
        delivery.preflight(destination / 'packet.json', candidate)
    finally:
        candidate.unlink()
    delivery.save(destination / 'ready.json', ready)
    print(json.dumps({'offline_ready': True, 'private_definition_count': 4,
                      'root_graph_membership': False, 'S2_04_completed': False}))


if __name__ == '__main__':
    main()
