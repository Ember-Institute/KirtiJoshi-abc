import Lean
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  -- moduleNames maps the entire module array; use the indexed record directly.
  let imported ← env.header.modules[index.toNat]?
  return imported.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace AdicCompletionTwoHelpersOriginalFacts
open Lean Elab Term Meta FoundationAudit

def actualFacts (cache : AxiomCache) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  let value := ci.value? (allowOpaque := true)
  let axs ← cachedAxioms cache name
  let taxs ← expressionAxioms cache ci.type
  let vaxs ← match value with
    | none => pure #[] | some expr => expressionAxioms cache expr
  let shape ← match getStructureInfo? (← getEnv) name with
    | none => pure Json.null
    | some info => checked (structureShape info pure)
  let ruleRhs ← match ci with
    | .recInfo info => info.rules.toArray.mapM fun rule => checked (encodeExpr rule.rhs)
    | _ => pure #[]
  return Json.mkObj [
    ("name", toJson name.toString), ("nameExpr", encodeName name),
    ("module", match moduleOf (← getEnv) name with
      | none => Json.null | some owner => toJson owner.toString),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("valueExpr", ← match value with | none => pure Json.null | some expr => checked (encodeExpr expr)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("isProposition", toJson (← isProp ci.type)),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name)),
    ("isClass", toJson (Lean.isClass (← getEnv) name)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("typeUsedConstants", Json.arr (ci.type.getUsedConstants.map encodeName)),
    ("valueUsedConstants", Json.arr (match value with
      | none => #[] | some expr => expr.getUsedConstants.map encodeName)),
    ("computationShape", ← checked (computationShape ci pure)),
    ("recursorRuleRhs", Json.arr ruleRhs), ("structure", shape),
    ("hasSorryAx", toJson (axs.contains `sorryAx))]

def query : TermElabM Unit := do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected original compiler4.35.0-rc3"
  let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_ADIC_HELPER_QUERY_CONFIG")
  unless (← checked (stringField config "schema")) == "tate-theta-adic-two-actual-helper-query-config-v1" do
    throwError "Expected the two actual missing helper Name records"
  let rows ← checked (arrayField config "roots")
  unless rows.size == 2 do throwError "Only the two actually missing helper roots may be queried"
  let roots ← rows.mapM fun row => do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    unless name.toString == (← checked (stringField row "name")) do throwError "Actual helper structural Name differs"
    return name
  let env ← getEnv
  let owners ← roots.mapM fun name => do
    let some owner := moduleOf env name | throwError "Missing actual source helper owner: {name}"
    return owner
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let mut queue := roots
  let mut seen : Array Name := #[]
  let mut edges : Array Json := #[]
  let mut facts : Array Json := #[]
  let mut usedNames : Array Name := #[]
  let mut index := 0
  while index < queue.size do
    let name := queue[index]!
    index := index + 1
    if seen.contains name then continue
    seen := seen.push name
    let ci ← getConstInfo name
    facts := facts.push (← actualFacts cache name)
    let mut exprs := #[ci.type] ++ (ci.value? (allowOpaque := true)).toArray
    if let .recInfo info := ci then
      for rule in info.rules do exprs := exprs.push rule.rhs
    for expr in exprs do
      for used in expr.getUsedConstants do
        unless usedNames.contains used do usedNames := usedNames.push used
        if used != name && (moduleOf env used).any owners.contains then
          let dependency ← getConstInfo used
          if (dependency.value? (allowOpaque := true)).isSome then
            edges := edges.push (Json.mkObj [("from", encodeName name), ("to", encodeName used)])
            unless seen.contains used || queue.contains used do queue := queue.push used
  let names ← (usedNames.qsort Name.lt).mapM fun name => do
    let ci ← getConstInfo name
    return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
      ("constantKind", toJson (kind ci)),
      ("module", match moduleOf env name with | none => Json.null | some owner => toJson owner.toString)]
  let output ← absoluteEnv "NEXT_CARRIER_ADIC_HELPER_SOURCE_FACTS_OUTPUT"
  IO.FS.writeFile output ((Json.mkObj [
    ("schema", toJson "tate-theta-adic-two-helper-original-facts-v1"),
    ("compilerVersion", toJson Lean.versionString), ("queryConfiguration", config),
    ("roots", Json.arr (roots.map encodeName)), ("owners", Json.arr (owners.map encodeName)),
    ("sameOwnerValueClosureNames", Json.arr (seen.map encodeName)),
    ("sameOwnerValueClosureEdges", Json.arr edges), ("facts", Json.arr facts),
    ("usedStandardNames", Json.arr names), ("usedStandardNameCount", toJson names.size),
    ("policy", toJson "Two actual missing helper roots with copied structural Names, plus only their necessary same-owner value-bearing type/value/rule dependency closure. No guessed private Name, Nat pre-expansion, or data compatibility.")]).compress ++ "\n")
  logInfo s!"Two actual source helpers: {facts.size} exact body records and {names.size} actual used standard Names"

end AdicCompletionTwoHelpersOriginalFacts
syntax (name := queryAdicCompletionTwoHelpersOriginalFacts) "query_adic_completion_two_helpers_original_facts" : command
@[command_elab queryAdicCompletionTwoHelpersOriginalFacts]
def elabQueryAdicCompletionTwoHelpersOriginalFacts : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM AdicCompletionTwoHelpersOriginalFacts.query
query_adic_completion_two_helpers_original_facts
