




module

public import Mathlib.Algebra.BigOperators.Finprod
public import Mathlib.Topology.Algebra.InfiniteSum.SummationFilter
public import Mathlib.Topology.Separation.Hausdorff
public import Mathlib.Algebra.BigOperators.Group.Finset.Preimage









































@[expose] public section








noncomputable section

open Filter Function SummationFilter

open scoped Topology

variable {α β γ : Type*}

section HasProd

variable [CommMonoid α] [TopologicalSpace α]
















@[to_additive 















]
def HasProd (f : β → α) (a : α) (L := unconditional β) : Prop :=
  Tendsto (fun s : Finset β ↦ ∏ b ∈ s, f b) L.filter (𝓝 a)



@[to_additive

]
def Multipliable (f : β → α) (L := unconditional β) : Prop :=
  ∃ a, HasProd f a L

@[to_additive]
lemma Multipliable.mono_filter {f : β → α} {L₁ L₂ : SummationFilter β}
    (hf : Multipliable f L₂) (h : L₁.filter ≤ L₂.filter) : Multipliable f L₁ :=
  match hf with | ⟨a, ha⟩ => ⟨a, ha.mono_left h⟩

open scoped Classical in









@[to_additive 








]
noncomputable irreducible_def tprod (f : β → α) (L := unconditional β) :=
  if h : Multipliable f L then
    if L.HasSupport ∧ (mulSupport f ∩ L.support).Finite then finprod (L.support.mulIndicator f)
    else if HasProd f 1 L then 1
    else h.choose
  else 1

variable {L : SummationFilter β}

@[inherit_doc tprod]
notation3 "∏'[" L "]" (...)", "r:67:(scoped f => tprod f L) => r
@[inherit_doc tsum]
notation3 "∑'[" L "]" (...)", "r:67:(scoped f => tsum f L) => r


@[inherit_doc tprod]
notation3 "∏' "(...)", "r:67:(scoped f => tprod f (unconditional _)) => r
@[inherit_doc tsum]
notation3 "∑' "(...)", "r:67:(scoped f => tsum f (unconditional _)) => r

@[to_additive]
lemma hasProd_bot (hL : ¬L.NeBot) (f : β → α) (a : α) :
    HasProd f a L := by
  have : L.filter = ⊥ := by contrapose! hL; exact ⟨hL⟩
  rw [HasProd, this]
  exact tendsto_bot

@[to_additive]
lemma multipliable_bot (hL : ¬L.NeBot) (f : β → α) :
    Multipliable f L :=
  ⟨1, hasProd_bot hL ..⟩






@[to_additive 



]
lemma tprod_bot (hL : ¬L.NeBot) (f : β → α) : ∏'[L] b, f b = ∏ᶠ b, f b := by
  simp only [tprod_def, dif_pos (multipliable_bot hL f)]
  have : L.LeAtTop := L.leAtTop_of_not_NeBot hL
  rw [L.support_eq_univ, Set.inter_univ, Set.mulIndicator_univ]
  by_cases hf : (mulSupport f).Finite
  · rw [eq_true_intro hf, if_pos]
    simp only [and_true]
    infer_instance
  · rwa [if_neg (by tauto), if_pos (hasProd_bot hL _ _), finprod_of_infinite_mulSupport]

variable {f : β → α} {a : α} {s : Finset β}

@[to_additive]
theorem HasProd.multipliable (h : HasProd f a L) : Multipliable f L :=
  ⟨a, h⟩

@[to_additive]
theorem tprod_eq_one_of_not_multipliable (h : ¬Multipliable f L) : ∏'[L] b, f b = 1 := by
  simp [tprod_def, h]

@[to_additive]
theorem Function.Injective.hasProd_map_iff {L : SummationFilter γ} {g : γ → β} (hg : Injective g) :
    HasProd f a (L.map ⟨g, hg⟩) ↔ HasProd (f ∘ g) a L := by
  simp [HasProd, Function.comp_def]

@[to_additive]
theorem Function.Injective.hasProd_comap_iff_of_hasSupport [L.HasSupport] {g : γ → β}
    (hg : Injective g) (hf : ∀ x ∈ L.support, x ∉ Set.range g → f x = 1) :
    HasProd (f ∘ g) a (L.comap ⟨g, hg⟩) ↔ HasProd f a L := by
  simp only [HasProd, SummationFilter.comap_filter, tendsto_map'_iff, comp_apply,
    Embedding.coeFn_mk, Function.comp_def]
  refine tendsto_congr' ?_
  filter_upwards [L.eventually_le_support] with s hs
  rw [s.prod_preimage]
  exact fun x h h' ↦ hf x (hs h) h'

@[to_additive]
theorem Function.Injective.hasProd_comap_iff {g : γ → β} (hg : Injective g)
    (hf : ∀ x, x ∉ Set.range g → f x = 1) :
    HasProd (f ∘ g) a (L.comap ⟨g, hg⟩) ↔ HasProd f a L := by
  simp only [HasProd, SummationFilter.comap_filter, tendsto_map'_iff, comp_apply,
    Embedding.coeFn_mk, Function.comp_def]
  refine tendsto_congr fun s ↦ ?_
  rw [s.prod_preimage]
  exact fun x _ h ↦ hf x h

@[to_additive]
theorem Function.Injective.hasProd_iff {g : γ → β} (hg : Injective g)
    (hf : ∀ x, x ∉ Set.range g → f x = 1) :
    HasProd (f ∘ g) a ↔ HasProd f a := by
  rw [← hg.hasProd_comap_iff hf, SummationFilter.comap_unconditional]

@[to_additive]
theorem hasProd_subtype_comap_iff_of_mulSupport_subset {s : Set β} (hf : mulSupport f ⊆ s) :
    HasProd (f ∘ (↑) : s → α) a (L.comap <| Embedding.subtype _) ↔ HasProd f a L :=
  Subtype.coe_injective.hasProd_comap_iff <| by simpa using mulSupport_subset_iff'.1 hf

@[to_additive]
theorem hasProd_subtype_iff_of_mulSupport_subset {s : Set β} (hf : mulSupport f ⊆ s) :
    HasProd (f ∘ (↑) : s → α) a ↔ HasProd f a := by
  simpa using hasProd_subtype_comap_iff_of_mulSupport_subset hf (L := unconditional _)

@[to_additive]
theorem hasProd_fintype_support [Fintype β] (f : β → α) (L : SummationFilter β) [L.HasSupport]
    [DecidablePred (· ∈ L.support)] : HasProd f (∏ b ∈ L.support, f b) L := by
  apply tendsto_nhds_of_eventually_eq
  have h1 : ⋂ b ∈ L.support, {s | b ∈ s} ∈ L.filter :=
    (L.filter.biInter_mem L.support.toFinite).mpr (by tauto)
  have h2 : ⋂ b ∈ L.supportᶜ, {s | b ∉ s} ∈ L.filter :=
    (L.filter.biInter_mem L.supportᶜ.toFinite).mpr
      (fun b hb ↦ (L.eventually_mem_or_not_mem b).resolve_left hb)
  filter_upwards [h1, h2] with s hs hs'
  congr 1
  simp only [Set.mem_iInter, Set.mem_ofPred_eq, Set.mem_compl_iff] at hs hs'
  grind

@[to_additive]
theorem hasProd_fintype [Fintype β] (f : β → α) (L := unconditional β) [L.LeAtTop] :
    HasProd f (∏ b, f b) L := by
  simpa using hasProd_fintype_support f L

@[to_additive]
theorem Finset.hasProd_support (s : Finset β) (f : β → α) (L := unconditional (s : Set β))
    [L.HasSupport] [DecidablePred (· ∈ L.support)] :
    HasProd (f ∘ (↑) : (↑s : Set β) → α)
      (∏ b ∈ (L.support.toFinset.map <| Embedding.subtype _), f b) L := by
  simpa [prod_attach] using hasProd_fintype_support (f ∘ Subtype.val) L

set_option backward.isDefEq.respectTransparency false in

@[to_additive]
protected theorem Finset.hasProd (s : Finset β) (f : β → α)
    (L := unconditional (s : Set β)) [L.LeAtTop] :
    HasProd (f ∘ (↑) : (↑s : Set β) → α) (∏ b ∈ s, f b) L := by
  simpa [prod_attach, Embedding.subtype] using Finset.hasProd_support s f L


@[to_additive 
]
theorem hasProd_prod_support_of_ne_finset_one (hf : ∀ b ∈ L.support, b ∉ s → f b = 1)
    [L.HasSupport] [DecidablePred (· ∈ L.support)] :
    HasProd f (∏ b ∈ (↑s ∩ L.support).toFinset, f b) L := by
  apply tendsto_nhds_of_eventually_eq
  have h1 : ⋂ b ∈ (↑s ∩ L.support), {s | b ∈ s} ∈ L.filter :=
    (L.filter.biInter_mem (Set.toFinite _)).mpr (fun b hb ↦ hb.2)
  filter_upwards [h1, L.eventually_le_support] with t ht ht'
  simp only [Set.mem_iInter] at ht
  apply Finset.prod_congr_of_eq_on_inter <;> grind


@[to_additive 
]
theorem hasProd_prod_of_ne_finset_one (hf : ∀ b ∉ s, f b = 1) [L.LeAtTop] :
    HasProd f (∏ b ∈ s, f b) L :=
  ((hasProd_subtype_iff_of_mulSupport_subset <| mulSupport_subset_iff'.2 hf).1 <| s.hasProd f)
    |>.mono_left L.le_atTop

@[to_additive]
theorem multipliable_of_ne_finset_one (hf : ∀ b ∉ s, f b = 1) [L.HasSupport] :
    Multipliable f L := by
  classical
  exact (hasProd_prod_support_of_ne_finset_one (fun b _ hb ↦ hf b hb)).multipliable

@[to_additive]
theorem Multipliable.hasProd (ha : Multipliable f L) : HasProd f (∏'[L] b, f b) L := by
  
  classical
  rw [tprod_def, dif_pos ha]
  split_ifs with h h'
  · convert! hasProd_prod_support_of_ne_finset_one (s := h.2.toFinset) (L := L) _ using 2
    · simp only [Set.inter_eq_left.mpr (show ↑h.2.toFinset ⊆ L.support by simp)]
      simp only [Set.Finite.coe_toFinset, Finset.toFinset_coe]
      rw [finprod_eq_prod_of_mulSupport_subset (s := h.2.toFinset)]
      · exact Finset.prod_congr rfl (by simp_all)
      · simp
    · grind [Set.Finite.mem_toFinset, mem_mulSupport]
    · exact h.1
  · exact h'
  · exact ha.choose_spec

variable [T2Space α] [L.NeBot]

@[to_additive]
theorem HasProd.unique {a₁ a₂ : α} :
    HasProd f a₁ L → HasProd f a₂ L → a₁ = a₂ := by
  exact tendsto_nhds_unique

@[to_additive]
theorem HasProd.tprod_eq (ha : HasProd f a L) : ∏'[L] b, f b = a :=
  (Multipliable.hasProd ⟨a, ha⟩).unique ha

@[to_additive]
theorem Multipliable.hasProd_iff (h : Multipliable f L) :
    HasProd f a L ↔ ∏'[L] b, f b = a :=
  Iff.intro HasProd.tprod_eq fun eq ↦ eq ▸ h.hasProd

@[to_additive]
theorem tprod_eq_of_filter_le {L₁ L₂ : SummationFilter β} [L₁.NeBot]
    (h : L₁.filter ≤ L₂.filter) (hf : Multipliable f L₂) : ∏'[L₁] b, f b = ∏'[L₂] b, f b :=
  (hf.mono_filter h).hasProd_iff.mp (hf.hasProd.mono_left h)

@[to_additive]
theorem tprod_eq_of_multipliable_unconditional [L.LeAtTop] (hf : Multipliable f) :
     ∏'[L] b, f b = ∏' b, f b :=
  tprod_eq_of_filter_le L.le_atTop hf

end HasProd
