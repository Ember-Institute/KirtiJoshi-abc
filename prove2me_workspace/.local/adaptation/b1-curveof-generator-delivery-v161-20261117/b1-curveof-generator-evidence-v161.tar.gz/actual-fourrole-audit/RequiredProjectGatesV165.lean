import ArithmeticTeichmullerSpaces.Prologue.Audit.Checks
import ArithmeticTeichmullerSpaces.Prologue.Audit.ImportAudit
import ArithmeticTeichmullerSpaces.Act1Scene1
import ArithmeticTeichmullerSpaces.Prologue.Audit.AxiomAudit
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfGenerator
import Solutions.Sol_AbcAdaptation_Tripod_mem_fieldOfExtended_self

#print axioms AbcAdaptation.Tripod.mem_fieldOfExtended_self
#print axioms AbcAdaptation.Tripod.gen'
#print axioms solution

open Lean Elab Command Meta in
run_meta do
  for name in #[``AbcAdaptation.Tripod.mem_fieldOfExtended_self,
      ``AbcAdaptation.Tripod.gen', ``solution] do
    let axioms ← collectAxioms name
    for axiomName in axioms do
      unless axiomName == `propext || axiomName == `Classical.choice || axiomName == `Quot.sound do
        throwError "Unexpected axiom {axiomName} in {name}"
  logInfo "Checks, ImportAudit, Act1Scene1 and AxiomAudit imported; all three new declarations have standard axioms only"
