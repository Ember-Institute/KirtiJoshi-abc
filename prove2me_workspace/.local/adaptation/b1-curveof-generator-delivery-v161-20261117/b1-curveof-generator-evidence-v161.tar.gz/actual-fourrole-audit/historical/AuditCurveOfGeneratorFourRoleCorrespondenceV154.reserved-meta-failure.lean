import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfGenerator
import Solutions.Sol_AbcAdaptation_Tripod_mem_fieldOfExtended_self

import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData

open AbcAdaptation.Tripod

theorem GeneratorPlatformShape.mem_fieldOfExtended_self (l : AbcAdaptation.Tripod.Qbar) : l ∈ AbcAdaptation.Tripod.fieldOf' l := by
  exact AbcAdaptation.Tripod.mem_fieldOfExtended_self l

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare
namespace CurveOfGeneratorReview
open Lean Elab Term Meta FoundationAudit BasicNativeCompare

def uniqueActual (display owner : String) : MetaM Name := do
  let env ← getEnv
  let found := env.constants.fold (fun acc n _ =>
    if n.toString == display && (if owner == "CURRENT_QUERY" then n == ``GeneratorPlatformShape.mem_fieldOfExtended_self else ((moduleOf env n).map Name.toString == some owner))
    then acc.push n else acc) (#[] : Array Name)
  unless found.size == 1 do throwError "Expected unique actual native name {display} at {owner}"
  return found[0]!

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_CURVEOF_GENERATOR_FOURROLE_REVIEW_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-generator-fourrole-audit-config/v154" do
    throwError "Wrong generator audit configuration"
  let platform ← checked (field cfg "expectedPlatformPayload")
  let expectedTheoremName := "AbcAdaptation.Tripod.mem_fieldOfExtended_self"
  let expectedPreamble := "import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData\n\nopen AbcAdaptation.Tripod\n"
  let expectedFormal := "theorem AbcAdaptation.Tripod.mem_fieldOfExtended_self (l : AbcAdaptation.Tripod.Qbar) : l ∈ AbcAdaptation.Tripod.fieldOf' l := by sorry"
  unless (← checked (stringField platform "theorem_name")) == expectedTheoremName &&
      (← checked (stringField platform "preamble")) == expectedPreamble &&
      (← checked (stringField platform "formal_statement")) == expectedFormal do
    throwError "Exact frozen platform theorem_name/preamble/formal_statement differs"
  unless expectedTheoremName.toUTF8.all (· < 128) do throwError "Platform theorem_name must be ASCII"
  let actualCanonical ← uniqueActual expectedTheoremName "Theorems.Thm_AbcAdaptation_Tripod_mem_fieldOfExtended_self"
  unless actualCanonical.toString == expectedTheoremName do throwError "Metadata theorem_name differs from actual canonical full name"
  let shapeInfo ← getConstInfo ``GeneratorPlatformShape.mem_fieldOfExtended_self
  let shapeValue := shapeInfo.value? (allowOpaque := true)
  unless shapeValue.any (fun e => e.getUsedConstants.contains actualCanonical) do
    throwError "Compiled platform shape does not consume the actual canonical membership theorem"
  let bound ← jsonFile (← checked (stringField cfg "boundInputsFile"))
  unless bound == (← checked (field (← checked (field cfg "boundInputsBinding")) "contents")) do
    throwError "Bound complete source facts or boundary map changed"
  let rows ← checked (arrayField bound "sourceRecords")
  unless rows.size == 2 do throwError "Expected actual source membership theorem and generator definition"
  let targets ← checked (arrayField cfg "targets")
  unless targets.size == 4 do throwError "Expected canonical theorem/global solution/compiled platform shape/pure generator definition"
  let mut maps : NameMap := #[]
  for p in ← checked (arrayField bound "acceptedBoundaryPairs") do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    let owner ← checked (decodeName (← checked (field p "targetOwnerNameExpr")))
    unless moduleOf (← getEnv) t == some owner do throwError "Accepted boundary actual owner differs {t}"
    if maps.any (·.1 == s) then throwError "Duplicate accepted source boundary map"
    maps := maps.push (s,t)
  let mut actualTargets : Array (Name × Json) := #[]
  for req in targets do
    let t ← uniqueActual (← checked (stringField req "targetDisplay")) (← checked (stringField req "targetOwner"))
    actualTargets := actualTargets.push (t,req)
    if ← checked (req.getObjValAs? Bool "addSourceNameMap") then
      let s ← checked (decodeName (← checked (field req "sourceNameExpr")))
      if maps.any (·.1 == s) then throwError "New generator map duplicates accepted source map"
      maps := maps.push (s,t)
  let mut reports : Array Json := #[]
  for (t,req) in actualTargets do
    let sourceName ← checked (decodeName (← checked (field req "sourceNameExpr")))
    let selected := rows.filter fun r => (field r "nameExpr").toOption == some (encodeName sourceName)
    unless selected.size == 1 do throwError "Missing unique actual source root"
    let sr := selected[0]!
    let ci ← getConstInfo t
    unless kind ci == (← checked (stringField sr "kind")) do throwError "Source/target constant kind differs {sourceName}"
    unless (← checked (arrayField sr "levelParams")).isEmpty && ci.levelParams.isEmpty do
      throwError "Original source has no universes; native must retain that exact arity"
    unless (← checked (sr.getObjValAs? Bool "valueRead")) &&
        (← checked (sr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
      throwError "Source complete value was not kernel checked"
    let st ← checked (relocateExpr maps #[] #[] false (← checked (field sr "actualTypeExpr")))
    let sv ← checked (relocateExpr maps #[] #[] false (← checked (field sr "actualValueExpr")))
    unless binderInventory st == binderInventory ci.type && binderPlacement st == binderPlacement ci.type &&
        outerForallBinderInfo st == #["default"] do
      throwError "Strict complete TYPE/BinderInfo or explicit Qbar argument differs {sourceName}"
    kernelEq s!"complete actual TYPE {sourceName}" st ci.type
    let some tv := ci.value? (allowOpaque := true) | throwError "Native full proof/value unavailable {t}"
    let sourceValueTYPE ← kernelCheck s!"complete relocated source proof/value {sourceName}" sv
    kernelEq s!"relocated complete proof/value TYPE {sourceName}" sourceValueTYPE st
    let nativeValueTYPE ← kernelCheck s!"complete native proof/value {t}" tv
    kernelEq s!"native complete proof/value TYPE {t}" nativeValueTYPE ci.type
    kernelEq s!"complete source/native proof/value {sourceName}" sv tv
    let meta ← checked (field sr "metadata")
    unless (← checked (field meta "structure")) == Json.null &&
        (← checked (arrayField meta "recursorRules")).isEmpty && (getStructureInfo? (← getEnv) t).isNone do
      throwError "Unexpected structure or recursor metadata"
    unless (← checked (field meta "computationShape")) == (← checked (computationShape ci pure)) do
      throwError "Actual computation metadata differs"
    let axs ← collectAxioms t
    ensureStandard s!"actual target {t}" axs
    for e in #[st,sv,ci.type,tv] do ensureStandard "complete source/native actual Expr" (← expressionAxioms e)
    unless (← checked (sr.getObjValAs? Bool "isInstance")) == Lean.Meta.isInstanceCore (← getEnv) t do
      throwError "Instance registration differs"
    let prop ← isProp ci.type
    unless prop == (← checked (sr.getObjValAs? Bool "isProposition")) do throwError "Prop/data differs"
    reports := reports.push (Json.mkObj [
      ("source",toJson sourceName.toString),("sourceNameExpr",encodeName sourceName),
      ("target",toJson t.toString),("targetNameExpr",encodeName t),
      ("role",← checked (field req "role")),
      ("targetOwner",toJson ((moduleOf (← getEnv) t).map Name.toString)),
      ("completeTYPEKernelEqual",toJson true),("strictTYPEBinderInfoEqual",toJson true),
      ("completeProofOrDataValueKernelEqual",toJson true),
      ("rawValueBinderInfoEqual",toJson (binderPlacement sv == binderPlacement tv)),
      ("rawValueStructurallyEqual",toJson (sv == tv)),
      ("sourceNativeProofByteIdentityClaimed",toJson false),("isProposition",toJson prop),
      ("nativeActualTYPE",← checked (encodeExpr ci.type)),("nativeActualValue",← checked (encodeExpr tv)),
      ("axioms",toJson (axs.map Name.toString)),("hasSorryAx",toJson (axs.contains `sorryAx))])
  let output ← checked (stringField cfg "outputFile")
  unless output.startsWith "/" do throwError "Expected absolute output path"
  if let some parent := (System.FilePath.mk output).parent then IO.FS.createDirAll parent
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "B1-generator-fourrole-and-pure-generator-correspondence/v154"),
    ("reports",Json.arr reports),("allRequiredCorrespondenceChecksPassed",toJson true),
    ("namedMembershipTheoremConsumedByPureGenerator",toJson true),
    ("sourceMembershipCanonicalSolutionPlatformFourRolesCompared",toJson true),
    ("compiledPlatformShapeComparedAgainstCompleteSourceTYPEAndProof",toJson true),
    ("platformTheoremNameEqualsActualCanonicalFullName",toJson true),
    ("expectedPlatformPayload",platform),
    ("sourceBinderRestrictedToPt",toJson false),("newAssumptionsIntroduced",toJson false),
    ("configuration",cfg)]).pretty ++ "\n")
  logInfo "Original membership theorem/global solution and pure generator actual TYPE/value correspond"
end CurveOfGeneratorReview
