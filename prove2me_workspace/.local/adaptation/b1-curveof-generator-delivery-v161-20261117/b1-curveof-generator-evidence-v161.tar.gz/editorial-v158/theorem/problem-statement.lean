import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData

open AbcAdaptation.Tripod

theorem AbcAdaptation.Tripod.mem_fieldOfExtended_self (l : AbcAdaptation.Tripod.Qbar) : l ∈ AbcAdaptation.Tripod.fieldOf' l := by sorry
