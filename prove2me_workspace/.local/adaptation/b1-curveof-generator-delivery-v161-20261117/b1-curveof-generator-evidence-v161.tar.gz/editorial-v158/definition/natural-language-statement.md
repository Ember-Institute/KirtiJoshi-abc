# English

For every $l\in\overline{\mathbb Q}$, where $\overline{\mathbb Q}$ is the algebraic closure of $\mathbb Q$, fix the chosen elements $i,r_l,s_l\in\overline{\mathbb Q}$ supplied by the definitions, with $i^2=-1$, $r_l^2=l$, and $s_l^2=1-l$. Let $G_l$ be the group consisting of the point at infinity $O$ and the nonsingular affine points $(x,y)$ of the Weierstrass curve $y^2=x(x-1)(x-l)$ over $\overline{\mathbb Q}$; here an affine point is nonsingular precisely when it satisfies this equation and at least one of $3x^2-2(1+l)x+l$ and $2y$ is nonzero. Put $c(O)=\varnothing$ and $c((x,y))=\{x,y\}$, and, for $n=3,5$, put $T_{l,n}=\{P\in G_l:nP=O\}$, where $nP$ is repeated addition in this group. Define $F_l$ (the field denoted by $\mathrm{fieldOf}'(l)$) to be the smallest intermediate field between $\mathbb Q$ and $\overline{\mathbb Q}$ containing the full set $\{l,i,r_l,s_l\}\cup\bigcup_{P\in T_{l,3}}c(P)\cup\bigcup_{P\in T_{l,5}}c(P)$. The noncomputable definition $\mathrm{gen}'(l)$ is the element of the subtype $F_l=\{a\in\overline{\mathbb Q}:a\in F_l\}$ whose underlying value is $l$ and whose membership certificate is the theorem $l\in F_l$ stated above. Thus its value after inclusion into $\overline{\mathbb Q}$ is $l$. This definition applies to every $l\in\overline{\mathbb Q}$, including $l=0$ and $l=1$, without additional hypotheses.

## Original paper background and scope

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

> Suppose that $X=\mathbb P^1_{\mathbb Q}$ is the projective line over $\mathbb Q$, and that $D\subseteq X$ is the divisor consisting of the three points “$0$”, “$1$”, and “$\infty$”. We shall regard $X$ as the “$\lambda$-line” — i.e., we shall regard the standard coordinate on $X=\mathbb P^1_{\mathbb Q}$ as the “$\lambda$” in the Legendre form “$y^2=x(x-1)(x-\lambda)$” of the Weierstrass equation defining an elliptic curve — and hence as being equipped with a natural classifying morphism $U_X\to(\mathcal M_{\mathrm{ell}})_{\mathbb Q}$ [cf. the discussion preceding Proposition 1.8].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`. The remainder of the corollary is omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

> $F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`.

These excerpts supply the Legendre-parameter and selected-closure background. The full field $F_l$ is the reference project's explicit adjoin of the parameter, selected roots, and the specified torsion coordinates. The membership lemma follows from inclusion of a generating set in its generated field; it is not quoted as a paper theorem. The dependent element is the parameter itself paired with that membership proof. Neither construction says that $l$ alone generates the full field, and neither requires or proves torsion finiteness, finite degree, a number-field structure, or the Galois property.


## Intuitive explanation (non-rigorous)

The definition views the same parameter as an element of the larger generated field, with its membership certificate attached.

# 简体中文

对每个 $l\in\overline{\mathbb Q}$，其中 $\overline{\mathbb Q}$ 是 $\mathbb Q$ 的代数闭包，取各定义选定的元素 $i,r_l,s_l\in\overline{\mathbb Q}$，满足 $i^2=-1$、$r_l^2=l$、$s_l^2=1-l$。令 $G_l$ 为由无穷远点 $O$ 以及 $\overline{\mathbb Q}$ 上的 Weierstrass 曲线 $y^2=x(x-1)(x-l)$ 的非奇异仿射点 $(x,y)$ 组成的群；这里，一个仿射点非奇异，当且仅当它满足该方程，且 $3x^2-2(1+l)x+l$ 与 $2y$ 中至少一个非零。令 $c(O)=\varnothing$、$c((x,y))=\{x,y\}$，并对 $n=3,5$ 令 $T_{l,n}=\{P\in G_l:nP=O\}$，其中 $nP$ 表示在这个群中重复相加。定义 $F_l$（即 $\mathrm{fieldOf}'(l)$ 所表示的域）为 $\mathbb Q$ 与 $\overline{\mathbb Q}$ 之间包含完整集合 $\{l,i,r_l,s_l\}\cup\bigcup_{P\in T_{l,3}}c(P)\cup\bigcup_{P\in T_{l,5}}c(P)$ 的最小中间域。不可计算定义 $\mathrm{gen}'(l)$ 是子类型 $F_l=\{a\in\overline{\mathbb Q}:a\in F_l\}$ 中的元素，其底层值为 $l$，其属于该域的证明由上述定理 $l\in F_l$ 给出。因此，将它包含到 $\overline{\mathbb Q}$ 后所得的值就是 $l$。该定义适用于所有 $l\in\overline{\mathbb Q}$，包括 $l=0$ 与 $l=1$，没有其他假设。

## 论文原文背景与范围

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2 开头、“Let”之前的完整两句，印刷页与文件页均为第 41 页。精确英文引文见英文部分，推论其余部分未引用。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页。精确英文引文见英文部分。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

这些节录提供 Legendre 参数及选定代数闭包的背景。完整的域 $F_l$ 是参考工程通过参数、选定平方根及指定挠点坐标显式生成的域。成员引理由生成集合包含于其生成域这一事实得到，不称为论文中的原文定理。依赖类型中的元素是参数本身与其成员证明组成的有序数据。两个构造均不宣称仅由 $l$ 就生成整个域，也不要求或证明挠点有限性、有限次数、数域结构或 Galois 性质。


## 直观解释（非严格）

该定义把同一个参数看作较大生成域中的元素，并附上它属于该域的证明。

# 日本語

任意の $l\in\overline{\mathbb Q}$ に対し、$\overline{\mathbb Q}$ を $\mathbb Q$ の代数閉包とし、各定義によって選ばれた元 $i,r_l,s_l\in\overline{\mathbb Q}$ を取る。これらは $i^2=-1$、$r_l^2=l$、$s_l^2=1-l$ を満たす。$G_l$ を、無限遠点 $O$ と、$\overline{\mathbb Q}$ 上のワイエルシュトラス曲線 $y^2=x(x-1)(x-l)$ の非特異アフィン点 $(x,y)$ からなる群とする。ここで、アフィン点が非特異であるとは、この方程式を満たし、$3x^2-2(1+l)x+l$ と $2y$ の少なくとも一方が零でないことである。$c(O)=\varnothing$、$c((x,y))=\{x,y\}$ と置き、$n=3,5$ に対して $T_{l,n}=\{P\in G_l:nP=O\}$ と置く。ただし、$nP$ はこの群での反復加法を表す。$F_l$（$\mathrm{fieldOf}'(l)$ が表す体）を、集合 $\{l,i,r_l,s_l\}\cup\bigcup_{P\in T_{l,3}}c(P)\cup\bigcup_{P\in T_{l,5}}c(P)$ 全体を含む、$\mathbb Q$ と $\overline{\mathbb Q}$ の間の最小の中間体と定義する。非計算的定義 $\mathrm{gen}'(l)$ は、部分型 $F_l=\{a\in\overline{\mathbb Q}:a\in F_l\}$ の元であり、その基となる値は $l$、その体に属することの証明は上述の定理 $l\in F_l$ によって与えられる。したがって、$\overline{\mathbb Q}$ への包含によって得られる値は $l$ である。この定義は、$l=0$ と $l=1$ を含む任意の $l\in\overline{\mathbb Q}$ に適用され、追加の仮定はない。

## 論文原文の背景と範囲

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示した。系の残りは引用しない。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61。正確な英文は英語部分に示した。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

これらの引用は、ルジャンドルのパラメータと選ばれた代数閉包の背景を与える。完全な体 $F_l$ は、パラメータ、選ばれた平方根、指定された等分点座標から、参照プロジェクトで明示的に生成される体である。所属の補題は、生成集合が生成体に含まれることから従うものであり、論文の逐語的な定理とはしない。依存型の元はパラメータそのものと所属証明の組である。いずれの構成も $l$ だけで体全体が生成されるとは主張せず、等分点集合の有限性、有限次数、数体構造、ガロア性を要求も証明もしない。


## 直観的説明（非厳密）

この定義は、同じパラメータを、所属証明を添えて大きい生成体の元と見なす。
