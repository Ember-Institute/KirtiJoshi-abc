from pathlib import Path
import json,hashlib
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');D=Path('/tmp/p2m-b1-curveof-generator-v153-20261117');V=Path('/tmp/p2m-b1-curveof-generator-v152-20261117');P=W/'.local/adaptation/b1-source-parser-v93-20261117/parser-output/Iut-Tripod-CurveOf.jsonl';B=P.with_suffix('.normalized.lean').read_bytes();rows={r['commandIndex']:r for r in map(json.loads,P.read_text().splitlines()) if r.get('commandSyntax')}
old="mem_fieldOf'_self";new='mem_fieldOfExtended_self';theoremFull='AbcAdaptation.Tripod.'+new;slug=theoremFull.replace('.','_')
def nodes(n):
 yield n
 for c in n.get('children',[]):yield from nodes(c)
def raw(idx):
 c=rows[idx];a,z=c['range']['start']['offset'],c['range']['end']['offset'];return c,a,B[a:z]
def replaceBoundIdentifier(idx,identifier,replacement):
 c,a,src=raw(idx);selected=[x for x in nodes(c['commandSyntax']) if x.get('identifier')==identifier];assert len(selected)==1
 r=selected[0]['range'];i,j=r['start']['offset']-a,r['end']['offset']-a;assert src[i:j].decode()==identifier
 return src[:i]+replacement.encode()+src[j:],{'originalIdentifier':identifier,'replacementIdentifier':replacement,'sourceCommandIndex':idx,'sourceIdentifierRange':r,'originalCommandSHA256':hashlib.sha256(src).hexdigest(),'resultCommandSHA256':hashlib.sha256(src[:i]+replacement.encode()+src[j:]).hexdigest(),'replacementByteRangeInCommand':[i,j]}
notice='''/-
Adaptation provenance: accepted Iut source AST spans; only bound identifier changes are recorded.
Original repository: https://github.com/lana-agents/iut
Original commit: 07cb1da58f6d428a670dbb5dd6093d428bcbcdd8
Original source: Iut/Tripod/CurveOf.lean
-/
/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
''';imp='import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData\n';ctx='\nnamespace AbcAdaptation.Tripod\nopen WeierstrassCurve NumberField\nopen scoped IntermediateField\n\n';rewrites=[]
for sub in ['canonical','solution','definition','stub']:(D/sub).mkdir(exist_ok=True)
cmd,record=replaceBoundIdentifier(23,old,new);rewrites.append(record);C=D/'canonical'/('Thm_'+slug+'.lean');C.write_text(notice+imp+ctx+cmd.decode()+'\n\nend AbcAdaptation.Tripod\n')
sol,record=replaceBoundIdentifier(23,old,'solution');rewrites.append(record);S=D/'solution'/('Sol_'+slug+'.lean');S.write_text(notice+imp+'\nopen AbcAdaptation.Tripod\nopen WeierstrassCurve NumberField\nopen scoped IntermediateField\n\n'+sol.decode()+'\n')
gen,record=replaceBoundIdentifier(31,old,new);rewrites.append(record);G=D/'definition/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfGenerator.lean';G.write_text(notice+imp+'import Theorems.Thm_'+slug+'\n'+ctx+gen.decode()+'\n\nend AbcAdaptation.Tripod\n')
# Stub preserves the renamed declaration signature. It is never proof acceptance evidence.
c,a,orig=raw(23);assign=next(x for x in nodes(c['commandSyntax']) if x.get('atom')==':=');end=assign['range']['start']['offset']-a;signature=orig[:end].decode().replace(old,new,1);T=D/'stub'/('Thm_'+slug+'.lean');T.write_text(notice+imp+ctx+signature+':= by\n  sorry\n\nend AbcAdaptation.Tripod\n')
for short,out in [('mem_fieldOfPrime_self','source-membership-full-actual-fact.json'),('genPrime','source-generator-full-actual-fact.json')]:
 (D/out).write_bytes((V/short/'source-full-actual-fact.json').read_bytes())
(D/'ast-bound-identifier-rewrites.json').write_text(json.dumps({'schema':'B1-generator-ASCII-AST-bound-renames/v153','publicTheoremFullName':theoremFull,'platformFileSlug':slug,'expectedPlatformFormalStatement':"(l : Qbar) : l ∈ fieldOf' l",'definitionAPIName':'AbcAdaptation_Reference_Iut_Tripod_CurveOfGenerator','generatorIdentifierUnchanged':"gen'",'rewrites':rewrites,'onlyTheoremBindingAndGeneratorUseSiteChanged':True,'newMathematicalParametersOrAssumptions':False,'originalSourceProofBodyBytesUnchanged':True,'globalSolutionOnlyDeclIdChanged':True},ensure_ascii=False,indent=2)+'\n')
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(D/'minimal-source-ready.json').write_text(json.dumps({'schema':'B1-generator-ASCII-source-ready/v153','publicTheoremFullName':theoremFull,'expectedPlatformFormalStatement':"(l : Qbar) : l ∈ fieldOf' l",'sourceFiles':[pin(p) for p in [C,S,G,T]],'sourceASTBinding':pin(P),'sourceNormalizedBytes':pin(P.with_suffix('.normalized.lean')),'previousV152DraftUnchanged':True,'compiled':False},ensure_ascii=False,indent=2)+'\n')
print(C);print(S);print(G)
