# CurveOf generator ASCII theorem delivery v153

公开定理：`AbcAdaptation.Tripod.mem_fieldOfExtended_self`。
平台文件slug严格由完整定理名替换点号得到：`AbcAdaptation_Tripod_mem_fieldOfExtended_self`。
平台formal statement精确为 `(l : Qbar) : l ∈ fieldOf' l`。

先验收canonical与独立global `solution`；再验收消费该具名定理的纯定义CurveOfGenerator。源gen'标识、显式l:Qbar、fieldOf'、subtype构造全部保持，唯一定义内改动是原AST中成员定理的use-site标识替换。没有Pt限制、NumberField假设或重新定义fieldOf'。

三个最小源文件：

- canonical/Thm_AbcAdaptation_Tripod_mem_fieldOfExtended_self.lean
- solution/Sol_AbcAdaptation_Tripod_mem_fieldOfExtended_self.lean
- definition/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfGenerator.lean

stub仅供平台声明，不是证明验收证据。成员定理源proof body原字节保留；global solution只改原declId为solution。exact AST标识range及前后command哈希见ast-bound-identifier-rewrites.json。

最终actual审查：AuditCurveOfGeneratorActualCorrespondenceV153.lean；环境变量B1_CURVEOF_GENERATOR_ASCII_REVIEW_CONFIG。复制query、generator-audit.bound-inputs.json、generator-audit.config.json到当前工作区，修改配置boundInputsFile/outputFile。首次新叶60s/16GiB，主智能体统一exclusive MCP-CI。source2 fullfacts保持实际原NameExpr，target运行时按新owner/display唯一定位真实NameExpr，完整TYPE/proof/data值、BinderInfo/无u、元数据、公理仍严格核验。

V152完整草稿保留历史未覆盖。本目录未Lean/CI/API/Git，未改主区。
