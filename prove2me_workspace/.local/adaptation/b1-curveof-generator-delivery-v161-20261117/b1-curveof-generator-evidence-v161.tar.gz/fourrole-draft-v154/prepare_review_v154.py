from pathlib import Path
import json,hashlib
V=Path('/tmp/p2m-b1-curveof-generator-v153-20261117');D=Path('/tmp/p2m-b1-curveof-generator-v154-20261117');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
full='AbcAdaptation.Tripod.mem_fieldOfExtended_self'
preamble='import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData\n\nopen AbcAdaptation.Tripod\n'
formal="theorem AbcAdaptation.Tripod.mem_fieldOfExtended_self (l : AbcAdaptation.Tripod.Qbar) : l ∈ AbcAdaptation.Tripod.fieldOf' l := by sorry"
platformId='GeneratorPlatformShape.mem_fieldOfExtended_self';proof='by\n  exact AbcAdaptation.Tripod.mem_fieldOfExtended_self l'
# The formal declaration is replayed with exactly two byte-span edits: declId and proof.
idStart=formal.index(full);idEnd=idStart+len(full);proofStart=formal.index('by sorry');proofEnd=len(formal)
compiled=formal[:idStart]+platformId+formal[idEnd:proofStart]+proof+formal[proofEnd:]
assert compiled=="theorem GeneratorPlatformShape.mem_fieldOfExtended_self (l : AbcAdaptation.Tripod.Qbar) : l ∈ AbcAdaptation.Tripod.fieldOf' l := by\n  exact AbcAdaptation.Tripod.mem_fieldOfExtended_self l"
expected={'theorem_name':full,'preamble':preamble,'formal_statement':formal}
(D/'frozen-expected-platform-payload-input.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2)+'\n')
(D/'platform-shape-replay.lean.txt').write_text(preamble+'\n'+compiled+'\n')
(D/'platform-formal-two-edit-replay.json').write_text(json.dumps({'schema':'B1-generator-platform-two-edit-replay/v154','sourceFormalStatement':formal,'sourceFormalStatementSHA256':hashlib.sha256(formal.encode()).hexdigest(),'replayedStatement':compiled,'replayedStatementSHA256':hashlib.sha256(compiled.encode()).hexdigest(),'edits':[{'role':'declaration-identifier','range':[idStart,idEnd],'original':full,'replacement':platformId},{'role':'proof-body','range':[proofStart,proofEnd],'original':'by sorry','replacement':proof}],'allOtherBytesIdentical':True,'formalAndCompiledBinderScopeIdentical':True,'formalSourceASTBinderReference':json.loads((V/'ast-bound-identifier-rewrites.json').read_text())['rewrites'][0],'sourceProofAssumptionsAdded':False},ensure_ascii=False,indent=2)+'\n')
s=(V/'AuditCurveOfGeneratorActualCorrespondenceV153.lean').read_text();a=s.index('namespace FoundationAudit');s=s[:a]+preamble+'\n'+compiled+'\n\n'+s[a:]
s=s.replace('B1_CURVEOF_GENERATOR_ASCII_REVIEW_CONFIG','B1_CURVEOF_GENERATOR_FOURROLE_REVIEW_CONFIG').replace('B1-generator-audit-config/v153','B1-generator-fourrole-audit-config/v154').replace('B1-generator-membership-and-gen-correspondence/v153','B1-generator-fourrole-and-pure-generator-correspondence/v154')
s=s.replace('''if n.toString == display && ((moduleOf env n).map Name.toString == some owner)''','''if n.toString == display && (if owner == "CURRENT_QUERY" then n == ``GeneratorPlatformShape.mem_fieldOfExtended_self else ((moduleOf env n).map Name.toString == some owner))''')
a='''  let bound ← jsonFile (← checked (stringField cfg "boundInputsFile"))'''
b='''  let platform ← checked (field cfg "expectedPlatformPayload")
  let expectedTheoremName := "AbcAdaptation.Tripod.mem_fieldOfExtended_self"
  let expectedPreamble := "import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData\\n\\nopen AbcAdaptation.Tripod\\n"
  let expectedFormal := "theorem AbcAdaptation.Tripod.mem_fieldOfExtended_self (l : AbcAdaptation.Tripod.Qbar) : l ∈ AbcAdaptation.Tripod.fieldOf' l := by sorry"
  unless (← checked (stringField platform "theorem_name")) == expectedTheoremName &&
      (← checked (stringField platform "preamble")) == expectedPreamble &&
      (← checked (stringField platform "formal_statement")) == expectedFormal do
    throwError "Exact frozen platform theorem_name/preamble/formal_statement differs"
  unless expectedTheoremName.toUTF8.all (· < 128) do throwError "Platform theorem_name must be ASCII"
  let actualCanonical ← uniqueActual expectedTheoremName "Theorems.Thm_AbcAdaptation_Tripod_mem_fieldOfExtended_self"
  unless actualCanonical.toString == expectedTheoremName do throwError "Metadata theorem_name differs from actual canonical full name"
  let shapeInfo ← getConstInfo ``GeneratorPlatformShape.mem_fieldOfExtended_self
  let shapeValue := shapeInfo.value? (allowOpaque := true)
  unless shapeValue.any (fun e => e.getUsedConstants.contains actualCanonical) do
    throwError "Compiled platform shape does not consume the actual canonical membership theorem"
  let bound ← jsonFile (← checked (stringField cfg "boundInputsFile"))'''
assert a in s;s=s.replace(a,b)
s=s.replace('targets.size == 3','targets.size == 4').replace('Expected canonical theorem/global solution/pure generator definition','Expected canonical theorem/global solution/compiled platform shape/pure generator definition')
s=s.replace('''("target",toJson t.toString),("targetNameExpr",encodeName t),''','''("target",toJson t.toString),("targetNameExpr",encodeName t),
      ("role",← checked (field req "role")),''')
s=s.replace('''("namedMembershipTheoremConsumedByPureGenerator",toJson true),''','''("namedMembershipTheoremConsumedByPureGenerator",toJson true),
    ("sourceMembershipCanonicalSolutionPlatformFourRolesCompared",toJson true),
    ("compiledPlatformShapeComparedAgainstCompleteSourceTYPEAndProof",toJson true),
    ("platformTheoremNameEqualsActualCanonicalFullName",toJson true),
    ("expectedPlatformPayload",platform),''')
Q=D/'AuditCurveOfGeneratorFourRoleCorrespondenceV154.lean';Q.write_text(s)
bound=json.loads((V/'generator-audit.bound-inputs.json').read_text());bound['schema']='B1-generator-two-source-facts/v154';B=D/'generator-audit.bound-inputs.json';B.write_text(json.dumps(bound,ensure_ascii=False,separators=(',',':'))+'\n')
def pin(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
c=json.loads((V/'generator-audit.config.json').read_text());c['schema']='B1-generator-fourrole-audit-config/v154';c['boundInputsFile']=str(B);c['boundInputsBinding']={**pin(B),'contents':bound};c['expectedPlatformPayload']=expected;c['outputFile']=str(D/'actual/generator-fourrole-correspondence.json');c['targets'][0]['role']='canonical-membership-theorem';c['targets'][1]['role']='global-solution';c['targets'][2]['role']='pure-generator-data';c['targets'].insert(2,{'sourceNameExpr':bound['sourceRecords'][0]['nameExpr'],'targetDisplay':platformId,'targetOwner':'CURRENT_QUERY','addSourceNameMap':False,'role':'compiled-exact-platform-formal-shape'})
c['status']='uncompiled V154 four membership roles plus complete pure gen data; exact frozen publication fields guarded and replayed with declaration/proof byte edits only';C=D/'generator-fourrole-audit.config.json';C.write_text(json.dumps(c,ensure_ascii=False,separators=(',',':'))+'\n')
(D/'handoff-manifest.json').write_text(json.dumps({'schema':'B1-generator-fourrole-handoff/v154','query':pin(Q),'configuration':pin(C),'boundInputs':pin(B),'expectedPlatformPayload':pin(D/'frozen-expected-platform-payload-input.json'),'twoEditReplay':pin(D/'platform-formal-two-edit-replay.json'),'environmentVariable':'B1_CURVEOF_GENERATOR_FOURROLE_REVIEW_CONFIG','firstLeafEstimate':{'expected_duration':'60s','expected_memory':'16GiB'},'stageInstructions':'Stage query/bound-inputs/config; change boundInputsFile/outputFile. Publication payload must copy theorem_name,preamble,formal_statement exactly from expectedPlatformPayload; new compiled declaration tests same binder/statement with only declId and proof replaced.','V153Untouched':True,'compiled':False,'CIrun':False,'mainWorkspaceWrites':False},ensure_ascii=False,indent=2)+'\n')
print('query',Q.stat().st_size,hashlib.sha256(Q.read_bytes()).hexdigest());print('config',C.stat().st_size,hashlib.sha256(C.read_bytes()).hexdigest());print(expected)
