import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PointMap
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PlacesOver
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_PrimeToOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Weierstrass
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_NormalizedOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_JInvariant
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Parametrization
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateStructure
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateFamily
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

structure Relocation where
  original : Name
  target : Name
  permutation : Option (Array Nat)
  expectedInstance : Option Bool
  expectedAxioms : Option (Array Name)

structure Relocations where
  rows : Array Relocation
  projectPrefixes : Array Name
  sourcePrefixes : Array Name
  targetPrefix : Name
  excludedSourceNames : Array Name
  sourceProofValues : Array (Name × (List Name × Expr))
  standardProofValues : Array (Name × (List Name × Expr))
  sourceCompatibilityValues : Array (Name × (List Name × Expr))

def Relocations.find? (rs : Relocations) (p : Relocation → Bool) : Option Relocation := rs.rows.find? p
def Relocations.any (rs : Relocations) (p : Relocation → Bool) : Bool := rs.rows.any p

def projectName (rs : Relocations) (n : Name) : Bool :=
  rs.projectPrefixes.any (·.isPrefixOf n) || rs.excludedSourceNames.contains n

def relocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.original == n) then return r.target
  if projectName rs n then throw s!"Unmapped project name {n}"
  return n

def inverseRelocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.target == n) then return r.original
  if projectName rs n then throw s!"Unmapped wrapped name {n}"
  return n

def reorder (indices : Array Nat) (us : Array α) : Except String (Array α) := do
  unless indices.size == us.size && indices.toList.eraseDups.length == us.size do
    throw "Universe permutation has incorrect size or repeated indices"
  indices.mapM fun i => match us[i]? with
    | some u => pure u
    | none => throw "Universe permutation index out of range"

partial def decodeExpr (rs : Relocations) (j : Json) : Except String Expr := do
  let recur := decodeExpr rs
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    if let some source := rs.sourceCompatibilityValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == source.2.1.length do throw "Exact source compatibility universe arity differs"
      return source.2.2.instantiateLevelParams source.2.1 levels.toList
    if let some proof := rs.standardProofValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == proof.2.1.length do
        throw "Universe arity differs for the exact standard proposition-valued instance proof"
      return proof.2.2.instantiateLevelParams proof.2.1 levels.toList
    if let some proof := rs.sourceProofValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == proof.2.1.length do
        throw "Universe arity differs for exact genuine equation source proof value"
      return proof.2.2.instantiateLevelParams proof.2.1 levels.toList
    let target ← relocated rs original
    let mut levels ← (← arrayField j "levels").mapM decodeLevel
    if let some r := rs.find? (·.original == original) then
      if let some indices := r.permutation then levels ← reorder indices levels
    return .const target levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocated rs (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unknown Expr kind {k}"

def readRelocations (config : Json) : MetaM Relocations := do
  let projectPrefixes := (← namesFromJson (← checked (field config "projectPrefixes"))).toArray
  let sourcePrefixes := (← namesFromJson (← checked (field config "originalProjectPrefixes"))).toArray
  let targetPrefix ← checked (decodeName (← checked (field config "targetProjectPrefix")))
  unless !projectPrefixes.isEmpty && !sourcePrefixes.isEmpty && targetPrefix != .anonymous do
    throwError "Empty project-prefix policy"
  let mut result : Array Relocation := #[]
  for key in #["projectMap", "standardRenames"] do
    for row in ← checked (arrayField config key) do
      let original ← checked (decodeName (← checked (field row "originalName")))
      let targetJson ← checked (field row "targetName")
      let target ← if targetJson == Json.null then do
        unless key == "projectMap" && (← checked (stringField row "mappingRole")) == "prior-accepted-required" do
          throwError "Only accepted legacy prior identities may need platform Name resolution"
        let display ← checked (stringField row "target")
        let owner := (← checked (stringField row "targetOwner")).toName
        let env ← getEnv
        let matchingTargets := env.constants.fold (fun acc n _ =>
          if n.toString == display && moduleOf env n == some owner then acc.push n else acc) (#[] : Array Name)
        unless matchingTargets.size == 1 do
          throwError "Accepted prior target Name is not unique at expected owner: {display}"
        pure matchingTargets[0]!
      else checked (decodeName targetJson)
      unless original.toString == (← checked (stringField row "original")) &&
        target.toString == (← checked (stringField row "target")) do
        throwError "Structural relocation name mismatch"
      if key == "standardRenames" then
        if projectPrefixes.any (·.isPrefixOf original) || projectPrefixes.any (·.isPrefixOf target) then
          throwError "Standard relocation contains project name"
        unless (← checked (stringField row "evidence")).length > 0 do
          throwError "Standard rename requires reviewed compiler/source evidence"
      else
        let exactShifts := #[(`Iut.OrbicurveDataSection.XK._proof_2, `AbcAdaptation.Reference.Iut.OrbicurveDataSection.XK._proof_1),
          (`Iut.curveK._proof_2, `AbcAdaptation.Reference.Iut.curveK._proof_1)]
        let exactShift := exactShifts.contains (original, target)
        unless sourcePrefixes.any (·.isPrefixOf original) && (target == targetPrefix ++ original || exactShift) do
          throwError "Unexpected project relocation {original} -> {target}"
      if result.any (fun r => r.original == original || r.target == target) then
        throwError "Duplicate or non-injective relocation {original} -> {target}"
      let indicesJson ← checked (field row "targetToSourceUniverseIndices")
      let permutation ← if indicesJson == Json.null then pure none else
        pure (some (← checked ((← checked indicesJson.getArr?).mapM Json.getNat?)))
      let expectedInstance ← if key == "projectMap" then
        pure (some (← checked (row.getObjValAs? Bool "expectedIsInstance"))) else pure none
      let expectedAxioms ← if key == "projectMap" then
        pure (some (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray) else pure none
      result := result.push ⟨original, target, permutation, expectedInstance, expectedAxioms⟩
  let excludedRows ← checked (arrayField config "excludedOriginalDeclarations")
  let excludedSourceNames ← excludedRows.mapM fun row => do
    checked (decodeName (← checked (field row "originalName")))
  unless excludedSourceNames.size == excludedSourceNames.toList.eraseDups.length &&
      excludedSourceNames.all (fun n => (`_private).isPrefixOf n && !(result.any (·.original == n))) do
    throwError "Excluded original-private identities overlap relocation map or are not private"
  return ⟨result, projectPrefixes, sourcePrefixes, targetPrefix, excludedSourceNames, #[], #[], #[]⟩

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No imported owner for {name}"
  unless modules.contains owner do
    throwError "Forbidden dependency {name}, owner {owner}"
  if rs.sourcePrefixes.any (·.isPrefixOf name) || rs.excludedSourceNames.contains name then
    throwError "Unrelocated original project dependency {name}"

def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  if let .axiomInfo _ := ci then throwError "Carrier declares an axiom {name}"
  let axs ← collectAxioms name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"carrier {name}" axs
  ensureStandard s!"carrier type {name}" taxs
  let value? := ci.value? (allowOpaque := true)
  let vaxs ← match value? with
    | some v => expressionAxioms v
    | none => pure #[]
  ensureStandard s!"carrier value {name}" vaxs
  for expr in #[ci.type] ++ value?.toArray do
    for dep in expr.getUsedConstants do allowedOwner rs modules dep
  if let .recInfo r := ci then
    for rule in r.rules do
      for dep in rule.rhs.getUsedConstants do allowedOwner rs modules dep
      ensureStandard s!"recursor rule {name}" (← expressionAxioms rule.rhs)
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("hasValue", toJson value?.isSome),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name))]

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

def boundPlatformHelperEvidence (config : Json) (key : String) : MetaM Json := do
  let evidence ← checked (field config "platformHelperEvidence")
  let binding ← checked (field evidence key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do
    throwError "Platform helper evidence changed after hash binding: {key}"
  unless (← checked (stringField binding "sha256")).length == 64 do
    throwError "Missing external SHA256 binding for platform helper evidence: {key}"
  return actual

def verifyPlatformHelperFacts (config : Json) : MetaM Json := do
  let facts ← boundPlatformHelperEvidence config "facts"
  let receipt ← boundPlatformHelperEvidence config "receipt"
  unless (← checked (stringField receipt "job_id")) == (← checked (stringField (← checked (field config "platformHelperEvidence")) "job_id")) &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Expected successful actual platform helper query receipt"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
    throwError "Actual platform helper query exit code is not zero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do
    throwError "Wrong actual platform helper query workspace mode"
  unless (← checked (stringField facts "schema")) == "initial-theta-platform-helper-facts-v1" &&
      (← checked (stringField facts "compilerVersion")) == Lean.versionString &&
      (← checked (facts.getObjValAs? Nat "sourceRecordCount")) == 232 &&
      (← checked (facts.getObjValAs? Nat "selectedSourceCount")) == 204 &&
      (← checked (facts.getObjValAs? Nat "selectedMissingCount")) == 3 &&
      (← checked (facts.getObjValAs? Nat "ownedDeclarationCount")) == (← checked (config.getObjValAs? Nat "expectedOwnedDeclarationCount")) do
    throwError "Unexpected actual platform helper query dimensions/compiler"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field facts key)) == (← checked (field config key)) do
      throwError "Actual platform helper query provenance changed: {key}"
  unless (← checked (arrayField facts "targetOnlyNames")).isEmpty do
    throwError "Unresolved target-only compiler declaration requires source provenance review"
  let env ← getEnv
  let moduleRows ← checked (arrayField config "modules")
  let modules ← moduleRows.mapM fun row => do
    return (← checked (stringField row "target")).toName
  let actualOwned := env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)
  let ownedRows ← checked (arrayField facts "ownedDeclarations")
  let ownedNames ← ownedRows.mapM fun row => do
    checked (decodeName (← checked (field row "nameExpr")))
  unless ownedNames.size == (← checked (config.getObjValAs? Nat "expectedOwnedDeclarationCount")) && ownedNames.toList.eraseDups.length == ownedNames.size &&
      actualOwned.size == ownedNames.size && actualOwned.all ownedNames.contains do
    throwError "Actual current owned declaration set changed after platform query"
  for row in ownedRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    let ci ← getConstInfo name
    unless name.toString == (← checked (stringField row "name")) &&
        moduleOf env name == some (← checked (stringField row "module")).toName &&
        kind ci == (← checked (stringField row "constantKind")) &&
        Json.arr (ci.levelParams.toArray.map encodeName) == (← checked (field row "levelParams")) &&
        Lean.Meta.isInstanceCore env name == (← checked (row.getObjValAs? Bool "isInstance")) do
      throwError "Actual owned declaration identity/owner/kind/universes/instance changed: {name}"
    unless !(← checked (row.getObjValAs? Bool "hasSorryAx")) do
      throwError "Actual platform query contains sorryAx: {name}"
    for key in #["axioms", "typeAxioms", "valueAxioms"] do
      for ax in ← checked (arrayField row key) do
        unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
          throwError "Unexpected actual platform query axiom: {name}"
  let helperRows ← checked (arrayField facts "helperFacts")
  for row in helperRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    unless ownedNames.contains name do throwError "Unowned actual helper fact {name}"
    let ci ← getConstInfo name
    unless (← checked (encodeExpr ci.type)) == (← checked (field row "elaboratedExpr")) do
      throwError "Actual platform helper type changed: {name}"
    let value ← match ci.value? (allowOpaque := true) with
      | none => pure Json.null | some expr => checked (encodeExpr expr)
    unless value == (← checked (field row "valueExpr")) do
      throwError "Actual platform helper value changed: {name}"
  let candidates ← checked (arrayField facts "expectedCurrentCandidates")
  unless candidates.size == 232 do throwError "Wrong actual public source candidate count"
  let mut selectedCount := 0
  let mut missingCount := 0
  for row in candidates do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let target ← checked (decodeName (← checked (field row "candidateTargetName")))
    let selected ← checked (row.getObjValAs? Bool "selected")
    let present ← checked (row.getObjValAs? Bool "present")
    unless env.contains target == present do
      throwError "Actual source candidate presence changed: {original}"
    if selected then
      selectedCount := selectedCount + 1
      if !present then
        missingCount := missingCount + 1
        unless #[`Iut.OrbicurveDataSection.XK._proof_2, `Iut.curveK._proof_2, `Iut.galK._proof_2].contains original do
          throwError "Unresolved missing selected declaration {original}"
  unless selectedCount == 204 && missingCount == 3 do
    throwError "Unresolved generated names require actual evidence and a reviewed new attempt"
  return facts

-- Exact parent only. This diagnostic never changes the original raw guard.
def galKInternalSemiringData (sourceType targetType : Expr) : MetaM Json := do
  unless (binderInventory sourceType).size == 28 && (binderInventory targetType).size == 32 do
    throwError "Unexpected exact galK full raw BinderInfo dimensions"
  let expectedFlags : Array String := #["implicit", "instImplicit", "default", "implicit", "instImplicit", "instImplicit", "default", "default"]
  let accounting ← forallTelescope sourceType fun args sourceBody => do
    unless args.size == 8 do throwError "Expected all eight original galK parameters"
    let mut targetBody := targetType
    let mut domainReports : Array Json := #[]
    let mut instanceReports : Array Json := #[]
    for index in [:args.size] do
      let sourceDecl ← args[index]!.fvarId!.getDecl
      let .forallE _ targetDomain targetRest targetBinder := targetBody |
        throwError "Actual galK lost an exposed Pi binder"
      unless encodeBinder sourceDecl.binderInfo == expectedFlags[index]! && sourceDecl.binderInfo == targetBinder do
        throwError "Exact galK exposed binder attribute changed at {index}"
      let prefixArgs := args.extract 0 index
      kernelTypeEq s!"exact galK complete exposed parameter domain {index}"
        (← mkForallFVars prefixArgs sourceDecl.type) (← mkForallFVars prefixArgs targetDomain)
      let rawInventoryEqual := binderInventory sourceDecl.type == binderInventory targetDomain
      let rawPlacementEqual := binderPlacement sourceDecl.type == binderPlacement targetDomain
      if index != 7 then
        unless rawInventoryEqual && rawPlacementEqual do
          throwError "A galK parameter domain outside sigma contains different BinderInfo at {index}"
      else
        let sourceSigma := sourceDecl.type
        let targetSigma := targetDomain
        unless sourceSigma.getAppFn.isConstOf ``AlgEquiv && targetSigma.getAppFn.isConstOf ``AlgEquiv &&
            sourceSigma.getAppArgs.size == 8 && targetSigma.getAppArgs.size == 8 do
          throwError "Expected exact sigma AlgEquiv with three types and five data instances"
        let sourceSigmaArgs := sourceSigma.getAppArgs
        let targetSigmaArgs := targetSigma.getAppArgs
        for argumentIndex in [:8] do
          let sourceArgument := sourceSigmaArgs[argumentIndex]!
          let targetArgument := targetSigmaArgs[argumentIndex]!
          let sourceBinders := binderInventory sourceArgument
          let targetBinders := binderInventory targetArgument
          let argumentRawEqual := sourceBinders == targetBinders && binderPlacement sourceArgument == binderPlacement targetArgument
          if argumentIndex < 3 then
            unless argumentRawEqual do throwError "Exact sigma mathematical type argument BinderInfo changed"
            kernelTypeEq s!"sigma full mathematical type argument {argumentIndex}"
              (← mkForallFVars prefixArgs sourceArgument) (← mkForallFVars prefixArgs targetArgument)
            instanceReports := instanceReports.push (Json.mkObj [
              ("AlgEquivArgumentIndex", toJson argumentIndex), ("kind", toJson "mathematical-type"),
              ("rawBinderInfoInventoryAndPlacementEqual", toJson true), ("completeClosedTypeKernelEqual", toJson true)])
          else
            let sourceInstanceType ← whnf (← inferType sourceArgument)
            let targetInstanceType ← whnf (← inferType targetArgument)
            unless !(← isProp sourceInstanceType) && !(← isProp targetInstanceType) do
              throwError "An alleged galK data instance is a proposition"
            let expectedHead := if argumentIndex == 3 then ``CommSemiring else if argumentIndex < 6 then ``Semiring else ``Algebra
            unless sourceInstanceType.getAppFn.isConstOf expectedHead && targetInstanceType.getAppFn.isConstOf expectedHead do
              throwError "Exact sigma data instance class changed at {argumentIndex}"
            if argumentIndex == 4 || argumentIndex == 5 then
              unless sourceBinders.size == 1 && targetBinders.size == 3 &&
                  sourceBinders.all (· == "lambda:default") && targetBinders.all (· == "lambda:default") do
                throwError "Exact Semiring subtype-predicate lambda inventory changed"
            else
              unless argumentRawEqual do throwError "A sigma data slot outside the two Semiring instances changed BinderInfo"
            let closedSource ← mkLambdaFVars prefixArgs sourceArgument
            let closedTarget ← mkLambdaFVars prefixArgs targetArgument
            kernelTermEq s!"sigma complete closed computational data instance {argumentIndex}" closedSource closedTarget
            instanceReports := instanceReports.push (Json.mkObj [
              ("AlgEquivArgumentIndex", toJson argumentIndex), ("kind", toJson "computational-data-instance"),
              ("instanceClass", toJson expectedHead.toString), ("isProofSubterm", toJson false),
              ("sourceRawBinderInfo", toJson sourceBinders), ("targetRawBinderInfo", toJson targetBinders),
              ("rawBinderInfoInventoryAndPlacementEqual", toJson argumentRawEqual),
              ("closedOverAllSevenPreviousParameters", toJson true),
              ("completeClosedDataInstanceTypesAndValuesKernelEqual", toJson true),
              ("completeSourceDataExpression", ← checked (encodeExpr closedSource)),
              ("completeTargetDataExpression", ← checked (encodeExpr closedTarget))])
        -- This view records the two complete data slots separately. The original
        -- expressions are retained; exact reconstruction proves reversibility.
        -- The view itself is not used as a kernel typing or conversion input.
        let marker := Expr.sort .zero
        let sourceSlots := #[sourceSigmaArgs[4]!, sourceSigmaArgs[5]!]
        let targetSlots := #[targetSigmaArgs[4]!, targetSigmaArgs[5]!]
        let sourceViewArgs := (sourceSigmaArgs.set! 4 marker).set! 5 marker
        let targetViewArgs := (targetSigmaArgs.set! 4 marker).set! 5 marker
        let sourceView := mkAppN sourceSigma.getAppFn sourceViewArgs
        let targetView := mkAppN targetSigma.getAppFn targetViewArgs
        let sourceRestored := mkAppN sourceSigma.getAppFn ((sourceViewArgs.set! 4 sourceSlots[0]!).set! 5 sourceSlots[1]!)
        let targetRestored := mkAppN targetSigma.getAppFn ((targetViewArgs.set! 4 targetSlots[0]!).set! 5 targetSlots[1]!)
        unless sourceRestored.equal sourceSigma && targetRestored.equal targetSigma do
          throwError "Exact sigma data-slot view did not restore the complete original expressions"
        unless binderInventory sourceView == binderInventory targetView && binderPlacement sourceView == binderPlacement targetView do
          throwError "A sigma binder difference remains outside the two exact kernel-equal Semiring data slots"
      domainReports := domainReports.push (Json.mkObj [
        ("parameterIndex", toJson index), ("binderInfo", toJson (encodeBinder sourceDecl.binderInfo)),
        ("exposedBinderInfoStrictlyEqual", toJson true), ("completeClosedParameterDomainKernelEqual", toJson true),
        ("rawDomainBinderInventoryEqual", toJson rawInventoryEqual),
        ("rawDomainBinderPlacementEqual", toJson rawPlacementEqual),
        ("onlyTwoExactSemiringDataSlotsAccounted", toJson (index == 7))])
      targetBody := targetRest.instantiate1 args[index]!
    unless binderInventory sourceBody == binderInventory targetBody && binderPlacement sourceBody == binderPlacement targetBody do
      throwError "galK result type contains an unaccounted BinderInfo difference"
    kernelTypeEq "galK complete result type over all original parameters"
      (← mkForallFVars args sourceBody) (← mkForallFVars args targetBody)
    return (domainReports, instanceReports)
  return Json.mkObj [
    ("scope", toJson "Only AlgEquiv args4/5 in galK parameter7 sigma; complete Semiring data instances"),
    ("sourceRawSignatureBinderCount", toJson (28 : Nat)), ("targetRawSignatureBinderCount", toJson (32 : Nat)),
    ("originalRawSignatureInventoryEqual", toJson false), ("originalRawSignaturePlacementEqual", toJson false),
    ("allEightExposedBinderAttributesStrictlyEqual", toJson true),
    ("allEightCompleteParameterDomainsKernelEqual", toJson true),
    ("allOtherDomainAndResultBinderInfoStrictlyEqual", toJson true),
    ("allFiveCompleteAlgEquivDataInstanceTypesAndValuesKernelEqual", toJson true),
    ("threeMathematicalTypeArgumentsBinderInfoAndKernelTypesEqual", toJson true),
    ("twoSemiringSlotViewExactExprEqualRoundTrip", toJson true),
    ("twoSemiringSlotViewRemainingBinderInfoStrictlyEqual", toJson true),
    ("viewNeverUsedAsKernelTypeOrValue", toJson true),
    ("domainComparisons", Json.arr accounting.1), ("AlgEquivArgumentComparisons", Json.arr accounting.2)]


def boundExactProofEvidence (config : Json) (key : String) : MetaM Json := do
  let binding ← checked (field config key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) &&
      (← checked (stringField binding "sha256")).length == 64 do
    throwError "Exact source-backed evidence changed after binding: {key}"
  return actual

def installExactInitialThetaProofValues (rs : Relocations) (allowedOwners : Array Name)
    (config facts : Json) : MetaM (Relocations × Array Json) := do
  let source ← boundExactProofEvidence config "exactOriginalProofRecords"
  let priorShiftReceipt ← boundExactProofEvidence config "successfulShiftReceipt"
  let priorGalReceipt ← boundExactProofEvidence config "successfulGalReceipt"
  unless (← checked (stringField priorShiftReceipt "job_id")) == "ci-014978-ca2f4850" &&
      (← checked (stringField priorShiftReceipt "status")) == "succeeded" &&
      (← checked (stringField priorGalReceipt "job_id")) == "ci-015034-278554cf" &&
      (← checked (stringField priorGalReceipt "status")) == "succeeded" do
    throwError "Exact actual successful source-backed diagnostics are not bound"
  for receipt in #[priorShiftReceipt, priorGalReceipt] do
    unless (← checked ((← checked (field receipt "result")).getObjValAs? Nat "exit_code")) == 0 do
      throwError "Exact diagnostic receipt did not exit zero"
  let exact := #[`Iut.OrbicurveDataSection.XK._proof_1, `Iut.curveK._proof_1,
    `Iut.galK._proof_1, `Iut.galK._proof_2]
  let bindings ← checked (arrayField config "proofValueResolutions")
  unless bindings.size == 4 && rs.sourceProofValues.isEmpty && rs.standardProofValues.isEmpty && rs.sourceCompatibilityValues.isEmpty do
    throwError "Expected exactly four actual source proof values and no data/standard substitutions"
  let sourceRecords ← checked (arrayField source "records")
  let mut result := rs
  let mut reports : Array Json := #[]
  for original in exact do
    let rows := bindings.filter fun row => (field row "originalName").toOption == some (encodeName original)
    let matchingRecords := sourceRecords.filter fun row => (field row "nameExpr").toOption == some (encodeName original)
    unless rows.size == 1 && matchingRecords.size == 1 && !(result.any (·.original == original)) do
      throwError "Genuine source proof identity missing or improperly mapped: {original}"
    let binding := rows[0]!
    let record := matchingRecords[0]!
    unless record == (← checked (field binding "sourceRecord")) &&
        (← checked (field binding "standaloneTargetIdentity")) == Json.null &&
        (← checked (stringField record "constantKind")) == "theorem" &&
        (← checked (record.getObjValAs? Bool "selected")) &&
        (← checked (record.getObjValAs? Bool "isProposition")) &&
        !(← checked (record.getObjValAs? Bool "isInstance")) do
      throwError "Only exact genuine selected original proposition proofs may be replayed"
    let parent ← checked (decodeName (← checked (field binding "parentOriginalName")))
    let parentTarget ← checked (relocated result parent)
    let parentFacts := (← checked (arrayField facts "helperFacts")).filter fun row =>
      (field row "nameExpr").toOption == some (encodeName parentTarget)
    unless parentFacts.size == 1 && parentFacts[0]! == (← checked (field binding "actualParentFact")) do
      throwError "Whole original proof-parent data is not bound to actual current compiler facts"
    let params ← namesFromJson (← checked (field record "levelParams"))
    unless params.eraseDups == params do throwError "Repeated source proof universe parameter"
    let levels := (canonicalLevels params.length).map Level.param
    let type ← checked (decodeExpr result (← checked (field record "elaboratedExpr")))
    let value ← checked (decodeExpr result (← checked (field record "valueExpr")))
    let rawRs := { result with rows := #[], projectPrefixes := #[], excludedSourceNames := #[], sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[] }
    let rawType ← checked (decodeExpr rawRs (← checked (field record "elaboratedExpr")))
    unless binderInventory rawType == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
      throwError "Original source proof signature BinderInfo serialization differs"
    let canonicalType := type.instantiateLevelParams params levels
    let canonicalValue := value.instantiateLevelParams params levels
    match ← kernelCheck "genuine original source proof proposition type" canonicalType with
    | .sort level => unless level.isAlwaysZero do throwError "Genuine source proof type is not Prop"
    | _ => throwError "Genuine source proof type is not a type"
    let inferred ← kernelCheck "genuine original source proof body" canonicalValue
    kernelTypeEq "genuine original source proof inhabits its exact full original type" inferred canonicalType
    let inferredInventoryEqual := binderInventory inferred == binderInventory canonicalType
    let inferredPlacementEqual := binderPlacement inferred == binderPlacement canonicalType
    if original != `Iut.galK._proof_2 then
      unless inferredInventoryEqual && inferredPlacementEqual do throwError "Source class proof inferred full BinderInfo differs"
    else
      unless !inferredInventoryEqual && !inferredPlacementEqual do
        throwError "The exact actual galK source proof inferred BinderInfo diagnostic changed"
    let sourceAxioms := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
    let expectedAxioms := (← namesFromJson (← checked (field binding "expectedSourceAxioms"))).toArray
    unless sourceAxioms.qsort Name.lt == expectedAxioms.qsort Name.lt do
      throwError "Genuine source proof axiom closure differs from accepted graph"
    let taxs ← expressionAxioms canonicalType
    let vaxs ← expressionAxioms canonicalValue
    ensureStandard "genuine original source proof type" taxs
    ensureStandard "genuine original source proof body" vaxs
    for term in #[canonicalType, canonicalValue] do
      for dep in term.getUsedConstants do allowedOwner result allowedOwners dep
    result := { result with sourceProofValues := result.sourceProofValues.push (original, (params, value)) }
    reports := reports.push (Json.mkObj [
      ("original", toJson original.toString), ("originalName", encodeName original), ("sourceRecord", record),
      ("resolution", toJson "genuine-exported-original-proof-value"), ("standaloneTargetIdentity", Json.null),
      ("sourceSignatureBinderInfoSerializationValidated", toJson true),
      ("exactOriginalTypeKernelChecked", toJson true), ("genuineOriginalValueInhabitsExactOriginalType", toJson true),
      ("inferredTypeFullBinderInfoInventoryEqual", toJson inferredInventoryEqual),
      ("inferredTypeFullBinderInfoPlacementEqual", toJson inferredPlacementEqual),
      ("inferredBinderInfoPolicy", toJson (if original == `Iut.galK._proof_2 then
        "Actual full inferred implementation BinderInfo differs; no named target identity. Exact original proposition/body kernel checked; parent whole computational data equality remains mandatory." else "Full inferred BinderInfo inventory and placement strictly equal.")),
      ("expandedTypeAxioms", toJson (taxs.map Name.toString)), ("expandedValueAxioms", toJson (vaxs.map Name.toString)),
      ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true), ("expandedDependenciesHaveAllowedOwners", toJson true),
      ("parentOriginal", toJson parent.toString), ("parentTarget", encodeName parentTarget),
      ("parentWholeValueEqualityRequired", toJson true), ("parentKernelDefinitionalValueEqualityRequired", toJson true),
      ("actualSourceDiagnosticJob", toJson "ci-014978-ca2f4850"), ("actualWholeDataDiagnosticJob", toJson "ci-015034-278554cf"),
      ("hasSorryAx", toJson false)])
  return (result, reports)

def compareRecord (rs : Relocations) (allowedOwners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.eraseDups == sourceParams do throwError "Duplicate universe parameter {original}"
  unless sourceParams.length == target.levelParams.length do
    throwError "Universe parameter count differs for {original}"
  unless (← checked (stringField record "constantKind")) == kind target do
    throwError "ConstantInfo kind differs for {original}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original axiom for {original}"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "Missing map entry {original}"
  let some expectedAxioms := rel.expectedAxioms |
    throwError "Missing accepted-graph source axiom inventory {original}"
  let sourceAxiomNames := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxiomNames.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Original axiom closure differs from accepted compiler graph {original}"
  let some expectedInstance := rel.expectedInstance |
    throwError "Missing accepted-graph instance flag {original}"
  unless (← checked (record.getObjValAs? Bool "isInstance")) == expectedInstance do
    throwError "Exported original instance flag differs from accepted graph {original}"
  unless Lean.Meta.isInstanceCore (← getEnv) target.name == expectedInstance do
    throwError "Instance registry membership differs for {original}"
  let targetLevels ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let reordered ← checked (reorder indices canonical.toArray)
      pure reordered.toList
  let signatureRs := { rs with sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[] }
  let originalSignature ← checked (decodeExpr signatureRs (← checked (field record "elaboratedExpr")))
  let originalSignature := originalSignature.instantiateLevelParams sourceParams canonical
  let sourceTypeRaw ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams targetLevels
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory originalSignature do
    throwError "Unexpanded original signature BinderInfo serialization differs for {original}"
  let rawInventoryEqual := binderInventory originalSignature == binderInventory targetType
  let rawPlacementEqual := binderPlacement originalSignature == binderPlacement targetType
  let internalInstanceEvidence ← if original == `Iut.galK then do
    unless target.name == `AbcAdaptation.Reference.Iut.galK && !rawInventoryEqual && !rawPlacementEqual do
      throwError "Exact galK raw implementation BinderInfo diagnostic changed"
    galKInternalSemiringData sourceType targetType
  else do
    unless rawInventoryEqual do
      throwError "Full unexpanded original/actual target signature BinderInfo inventory differs for {original}"
    unless rawPlacementEqual do
      throwError "Full unexpanded original/actual target signature BinderInfo placement differs for {original}"
    pure Json.null
  kernelTypeEq s!"original versus target type {original}" sourceType targetType
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do
    throwError "Inductive/constructor/recursor computation shape differs for {original}"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  unless sourceProp == (← isProp target.type) do throwError "Proposition status differs {original}"
  let mut comparedValue := false
  let mut definitionallyEqualValue := false
  let originalValueJson ← checked (field record "valueExpr")
  -- Proof declarations are audited by exact type and axiom closure. For a data
  -- value containing proof fields, Kernel.isDefEq itself uses proof irrelevance.
  if !sourceProp && originalValueJson != Json.null then
    let sourceValue := (← checked (decodeExpr rs originalValueJson)).instantiateLevelParams sourceParams canonical
    let some targetValue := target.value? (allowOpaque := true) |
      throwError "Target value missing for {original}"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq s!"original value inhabits original type {original}"
      (← kernelCheck s!"original value {original}" sourceValue) sourceType
    kernelTypeEq s!"target value inhabits target type {original}"
      (← kernelCheck s!"target value {original}" targetValue) targetType
    kernelTermEq s!"original versus target computational value {original}" sourceValue targetValue
    definitionallyEqualValue := true
    comparedValue := true
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut comparedRules := 0
  if let .recInfo r := target then
    unless rules.size == r.rules.length do throwError "Recursor rule count differs {original}"
    for i in [:rules.size] do
      let sourceRhs := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let targetRhs := r.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      kernelTermEq s!"recursor rule {original} #{i}" sourceRhs targetRhs
      comparedRules := comparedRules + 1
  else
    unless rules.isEmpty do throwError "Unexpected original recursor rules {original}"
  let sourceStruct ← checked (field record "structure")
  unless (sourceStruct != Json.null) == (getStructureInfo? (← getEnv) target.name).isSome do
    throwError "Structure metadata presence differs {original}"
  if sourceStruct != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name |
      throwError "Target structure metadata missing {target.name}"
    unless (← checked (field sourceStruct "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do
      throwError "Complete structure field/parent metadata differs {original}"
    let autoParams ← checked (arrayField sourceStruct "fieldAutoParamExprs")
    unless autoParams.size == info.fieldInfo.size do
      throwError "Structure field autoParam count differs {original}"
    for i in [:autoParams.size] do
      match autoParams[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some targetExpr =>
        if sourceJson == Json.null then throwError "Missing source autoParam {original} #{i}"
        let sourceExpr := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let targetExpr := targetExpr.instantiateLevelParams target.levelParams targetLevels
        unless binderPlacement sourceExpr == binderPlacement targetExpr do
          throwError "Structure autoParam BinderInfo placement differs {original} #{i}"
        kernelTermEq s!"structure field autoParam {original} #{i}" sourceExpr targetExpr
      | sourceJson, none =>
        unless sourceJson == Json.null do throwError "Missing target autoParam {original} #{i}"
    unless (← checked (field sourceStruct "fieldsInConstructorOrder")) ==
        toJson (info.fieldNames.map Name.toString) do
      throwError "Structure field order differs {original}"
    let projections ← namesFromJson (← checked (field sourceStruct "projections"))
    let targetProjections ← projections.toArray.mapM fun n => checked (relocated rs n)
    unless targetProjections == info.fieldInfo.map (·.projFn) do
      throwError "Structure accessor identities/order differ {original}"
    for p in targetProjections do
      unless rs.any (·.target == p) do throwError "Unaudited structure accessor {p}"
  return Json.mkObj [("original", toJson original.toString), ("originalName", encodeName original),
    ("target", toJson target.name.toString), ("targetName", encodeName target.name),
    ("sourceRecord", record), ("kernelTypeEqual", toJson true),
    ("allExpressionBinderInfoEqual", toJson (rawInventoryEqual && rawPlacementEqual)),
    ("binderInfoPlacementEqual", toJson rawPlacementEqual),
    ("sourceSignatureBinderInfoSerializationValidated", toJson true),
    ("sourceTargetSignatureBinderInfoInventoryEqual", toJson rawInventoryEqual),
    ("sourceTargetSignatureBinderInfoPlacementEqual", toJson rawPlacementEqual),
    ("binderInfoComparisonScope", toJson "unexpanded-original-exported-signature-after-named-relocation-vs-actual-target-type"),
    ("exactInternalDataInstanceBinderAccounting", internalInstanceEvidence),
    ("strictRawBinderInfoOrExactGalKTwoSemiringDataAccountingPassed", toJson true),
    ("expandedOriginalTypeKernelEqual", toJson true),
    ("computationShapeEqual", toJson true), ("completeStructureMetadataEqual", toJson true),
    ("kernelValueEqual", toJson definitionallyEqualValue),
    ("computationalValueEqualityChecked", toJson comparedValue),
    ("kernelPropositionalValueEquality", toJson false),
    ("propositionalValueEqualityEvidence", Json.null),
    ("proofDeclaration", toJson sourceProp), ("recursorRulesCompared", toJson comparedRules),
    ("instanceRegistryMatchesAcceptedGraph", toJson true),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("expectedIsInstance", toJson expectedInstance),
    ("universeOriginalOrder", Json.arr (sourceParams.toArray.map encodeName)),
    ("universeTargetOrder", Json.arr (target.levelParams.toArray.map encodeName)),
    ("targetToSourceUniverseIndices", match rel.permutation with | none => Json.null | some a => toJson a)]

-- Each declaration receives the existing default budget. Neither the option nor
-- the maximum is increased. The final check also bounds work without internal
-- heartbeat checkpoints. IO counters use 1000 internal ticks per user heartbeat.
def boundedMetaAuditUnit (label : String) (action : MetaM α) : MetaM (α × Nat) :=
  withCurrHeartbeats do
    unless maxHeartbeats.get (← getOptions) == 200000 do
      throwError "Expected default maxHeartbeats200000 for each independent audit unit"
    let start ← IO.getNumHeartbeats
    let value ← action
    Lean.Core.checkMaxHeartbeats label
    let finish ← IO.getNumHeartbeats
    return (value, finish - start)

def audit : TermElabM Unit := do
  let setupStarted ← IO.getNumHeartbeats
  let (config, records, expectedSelectedCount, moduleRows, activeOriginal, rs, allowedOwners, globalProofReports, dependencyModules, directImportReports, declarations, platformFactsHeartbeats, sourceProofHeartbeats) ← withCurrHeartbeats do
    unless Lean.versionString == "4.33.1" do throwError "Expected platform4.33.1, got {Lean.versionString}"
    let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
    unless (← checked (stringField config "schema")) == "next-carrier-kernel-audit-config-v3" do
      throwError "Wrong config schema"
    let source ← jsonFile (← checked (stringField config "originalExprFile"))
    unless (← checked (stringField source "schema")) == "initial-theta-receipt-bound-original-module-view-v1" &&
        (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" do
      throwError "Wrong original compiler/schema"
    for key in #["inventorySha256", "graphSha256"] do
      unless (← checked (field source key)) == (← checked (field config key)) do
        throwError "Input provenance hash differs: {key}"
    unless (← checked (source.getObjValAs? Nat "completeOriginalRecordCount")) == 232 &&
        (← checked (source.getObjValAs? Nat "completeOriginalSelectedCount")) == 204 &&
        (← checked (field source "sourceModule")) == (← checked (field config "activeOriginalModule")) do
      throwError "Wrong complete source receipt-bound module view"
    let records ← checked (arrayField source "records")
    let expectedRecordCount ← checked (config.getObjValAs? Nat "expectedRecordCount")
    let expectedSelectedCount ← checked (config.getObjValAs? Nat "expectedSelectedCount")
    unless records.size == expectedRecordCount do throwError "Original record count differs from config"
    unless (← checked (source.getObjValAs? Nat "recordCount")) == expectedRecordCount do
      throwError "Exporter record count differs from config"
    unless (← checked (source.getObjValAs? Nat "selectedCount")) == expectedSelectedCount do
      throwError "Exporter selected count differs from config"
    let moduleRows ← checked (arrayField config "modules")
    unless moduleRows.size == (← checked (config.getObjValAs? Nat "expectedModuleCount")) do
      throwError "Module count differs from config"
    let modules ← moduleRows.mapM fun row => return (← checked (stringField row "target")).toName
    let activeOriginal ← checked (stringField config "activeOriginalModule")
    let activeRows := moduleRows.filter fun row => (stringField row "original").toOption == some activeOriginal
    unless activeRows.size == 1 do throwError "Exactly one original module must own this audit leaf"
    let activeModule := (← checked (stringField activeRows[0]! "target")).toName
    let rs ← readRelocations config
    let env ← getEnv
    let dependencyModules := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
    let standardPrefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
    let allowedProjectModules := modules ++ dependencyModules
    unless allowedProjectModules.size == allowedProjectModules.toList.eraseDups.length do
      throwError "Duplicate allowed project modules"
    let mut allowedOwners := #[]
    for imported in env.header.moduleNames do
      unless standardPrefixes.any (·.isPrefixOf imported) || allowedProjectModules.contains imported do
        throwError "Forbidden imported module {imported}"
      allowedOwners := allowedOwners.push imported
    unless (← checked (arrayField config "standardRenames")).isEmpty do
      throwError "Initial-theta audit permits no standard substitutions"
    let (platformFacts, platformFactsHeartbeats) ← boundedMetaAuditUnit "actual platform fact verification" (verifyPlatformHelperFacts config)
    let ((rs, globalProofReports), sourceProofHeartbeats) ← boundedMetaAuditUnit "four genuine original source proof checks" (installExactInitialThetaProofValues rs allowedOwners config platformFacts)
    let directImports := ((env.header.imports.map (·.module)).toList.eraseDups).toArray.filter (· != `Init)
    let reviewedStandardImports := (← checked (config.getObjValAs? (Array String) "auditorStandardImports")).map String.toName
    unless reviewedStandardImports.isEmpty do
      throwError "Unexpected auditor-only standard import"
    let expectedDirectImports := #[`Lean] ++ reviewedStandardImports ++ allowedProjectModules
    unless directImports.size == expectedDirectImports.size && expectedDirectImports.all directImports.contains do
      throwError "Auditor direct imports differ from exact reviewed standard and Def-module set"
    let mut directImportReports : Array Json := #[]
    for row in moduleRows do
      let owner := (← checked (stringField row "target")).toName
      let expected := (← checked (row.getObjValAs? (Array String) "allowedDirectImports")).map String.toName
      unless expected.size == expected.toList.eraseDups.length do throwError "Duplicate direct imports {owner}"
      let mut actual : Array Name := #[]
      let mut ownerFound := false
      for i in [:env.header.moduleNames.size] do
        if env.header.moduleNames[i]! == owner then
          let some data := env.header.moduleData[i]? | throwError "Module data missing {owner}"
          actual := ((data.imports.map (·.module)).toList.eraseDups).toArray.filter (· != `Init)
          ownerFound := true
      unless ownerFound && actual.size == expected.size && actual.all expected.contains do
        throwError "Target direct imports differ from precise configured imports {owner}"
      if actual.contains `Mathlib then throwError "Broad Mathlib import forbidden {owner}"
      directImportReports := directImportReports.push (Json.mkObj [
        ("module", toJson owner.toString), ("actual", toJson (actual.map Name.toString)),
        ("exactConfiguredImportSet", toJson true)])
    let declarations := env.constants.fold (fun acc n _ =>
      if moduleOf env n == some activeModule then acc.push n else acc) (#[] : Array Name)
    unless declarations.size == (← checked (config.getObjValAs? Nat "expectedAuditOwnedDeclarationCount")) && declarations.size > 0 do throwError "No carrier declarations"
    Lean.Core.checkMaxHeartbeats "audit initialization phase"
    return (config, records, expectedSelectedCount, moduleRows, activeOriginal, rs, allowedOwners, globalProofReports, dependencyModules, directImportReports, declarations, platformFactsHeartbeats, sourceProofHeartbeats)
  let setupFinished ← IO.getNumHeartbeats
  let env ← getEnv
  let mut proofReports : Array Json := #[]
  let mut ownedReports := #[]
  let mut comparisons := #[]
  let mut seenOriginal : Array Name := #[]
  let mut requiredCount := 0
  let mut requiredNamedCount := 0
  let excludedRows ← checked (arrayField config "excludedOriginalDeclarations")
  let mut excludedSeen : Array Name := #[]
  let mut missingOptional := #[]
  for record in records do
    let original ← checked (decodeName (← checked (field record "nameExpr")))
    if seenOriginal.contains original then throwError "Duplicate original record {original}"
    seenOriginal := seenOriginal.push original
    unless original.toString == (← checked (stringField record "name")) do
      throwError "Original name identity differs"
    let sourceOwner ← checked (stringField record "module")
    unless sourceOwner == activeOriginal do throwError "A source record belongs to another module leaf"
    let ownerRows := moduleRows.filter fun row => (stringField row "original").toOption == some sourceOwner
    unless ownerRows.size == 1 do throwError "Original module not configured: {sourceOwner}"
    for key in #["sourceSha256", "normalizedSha256"] do
      unless (← checked (field record key)) == (← checked (field ownerRows[0]! key)) do
        throwError "Original source provenance differs: {key}"
    let selected ← checked (record.getObjValAs? Bool "selected")
    let excluded := excludedRows.filter fun row => (field row "originalName").toOption == some (encodeName original)
    unless excluded.size <= 1 do throwError "Duplicate excluded original {original}"
    if !excluded.isEmpty then
      unless !selected && !(rs.any (·.original == original)) && (`_private).isPrefixOf original do
        throwError "Invalid unselected-private exclusion {original}"
      unless (← checked (field excluded[0]! "target")) == Json.null do
        throwError "Excluded private declaration must have no target identity {original}"
      excludedSeen := excludedSeen.push original
      missingOptional := missingOptional.push (toJson original.toString)
      continue
    let resolution := globalProofReports.filter fun row => (field row "originalName").toOption == some (encodeName original)
    unless resolution.size <= 1 do throwError "Duplicate genuine source proof resolution"
    if !resolution.isEmpty then
      unless selected && !(rs.any (·.original == original)) &&
          record == (← checked (field resolution[0]! "sourceRecord")) do
        throwError "Invalid source proof resolution in the complete module view"
      requiredCount := requiredCount + 1
      proofReports := proofReports.push resolution[0]!
      continue
    let targetName ← checked (relocated rs original)
    if selected then requiredCount := requiredCount + 1
    unless env.contains targetName do
      if selected then throwError "Required generated/source declaration missing: {original} -> {targetName}"
      missingOptional := missingOptional.push (toJson original.toString)
      continue
    unless moduleOf env targetName == some (← checked (stringField ownerRows[0]! "target")).toName do
      throwError "Wrong target artifact owner {targetName}"
    logInfo s!"Checking complete public source declaration {original}"
    let (comparison, usedHeartbeats) ← boundedMetaAuditUnit s!"complete source declaration {original}"
      (compareRecord rs allowedOwners record (← getConstInfo targetName))
    comparisons := comparisons.push (Json.mkObj ((← checked comparison.getObj?).toList ++ [
      ("independentDefaultHeartbeatBudget", toJson (200000 : Nat)),
      ("declarationHeartbeatsInternalTicks", toJson usedHeartbeats)]))
    if selected then requiredNamedCount := requiredNamedCount + 1
  unless requiredCount == expectedSelectedCount do throwError "Mandatory selected count differs from config"
  unless excludedSeen.size == excludedRows.size do
    throwError "Excluded original declaration set differs from actual source records"
  unless requiredNamedCount + proofReports.size == expectedSelectedCount &&
      proofReports.size == (← checked (config.getObjValAs? Nat "expectedProofValueResolutionCount")) &&
      requiredNamedCount == (← checked (config.getObjValAs? Nat "expectedNamedSelectedCount")) do
    throwError "Mandatory named comparison count differs from exact source inventory"
  for report in proofReports do
    let parent ← checked (stringField report "parentOriginal")
    let parentComparisons := comparisons.filter fun row => (stringField row "original").toOption == some parent
    unless parentComparisons.size == 1 &&
        !(← checked (parentComparisons[0]!.getObjValAs? Bool "proofDeclaration")) &&
        (← checked (parentComparisons[0]!.getObjValAs? Bool "computationalValueEqualityChecked")) &&
        (← checked (parentComparisons[0]!.getObjValAs? Bool "kernelValueEqual")) &&
        !(← checked (parentComparisons[0]!.getObjValAs? Bool "kernelPropositionalValueEquality")) do
      throwError "Genuine source proof requires complete owning parent data kernel definitional equality"
  let mut targetOnly := #[]
  logInfo "Checking owned declaration axiom closures"
  for name in declarations.qsort Name.lt do
    let (ownedReport, usedHeartbeats) ← boundedMetaAuditUnit s!"owned declaration type/value/axiom closure {name}"
      (auditDeclaration rs allowedOwners name)
    ownedReports := ownedReports.push (Json.mkObj ((← checked ownedReport.getObj?).toList ++ [
      ("independentDefaultHeartbeatBudget", toJson (200000 : Nat)),
      ("declarationHeartbeatsInternalTicks", toJson usedHeartbeats)]))
    if !(rs.any fun r => r.target == name && seenOriginal.contains r.original) then
      targetOnly := targetOnly.push (toJson name.toString)
  withCurrHeartbeats do
    unless maxHeartbeats.get (← getOptions) == 200000 do throwError "Final phase must retain default heartbeat budget"
    let expectedTargetOnly ← checked (arrayField config "expectedTargetOnlyCompilerDeclarations")
    unless targetOnly.size == expectedTargetOnly.size && targetOnly.all expectedTargetOnly.contains do
      throwError "Actual target-only compiler declarations differ from genuine platform facts"
    let output ← checked (stringField config "outputDir")
    IO.FS.createDirAll output
    IO.FS.writeFile (output ++ "/next-carrier-kernel-audit.json") ((Json.mkObj [
      ("schema", toJson "next-carrier-kernel-audit-v3"), ("compilerVersion", toJson Lean.versionString),
      ("originalCompilerVersion", toJson "4.35.0-rc3"),
      ("configuration", config),
      ("declarationBudgetPolicy", toJson "Each comparison and owned audit uses withCurrHeartbeats at unchanged default200000; initialization and result emission are distinct default-budget phases."),
      ("defaultHeartbeatBudget", toJson (200000 : Nat)),
      ("initializationHeartbeatsInternalTicks", toJson (setupFinished - setupStarted)),
      ("actualPlatformFactHeartbeatsInternalTicks", toJson platformFactsHeartbeats),
      ("genuineSourceProofHeartbeatsInternalTicks", toJson sourceProofHeartbeats),
      ("activeOriginalModule", toJson activeOriginal),
      ("completeOriginalRecordCount", toJson (232 : Nat)),
      ("completeOriginalSelectedCount", toJson (204 : Nat)),
      ("standardProofValueResolutionCount", toJson (0 : Nat)),
      ("requiredComparedCount", toJson requiredCount),
      ("requiredSourceDeclarationCount", toJson requiredCount),
      ("requiredResolvedCount", toJson (requiredNamedCount + proofReports.size)),
      ("requiredEliminatedInternalProofCount", toJson proofReports.size),
      ("requiredNamedComparedCount", toJson requiredNamedCount),
      ("requiredProofValueResolutionCount", toJson proofReports.size),
      ("proofValueResolutions", Json.arr proofReports),
      ("actualPlatformHelperEvidenceVerified", toJson true),
      ("actualPlatformHelperQueryJob", ← checked (field (← checked (field config "platformHelperEvidence")) "job_id")),
      ("explicitGeneratedNameShifts", ← checked (field config "explicitGeneratedNameShifts")),
      ("comparisons", Json.arr comparisons), ("ownedDeclarations", Json.arr ownedReports),
      ("directImportReports", Json.arr directImportReports),
      ("previouslyAcceptedDependencyModules", Json.arr (dependencyModules.map encodeName)),
      ("missingUnselectedOriginalDeclarations", Json.arr missingOptional),
      ("targetOnlyCompilerDeclarations", Json.arr targetOnly),
      ("targetOnlyCompilerProvenance", ← checked (field config "targetOnlyCompilerProvenance")),
      ("allOwnedTypeValueClosuresStandardAxiomsOnly", toJson true),
      ("hasSorryAx", toJson false),
      ("targetOnlyPolicy", toJson "all reported and axiom audited; review source-command generation provenance before acceptance")]).compress ++ "\n")
    logInfo s!"Next carrier audit: {requiredCount} mandatory exact types; {comparisons.size} total original/target pairs; {ownedReports.size} artifact-owned axiom closures"
    Lean.Core.checkMaxHeartbeats "audit result emission phase"

end FoundationAudit

syntax (name := auditNextCarrier) "audit_next_carriers" : command
@[command_elab auditNextCarrier] def elabAuditNextCarrier : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.audit

audit_next_carriers
