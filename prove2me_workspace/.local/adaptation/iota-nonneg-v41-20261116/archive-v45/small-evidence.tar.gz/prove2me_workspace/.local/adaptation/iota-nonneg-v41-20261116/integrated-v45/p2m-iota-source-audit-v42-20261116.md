# Independent source audit: `ι_nonneg`

Audit scope: source identity, proof-body fidelity, theorem meaning, and the adequacy of the planned source/native/stub/solution comparison. No repository files were changed. No compiler, CI, API, or Git command was run.

## Source and license

- Upstream file: `refer/iut/Iut/Implication/Invariants.lean`, SHA-256 `cef53e39e80da02efc741741d70801f167ea34cdf8b5ce87f42f2e28178018a0`.
- The source file carries the iut contributors' 2026 copyright notice and Apache-2.0 notice. `refer/iut/LICENSE` is Apache-2.0. The migrated native file retains the notice and names the source path and lines 166-167.
- The adapted compiler input is not byte-identical to the current upstream file. The target definition module records effective compiler source SHA-256 `5826090f3a4e8e27fa915a133df4cbcd1b3f42881c00f55b2fe25d8a53e346f1` and upstream/effective patch SHA-256 `a1413299eefdeb8639e86c718c3e37eba68d3c14c4d33446b828897a9264a7e6`. The acceptance claim must therefore cite that effective adapted source, not imply that raw upstream was compiled unchanged.

## Mathematical correspondence

In the source module, the relevant declarations are:

```lean
noncomputable def ι (p : ℕ) : ℝ := if p ≤ inv.eStar * X.ℓ then 1 else 0
lemma ι_nonneg (p : ℕ) : 0 ≤ inv.ι p := by
  unfold ι; split_ifs <;> norm_num
lemma logSle_nonneg : 0 ≤ inv.logSle :=
  Finset.sum_nonneg fun p _ => inv.ι_nonneg p
```

The migrated target has the same statement and proof text, with the project namespace inserted. `ι_nonneg` says that the zero-or-one cutoff indicator is nonnegative for every natural prime index; it is the immediate actual `value` dependency of `logSle_nonneg`. This is a pure definitional arithmetic fact, not a claim about existence of arithmetic invariants.

The candidate native proof SHA-256 is `73da80bbef0aaf61d9855a020c28c5d02b3f5e063ab5a06db70a557447e56c82`; its body is byte-for-byte the source tactic body. The solution file SHA-256 is `accedd9905821df825f446285fbfdcda7180bb084e8aa09f5da3a0a19bb4d3db`. The target stub SHA-256 is `8490c7940be14fbcf6c74d6564b6923315e4563d070c6bf8bdd4977aa776c02e`.

## Audit sufficiency and remaining gate

The planned `pure-four-role` audit is structurally adequate if its generated inputs are bound to the actual receipts and map evidence: it decodes the source compiler type, historical native theorem type, target stub type, and global solution type; checks all six kernel type-equality pairs after the explicit source-to-target constant map; and separately compares binder inventory and binder placement. It also binds the InfoTree declaration range and checks that the source proof/signature byte ranges equal the native and solution ranges. This closes the gap that proof-body replay alone would leave: replay proves a source command elaborates in its oracle context, but does not by itself establish that the target theorem has the same type.

The source proof oracle facts are tied to normalized source SHA-256 `3f6e64f8e6bec56f54ae9b5a191cb4f90decf55682fdc282892d8f95cee21ffc`; its index reports a complete one-file result. The displayed configuration still identifies itself as candidate-only and unpublished. The four-role run and its receipt are not yet present in the evidence inspected here. Therefore the source correspondence is well supported but **not yet accepted**; do not publish or mark the unit complete until the actual four-role result passes against the five-map evidence and all receipts.

One provenance caveat should be carried into the final record: the target definition block has an effective-source override and a nonzero patch hash. The four-role audit verifies the theorem type over target definitions, while the override's source/patch provenance remains a separate existing accepted-source fact; do not conflate theorem type equality with a fresh audit of the entire migrated definition block.
