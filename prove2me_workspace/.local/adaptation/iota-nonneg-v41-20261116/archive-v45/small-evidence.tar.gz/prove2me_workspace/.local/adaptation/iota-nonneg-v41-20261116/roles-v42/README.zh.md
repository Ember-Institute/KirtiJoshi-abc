本目录只包含 four-role 查询/配置草稿与 source TYPE 映射审计；没有编译、MCP-CI、API、Git或主区写入。

`typedata-map-evidence.json` 的五个 source TYPE project 常量都来自真实 `iota-nonneg-v41/actual/source-type.json`：

- `Iut.AnabelianGeometry` → Orbicurve Definition `05abfe4b-61dd-404a-bbd1-e75a81a752f1`
- `Iut.Corollary312VariantData` → Statement Definition `78a99b35-17b6-4b19-8359-f12cf69ee29b`
- `Iut.TemperedGeometry` → LocalConditions Definition `91d62428-423b-492d-82d4-c3b61e9bfe82`
- `Iut.Theorem110Invariants` → Invariants Definition `f56e4f81-55bf-4446-9e57-eb0648ee1c7e`
- `Iut.Theorem110Invariants.ι` → same Invariants Definition `f56e4f81-55bf-4446-9e57-eb0648ee1c7e`

前四类的 declaration target owner/hash 从既有 `main5` current-owned176 / current-source-log32 project map 读取，registry 的当前34项清单独立核验实际Definition id和W源码hash。map字段 `targetToSourceUniverseIndices` 全为null。Native TYPE map 对每个source name给一对source→target与target→target reflexive pair，共10行。该JSON只作名称/data依赖映射证据，不构成新数学验收门或假设。

入口：

- `queries/NativeFacts.lean` 直接导入实际已编译native模块：`«.local».adaptation.«iota-nonneg-v41-20261116».native.Thm_..._NativeAuditProof`。`.local`是Name component，目录hyphen按quoted identifier编码。CI在真实kernel environment以`getModuleIdxFor?`核验owner。
- `configs/four-role.template.json` 绑定source proof `ci-017569-a276b44c`、source TYPE `ci-017568-e1627eb4`、native leaf/artifact `ci-017570-762070db` / `ci-017584-fbdd1ceb`、stub leaf `ci-017586-4033c9d2`、solution leaf `ci-017585-ba82811d`，以及所有source/proof/type/map文件SHA。four-role自身仍待运行。
- root运行NativeFacts后，以`bind_four_role.py`绑定native facts JSON和真实receipt，生成本目录`bound/final.json`；之后再以`PURE_FOUR_ROLE_CONFIG`指向此文件运行`queries/FourRoles.lean`。

来源 OracleConfig 原件未改，路径 `iota-nonneg-v41-20261116/source/OracleConfig.json`，SHA256 `0657c05591b929763c0df4e67ca0c2c608974c395166935abc9bd13f6c24bb7e`；sourceProbe SHA256 `3f6e64f8e6bec56f54ae9b5a191cb4f90decf55682fdc282892d8f95cee21ffc`。实际源码 proof SHA256 为 `6aee0eb5f43f971aa76e7c413f5427da16c61c940a04c592eddac32634995c5f`。source theorem签名在target中多出显式section binders，故其空格/换行不做伪装的逐字等同；查询仍逐字核对原source InfoTree签名和proof，并通过source/native/stub/global solution六对kernel完整TYPE/BinderInfo比较验证target类型。target native/global solution proof字节与原proof完全一致。

证明来自冻结 source probe，reader B 英文与三语读回按原文件保留。论文上下文限于 IUT IV Theorem 1.10 proof Step (iii) 的indicator定义，没有把这条源lemma说成独立论文结果。canonical C22 与 S2-04仍不在本验收范围。
