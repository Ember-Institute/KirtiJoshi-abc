#!/usr/bin/env python3
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import argparse,json,hashlib
D=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def receipt(p):
 p=Path(p).resolve();j=read(p);assert j['status']=='succeeded'and j['result']['exit_code']==0 and j['result']['snapshot']['workspace_mode']=='exclusive_worktree'and j['result']['snapshot']['snapshot_id']is None;return {'path':str(p),'sha256':sha(p),'contents':j}
ap=argparse.ArgumentParser();ap.add_argument('--native-facts',type=Path,required=True);ap.add_argument('--native-facts-receipt',type=Path,required=True);ap.add_argument('--out',type=Path,default=D/'bound/final.json');a=ap.parse_args();c=read(D/'configs/four-role.template.json');b=read(a.native_facts);assert b['schema']=='pure-historical-native-type-facts/v13'and b['targetName']==c['targetName']and b['nativeName']==c['nativeName'];assert b['kernelOriginalNativeTypeEqual']and b['fullBinderInfoEqual']and not b['nativeBodyDirectSorryAx']and not b['nativeHasTransitiveSorryAx'];assert b['typeProofValues']==[];r=receipt(a.native_facts_receipt);cfg=Path(r['contents']['request']['environment']['PURE_FOUR_ROLE_CONFIG']);assert read(cfg)==b['configuration']and r['contents']['request']['worktree_manifest']['input_hashes'].get(str(cfg))==sha(cfg);c['nativeFactsBinding']={'path':str(Path(a.native_facts).resolve()),'sha256':sha(a.native_facts),'contents':b,'receipt':r};c['pending']='Root must run FourRoles.lean using this bound config and review its actual result; no success is predicted.';o=Path(a.out).resolve();assert o.is_relative_to(D);o.parent.mkdir(parents=True,exist_ok=True);o.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(o,sha(o))
