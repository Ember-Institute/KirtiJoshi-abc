from pathlib import Path
import sys
sys.dont_write_bytecode=True
import json,hashlib,shutil
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';G=A/'main-chain-open-20261116/tools/generated';R=A/'main-chain-open-20261116/independent-readbacks-v9';N='Iut.Theorem110Invariants.ι_nonneg';T='AbcAdaptation.Reference.'+N;S=N.replace('.','_')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(p if isinstance(p,bytes) else Path(p).read_bytes()).hexdigest();pin=lambda p:{'path':str(p),'sha256':sha(p)}
def save(p,j):
 p=Path(p);assert p.resolve().is_relative_to(D);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def nm(x):return ''if not x else nm(x[0])+('.'if x[0]else'')+str(x[2])
meta=read(G/'metadata'/f'{S}.json');orig=(G/'OriginalCommands'/f'{S}.lean').read_bytes();cmd=orig[orig.index(b'lemma '):];
# The compiler-AST body range binds the entire `:= by` term; verify from normalized source.
normalized=Path(meta['originalCoordinateSource']).read_bytes();br=meta['proofAndDefinitionBodyRanges'][0];sourceproof=normalized[br['start']['offset']:br['end']['offset']];assert sha(sourceproof)==meta['originalBodyHashes'][0]
assert sourceproof.decode()==':= by\n  unfold ι; split_ifs <;> norm_num'
assert meta['actualConsumerEdges']==[{'consumer':'Iut.Theorem110Invariants.logSle_nonneg','module':'Iut.Implication.Invariants','edge':'value'}]
parts=['native','stub','solution','source','readbacks','paper']
for q in parts:(D/q).mkdir(exist_ok=True)
preamble='''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Exact source proof candidate. Source: Iut/Implication/Invariants.lean#L166-L167.
No source compilation or target acceptance is claimed. -/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.SplitIfs

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open AbcAdaptation.Reference.Iut
open AbcAdaptation.Reference.Iut.Theorem110Invariants
universe u v

'''
sig=''' {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
    {X : Corollary312VariantData.{u, v} AG TG}
    (inv : Theorem110Invariants X) (p : ℕ) :
    0 ≤ inv.ι p'''
proof=sourceproof.decode();top=lambda name:preamble+f'theorem {name}'+sig+' '+proof+'\n'
for folder,name,decl in [('native',f'Thm_{T.replace(".","_")}_NativeAuditProof.lean',T+'_NativeAuditProof'),('stub',f'Thm_{T.replace(".","_")}.lean',T),('solution',f'Sol_{T.replace(".","_")}.lean','solution')]:
 (D/folder/name).write_text(top(decl) if folder!='stub'else preamble+f'theorem {T}'+sig+' := by\n  sorry\n')
(D/'solution/proof.lean.txt').write_bytes(sourceproof+b'\n')
for f,src in [('OriginalCommand.lean',G/'OriginalCommands'/f'{S}.lean'),('SourceProbe.lean',G/'OracleSourceProbes'/f'{S}.lean'),('OracleConfig.json',G/'OracleConfigs'/f'{S}.json'),('SourceMetadata.json',G/'metadata'/f'{S}.json')]:shutil.copyfile(src,D/'source'/f)
for f in ['readback-b-en.json','trilingual-b.json','terminology-b.json','coverage.json']:shutil.copyfile(R/f,D/'readbacks'/f)
tr=read(D/'readbacks/trilingual-b.json');row=next(x for x in tr['nodes']if x['sourceName']==N);save(D/'readbacks/selected-node.json',row)
Q=A/'reference-main-bound-carriers-20261115/paper-materials-v1/quotations-and-evidence.json';qdb=read(Q);q=next(x for x in qdb['quotations']if x['id']=='IV-indicator');evidence=[]
for e in q['evidence']:
 for k,h in [('page_image_path','page_image_sha256'),('raw_text_path','raw_text_sha256')]:
  x=Path(e[k]);assert sha(x)==e[h];evidence.append(pin(x))
save(D/'paper/context.json',{'sourceMaterials':pin(Q),'paperIV':qdb['paper_sources']['IV'],'quotation':q,'evidence':evidence,'scope':'IUT IV Theorem1.10 proof Step(iii) defines the cutoff indicator. Nonnegativity follows from the source-level 0/1 cases; the paper is not cited as stating a separate named nonnegativity lemma.','standalonePaperLemmaClaimed':False})
body=sourceproof.decode();inline=':= by\n  unfold ι\n  split_ifs <;> norm_num';save(D/'candidate.json',{'schema':'iota-nonneg-source-candidate-v40','sourceName':N,'targetName':T,'fullSourceTypeText':'{AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG} {X : Corollary312VariantData.{u,v} AG TG} (inv : Theorem110Invariants X) (p : ℕ) : 0 ≤ inv.ι p','binderAnalysis':{'universes':['u','v'],'implicit':['AG','TG','X'],'explicit':['inv : Theorem110Invariants X','p : ℕ'],'instances':[]},'sourceProofBodyBytes':pin(D/'source/OriginalCommand.lean'),'sourceCompilerBodySha256':meta['originalBodyHashes'][0],'sourceTypeAndProofOracleConfig':pin(D/'source/OracleConfig.json'),'sourceProofProbe':pin(D/'source/SourceProbe.lean'),'sourceMetadata':pin(D/'source/SourceMetadata.json'),'sourceGraphTypeDependencies':meta['graphTypeDependencies'],'sourceGraphValueDependencies':meta['graphValueDependencies'],'actualConsumerEdges':meta['actualConsumerEdges'],'consumer':{'name':'Iut.Theorem110Invariants.logSle_nonneg','reason':'This theorem is its only actual source value consumer; theorem110 consumes logSle_nonneg directly.'},'paperContext':pin(D/'paper/context.json'),'readbackSelected':pin(D/'readbacks/selected-node.json'),'frozenReadbackFiles':[pin(D/'readbacks'/f)for f in ['readback-b-en.json','trilingual-b.json','terminology-b.json','coverage.json']],'originalSourceProof':body,'localNativeProofCandidate':inline,'localNativeProofSha256':sha(inline.encode()),'sourceProofChangedForAdaptedStandaloneRoles':False,'standalonePlatformLiftRecommendation':'Do not upload by default: this is a one-line elementary 0/1 case split, has one consumer, and no independently identified named paper lemma. The accepted Invariants Definition already carries the source declaration; inline the two cases into the eventual logSle_nonneg target if its imported Definition proof cannot be used in an accepted proof closure. Publish separately only if source-identity policy requires retaining this named edge.','rootGraphMembership':False,'canonicalC22Connected':False,'S2-04Completed':False,'CIInvoked':False,'APIInvoked':False,'GitInvoked':False,'mainWorkspaceModified':False})
print('Prepared source-exact ι_nonneg declaration; body SHA',meta['originalBodyHashes'][0])
