**English**

For every natural number $p$, $$0\leq\iota(p).$$ The indicator is $1$ when $p\leq e^*\ell$ and $0$ otherwise, so each case is nonnegative.

**简体中文**

对每个自然数 $p$，都有 $$0\leq\iota(p).$$ 当 $p\leq e^*\ell$ 时，指标函数取值为一，否则取值为零；两种情形都非负。

**日本語**

任意の自然数 $p$ に対し、$$0\leq\iota(p)$$ が成り立つ。指示関数は $p\leq e^*\ell$ のとき一、それ以外は零であり、いずれの場合も非負である。
