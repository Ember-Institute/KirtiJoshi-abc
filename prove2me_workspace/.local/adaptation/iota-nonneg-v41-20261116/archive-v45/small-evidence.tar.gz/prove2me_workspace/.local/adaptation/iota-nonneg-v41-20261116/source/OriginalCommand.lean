lemma ι_nonneg (p : ℕ) : 0 ≤ inv.ι p := by
  unfold ι; split_ifs <;> norm_num
