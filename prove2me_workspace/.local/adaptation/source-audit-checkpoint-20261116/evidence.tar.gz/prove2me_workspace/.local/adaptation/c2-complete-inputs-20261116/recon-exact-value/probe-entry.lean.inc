partial def eraseRecOnBinderInfo : Expr → Expr
  | .lam n t b _ => .lam n (eraseRecOnBinderInfo t) (eraseRecOnBinderInfo b) .default
  | .forallE n t b _ => .forallE n (eraseRecOnBinderInfo t) (eraseRecOnBinderInfo b) .default
  | .app f a => .app (eraseRecOnBinderInfo f) (eraseRecOnBinderInfo a)
  | .letE n t v b nd => .letE n (eraseRecOnBinderInfo t) (eraseRecOnBinderInfo v) (eraseRecOnBinderInfo b) nd
  | .proj n i b => .proj n i (eraseRecOnBinderInfo b)
  | .mdata _ b => eraseRecOnBinderInfo b
  | other => other

def probeExactRecOnValue : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected locked actual target compiler4.33.1"
  let cfg ← jsonFile (← absoluteEnv "C2_RECON_PROBE_CONFIG")
  let record ← jsonFile (← checked (stringField cfg "sourceFile"))
  unless (← checked (stringField record "name")) == "Iut.ThetaDataExistence.recOn" &&
      (← checked (stringField cfg "sourceJob")) == "ci-015918-e7d68794" do
    throwError "Wrong exact source44 recOn record"
  let targetName := `AbcAdaptation.Reference.Iut.ThetaDataExistence.recOn
  let env ← getEnv
  let some target := env.find? targetName | throwError "Missing actual imported target recOn"
  unless moduleOf env targetName == some `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22 do
    throwError "Actual imported target recOn owner differs"
  let some targetRawValue := target.value? (allowOpaque := true) | throwError "Actual imported recOn value missing"
  let targetAxioms ← collectAxioms targetName
  let targetTypeAxioms ← expressionAxioms target.type
  let targetValueAxioms ← expressionAxioms targetRawValue
  for axs in #[targetAxioms, targetTypeAxioms, targetValueAxioms] do ensureStandard "actual recOn" axs
  let actualTargetFact := Json.mkObj [
    ("compilerVersion", toJson Lean.versionString), ("name", toJson targetName.toString),
    ("nameExpr", encodeName targetName),
    ("owner", toJson "Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22"),
    ("levelParams", toJson (target.levelParams.map Name.toString)),
    ("levelParamNames", Json.arr (target.levelParams.toArray.map encodeName)),
    ("typeExpr", ← checked (encodeExpr target.type)),
    ("valueExpr", ← checked (encodeExpr targetRawValue)),
    ("axioms", toJson (targetAxioms.map Name.toString)),
    ("typeAxioms", toJson (targetTypeAxioms.map Name.toString)),
    ("valueAxioms", toJson (targetValueAxioms.map Name.toString))]
  -- This authoritative fact is emitted in this job before any equality proof.
  IO.FS.writeFile (← checked (stringField cfg "targetFactOutput")) (actualTargetFact.pretty ++ "\n")
  let nativeNames := env.constants.fold (fun acc n _ =>
    if (`AbcAdaptation.Reference).isPrefixOf n then acc.push n else acc) (#[] : Array Name)
  let mut nameIndex : Std.HashMap String (Array Name) := {}
  for n in nativeNames do
    nameIndex := nameIndex.insert n.toString ((nameIndex[n.toString]?.getD #[]).push n)
  let mut rs : Relocations := #[]
  for row in ← checked (arrayField cfg "projectMap") do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let display ← checked (stringField row "target")
    let owner := (← checked (stringField row "targetOwner")).toName
    let resolvedNames := (nameIndex[display]?.getD #[]).filter fun n => moduleOf env n == some owner
    unless resolvedNames.size == 1 do throwError "Missing/nonunique exact existing Name {display}"
    let actual := resolvedNames[0]!
    unless actual == `AbcAdaptation.Reference ++ original ||
        (original == `Iut.Corollary22Inputs.threshold._proof_4 &&
         actual == `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_6) do
      throwError "Unexpected source/native name exception {original}"
    unless (← checked (field row "targetToSourceUniverseIndices")) == Json.null do
      throwError "No guessed universe permutation admitted"
    rs := rs.push ⟨original, actual, none, none, none⟩
  let params ← namesFromJson (← checked (field record "levelParams"))
  unless params.length == 5 && target.levelParams.length == 5 do throwError "Unexpected recOn universe telescope"
  let canonical := (canonicalLevels params.length).map Level.param
  let sourceType := (← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))).instantiateLevelParams params canonical
  let sourceValue := (← checked (decodeExpr rs (← checked (field record "valueExpr")))).instantiateLevelParams params canonical
  let targetType := target.type.instantiateLevelParams target.levelParams canonical
  let targetValue := targetRawValue.instantiateLevelParams target.levelParams canonical
  kernelTypeEq "complete source/native recOn public type" sourceType targetType
  kernelTypeEq "complete original recOn value has its exact type"
    (← kernelCheck "complete original recOn value" sourceValue) sourceType
  kernelTypeEq "complete actual recOn value has its exact type"
    (← kernelCheck "complete actual recOn value" targetValue) targetType
  let signatureInventoryEqual := binderInventory sourceType == binderInventory targetType
  let signaturePlacementEqual := binderPlacement sourceType == binderPlacement targetType
  unless signatureInventoryEqual && signaturePlacementEqual do throwError "Actual recOn public signature BinderInfo differs"
  let (sourceBinderCount, targetBinderCount) ← forallTelescope sourceType fun sourceXs _ => do
    forallTelescope targetType fun targetXs _ => pure (sourceXs.size, targetXs.size)
  unless sourceBinderCount == 10 && targetBinderCount == 10 do throwError "Actual recOn public telescopes differ from inspected ten-binder source"
  let rawInventoryEqual := binderInventory sourceValue == binderInventory targetValue
  let rawPlacementEqual := binderPlacement sourceValue == binderPlacement targetValue
  let annotationErasedEqual := Expr.equal (eraseRecOnBinderInfo sourceValue) (eraseRecOnBinderInfo targetValue)
  let (kernelValueEqual, kernelValueError) ← try
    kernelTermEq "exact complete source/native recOn computational values" sourceValue targetValue
    pure (true, Json.null)
  catch e => pure (false, toJson (← e.toMessageData.toString))
  let expectedEquality ← mkEq sourceValue targetValue
  let (closedProof, closedProofError) ← try
    let proof ← Term.elabTerm (← `(by
      funext T AG TG P K d I motive t mk
      cases t
      rfl)) (some expectedEquality)
    Term.synthesizeSyntheticMVarsNoPostponing
    let proof ← instantiateMVars proof
    kernelTypeEq "actual exact closed whole recOn value equality proof"
      (← kernelCheck "closed whole recOn value equality proof" proof) expectedEquality
    ensureStandard "whole recOn equality proof" (← expressionAxioms proof)
    pure (some proof, Json.null)
  catch e => pure (none, toJson (← e.toMessageData.toString))
  let proofJson ← match closedProof with
    | some proof => checked (encodeExpr proof)
    | none => pure Json.null
  let sourceTypeAxioms ← expressionAxioms sourceType
  let sourceValueAxioms ← expressionAxioms sourceValue
  let proofAxioms ← match closedProof with
    | some proof => expressionAxioms proof
    | none => pure #[]
  for axs in #[sourceTypeAxioms, sourceValueAxioms, proofAxioms] do ensureStandard "recOn exact whole value" axs
  let owners := env.header.moduleNames.filter fun owner =>
    #[`Init, `Lean, `Std, `Mathlib, `Batteries, `Aesop, `Qq, `Plausible,
      `ProofWidgets, `ImportGraph, `Cli, `LeanSearchClient].any (·.isPrefixOf owner) ||
        (rs.any fun row => moduleOf env row.target == some owner)
  for e in #[sourceType, targetType, sourceValue, targetValue, expectedEquality] ++ closedProof.toArray do
    for dep in e.getUsedConstants do allowedOwner rs owners dep
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema", toJson "c2-recon-exact-whole-value-probe/v1"), ("configuration", cfg),
    ("actualTargetFact", actualTargetFact), ("actualTargetFactExportedBeforeProof", toJson true),
    ("sourcePublicBinderCount", toJson sourceBinderCount), ("targetPublicBinderCount", toJson targetBinderCount),
    ("completePublicTypeKernelEqual", toJson true),
    ("completePublicTypeBinderInventoryEqual", toJson signatureInventoryEqual),
    ("completePublicTypeBinderPlacementEqual", toJson signaturePlacementEqual),
    ("sourceAndTargetWholeValuesIndividuallyKernelTyped", toJson true),
    ("rawComputationalValueBinderInventoryEqual", toJson rawInventoryEqual),
    ("rawComputationalValueBinderPlacementEqual", toJson rawPlacementEqual),
    ("sourceRawValueBinderCount", toJson (binderInventory sourceValue).size),
    ("targetRawValueBinderCount", toJson (binderInventory targetValue).size),
    ("annotationErasedValueExprStructuralEqual", toJson annotationErasedEqual),
    ("kernelComputationalValueEqual", toJson kernelValueEqual), ("kernelComputationalValueError", kernelValueError),
    ("completePropositionalValueEqualityProved", toJson closedProof.isSome),
    ("completePropositionalValueEqualityError", closedProofError),
    ("completePropositionalEqualityType", ← checked (encodeExpr expectedEquality)),
    ("completePropositionalEqualityProof", proofJson),
    ("sourceTypeAxioms", toJson (sourceTypeAxioms.map Name.toString)),
    ("sourceValueAxioms", toJson (sourceValueAxioms.map Name.toString)),
    ("targetAxioms", toJson (targetAxioms.map Name.toString)),
    ("equalityProofAxioms", toJson (proofAxioms.map Name.toString)),
    ("allValueTypeAndProofDependenciesHaveAllowedOwners", toJson true),
    ("casesOnCertificateChanged", toJson false), ("full44AcceptanceClaimed", toJson false),
    ("dataValueSubstitutions", Json.arr #[]), ("newAliases", Json.arr #[]),
    ("publishAllowed", toJson false), ("finalAcceptance", toJson false)]).pretty ++ "\n")

end FoundationAudit
syntax (name := exactRecOnProbe) "probe_exact_recon_whole_value" : command
@[command_elab exactRecOnProbe] def elabExactRecOnProbe : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.probeExactRecOnValue

probe_exact_recon_whole_value
