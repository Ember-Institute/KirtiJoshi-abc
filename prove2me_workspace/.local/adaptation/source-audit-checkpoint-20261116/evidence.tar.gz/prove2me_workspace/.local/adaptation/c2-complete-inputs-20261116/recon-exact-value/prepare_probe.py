#!/usr/bin/env python3
"""Prepare one recOn probe with authoritative same-job target facts."""
import sys
sys.dont_write_bytecode=True
import json,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
C=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/c2-complete-inputs-20261116')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'sha256':sha(p)}
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def display(n):return (display(n[0])+'.'if n[0]else'')+str(n[2])if n else''

def main():
    assert D==Path('/tmp/p2m-main-bound-candidates-v8-20261115/c2-recon-exact-value-20261116')
    full_path=C/'source-original-exprs.json';full=load(full_path)
    record,=[r for r in full['records']if r['name']=='Iut.ThetaDataExistence.recOn']
    assert record['valueExpr']['kind']=='const'and display(record['valueExpr']['name'])=='Iut.ThetaDataExistence.casesOn'
    telescope=[];e=record['elaboratedExpr']
    while e['kind']=='forall':telescope.append({'name':display(e['name']),'binder':e['binder']});e=e['body']
    assert [r['name']for r in telescope]==['T','AG','TG','P','K','d','I','motive','t','mk']
    assert [r['binder']for r in telescope]==['implicit']*8+['default']*2
    names={r['name']:r['nameExpr']for r in full['records']}
    names.update({r['original']:r['originalName']for r in full['approvedDependencyFacts']})
    finalcfg=load(C/'generated-proof-audit-config-v2.json')
    rows=[]
    for r in finalcfg['projectMap']+finalcfg['priorDependencies']:
        rows.append({'original':r['original'],'originalName':names[r['original']],
            'target':r['target'],'targetOwner':r['targetOwner'],
            'targetToSourceUniverseIndices':r.get('targetToSourceUniverseIndices')})
    assert len(rows)==81and len({r['original']for r in rows})==81
    rowmap={r['original']:r for r in rows};used=set()
    def walk(x):
        if isinstance(x,dict):
            if x.get('kind')in ['const','proj']:
                n=display(x['name'])
                if n in rowmap:used.add(n)
                else:assert not n.startswith(('Iut.','Genl.')),n
            for v in x.values():walk(v)
        elif isinstance(x,list):
            for v in x:walk(v)
    walk(record['elaboratedExpr']);walk(record['valueExpr'])
    prior_cfg=load(C/'caseson-exact-delta/whole-value-probe-config-bound.json')
    for r in prior_cfg['projectMap']:
        current=rowmap[r['original']]
        assert all(current[k]==r[k]for k in ['originalName','target','targetOwner'])
    source=D/'source-recon-record.json';save(source,record)
    passed_probe=C/'caseson-exact-delta/ProbeWholeCasesOnValueEquality.lean'
    base=passed_probe.read_text();marker='partial def eraseOnlyBinderInfo';assert base.count(marker)==1
    generic=base[:base.index(marker)]
    query=D/'ProbeExactRecOnWholeValueEquality.lean';query.write_text(generic+(D/'probe-entry.lean.inc').read_text())
    cfg={'schema':'exact-source44-recOn-whole-value-probe-config/v1','sourceJob':'ci-015918-e7d68794',
        'sourceFile':str(source),'sourceRecordBinding':pin(source),'originalSource44':pin(full_path),
        'originalSource44Receipt':pin(C/'source-identity-exprs-v3-result.json'),
        'projectMap':rows,'actuallyUsedProjectMap':[rowmap[n]for n in sorted(used)],
        'sourcePublicTelescope':telescope,'sourceValueShape':'one exact original casesOn constant at the five original universes',
        'targetFactOutput':str(D/'target-recon-exprs.json'),'outputFile':str(D/'whole-value-probe-result.json'),
        'casesOnCertificateChanged':False,'existingCasesOnEqualityJob':'ci-016049-9435bd46',
        'full44AcceptanceClaimed':False,'publishAllowed':False,'finalAcceptance':False}
    config=D/'probe-config.json';save(config,cfg)
    save(D/'source-inspection.json',{'source44':pin(full_path),'sourceRecord':pin(source),
        'sourcePublicTelescope':telescope,'sourceLevels':record['levelParams'],'sourceWholeValue':record['valueExpr'],
        'sourceValueHasNoLambdaBinders':True,'priorActualCasesOn33MappingsPreserved':True,
        'sourceUsedProjectNameCount':len(used),'sourceUsesExistingNamedCasesOnPair':rowmap['Iut.ThetaDataExistence.casesOn'],
        'full81ExistingMapUsedForTargetProofOwnerChecks':True,
        'nativeValueShapeNotAssumed':True,'nativeFactsExportedBySameProbeJob':True,
        'kernelDefinitionalEqualityResultNotAssumed':True,'dataValueSubstitutions':[],'newAliases':[],
        'compilerRun':False,'CIInvoked':False,'mainWorkspaceWritten':False,'publishAllowed':False,'finalAcceptance':False})
    save(D/'handoff.json',{'schema':'one-recon-closed-whole-value-probe-draft/v1','query':pin(query),'config':pin(config),
        'environment':{'C2_RECON_PROBE_CONFIG':str(config)},'actualTargetFactOutput':cfg['targetFactOutput'],
        'actualProofOutput':cfg['outputFile'],'reusePassedCasesOnProbeCode':pin(passed_probe),
        'sourcePublicBindersInspected':10,'canonicalUniverses':5,'sourceUsedProjectNames':len(used),
        'existingOwnerMaps':81,'expected_duration':'60s','expected_memory':'16GiB',
        'pending':['Actual root MCP-CI closed proof and same-job native recOn facts.','After success, bind exact second named certificate without modifying the first casesOn certificate or admitting other declarations.'],
        'compilerRun':False,'CIInvoked':False,'mainWorkspaceWritten':False,'publishAllowed':False,'finalAcceptance':False})
    print(json.dumps({'query':pin(query),'config':pin(config),'sourceUsedMappings':len(used),'fullOwnerMappings':len(rows)},indent=2))

if __name__=='__main__':main()
