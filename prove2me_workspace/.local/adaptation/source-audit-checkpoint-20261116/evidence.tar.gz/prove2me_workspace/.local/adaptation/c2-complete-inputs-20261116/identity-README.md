# Discrepancy 与完整 C2/P7 内核对应交接

本目录含两个独立的小单元。`discrepancy/` 导出两个原定义；`c2-inputs/` 导出三条原命令及完整生成 API。所有文件仅为离线草稿，`publishAllowed=false`、`finalAcceptance=false`。

| 单元 | 数学 root | 完整导出声明 | 依赖 Name 映射 |
| --- | --- | --- | --- |
| discrepancy | `DiscrepancyLE`、`DiscrepancyEquiv` | 2 | 0 |
| c2-inputs | `Iut.Corollary22Inputs`、`Iut.ThetaDataExistence`、`Iut.Corollary22Inputs.threshold` | 44 | 37 |

C2 的 44 项为完整 `Corollary22Inputs` 结构及生成 API 共 32 项、完整 `ThetaDataExistence` 及生成 API 共 7 项、threshold 及原四条生成辅助证明共 5 项。完整 16+1 字段、构造子、recursor、recursor RHS、noConfusion、sizeOf、flat_ctor、字段 metadata 和 autoParam Expr 均在范围内。独立 `Iut.Corollary22Inputs.c2` 主定理及其 proof/match 项不在此范围。

每单元先运行 `QueryOriginalExprs.lean`。入口环境变量为 `NEXT_CARRIER_EXPORT_CONFIG`，值为该单元 `source-export-config.json` 的绝对路径。工具使用原 4.35.0-rc3 环境与现有热缓存，导出真实 ConstantInfo 的完整 type/value Expr 和结构信息。首次估计为 60s / 16GiB。`source-environment-candidate.json` 只提供既有路径候选；父智能体须绑定实际工作区与输入，不复用旧 manifest。

来源导出器按 display+真实 owner 唯一解析原结构 Name，再保留真实结构化 Name（包括数字分量）。没有把配置中的 display 拼成已接受的原 Name。完整 C2/P7 生成集合还会与实际原 Env 中的命令闭包核对；新增、缺失、非唯一 Name 或未列出的项目依赖都会保持 pending。两个 source exporter 中 `matches` 保留字已改为 `resolvedNames`。

`actual-ast-closure-plan.json` 记录实际原 AST 命令、字段、上下文和每项 closure 来源。Discrepancy 的实际 AST 任务是 `ci-015832-d0585b02`，原 C2 AST 任务是 `ci-014817-8a1bb50d`。无 source range 的生成项依赖已接受 compiler graph，并由导出器对实际 Env 的完整集合守卫验收；不伪造原命令位置。

父智能体取得实际成功 source export 后，应校验输出 SHA，并在 `audit-config.json.sourceReceiptBinding` 绑定真实 `receiptPath`、完整 `receiptContents` 和 `sourceExprSha256`，同时将这些内容与 query/config/SHA 列入实际审查 CI 输入。当前 binding 为 null，故审查入口会明确停止。不能凭 AST、native 叶检查或类型打印关闭身份门。

目标入口为 `AuditPackageIdentity.lean`，使用 4.33.1 与 `PACKAGE_IDENTITY_AUDIT_CONFIG`。它只导入已有 native Definitions，将导出的原 Expr 按精确 Name 映射递归解码，再与真实目标 ConstantInfo 比较完整签名、BinderInfo 位置、非 Prop 计算值、recursor RHS、结构全部字段及 autoParam。Prop 证明逐条核对完整类型和标准公理闭包。没有从原生产 Iut/Genl、未来 source 文件或自身 source oracle 补齐目标数学义务。

`ThetaDataExistence` 的参数 `P` 及 AG/TG、宇宙、K/d/I、每条前提和所有结论均由原完整类型 Expr 导出与比较；原有 predicate 未删除、替换或泛化。原 definition-body 内的数值辅助证明维持原包含关系，未迁移为 standalone Open 定理。

37 个依赖只作为已有 native Name 映射操作数；`dependency-map-evidence.json` 保留现有 main/initial 映射行、真实模块 owner 及源码 SHA。它们的独立 formal gate 不因本单元改变。所有 target generated Name 必须在指定 native owner 唯一解析并等于真实原 Name 的命名空间前缀重定位。缺失或跨版本变化不会触发猜测映射、标准常量替换或证明值替换。

通用 encode/decode、kernelCheck、kernelTypeEq、kernelTermEq、compareRecord 沿用 `/tmp/p2m-iut-small-supplier-identity-20261116` 已有草稿，与 main/initial 审计实现同源；本次只改小单元入口、导入、计数、依赖闭包及字段顺序守卫。代码复用来源与 SHA 见 `handoff.json`，离线范围核对见 `offline-checks.json`。子智能体未运行 Lean、MCP-CI、平台 API 或 Git，也未写主工作区。
