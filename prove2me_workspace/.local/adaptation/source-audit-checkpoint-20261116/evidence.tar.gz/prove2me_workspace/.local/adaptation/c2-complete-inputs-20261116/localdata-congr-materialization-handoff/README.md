# localData.congr_simp 的最小持久化方案

建议在 native C2 文件的 `end Corollary22Inputs` 之后、`end Iut` 之前加入一条命令：

```lean
attribute [local congr] Corollary22Inputs.localData.congr_simp
```

完整临时草稿在 `ready/Definitions/Def_AbcAdaptation_Reference_Iut_Implication_Corollary22.lean`，精确单行补丁在 `suggested-fix.patch`。除插入该命令和分隔空行外，现有 native 字节全部不变；没有新 import、数学 alias、手写证明或义务删减。

实际 source44 的 `Iut.Corollary22Inputs.localData.congr_simp` 是原 compiler theorem：宇宙参数 `[w,u_1]`；T/K/d 隐式；后续参数为两份 self、self 等式、两份 x、x 等式和原成员证明，结论是两份依赖 localData 值的等式。完整原 Expr 来自成功任务 `ci-015918-e7d68794`，摘要与完整记录/Expr 哈希在 `evidence.json`。source 的完整、type 和 value 公理均为三个标准公理。

锁定 Lean 4.33.1 的 `Lean/Meta/CongrTheorems.lean` 在第 399–444 行保留 `congr_simp` 后缀并安装生成 action。该 action 以原 projection 的类型计算 `mkCongrSimpCore?`，再通过 `realizeConst`、`mkThmOrUnsafeDef`、`addDecl` 生成同名 theorem。该文件与来源 Lean 4.35.0-rc3 的对应文件逐字相同，SHA 为 `2a24eae0954ff67bab815eab23dd595be020c0320086f070bae846947413d2db`。

`Lean/Elab/Declaration.lean` 第 316–333 行显示：attribute 命令先调用 `realizeGlobalConstWithInfos`，随后才应用属性。因此本命令触发的是编译器原生 reserved-name action。`congr` 属性对应依赖参数的 congruence theorem；它是局部登记，不添加全局 simp rewrite。调用发生于 projection 自己的 native 模块内，以保留该模块拥有的真实生成声明。

`QueryImportedLocalDataCongr.lean` 导入重新生成的 native artifact 后，首先直接查 `env.find?` 和实际 owner，确认 theorem 已存在；此检查在任何 `#check` 或 `#print` 之前。这样查询自身不会通过触发 reserved-name action 掩盖 artifact 中缺失的声明。随后打印完整类型、证明体及公理。

父智能体可在应用一行补丁并单独重新生成 native artifact 后，用上述窄查询检查持久化，再运行既有完整 44 项来源对应审查。此前 `ci-015942-a890ad15` 在名称预检处失败，尚未关闭 C2 门。本次不改 44 项配置、不改三项 literal-proof 差异证书、不改 root 增强的 data/recursor BinderInfo 检查。

本目录仅为离线方案，未执行 Lean、MCP-CI、平台 API 或 Git，未写主工作区。`publishAllowed=false`、`finalAcceptance=false`。
