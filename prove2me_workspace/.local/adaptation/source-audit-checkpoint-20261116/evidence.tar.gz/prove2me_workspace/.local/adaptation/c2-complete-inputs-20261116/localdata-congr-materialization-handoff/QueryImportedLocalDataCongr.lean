import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22

-- Read the imported environment before any command can realize the reserved name.
run_meta do
  let n := `AbcAdaptation.Reference.Iut.Corollary22Inputs.localData.congr_simp
  let env ← Lean.getEnv
  let some ci := env.find? n | throwError "Missing persisted localData.congr_simp in imported artifact"
  let .thmInfo _ := ci | throwError "Expected compiler-generated congruence theorem"
  let some idx := env.getModuleIdxFor? n | throwError "Missing imported declaration owner"
  let some imported := env.header.modules[idx.toNat]? | throwError "Missing indexed module record"
  unless imported.module == `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22 do
    throwError "Unexpected imported owner for localData.congr_simp"
  let axs ← Lean.collectAxioms n
  let expected := #[`propext, `Classical.choice, `Quot.sound]
  unless axs.qsort Lean.Name.lt == expected.qsort Lean.Name.lt do
    throwError "Imported congruence theorem axiom inventory differs from source44"
  logInfo m!"Persisted compiler theorem present at exact native owner: {n}"

set_option pp.fullNames true
set_option pp.explicit true
set_option pp.universes true
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.localData.congr_simp
#print AbcAdaptation.Reference.Iut.Corollary22Inputs.localData.congr_simp
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs.localData.congr_simp
