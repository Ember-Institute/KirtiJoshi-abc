def checkExactThetaDataRecOnCertificate (rs : Relocations) (owners : Array Name)
    (cfg record : Json) (target : ConstantInfo) (sourceValue targetValue : Expr) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  unless original == `Iut.ThetaDataExistence.recOn &&
      target.name == `AbcAdaptation.Reference.Iut.ThetaDataExistence.recOn &&
      moduleOf (← getEnv) target.name == some `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22 do
    throwError "Second whole-value certificate is restricted to the exact ThetaDataExistence.recOn pair"
  unless (← checked (stringField cfg "schema")) == "exact-ThetaDataExistence-recOn-whole-value-certificate/v1" &&
      (← checked (decodeName (← checked (field cfg "originalName")))) == original &&
      (← checked (decodeName (← checked (field cfg "targetName")))) == target.name do
    throwError "Wrong exact recOn certificate scope"
  for key in #["dataValueSubstitutions", "newAliases"] do
    unless (← checked (arrayField cfg key)).isEmpty do throwError "No data substitution or new alias admitted"
  let receiptBinding ← checked (field cfg "passedProbeReceipt")
  let receipt ← jsonFile (← checked (stringField receiptBinding "path"))
  unless receipt == (← checked (field receiptBinding "contents")) &&
      (← checked (stringField receipt "job_id")) == "__ACTUAL_RECON_JOB__" &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Actual passed recOn proof receipt differs"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Actual recOn proof job did not exit zero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do throwError "recOn proof workspace differs"
  let manifest ← checked (field snapshot "manifest")
  let queryBinding ← checked (field cfg "passedProbeQuery")
  unless (← checked (field manifest "source_sha256")) == (← checked (field queryBinding "sha256")) do
    throwError "Actually passed recOn probe source SHA differs"
  let probeConfigBinding ← checked (field cfg "passedProbeConfig")
  let probeConfigPath ← checked (stringField probeConfigBinding "path")
  let probeConfig ← jsonFile probeConfigPath
  unless probeConfig == (← checked (field probeConfigBinding "contents")) do throwError "recOn proof configuration changed"
  let request ← checked (field receipt "request")
  let environment ← checked (field request "environment")
  unless (← checked (stringField environment "C2_RECON_PROBE_CONFIG")) == probeConfigPath do
    throwError "recOn receipt used another exact probe configuration"
  let outputBinding ← checked (field cfg "passedProbeOutput")
  unless (← checked (stringField outputBinding "sha256")).length == 64 do
    throwError "Missing actual complete recOn proof output SHA in final CI input binding"
  let output ← jsonFile (← checked (stringField outputBinding "path"))
  unless (← checked (field output "configuration")) == probeConfig &&
      (← checked (stringField output "schema")) == "c2-recon-exact-whole-value-probe/v1" do
    throwError "recOn output/configuration binding differs"
  for key in #["completePublicTypeKernelEqual", "completePublicTypeBinderInventoryEqual",
      "completePublicTypeBinderPlacementEqual", "sourceAndTargetWholeValuesIndividuallyKernelTyped",
      "completePropositionalValueEqualityProved", "actualTargetFactExportedBeforeProof",
      "allValueTypeAndProofDependenciesHaveAllowedOwners"] do
    unless (← checked (output.getObjValAs? Bool key)) do throwError "Actual recOn proof precondition failed {key}"
  for key in #["rawComputationalValueBinderInventoryEqual", "rawComputationalValueBinderPlacementEqual",
      "annotationErasedValueExprStructuralEqual", "casesOnCertificateChanged", "full44AcceptanceClaimed"] do
    if (← checked (output.getObjValAs? Bool key)) then throwError "Actual recOn raw-false/scoped evidence changed {key}"
  let sourceBinding ← checked (field cfg "actualProbeSourceRecord")
  let sourcePath ← checked (stringField sourceBinding "path")
  unless (← checked (stringField probeConfig "sourceFile")) == sourcePath && (← jsonFile sourcePath) == record do
    throwError "Current full source44 recOn record differs from proved original record"
  let factBinding ← checked (field cfg "sameJobActualTargetFact")
  let factPath ← checked (stringField factBinding "path")
  unless (← checked (stringField probeConfig "targetFactOutput")) == factPath do
    throwError "recOn proof/fact output path differs"
  let fact ← jsonFile factPath
  unless fact == (← checked (field output "actualTargetFact")) do
    throwError "recOn target facts are not the authoritative facts emitted in the proof job"
  let some rawTargetValue := target.value? (allowOpaque := true) | throwError "Actual recOn value missing"
  unless (← checked (field fact "name")) == toJson target.name.toString &&
      (← checked (field fact "typeExpr")) == (← checked (encodeExpr target.type)) &&
      (← checked (field fact "valueExpr")) == (← checked (encodeExpr rawTargetValue)) do
    throwError "Current imported recOn type/value differs from same-job authoritative proof operands"
  let expectedEquality ← mkEq sourceValue targetValue
  let equalityJson ← checked (field output "completePropositionalEqualityType")
  unless equalityJson == (← checked (encodeExpr expectedEquality)) do
    throwError "Stored recOn Eq is not exactly Eq(current complete source value,current complete target value)"
  let equality ← checked (decodeActualCertificateExpr equalityJson)
  let proofJson ← checked (field output "completePropositionalEqualityProof")
  let proof ← checked (decodeActualCertificateExpr proofJson)
  kernelTypeEq "exact recOn stored full equality type" equality expectedEquality
  kernelTypeEq "encoded recOn proof inhabits exact current complete equality"
    (← kernelCheck "actual closed complete recOn equality proof" proof) expectedEquality
  let definitionallyEqual ← checked (output.getObjValAs? Bool "kernelComputationalValueEqual")
  if definitionallyEqual then
    kernelTermEq "actual recOn definitional equality independently holds in final environment" sourceValue targetValue
  let axs ← expressionAxioms proof
  let taxs ← expressionAxioms expectedEquality
  ensureStandard "exact full recOn equality proof" axs
  ensureStandard "exact full recOn equality type" taxs
  for e in #[sourceValue,targetValue,expectedEquality,proof] do
    for dep in e.getUsedConstants do allowedOwner rs owners dep
  let rawInventoryEqual := binderInventory sourceValue == binderInventory targetValue
  let rawPlacementEqual := binderPlacement sourceValue == binderPlacement targetValue
  unless !rawInventoryEqual && !rawPlacementEqual do throwError "Actual recOn raw BinderInfo discrepancy changed"
  return Json.mkObj [
    ("scope", toJson "only Iut.ThetaDataExistence.recOn"),
    ("kernelCheckedExactCompleteValueEqualityProof", toJson true),
    ("exactCurrentEqualityType", equalityJson), ("kernelCheckedEqualityProof", proofJson),
    ("proofAxioms", toJson (axs.map Name.toString)), ("equalityTypeAxioms", toJson (taxs.map Name.toString)),
    ("allProofAndWholeValueDependenciesHaveAllowedOwners", toJson true),
    ("kernelDefinitionalValueEquality", toJson definitionallyEqual),
    ("actualDefinitionalEqualityProbeJob", toJson "__ACTUAL_RECON_JOB__"),
    ("rawComputationalValueBinderInventoryEqual", toJson false),
    ("rawComputationalValueBinderPlacementEqual", toJson false),
    ("annotationErasedStructuralEquality", toJson false),
    ("passedProbeReceipt", receiptBinding), ("passedProbeOutput", outputBinding),
    ("sameJobActualTargetFact", factBinding),
    ("sourceValueUnmodified", toJson true), ("targetValueUnmodified", toJson true),
    ("dataValueSubstitutions", Json.arr #[]), ("newAliases", Json.arr #[])]
