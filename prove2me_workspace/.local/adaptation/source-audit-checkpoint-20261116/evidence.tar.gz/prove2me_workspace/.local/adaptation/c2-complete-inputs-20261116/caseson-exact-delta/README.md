# C2 casesOn 的实际差异与窄诊断

`actual-delta.json` 来自实际 source44（`ci-015918-e7d68794`）及 actual native JSON（`ci-016005-288d6005`），不靠 pretty-printer 推断 Expr。33 个项目 Name 精确重定位后，完整公开 type 的 JSON 结构与 BinderInfo 都完全相同。

两份完整 value 的顶层10个 lambda（T、AG、TG、P、K、d、I、motive、t、mk）BinderInfo 也相同。差异是生成算法：source4.35 使用 `minor (projection major)`，native4.33 使用 `ThetaDataExistence.rec ... (fun thetaData => minor thetaData) major`。native minor wrapper 携带完整 P7 参数类型，因此完整 value BinderInfo 数量为 source31、target50，19 个路径不同。擦除所有 BinderInfo 后仍不结构相同；连 binderName 也擦除仍不相同。注释专用例外不适用，`annotationOnlyExceptionAdmissible=false`。

锁定源码显示，4.35 `CasesOn.lean` 新增 `isCasesOnViaProjs`/`mkCasesOnViaProjs?`，针对单构造、无 indices、非递归、可 large elimination 的 Prop 结构，用字段 projection 生成 value。4.33 仅调用原 `mkCasesOnImp`。准确文件 SHA 和位置见 `generator-evidence.json`。这不是数学字段变化；但也不能谎报完整计算值 BinderInfo 相同。

`DiagnoseExactCasesOn.lean` 是独立内核诊断，使用 `C2_CASESON_DIAGNOSTIC_CONFIG=diagnostic-mappings.json`。它先核对实际 compiled target.type/value 与成功 native JSON 完全相同，再将 source/target 五个宇宙参数统一，检查完整公开类型、原始两份值分别具有该类型，最后独立尝试 `KernelTermEq`。它保留真实 raw-value BinderInfo 与 annotation-erased 结构标志；内核转换失败会被单独记录，不会改写成通过。擦除标注的表达式从不作为内核比较输入。

`ProbeWholeCasesOnValueEquality.lean` 是额外、未编译的完整值等式探针，配置为 `whole-value-probe-config.json`。它保留上述全部诊断，另尝试对原始两份完整值构造10参数 funext、对 major proof 做 constructor elimination、再 reflexivity 的闭合等式证书。该证书必须被 Kernel 检查且公理为标准集合，才会在结果中记录 true；代码不加入数学 alias、不替换任何 data value、不重定义生成声明。即使成功，也不会自动打开当前44项门或把 raw BinderInfo false 改成 true。这是一条更强的、需要单独审查的 whole-value 证明路线，不是已经失败的 annotation-only 例外。

本任务没有修改当前44项审查器。该审查器增强的公开类型、data-value、recursor RHS、结构、autoParam 与 owner/axiom 检查继续保留。完整44验收及任何额外具体 value-equality 例外仍待 root 实际 CI 与显式整合。`publishAllowed=false`、`finalAcceptance=false`。

所有新增文件在任务临时目录；未执行 Lean、CI、API 或 Git，未写主工作区。main5 工作在独立 `/tmp/p2m-main-bound-five-identity-v9-20261116`，未混入本任务。
