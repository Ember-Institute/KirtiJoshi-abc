import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs
#check @AbcAdaptation.Reference.Iut.ThetaDataExistence
#print axioms AbcAdaptation.Reference.Iut.ThetaDataExistence
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.htCan_equiv
#check @AbcAdaptation.Reference.Iut.ThetaDataExistence.thetaData
#print AbcAdaptation.Reference.Iut.Corollary22Inputs
#print AbcAdaptation.Reference.Iut.ThetaDataExistence
#print AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold
