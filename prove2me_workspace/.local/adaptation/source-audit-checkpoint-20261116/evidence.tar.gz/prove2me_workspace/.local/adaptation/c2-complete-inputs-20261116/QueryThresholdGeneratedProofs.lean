import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22
set_option pp.fullNames true
set_option pp.explicit true
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_1
#print AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_1
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_1
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_2
#print AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_2
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_2
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_3
#print AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_3
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_3
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_4
#print AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_4
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_4
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_5
#print AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_5
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_5
#check @AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_6
#print AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_6
#print axioms AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_6
#check @AbcAdaptation.Reference.Iut.epsilonE.eq_1
#print axioms AbcAdaptation.Reference.Iut.epsilonE.eq_1
