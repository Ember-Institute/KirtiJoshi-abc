import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22
import Definitions.Def_AbcAdaptation_Reference_Genl_Mathlib_Order_BoundedDiscrepancy
import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_HeightTheory
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection_HeightParts
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

structure Relocation where
  original : Name
  target : Name
  permutation : Option (Array Nat)
  expectedInstance : Option Bool
  expectedAxioms : Option (Array Name)

abbrev Relocations := Array Relocation

def projectName (n : Name) : Bool :=
  #[`Iut, `Genl, `AbcAdaptation, `Definitions, `Theorems, `Solutions].any (·.isPrefixOf n)

def relocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.original == n) then return r.target
  if projectName n then throw s!"Unmapped project name {n}"
  return n

def inverseRelocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.target == n) then return r.original
  if projectName n then throw s!"Unmapped wrapped name {n}"
  return n

def reorder (indices : Array Nat) (us : Array α) : Except String (Array α) := do
  unless indices.size == us.size && indices.toList.eraseDups.length == us.size do
    throw "Universe permutation has incorrect size or repeated indices"
  indices.mapM fun i => match us[i]? with
    | some u => pure u
    | none => throw "Universe permutation index out of range"

partial def decodeExpr (rs : Relocations) (j : Json) : Except String Expr := do
  let recur := decodeExpr rs
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    let target ← relocated rs original
    let mut levels ← (← arrayField j "levels").mapM decodeLevel
    if let some r := rs.find? (·.original == original) then
      if let some indices := r.permutation then levels ← reorder indices levels
    return .const target levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocated rs (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unknown Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name)
    (certifiedGeneratedProofs : Array Name := #[]) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No owner {name}"
  unless modules.contains owner do throwError "Forbidden dependency {name}, owner {owner}"
  if #[`Iut, `Genl].any (·.isPrefixOf name) then
    throwError "Pending unrelocated source dependency {name}"
  if (`AbcAdaptation).isPrefixOf name &&
      !(rs.any (·.target == name)) && !certifiedGeneratedProofs.contains name then
    throwError "Pending unmapped target dependency {name}"

def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name)
    (certifiedGeneratedProofs : Array Name := #[]) : MetaM Json := do
  let ci ← getConstInfo name
  if let .axiomInfo _ := ci then throwError "Carrier declares an axiom {name}"
  let axs ← collectAxioms name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"carrier {name}" axs
  ensureStandard s!"carrier type {name}" taxs
  let value? := ci.value? (allowOpaque := true)
  let vaxs ← match value? with
    | some v => expressionAxioms v
    | none => pure #[]
  ensureStandard s!"carrier value {name}" vaxs
  for expr in #[ci.type] ++ value?.toArray do
    for dep in expr.getUsedConstants do allowedOwner rs modules dep certifiedGeneratedProofs
  if let .recInfo r := ci then
    for rule in r.rules do
      for dep in rule.rhs.getUsedConstants do allowedOwner rs modules dep certifiedGeneratedProofs
      ensureStandard s!"recursor rule {name}" (← expressionAxioms rule.rhs)
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("hasValue", toJson value?.isSome),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name))]

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

-- Decode the actual target-language proof verbatim. There is no source Name
-- relocation, proof-value replacement, normalization, or data substitution here.
partial def decodeActualCertificateExpr (j : Json) : Except String Expr := do
  let recur := decodeActualCertificateExpr
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" => do
    let name ← decodeName (← field j "name")
    let levels ← (← arrayField j "levels").mapM decodeLevel
    return .const name levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => do
    let name ← decodeName (← field j "name")
    let type ← recur (← field j "type")
    let body ← recur (← field j "body")
    let binder ← decodeBinder (← stringField j "binder")
    return .lam name type body binder
  | "forall" => do
    let name ← decodeName (← field j "name")
    let type ← recur (← field j "type")
    let body ← recur (← field j "body")
    let binder ← decodeBinder (← stringField j "binder")
    return .forallE name type body binder
  | "let" => do
    let name ← decodeName (← field j "name")
    let type ← recur (← field j "type")
    let value ← recur (← field j "value")
    let body ← recur (← field j "body")
    let nondependent ← (← field j "nondependent").getBool?
    return .letE name type value body nondependent
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => do
    let name ← decodeName (← field j "name")
    let index ← (← field j "index").getNat?
    let body ← recur (← field j "body")
    return .proj name index body
  | other => throw s!"Unsupported actual encoded certificate node {other}"

def checkExactThetaDataCasesOnCertificate (rs : Relocations) (owners : Array Name)
    (cfg record : Json) (target : ConstantInfo) (sourceValue targetValue : Expr) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  unless original == `Iut.ThetaDataExistence.casesOn &&
      target.name == `AbcAdaptation.Reference.Iut.ThetaDataExistence.casesOn &&
      moduleOf (← getEnv) target.name == some `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22 do
    throwError "Whole-value equality certificate is restricted to the exact ThetaDataExistence.casesOn pair"
  unless (← checked (stringField cfg "schema")) == "exact-ThetaDataExistence-casesOn-whole-value-certificate/v1" &&
      (← checked (decodeName (← checked (field cfg "originalName")))) == original &&
      (← checked (decodeName (← checked (field cfg "targetName")))) == target.name do
    throwError "Wrong exact casesOn certificate scope"
  for key in #["dataValueSubstitutions", "newAliases"] do
    unless (← checked (arrayField cfg key)).isEmpty do throwError "No data substitution or alias is admitted"
  let receiptBinding ← checked (field cfg "passedProbeReceipt")
  let receipt ← jsonFile (← checked (stringField receiptBinding "path"))
  unless receipt == (← checked (field receiptBinding "contents")) &&
      (← checked (stringField receipt "job_id")) == "ci-016049-9435bd46" &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Actual passed complete-value equality receipt differs"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Whole-value proof job did not exit zero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Whole-value proof workspace mode differs"
  let manifest ← checked (field snapshot "manifest")
  let queryBinding ← checked (field cfg "passedProbeQuery")
  unless (← checked (field manifest "source_sha256")) == (← checked (field queryBinding "sha256")) do
    throwError "Passed proof query source hash differs"
  let probeConfigBinding ← checked (field cfg "passedProbeConfig")
  let probeConfigPath ← checked (stringField probeConfigBinding "path")
  let probeConfig ← jsonFile probeConfigPath
  unless probeConfig == (← checked (field probeConfigBinding "contents")) do throwError "Passed proof configuration changed"
  let request ← checked (field receipt "request")
  let environment ← checked (field request "environment")
  unless (← checked (stringField environment "C2_CASESON_DIAGNOSTIC_CONFIG")) == probeConfigPath do
    throwError "Proof receipt used another actual source/target configuration"
  let proofOutputBinding ← checked (field cfg "passedProbeOutput")
  unless (← checked (stringField proofOutputBinding "sha256")).length == 64 do
    throwError "Missing complete proof output SHA bound in final CI inputs"
  let proofOutput ← jsonFile (← checked (stringField proofOutputBinding "path"))
  unless (← checked (field proofOutput "configuration")) == probeConfig &&
      (← checked (stringField proofOutput "schema")) == "c2-caseson-exact-whole-value-diagnostic/v1" do
    throwError "Actual proof output/configuration binding differs"
  for key in #["completePublicTypeKernelEqual", "completePublicTypeBinderInventoryEqual",
      "completePublicTypeBinderPlacementEqual", "sourceAndTargetWholeValuesIndividuallyKernelTyped",
      "completePropositionalValueEqualityProved"] do
    unless (← checked (proofOutput.getObjValAs? Bool key)) do throwError "Actual whole-value proof precondition failed {key}"
  for key in #["rawComputationalValueBinderInventoryEqual", "rawComputationalValueBinderPlacementEqual",
      "annotationErasedValueExprStructuralEqual", "annotationOnlyExceptionAdmissible",
      "kernelComputationalValueEqual", "full44AcceptanceClaimed", "proofRouteAutomaticallyAdmitsFull44"] do
    if (← checked (proofOutput.getObjValAs? Bool key)) then throwError "Raw-false or scoped proof evidence changed {key}"
  let sourceBinding ← checked (field cfg "actualProbeSourceRecord")
  let probeSourcePath ← checked (stringField sourceBinding "path")
  unless (← checked (stringField probeConfig "sourceFile")) == probeSourcePath &&
      (← jsonFile probeSourcePath) == record do
    throwError "Complete current source44 record differs from the actually proved source value"
  let targetBinding ← checked (field cfg "actualTargetFact")
  let targetFactPath ← checked (stringField targetBinding "path")
  unless (← checked (stringField probeConfig "targetFactFile")) == targetFactPath do
    throwError "Proof used another actual target fact"
  let fact ← jsonFile targetFactPath
  let some rawTargetValue := target.value? (allowOpaque := true) | throwError "Current target value missing"
  unless (← checked (field fact "name")) == toJson target.name.toString &&
      (← checked (field fact "typeExpr")) == (← checked (encodeExpr target.type)) &&
      (← checked (field fact "valueExpr")) == (← checked (encodeExpr rawTargetValue)) do
    throwError "Actual compiled target type/value differs from the complete equality certificate operands"
  let expectedEquality ← mkEq sourceValue targetValue
  let storedEqualityJson ← checked (field proofOutput "completePropositionalEqualityType")
  -- The common Expr codec erases metadata only. This is exact structural equality
  -- of both complete current operands, not merely convertibility to a weaker Eq.
  unless storedEqualityJson == (← checked (encodeExpr expectedEquality)) do
    throwError "Certificate is not the exact Eq(current complete source value, current complete target value)"
  let storedEquality ← checked (decodeActualCertificateExpr storedEqualityJson)
  let proof ← checked (decodeActualCertificateExpr (← checked (field proofOutput "completePropositionalEqualityProof")))
  kernelTypeEq "stored whole-value Eq is the exact current complete Eq" storedEquality expectedEquality
  kernelTypeEq "actual encoded whole-value proof inhabits exact current complete Eq"
    (← kernelCheck "actual encoded full casesOn equality proof" proof) expectedEquality
  let proofAxioms ← expressionAxioms proof
  let equalityAxioms ← expressionAxioms expectedEquality
  ensureStandard "exact full casesOn equality proof" proofAxioms
  ensureStandard "exact full casesOn equality type" equalityAxioms
  for e in #[sourceValue, targetValue, expectedEquality, proof] do
    for dep in e.getUsedConstants do allowedOwner rs owners dep
  let rawInventoryEqual := binderInventory sourceValue == binderInventory targetValue
  let rawPlacementEqual := binderPlacement sourceValue == binderPlacement targetValue
  unless !rawInventoryEqual && !rawPlacementEqual do throwError "Expected actual raw computational BinderInfo differences changed"
  return Json.mkObj [
    ("scope", toJson "only Iut.ThetaDataExistence.casesOn"),
    ("kernelCheckedExactCompleteValueEqualityProof", toJson true),
    ("exactCurrentEqualityType", storedEqualityJson),
    ("kernelCheckedEqualityProof", ← checked (field proofOutput "completePropositionalEqualityProof")),
    ("proofAxioms", toJson (proofAxioms.map Name.toString)),
    ("equalityTypeAxioms", toJson (equalityAxioms.map Name.toString)),
    ("allProofAndWholeValueDependenciesHaveAllowedOwners", toJson true),
    ("kernelDefinitionalValueEquality", toJson false),
    ("actualDefinitionalEqualityFailureJob", toJson "ci-016049-9435bd46"),
    ("rawComputationalValueBinderInventoryEqual", toJson false),
    ("rawComputationalValueBinderPlacementEqual", toJson false),
    ("annotationErasedStructuralEquality", toJson false),
    ("passedProbeReceipt", receiptBinding), ("passedProbeOutput", proofOutputBinding),
    ("sourceValueUnmodified", toJson true), ("targetValueUnmodified", toJson true),
    ("dataValueSubstitutions", Json.arr #[]), ("newAliases", Json.arr #[])]

def compareRecord (rs : Relocations) (allowedOwners : Array Name) (record : Json) (target : ConstantInfo)
    (wholeValueCertificate : Option Json := none) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.eraseDups == sourceParams do throwError "Duplicate universe parameter {original}"
  unless sourceParams.length == target.levelParams.length do
    throwError "Universe parameter count differs for {original}"
  unless (← checked (stringField record "constantKind")) == kind target do
    throwError "ConstantInfo kind differs for {original}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original axiom for {original}"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "Missing map entry {original}"
  let some expectedAxioms := rel.expectedAxioms |
    throwError "Missing accepted-graph source axiom inventory {original}"
  let sourceAxiomNames := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxiomNames.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Original axiom closure differs from accepted compiler graph {original}"
  let some expectedInstance := rel.expectedInstance |
    throwError "Missing accepted-graph instance flag {original}"
  unless (← checked (record.getObjValAs? Bool "isInstance")) == expectedInstance do
    throwError "Exported original instance flag differs from accepted graph {original}"
  unless Lean.Meta.isInstanceCore (← getEnv) target.name == expectedInstance do
    throwError "Instance registry membership differs for {original}"
  let targetLevels ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let reordered ← checked (reorder indices canonical.toArray)
      pure reordered.toList
  let originalSignature ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let originalSignature := originalSignature.instantiateLevelParams sourceParams canonical
  let sourceTypeRaw ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams targetLevels
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory originalSignature do
    throwError "Unexpanded original signature BinderInfo serialization differs for {original}"
  unless binderInventory originalSignature == binderInventory targetType do
    throwError "Full unexpanded original/actual target signature BinderInfo inventory differs for {original}"
  unless binderPlacement originalSignature == binderPlacement targetType do
    throwError "Full unexpanded original/actual target signature BinderInfo placement differs for {original}"
  kernelTypeEq s!"original versus target type {original}" sourceType targetType
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do
    throwError "Inductive/constructor/recursor computation shape differs for {original}"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  unless sourceProp == (← isProp target.type) do throwError "Proposition status differs {original}"
  let mut comparedValue := false
  let mut definitionallyEqualValue := false
  let mut propositionalValueEquality := false
  let mut propositionalValueEvidence := Json.null
  let mut rawValueBinderInventoryEqual := true
  let mut rawValueBinderPlacementEqual := true
  let originalValueJson ← checked (field record "valueExpr")
  -- Proof declarations are audited by exact type and axiom closure. For a data
  -- value containing proof fields, Kernel.isDefEq itself uses proof irrelevance.
  if !sourceProp && originalValueJson != Json.null then
    let sourceValue := (← checked (decodeExpr rs originalValueJson)).instantiateLevelParams sourceParams canonical
    let some targetValue := target.value? (allowOpaque := true) |
      throwError "Target value missing for {original}"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq s!"original value inhabits original type {original}"
      (← kernelCheck s!"original value {original}" sourceValue) sourceType
    kernelTypeEq s!"target value inhabits target type {original}"
      (← kernelCheck s!"target value {original}" targetValue) targetType
    rawValueBinderInventoryEqual := binderInventory sourceValue == binderInventory targetValue
    rawValueBinderPlacementEqual := binderPlacement sourceValue == binderPlacement targetValue
    if original == `Iut.ThetaDataExistence.casesOn then
      let some certificate := wholeValueCertificate |
        throwError "Pending exact complete ThetaDataExistence.casesOn value equality certificate"
      propositionalValueEvidence ← checkExactThetaDataCasesOnCertificate rs allowedOwners
        certificate record target sourceValue targetValue
      propositionalValueEquality := true
      -- The actual prior check failed; do not relabel propositional equality or
      -- the changed generated BinderInfo as definitional/structural equality.
      definitionallyEqualValue := false
    else
      unless rawValueBinderInventoryEqual && rawValueBinderPlacementEqual do
        throwError "Pending computational value BinderInfo inventory/placement difference {original}"
      kernelTermEq s!"original versus target computational value {original}" sourceValue targetValue
      definitionallyEqualValue := true
    comparedValue := true
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut comparedRules := 0
  if let .recInfo r := target then
    unless rules.size == r.rules.length do throwError "Recursor rule count differs {original}"
    for i in [:rules.size] do
      let sourceRhs := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let targetRhs := r.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      unless binderInventory sourceRhs == binderInventory targetRhs &&
          binderPlacement sourceRhs == binderPlacement targetRhs do
        throwError "Pending recursor RHS BinderInfo inventory/placement difference {original} #{i}"
      kernelTermEq s!"recursor rule {original} #{i}" sourceRhs targetRhs
      comparedRules := comparedRules + 1
  else
    unless rules.isEmpty do throwError "Unexpected original recursor rules {original}"
  let sourceStruct ← checked (field record "structure")
  unless (sourceStruct != Json.null) == (getStructureInfo? (← getEnv) target.name).isSome do
    throwError "Structure metadata presence differs {original}"
  if sourceStruct != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name |
      throwError "Target structure metadata missing {target.name}"
    unless (← checked (field sourceStruct "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do
      throwError "Complete structure field/parent metadata differs {original}"
    let autoParams ← checked (arrayField sourceStruct "fieldAutoParamExprs")
    unless autoParams.size == info.fieldInfo.size do
      throwError "Structure field autoParam count differs {original}"
    for i in [:autoParams.size] do
      match autoParams[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some targetExpr =>
        if sourceJson == Json.null then throwError "Missing source autoParam {original} #{i}"
        let sourceExpr := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let targetExpr := targetExpr.instantiateLevelParams target.levelParams targetLevels
        unless binderPlacement sourceExpr == binderPlacement targetExpr do
          throwError "Structure autoParam BinderInfo placement differs {original} #{i}"
        kernelTermEq s!"structure field autoParam {original} #{i}" sourceExpr targetExpr
      | sourceJson, none =>
        unless sourceJson == Json.null do throwError "Missing target autoParam {original} #{i}"
    unless (← checked (field sourceStruct "fieldsInConstructorOrder")) ==
        toJson (info.fieldNames.map Name.toString) do
      throwError "Structure field order differs {original}"
    let projections ← namesFromJson (← checked (field sourceStruct "projections"))
    let targetProjections ← projections.toArray.mapM fun n => checked (relocated rs n)
    unless targetProjections == info.fieldInfo.map (·.projFn) do
      throwError "Structure accessor identities/order differ {original}"
    for p in targetProjections do
      unless rs.any (·.target == p) do throwError "Unaudited structure accessor {p}"
  return Json.mkObj [("original", toJson original.toString), ("originalName", encodeName original),
    ("target", toJson target.name.toString), ("targetName", encodeName target.name),
    ("sourceRecord", record), ("kernelTypeEqual", toJson true),
    ("allExpressionBinderInfoEqual", toJson (rawValueBinderInventoryEqual && rawValueBinderPlacementEqual)),
    ("binderInfoPlacementEqual", toJson rawValueBinderPlacementEqual),
    ("rawComputationalValueBinderInventoryEqual", toJson rawValueBinderInventoryEqual),
    ("rawComputationalValueBinderPlacementEqual", toJson rawValueBinderPlacementEqual),
    ("computationalValueBinderInfoComparisonPerformed", toJson comparedValue),
    ("sourceSignatureBinderInfoSerializationValidated", toJson true),
    ("sourceTargetSignatureBinderInfoInventoryEqual", toJson true),
    ("sourceTargetSignatureBinderInfoPlacementEqual", toJson true),
    ("binderInfoComparisonScope", toJson "actual-exported-4.35-source-type-after-exact-name-relocation-vs-actual-4.33-target-type"),
    ("expandedOriginalTypeKernelEqual", toJson true),
    ("computationShapeEqual", toJson true), ("completeStructureMetadataEqual", toJson true),
    ("kernelValueEqual", toJson definitionallyEqualValue),
    ("computationalValueEqualityChecked", toJson comparedValue),
    ("kernelPropositionalValueEquality", toJson propositionalValueEquality),
    ("propositionalValueEqualityEvidence", propositionalValueEvidence),
    ("proofDeclaration", toJson sourceProp), ("recursorRulesCompared", toJson comparedRules),
    ("instanceRegistryMatchesAcceptedGraph", toJson true),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("expectedIsInstance", toJson expectedInstance),
    ("universeOriginalOrder", Json.arr (sourceParams.toArray.map encodeName)),
    ("universeTargetOrder", Json.arr (target.levelParams.toArray.map encodeName)),
    ("targetToSourceUniverseIndices", match rel.permutation with | none => Json.null | some a => toJson a)]

-- Three source-backed generated-proof checks. No new Lean declaration is added
-- to the mathematical modules and no data Expr is replaced.
def checkedProofRecord (records : Array Json) (name : Name) : MetaM Json := do
  let resolvedRecords := records.filter fun row =>
    (stringField row "name").toOption == some name.toString
  unless resolvedRecords.size == 1 do throwError "Missing exact source proof record {name}"
  let record := resolvedRecords[0]!
  unless (← checked (decodeName (← checked (field record "nameExpr")))) == name do
    throwError "Source proof structural Name differs {name}"
  unless (← checked (stringField record "constantKind")) == "theorem" &&
      (← checked (record.getObjValAs? Bool "isProposition")) &&
      (← checked (arrayField record "levelParams")).isEmpty &&
      (← checked (arrayField record "binderInventory")).isEmpty do
    throwError "Expected closed monomorphic source literal proof {name}"
  return record

def resolveNativeGeneratedProof (name : Name) : MetaM Name := do
  let env ← getEnv
  let owner := `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22
  let resolvedNames := env.constants.fold (fun acc n _ =>
    if n.toString == name.toString && moduleOf env n == some owner then acc.push n else acc) (#[] : Array Name)
  unless resolvedNames.size == 1 && resolvedNames[0]! == name do
    throwError "Missing exact native generated proof Name/owner {name}"
  return resolvedNames[0]!

def certifyGeneratedProof (rs : Relocations) (allowed : Array Name)
    (record : Json) (target : Name) (role : String) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let target ← resolveNativeGeneratedProof target
  let ci ← getConstInfo target
  unless kind ci == "theorem" && ci.levelParams.isEmpty && (← isProp ci.type) do
    throwError "Expected closed native generated theorem {target}"
  -- The three actual source types use standard numeric constants only. This
  -- check prevents project aliases or data replacements from entering here.
  let sourceType ← checked (decodeExpr #[] (← checked (field record "elaboratedExpr")))
  for dep in sourceType.getUsedConstants do
    if projectName dep then throwError "Unexpected project operand in literal proof type {original}: {dep}"
  unless binderInventory sourceType == binderInventory ci.type &&
      binderPlacement sourceType == binderPlacement ci.type do
    throwError "Generated proof signature BinderInfo differs {original} / {target}"
  kernelTypeEq s!"source-backed generated proof type {original} / {target}" sourceType ci.type
  let targetAudit ← auditDeclaration rs allowed target
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    unless (← checked (field record key)) == (← checked (field targetAudit key)) do
      throwError "Source/native generated proof axiom closure differs {original} / {target}: {key}"
  return Json.mkObj [
    ("sourceEvidenceName", encodeName original), ("targetName", encodeName target),
    ("role", toJson role), ("sourceRecord", record), ("targetAudit", targetAudit),
    ("kernelTypeEqual", toJson true), ("axiomClosuresEqual", toJson true),
    ("signatureBinderInfoEqual", toJson true),
    ("rawNamespacePrefixNameEqual", toJson (target == `AbcAdaptation.Reference ++ original)),
    ("proofBodyEqualityClaimed", toJson false), ("dataValueSubstitution", toJson false),
    ("newMathematicalAliasCreated", toJson false)]

def boundSmallLiteralSource (compat : Json) : MetaM (Array Json) := do
  let binding ← checked (field compat "literalSourceBinding")
  let receipt ← jsonFile (← checked (stringField binding "receiptPath"))
  unless receipt == (← checked (field binding "receiptContents")) &&
      (← checked (stringField receipt "status")) == "succeeded" &&
      (← checked (stringField receipt "job_id")) == "ci-015877-23714e2c" do
    throwError "Actual original epsilonE proof export receipt differs"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
    throwError "Original literal proof export did not exit zero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do
    throwError "Original literal proof export workspace differs"
  unless (← checked (stringField binding "sourceExprSha256")).length == 64 do
    throwError "Missing exact small38 Expr SHA bound in target CI manifest"
  let source ← jsonFile (← checked (stringField binding "sourceExprFile"))
  unless (← checked (stringField source "schema")) == "foundation-original-exprs-v2" &&
      (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" &&
      (← checked (source.getObjValAs? Nat "recordCount")) == 38 do
    throwError "Unexpected actual original small38 source export"
  let exportConfig ← jsonFile (← checked (stringField binding "sourceExportConfigPath"))
  for key in #["inventorySha256", "graphSha256", "sources"] do
    unless (← checked (field source key)) == (← checked (field exportConfig key)) do
      throwError "Original literal proof source provenance differs {key}"
  let request ← checked (field receipt "request")
  let environment ← checked (field request "environment")
  unless (← checked (stringField environment "NEXT_CARRIER_EXPORT_CONFIG")) ==
      (← checked (stringField binding "sourceExportConfigPath")) do
    throwError "Original literal proof source receipt used another configuration"
  return ← checked (arrayField source "records")

def requireNativeGeneratedProofReceipt (compat : Json) : MetaM Unit := do
  let binding ← checked (field compat "nativeProofQueryBinding")
  if binding == Json.null then throwError "Pending actual native generated-proof query receipt"
  let receipt ← jsonFile (← checked (stringField binding "receiptPath"))
  unless receipt == (← checked (field binding "receiptContents")) &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Actual native generated-proof receipt differs or failed"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
    throwError "Native generated-proof query did not exit zero"
  let request ← checked (field receipt "request")
  let params ← checked (field request "parameters")
  unless (← checked (stringField params "source")) ==
      ".local/adaptation/c2-complete-inputs-20261116/QueryThresholdGeneratedProofs.lean" do
    throwError "Native generated-proof receipt checked another source"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do
    throwError "Native generated-proof query workspace differs"
  let manifest ← checked (field snapshot "manifest")
  unless (← checked (field manifest "source_sha256")) == (← checked (field binding "querySha256")) do
    throwError "Actual native generated-proof query source hash differs"


-- The source file is produced by the small existing Expr exporter, not by a
-- pretty-printer round trip. Source receipt binding is deliberately pending.
def auditPackageIdentity : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected native 4.33.1 audit"
  let cfg ← jsonFile (← absoluteEnv "PACKAGE_IDENTITY_AUDIT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "package-identity-config/v1" &&
      !(← checked (cfg.getObjValAs? Bool "publish")) do throwError "Unexpected small-supplier config"
  let binding ← checked (field cfg "sourceReceiptBinding")
  if binding == Json.null then throwError "Pending actual source Expr receipt/SHA binding"
  let receiptPath ← checked (stringField binding "receiptPath")
  let receipt ← jsonFile receiptPath
  unless receipt == (← checked (field binding "receiptContents")) &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Source receipt binding differs or is not successful"
  let sourceResult ← checked (field receipt "result")
  unless (← checked (sourceResult.getObjValAs? Nat "exit_code")) == 0 do
    throwError "Source export did not exit zero"
  let snap ← checked (field sourceResult "snapshot")
  unless (← checked (stringField snap "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snap "snapshot_id")) == Json.null do
    throwError "Source export workspace receipt differs"
  unless (← checked (stringField binding "sourceExprSha256")).length == 64 do
    throwError "Missing source Expr SHA binding; root must also list it in audit CI manifest"
  let exportBinding ← checked (field cfg "sourceExportConfig")
  let exportConfigPath ← checked (stringField exportBinding "path")
  let sourceCfg ← jsonFile exportConfigPath
  let req ← checked (field receipt "request")
  let sourceEnv ← checked (field req "environment")
  unless (← checked (stringField sourceEnv "NEXT_CARRIER_EXPORT_CONFIG")) == exportConfigPath do
    throwError "Source receipt used another export config"
  let source ← jsonFile (← checked (stringField cfg "sourceExprFile"))
  unless (← checked (stringField source "schema")) == "foundation-original-exprs-v2" &&
      (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" do
    throwError "Unexpected source Expr compiler/schema"
  for k in #["inventorySha256", "graphSha256", "sources"] do
    unless (← checked (field source k)) == (← checked (field sourceCfg k)) do
      throwError "Source Expr provenance differs {k}"
  let records ← checked (arrayField source "records")
  unless records.size == 44 &&
      (← checked (source.getObjValAs? Nat "recordCount")) == 44 &&
      (← checked (source.getObjValAs? Nat "selectedCount")) == 44 do
    throwError "Expected exactly selected44 full records"
  unless (← checked (arrayField cfg "standardRenames")).isEmpty &&
      (← checked (arrayField cfg "proofValueSubstitutions")).isEmpty do
    throwError "No compatibility substitution or standard rename is admitted"
  let compat ← checked (field cfg "generatedProofCompatibility")
  unless (← checked (stringField compat "schema")) == "c2-three-source-backed-generated-proofs/v1" do
    throwError "Unexpected generated-proof compatibility scope"
  unless (← checked (arrayField compat "dataValueSubstitutions")).isEmpty &&
      (← checked (arrayField compat "newAliases")).isEmpty do
    throwError "No data substitution or new alias is allowed"
  requireNativeGeneratedProofReceipt compat
  let literalRecords ← boundSmallLiteralSource compat
  let env ← getEnv
  let configured ← checked (arrayField cfg "projectMap")
  let prior ← checked (arrayField cfg "priorDependencies")
  unless configured.size == 44 && prior.size == 37 do throwError "Expected 44 pairs plus prior37 dependencies"
  let mut rs : Relocations := #[]
  let mut missing : Array String := #[]
  for row in configured ++ prior do
    let display ← checked (stringField row "original")
    let sourceMatches := records.filter fun r => (stringField r "name").toOption == some display
    let original ← if sourceMatches.size == 1 then
      checked (decodeName (← checked (field sourceMatches[0]! "nameExpr")))
    else do
      let deps ← checked (arrayField source "approvedDependencyFacts")
      let resolvedNames := deps.filter fun r => (stringField r "original").toOption == some display
      unless resolvedNames.size == 1 do throwError "Pending exact original dependency Name {display}"
      checked (decodeName (← checked (field resolvedNames[0]! "originalName")))
    let targetDisplay ← checked (stringField row "target")
    let owner := (← checked (stringField row "targetOwner")).toName
    let resolvedNames := env.constants.fold (fun acc n _ =>
      if n.toString == targetDisplay && moduleOf env n == some owner then acc.push n else acc) (#[] : Array Name)
    unless resolvedNames.size == 1 do
      missing := missing.push s!"{display} -> {targetDisplay}, expected owner {owner}, actual resolvedNames {resolvedNames.size}"
      continue
    let target := resolvedNames[0]!
    unless target == `AbcAdaptation.Reference ++ original do
      unless original == `Iut.Corollary22Inputs.threshold._proof_4 &&
          target == `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_6 do
        throwError "Pending generated relocation differs from exact namespace-prefix candidate {display}"
      let exception ← checked (field compat "exactRenamedOriginalProof")
      unless (← checked (stringField exception "original")) == original.toString &&
          (← checked (stringField exception "target")) == target.toString do
        throwError "Exact source-backed generated-proof rename configuration differs"
    if rs.any (fun r => r.original == original || r.target == target) then throwError "Duplicate Name pair {display}"
    let inst ← if sourceMatches.size == 1 then
      pure (some (← checked (row.getObjValAs? Bool "expectedIsInstance"))) else pure none
    let axs ← if sourceMatches.size == 1 then
      pure (some (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray) else pure none
    rs := rs.push ⟨original, target, none, inst, axs⟩
  unless missing.isEmpty do
    for msg in missing do logInfo s!"Pending target generated/source identity: {msg}"
    throwError "Pending {missing.size} missing/nonunique target source Names; no fallback map"
  let owners := #[`Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22,
    `Definitions.Def_AbcAdaptation_Reference_Genl_Mathlib_Order_BoundedDiscrepancy,
    `Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_HeightTheory,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection_HeightParts,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs]
  let standard := #[`Init, `Lean, `Std, `Mathlib, `Batteries, `Aesop, `Qq, `Plausible,
    `ProofWidgets, `ImportGraph, `Cli, `LeanSearchClient]
  let allowed := env.header.moduleNames.filter fun n => owners.contains n || standard.any (·.isPrefixOf n)
  let originalProof4 ← checkedProofRecord records `Iut.Corollary22Inputs.threshold._proof_4
  let renamedProofCertificate ← certifyGeneratedProof rs allowed originalProof4
    `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_6 "one exact original generated-proof rename"
  let sourceLiteral2 ← checkedProofRecord literalRecords `Iut.epsilonE._proof_2
  let sourceLiteral60 ← checkedProofRecord literalRecords `Iut.epsilonE._proof_1
  let targetProof4 ← resolveNativeGeneratedProof `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_4
  let targetProof5 ← resolveNativeGeneratedProof `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_5
  let extra2Certificate ← certifyGeneratedProof rs allowed sourceLiteral2 targetProof4
    "target-only generated proof backed by actual original epsilonE literal2 proof; no named identity"
  let extra60Certificate ← certifyGeneratedProof rs allowed sourceLiteral60 targetProof5
    "target-only generated proof backed by actual original epsilonE literal60 proof; no named identity"
  let certifiedGeneratedProofs := #[targetProof4, targetProof5]
  let extraRows ← checked (arrayField compat "targetOnlyGeneratedProofs")
  unless extraRows.size == 2 do throwError "Expected exactly two source-backed target-only generated proofs"
  for row in extraRows do
    let sourceDisplay ← checked (stringField row "sourceEvidence")
    let targetDisplay ← checked (stringField row "target")
    unless !(← checked (row.getObjValAs? Bool "namedIdentityClaimed")) &&
        ((sourceDisplay == "Iut.epsilonE._proof_2" && targetDisplay == targetProof4.toString) ||
         (sourceDisplay == "Iut.epsilonE._proof_1" && targetDisplay == targetProof5.toString)) do
      throwError "Unexpected source-backed target-only proof configuration"
  let actualTargetClosure := env.constants.fold (fun acc n _ =>
    if moduleOf env n == some `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22 &&
        ((`AbcAdaptation.Reference.Iut.Corollary22Inputs).isPrefixOf n ||
         (`AbcAdaptation.Reference.Iut.ThetaDataExistence).isPrefixOf n) &&
        !(`AbcAdaptation.Reference.Iut.Corollary22Inputs.c2).isPrefixOf n then acc.push n else acc) (#[] : Array Name)
  let configuredTargets ← configured.mapM fun row => do
    let originalDisplay ← checked (stringField row "original")
    let sourceRecord := records.find? fun r => (stringField r "name").toOption == some originalDisplay
    let some sourceRecord := sourceRecord | throwError "Missing actual configured source Name {originalDisplay}"
    let original ← checked (decodeName (← checked (field sourceRecord "nameExpr")))
    let some rel := rs.find? (·.original == original) | throwError "Missing configured target Name {original}"
    pure rel.target
  unless actualTargetClosure.size == 46 && configuredTargets.size == 44 &&
      actualTargetClosure.all (fun n => configuredTargets.contains n || certifiedGeneratedProofs.contains n) do
    throwError "Actual target C2/P7 closure differs from original44 plus the two certified generated proofs"
  let mut comparisons := #[]
  let mut rawNameObservations := #[]
  let mut completeValueCertificateCount := 0
  let mut targetAudits := #[]
  let mut rootCount := 0
  let roots ← checked (cfg.getObjValAs? (Array String) "mathematicalRoots")
  let mut seen : Array Name := #[]
  for record in records do
    let original ← checked (decodeName (← checked (field record "nameExpr")))
    if seen.contains original then throwError "Duplicate exported original Name {original}"
    seen := seen.push original
    let some rel := rs.find? (·.original == original) | throwError "Missing configured source Name {original}"
    if roots.contains original.toString then rootCount := rootCount + 1
    if original == `Iut.Corollary22Inputs then
      let structureInfo ← checked (field record "structure")
      let actualFields ← checked (structureInfo.getObjValAs? (Array String) "fieldsInConstructorOrder")
      unless actualFields == #["h", "localData", "localData_height", "localData_deg_le", "htCan_equiv", "northcott", "B", "B_nonneg", "heightEq_two_le", "HasCyclicSubgroup", "TK", "cyclic_bound", "SL2Image", "sl2_of", "excCore", "excCore_finite"] do
        throwError "Complete original field order/types required for Iut.Corollary22Inputs"
    if original == `Iut.ThetaDataExistence then
      let structureInfo ← checked (field record "structure")
      let actualFields ← checked (structureInfo.getObjValAs? (Array String) "fieldsInConstructorOrder")
      unless actualFields == #["thetaData"] do
        throwError "Complete original field order/types required for Iut.ThetaDataExistence"
    let target ← getConstInfo rel.target
    let certificate ← checked (field cfg "casesOnWholeValueCertificate")
    let comparison ← compareRecord rs allowed record target (some certificate)
    if original == `Iut.ThetaDataExistence.casesOn then
      unless (← checked (comparison.getObjValAs? Bool "kernelPropositionalValueEquality")) &&
          !(← checked (comparison.getObjValAs? Bool "kernelValueEqual")) &&
          !(← checked (comparison.getObjValAs? Bool "allExpressionBinderInfoEqual")) do
        throwError "Exact casesOn certificate result lost its raw-false flags"
      completeValueCertificateCount := completeValueCertificateCount + 1
    comparisons := comparisons.push comparison
    rawNameObservations := rawNameObservations.push (Json.mkObj [
      ("originalName", encodeName original), ("targetName", encodeName target.name),
      ("rawNamespacePrefixNameEqual", toJson (target.name == `AbcAdaptation.Reference ++ original)),
      ("exactGeneratedProofRenameUsed", toJson (original == `Iut.Corollary22Inputs.threshold._proof_4))])
    targetAudits := targetAudits.push (← auditDeclaration rs allowed target.name certifiedGeneratedProofs)
  unless comparisons.size == 44 && rootCount == 3 && completeValueCertificateCount == 1 do
    throwError "Incomplete44 comparisons or exact one-declaration value certificate"
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema", toJson "package-kernel-identity-result/v1"),
    ("compilerVersion", toJson Lean.versionString), ("sourceCompilerVersion", toJson "4.35.0-rc3"),
    ("publish", toJson false), ("publishAllowed", toJson false), ("finalAcceptance", toJson false), ("sourceReceiptBinding", binding),
    ("configuration", cfg), ("rootCount", toJson rootCount),
    ("comparedRecordCount", toJson comparisons.size), ("comparisons", Json.arr comparisons),
    ("targetAxiomAudits", Json.arr targetAudits), ("unresolvedTargetNames", Json.arr #[]),
    ("compatibilitySubstitutions", Json.arr #[]), ("hasSorryAx", toJson false),
    ("rawNamespacePrefixIdentity", toJson false),
    ("rawNameIdentityObservations", Json.arr rawNameObservations),
    ("sourceBackedGeneratedProofRename", renamedProofCertificate),
    ("sourceBackedTargetOnlyGeneratedProofs", Json.arr #[extra2Certificate, extra60Certificate]),
    ("targetGeneratedClosureCount", toJson actualTargetClosure.size),
    ("sourceGeneratedClosureCount", toJson configuredTargets.size),
    ("newMathematicalAliases", Json.arr #[]), ("dataValueSubstitutions", Json.arr #[]),
    ("generatedProofCompatibility", compat),
    ("sourceBackedWholeValueEqualityCertificateCount", toJson completeValueCertificateCount),
    ("wholeValueEqualityCertificateScope", toJson "only Iut.ThetaDataExistence.casesOn"),
    ("rawAllComputationalValueBinderInfoEqual", toJson false),
    ("casesOnWholeValueCertificateBinding", ← checked (field cfg "casesOnWholeValueCertificate")),
    ("scope", toJson "Complete original Corollary22Inputs and ThetaDataExistence commands, full16+1 fields, threshold and generated API. Original c2 theorem and its helper commands excluded. Dependencies are Name-relocated only; their independent formal gates stay unchanged.")]).compress ++ "\n")

end FoundationAudit
syntax (name := auditPackageUnit) "audit_package_unit" : command
@[command_elab auditPackageUnit] def elabAuditPackageUnit : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.auditPackageIdentity

audit_package_unit
