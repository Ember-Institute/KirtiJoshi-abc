/- Adaptation draft from the exact accepted source AST. Original notice retained below. Mathematical types and definition bodies are unchanged; the selected Open proof is explicitly sorry. No acceptance or publication is claimed. -/
/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants

namespace AbcAdaptation.Reference


set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3

namespace Iut

universe u v

open NumberField

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}

namespace Corollary312VariantData

variable (X : Corollary312VariantData.{u, v} AG TG)

lemma one_le_dmod : 1 ≤ X.dmod := by
  sorry

end Corollary312VariantData

end Iut

end AbcAdaptation.Reference
