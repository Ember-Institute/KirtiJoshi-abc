/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Exact source proof adaptation candidate. Source: Iut/Implication/Invariants.lean#L172-L173.
The original binder and proof term are retained. No source or platform acceptance is claimed. -/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
open AbcAdaptation.Reference.Iut
open AbcAdaptation.Reference.Iut.Theorem110Invariants
universe u v

theorem AbcAdaptation.Reference.Iut.Theorem110Invariants.logSle_nonneg_NativeAuditProof {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
    {X : Corollary312VariantData.{u, v} AG TG}
    (inv : Theorem110Invariants X) :
    0 ≤ inv.logSle :=
  Finset.sum_nonneg fun p _ => by
    unfold ι
    split_ifs <;> norm_num
