lemma logSQ_nonneg : 0 ≤ inv.logSQ :=
  Finset.sum_nonneg fun p hp => Real.log_nonneg (by exact_mod_cast (inv.dst_prime p hp).one_lt.le)
