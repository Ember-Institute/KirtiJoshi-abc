**English**

Fix the initial data, invariant record, arithmetic certificate, local estimates and prime-counting bound in the statement. Write $Q=\log(q)$, $D=\log(d_{F_{\mathrm{tpd}}})+\log(f_{F_{\mathrm{tpd}}})$, $e^*=552960e_{\mathrm{mod}}$ and $\eta=\eta_{\mathrm{prm}}$. The asserted inequality is

$$\frac{Q}{6}\leq\left(1+\frac{20d_{\mathrm{mod}}}{\ell}\right)D+20(e^*\ell+\eta).$$

The reduction uses the open child `LocalEstimate.rhs_le`, which bounds the right-hand volume expression by the average of the local bounds over the standard increasing family of label sets. Set $L=(\ell-1)/2$. The standard-family sum identities evaluate the linear and quadratic label contributions; grouping the finite-place terms by residue characteristic recovers $Q$ and the three invariant sums. Combining that upper bound with the supplied Corollary 3.12 inequality gives the numerical inequality needed by the assembly lemma.

The arithmetic certificate supplies the different and distinguished-prime estimates. The accepted prime-counting lemma bounds the indicator sum, and the remaining nonnegative terms and logarithm bounds discharge the assembly hypotheses. The input certificate, local estimates and Corollary 3.12 hypothesis remain exactly the explicit assumptions of the target. This submission is a reduction to the open child, with the other imported helper theorems already proved; it does not construct those input records.

**简体中文**

固定陈述中的初始资料、不变量记录、算术证书、局部估计和素数计数界。记 $Q=\log(q)$、$D=\log(d_{F_{\mathrm{tpd}}})+\log(f_{F_{\mathrm{tpd}}})$、$e^*=552960e_{\mathrm{mod}}$、$\eta=\eta_{\mathrm{prm}}$。目标不等式为

$$\frac{Q}{6}\leq\left(1+\frac{20d_{\mathrm{mod}}}{\ell}\right)D+20(e^*\ell+\eta).$$

归约使用开放子节点 `LocalEstimate.rhs_le`，它用标准标签集递增族上的局部界平均值控制右侧体积表达式。令 $L=(\ell-1)/2$，利用标准递增族的求和恒等式计算标签数的一次项和二次项，再按剩余特征归并有限处的项，得到 $Q$ 和三个不变量之和。将此上界与给定的推论 3.12 不等式结合，就得到数值组合引理所需的不等式。

算术证书提供不同理想及区分素数的估计；已证明的素数计数引理控制指标函数之和，其余非负性和对数界满足数值组合引理的假设。目标原有的证书、局部估计和推论 3.12 假设均保留为显式输入。本提交归约到上述开放子节点，其余导入的辅助定理已有证明；它不构造这些输入记录。

**日本語**

命題に現れる初期データ、不変量のレコード、算術的証明書、局所評価および素数計数評価を固定する。$Q=\log(q)$、$D=\log(d_{F_{\mathrm{tpd}}})+\log(f_{F_{\mathrm{tpd}}})$、$e^*=552960e_{\mathrm{mod}}$、$\eta=\eta_{\mathrm{prm}}$ と置く。示す不等式は

$$\frac{Q}{6}\leq\left(1+\frac{20d_{\mathrm{mod}}}{\ell}\right)D+20(e^*\ell+\eta)$$

である。帰着に用いる未解決の子命題 `LocalEstimate.rhs_le` は、右辺の体積を標準的なラベル集合の増大族に沿う局所評価の平均で上から評価する。$L=(\ell-1)/2$ と置き、標準的な増大族の和の恒等式によってラベル数の一次項と二次項を計算する。有限素点の項を剰余標数ごとにまとめると、$Q$ と三つの不変量の和が得られる。この上界と仮定された系3.12の不等式を組み合わせ、数値的な組合せ補題に必要な不等式を得る。

算術的証明書は差積イデアルと区別された素数に関する評価を与える。既証明の素数計数補題で指示関数の和を評価し、非負性と対数の評価によって残りの仮定を満たす。証明書、局所評価、系3.12は元の命題の明示的な仮定として残る。この提出は上記の未解決の子命題への帰着であり、他の導入された補助定理は既証明である。入力レコードの構成を主張するものではない。
