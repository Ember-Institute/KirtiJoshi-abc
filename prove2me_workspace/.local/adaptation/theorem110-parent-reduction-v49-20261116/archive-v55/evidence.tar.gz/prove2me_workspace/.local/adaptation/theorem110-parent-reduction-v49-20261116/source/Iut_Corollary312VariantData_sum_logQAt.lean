/-- `log(q)` is the sum of its residue-characteristic components over any finite set of
primes containing the residue characteristics of the bad places. -/
lemma sum_logQAt {s : Finset ℕ} (hbad : ∀ w ∈ X.qPilot.badFinset, residueChar w ∈ s) :
    ∑ p ∈ s, X.logQAt p = X.qPilot.logQ := by
  unfold logQAt QPilotData.logQ
  exact Finset.sum_fiberwise_of_maps_to (fun w _ => hbad w.1 w.2) _
