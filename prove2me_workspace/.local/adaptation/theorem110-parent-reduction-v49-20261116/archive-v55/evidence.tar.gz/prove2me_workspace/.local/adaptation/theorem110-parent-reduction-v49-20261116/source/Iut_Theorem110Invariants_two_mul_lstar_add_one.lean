/-- `ℓ = 2·ℓ* + 1`: the prime `ℓ ≥ 5` is odd. -/
lemma two_mul_lstar_add_one : 2 * X.lstar + 1 = X.ℓ := by
  have hodd : Odd X.ℓ :=
    X.data.prime.ℓ_prime.odd_of_ne_two (by have := X.data.prime.five_le; omega)
  obtain ⟨k, hk⟩ := hodd
  simp only [Corollary312VariantData.lstar, Corollary312VariantData.ℓ] at hk ⊢
  omega
