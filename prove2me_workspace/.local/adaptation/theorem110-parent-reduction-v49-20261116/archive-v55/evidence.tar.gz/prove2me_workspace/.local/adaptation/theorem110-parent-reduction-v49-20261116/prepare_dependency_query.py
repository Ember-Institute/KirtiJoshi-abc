from pathlib import Path
import json,hashlib
P=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/theorem110-parent-reduction-v49-20261116')
deps=json.loads((P/'dependencies.json').read_text())
rows=[{'name':x['name'],'status':'ACCEPTED','theoremId':x['platform']['theorem_id']} for x in deps['acceptedClosedPlatformHelpers']]+[{'name':deps['semanticOpenChildren'][0]['name'],'status':'Open','theoremId':None}]
cfg={'schema':'theorem110-parent-reduction-dependency-audit/v46','expectedCompiler':'4.33.1','root':'solution','rootModule':'Solutions.Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110','forbiddenParent':'AbcAdaptation.Reference.Iut.Theorem110Invariants.theorem110','openChild':rows[-1]['name'],'publicProofs':rows,'outputFile':str(P/'actual/dependency-audit.json')}
(P/'queries').mkdir(exist_ok=True);(P/'actual').mkdir(exist_ok=True)
(P/'queries/dependency-audit.config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
(P/'queries/QueryTheorem110ReductionDependencies.lean').write_text(r'''import Lean
import Solutions.Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110

namespace Theorem110ReductionDependencies
open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let i ← env.getModuleIdxFor? name
  return (← env.header.modules[i.toNat]?).module

def valueOf (ci : ConstantInfo) : Option Expr :=
  match ci with
  | .thmInfo i => some i.value
  | .defnInfo i => some i.value
  | .opaqueInfo i => some i.value
  | _ => none

run_meta do
  let some cfgPath ← IO.getEnv "THEOREM110_REDUCTION_AUDIT_CONFIG"
    | throwError "Missing THEOREM110_REDUCTION_AUDIT_CONFIG"
  unless cfgPath.startsWith "/" do throwError "Expected absolute configuration path"
  let cfg ← checked (Json.parse (← IO.FS.readFile cfgPath))
  unless (← checked (cfg.getObjValAs? String "schema")) == "theorem110-parent-reduction-dependency-audit/v46" do
    throwError "Wrong dependency audit schema"
  unless Lean.versionString == (← checked (cfg.getObjValAs? String "expectedCompiler")) do
    throwError "Wrong compiler version"
  let root := (← checked (cfg.getObjValAs? String "root")).toName
  let ownModule := (← checked (cfg.getObjValAs? String "rootModule")).toName
  let forbidden := (← checked (cfg.getObjValAs? String "forbiddenParent")).toName
  let openChild := (← checked (cfg.getObjValAs? String "openChild")).toName
  let allowed ← checked (cfg.getObjValAs? (Array Json) "publicProofs")
  let env ← getEnv
  let ci ← getConstInfo root
  unless moduleOf env root == some ownModule do throwError "Wrong solution module"
  let some value := valueOf ci | throwError "Missing solution proof"
  let mut queue := #[root]
  let mut doneNames : Array Name := #[]
  let mut importedProofRows : Array Json := #[]
  let mut privateRows : Array Json := #[]
  let mut referenced : Array Name := #[]
  let mut i := 0
  while i < queue.size do
    let n := queue[i]!
    i := i + 1
    unless doneNames.contains n do
      doneNames := doneNames.push n
      let info ← getConstInfo n
      let some proof := valueOf info | throwError "Missing own-module proof {n}"
      -- Every local auxiliary/root is checked without sorryAx; admitted dependencies
      -- are allowed only through the imported public theorem registry below.
      if proof.getUsedConstants.contains `sorryAx do throwError "Direct sorryAx in local proof {n}"
      let used := proof.getUsedConstants
      privateRows := privateRows.push (Json.mkObj [
        ("name",toJson n.toString),("proofDirectConstants",toJson (used.map Name.toString))])
      for dep in used do
        if dep == forbidden do throwError "Parent theorem occurs in its own reduction"
        unless referenced.contains dep do referenced := referenced.push dep
        if moduleOf env dep == some ownModule then
          unless queue.contains dep do queue := queue.push dep
        else if let some owner := moduleOf env dep then
          if owner.toString.startsWith "Theorems." then
            let some row := allowed.find? (fun row =>
              (row.getObjValAs? String "name").toOption == some dep.toString)
              | throwError "Unclassified public theorem dependency: {dep} from {owner}"
            unless importedProofRows.contains row do importedProofRows := importedProofRows.push row
  unless referenced.contains openChild do throwError "The supplied Open child is not consumed"
  let telescope ← forallTelescope ci.type fun xs result => do
    let bs ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name",toJson d.userName.toString),
        ("binderInfo",toJson (reprStr d.binderInfo)),
        ("type",toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders",Json.arr bs),("result",toJson (← ppExpr result).pretty)]
  let axs ← collectAxioms root
  let result := Json.mkObj [
    ("schema",toJson "theorem110-parent-reduction-dependency-facts/v46"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("root",toJson root.toString),("telescope",telescope),
    ("type",toJson (← ppExpr ci.type).pretty),
    ("ownModuleProofs",Json.arr privateRows),
    ("importedTheoremDependencies",Json.arr importedProofRows),
    ("parentTheoremReferenceAbsent",toJson true),
    ("openChildConsumed",toJson true),
    ("allOwnModuleProofBodiesDirectSorryFree",toJson true),
    ("localAxiomClosure",toJson ((axs.qsort Name.lt).map Name.toString)),
    ("localSorryClosureIsNotPlatformStatus",toJson true)]
  IO.FS.writeFile (← checked (cfg.getObjValAs? String "outputFile")) (result.pretty ++ "\n")
  logInfo "Theorem110 parent reduction dependencies classified; Open child consumed"
end Theorem110ReductionDependencies
''')
# Add the uncompiled validation entry to the existing handoff docs without touching source input.
p=P/'README.zh.md';s=p.read_text();s+='\n`queries/QueryTheorem110ReductionDependencies.lean` 和配置另备编译后依赖审查：展开同模块 private proofs，拒绝直接 sorryAx、父 theorem110 自引用及未分类公开 theorem 依赖；要求实际消费 rhs_le，输出八参数 telescope 与本地公理闭包。使用结构化环境 `THEOREM110_REDUCTION_AUDIT_CONFIG` 传入绝对配置路径。此查询也未编译。\n';p.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=[]
for p in sorted(P.rglob('*')):
 if p.is_file() and p.name!='artifact-manifest.json':files.append({'path':str(p.relative_to(P)),'sha256':sha(p),'bytes':p.stat().st_size})
m={'schema':'theorem110-parent-reduction-manifest/v46','packetRoot':str(P),'files':files,'sourceCommit':'07cb1da58f6d428a670dbb5dd6093d428bcbcdd8','compiled':False,'mainWorkspaceWritten':False}
(P/'artifact-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print('manifest SHA256 '+sha(P/'artifact-manifest.json'))
