/-- Step (v), the sum over the capsules of the standard procession of the local bound at
a distinguished prime `p`, via (E1) and (E2). -/
lemma sum_capsuleBound (L : ℕ) (p : ℕ) :
    ∑ i : Fin L, inv.capsuleBound (i + 2) p =
      (inv.logDK p + 4 * inv.lmod * inv.ι p) * (L * (L + 3) / 2) -
        X.logQAt p / (2 * X.ℓ) * (L * (L + 1) * (2 * L + 1) / 6) + Real.log p * L := by
  calc ∑ i : Fin L, inv.capsuleBound (i + 2) p
      = ∑ i : Fin L, ((inv.logDK p + 4 * inv.lmod * inv.ι p) * ((i : ℝ) + 2) +
          (-(X.logQAt p / (2 * X.ℓ))) * ((i : ℝ) + 1) ^ 2 + Real.log p) :=
        Finset.sum_congr rfl fun i _ => by unfold capsuleBound; push_cast; ring
    _ = _ := by rw [sum_affine_quadratic]; ring
