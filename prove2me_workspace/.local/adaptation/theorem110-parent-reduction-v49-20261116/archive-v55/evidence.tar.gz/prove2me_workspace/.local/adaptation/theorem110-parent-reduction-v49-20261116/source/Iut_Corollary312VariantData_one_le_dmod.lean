lemma one_le_dmod : 1 ≤ X.dmod :=
  Module.finrank_pos
