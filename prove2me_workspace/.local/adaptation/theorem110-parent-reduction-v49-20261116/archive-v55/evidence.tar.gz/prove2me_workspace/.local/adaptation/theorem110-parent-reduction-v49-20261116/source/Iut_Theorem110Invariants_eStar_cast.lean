lemma eStar_cast : (inv.eStar : ℝ) = 552960 * inv.emod := by
  simp only [eStar]; push_cast; ring
