from pathlib import Path
import json,hashlib,shutil,re,difflib
P=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/theorem110-parent-reduction-v49-20261116');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';G=A/'main-chain-open-20261116/tools/generated'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); bh=lambda s:hashlib.sha256(s.encode()).hexdigest()
def write(rel,x):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p,rel=None):
 p=Path(p);d={'path':str(p),'sha256':sha(p)}
 if rel:
  out=P/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out);d['frozenCopy']=str(out)
 return d
reg=json.loads((A/'platform-node-registry.json').read_text());proved={x['name']:x for x in reg['reference_source_preparation']['proved_nodes']}
# All imported public helpers below have an ACCEPTED registry record. These paths are the actual current canonical files.
helpers=[('Iut.assembly','Thm_AbcAdaptation_Reference_Iut_assembly.lean'),('Iut.log_pi_le_two','Thm_AbcAdaptation_Reference_Iut_log_pi_le_two.lean'),('Iut.sum_affine_quadratic','Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean'),('Iut.Theorem110Invariants.sum_arch','Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_arch.lean'),('Iut.Theorem110Invariants.sum_card_standard','Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_card_standard.lean'),('Iut.Theorem110Invariants.lmod_mul_logSle_le','Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_lmod_mul_logSle_le.lean'),('Iut.Theorem110Invariants.iota_nonneg','Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_iota_nonneg.lean')]
accepted=[]
for short,file in helpers:
 name='AbcAdaptation.Reference.'+short;row=proved[name];assert row['verification_status']=='ACCEPTED';p=W/'Theorems'/file
 accepted.append({'name':name,'module':'Theorems.'+p.stem,'canonicalFile':pin(p,'frozen-imports/Theorems/'+file),'platform':row,'localCanonicalFileContainsSorry':bool(re.search(r'\bsorry\b',p.read_text())),'sourceRole':'closed platform proof dependency, not an additional open semantic cut'})
openfile=W/'Theorems/Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_LocalEstimate_rhs_le.lean'
openrow={'name':'AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.rhs_le','module':'Theorems.'+openfile.stem,'canonicalFile':pin(openfile,'frozen-imports/Theorems/'+openfile.name),'status':'Open; publication job pending as supplied by main task','typeBinderInfoAuditJob':'ci017830 (task instruction; no receipt read by subagent)','publicationJobId':'fe24b947-fc7e-4f2f-8ba3-baec32b156cb','semanticRole':'the only new open mathematical dependency in this parent reduction'}
notice='''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Parent reduction candidate for the exact theorem110 statement. Complete source
proof body retained. Internal auxiliary proofs are private; accepted public helpers
are imported by their real canonical modules. The only new semantic open child is
LocalEstimate.rhs_le. This draft has not been compiled or submitted. -/
'''
mods=['Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound']+[x['module'] for x in accepted]+[openrow['module']]+[
'Mathlib.Algebra.BigOperators.Ring.Finset','Mathlib.Analysis.Real.Pi.Bounds','Mathlib.Analysis.SpecialFunctions.Log.Basic','Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic','Mathlib.Data.Fintype.BigOperators','Mathlib.LinearAlgebra.Dimension.Finrank','Mathlib.Tactic.FieldSimp','Mathlib.Tactic.Linarith','Mathlib.Tactic.NormNum','Mathlib.Tactic.Omega','Mathlib.Tactic.Positivity','Mathlib.Tactic.Ring']
# No parent target import and no Solutions import: this is a proof candidate, not a cycle through its own stub.
pre=notice+''.join('import '+m+'\n' for m in mods)+'''
set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
open NumberField
open AbcAdaptation.Reference.Iut
open AbcAdaptation.Reference.Iut.Theorem110Invariants
universe u v

'''
blocks=[];maps=[]
def private_source(source_name, namespace, varheader, replacement=None):
 stem=source_name.replace('.','_');mp=G/'metadata'/(stem+'.json');sp=G/'OriginalCommands'/(stem+'.lean');s=sp.read_text();md=json.loads(mp.read_text());adapted=s.replace('lemma ','private lemma ',1)
 edits=[{'kind':'visibility','before':'lemma','after':'private lemma','purpose':'Internal complete auxiliary; no extra public mathematical node'}]
 if replacement:
  for a,b in replacement:
   assert a in adapted;adapted=adapted.replace(a,b);edits.append({'kind':'proof-reference-rename','before':a,'after':b,'purpose':'Use accepted canonical ASCII identifier; no alias wrapper introduced'})
 block='namespace '+namespace+'\n\n'+varheader+'\n\n'+adapted+'\nend '+namespace+'\n\n';blocks.append(block)
 origbody=s.split(':=',1)[1];newbody=adapted.split(':=',1)[1]
 source=pin(sp,'source/'+stem+'.lean');meta=pin(mp,'source/'+stem+'.metadata.json')
 maps.append({'sourceName':source_name,'sourceCommand':source,'sourceMetadata':meta,'sourceModule':md['module'],'sourceRange':md['originalRange'],'sourceBodyRanges':md['proofAndDefinitionBodyRanges'],'sourceBodyHashesFromParser':md['originalBodyHashes'],'targetSpelling':'private '+namespace+'.'+source_name.split('.')[-1],'targetHeaderContext':varheader,'edits':edits,'sourceBodySHA256AfterColonEquals':bh(origbody),'adaptedBodySHA256AfterColonEquals':bh(newbody),'proofBodyByteIdenticalAfterColonEquals':origbody==newbody,'originalCommandSHA256':sha(sp),'adaptedPrivateCommandSHA256':bh(adapted)})
 return adapted
ag='variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}'
xexp=ag+'\nvariable (X : Corollary312VariantData.{u, v} AG TG)'
xinv=ag+'\nvariable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)'
for n in ['one_le_dmod','logQAt_nonneg','sum_logQAt']:
 private_source('Iut.Corollary312VariantData.'+n,'AbcAdaptation.Reference.Iut.Corollary312VariantData',xexp)
for n in ['eStar_cast','logSle_nonneg','logSQ_nonneg','logDKtot_nonneg','two_mul_lstar_add_one','sum_capsuleBound']:
 private_source('Iut.Theorem110Invariants.'+n,'AbcAdaptation.Reference.Iut.Theorem110Invariants',xinv, [('inv.ι_nonneg p','inv.iota_nonneg p')] if n=='logSle_nonneg' else None)
# This source auxiliary is not a frontier node. Retain it locally with a private visibility change only.
raw='lemma log_pi_nonneg : 0 ≤ Real.log Real.pi :=\n  Real.log_nonneg (by linarith [Real.pi_gt_three])\n'
source_context=G/'SourceContextModules/AbcSourceOracle/Context/Theorem110.lean'
sct=source_context.read_text();assert raw.rstrip() in sct
privatepi=raw.replace('lemma ','private lemma ',1)
blocks.insert(0,'namespace AbcAdaptation.Reference.Iut\n\n'+privatepi+'\nend AbcAdaptation.Reference.Iut\n\n')
maps.insert(0,{'sourceName':'Iut.log_pi_nonneg','sourceModule':'Iut.Implication.Theorem110','sourceRange':{'start':{'line':75,'col':0},'end':{'line':76,'col':50}},'sourceContext':pin(source_context,'source/Theorem110SourceContext.lean'),'sourceExactCommand':raw,'targetExactCommand':privatepi,'proofBodyByteIdenticalAfterColonEquals':True,'sourceBodySHA256AfterColonEquals':bh(raw.split(':=',1)[1]),'adaptedBodySHA256AfterColonEquals':bh(privatepi.split(':=',1)[1]),'edits':[{'kind':'visibility','before':'lemma','after':'private lemma'}]})
rootstem='Iut_Theorem110Invariants_theorem110';rootsource=G/'OriginalCommands'/(rootstem+'.lean');rootmd=json.loads((G/'metadata'/(rootstem+'.json')).read_text());rs=rootsource.read_text();rootbody=rs.split(':=',1)[1];assert rootbody.startswith(' by\n')
# Exact parent type is copied from the already prepared eight-binder stub; only declaration binding is solution.
currentstub=W/'Theorems/Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110.lean';stub=currentstub.read_text();formal=stub[stub.index('theorem AbcAdaptation.Reference.Iut.Theorem110Invariants.theorem110'):];header=formal.split(':=',1)[0].replace('theorem AbcAdaptation.Reference.Iut.Theorem110Invariants.theorem110','theorem solution',1)
solution=header+':='+rootbody
content=pre+''.join(blocks)+solution
out='solution/Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110.lean';write(out,content)
write('solution/proof.lean.txt',rootbody.lstrip())
write('source/root-source.json',{'source':pin(rootsource,'source/'+rootstem+'.lean'),'sourceMetadata':pin(G/'metadata'/(rootstem+'.json'),'source/'+rootstem+'.metadata.json'),'sourceRange':rootmd['originalRange'],'sourceBodyRanges':rootmd['proofAndDefinitionBodyRanges'],'sourceParserBodyHashes':rootmd['originalBodyHashes'],'sourceBodySHA256AfterColonEquals':bh(rootbody),'targetBodySHA256AfterColonEquals':bh(solution.split(':=',1)[1]),'rootProofBodyByteIdenticalAfterColonEquals':True,'inheritedParentStub':pin(currentstub,'source/ParentExactStub.lean'),'parentHeaderAdaptation':'Exact inherited eight-binder header copied; only theorem declaration binding changed to solution. No target or child parameters added.'})
# Add actual generated solution line locations, and preserve all ten original source proof commands.
for row in maps:
 short=row['sourceName'].split('.')[-1];needle='private lemma '+short
 pos=content.index(needle);row['targetDeclarationLine']=content.count('\n',0,pos)+1
write('private-source-map.json',maps)
# Record exact byte-change for the canonical spelling adaptation.
changed=[x for x in maps if x.get('proofBodyByteIdenticalAfterColonEquals') is False];assert len(changed)==1 and changed[0]['sourceName'].endswith('.logSle_nonneg')
write('adaptation-differences.json',{'schema':'theorem110-parent-reduction-differences/v46','namespace':'Iut → AbcAdaptation.Reference.Iut','rootBinding':'theorem110 → solution (solution-file entry point)','rootProofBodyByteIdenticalAfterColonEquals':True,'parentEightBinderTypePreservedTextually':True,'privateAuxiliaryCount':len(maps),'privateProofBodiesByteIdenticalExcept':['Iut.Theorem110Invariants.logSle_nonneg'],'changedPrivateProof':changed,'identifierAdaptation':{'source':'Iut.Theorem110Invariants.ι_nonneg','canonicalTarget':'AbcAdaptation.Reference.Iut.Theorem110Invariants.iota_nonneg','reason':'Already ACCEPTED platform-compatible ASCII identifier','noExtraAliasDeclaration':True},'imports':'Only current published Definition wrapper, actual canonical ACCEPTED theorem helper files, sole Open rhs_le child, and named Mathlib modules. No import of parent theorem110 stub or source Iut modules.','sourceProofNotClaimedWholeFileByteIdentical':'Private declaration visibility, namespace/context, imports, and one helper proof-reference spelling differ. Root main proof body is byte-identical.','uncompiled':True})
write('dependencies.json',{'schema':'theorem110-parent-reduction-dependencies/v46','registry':pin(A/'platform-node-registry.json'),'semanticOpenChildren':[openrow],'acceptedClosedPlatformHelpers':accepted,'privateClosedSourceHelpers':[x['sourceName'] for x in maps],'parentOriginalExplicitInputs':['inv : Theorem110Invariants X','cert : Theorem110Certificate inv','est : inv.LocalEstimate','pnt : PrimeCountingBound','h312 : Corollary312Variant X'],'noNewMathematicalParameters':True,'localSorryAxExplanation':'Only imported rhs_le is a new semantic Open child. Canonical local assembly/log_pi_le_two files also contain sorry while their platform records are ACCEPTED. A local #print axioms solution can therefore include sorryAx; do not claim a closed kernel theorem from this local file alone. Platform dependency checking must distinguish the accepted closed records from the Open child.','publicImports':mods,'runtimeDependencyExtractionStatus':'Pending compiled dependency query; this list is source-text/reference analysis, not an inspected proof-term receipt.'})
# Static import closure: ensure parent theorem file or any source module cannot occur through local imports.
visited=set();queue=[(m,W/(m.replace('.','/')+'.lean')) for m in mods if m.startswith(('Theorems.','Definitions.'))];closure=[]
forbidden='Theorems.Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110'
while queue:
 mod,p=queue.pop(0)
 if mod in visited:continue
 assert mod!=forbidden;visited.add(mod);assert p.exists();text=p.read_text();closure.append({'module':mod,'path':str(p),'sha256':sha(p)})
 for child in re.findall(r'^import\s+(\S+)',text,re.M):
  assert not child.startswith('Iut.')
  if child.startswith(('Theorems.','Definitions.','Solutions.')):queue.append((child,W/(child.replace('.','/')+'.lean')))
assert not re.search(r'\b(sorry|admit|axiom)\b',solution)
assert len(re.findall(r'^private lemma ',content,re.M))==10
assert all(p['sourceBodySHA256AfterColonEquals']==p['adaptedBodySHA256AfterColonEquals'] for p in maps if p['sourceName']!='Iut.Theorem110Invariants.logSle_nonneg')
write('static-check.json',{'schema':'theorem110-parent-reduction-static/v46','solutionFile':str(P/out),'solutionSHA256':sha(P/out),'privateLemmaCount':10,'sourceRootProofBodyByteIdentity':True,'targetParentTypeExactTextAfterOnlyBindingRename':True,'newParameters':[],'newOpenTheoremDeclarationsInSolution':[],'soleNewOpenSemanticDependency':openrow['name'],'parentImportAbsentTransitively':True,'sourceIutImportsAbsentTransitively':True,'privateProofRenameRecorded':True,'localImportClosure':closure,'compiled':False,'CIcalled':False,'APIcalled':False,'GitCalled':False,'mainWorkspaceWritten':False})
write('README.zh.md','''这是 theorem110 的完整父归约草稿，仅写入本临时目录；未编译、未调用 MCP-CI/API/Git，也未修改主工作区。

入口为 `solution/Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110.lean`。它定义顶层 `solution`，完整类型从当前已发布父 stub 的八参数签名复制，仅变更声明名。主证明体逐字保留来源 `:=` 后的字节。它不导入父 theorem110 stub，也不导入源项目 Iut 模块；静态递归导入检查无父目标循环。

唯一新的公开开放语义子节点是 `AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.rhs_le`。当前子节点文件与主任务给出的 TYPE/BinderInfo job、待完成发布 job 均记录于 `dependencies.json`。未新增任何数学参数或公开内部辅助节点。

七个公开 helper 均按当前 registry 的真实 canonical Theorems 文件与 ACCEPTED 平台 ID 导入：assembly、log_pi_le_two、sum_affine_quadratic、sum_arch、sum_card_standard、lmod_mul_logSle_le、iota_nonneg。特别注意：assembly/log_pi_le_two 的本地 canonical 文件仍为 sorry stub，但平台已有 ACCEPTED 证明；因此本地 axiom 闭包中的 sorryAx 不能直接解释为七个新的数学债务，也不能冒充本地无 sorry 完整证明。平台归约必须按实际 ID/状态区别封闭证明与 Open rhs_le。

十项内部辅助均含完整来源证明，以 private lemma 留在同一 solution 文件中：log_pi_nonneg、one_le_dmod、logQAt_nonneg、sum_logQAt、eStar_cast、logSle_nonneg、logSQ_nonneg、logDKtot_nonneg、two_mul_lstar_add_one、sum_capsuleBound。`private-source-map.json` 保存完整原始命令、源范围、目标位置和逐体摘要。除可见性/命名空间/继承参数上下文外，仅 logSle_nonneg 的 proof 引用从 `inv.ι_nonneg p` 改为 `inv.iota_nonneg p`，使用刚验收的 ASCII canonical。原 proof bytes 的差异已明确记录，未添加 alias 包装。

`adaptation-differences.json` 与 `source/root-source.json` 分别区分“父主 proof 逐字相同”和“整个适配文件/该私有helper proof不同”。`dependencies.json` 的实际依赖列表基于源码和 registry，尚不是编译后的 used-constant 回执。父义务的 cert、est、pnt、h312 仍是原有显式输入；本归约不实例化这些数据，也不宣称无条件 abc。

下一步由主智能体在当前 source TYPE 任务终态后整合并通过 MCP-CI 完成叶检查、solution 类型/绑定信息与 compiled dependency 审查。实际依赖审查应检查：父 stub 未入闭包；唯一新增 Open theorem 是 rhs_le；七项其余公开 theorem ID 的证明状态均仍为 ACCEPTED；十项 private helper 没有 sorry；目标 public 数值结论未改变。当前草稿没有缺失 proof 片段，但全部 Lean 兼容性仍未编译验收。
''')
files=[]
for p in sorted(P.rglob('*')):
 if p.is_file() and p.name!='artifact-manifest.json':files.append({'path':str(p.relative_to(P)),'sha256':sha(p),'bytes':p.stat().st_size})
write('artifact-manifest.json',{'schema':'theorem110-parent-reduction-manifest/v46','packetRoot':str(P),'files':files,'sourceCommit':'07cb1da58f6d428a670dbb5dd6093d428bcbcdd8','compiled':False,'mainWorkspaceWritten':False})
print(json.dumps({'solution':str(P/out),'solutionSHA256':sha(P/out),'manifestSHA256':sha(P/'artifact-manifest.json'),'privateHelpers':len(maps),'rootBodySHA256':bh(rootbody),'acceptedHelpers':[(x['name'],x['platform']['theorem_id']) for x in accepted]},ensure_ascii=False))
