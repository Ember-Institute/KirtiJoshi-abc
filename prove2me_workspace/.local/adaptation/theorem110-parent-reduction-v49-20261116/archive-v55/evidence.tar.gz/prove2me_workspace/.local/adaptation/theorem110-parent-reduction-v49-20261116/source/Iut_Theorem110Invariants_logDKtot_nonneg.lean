lemma logDKtot_nonneg : 0 ≤ inv.logDKtot :=
  Finset.sum_nonneg fun p _ => inv.logDK_nonneg p
