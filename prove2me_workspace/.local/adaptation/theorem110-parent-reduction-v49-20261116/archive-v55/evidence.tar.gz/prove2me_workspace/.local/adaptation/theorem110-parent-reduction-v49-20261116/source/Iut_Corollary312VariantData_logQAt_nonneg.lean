lemma logQAt_nonneg (p : ℕ) : 0 ≤ X.logQAt p := by
  refine Finset.sum_nonneg fun w hw => ?_
  refine mul_nonneg (mul_nonneg (X.qPilot.weight_pos w.1 w.2).le (by positivity)) ?_
  rcases Nat.eq_zero_or_pos (residueChar w.1) with h | h
  · simp [h]
  · exact Real.log_nonneg (by exact_mod_cast h)
