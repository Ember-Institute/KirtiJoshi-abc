这是 theorem110 的完整父归约草稿，仅写入本临时目录；未编译、未调用 MCP-CI/API/Git，也未修改主工作区。

入口为 `solution/Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110.lean`。它定义顶层 `solution`，完整类型从当前已发布父 stub 的八参数签名复制，仅变更声明名。主证明体逐字保留来源 `:=` 后的字节。它不导入父 theorem110 stub，也不导入源项目 Iut 模块；静态递归导入检查无父目标循环。

唯一新的公开开放语义子节点是 `AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.rhs_le`。当前子节点文件与主任务给出的 TYPE/BinderInfo job、待完成发布 job 均记录于 `dependencies.json`。未新增任何数学参数或公开内部辅助节点。

七个公开 helper 均按当前 registry 的真实 canonical Theorems 文件与 ACCEPTED 平台 ID 导入：assembly、log_pi_le_two、sum_affine_quadratic、sum_arch、sum_card_standard、lmod_mul_logSle_le、iota_nonneg。特别注意：assembly/log_pi_le_two 的本地 canonical 文件仍为 sorry stub，但平台已有 ACCEPTED 证明；因此本地 axiom 闭包中的 sorryAx 不能直接解释为七个新的数学债务，也不能冒充本地无 sorry 完整证明。平台归约必须按实际 ID/状态区别封闭证明与 Open rhs_le。

十项内部辅助均含完整来源证明，以 private lemma 留在同一 solution 文件中：log_pi_nonneg、one_le_dmod、logQAt_nonneg、sum_logQAt、eStar_cast、logSle_nonneg、logSQ_nonneg、logDKtot_nonneg、two_mul_lstar_add_one、sum_capsuleBound。`private-source-map.json` 保存完整原始命令、源范围、目标位置和逐体摘要。除可见性/命名空间/继承参数上下文外，仅 logSle_nonneg 的 proof 引用从 `inv.ι_nonneg p` 改为 `inv.iota_nonneg p`，使用刚验收的 ASCII canonical。原 proof bytes 的差异已明确记录，未添加 alias 包装。

`adaptation-differences.json` 与 `source/root-source.json` 分别区分“父主 proof 逐字相同”和“整个适配文件/该私有helper proof不同”。`dependencies.json` 的实际依赖列表基于源码和 registry，尚不是编译后的 used-constant 回执。父义务的 cert、est、pnt、h312 仍是原有显式输入；本归约不实例化这些数据，也不宣称无条件 abc。

下一步由主智能体在当前 source TYPE 任务终态后整合并通过 MCP-CI 完成叶检查、solution 类型/绑定信息与 compiled dependency 审查。实际依赖审查应检查：父 stub 未入闭包；唯一新增 Open theorem 是 rhs_le；七项其余公开 theorem ID 的证明状态均仍为 ACCEPTED；十项 private helper 没有 sorry；目标 public 数值结论未改变。当前草稿没有缺失 proof 片段，但全部 Lean 兼容性仍未编译验收。

`queries/QueryTheorem110ReductionDependencies.lean` 和配置另备编译后依赖审查：展开同模块 private proofs，拒绝直接 sorryAx、父 theorem110 自引用及未分类公开 theorem 依赖；要求实际消费 rhs_le，输出八参数 telescope 与本地公理闭包。使用结构化环境 `THEOREM110_REDUCTION_AUDIT_CONFIG` 传入绝对配置路径。此查询也未编译。
