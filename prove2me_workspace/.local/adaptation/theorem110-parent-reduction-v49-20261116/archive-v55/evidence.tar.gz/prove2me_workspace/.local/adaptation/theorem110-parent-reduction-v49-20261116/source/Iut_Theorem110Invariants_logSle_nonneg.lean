lemma logSle_nonneg : 0 ≤ inv.logSle :=
  Finset.sum_nonneg fun p _ => inv.ι_nonneg p
