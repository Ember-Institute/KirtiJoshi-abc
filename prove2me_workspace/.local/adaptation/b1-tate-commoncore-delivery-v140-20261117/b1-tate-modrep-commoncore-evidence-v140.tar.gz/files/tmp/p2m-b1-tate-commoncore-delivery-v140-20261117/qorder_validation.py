"""Validate qOrder complete source/target evidence without claiming a 20-name bijection."""
import gc,json
from pathlib import Path
S={'propext','Classical.choice','Quot.sound'}
def read(p):return json.loads(Path(p).read_text())
def nm(n):return '' if not n else nm(n[0])+('.' if n[0] else '')+str(n[2])
def count(e,n):
 if isinstance(e,dict):return int(e.get('kind')=='const' and nm(e['name'])==n)+sum(count(v,n) for v in e.values())
 if isinstance(e,list):return sum(count(v,n) for v in e)
 return 0
def validate(source_path,target_path,certify):
 d=read(source_path);assert d['schema']=='B1-qOrder-source-common-core-normalization/v138' and d['compilerVersion']=='4.35.0-rc3'
 assert len(d['sourceRecords'])==6 and len(d['normalizationCertificates'])==12
 assert d['allSixPolymorphicSourceFactsPreserved'] is True and d['sourceCompleteKernelNormalizationChecked'] is True
 assert d['crossVersionComparisonCandidateCount']==4 and d['sourceOnlyEliminatedSupportCount']==2
 for key in ['classCorrespondenceAssumed','certificateProofParametersAddedToProductionDefinitions','sourceGeneratedProofsReplacedByDifferentTargetPropositions','nativeCorrespondenceAccepted']:assert d[key] is False
 excluded={nm(n) for n in d['sourceOnlyAPIProofSupportNames']};assert excluded=={'Iut.EllipticCurveData.TateInputs.qOrder._proof_3','Iut.EllipticCurveData.TateInputs.qOrder._proof_4'}
 source_summary=[]
 for r in d['sourceRecords']:
  assert r['hasSorryAx'] is False
  for key in ['axioms','typeAxioms','valueAxioms']:assert set(r[key])<=S
 for c in d['normalizationCertificates']:
  assert c['sourceCompleteKernelNormalizationChecked'] is True and c['nativeCorrespondenceAccepted'] is False and c['crossVersionSamePropositionClaimed'] is False
  certify(c['wholeRawToDeltaCoreCertificate']);t=c['samePropCompatibilityTemplateCertificate'];certify(t['actualSourceProofInstantiationCertificate'])
  assert t['universalCompleteEqualityKernelChecked'] is True and t['productionDefinitionParametersAdded'] is False
  assert t['nativeProofFunctionsMustMatchCompleteTYPE'] is True
  if c['versionIndependentTemplateRequired']:
   assert c['name'] not in excluded
   for n in excluded:assert count(t['completeProofFunctionTemplate'],n)==0,'old source-only helper remains in complete candidate template'
  else:assert c['name'] in excluded and c['sourceOnlyEliminatedAPIProofSupport'] is True
  source_summary.append({'source':c['name'],'label':c['label'],'role':c['sourceRecordRole'],'versionIndependentTemplateRequired':c['versionIndependentTemplateRequired'],'completeSourceKernelCertificatePreserved':True})
 del d;gc.collect()
 d=read(target_path);assert d['schema']=='B1-qOrder-common-core-consumer/v139' and d['status']=='accepted' and d['correspondenceAccepted'] is True
 assert d['completeStrictComparableRootCount']==4 and d['sourceRecordCount']==6 and d['completeExpressionCount']==8 and len(d['reports'])==4 and len(d['actualPairs'])==4
 assert d['wholeDataCommonCoreKernelEqual'] is True and d['allSixSourceRecordsKernelAudited'] is True and d['allSixNativeOriginalRecordsLegallyAuditedInNativeTwenty'] is True
 for key in ['sixSameBasenameMathematicalCorrespondencesClaimed','classCorrespondenceAssumed','proofParametersAddedToProductionDefinitions']:assert d[key] is False
 labels=[];rows=[]
 for r in d['reports']:
  assert r['source'] not in excluded and r['hasSorryAx'] is False and set(r['axioms'])<=S
  reports=[]
  for c in r['completeActualExprReports']:
   labels.append(c['label']);assert c['completeSourceNativeKernelEqual'] is True and c['proofArgumentsAddedToProductionDefinition'] is False
   for k in ['actualNativeCommonCoreCertificate','sourceDeepBetaCertificate','nativeCoreDeepBetaCertificate','nativeRawDeepBetaCertificate']:certify(c[k])
   if c['label']=='TYPE':assert c['normalizedCommonCoreBinderInfoEqual'] is True
   assert c['rawValueBinderDifferenceRetained'] is (not c['commonCoreBinderInfoEqual'])
   for p in c['nativeActualProofArguments']:assert p['actualCompleteFunctionTYPEEqual'] is True and p['productionAssumptionAdded'] is False
   reports.append({k:c[k] for k in ['label','commonCoreBinderInfoEqual','normalizedCommonCoreBinderInfoEqual','rawValueBinderDifferenceRetained','certificateOnlyProofFunctionCount']})
  rows.append({'source':r['source'],'target':r['target'],'axioms':r['axioms'],'expressions':reports})
 assert labels.count('TYPE')==4 and labels.count('value')==4
 assert len(d['sourceOnlyEliminatedSupportAudits'])==2 and {r['source'] for r in d['sourceOnlyEliminatedSupportAudits']}==excluded
 for r in d['sourceOnlyEliminatedSupportAudits']:assert r['sourceOnlyEliminatedOldAPIProof'] is True and r['sourceCompleteTYPEAndProofKernelAuditBound'] is True and r['sameBasenameNativeCorrespondenceClaimed'] is False
 assert len(d['nativeUnpairedOldAPIProofAudits'])==2
 for r in d['nativeUnpairedOldAPIProofAudits']:assert r['completeNativeTYPEAndProofKernelChecked'] is True and r['sourceProofMathematicalCorrespondenceClaimed'] is False and set(r['axioms'])<=S
 return {'sourceJob':'ci-018666-3f9d7568','targetJob':'ci-018670-ae2beb39','sourceRawRecordCount':6,'sourceCertificateCount':12,'strictComparableRootCount':4,'completeComparableExpressionCount':8,'sourceOnlyCount':2,'nativeUnpairedLegalityCount':2,'sourceSummary':source_summary,'targetRows':rows,'sourceOnlyAudits':d['sourceOnlyEliminatedSupportAudits'],'nativeUnpairedAudits':d['nativeUnpairedOldAPIProofAudits'],'productionDataReplacementUsed':False,'productionProofParametersAdded':False,'classCorrespondenceAssumed':False,'source20Native20MathematicalBijectionClaimed':False}
