#!/usr/bin/env python3
"""Prepare Tate/ModRep evidence; static by default, one archive pass on --archive.
Only this task /tmp is written. No compiler, CI, API, Git, cleanup or production edits.
"""
import argparse,gc,hashlib,io,json,os,tarfile
from pathlib import Path
from qorder_validation import validate as validate_qorder
T=Path('/tmp/p2m-b1-tate-commoncore-delivery-v140-20261117');R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation';C=A/'main-chain-open-20261116';S={'propext','Classical.choice','Quot.sound'}
JOBS={
 'sourceLibraryFailure':('018628','failed','b1-finiteplace-source-library-facts-v130-result.json'),
 'sourceLibrary11':('018630','succeeded','b1-finiteplace-source-library-facts-v131-result.json'),
 'nativeLibraryPartialV131':('018632','failed','b1-finiteplace-native-library-facts-v131-result.json'),
 'nativeLibraryPartialV132':('018635','failed','b1-finiteplace-native-library-facts-v132-result.json'),
 'sourceCommonCore':('018645','succeeded','b1-tate-finiteplace-source-normalization-v134-result.json'),
 'targetCommonCoreFailure':('018652','failed','b1-tate-commoncore-target-review-v136-result.json'),
 'targetDeepBeta':('018655','succeeded','b1-tate-commoncore-deepbeta-review-v137-result.json'),
 'ModRep7':('018625','succeeded','b1-mod-elliptic-representation-seven-review-v129-result.json'),
 'native20':('018620','succeeded','b1-curve-data-native-twenty-facts-v127-result.json'),
 'qOrderSource':('018666','succeeded','b1-qorder-source-normalization-v139-result.json'),
 'qOrderTarget':('018670','succeeded','b1-qorder-target-commoncore-review-v141-result.json'),
 'CurveDataLeaf':('018613','succeeded','b1-curve-tate-modrep-data-leaf-v126-result.json'),
 'CurveDataArtifact':('018616','succeeded','b1-curve-tate-modrep-data-artifact-v127-result.json')}
DIRS=['b1-finiteplace-source-normalization-v132-20261117','b1-tate-commoncore-review-v137-20261117','b1-tate-commoncore-review-v136-20261117','b1-modrep-review-v129-20261117','b1-finiteplace-library-v130-20261117','b1-curve-data-native20-v127-20261117','b1-qorder-source-normalization-v138-20261117','b1-qorder-target-review-v141-20261117']
def read(p):return json.loads(Path(p).read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def walk(x):
 if isinstance(x,dict):
  yield x
  for v in x.values():yield from walk(v)
 elif isinstance(x,list):
  for v in x:yield from walk(v)
def resource(d):
 r=d.get('resources') or d.get('result',{}).get('resources') or {};t,u,s=[r.get(k) for k in ['cpu_time_seconds','cpu_user_seconds','cpu_system_seconds']]
 return {**r,'cpu_total_equals_user_plus_system':None if None in (t,u,s) else abs(t-u-s)<.02,'peak_rss_GiB':r.get('peak_rss_bytes')/1024**3 if r.get('peak_rss_bytes') is not None else None,'peak_pss_GiB':r.get('peak_pss_bytes')/1024**3 if r.get('peak_pss_bytes') is not None else None,'resource_source':r.get('resource_source',r.get('source')),'resource_degraded':r.get('degraded'),'memory_basis':'MCP-CI process-tree physical RSS/PSS; absent fields remain unknown'}
def certify(c):
 assert c['completeExprKernelDefEq'] is True and c['completeEqualityProofKernelChecked'] is True
 for k in ['originalExpr','normalizedExpr','equalityExpr','equalityProofExpr']:assert isinstance(c[k],dict)
 if 'axioms' in c:assert set(c['axioms'])<=S

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,default=T/'prepared-qorder');ap.add_argument('--archive',action='store_true',help='Load full new certificates once, validate, compress once and reopen members; publication can remain pending')
 ap.add_argument('--evidence-directory',type=Path,default=A/'b1-tate-commoncore-delivery-v140-20261117');ap.add_argument('--publication-directory',type=Path,help='Optional actual CurveData publish receipts; default is explicitly unpublished')
 x=ap.parse_args();out=x.output.resolve();assert T in out.parents;out.mkdir(parents=True,exist_ok=True)
 files={};pins={};prior_refs={};hashes={};errors={};gates={};smallscan={};bound_checks=[]
 priors=[];prior_index={}
 for dirname in ['b1-existing-and-elliptic-delivery-v123-20261117','b1-arithmetic-delivery-v129-20261117']:
  p=A/dirname/'archive-manifest.json';m=read(p);assert m['archiveCreated'] is True and m['allMembersReopenedSHA256Verified'] is True
  priors.append({'manifest':str(p),'archive':m['archive'],'sha256':m['archiveSHA256'],'bytes':m['archiveBytes']})
  for f in m['files']:prior_index[f['path']]=(f,m)
 def digest(p):
  key=str(p)
  if key not in hashes:hashes[key]=sha(p)
  return hashes[key]
 def add(p,scan=False):
  p=Path(p).absolute();assert p.is_file(),'missing raw input '+str(p)
  if '.lake' in p.parts or p.suffix in {'.olean','.ilean','.ir','.o','.a','.so'}:
   pins[str(p)]={'path':str(p),'copied':False,'reason':'prebuilt pin only; cache not traversed'};return
  h=digest(p)
  if str(p) in prior_index:
   f,m=prior_index[str(p)]
   if f['sha256']==h:
    prior_refs[str(p)]={'path':str(p),'sha256':h,'bytes':p.stat().st_size,'priorArchiveSHA256':m['archiveSHA256'],'priorArchive':m['archive'],'priorMember':f['member']};return
  if str(p) not in files:
   files[str(p)]={'path':str(p),'sha256':h,'bytes':p.stat().st_size,'member':'files/'+str(p).lstrip('/')}
   if scan and p.suffix=='.json' and p.stat().st_size<20*1024**2 and any((A/n) in p.parents for n in DIRS):smallscan[str(p)]=p
 def gate(k,f):
  try:f();gates[k]=True
  except (OSError,AssertionError,KeyError,TypeError,ValueError) as e:gates[k]=False;errors[k]=str(e)
 receipts={role:(C/n,read(C/n)) for role,(_,_,n) in JOBS.items()}
 def receipts_gate():
  for role,(p,d) in receipts.items():
   expected,status,_=JOBS[role];q,r=d['request'],d['result'];assert d['job_id'].startswith('ci-'+expected) and d['status']==status
   assert Path(q['workspace'])==W and q['exclusive'] is True and r['snapshot']['workspace_mode']=='exclusive_worktree' and r['snapshot']['snapshot_id'] is None
   assert resource(d)['cpu_total_equals_user_plus_system'] is True and resource(d)['peak_rss_bytes']<=16*1024**3
   if status=='succeeded':
    assert r['exit_code']==0
    if q['task_type']=='review':
     v=r['review'];assert v['passed'] is True and v['checks']['no_sorryAx'] is True and v['checks']['assumptions_reported'] is True and not v['violations']
   else:assert r['exit_code']!=0
   add(p)
   for tag in ['request','submit']:
    side=p.with_name(p.name.replace('-result.json','-'+tag+'.json'))
    if side.is_file():add(side)
   for path,h in q['worktree_manifest']['input_hashes'].items():
    pp=Path(path)
    if '.lake' in pp.parts:pins[path]={'path':path,'sha256':h,'copied':False};continue
    assert digest(pp)==h,'exact CI input changed '+path;add(pp,True)
   for art in r.get('artifacts',[]):pins[str(art)]={'path':str(art),'copied':False,'reason':'MCP-CI artifact-store reference; raw receipt preserved'}
 gate('thirteen_actual_success_failure_receipts_and_exact_inputs',receipts_gate)
 for name in DIRS:
  for folder,sub,names in os.walk(A/name):
   sub[:]=[n for n in sub if n not in ['.git','.lake','__pycache__']]
   for n in names:
    if n not in ['credentials.json','.env']:add(Path(folder,n),True)
 code=W/'Definitions/Def_AbcAdaptation_Reference_Iut_Concrete_CurveData.lean';add(code)
 def bound_gate():
  seen=set()
  while smallscan:
   key,p=smallscan.popitem()
   if key in seen:continue
   seen.add(key)
   for node in walk(read(p)):
    path=node.get('path');h=node.get('sha256')
    if isinstance(path,str) and path.startswith('/') and '\n' not in path and len(path)<4096 and isinstance(h,str):
     pp=Path(path)
     if '.lake' in pp.parts:pins[path]={'path':path,'sha256':h,'copied':False};continue
     # Old handoff draft pins are retained as history; accepted input is fixed by its actual receipt.
     if 'handoff' in p.name:
      bound_checks.append({'path':path,'historicalSHA256':h,'kind':'draft handoff reference, not an accepted-input identity claim','currentSHA256':digest(pp) if pp.is_file() else None});
      if pp.is_file():add(pp)
      continue
     assert digest(pp)==h,'bound input changed '+path;add(pp,True);bound_checks.append({'path':path,'sha256':h,'boundBy':str(p)})
 gate('current_small_configs_full_producer_pins_and_prior_inputs',bound_gate)
 def sample_gate():
  d=read(A/'b1-finiteplace-library-v130-20261117/actual/source-library-facts.json');assert d['schema']=='B1-FinitePlace-actual-library-sample/v130' and len(d['records'])==11 and d['unresolvedActualRequests']==[] and d['crossVersionCorrespondenceAccepted'] is False
  d=read(A/'b1-finiteplace-library-v130-20261117/actual/native-library-facts.json');assert len(d['records'])==10 and len(d['unresolvedActualRequests'])==1 and d['crossVersionCorrespondenceAccepted'] is False
  assert 'unresolved' in str(receipts['nativeLibraryPartialV131'][1]['result']['diagnostics']).lower()
  assert 'unresolved' in str(receipts['nativeLibraryPartialV132'][1]['result']['diagnostics']).lower()
 gate('source_eleven_sample_success_native_ten_partial_not_whole_success',sample_gate)
 validation={'performed':False,'mode':'static pointers and receipt checks only; complete new certificate JSON is loaded only on --archive'}
 large_source=A/'b1-finiteplace-source-normalization-v132-20261117/actual/tate-seven-finiteplace-normalization.json';large_target=A/'b1-tate-commoncore-review-v137-20261117/actual/TateInputs-common-core-deepbeta-audit.json';modrep=A/'b1-modrep-review-v129-20261117/actual/ModEllRepData-correspondence-audit.json'
 if x.archive:
  def certificate_gate():
   nonlocal validation
   for pin in priors:assert sha(pin['archive'])==pin['sha256'],'prior archive changed'
   d=read(large_source);assert d['schema']=='B1-FinitePlace-source-common-core-normalization/v132' and d['compilerVersion']=='4.35.0-rc3'
   assert len(d['sourceRecords'])==7 and len(d['normalizationCertificates'])==12 and d['sourceCompleteKernelNormalizationChecked'] is True
   assert d['certificateProofParametersAddedToProductionDefinitions'] is False and d['classCorrespondenceAssumed'] is False and d['nativeCorrespondenceAccepted'] is False
   source_summary=[]
   for c in d['normalizationCertificates']:
    assert c['sourceCompleteKernelNormalizationChecked'] is True and c['nativeCorrespondenceAccepted'] is False;certify(c['wholeRawToDeltaCoreCertificate'])
    t=c['samePropCompatibilityTemplateCertificate'];assert t['universalCompleteEqualityKernelChecked'] is True and t['productionDefinitionParametersAdded'] is False and t['nativeProofFunctionsMustMatchCompleteTYPE'] is True
    certify(t['actualSourceProofInstantiationCertificate'])
    for key in ['completeProofFunctionTemplate','completeProofFunctionTemplateType','universalEqualityExpr','universalEqualityProofExpr']:assert isinstance(t[key],dict)
    assert len(t['actualSourceProofArguments'])==t['certificateOnlyProofFunctionCount']
    source_summary.append({'source':c['name'],'label':c['label'],'certificateOnlyProofFunctionCount':t['certificateOnlyProofFunctionCount']})
   del d;gc.collect()
   d=read(large_target);assert d['schema']=='B1-TateInputs-common-core-consumer/v137' and d['status']=='accepted' and d['correspondenceAccepted'] is True and len(d['reports'])==7
   assert d['wholeDataCommonCoreKernelEqual'] is True and d['classCorrespondenceAssumed'] is False and d['proofParametersAddedToProductionDefinitions'] is False and d['completeStructureMetadataReviewed'] is True
   assert (d['completeExpressionCount'],d['structureCount'],d['projectionCount'],d['constructorCount'],d['recursorCount'],d['recursorRuleCount'])==(12,1,4,1,1,1)
   target_summary=[];labels=[]
   for row in d['reports']:
    assert row['hasSorryAx'] is False and set(row['axioms'])<=S
    summaries=[]
    for c in row['completeActualExprReports']:
     labels.append(c['label']);assert c['completeSourceNativeKernelEqual'] is True and c['proofArgumentsAddedToProductionDefinition'] is False
     assert c['rawValueBinderDifferenceRetained'] is (not c['commonCoreBinderInfoEqual'])
     certify(c['actualNativeCommonCoreCertificate'])
     for key in ['sourceDeepBetaCertificate','nativeCoreDeepBetaCertificate','nativeRawDeepBetaCertificate']:certify(c[key])
     if c['label']=='TYPE':assert c['normalizedCommonCoreBinderInfoEqual'] is True and c['deepBetaBinderDiagnostics']['afterDeepBetaNormalizedBinderInfoEqual'] is True
     for p in c['nativeActualProofArguments']:assert p['actualCompleteFunctionTYPEEqual'] is True and p['productionAssumptionAdded'] is False
     summaries.append({k:c[k] for k in ['label','commonCoreBinderInfoEqual','normalizedCommonCoreBinderInfoEqual','beforeDeepBetaNormalizedBinderInfoEqual','rawValueBinderDifferenceRetained','certificateOnlyProofFunctionCount']})
    target_summary.append({'source':row['source'],'target':row['target'],'axioms':row['axioms'],'expressions':summaries})
   assert labels.count('TYPE')==7 and labels.count('value')==4 and labels.count('recursorRHS:0')==1
   del d;gc.collect()
   d=read(modrep);assert d['schema']=='B1-CurveData-group-correspondence-audit/v125' and d['group']=='ModEllRepData' and d['correspondenceAccepted'] is True and len(d['reports'])==7
   assert (d['structureCount'],d['projectionCount'],d['instanceProjectionCount'],d['constructorCount'],d['recursorCount'],d['recursorRuleCount'])==(1,4,0,1,1,1)
   for row in d['reports']:
    for key in ['completeTYPEKernelEqual','strictCompleteTYPEBinderInfoEqual','instanceRegistrationEqual','completeComputationMetadataEqual']:assert row[key] is True
    assert row['hasSorryAx'] is False and set(row['axioms'])<=S
    assert row['rawValueBinderDifferenceRetained'] is (not row['rawValueBinderInfoEqual'])
   assert d['newAssumptionsIntroduced'] is False and d['extraUnreachableGeneratedDeclarationsClaimedCompared'] is False
   modrep_summary=[{k:v for k,v in row.items() if k!='actualRuleReports'} for row in d['reports']];del d;gc.collect()
   validation={'performed':True,'sourceCertificateCount':12,'sourceSummary':source_summary,'TateRows':target_summary,'ModRepRows':modrep_summary,'strictBetaOnly':'Full source/native β certificates and original BinderInfo diagnostics retained; no η/δ/class equivalence waiver.'}
  gate('complete_new_source_target_certificates_and_ModRep_full_reports',certificate_gate)
 else:gates['complete_new_source_target_certificates_and_ModRep_full_reports']=None
 qorder_source=A/'b1-qorder-source-normalization-v138-20261117/actual/qorder-six-source-common-core-normalization.json'
 qorder_target=A/'b1-qorder-target-review-v141-20261117/actual/qorder-commoncore-correspondence.json'
 qorder_validation={'performed':False,'sourceRecordCount':6,'candidateRootCount':4,'sourceOnlyCount':2,'nativeUnpairedLegalityCount':2,'source20Native20MathematicalBijectionClaimed':False}
 if x.archive:
  def qorder_gate():
   nonlocal qorder_validation
   qorder_validation=validate_qorder(qorder_source,qorder_target,certify);qorder_validation['performed']=True
  gate('qOrder_four_comparisons_two_source_only_and_two_native_unpaired',qorder_gate)
 else:gates['qOrder_four_comparisons_two_source_only_and_two_native_unpaired']=None
 write(out/'qorder-certificate-validation.json',qorder_validation)
 publication=None
 if x.publication_directory:
  def publication_gate():
   nonlocal publication
   p=x.publication_directory;original=read(p/'payload.json');payload=read(p/'payload-final.json');item=read(p/'published-item.json');r=read(p/'publish-result.json');j=read(p/'publish-journal.json');submit=read(p/'publish-submit.json');intent=read(p/'publish-intent.json')
   assert set(payload)=={'definition_name','definition_title','definition','natural_language_statement','source','env','private'}
   assert payload['definition']==code.read_text() and payload['private'] is True
   for key in payload:
    if key!='natural_language_statement':assert payload[key]==original[key]
   import difflib
   edits=[op for op in difflib.SequenceMatcher(a=original['natural_language_statement'],b=payload['natural_language_statement'],autojunk=False).get_opcodes() if op[0]!='equal']
   assert len(edits)==1 and edits[0][0]=='insert'
   _,a0,a1,b0,b1=edits[0];assert a0==a1 and payload['natural_language_statement'][b0:b1]=='`'
   assert payload['natural_language_statement'].split('# 简体中文',1)[1:]==original['natural_language_statement'].split('# 简体中文',1)[1:]
   assert r['status']=='PUBLISHED' and r['kind']=='definition' and r['error_message']=='' and r['formal_statement']==''
   assert r['id']==j['job_id']==submit['job_id']=='b92beb54-c83b-4e38-91cd-6d47232de732'
   assert r['theorem_id']==item['definition_id']==j['definition_id']=='8699f56a-0ef9-4a3c-a533-064283969900' and r['visibility']=='private'
   for k in ['definition_name','definition_title','definition','natural_language_statement','source']:assert item[k]==payload[k]
   for k,key in [('theorem_name','definition_name'),('theorem_title','definition_title'),('definitions','definition'),('natural_language_statement','natural_language_statement'),('source','source')]:assert r[k]==payload[key]
   assert item['mathlib_rev']==payload['env']=='0df444a360eaa60ab8c11dca51a86af692955474' and item['visibility']=='private' and item['deprecated_at'] is None and item['deprecated_by'] is None
   assert intent['payloadSha256']==sha(p/'payload-final.json') and all(read(p/'publication-validation.json').values())
   assert j['allPayloadFieldsExact'] is True and set(j['actualReviewJobs'])=={'ci-018655-107096d5','ci-018625-581f9567','ci-018670-ae2beb39'}
   blind=read(p/'independent-readback/manifest.json');assert blind['auditor_model']=='gpt-6.1-sol' and blind['code_sha256']==sha(code)
   for pin in blind['inputs']:assert sha(pin['path'])==pin['sha256'];add(pin['path'])
   for pin in blind['artifacts']:assert sha(p/'independent-readback'/pin['path'])==pin['sha256']
   publication={'id':item['definition_id'],'name':item['definition_name'],'job':r['id'],'private':True,'allItemFieldsExact':True,'payloadFinalSHA256':sha(p/'payload-final.json'),'originalPayloadSHA256':sha(p/'payload.json'),'onlyFinalEdit':'One backtick inserted around English paper local path; canonical mathematical definition unchanged','independentBlindOriginalsUnchanged':True,'historicalMetadataPendingStatusesPreserved':True}
   for f in p.rglob('*'):
    if f.is_file():add(f)
  gate('actual_CurveData_private_publication',publication_gate)
 else:gates['actual_CurveData_private_publication']=False;errors['actual_CurveData_private_publication']='Not yet published in this frozen scope; qOrder local evidence accepted; actual CurveData private publication remains pending.'
 evidence_ready=all(v is True for k,v in gates.items() if k!='actual_CurveData_private_publication');complete=evidence_ready and bool(publication)
 write(out/'completion-gates.json',{'schema':'B1-Tate-ModRep-delivery-gates/v140','completeDelivery':complete,'evidenceReadyForArchive':evidence_ready,'certificateValidationDeferredUntilArchive':not x.archive,'gates':gates,'errors':errors,'CurveDataPlatformPublished':bool(publication),'qOrderLocalEvidenceIncluded':True,'sourceComparableRootCount':18,'source20Native20MathematicalBijectionClaimed':False,'allNativeLibrarySamplingSucceeded':False,'classCorrespondenceAssumed':False,'productionProofParametersAdded':False,'initialThetaDataExistenceProved':False,'Height603FirstClassOpen':True,'mainWorkspaceWritten':False,'CICompilerAPIGitExecuted':False})
 write(out/'certificate-validation.json',validation)
 history=[]
 for role,(p,d) in receipts.items():
  q,r=d['request'],d['result'];history.append({'role':role,'jobId':d['job_id'],'status':d['status'],'rawReceipt':str(p),'sha256':digest(p),'exitCode':r.get('exit_code'),'actualArguments':r.get('actual_arguments'),'workspaceMode':r['snapshot']['workspace_mode'],'snapshotId':r['snapshot']['snapshot_id'],'resources':resource(d),'diagnostics':r.get('diagnostics'),'inputManifestPointer':str(p)+'#/request/worktree_manifest'})
 write(out/'ci-history.json',history);write(out/'prebuilt-pins.json',list(pins.values()));write(out/'bound-input-checks.json',bound_checks);write(out/'prior-evidence-references.json',{'archives':priors,'members':list(prior_refs.values()),'restoreRequiresPriorArchives':True})
 pointers=[files[str(p)] for p in [large_source,large_target,modrep]];write(out/'large-evidence-pointers.json',pointers)
 ledger={'schema':'B1-Tate-ModRep-compact-ledger/v140','status':'PREPARED_PENDING_FULL_CERTIFICATE_ARCHIVE_AND_PUBLICATION' if not x.archive else 'ACCEPTED_LOCAL_EVIDENCE_PENDING_PUBLICATION' if evidence_ready and not publication else 'ACCEPTED_DELIVERY' if complete else 'PENDING_GATES','Tate7':{'sourceJob':'ci-018645-d8111892','targetJob':'ci-018655-107096d5','failedTargetJob':'ci-018652-791e8a15','TYPECount':7,'valueCount':4,'recursorRHSCount':1,'fields':4,'certificateScope':'exact finite-place delta common core, certificate-only same-Prop proof functions, strict deep beta; complete raw/normalized Expr and before/after BinderInfo retained','fullRawTargetEvidence':pointers[1]},'ModRep7':{'job':'ci-018625-581f9567','fields':4,'instances':0,'fullRawEvidence':pointers[2]},'finitePlaceLibrarySampling':{'sourceJob':'ci-018630-c7bda35b','sourceRecordCount':11,'sourcePriorAtKeywordFailure':'ci-018628-6875b754','nativeRecordCount':10,'nativeWholeJobStatuses':['failed','failed'],'nativeFailureJobs':['ci-018632-03b7a20f','ci-018635-a9777af3'],'oneUnusedGenericExactNameUnresolved':True,'crossVersionLibraryClassCorrespondenceClaimed':False},'CurveDataDefinition':{'path':str(code),'sha256':digest(code),'leafJob':'ci-018613-edfde842','artifactJob':'ci-018616-cccfdc10','native20Job':'ci-018620-5cc00625','publication':publication},'qOrder':{'sourceJob':'ci-018666-3f9d7568','targetJob':'ci-018670-ae2beb39','sourceRawRecords':6,'sourceCertificates':12,'strictComparableRoots':4,'comparableExpressions':8,'sourceOnlyHelpers':2,'nativeUnpairedProofLegality':2,'sourceHelperPropositions':['Ring.HasFiniteQuotients','Infinite'],'sameBasenameNativeHelperPropositions':['Finite','Module.Free'],'sameBasenameMathematicalCorrespondenceClaimed':False,'sourceOnlyHelpersEliminatedFromCompleteProductionQOrderAndPos':True,'dataReplacementUsed':False,'newProductionParametersAdded':False,'classCorrespondenceAssumed':False},'source20AndNative20FactsPreserved':True,'mathematicalCorrespondenceCount':18,'sourceOnlyRecordCount':2,'nativeUnpairedRecordCount':2,'certificateOnlyProofFunctionsAreProductionParameters':False,'rawBinderFalseFlagsPreserved':True,'allNativeGeneratedDeclarationsCovered':False,'qOrderLocalEvidenceIncluded':True,'sourceComparableRootCount':18,'source20Native20MathematicalBijectionClaimed':False,'initialThetaDataConstructed':False,'initialThetaDataExistenceProved':False,'Height603FirstClassOpen':True,'mathematicalParentClosed':False,'parentPriorArchives':priors};write(out/'SOURCE_LEDGER.json',ledger)
 write(out/'root-application.json',{'evidenceDirectory':str(x.evidence_directory),'copyWholeOutputAfterReview':True,'overwritePriorLedger':False,'deletePaths':[],'newMarkdownDocumentsCreated':False,'archiveCommand':'python3 '+str(Path(__file__))+' --archive --output '+str(T/'final'),'publicationGateDefaultPending':True,'qOrderEvidenceIncluded':True,'source20Native20BijectionClaimed':False})
 add(T/'qorder_validation.py')
 add(Path(__file__))
 for p in out.iterdir():
  if p.is_file() and p.suffix=='.json' and p.name!='archive-manifest.json':add(p)
 manifest={'schema':'B1-Tate-ModRep-content-archive/v140','completeDelivery':complete,'evidenceReadyForArchive':evidence_ready,'archiveCreated':False,'files':[files[k] for k in sorted(files)],'fullNewCertificatesPreserved':True,'priorArchivesRequired':True,'publicationPending':not bool(publication)};write(out/'archive-manifest.json',manifest)
 if x.archive:
  assert evidence_ready,'local evidence gates failed; publication may remain pending';archive=out/'b1-tate-modrep-commoncore-evidence-v140.tar.gz';idx=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
  with tarfile.open(archive,'w:gz') as t:
   i=tarfile.TarInfo('archive-index.json');i.size=len(idx);t.addfile(i,io.BytesIO(idx))
   for row in manifest['files']:assert sha(row['path'])==row['sha256'];t.add(row['path'],arcname=row['member'],recursive=False)
  with tarfile.open(archive,'r:gz') as t:
   assert len(t.getmembers())==len(manifest['files'])+1 and t.extractfile('archive-index.json').read()==idx
   for row in manifest['files']:
    f=t.extractfile(row['member']);h=hashlib.sha256()
    for b in iter(lambda:f.read(1048576),b''):h.update(b)
    assert h.hexdigest()==row['sha256'] and sha(row['path'])==row['sha256']
  manifest.update(archiveCreated=True,archive=str(archive),archiveSHA256=sha(archive),archiveBytes=archive.stat().st_size,allMembersReopenedSHA256Verified=True);write(out/'archive-manifest.json',manifest)
 print(json.dumps({'completeDelivery':complete,'evidenceReadyForArchive':evidence_ready,'gates':gates,'errors':errors,'fileCount':len(files),'priorReferenceCount':len(prior_refs),'output':str(out),'archiveCreated':manifest['archiveCreated']},ensure_ascii=False))
if __name__=='__main__':main()
