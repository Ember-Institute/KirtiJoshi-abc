import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_CurveData

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]

def validateSupport (maps : NameMap) (rows : Array Json) : MetaM Unit := do
  for p in rows do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) && (← checked (p.getObjValAs? Bool "isClosed")) && (← checked (arrayField p "levelParams")).isEmpty do
      throwError "Invalid actual closed proof support {n}"
    let t ← checked (relocateExpr maps rows #[] true (← checked (field p "actualTypeExpr")))
    let v ← checked (relocateExpr maps rows #[n] true (← checked (field p "actualProofExpr")))
    let vt ← kernelCheck s!"proof support {n}" v
    unless ← isProp vt do throwError "Support proof would replace data {n}"
    kernelEq s!"proof support TYPE {n}" vt t
    ensureStandard s!"expanded proof support {n}" (← expressionAxioms v)


def sameBound (label : String) (a b : Json) : MetaM Unit :=
  unless a == b do throwError "Bound actual fact differs {label}"

def writeOutput (path : String) (j : Json) : MetaM Unit := do
  unless path.startsWith "/" do throwError "Expected absolute output path"
  if let some parent := (System.FilePath.mk path).parent then IO.FS.createDirAll parent
  IO.FS.writeFile path (j.pretty ++ "\n")

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]


def canonicalStructureMetadata (j : Json) : MetaM Json := do
  let rawFields ← checked (arrayField j "fieldsSortedByName")
  let fields ← rawFields.mapM fun r => do
    return (← checked (decodeName (← checked (field r "fieldName"))), r)
  let fields := (fields.qsort fun a b => Name.lt a.1 b.1).map (·.2)
  return Json.mkObj [
    ("structure",← checked (field j "structure")),
    ("fieldNamesInConstructorOrder",← checked (field j "fieldNamesInConstructorOrder")),
    ("fieldsSortedByName",Json.arr fields),
    ("parentsInExtendsOrder",← checked (field j "parentsInExtendsOrder"))]


def closed := requireClosed
def kcheck := kernelCheck
def keq := kernelEq

def certify (raw normalized : Expr) : MetaM Json := do
  kernelEq "complete native raw/common-core Expr" raw normalized
  let equality ← mkEq raw normalized
  let proof ← mkEqRefl raw
  let proofType ← kernelCheck "native common-core equality proof" proof
  kernelEq "native common-core equality proposition" proofType equality
  ensureStandard "native common-core equality proof" (← expressionAxioms proof)
  return Json.mkObj [
    ("originalExpr",← checked (encodeExpr raw)),("normalizedExpr",← checked (encodeExpr normalized)),
    ("equalityExpr",← checked (encodeExpr equality)),("equalityProofExpr",← checked (encodeExpr proof)),
    ("completeExprKernelDefEq",toJson true),("completeEqualityProofKernelChecked",toJson true)]
def contextVars (exclude : Array Expr := #[]) : MetaM (Array Expr) := do
  return (← getLCtx).foldl (fun xs d =>
    let x := mkFVar d.fvarId
    if exclude.contains x then xs else xs.push x) (#[] : Array Expr)

def localEqEvidence (label : String) (raw normalized : Expr) : MetaM Json := do
  let locals ← contextVars
  let rawClosed ← mkLambdaFVars locals raw
  let normalizedClosed ← mkLambdaFVars locals normalized
  let certificate ← certify rawClosed normalizedClosed
  return certificate.setObjVal! "label" (toJson label)

-- These are the only computational declarations expanded. All ten source
-- arguments are supplied to real delta reduction; no class is renamed or mapped.
def normalizeCore (raw : Expr) : MetaM (Expr × Json) := do
  let events ← IO.mkRef (#[] : Array Json)
  let normalized ← Meta.transform raw (pre := fun e => do
    if e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.one_lt_absNorm_nnreal then
      unless e.getAppNumArgs == 6 do throwError "Unexpected partial one_lt_absNorm_nnreal application"
      return .done e
    if e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.instNormedFieldValuedAdicCompletion ||
        e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.instRankOneAdicCompletion then
      unless e.getAppNumArgs == 10 do throwError "Unexpected partial FinitePlace data instance application"
      let some expanded ← unfoldDefinition? e (ignoreTransparency := true) |
        throwError "Actual FinitePlace data instance failed exact delta reduction"
      let candidate := expanded.headBeta
      let expected := if e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.instNormedFieldValuedAdicCompletion
        then ``Valued.toNormedField else ``Valuation.IsRankOneDiscrete.rankOne
      unless candidate.getAppFn.isConstOf expected do throwError "Unexpected delta core head"
      let event ← localEqEvidence "exact-ten-argument-instance-delta" e candidate
      events.modify (·.push event)
      return .visit candidate
    let args := e.getAppArgs
    if e.getAppFn.isConstOf ``DFunLike.coe && args.size == 6 then
      let hom := args[4]!
      if hom.getAppFn.isConstOf ``Ideal.absNorm && hom.getAppNumArgs == 4 then
        let some expanded ← unfoldDefinition? hom (ignoreTransparency := true) |
          throwError "Cannot delta-expand actual bundled absNorm"
        let projected := mkAppN e.getAppFn (args.set! 4 expanded)
        let candidate ← withReducibleAndInstances <| whnf projected
        unless candidate.getAppFn.isConstOf ``Submodule.cardQuot do throwError "Actual absNorm did not reduce to cardQuot"
        let event ← localEqEvidence "saturated-actual-Nat-absNorm-to-cardQuot" e candidate
        events.modify (·.push event)
        return .done candidate
    if e.getAppFn.isConstOf ``Ideal.absNorm then
      throwError "Unsupported unsaturated or bundled absNorm outside the retained Prop proof"
    return .continue)
  let evidence ← events.get
  return (normalized, Json.mkObj [
    ("events",Json.arr evidence),("exactDataDeltaCount",toJson evidence.size),
    ("nonPropositionalDataReplacedWithoutKernelCertificate",toJson false)])

structure ProofSite where
  functionType : Expr
  actualProofFunction : Expr
  localBinders : Array String
  localContextIndices : Array Nat
  deriving Inhabited

def collectProofSites (core : Expr) : MetaM (Array ProofSite) := do
  let sites ← IO.mkRef (#[] : Array ProofSite)
  discard <| Meta.transform core (pre := fun e => do
    unless e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.one_lt_absNorm_nnreal do
      return .continue
    unless e.getAppNumArgs == 6 do throwError "Expected complete source one_lt_absNorm_nnreal proof application"
    let expectedType ← inferType e
    unless ← isProp expectedType do throwError "Certificate abstraction would abstract computational data"
    let (normalizedProp,_) ← normalizeCore expectedType
    let allLocals ← contextVars
    let used ← (Lean.collectFVars (Lean.collectFVars {} normalizedProp) e).addDependencies
    let localContextIndices := (Array.range allLocals.size).filter fun i =>
      used.fvarSet.contains allLocals[i]!.fvarId!
    let locals := localContextIndices.map (allLocals[·]!)
    let functionType ← mkForallFVars locals normalizedProp
    let actualProofFunction ← mkLambdaFVars locals e
    closed "certificate-only proof-function TYPE" functionType
    closed "original actual proof function" actualProofFunction
    let proofType ← kcheck "actual original one_lt proof function" actualProofFunction
    keq "actual one_lt proof function TYPE" proofType functionType
    ensureStandard "actual original proof function" (← expressionAxioms actualProofFunction)
    let localBinders ← locals.mapM fun x => return encodeBinder (← x.fvarId!.getDecl).binderInfo
    sites.modify (·.push {functionType,actualProofFunction,localBinders,localContextIndices})
    return .done e)
  return ← sites.get


def boolField (j : Json) (key : String) : MetaM Bool := checked (j.getObjValAs? Bool key)

def instantiateSourceTemplate (maps : NameMap) (sourceCertificate : Json) (nativeRaw : Expr) (isTYPE : Bool)
    (diagnosticOutput : String) (sourceUniverses nativeUniverses : List Name) (commonLevels : List Level) : MetaM Json := do
  unless ← boolField sourceCertificate "sourceCompleteKernelNormalizationChecked" do
    throwError "Source complete normalization certificate not checked"
  let sourceTemplateCertificate ← checked (field sourceCertificate "samePropCompatibilityTemplateCertificate")
  unless ← boolField sourceTemplateCertificate "universalCompleteEqualityKernelChecked" do
    throwError "Source universal whole-data equality was not kernel checked"
  if ← boolField sourceTemplateCertificate "productionDefinitionParametersAdded" then
    throwError "Compatibility proof parameters must not enter production definitions"
  unless ← boolField sourceTemplateCertificate "nativeProofFunctionsMustMatchCompleteTYPE" do
    throwError "Source certificate does not require exact actual proof-function TYPE"
  let decode (j : Json) := checked (relocateExpr maps #[] #[] true j)
  let sourceTemplate ← decode (← checked (field sourceTemplateCertificate "completeProofFunctionTemplate"))
  let sourceTemplate := sourceTemplate.instantiateLevelParams sourceUniverses commonLevels
  let nativeRaw := nativeRaw.instantiateLevelParams nativeUniverses commonLevels
  let (nativeCore,nativeDelta) ← normalizeCore nativeRaw
  let nativeCoreCertificate ← certify nativeRaw nativeCore
  let nativeSites ← collectProofSites nativeCore
  let sourceArguments ← checked (arrayField sourceTemplateCertificate "actualSourceProofArguments")
  let expectedCount ← checked (sourceTemplateCertificate.getObjValAs? Nat "certificateOnlyProofFunctionCount")
  unless nativeSites.size == sourceArguments.size && sourceArguments.size == expectedCount do
    throwError "Actual native/source one_lt proof-function occurrence count differs"
  let mut actualNativeProofArguments : Array Expr := #[]
  let mut proofReports : Array Json := #[]
  for i in [:nativeSites.size] do
    let sourceArgument := sourceArguments[i]!
    let nativeSite := nativeSites[i]!
    unless (← checked (sourceArgument.getObjValAs? Nat "occurrenceIndex")) == i &&
        (← boolField sourceArgument "proofOnlyCertificateBinder") do
      throwError "Source proof-function ordering or certificate-only scope changed"
    let sourceFunctionTYPE ← decode (← checked (field sourceArgument "proofFunctionType"))
    let sourceFunctionTYPE := sourceFunctionTYPE.instantiateLevelParams sourceUniverses commonLevels
    kernelEq s!"actual source/native proof-function complete TYPE {i}" sourceFunctionTYPE nativeSite.functionType
    sameBound "actual source/native context BinderInfo"
      (← checked (field sourceArgument "originalContextBinderInfo")) (toJson nativeSite.localBinders)
    sameBound "actual source/native proof context dependency indices"
      (← checked (field sourceArgument "originalContextDependencyIndices")) (toJson nativeSite.localContextIndices)
    let inferred ← kernelCheck s!"actual native proof-function {i}" nativeSite.actualProofFunction
    kernelEq s!"actual native proof-function expected TYPE {i}" inferred sourceFunctionTYPE
    ensureStandard s!"actual native proof-function {i}" (← expressionAxioms nativeSite.actualProofFunction)
    actualNativeProofArguments := actualNativeProofArguments.push nativeSite.actualProofFunction
    proofReports := proofReports.push (Json.mkObj [
      ("occurrenceIndex",toJson i),("actualCompleteFunctionTYPEEqual",toJson true),
      ("nativeActualProofFunctionTYPE",← checked (encodeExpr nativeSite.functionType)),
      ("nativeActualProofFunction",← checked (encodeExpr nativeSite.actualProofFunction)),
      ("contextBinderInfo",toJson nativeSite.localBinders),
      ("productionAssumptionAdded",toJson false)])
  let declaration ← checked (stringField sourceCertificate "name")
  let expressionLabel ← checked (stringField sourceCertificate "label")
  let instantiatedSource := mkAppN sourceTemplate actualNativeProofArguments |>.headBeta
  let sourceInstantiatedTYPE ← kernelCheck "complete source common-core template with real native proofs" instantiatedSource
  let nativeTYPE ← kernelCheck "complete native raw Expr" nativeRaw
  kernelEq "complete instantiated source/native inferred TYPE" sourceInstantiatedTYPE nativeTYPE
  kernelEq "complete source/native common-core data Expr" instantiatedSource nativeRaw
  for e in #[instantiatedSource,sourceInstantiatedTYPE,nativeRaw,nativeTYPE] do
    ensureStandard "actual common-core source/native expression" (← expressionAxioms e)
  let binderEqual := binderInventory instantiatedSource == binderInventory nativeRaw &&
    binderPlacement instantiatedSource == binderPlacement nativeRaw
  let beforeBetaNormalizedBinderEqual := binderInventory instantiatedSource == binderInventory nativeCore &&
    binderPlacement instantiatedSource == binderPlacement nativeCore
  -- Reduce only beta redexes at every depth. No definitions, lets, or typeclass data are replaced.
  let betaSource ← Core.betaReduce instantiatedSource
  let betaNativeCore ← Core.betaReduce nativeCore
  let betaNativeRaw ← Core.betaReduce nativeRaw
  let sourceDeepBetaCertificate ← certify instantiatedSource betaSource
  let nativeCoreDeepBetaCertificate ← certify nativeCore betaNativeCore
  let nativeRawDeepBetaCertificate ← certify nativeRaw betaNativeRaw
  kernelEq s!"complete deep-beta source/native data Expr {declaration}:{expressionLabel}" betaSource betaNativeRaw
  kernelEq s!"complete deep-beta source/native core Expr {declaration}:{expressionLabel}" betaSource betaNativeCore
  let normalizedBinderEqual := binderInventory betaSource == binderInventory betaNativeCore &&
    binderPlacement betaSource == binderPlacement betaNativeCore
  let publicBinderEqual := outerForallBinderInfo instantiatedSource == outerForallBinderInfo nativeRaw &&
    outerForallBinderInfo betaSource == outerForallBinderInfo betaNativeRaw
  let binderDiagnostic := Json.mkObj [
    ("declaration",toJson declaration),("label",toJson expressionLabel),("isTYPE",toJson isTYPE),
    ("completeKernelEqualityBeforeStrictGate",toJson true),
    ("beforeDeepBetaNormalizedBinderInfoEqual",toJson beforeBetaNormalizedBinderEqual),
    ("afterDeepBetaNormalizedBinderInfoEqual",toJson normalizedBinderEqual),
    ("publicOuterBinderInfoEqual",toJson publicBinderEqual),
    ("beforeDeepBetaSourceBinderInventory",toJson (binderInventory instantiatedSource)),
    ("beforeDeepBetaNativeCoreBinderInventory",toJson (binderInventory nativeCore)),
    ("beforeDeepBetaSourceBinderPlacement",toJson (binderPlacement instantiatedSource)),
    ("beforeDeepBetaNativeCoreBinderPlacement",toJson (binderPlacement nativeCore)),
    ("afterDeepBetaSourceBinderInventory",toJson (binderInventory betaSource)),
    ("afterDeepBetaNativeCoreBinderInventory",toJson (binderInventory betaNativeCore)),
    ("afterDeepBetaSourceBinderPlacement",toJson (binderPlacement betaSource)),
    ("afterDeepBetaNativeCoreBinderPlacement",toJson (binderPlacement betaNativeCore)),
    ("afterDeepBetaSourceOnlyBinderPaths",toJson ((binderPlacement betaSource).filter fun p => !(binderPlacement betaNativeCore).contains p)),
    ("afterDeepBetaNativeOnlyBinderPaths",toJson ((binderPlacement betaNativeCore).filter fun p => !(binderPlacement betaSource).contains p))]
  if isTYPE then
    unless normalizedBinderEqual && publicBinderEqual do
      writeOutput diagnosticOutput (Json.mkObj [
        ("schema",toJson "B1-qOrder-common-core-consumer/v139"),
        ("status",toJson "strict-TYPE-BinderInfo-failed-after-kernel-certified-deep-beta"),
        ("failure",binderDiagnostic),
        ("sourceDeepBetaCertificate",sourceDeepBetaCertificate),
        ("nativeCoreDeepBetaCertificate",nativeCoreDeepBetaCertificate),
        ("nativeRawDeepBetaCertificate",nativeRawDeepBetaCertificate),
        ("correspondenceAccepted",toJson false)])
      throwError "Strict complete deep-beta normalized source/native TYPE BinderInfo differs at {declaration}:{expressionLabel}; full inventories and placements saved to {diagnosticOutput}"
  return Json.mkObj [
    ("sourceInstantiatedCommonCoreExpr",← checked (encodeExpr instantiatedSource)),
    ("sourceInstantiatedCommonCoreTYPE",← checked (encodeExpr sourceInstantiatedTYPE)),
    ("nativeRawExpr",← checked (encodeExpr nativeRaw)),
    ("completeSourceNativeKernelEqual",toJson true),("commonCoreBinderInfoEqual",toJson binderEqual),
    ("normalizedCommonCoreBinderInfoEqual",toJson normalizedBinderEqual),
    ("beforeDeepBetaNormalizedBinderInfoEqual",toJson beforeBetaNormalizedBinderEqual),
    ("deepBetaBinderDiagnostics",binderDiagnostic),
    ("sourceDeepBetaCertificate",sourceDeepBetaCertificate),
    ("nativeCoreDeepBetaCertificate",nativeCoreDeepBetaCertificate),
    ("nativeRawDeepBetaCertificate",nativeRawDeepBetaCertificate),
    ("sourceDeepBetaCommonCoreExpr",← checked (encodeExpr betaSource)),
    ("nativeDeepBetaCommonCoreExpr",← checked (encodeExpr betaNativeCore)),
    ("rawValueBinderDifferenceRetained",toJson (!binderEqual)),
    ("actualNativeCommonCoreCertificate",nativeCoreCertificate),("nativeExactDeltaSteps",nativeDelta),
    ("nativeActualProofArguments",Json.arr proofReports),("certificateOnlyProofFunctionCount",toJson expectedCount),
    ("proofArgumentsAddedToProductionDefinition",toJson false)]

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_QORDER_COMMONCORE_CONSUMER_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-qOrder-common-core-consumer-config/v139" do
    throwError "Wrong TateInputs common-core consumer configuration"
  let data ← checked (field cfg "completeFrozenInputs")
  let source ← checked (field data "sourceNormalization")
  unless (← checked (stringField source "schema")) == "B1-qOrder-source-common-core-normalization/v138" &&
      (← boolField source "sourceCompleteKernelNormalizationChecked") &&
      !(← boolField source "certificateProofParametersAddedToProductionDefinitions") &&
      !(← boolField source "classCorrespondenceAssumed") do
    throwError "Source whole-data common-core certificates are not accepted"
  let allSourceRows ← checked (arrayField source "sourceRecords")
  let selectedSource ← checked (field data "originalSourceRows")
  sameBound "source normalization runtime actual qOrder six raw rows" (Json.arr allSourceRows) selectedSource
  let sourceCertificates ← checked (arrayField source "normalizationCertificates")
  unless allSourceRows.size == 6 && sourceCertificates.size == 12 do
    throwError "Expected six complete source declarations and twelve full-Expr certificates"
  let roles ← checked (arrayField source "sourceRecordRoles")
  unless roles.size == 6 && (← checked (source.getObjValAs? Nat "sourceOnlyEliminatedSupportCount")) == 2 do
    throwError "Source qOrder exact proof-support role count differs"
  let oldSupportNames ← namesFromJson (← checked (field source "sourceOnlyAPIProofSupportNames"))
  unless oldSupportNames.length == 2 do throwError "Expected exact two eliminated source old-API proofs"
  let oldSupport := oldSupportNames.toArray
  let rawSourceRows := allSourceRows.filter fun r =>
    !oldSupport.any (fun n => (field r "nameExpr").toOption == some (encodeName n))
  unless rawSourceRows.size == 4 do throwError "Expected production qOrder/pos and two same-Prop support comparison roots"
  let mut sourceOnlyAuditReports : Array Json := #[]
  for sr in allSourceRows do
    let n ← checked (decodeName (← checked (field sr "nameExpr")))
    let sourceOnly := oldSupport.contains n
    let selectedRoles := roles.filter fun r => (field r "nameExpr").toOption == some (encodeName n)
    unless selectedRoles.size == 1 do throwError "Missing unique actual source declaration role"
    unless (← checked (stringField selectedRoles[0]! "role")) ==
        (if sourceOnly then "source-only-eliminated-old-API-proof-support" else "cross-version-common-core-comparison-candidate") do
      throwError "Source declaration role differs from exact allowed scope"
    if sourceOnly then
      unless (← boolField sr "isProposition") && (← boolField sr "valueRead") &&
          (← boolField sr "kernelValueTypeMatchesActualTYPE") do
        throwError "Source-only support must retain actual complete checked proof"
      for label in #["TYPE","value"] do
        let chosen := sourceCertificates.filter fun c =>
          (field c "nameExpr").toOption == some (encodeName n) && (stringField c "label").toOption == some label
        unless chosen.size == 1 do throwError "Missing complete source-only support certificate"
        let c := chosen[0]!
        unless (← boolField c "sourceCompleteKernelNormalizationChecked") &&
            (← boolField c "sourceOnlyEliminatedAPIProofSupport") &&
            !(← boolField c "versionIndependentTemplateRequired") do
          throwError "Source-only proof must not be declared a cross-version correspondence"
        sameBound "source-only actual raw expression preserved"
          (← checked (field sr (if label == "TYPE" then "actualTypeExpr" else "actualValueExpr")))
          (← checked (field c "rawExpression"))
      sourceOnlyAuditReports := sourceOnlyAuditReports.push (Json.mkObj [
        ("source",toJson n.toString),("sourceNameExpr",encodeName n),
        ("sourceCompleteTYPEAndProofKernelAuditBound",toJson true),
        ("sourceOnlyEliminatedOldAPIProof",toJson true),("sameBasenameNativeCorrespondenceClaimed",toJson false)])
  let nativeRows ← checked (arrayField data "nativeRecords")
  let nativePairs ← checked (arrayField data "nativeActualPairs")
  unless nativeRows.size == 4 && nativePairs.size == 4 do throwError "Expected four actual comparable native roots"
  let mut maps : NameMap := #[]
  for p in (← checked (arrayField data "allActualProjectPairs")) do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    if let some prior := maps.find? (·.1 == s) then
      unless prior.2 == t do throwError "Conflicting actual source Name maps"
    else maps := maps.push (s,t) |>.push (t,t)
  for n in oldSupport do
    if maps.any (·.1 == n) then throwError "Eliminated source old-API proof must not have any target Name map"
  let env ← getEnv
  let nativeUnmappedProofRecords ← checked (arrayField data "nativeUnmappedOldAPIProofRecords")
  unless nativeUnmappedProofRecords.size == 2 do throwError "Expected two distinct native finite/free proof records"
  let mut nativeUnmappedProofReports : Array Json := #[]
  for nr in nativeUnmappedProofRecords do
    let n ← checked (decodeName (← checked (field nr "nameExpr")))
    let ci ← getConstInfo n
    sameBound "native unpaired proof complete TYPE" (← checked (encodeExpr ci.type))
      (← checked (field nr "actualTypeExpr"))
    let some value := ci.value? (allowOpaque := true) | throwError "Native unpaired API proof has no complete value"
    sameBound "native unpaired proof complete value" (← checked (encodeExpr value))
      (← checked (field nr "actualValueExpr"))
    unless ← isProp ci.type do throwError "Native unpaired API support is not a proof"
    let inferred ← kernelCheck s!"native unpaired full API proof {n}" value
    kernelEq s!"native unpaired full API proof TYPE {n}" inferred ci.type
    let axs ← collectAxioms n
    ensureStandard s!"native unpaired API proof {n}" axs
    nativeUnmappedProofReports := nativeUnmappedProofReports.push (Json.mkObj [
      ("native",toJson n.toString),("nativeNameExpr",encodeName n),
      ("completeNativeTYPEAndProofKernelChecked",toJson true),
      ("sourceProofMathematicalCorrespondenceClaimed",toJson false),
      ("axioms",toJson (axs.map Name.toString))])
  let diagnosticOutput ← checked (stringField cfg "outputFile")
  let inverse (n : Name) : Except String Name := do
    if let some p := maps.find? (fun p => p.2 == n && p.1 != p.2) then return p.1
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual inverse TateInputs structural Name {n}"
    return n
  let mut reports : Array Json := #[]
  let mut completeExpressionCount := 0
  let mut structureCount := 0
  let mut projectionCount := 0
  let mut constructorCount := 0
  let mut recursorCount := 0
  let mut ruleCount := 0
  for sourceRow in rawSourceRows do
    let sourceName ← checked (field sourceRow "nameExpr")
    let s ← checked (decodeName sourceName)
    let selectedPair := nativePairs.filter fun p => (field p "sourceNameExpr").toOption == some sourceName
    unless selectedPair.size == 1 do throwError "Missing exact native TateInputs source correspondence candidate"
    let t ← checked (decodeName (← checked (field selectedPair[0]! "targetNameExpr")))
    let nativeSelected := nativeRows.filter fun r => (field r "nameExpr").toOption == some (encodeName t)
    unless nativeSelected.size == 1 do throwError "Missing native actual TateInputs full record"
    let nativeRow := nativeSelected[0]!
    let ci ← getConstInfo t
    sameBound "live complete native TYPE" (← checked (encodeExpr ci.type)) (← checked (field nativeRow "actualTypeExpr"))
    sameBound "live actual native owner" (toJson ((moduleOf env t).map Name.toString)) (← checked (field nativeRow "owner"))
    unless kind ci == (← checked (stringField sourceRow "kind")) do throwError "Actual source/native constant kind differs"
    unless (← boolField sourceRow "isInstance") == Lean.Meta.isInstanceCore env t do
      throwError "Actual source/native instance registration differs"
    let rawSourceTYPE ← checked (relocateExpr maps #[] #[] true (← checked (field sourceRow "actualTypeExpr")))
    unless outerForallBinderInfo rawSourceTYPE == outerForallBinderInfo ci.type do
      throwError "Original source/native public TYPE BinderInfo differs"
    let sourceUniverses ← namesFromJson (← checked (field sourceRow "levelParams"))
    unless sourceUniverses.length == ci.levelParams.length do throwError "Actual public universe arity differs"
    let commonLevels := (List.range sourceUniverses.length).map fun i => Level.param (.num (.str .anonymous "_TateCoreConsumerUniverse") i)
    let mut expressionReports : Array Json := #[]
    for label in #["TYPE","value"] do
      let rawJson ← checked (field sourceRow (if label == "TYPE" then "actualTypeExpr" else "actualValueExpr"))
      if rawJson != Json.null then
        let certificates := sourceCertificates.filter fun c =>
          (field c "nameExpr").toOption == some sourceName && (stringField c "label").toOption == some label
        unless certificates.size == 1 do throwError "Missing unique actual source normalization certificate {s}:{label}"
        let certificate := certificates[0]!
        sameBound "source certificate full raw Expr" rawJson (← checked (field certificate "rawExpression"))
        let nativeExpr ← if label == "TYPE" then pure ci.type else
          match ci.value? (allowOpaque := true) with
          | none => throwError "Missing complete native actual value"
          | some v => do
            sameBound "native actual complete value" (← checked (encodeExpr v)) (← checked (field nativeRow "actualValueExpr"))
            pure v
        unless !(← boolField certificate "sourceOnlyEliminatedAPIProofSupport") &&
            (← boolField certificate "versionIndependentTemplateRequired") do
          throwError "Comparable production/support root requires a version-independent complete template"
        let templateJson ← checked (field (← checked (field certificate "samePropCompatibilityTemplateCertificate")) "completeProofFunctionTemplate")
        let templateExpr ← checked (relocateExpr maps #[] #[] true templateJson)
        for n in oldSupport do
          if templateExpr.getUsedConstants.contains n then
            throwError "Source-only old API support remains reachable in complete production template"
        let result ← instantiateSourceTemplate maps certificate nativeExpr (label == "TYPE") diagnosticOutput sourceUniverses ci.levelParams commonLevels
        completeExpressionCount := completeExpressionCount + 1
        expressionReports := expressionReports.push (result.setObjVal! "label" (toJson label))
    let metadata ← checked (field sourceRow "metadata")
    let sourceRules ← checked (arrayField metadata "recursorRules")
    if let .recInfo recursor := ci then
      recursorCount := recursorCount + 1
      unless sourceRules.size == recursor.rules.length do throwError "Actual complete recursor rule count differs"
      for i in [:recursor.rules.length] do
        let label := s!"recursorRHS:{i}"
        let certificates := sourceCertificates.filter fun c =>
          (field c "nameExpr").toOption == some sourceName && (stringField c "label").toOption == some label
        unless certificates.size == 1 do throwError "Missing actual source full recursor RHS certificate"
        sameBound "actual source recursor RHS" (← checked (field sourceRules[i]! "rhs"))
          (← checked (field certificates[0]! "rawExpression"))
        let result ← instantiateSourceTemplate maps certificates[0]! recursor.rules[i]!.rhs false diagnosticOutput sourceUniverses ci.levelParams commonLevels
        completeExpressionCount := completeExpressionCount + 1
        ruleCount := ruleCount + 1
        expressionReports := expressionReports.push (result.setObjVal! "label" (toJson label))
    else unless sourceRules.isEmpty do throwError "Unexpected source recursor RHS"
    sameBound "actual complete constructor/recursor/computation metadata"
      (← checked (field metadata "computationShape")) (← checked (computationShape ci inverse))
    let sourceStructure ← checked (field metadata "structure")
    if sourceStructure != Json.null then
      let some info := getStructureInfo? env t | throwError "Missing actual TateInputs structure metadata"
      let sourceShape ← checked (field sourceStructure "completeMetadata")
      sameBound "complete TateInputs structure metadata" (← canonicalStructureMetadata sourceShape)
        (← canonicalStructureMetadata (← checked (structureShape info inverse)))
      let fields ← checked (arrayField sourceShape "fieldNamesInConstructorOrder")
      unless fields.size == 4 && info.fieldNames.size == 4 do throwError "TateInputs complete four fields changed"
      let aps ← checked (arrayField sourceStructure "fieldAutoParamExprs")
      unless aps.size == 4 && aps.all (· == Json.null) && info.fieldInfo.all (fun p => p.autoParam?.isNone) do
        throwError "TateInputs actual autoParam metadata changed"
      structureCount := structureCount + 1
      projectionCount := fields.size
    else if (getStructureInfo? env t).isSome then throwError "Unexpected target structure metadata"
    if let .ctorInfo _ := ci then constructorCount := constructorCount + 1
    let axs ← collectAxioms t
    ensureStandard s!"live actual native declaration {t}" axs
    reports := reports.push (Json.mkObj [
      ("source",toJson s.toString),("target",toJson t.toString),
      ("completeActualExprReports",Json.arr expressionReports),
      ("sourceLevelParams",← checked (field sourceRow "levelParams")),
      ("nativeLevelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
      ("axioms",toJson (axs.map Name.toString)),("hasSorryAx",toJson (axs.contains `sorryAx))])
  unless completeExpressionCount == 8 && structureCount == 0 && projectionCount == 0 &&
      constructorCount == 0 && recursorCount == 0 && ruleCount == 0 do
    throwError "Complete TateInputs expression/structure/constructor/recursor coverage differs"
  let output ← checked (stringField cfg "outputFile")
  writeOutput output (Json.mkObj [
    ("schema",toJson "B1-qOrder-common-core-consumer/v139"),
    ("status",toJson "accepted"),("group",toJson "qOrder-support"),("correspondenceAccepted",toJson true),("reports",Json.arr reports),
    ("wholeDataCommonCoreKernelEqual",toJson true),
    ("classCorrespondenceAssumed",toJson false),
    ("proofParametersAddedToProductionDefinitions",toJson false),
    ("completeStructureMetadataReviewed",toJson true),("completeExpressionCount",toJson completeExpressionCount),
    ("structureCount",toJson structureCount),("projectionCount",toJson projectionCount),
    ("constructorCount",toJson constructorCount),("recursorCount",toJson recursorCount),("recursorRuleCount",toJson ruleCount),
    ("actualPairs",Json.arr nativePairs),
    ("sourceRecordCount",toJson allSourceRows.size),("sourceOnlyEliminatedSupportAudits",Json.arr sourceOnlyAuditReports),
    ("completeStrictComparableRootCount",toJson rawSourceRows.size),
    ("allSixSourceRecordsKernelAudited",toJson true),
    ("allSixNativeOriginalRecordsLegallyAuditedInNativeTwenty",toJson true),
    ("nativeUnpairedOldAPIProofAudits",Json.arr nativeUnmappedProofReports),
    ("sixSameBasenameMathematicalCorrespondencesClaimed",toJson false),
    ("configuration",cfg)])
  logInfo "qOrder production roots and two same-Prop helpers accepted; source-only API support preserved without false mapping"
end BasicNativeCompare
