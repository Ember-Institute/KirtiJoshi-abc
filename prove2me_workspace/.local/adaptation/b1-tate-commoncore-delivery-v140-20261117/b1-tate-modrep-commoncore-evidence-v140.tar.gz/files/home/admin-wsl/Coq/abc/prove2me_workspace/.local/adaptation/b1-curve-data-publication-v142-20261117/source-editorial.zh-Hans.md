## 论文原文背景

望月新一，*Arithmetic Elliptic Curves in General Position*，2009 年 2 月版，第 3 节，局部设定段落，印刷页与文件页均为第 14–15 页；第 15 页从“Let $l$”开始、至“Also”之前的连续作用完整句；引理 3.2 之前以“The Tate parameter is”开始的完整句；以及第 15 页定义 3.3 全文。精确英文引文分别列于上方英文部分，中间未引用的正合列与引理段落已省略。

官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(c) 首句，至定义 $K$ 为止，印刷页与文件页均为第 62 页。精确英文引文见英文部分。其后以“Also”开始的句子及该项其余内容未引用。

官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

## 适配范围

原文的局部设定是在局部整数环上的一维半 Abel 概形，其特殊纤维是乘法群；这为 Tate 参数及其正离散阶提供背景。实际的 `TateInputs` 记录在 `badAll` 的所有位上提供四个族：Tate 参数、该参数的 Tate 曲线的 j 不变量与所保存曲线的 j 不变量经嵌入所得像的相等式、选定的【译名待定：uniformizer】，以及该元素的完整范数幂条件。记录不提供曲线同构或 Tate 一致化。本四字段接口及其显式 j 不变量相等式不称为论文中的逐字段原文。

原文将整数值赋值归一化为满射。`qOrder` 中的归一化通过给定的【译名待定：uniformizer】表达：选出的整数 $n_w$ 满足 $\lVert q_w\rVert=\lVert\pi_w\rVert^{n_w}$，转为自然数后仍为正。这是此处使用的离散局部阶，不是将在有理剩余特征处取值归一化为 1 的赋值。一行引理使用带阶参数记录中的正阶字段，是给定数据的辅助推论，不是这些数据的存在性定理。

原文的局部挠点段落要求 $l$ 为素数，并陈述非典范的模同构及连续作用。整体段落使用选定素数 $l\geq5$、特殊线性群像条件，以及由核确定的有限 Galois 扩张。这些构成原始数学背景。实际的 `ModEllRepData` 记录则接受任意自然数 $\ell$，并提供四个字段：到 `ZMod ℓ` 上两个坐标的**加法群同构**、取值于矩阵群的群同态、对每个挠点与坐标作用相容的等式，以及核在 Krull 拓扑下的开性。第一个字段不是另行声明的线性基。上述引文不为记录增添素数假设、特殊线性群像条件或存在性结论。

两个记录都针对同一组固定椭圆曲线数据及选定代数闭包，但它们是两种独立的给定数据类型。坏位集合允许为空。本定义不选取这些数据，不证明它们存在，也不断言高度估计或 abc 结论。

## 直观解释（非严格）

局部记录在每个乘法约化位保存一个小的 Tate 参数，以及衡量其离散阶的尺度。表示记录保存挠点群的坐标和描述这些坐标下 Galois 作用的矩阵。把相容条件保存在记录中，可使后续使用始终针对同一组给定选择。

