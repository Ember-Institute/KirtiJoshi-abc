from pathlib import Path
import json,hashlib,shutil,re
from datetime import datetime,timezone
O=Path('/tmp/p2m-b1-curve-data-publication-v141-20261117');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');F=Path('/tmp/p2m-b1-tate-modrep-fresh-blind-v127-20261117');S=W/'Definitions/Def_AbcAdaptation_Reference_Iut_Concrete_CurveData.lean'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
frozen={str(p):sha(p) for p in F.rglob('*') if p.is_file()}
bm=json.loads((F/'manifest.json').read_text());assert sha(S)==bm['code_sha256']
pc=json.loads((O/'paper-context.json').read_text());qs={q['id']:q for q in pc['quotations']};G=pc['papers']['GenEll'];I=pc['papers']['I']
cover=O/'paper-evidence/GenEll-cover.png';pc['visual_evidence'].append(dict(visual_checked_this_editorial_task=True,**rec(cover)));(O/'paper-context.json').write_text(json.dumps(pc,ensure_ascii=False,indent=2)+'\n')
source_en='''## Original paper context

Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position* (February 2009), §3, local-setting paragraph spanning printed/PDF pages 14–15:

> '''+qs['GenEll-local-setting']['quote_markdown']+'''

On printed/PDF page 15, the paragraph beginning “Let $l$”, through the complete continuous-action sentence before “Also”, states:

> '''+qs['GenEll-local-mod-l']['quote_markdown'].replace('\n','\n> ')+'''

The same page, in the paragraph before Lemma 3.2, gives the following complete sentence about the Tate parameter:

> '''+qs['GenEll-Tate-parameter']['quote_markdown']+'''

Definition 3.3 on printed/PDF page 15 states, in full:

> '''+qs['GenEll-Definition-3.3']['quote_markdown']+'''

Official original: '''+G['official_url']+'''. Local original: `'''+G['local_pdf']+'''`. These excerpts are separate; the unquoted exact-sequence and lemma passages between them are omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(c), first sentence through the definition of $K$, printed/PDF page 62:

> '''+qs['I-Definition-3.1c']['quote_markdown'].replace('\n','\n> ')+'''

Official original: '''+I['official_url']+'''. Local original: `'''+I['local_pdf']+'''. The subsequent sentence beginning “Also” and the rest of item (c) are omitted.

## Adaptation scope

The local paper setting is a split multiplicative semi-abelian model over a local integer ring. It supplies background for the Tate parameter and its positive discrete order. The actual `TateInputs` record supplies four families over all places in `badAll`: a Tate parameter, equality of its Tate j-invariant with the embedded j-invariant of the stored curve, a chosen uniformizer, and the full norm-power condition for that uniformizer. The record does not supply an isomorphism of curves or a Tate uniformization. The four-field interface and its explicit j-invariant equality are not presented as a verbatim paragraph of the paper.

The paper normalizes its integer-valued valuation to be surjective. In the definition `qOrder`, the normalization is expressed through the supplied uniformizer: the chosen integer $n_w$ satisfies $\\lVert q_w\\rVert=\\lVert\\pi_w\\rVert^{n_w}$. Its conversion to a natural number is positive. This is the discrete local order used here; it is not a valuation normalized to take value 1 on the rational residue characteristic. The one-line lemma uses the positive-order field of the ordered parameter. It is a supporting consequence of the supplied data, not an existence theorem for those data.

The paper's local torsion passage assumes that $l$ is prime and states a noncanonical module isomorphism and a continuous action. The global passage uses a chosen prime $l\\geq5$, a special-linear image condition, and a finite Galois extension determined by the kernel. These are the original mathematical backgrounds. The actual `ModEllRepData` record instead accepts any natural number $\\ell$ and supplies four fields: an **additive-group isomorphism** to two coordinates over `ZMod ℓ`, a matrix-valued group homomorphism, equality with the coordinate action on every torsion point, and openness of its kernel in the Krull topology. The first field is not a separately declared linear basis. No primality assumption, special-linear image condition, or existence statement is added to that record by these quotations.

Both records concern the same fixed elliptic-curve data and selected closure, but are separate types of supplied data. The bad set may be empty. This definition does not choose the data, prove their existence, or assert a height estimate or an abc conclusion.

## Intuitive explanation (non-rigorous)

The local record keeps a small Tate parameter and a scale for measuring its discrete order at each multiplicative place. The representation record keeps coordinates on the torsion group and matrices describing the Galois action in those coordinates. Keeping the compatibility conditions in the records makes each later use refer to the same supplied choices.
'''
source_zh='''## 论文原文背景

望月新一，*Arithmetic Elliptic Curves in General Position*，2009 年 2 月版，第 3 节，局部设定段落，印刷页与文件页均为第 14–15 页；第 15 页从“Let $l$”开始、至“Also”之前的连续作用完整句；引理 3.2 之前以“The Tate parameter is”开始的完整句；以及第 15 页定义 3.3 全文。精确英文引文分别列于上方英文部分，中间未引用的正合列与引理段落已省略。

官方原文：'''+G['official_url']+'''。本地原文：`'''+G['local_pdf']+'''`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(c) 首句，至定义 $K$ 为止，印刷页与文件页均为第 62 页。精确英文引文见英文部分。其后以“Also”开始的句子及该项其余内容未引用。

官方原文：'''+I['official_url']+'''。本地原文：`'''+I['local_pdf']+'''`。

## 适配范围

原文的局部设定是在局部整数环上的一维半 Abel 概形，其特殊纤维是乘法群；这为 Tate 参数及其正离散阶提供背景。实际的 `TateInputs` 记录在 `badAll` 的所有位上提供四个族：Tate 参数、该参数的 Tate 曲线的 j 不变量与所保存曲线的 j 不变量经嵌入所得像的相等式、选定的【译名待定：uniformizer】，以及该元素的完整范数幂条件。记录不提供曲线同构或 Tate 一致化。本四字段接口及其显式 j 不变量相等式不称为论文中的逐字段原文。

原文将整数值赋值归一化为满射。`qOrder` 中的归一化通过给定的【译名待定：uniformizer】表达：选出的整数 $n_w$ 满足 $\\lVert q_w\\rVert=\\lVert\\pi_w\\rVert^{n_w}$，转为自然数后仍为正。这是此处使用的离散局部阶，不是将在有理剩余特征处取值归一化为 1 的赋值。一行引理使用带阶参数记录中的正阶字段，是给定数据的辅助推论，不是这些数据的存在性定理。

原文的局部挠点段落要求 $l$ 为素数，并陈述非典范的模同构及连续作用。整体段落使用选定素数 $l\\geq5$、特殊线性群像条件，以及由核确定的有限 Galois 扩张。这些构成原始数学背景。实际的 `ModEllRepData` 记录则接受任意自然数 $\\ell$，并提供四个字段：到 `ZMod ℓ` 上两个坐标的**加法群同构**、取值于矩阵群的群同态、对每个挠点与坐标作用相容的等式，以及核在 Krull 拓扑下的开性。第一个字段不是另行声明的线性基。上述引文不为记录增添素数假设、特殊线性群像条件或存在性结论。

两个记录都针对同一组固定椭圆曲线数据及选定代数闭包，但它们是两种独立的给定数据类型。坏位集合允许为空。本定义不选取这些数据，不证明它们存在，也不断言高度估计或 abc 结论。

## 直观解释（非严格）

局部记录在每个乘法约化位保存一个小的 Tate 参数，以及衡量其离散阶的尺度。表示记录保存挠点群的坐标和描述这些坐标下 Galois 作用的矩阵。把相容条件保存在记录中，可使后续使用始终针对同一组给定选择。
'''
source_ja='''## 論文原文の背景

望月新一、*Arithmetic Elliptic Curves in General Position*、2009 年 2 月版、第 3 節、局所的な設定の段落、印刷・PDF ファイルページ 14–15、ページ 15 の「Let $l$」から「Also」の前の連続作用に関する完全な文まで、補題 3.2 の前の「The Tate parameter is」で始まる完全な文、およびページ 15 の定義 3.3 全文。正確な英文は上の英語部分でそれぞれ引用した。間にある正確列と補題の引用していない部分は省略した。

公式原文：'''+G['official_url']+'''。ローカル原文：`'''+G['local_pdf']+'''`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(c) の最初の文から $K$ の定義まで、印刷・PDF ファイルページ 62。正確な英文は英語部分に示した。続く「Also」で始まる文と、この項の残りは引用しない。

公式原文：'''+I['official_url']+'''。ローカル原文：`'''+I['local_pdf']+'''`。

## 移植の範囲

論文の局所的設定は、局所整数環上の一次元半アーベルスキームであり、その特殊ファイバーは乗法群である。これはテイト・パラメータとその正の離散的な位数の背景を与える。実際の `TateInputs` レコードは、`badAll` のすべての素点上で四つの族を与える。テイト・パラメータ、そのテイト曲線の j 不変量と格納された曲線の j 不変量の埋込みによる像との等式、選ばれた一様化元、およびその一様化元の完全なノルムの冪条件である。このレコードは曲線の同型やテイト一様化を与えない。この四フィールドのインターフェースと明示的な j 不変量の等式を、論文の逐語的なフィールド一覧とはしない。

論文は整数値付値を全射となるよう正規化する。`qOrder` では、与えられた一様化元を用いて正規化する。選ばれた整数 $n_w$ は $\\lVert q_w\\rVert=\\lVert\\pi_w\\rVert^{n_w}$ を満たし、自然数への変換後も正である。これはここで用いる離散的な局所の位数であり、有理剰余標数での値を 1 にする付値ではない。一行の補題は、順序を付したパラメータのレコードにある正値性のフィールドを用いる。与えられたデータの補助的帰結であり、データの存在定理ではない。

論文の局所的な等分点の段落は $l$ を素数と仮定し、非標準的な加群同型と連続作用を述べる。大域的な段落は、選ばれた素数 $l\\geq5$、特殊線形群の像条件、および核で定まる有限ガロア拡大を用いる。これらは原文の数学的背景である。一方、実際の `ModEllRepData` レコードは任意の自然数 $\\ell$ を受け取り、四つのフィールドを与える。`ZMod ℓ` の二つの座標への**加法群同型**、行列群に値を取る群準同型、各等分点で座標作用と両立する等式、およびクルル位相での核の開性である。第一のフィールドは、別に宣言された線形な基底ではない。これらの引用によって、素数という仮定、特殊線形群の像条件、存在の主張をレコードへ加えない。

二つのレコードは同じ固定した楕円曲線データと指定された代数閉包に関するものであるが、別々の型の入力データである。悪い素点の集合は空でもよい。この定義はデータを選ばず、その存在を証明せず、高さの評価や abc の結論も主張しない。

## 直観的説明（非厳密）

局所レコードは各乗法的還元素点で小さなテイト・パラメータと、その離散的な位数を測る尺度を保持する。表現レコードは等分点群の座標と、その座標でガロア作用を記述する行列を保持する。両立条件をレコードに含めることで、後の利用は同じ入力の選択に関するものになる。
'''
# Keep the complete mathematical readback, excluding only its process preface before unit 1.
readbacks={'en':(F/'original_readback.en.md').read_text(),'zh-Hans':(F/'readback.zh-Hans.md').read_text(),'ja':(F/'readback.ja.md').read_text()}
math={k:v[v.index('## 1. `TateInputs`'): ] for k,v in readbacks.items()}
statement='\n\n'.join('# '+label+'\n\n'+math[k].rstrip()+'\n\n'+src for k,label,src in [('en','English',source_en),('zh-Hans','简体中文',source_zh),('ja','日本語',source_ja)])+'\n'
for k,s in [('en',source_en),('zh-Hans',source_zh),('ja',source_ja)]:(O/f'source-editorial.{k}.md').write_text(s+'\n')
(O/'natural-language-statement.md').write_text(statement)
payload={'definition_name':'AbcAdaptation_Reference_Iut_Concrete_CurveData','definition_title':'Local Tate inputs, positive parameter orders, and torsion representations — 局部 Tate 输入、正参数阶与挠点表示 — 局所テイト入力・正のパラメータ位数・等分点表現','definition':S.read_text(),'natural_language_statement':statement,'source':'Shinichi Mochizuki, Arithmetic Elliptic Curves in General Position, February 2009, §3, local setting pp. 14–15, mod-l module and continuous-action paragraph p. 15, Tate-parameter sentence before Lemma 3.2 p. 15, and complete Definition 3.3 p. 15; Inter-universal Teichmüller Theory I: Construction of Hodge Theaters, May 2020, §3, Definition 3.1(c), first sentence through the definition of K, p. 62. Printed and PDF file pages agree. These are original mathematical backgrounds; the supplied four-field records and their arbitrary-natural-number parameter are not claimed to be verbatim paper interfaces. '+G['official_url']+' '+I['official_url'],'env':'0df444a360eaa60ab8c11dca51a86af692955474','private':True}
(O/'payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
(O/'independent-readback').mkdir(exist_ok=True)
for p in F.iterdir():
 if p.is_file():shutil.copyfile(p,O/'independent-readback'/p.name)
# Full formal snapshots remain frozen at F/inputs; hash them without copying the complete dependency tree again.
receipts=[]
for n in ['b1-curve-tate-modrep-data-leaf-v126-result.json','b1-curve-tate-modrep-data-artifact-v127-result.json','b1-tate-commoncore-deepbeta-review-v137-result.json','b1-mod-elliptic-representation-seven-review-v129-result.json','b1-qorder-source-normalization-v139-result.json']:
 p=W/'.local/adaptation/main-chain-open-20261116'/n;d=json.loads(p.read_text());assert d['status']=='succeeded' and d['result']['exit_code']==0
 receipts.append({'receipt':rec(p),'job_id':d['job_id'],'status':d['status'],'exit_code':d['result']['exit_code'],'resources':d['resources'],'review':d['result'].get('review')})
meta={'schema':'B1-CurveData-private-definition-academic-draft/v141','status':'DRAFT_NOT_POSTED_PENDING_QORDER_TARGET_KERNEL_REVIEW','created_utc':datetime.now(timezone.utc).isoformat(),'editorial_model':'gpt-6.1-sol','editorial_not_new_independent_blind_readback':True,'source':rec(S),'payload':rec(O/'payload.json'),'paper_context':rec(O/'paper-context.json'),'independent_readback':{'directory':str(F),'model':'gpt-6.1-sol','all_files_including_formal_snapshots_sha256':frozen,'originals_unchanged':all(sha(Path(p))==v for p,v in frozen.items()),'mathematical_bodies_reused_verbatim':True,'only_process_preface_before_unit_1_omitted_from_product_body':True,'original_process_prefaces_preserved_in_frozen_originals_and_local_copy':True,'translations_not_separate_independent_audits':True},'field_inventory':{'TateInputs':['tate','tateJ_eq','unif','unif_isUniformizer'],'ModEllRepData':['torsionBasis','rep','rep_spec','ker_isOpen']},'associated_declarations':['TateInputs.qOrder','TateInputs.qOrder_pos'],'normalization':{'input_C_implicit_for_order_and_pos':True,'place_and_membership_proof_required':True,'integer_exponent_norm_q_equals_norm_pi_pow_n':True,'Int_toNat_conversion_positive_not_truncating_here':True,'not_rational_prime_normalization':True,'no_order_at_places_without_membership_proof':True},'representation_boundaries':{'torsionBasis_actual_additive_equivalence':True,'no_separate_linear_basis_field':True,'all_natural_ell_including_zero_one_composite':True,'ZMod_zero_is_integers':True,'kernel_open_Krull_topology':True,'no_SL2_image_requirement':True,'no_existence_claim':True},'Chinese_uniformizer':{'value':'【译名待定：uniformizer】','user_confirmation_received':False,'reasked':False},'accepted_existing_evidence':receipts,'publication_gate':{'TateInputs_seven_target_kernel':'accepted in saved ci-018655-107096d5 receipt','ModEllRepData_seven_target_kernel':'accepted in saved ci-018625-581f9567 receipt','qOrder_six_target_kernel':'pending per parent task message; source normalization success is not substituted for target acceptance','whole_definition_published':False,'do_not_publish_before_qOrder_acceptance':True},'operations':{'CI_compiler_API_Git_executed':False,'main_workspace_written':False,'frozen_originals_changed':False,'publication_performed':False},'process_information_confined_to_metadata':True}
(O/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
assert len(payload)==7 and payload['private'] and payload['env']=='0df444a360eaa60ab8c11dca51a86af692955474'
assert all(v.rstrip() in statement for v in math.values())
assert all(sha(Path(p))==v for p,v in frozen.items())
assert '【译名待定：uniformizer】' in statement
assert not re.search(r'ci-\d|gpt-|SHA.?256|\bhash\b|\bCI\b|编译|コンパイル',statement,re.I)
checks={'seven_payload_keys':list(payload),'canonical_code_byte_identical':True,'four_Tate_fields_and_four_ModRep_fields_retained':True,'qOrder_and_qOrder_pos_retained':True,'all_original_math_units_reused_verbatim':True,'all_original_blind_files_unchanged':True,'uniformizer_placeholder_retained':True,'no_process_preface_model_hash_or_CI_in_product_body':True,'exact_original_paper_quotes_visually_checked':True,'paper_scope_limits_explicit':True,'publication_blocked_pending_qOrder_target_acceptance':True,'not_posted':True}
(O/'validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'payload_sha256':sha(O/'payload.json'),'source_sha256':sha(S),'publication_status':meta['status'],'directory':str(O)},ensure_ascii=False,indent=2))
