from pathlib import Path
import json,hashlib,shutil
O=Path('/tmp/p2m-b1-curve-data-publication-v141-20261117');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
ctx=W/'.local/adaptation/tate28-delivery-20261116/paper-context.TateFamily.json';d=json.loads(ctx.read_text())
qsetting=next(q for q in d['quotations'] if q.get('id')=='GenEll-local-setting') if any(q.get('id')=='GenEll-local-setting' for q in d['quotations']) else None
for q in d['quotations']:
 if q['paper_id']=='GenEll' and 14 in q.get('printed_pages',[]):qsetting=q
assert qsetting
qparam=next(q for q in d['quotations'] if q.get('id')=='GenEll-tate-parameter')
# Keep only its second complete sentence; the omitted first depends on an exact sequence outside this packet.
qparamtext=qparam['quote_markdown'].split('The Tate parameter is',1)[1]
qparamtext='The Tate parameter is'+qparamtext
qbasis=r'''Let $l$ be a prime number [possibly equal to $p$]; write

$$M_l(E)\overset{\mathrm{def}}{=}\operatorname{Hom}(\mathbb Z/l\cdot\mathbb Z,E(\overline K))$$

for the “mod $l$” Tate module of $E_K$. Thus, $M_l(E)$ is [noncanonically] isomorphic as an $\mathbb F_l$-module to $\mathbb F_l\times\mathbb F_l$ and, moreover, is equipped with a continuous action by $G_K$ induced by the natural action of $G_K$ on $\overline K$.'''
qheight=r'''We shall refer to the positive integer $v_K(q_E)\in\mathbb Z_{>0}$ as the local height of $E$ [or $E_K$].'''
base=W/'.local/adaptation/foundation-reference-carriers-20261115/paper-context.json';bd=json.loads(base.read_text());qi=next(q for q in bd['quotations'] if q['id']=='I-torsion-extension')
quotes=[{'id':'GenEll-local-setting','paper':'GenEll','locator':qsetting['locator'],'printed_pages':[14,15],'file_pages':[14,15],'quote_markdown':qsetting['quote_markdown']},{'id':'GenEll-local-mod-l','paper':'GenEll','locator':'§3, paragraph beginning Let l; through the continuous-action sentence, before Also','printed_pages':[15],'file_pages':[15],'quote_markdown':qbasis},{'id':'GenEll-Tate-parameter','paper':'GenEll','locator':'§3, paragraph before Lemma 3.2, complete sentence beginning The Tate parameter is','printed_pages':[15],'file_pages':[15],'quote_markdown':qparamtext},{'id':'GenEll-Definition-3.3','paper':'GenEll','locator':'§3, Definition 3.3, complete definition','printed_pages':[15],'file_pages':[15],'quote_markdown':qheight},{'id':'I-Definition-3.1c','paper':'I','locator':'§3, Definition 3.1(c), first sentence through definition of K; subsequent Also sentence omitted','printed_pages':[62],'file_pages':[62],'quote_markdown':qi['quote_markdown']}]
papers={k:d['paper_sources'][k] for k in ['GenEll','I']}
for paper in papers.values():assert sha(Path(paper['local_pdf']))==paper['sha256']
imgs=[(W/'.local/adaptation/reference-volume-tate-carriers-20261115/paper-context-evidence/GenEll-014.png','GenEll-014.png'),(W/'.local/adaptation/reference-volume-tate-carriers-20261115/paper-context-evidence/GenEll-015.png','GenEll-015.png'),(Path('/tmp/p2m-b1-arithmetic-publication-v126-20261117/paper-evidence/I-062.png'),'I-062.png')]
evidence=[]
for p,n in imgs:
 t=O/'paper-evidence'/n;shutil.copyfile(p,t);evidence.append(dict(visual_checked_this_editorial_task=True,**rec(t)))
pcontext={'schema':'B1-CurveData-Mochizuki-original-context/v141','author':'Shinichi Mochizuki','author_zh_ja':'望月新一','papers':papers,'quotations':quotes,'visual_evidence':evidence,'typography':'Line breaks, line-end hyphenation and ligatures normalized; mathematical typography transcribed to renderable LaTeX. Every excerpt is separately located; editorial claims stay outside quotes.','editorial_not_new_independent_readback':True,'source_context_inputs':[rec(ctx),rec(base)],'source_scope':{'TateInputs':'Local Tate parameter and local curve background; tateJ_eq and chosen uniformizers are explicit supplied interface data, not a quoted four-field paper record.','qOrder_and_positive_lemma':'Discrete local valuation normalized to be surjective and the positive integer v_K(q_E) in Definition 3.3; code uses the exponent of a supplied uniformizer norm and a natural-number conversion.','ModEllRepData':'Prime-level torsion action and finite Galois extension from a kernel; code records an additive equivalence, not a separately specified linear basis, at every supplied natural ell.','no_primality_hypothesis_added_to_interface':True,'no_SL2_image_field_added':True,'no_existence_claim_added':True,'Chinese_uniformizer_term':'【译名待定：uniformizer】'},'operations':{'CI_compiler_API_Git_executed':False,'main_workspace_written':False,'network_or_download':False},'editorial_model':'gpt-6.1-sol'}
(O/'paper-context.json').write_text(json.dumps(pcontext,ensure_ascii=False,indent=2)+'\n')
print('source context ready',O/'paper-context.json')
