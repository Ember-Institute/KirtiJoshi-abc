import Lean
import B1SourceReplay

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  let m ← env.header.modules[index.toNat]?
  return m.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit

namespace B1FinitePlaceSourceNormalization
open Lean Elab Term Meta FoundationAudit
def closed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasFVar || e.hasMVar || e.hasLooseBVars then throwError "Open Expr {label}"

def kcheck (label : String) (e : Expr) : MetaM Expr := do
  closed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def keq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kcheck label e
  let ft ← kcheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

def certify (raw normalized : Expr) : MetaM Json := do
  keq "complete original/normalized Expr" raw normalized
  let equality ← mkEq raw normalized
  let proof ← mkEqRefl raw
  let pt ← kcheck "complete normalization equality proof" proof
  keq "complete normalization equality proposition" pt equality
  ensureStandard "complete normalization equality proof" (← expressionAxioms proof)
  return Json.mkObj [
    ("originalExpr",← checked (encodeExpr raw)),
    ("normalizedExpr",← checked (encodeExpr normalized)),
    ("equalityExpr",← checked (encodeExpr equality)),
    ("equalityProofExpr",← checked (encodeExpr proof)),
    ("completeExprKernelDefEq",toJson true),
    ("completeEqualityProofKernelChecked",toJson true),
    ("axioms",toJson ((← expressionAxioms proof).map Name.toString))]


def contextVars (exclude : Array Expr := #[]) : MetaM (Array Expr) := do
  return (← getLCtx).foldl (fun xs d =>
    let x := mkFVar d.fvarId
    if exclude.contains x then xs else xs.push x) (#[] : Array Expr)

def localEqEvidence (label : String) (raw normalized : Expr) : MetaM Json := do
  let locals ← contextVars
  let rawClosed ← mkLambdaFVars locals raw
  let normalizedClosed ← mkLambdaFVars locals normalized
  let certificate ← certify rawClosed normalizedClosed
  return certificate.setObjVal! "label" (toJson label)

-- These are the only computational declarations expanded. All ten source
-- arguments are supplied to real delta reduction; no class is renamed or mapped.
def normalizeCore (raw : Expr) : MetaM (Expr × Json) := do
  let events ← IO.mkRef (#[] : Array Json)
  let normalized ← Meta.transform raw (pre := fun e => do
    if e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.one_lt_absNorm_nnreal then
      unless e.getAppNumArgs == 6 do throwError "Unexpected partial one_lt_absNorm_nnreal application"
      return .done e
    if e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.instNormedFieldValuedAdicCompletion ||
        e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.instRankOneAdicCompletion then
      unless e.getAppNumArgs == 10 do throwError "Unexpected partial FinitePlace data instance application"
      let some expanded ← unfoldDefinition? e (ignoreTransparency := true) |
        throwError "Actual FinitePlace data instance failed exact delta reduction"
      let candidate := expanded.headBeta
      let expected := if e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.instNormedFieldValuedAdicCompletion
        then ``Valued.toNormedField else ``Valuation.IsRankOneDiscrete.rankOne
      unless candidate.getAppFn.isConstOf expected do throwError "Unexpected delta core head"
      let event ← localEqEvidence "exact-ten-argument-instance-delta" e candidate
      events.modify (·.push event)
      return .visit candidate
    let args := e.getAppArgs
    if e.getAppFn.isConstOf ``DFunLike.coe && args.size == 6 then
      let hom := args[4]!
      if hom.getAppFn.isConstOf ``Ideal.absNorm && hom.getAppNumArgs == 4 then
        let some expanded ← unfoldDefinition? hom (ignoreTransparency := true) |
          throwError "Cannot delta-expand actual bundled absNorm"
        let projected := mkAppN e.getAppFn (args.set! 4 expanded)
        let candidate ← withReducibleAndInstances <| whnf projected
        unless candidate.getAppFn.isConstOf ``Submodule.cardQuot do throwError "Actual absNorm did not reduce to cardQuot"
        let event ← localEqEvidence "saturated-actual-Nat-absNorm-to-cardQuot" e candidate
        events.modify (·.push event)
        return .done candidate
    if e.getAppFn.isConstOf ``Ideal.absNorm then
      throwError "Unsupported unsaturated or bundled absNorm outside the retained Prop proof"
    return .continue)
  let evidence ← events.get
  return (normalized, Json.mkObj [
    ("events",Json.arr evidence),("exactDataDeltaCount",toJson evidence.size),
    ("nonPropositionalDataReplacedWithoutKernelCertificate",toJson false)])

structure ProofSite where
  functionType : Expr
  actualProofFunction : Expr
  localBinders : Array String
  localContextIndices : Array Nat
  deriving Inhabited

def collectProofSites (core : Expr) : MetaM (Array ProofSite) := do
  let sites ← IO.mkRef (#[] : Array ProofSite)
  discard <| Meta.transform core (pre := fun e => do
    unless e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.one_lt_absNorm_nnreal do
      return .continue
    unless e.getAppNumArgs == 6 do throwError "Expected complete source one_lt_absNorm_nnreal proof application"
    let expectedType ← inferType e
    unless ← isProp expectedType do throwError "Certificate abstraction would abstract computational data"
    let (normalizedProp,_) ← normalizeCore expectedType
    let allLocals ← contextVars
    let used ← (Lean.collectFVars (Lean.collectFVars {} normalizedProp) e).addDependencies
    let localContextIndices := (Array.range allLocals.size).filter fun i =>
      used.fvarSet.contains allLocals[i]!.fvarId!
    let locals := localContextIndices.map (allLocals[·]!)
    let functionType ← mkForallFVars locals normalizedProp
    let actualProofFunction ← mkLambdaFVars locals e
    closed "certificate-only proof-function TYPE" functionType
    closed "original actual proof function" actualProofFunction
    let proofType ← kcheck "actual original one_lt proof function" actualProofFunction
    keq "actual one_lt proof function TYPE" proofType functionType
    ensureStandard "actual original proof function" (← expressionAxioms actualProofFunction)
    let localBinders ← locals.mapM fun x => return encodeBinder (← x.fvarId!.getDecl).binderInfo
    sites.modify (·.push {functionType,actualProofFunction,localBinders,localContextIndices})
    return .done e)
  return ← sites.get

-- The proof functions below are bound only in the compatibility certificate.
-- Neither a source/target production definition nor its statement receives them.
def proofTemplateCertificate (raw core : Expr) (sites : Array ProofSite) : MetaM Json := do
  let decls := sites.mapIdx fun i site => (Name.mkSimple s!"finitePlaceProofCertificate{i}", site.functionType)
  withLocalDeclsDND decls fun proofFunctions => do
    let index ← IO.mkRef (0 : Nat)
    let openedTemplate ← Meta.transform core (pre := fun e => do
      unless e.getAppFn.isConstOf ``NumberField.HeightOneSpectrum.one_lt_absNorm_nnreal do
        return .continue
      let i ← index.get
      unless i < sites.size do throwError "More template proof sites than original source occurrences"
      let allLocals ← contextVars proofFunctions
      let locals := sites[i]!.localContextIndices.map (allLocals[·]!)
      let proofFunction := proofFunctions[i]!
      let candidate := mkAppN proofFunction locals
      unless ← isDefEq (← inferType candidate) (← inferType e) do
        throwError "Certificate proof-function application is not the same actual proposition"
      index.modify (·+1)
      return .done candidate)
    unless (← index.get) == sites.size do throwError "Template proof site count changed"
    let template ← mkLambdaFVars proofFunctions openedTemplate
    closed "complete certificate-only template" template
    for forbidden in #[``NumberField.HeightOneSpectrum.instNormedFieldValuedAdicCompletion,
        ``NumberField.HeightOneSpectrum.instRankOneAdicCompletion,
        ``NumberField.HeightOneSpectrum.one_lt_absNorm_nnreal,
        ``Ring.HasFiniteQuotients, ``NumberField.RingOfIntegers.instHasFiniteQuotients,
        ``Ideal.absNorm] do
      if template.getUsedConstants.contains forbidden then
        throwError "Version-specific finite-place dependency remains in complete template: {forbidden}"
    -- Applying the original actual proof functions must reproduce the real data core.
    let originalInstantiation := mkAppN template (sites.map (·.actualProofFunction))
    let originalCertificate ← certify raw originalInstantiation
    -- Prove the complete equality for EVERY proof function of the fixed propositions.
    let openedEquality ← mkEq raw openedTemplate
    let generalizedEquality ← mkForallFVars proofFunctions openedEquality
    let openedProof ← mkEqRefl raw
    let generalizedProof ← mkLambdaFVars proofFunctions openedProof
    let inferred ← kcheck "universal complete-data compatibility equality proof" generalizedProof
    keq "universal complete-data compatibility equality TYPE" inferred generalizedEquality
    ensureStandard "universal compatibility certificate" (← expressionAxioms generalizedProof)
    let templateType ← kcheck "complete compatibility template" template
    let mut sourceProofArguments : Array Json := #[]
    for i in [:sites.size] do
      let site := sites[i]!
      sourceProofArguments := sourceProofArguments.push (Json.mkObj [
        ("occurrenceIndex",toJson i),("proofFunctionType",← checked (encodeExpr site.functionType)),
        ("actualSourceProofFunction",← checked (encodeExpr site.actualProofFunction)),
        ("originalContextBinderInfo",toJson site.localBinders),
        ("originalContextDependencyIndices",toJson site.localContextIndices),
        ("proofOnlyCertificateBinder",toJson true)])
    return Json.mkObj [
      ("completeProofFunctionTemplate",← checked (encodeExpr template)),
      ("completeProofFunctionTemplateType",← checked (encodeExpr templateType)),
      ("actualSourceProofArguments",Json.arr sourceProofArguments),
      ("universalEqualityExpr",← checked (encodeExpr generalizedEquality)),
      ("universalEqualityProofExpr",← checked (encodeExpr generalizedProof)),
      ("universalCompleteEqualityKernelChecked",toJson true),
      ("actualSourceProofInstantiationCertificate",originalCertificate),
      ("certificateOnlyProofFunctionCount",toJson sites.size),
      ("productionDefinitionParametersAdded",toJson false),
      ("nativeProofFunctionsMustMatchCompleteTYPE",toJson true)]

def normalizeOne (n : Name) (label : String) (raw : Expr) : MetaM Json := do
  let (core,delta) ← normalizeCore raw
  let certificate ← certify raw core
  ensureStandard s!"complete source raw Expr {n}:{label}" (← expressionAxioms raw)
  ensureStandard s!"complete source delta core {n}:{label}" (← expressionAxioms core)
  let sites ← collectProofSites core
  let template ← proofTemplateCertificate raw core sites
  return Json.mkObj [
    ("name",toJson n.toString),("nameExpr",encodeName n),("label",toJson label),
    ("rawExpression",← checked (encodeExpr raw)),("deltaNormalizedExpression",← checked (encodeExpr core)),
    ("wholeRawToDeltaCoreCertificate",certificate),("exactDeltaSteps",delta),
    ("samePropCompatibilityTemplateCertificate",template),
    ("rawBinderInventory",toJson (binderInventory raw)),
    ("deltaNormalizedBinderInventory",toJson (binderInventory core)),
    ("sourceCompleteKernelNormalizationChecked",toJson true),
    ("nativeCorrespondenceAccepted",toJson false)]

run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected source4.35 compiler"
  let cfg ← jsonFile (← absoluteEnv "B1_FINITEPLACE_SOURCE_NORMALIZATION_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-FinitePlace-source-normalization-config/v132" do
    throwError "Wrong finite-place source normalization config"
  let bound ← jsonFile (← checked (stringField cfg "boundInputsFile"))
  let rows ← checked (arrayField bound "sourceRecords")
  unless rows.size == 7 do throwError "Expected complete TateInputs seven actual source facts"
  let env ← getEnv
  let mut certificates : Array Json := #[]
  for row in rows do
    let n ← checked (decodeName (← checked (field row "nameExpr")))
    unless moduleOf env n == some `B1SourceReplay do throwError "Wrong actual source owner {n}"
    let ci ← getConstInfo n
    unless (← checked (field row "actualTypeExpr")) == (← checked (encodeExpr ci.type)) do
      throwError "Bound actual source TYPE differs {n}"
    certificates := certificates.push (← normalizeOne n "TYPE" ci.type)
    match ci.value? (allowOpaque := true) with
    | none => unless (← checked (field row "actualValueExpr")) == Json.null do
        throwError "Bound source value exists but actual constant has no value {n}"
    | some v =>
      unless (← checked (field row "actualValueExpr")) == (← checked (encodeExpr v)) do
        throwError "Bound actual source value differs {n}"
      certificates := certificates.push (← normalizeOne n "value" v)
    let metadata ← checked (field row "metadata")
    let rules ← checked (arrayField metadata "recursorRules")
    match ci with
    | .recInfo recursor =>
      unless rules.size == recursor.rules.length do throwError "Actual recursor rule count differs {n}"
      for i in [:recursor.rules.length] do
        let rule := recursor.rules[i]!
        unless (← checked (field rules[i]! "rhs")) == (← checked (encodeExpr rule.rhs)) do
          throwError "Bound actual recursor RHS differs {n}:{i}"
        certificates := certificates.push (← normalizeOne n s!"recursorRHS:{i}" rule.rhs)
    | _ => unless rules.isEmpty do throwError "Unexpected source recursor rules {n}"
    ensureStandard s!"actual source declaration {n}" (← collectAxioms n)
  let output ← checked (stringField cfg "outputFile")
  if let some parent := (System.FilePath.mk output).parent then IO.FS.createDirAll parent
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "B1-FinitePlace-source-common-core-normalization/v132"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("sourceRecords",Json.arr rows),("candidatePairs",← checked (field bound "candidatePairs")),
    ("normalizationCertificates",Json.arr certificates),
    ("sourceCompleteKernelNormalizationChecked",toJson true),
    ("certificateProofParametersAddedToProductionDefinitions",toJson false),
    ("classCorrespondenceAssumed",toJson false),("nativeCorrespondenceAccepted",toJson false)]).pretty ++ "\n")
end B1FinitePlaceSourceNormalization
