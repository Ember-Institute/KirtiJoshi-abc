# English

## 1. `TateInputs`

Let $u$ be a universe level, and fix $C : \mathrm{EllipticCurveData}^{u}$, a record in $\mathrm{Type}(u+1)$ consisting of a type $F=C.F : \mathrm{Type}(u)$ with field and number-field structures, a type $\overline F=C.Fbar : \mathrm{Type}(u)$ with a field structure, an $F$-algebra structure and the property of being an algebraic closure of $F$, and a Weierstrass curve $E=C.E$ over $F$ whose discriminant is a unit (equivalently, is nonzero over this field). The definition `TateInputs` specifies a record type $C.\mathrm{TateInputs}:\mathrm{Type}(u)$ with the following four fields. Write $B=C.\mathrm{badAll}$ for the set of finite places $w$ of $F$ such that there exists a Weierstrass change of variables $D$ over $F$ for which the curve $D\mathbin{\bullet}E$, after extension of scalars to the completion $F_w=w.\mathrm{maximalIdeal}.\mathrm{adicCompletion}(F)$, has multiplicative reduction over its valuation ring $R_w=w.\mathrm{maximalIdeal}.\mathrm{adicCompletionIntegers}(F)$. Here multiplicative reduction means that this local model is minimal over $R_w$, the multiplicative valuation of its discriminant is strictly less than $1$, and the multiplicative valuation of its $c_4$ is $1$; minimality means that the model is integral and its discriminant has maximal multiplicative valuation among integral models obtained by changes of variables over $F_w$. First, `tate` assigns to each $w\in B$, with its membership proof, a Tate parameter $t_w$ over the normed field $F_w$, meaning a unit $q_w=t_w.q\in F_w^\times$ with $\lVert q_w\rVert<1$; in particular $0<\lVert q_w\rVert$. Second, `tateJ_eq` requires, for every such $w$, the equality $t_w.\mathrm{tateJ}=\iota_w(j(E))$, where $\iota_w:F\to F_w$ is the canonical ring embedding, $j(E)=c_4(E)^3/\Delta(E)$, and $t_w.\mathrm{tateJ}=c_4(W_{q_w})^3/\Delta(W_{q_w})$. The curve $W_q$ in this definition is the Weierstrass curve with coefficients $a_1=1,a_2=a_3=0,a_4=-5s_3(q),a_6=-(5s_3(q)+7s_5(q))/12$, where $s_k(q)=\sum_{n=0}^{\infty}(n+1)^kq^{n+1}/(1-q^{n+1})$, using the field-valued infinite-sum operation, and $c_4,\Delta$ are the usual Weierstrass invariants. Third, `unif` assigns to each $w\in B$, with its membership proof, an element $\pi_w\in F_w$. Fourth, `unif_isUniformizer` requires for every such $w$ that $\pi_w\ne0$, $\lVert\pi_w\rVert<1$, and for every unit $x\in F_w^\times$ there exists an integer $n$ with $\lVert x\rVert=\lVert\pi_w\rVert^n$. These are the full conditions imposed by this record type; in particular no nonemptiness condition on $B$ is imposed, so when $B$ is empty all four families are vacuous. The declaration defines the type of such records and does not assert that a record of this type exists. The declared universe variable $v$ does not occur as a parameter of this declaration.

## 2. `TateInputs.qOrder` and `TateInputs.qOrder_pos`

For any universe level $u$, let $C : \mathrm{EllipticCurveData}^{u}$ consist of a number field $F : \mathrm{Type}(u)$, a chosen algebraic closure $\overline F : \mathrm{Type}(u)$ with its field and $F$-algebra structures, and a Weierstrass curve $E/F$ with unit discriminant; these structures are provided by $C$. The noncomputable definition `TateInputs.qOrder`, with $C$ an implicit parameter, takes a record $TI:C.\mathrm{TateInputs}$, a finite place $w$ of $F$, and a proof $h_w:w\in C.\mathrm{badAll}$, and returns a natural number. Here membership in $C.\mathrm{badAll}$ means that some change of variables of $E$ over $F$ gives a model having multiplicative reduction over the valuation ring of $F_w$ after extension of scalars to $F_w$. Put $t_w=TI.\mathrm{tate}(w,h_w)$, $q_w=t_w.q$, and $\pi_w=TI.\mathrm{unif}(w,h_w)$. Thus $q_w$ is a unit of $F_w$ with $0<\lVert q_w\rVert<1$, and the supplied proof $TI.\mathrm{unif\_isUniformizer}(w,h_w)$ states that $\pi_w\ne0$, $\lVert\pi_w\rVert<1$, and every unit norm in $F_w$ is an integer power of $\lVert\pi_w\rVert$. The full definition is as follows: let $n_w\in\mathbb Z$ be the integer selected by classical choice from the existence statement $\exists n\in\mathbb Z,\ \lVert q_w\rVert=\lVert\pi_w\rVert^n$, obtained by applying that last condition to $q_w$; `orderZ` denotes this chosen integer. Form `toOrdered` from $t_w$ by adjoining the field $\mathrm{orderNat}=\mathrm{Int.toNat}(n_w)$ and a proof of its strict positivity, and return this `orderNat` field. Equivalently, $TI.\mathrm{qOrder}(w,h_w)=\mathrm{Int.toNat}(n_w)=\max(n_w,0)$, viewed as a natural number, where the equality with the maximum describes the integer-to-natural-number conversion. In this application $n_w>0$, as established by `orderZ_pos`, so this conversion does not truncate a nonpositive order. The function is defined only with the supplied membership proof; it does not assign values at other finite places. It adds no new choices of Tate parameters or of $\pi_w$ beyond those already supplied in $TI$. The universe variable $v$ does not occur as a parameter.

For every universe level $u$, every record $C : \mathrm{EllipticCurveData}^{u}$ of a number field $F : \mathrm{Type}(u)$, its chosen algebraic closure $\overline F : \mathrm{Type}(u)$ with the field and $F$-algebra structures, and an elliptic Weierstrass curve $E/F$, every $TI:C.\mathrm{TateInputs}$, every finite place $w$ of $F$, and every proof $h_w:w\in C.\mathrm{badAll}$ that $E$ has multiplicative reduction there in the change-of-variables sense above, the lemma `TateInputs.qOrder_pos` states the strict inequality $0<TI.\mathrm{qOrder}(w,h_w)$. The number on the right is $\mathrm{Int.toNat}(n_w)$, where $n_w$ is classically chosen with $\lVert (TI.\mathrm{tate}(w,h_w)).q\rVert=\lVert TI.\mathrm{unif}(w,h_w)\rVert^{n_w}$. The proof uses the `orderNat_pos` field of the `toOrdered` record formed from these data. Here $C$ is implicit, and the universe variable $v$ is absent. If $C.\mathrm{badAll}$ is empty there is no such $w,h_w$, and this universally quantified assertion has no instance at a place.

## 3. `ModEllRepData`

Let $u$ be a universe level, fix $C : \mathrm{EllipticCurveData}^{u}$, a record in $\mathrm{Type}(u+1)$ providing a number field $F=C.F : \mathrm{Type}(u)$ with its field structure, a chosen algebraic closure $\overline F=C.Fbar : \mathrm{Type}(u)$ with its field and $F$-algebra structures, and an elliptic Weierstrass curve $E=C.E$ over $F$, meaning that $\Delta(E)$ is a unit, and let $\ell$ be any natural number. Set $A=\mathrm{Affine.Point}(E_{\overline F})$, the additive group consisting of the point at infinity and the nonsingular affine $\overline F$-points of the base-changed Weierstrass curve, and $A[\ell]=\{P\in A:\ell P=0\}$. Set $R_\ell=\mathrm{ZMod}(\ell)$, the ring $\mathbb Z/\ell\mathbb Z$ for $\ell>0$ and the ring $\mathbb Z$ for $\ell=0$. The definition `ModEllRepData` specifies a record type $C.\mathrm{ModEllRepData}(\ell):\mathrm{Type}(u)$ with four fields. The first, `torsionBasis`, is an additive-group isomorphism $b:A[\ell]\xrightarrow{\sim}(\{0,1\}\to R_\ell)$; its declared type is an additive equivalence, with no separate linear-map or vector-space-basis field. The second, `rep`, is a group homomorphism $\rho:\mathrm{Aut}_F(\overline F)\to\mathrm{GL}_2(R_\ell)$, where the domain consists of $F$-algebra automorphisms of $\overline F$, and the codomain is the group of units of the $2$-by-$2$ matrix ring over $R_\ell$. The third, `rep_spec`, requires that for every $\sigma\in\mathrm{Aut}_F(\overline F)$ and every $P\in A[\ell]$, $b(\sigma_*P)=\rho(\sigma)b(P)$, where the right-hand side is ordinary matrix multiplication on the column vector $b(P)$, and $\sigma_*$ is the additive point map induced by the $F$-algebra homomorphism underlying $\sigma$: it fixes the point at infinity and applies $\sigma$ to both affine coordinates. In the left-hand side $\sigma_*P$ is regarded as an element of $A[\ell]$ using the proof `galPointMap_torsionBy` that this point map preserves $\ell P=0$. The fourth, `ker_isOpen`, requires that $\ker\rho=\{\sigma:\rho(\sigma)=1\}$ be open as a subset of $\mathrm{Aut}_F(\overline F)$ with its Krull topology, whose identity-neighborhood basis consists of the subgroups fixing finite-dimensional intermediate extensions of $\overline F/F$. There is no primality or lower-bound hypothesis on $\ell$: zero, one and composite natural numbers are in its parameter range; for $\ell=0$ the torsion subgroup in the definition is all of $A$ and the coordinate group is $\mathbb Z^2$, and for $\ell=1$ both the torsion subgroup and coordinate group are trivial. The declaration specifies these data and conditions for a record; it asserts no existence of such a record for any $\ell$. The declared universe variable $v$ does not occur as a parameter.

## Original paper context

Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position* (February 2009), §3, local-setting paragraph spanning printed/PDF pages 14–15:

> Next, we consider the local theory at nonarchimedean primes. Let $K$ be a finite extension of $\mathbb Q_p$ [where $p$ is a prime number] with residue field $k$, maximal ideal $\mathfrak m_K\subseteq\mathcal O_K$, and valuation map $v_K:K^{\times}\to\mathbb Z$ [which we normalize so that $v_K$ is surjective]; $\overline K$ an algebraic closure of $K$; $G_K\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline K/K)$; $E\to\operatorname{Spec}(\mathcal O_K)$ a one-dimensional semi-abelian scheme over $\mathcal O_K$ such that the generic fiber $E_K$ of $E$ is proper, while the special fiber $E_k$ of $E$ is isomorphic to $(\mathbb G_m)_k$, the multiplicative group over $k$.

On printed/PDF page 15, the paragraph beginning “Let $l$”, through the complete continuous-action sentence before “Also”, states:

> Let $l$ be a prime number [possibly equal to $p$]; write
> 
> $$M_l(E)\overset{\mathrm{def}}{=}\operatorname{Hom}(\mathbb Z/l\cdot\mathbb Z,E(\overline K))$$
> 
> for the “mod $l$” Tate module of $E_K$. Thus, $M_l(E)$ is [noncanonically] isomorphic as an $\mathbb F_l$-module to $\mathbb F_l\times\mathbb F_l$ and, moreover, is equipped with a continuous action by $G_K$ induced by the natural action of $G_K$ on $\overline K$.

The same page, in the paragraph before Lemma 3.2, gives the following complete sentence about the Tate parameter:

> The Tate parameter is an element of $\mathfrak m_K$ that is naturally associated to $E$ and has the property that the subscheme $\mathcal O_K/(q_E)$ is equal to the pull-back via the classifying morphism $\operatorname{Spec}(\mathcal O_K)\to\overline{\mathcal M}_{\mathrm{ell}}$ — where we write $\overline{\mathcal M}_{\mathrm{ell}}$ for the moduli stack of one-dimensional semi-abelian varieties over $\mathbb Z$ — of the divisor at infinity $\infty_{\mathcal M}\subseteq\overline{\mathcal M}_{\mathrm{ell}}$.

Definition 3.3 on printed/PDF page 15 states, in full:

> We shall refer to the positive integer $v_K(q_E)\in\mathbb Z_{>0}$ as the local height of $E$ [or $E_K$].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`. These excerpts are separate; the unquoted exact-sequence and lemma passages between them are omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(c), first sentence through the definition of $K$, printed/PDF page 62:

> $l$ is a prime number $\geq5$ such that the image of the outer homomorphism
> 
> $$G_F\to GL_2(\mathbb F_l)$$
> 
> determined by the $l$-torsion points of $E_F$ contains the subgroup $SL_2(\mathbb F_l)\subseteq GL_2(\mathbb F_l)$; write $K\subseteq\overline F$ for the finite Galois extension of $F$ determined by the kernel of this homomorphism.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf. The subsequent sentence beginning “Also” and the rest of item (c) are omitted.

## Adaptation scope

The local paper setting is a split multiplicative semi-abelian model over a local integer ring. It supplies background for the Tate parameter and its positive discrete order. The actual `TateInputs` record supplies four families over all places in `badAll`: a Tate parameter, equality of its Tate j-invariant with the embedded j-invariant of the stored curve, a chosen uniformizer, and the full norm-power condition for that uniformizer. The record does not supply an isomorphism of curves or a Tate uniformization. The four-field interface and its explicit j-invariant equality are not presented as a verbatim paragraph of the paper.

The paper normalizes its integer-valued valuation to be surjective. In the definition `qOrder`, the normalization is expressed through the supplied uniformizer: the chosen integer $n_w$ satisfies $\lVert q_w\rVert=\lVert\pi_w\rVert^{n_w}$. Its conversion to a natural number is positive. This is the discrete local order used here; it is not a valuation normalized to take value 1 on the rational residue characteristic. The one-line lemma uses the positive-order field of the ordered parameter. It is a supporting consequence of the supplied data, not an existence theorem for those data.

The paper's local torsion passage assumes that $l$ is prime and states a noncanonical module isomorphism and a continuous action. The global passage uses a chosen prime $l\geq5$, a special-linear image condition, and a finite Galois extension determined by the kernel. These are the original mathematical backgrounds. The actual `ModEllRepData` record instead accepts any natural number $\ell$ and supplies four fields: an **additive-group isomorphism** to two coordinates over `ZMod ℓ`, a matrix-valued group homomorphism, equality with the coordinate action on every torsion point, and openness of its kernel in the Krull topology. The first field is not a separately declared linear basis. No primality assumption, special-linear image condition, or existence statement is added to that record by these quotations.

Both records concern the same fixed elliptic-curve data and selected closure, but are separate types of supplied data. The bad set may be empty. This definition does not choose the data, prove their existence, or assert a height estimate or an abc conclusion.

## Intuitive explanation (non-rigorous)

The local record keeps a small Tate parameter and a scale for measuring its discrete order at each multiplicative place. The representation record keeps coordinates on the torsion group and matrices describing the Galois action in those coordinates. Keeping the compatibility conditions in the records makes each later use refer to the same supplied choices.


# 简体中文

## 1. `TateInputs`

设 $u$ 为宇宙层级，并固定 $C:\mathrm{EllipticCurveData}^{u}$。这是一个属于 $\mathrm{Type}(u+1)$ 的记录，其中给出类型 $F=C.F:\mathrm{Type}(u)$ 及其域结构和数域结构，类型 $\overline F=C.Fbar:\mathrm{Type}(u)$ 及其域结构、$F$-代数结构和作为 $F$ 的代数闭包的性质，以及 $F$ 上的 Weierstrass 曲线 $E=C.E$，且其判别式是单位（在这个域上等价于判别式非零）。定义 `TateInputs` 指定一个记录类型 $C.\mathrm{TateInputs}:\mathrm{Type}(u)$，具有以下四个字段。记 $B=C.\mathrm{badAll}$；它由 $F$ 的如下有限位 $w$ 组成：存在定义在 $F$ 上的 Weierstrass 变量变换 $D$，使曲线 $D\mathbin{\bullet}E$ 扩张标量到完备化域 $F_w=w.\mathrm{maximalIdeal}.\mathrm{adicCompletion}(F)$ 后，在赋值环 $R_w=w.\mathrm{maximalIdeal}.\mathrm{adicCompletionIntegers}(F)$ 上具有乘法约化。这里，乘法约化表示这个局部模型在 $R_w$ 上极小，其判别式的乘法赋值严格小于 $1$，且其 $c_4$ 的乘法赋值等于 $1$；极小表示模型是整的，且其判别式的乘法赋值，在通过 $F_w$ 上变量变换得到的所有整模型中取最大值。第一，`tate` 对每个 $w\in B$ 及其成员关系证明，指定赋范域 $F_w$ 上的 Tate 参数 $t_w$；这表示一个满足 $\lVert q_w\rVert<1$ 的单位 $q_w=t_w.q\in F_w^\times$，从而 $0<\lVert q_w\rVert$。第二，`tateJ_eq` 要求对每个这样的 $w$，均有 $t_w.\mathrm{tateJ}=\iota_w(j(E))$，其中 $\iota_w:F\to F_w$ 是自然的环嵌入，$j(E)=c_4(E)^3/\Delta(E)$，而 $t_w.\mathrm{tateJ}=c_4(W_{q_w})^3/\Delta(W_{q_w})$。这个定义中的 $W_q$ 是系数为 $a_1=1,a_2=a_3=0,a_4=-5s_3(q),a_6=-(5s_3(q)+7s_5(q))/12$ 的 Weierstrass 曲线，其中 $s_k(q)=\sum_{n=0}^{\infty}(n+1)^kq^{n+1}/(1-q^{n+1})$，使用取值于该域的无穷求和运算，$c_4,\Delta$ 为通常的 Weierstrass 不变量。第三，`unif` 对每个 $w\in B$ 及其成员关系证明，指定一个元素 $\pi_w\in F_w$，供作【译名待定：uniformizer】。第四，`unif_isUniformizer` 要求对每个这样的 $w$，均有 $\pi_w\ne0$、$\lVert\pi_w\rVert<1$，并且对每个单位 $x\in F_w^\times$，存在整数 $n$ 使 $\lVert x\rVert=\lVert\pi_w\rVert^n$。这就是这个记录类型施加的全部条件；特别地，没有要求 $B$ 非空，所以当 $B$ 为空时，这四个族均为空索引族。该声明定义这种记录的类型，并不断言存在这种类型的记录。已声明的宇宙变量 $v$ 不作为本声明的参数出现。

## 2. `TateInputs.qOrder` 与 `TateInputs.qOrder_pos`

对于任意宇宙层级 $u$，设 $C:\mathrm{EllipticCurveData}^{u}$ 给出数域 $F:\mathrm{Type}(u)$、选定的代数闭包 $\overline F:\mathrm{Type}(u)$ 及其域结构和 $F$-代数结构，以及判别式为单位的 Weierstrass 曲线 $E/F$；这些结构由 $C$ 提供。不可计算定义 `TateInputs.qOrder` 以 $C$ 为隐式参数，接受记录 $TI:C.\mathrm{TateInputs}$、$F$ 的有限位 $w$ 和证明 $h_w:w\in C.\mathrm{badAll}$，返回一个自然数。这里，属于 $C.\mathrm{badAll}$ 表示存在 $E$ 在 $F$ 上的变量变换，使所得模型扩张标量到 $F_w$ 后，在 $F_w$ 的赋值环上具有乘法约化。置 $t_w=TI.\mathrm{tate}(w,h_w)$、$q_w=t_w.q$ 和 $\pi_w=TI.\mathrm{unif}(w,h_w)$。于是 $q_w$ 是 $F_w$ 中满足 $0<\lVert q_w\rVert<1$ 的单位，而给定的【译名待定：uniformizer】证明 $TI.\mathrm{unif\_isUniformizer}(w,h_w)$ 断言 $\pi_w\ne0$、$\lVert\pi_w\rVert<1$，且 $F_w$ 中每个单位的范数都是 $\lVert\pi_w\rVert$ 的整数次幂。完整定义如下：将最后这个条件应用于 $q_w$，得到存在性命题 $\exists n\in\mathbb Z,\ \lVert q_w\rVert=\lVert\pi_w\rVert^n$，再通过经典选择从中选取整数 $n_w\in\mathbb Z$；`orderZ` 表示这个选出的整数。在 $t_w$ 上附加字段 $\mathrm{orderNat}=\mathrm{Int.toNat}(n_w)$ 及其严格正性的证明，形成 `toOrdered`，再返回它的 `orderNat` 字段。等价地，$TI.\mathrm{qOrder}(w,h_w)=\mathrm{Int.toNat}(n_w)=\max(n_w,0)$，其中结果看作自然数，而与最大值的相等式描述从整数到自然数的转换。本次应用中，`orderZ_pos` 已给出 $n_w>0$，所以这种转换不会截断非正的阶。这个函数只有在给出上述成员关系证明时才有定义，不为其他有限位指定数值。除了 $TI$ 已提供的 Tate 参数和 $\pi_w$ 外，它不再选择新的 Tate 参数或【译名待定：uniformizer】。宇宙变量 $v$ 不作为参数出现。

对于每个宇宙层级 $u$、每个给出数域 $F:\mathrm{Type}(u)$、选定的代数闭包 $\overline F:\mathrm{Type}(u)$ 及其域结构和 $F$-代数结构、以及椭圆 Weierstrass 曲线 $E/F$ 的记录 $C:\mathrm{EllipticCurveData}^{u}$，每个 $TI:C.\mathrm{TateInputs}$、每个 $F$ 的有限位 $w$，以及每个证明 $h_w:w\in C.\mathrm{badAll}$，即 $E$ 在该处按上述变量变换意义具有乘法约化的证明，引理 `TateInputs.qOrder_pos` 断言严格不等式 $0<TI.\mathrm{qOrder}(w,h_w)$。右侧的数为 $\mathrm{Int.toNat}(n_w)$，其中 $n_w$ 通过经典选择得到，并满足 $\lVert (TI.\mathrm{tate}(w,h_w)).q\rVert=\lVert TI.\mathrm{unif}(w,h_w)\rVert^{n_w}$。证明使用由这些数据形成的 `toOrdered` 记录的 `orderNat_pos` 字段。这里 $C$ 是隐式参数，宇宙变量 $v$ 不出现。若 $C.\mathrm{badAll}$ 为空，就不存在这样的 $w,h_w$，所以这个全称断言在任何位都没有可应用的实例。

## 3. `ModEllRepData`

设 $u$ 为宇宙层级，固定 $C:\mathrm{EllipticCurveData}^{u}$。这个属于 $\mathrm{Type}(u+1)$ 的记录提供数域 $F=C.F:\mathrm{Type}(u)$ 及其域结构、选定的代数闭包 $\overline F=C.Fbar:\mathrm{Type}(u)$ 及其域结构和 $F$-代数结构，以及 $F$ 上的椭圆 Weierstrass 曲线 $E=C.E$，即 $\Delta(E)$ 为单位；另设 $\ell$ 为任意自然数。置 $A=\mathrm{Affine.Point}(E_{\overline F})$，即扩张标量后的 Weierstrass 曲线的无穷远点与所有非奇异仿射 $\overline F$-点所组成的加法群，并置 $A[\ell]=\{P\in A:\ell P=0\}$。置 $R_\ell=\mathrm{ZMod}(\ell)$；当 $\ell>0$ 时，它是环 $\mathbb Z/\ell\mathbb Z$，当 $\ell=0$ 时，它是环 $\mathbb Z$。定义 `ModEllRepData` 指定一个具有四个字段的记录类型 $C.\mathrm{ModEllRepData}(\ell):\mathrm{Type}(u)$。第一个字段 `torsionBasis` 是加法群同构 $b:A[\ell]\xrightarrow{\sim}(\{0,1\}\to R_\ell)$；其声明类型是加法同构，没有另设线性映射字段或向量空间基字段。第二个字段 `rep` 是群同态 $\rho:\mathrm{Aut}_F(\overline F)\to\mathrm{GL}_2(R_\ell)$，其定义域由 $\overline F$ 的 $F$-代数自同构组成，陪域是 $R_\ell$ 上 $2$ 阶方阵环的单位群。第三个字段 `rep_spec` 要求：对每个 $\sigma\in\mathrm{Aut}_F(\overline F)$ 和每个 $P\in A[\ell]$，均有 $b(\sigma_*P)=\rho(\sigma)b(P)$；右侧是矩阵对列向量 $b(P)$ 的通常乘法，$\sigma_*$ 是由 $\sigma$ 所对应的 $F$-代数同态诱导的加法点映射，它固定无穷远点，并对两个仿射坐标分别应用 $\sigma$。等式左侧使用 `galPointMap_torsionBy` 给出的证明，将 $\sigma_*P$ 看作 $A[\ell]$ 的元素；该证明断言这个点映射保持条件 $\ell P=0$。第四个字段 `ker_isOpen` 要求 $\ker\rho=\{\sigma:\rho(\sigma)=1\}$ 在带有 Krull 拓扑的 $\mathrm{Aut}_F(\overline F)$ 中是开子集；这个拓扑在单位元处的邻域基由逐点固定 $\overline F/F$ 的有限维中间扩张的子群组成。没有要求 $\ell$ 为素数，也没有要求它满足某个下界：参数范围包括零、一和合数；当 $\ell=0$ 时，定义中的挠子群是整个 $A$，坐标群是 $\mathbb Z^2$；当 $\ell=1$ 时，挠子群和坐标群都是平凡群。该声明规定记录所需的数据和条件，并不断言对任何 $\ell$ 存在这样的记录。已声明的宇宙变量 $v$ 不作为参数出现。

## 论文原文背景

望月新一，*Arithmetic Elliptic Curves in General Position*，2009 年 2 月版，第 3 节，局部设定段落，印刷页与文件页均为第 14–15 页；第 15 页从“Let $l$”开始、至“Also”之前的连续作用完整句；引理 3.2 之前以“The Tate parameter is”开始的完整句；以及第 15 页定义 3.3 全文。精确英文引文分别列于上方英文部分，中间未引用的正合列与引理段落已省略。

官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(c) 首句，至定义 $K$ 为止，印刷页与文件页均为第 62 页。精确英文引文见英文部分。其后以“Also”开始的句子及该项其余内容未引用。

官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

## 适配范围

原文的局部设定是在局部整数环上的一维半 Abel 概形，其特殊纤维是乘法群；这为 Tate 参数及其正离散阶提供背景。实际的 `TateInputs` 记录在 `badAll` 的所有位上提供四个族：Tate 参数、该参数的 Tate 曲线的 j 不变量与所保存曲线的 j 不变量经嵌入所得像的相等式、选定的【译名待定：uniformizer】，以及该元素的完整范数幂条件。记录不提供曲线同构或 Tate 一致化。本四字段接口及其显式 j 不变量相等式不称为论文中的逐字段原文。

原文将整数值赋值归一化为满射。`qOrder` 中的归一化通过给定的【译名待定：uniformizer】表达：选出的整数 $n_w$ 满足 $\lVert q_w\rVert=\lVert\pi_w\rVert^{n_w}$，转为自然数后仍为正。这是此处使用的离散局部阶，不是将在有理剩余特征处取值归一化为 1 的赋值。一行引理使用带阶参数记录中的正阶字段，是给定数据的辅助推论，不是这些数据的存在性定理。

原文的局部挠点段落要求 $l$ 为素数，并陈述非典范的模同构及连续作用。整体段落使用选定素数 $l\geq5$、特殊线性群像条件，以及由核确定的有限 Galois 扩张。这些构成原始数学背景。实际的 `ModEllRepData` 记录则接受任意自然数 $\ell$，并提供四个字段：到 `ZMod ℓ` 上两个坐标的**加法群同构**、取值于矩阵群的群同态、对每个挠点与坐标作用相容的等式，以及核在 Krull 拓扑下的开性。第一个字段不是另行声明的线性基。上述引文不为记录增添素数假设、特殊线性群像条件或存在性结论。

两个记录都针对同一组固定椭圆曲线数据及选定代数闭包，但它们是两种独立的给定数据类型。坏位集合允许为空。本定义不选取这些数据，不证明它们存在，也不断言高度估计或 abc 结论。

## 直观解释（非严格）

局部记录在每个乘法约化位保存一个小的 Tate 参数，以及衡量其离散阶的尺度。表示记录保存挠点群的坐标和描述这些坐标下 Galois 作用的矩阵。把相容条件保存在记录中，可使后续使用始终针对同一组给定选择。


# 日本語

## 1. `TateInputs`

$u$ を宇宙レベルとし、$C:\mathrm{EllipticCurveData}^{u}$ を固定する。これは $\mathrm{Type}(u+1)$ に属するレコードであり、体構造および数体構造を持つ型 $F=C.F:\mathrm{Type}(u)$、体構造、$F$-代数構造および $F$ の代数閉包であるという性質を持つ型 $\overline F=C.Fbar:\mathrm{Type}(u)$、ならびに判別式が単元である $F$ 上のワイエルシュトラス曲線 $E=C.E$ を与える。この体上では、判別式が単元であることは非零であることと同値である。定義 `TateInputs` は、次の四つのフィールドを持つレコード型 $C.\mathrm{TateInputs}:\mathrm{Type}(u)$ を指定する。$B=C.\mathrm{badAll}$ と書く。これは、$F$ 上のワイエルシュトラス変数変換 $D$ が存在し、曲線 $D\mathbin{\bullet}E$ を完備化体 $F_w=w.\mathrm{maximalIdeal}.\mathrm{adicCompletion}(F)$ に係数拡大すると、その付値環 $R_w=w.\mathrm{maximalIdeal}.\mathrm{adicCompletionIntegers}(F)$ 上で乗法的還元を持つような、$F$ の有限素点 $w$ の集合である。ここで乗法的還元とは、この局所モデルが $R_w$ 上極小であり、その判別式の乗法的付値が $1$ より真に小さく、その $c_4$ の乗法的付値が $1$ であることをいう。極小性とは、モデルが整であり、その判別式の乗法的付値が、$F_w$ 上の変数変換から得られる整モデル全体の中で最大になることである。第一に、`tate` は各 $w\in B$ とその所属証明に対し、ノルム体 $F_w$ 上のテイト・パラメータ $t_w$ を指定する。これは $\lVert q_w\rVert<1$ を満たす単元 $q_w=t_w.q\in F_w^\times$ を意味し、特に $0<\lVert q_w\rVert$ である。第二に、`tateJ_eq` はそのような各 $w$ に対して $t_w.\mathrm{tateJ}=\iota_w(j(E))$ を要求する。ここで $\iota_w:F\to F_w$ は標準的な環埋込みであり、$j(E)=c_4(E)^3/\Delta(E)$、$t_w.\mathrm{tateJ}=c_4(W_{q_w})^3/\Delta(W_{q_w})$ である。この定義における $W_q$ は、係数が $a_1=1,a_2=a_3=0,a_4=-5s_3(q),a_6=-(5s_3(q)+7s_5(q))/12$ であるワイエルシュトラス曲線である。ここで $s_k(q)=\sum_{n=0}^{\infty}(n+1)^kq^{n+1}/(1-q^{n+1})$ は体に値を取る無限和演算を用いて定められ、$c_4,\Delta$ は通常のワイエルシュトラス不変量である。第三に、`unif` は各 $w\in B$ とその所属証明に対して元 $\pi_w\in F_w$ を指定する。第四に、`unif_isUniformizer` は各 $\pi_w$ が一様化元であること、すなわち $\pi_w\ne0$、$\lVert\pi_w\rVert<1$ であり、すべての単元 $x\in F_w^\times$ に対して $\lVert x\rVert=\lVert\pi_w\rVert^n$ を満たす整数 $n$ が存在することを要求する。これらがこのレコード型に課される条件のすべてである。特に $B$ が空でないという条件はなく、$B$ が空ならば四つの族はいずれも空の添字集合を持つ。この宣言はそのようなレコードの型を定義し、その型のレコードが存在するとは主張しない。宣言された宇宙変数 $v$ は、この宣言のパラメータには現れない。

## 2. `TateInputs.qOrder` と `TateInputs.qOrder_pos`

任意の宇宙レベル $u$ に対し、$C:\mathrm{EllipticCurveData}^{u}$ が、数体 $F:\mathrm{Type}(u)$、選ばれた代数閉包 $\overline F:\mathrm{Type}(u)$ とその体構造および $F$-代数構造、ならびに判別式が単元であるワイエルシュトラス曲線 $E/F$ を与えるとする。これらの構造は $C$ によって与えられる。計算不可能な定義 `TateInputs.qOrder` は、$C$ を暗黙のパラメータとし、レコード $TI:C.\mathrm{TateInputs}$、$F$ の有限素点 $w$、および証明 $h_w:w\in C.\mathrm{badAll}$ を受け取り、自然数を返す。ここで $C.\mathrm{badAll}$ への所属は、$E$ の $F$ 上のある変数変換から得られるモデルが、$F_w$ へ係数拡大した後に $F_w$ の付値環上で乗法的還元を持つことを意味する。$t_w=TI.\mathrm{tate}(w,h_w)$、$q_w=t_w.q$、$\pi_w=TI.\mathrm{unif}(w,h_w)$ と置く。したがって $q_w$ は $0<\lVert q_w\rVert<1$ を満たす $F_w$ の単元であり、与えられた証明 $TI.\mathrm{unif\_isUniformizer}(w,h_w)$ は、$\pi_w\ne0$、$\lVert\pi_w\rVert<1$ であり、$F_w$ のすべての単元のノルムが $\lVert\pi_w\rVert$ の整数乗になることを述べる。完全な定義は次のとおりである。最後の条件を $q_w$ に適用して得られる存在命題 $\exists n\in\mathbb Z,\ \lVert q_w\rVert=\lVert\pi_w\rVert^n$ から、古典的選択によって整数 $n_w\in\mathbb Z$ を選ぶ。`orderZ` はこの選ばれた整数を表す。$t_w$ にフィールド $\mathrm{orderNat}=\mathrm{Int.toNat}(n_w)$ とその真の正値性の証明を付加して `toOrdered` を作り、その `orderNat` フィールドを返す。すなわち $TI.\mathrm{qOrder}(w,h_w)=\mathrm{Int.toNat}(n_w)=\max(n_w,0)$ であり、結果は自然数として解釈され、最大値との等式は整数から自然数への変換を記述する。この適用では `orderZ_pos` により $n_w>0$ なので、この変換で非正の位数が切り捨てられることはない。この関数は上記の所属証明が与えられる場合にだけ定義され、他の有限素点には値を指定しない。また、$TI$ で既に与えられたテイト・パラメータと $\pi_w$ のほかに、新たなテイト・パラメータや一様化元を選ぶことはない。宇宙変数 $v$ はパラメータには現れない。

すべての宇宙レベル $u$、数体 $F:\mathrm{Type}(u)$、選ばれた代数閉包 $\overline F:\mathrm{Type}(u)$ とその体構造および $F$-代数構造、ならびに楕円ワイエルシュトラス曲線 $E/F$ を与えるすべてのレコード $C:\mathrm{EllipticCurveData}^{u}$、すべての $TI:C.\mathrm{TateInputs}$、$F$ のすべての有限素点 $w$、および上記の変数変換の意味で $E$ がその素点において乗法的還元を持つことのすべての証明 $h_w:w\in C.\mathrm{badAll}$ に対し、補題 `TateInputs.qOrder_pos` は真の不等式 $0<TI.\mathrm{qOrder}(w,h_w)$ を述べる。右辺の数は $\mathrm{Int.toNat}(n_w)$ であり、$n_w$ は古典的選択で選ばれ、$\lVert (TI.\mathrm{tate}(w,h_w)).q\rVert=\lVert TI.\mathrm{unif}(w,h_w)\rVert^{n_w}$ を満たす整数である。証明では、これらのデータから作られる `toOrdered` レコードの `orderNat_pos` フィールドを用いる。ここで $C$ は暗黙のパラメータであり、宇宙変数 $v$ は現れない。$C.\mathrm{badAll}$ が空ならば、そのような $w,h_w$ は存在せず、この全称命題を適用できる素点はない。

## 3. `ModEllRepData`

$u$ を宇宙レベルとし、$C:\mathrm{EllipticCurveData}^{u}$ を固定する。この $\mathrm{Type}(u+1)$ に属するレコードは、数体 $F=C.F:\mathrm{Type}(u)$ とその体構造、選ばれた代数閉包 $\overline F=C.Fbar:\mathrm{Type}(u)$ とその体構造および $F$-代数構造、ならびに $F$ 上の楕円ワイエルシュトラス曲線 $E=C.E$、すなわち $\Delta(E)$ が単元である曲線を与える。また、$\ell$ を任意の自然数とする。$A=\mathrm{Affine.Point}(E_{\overline F})$ と置く。これは係数拡大されたワイエルシュトラス曲線の無限遠点と非特異なアフィン $\overline F$-点からなる加法群であり、$A[\ell]=\{P\in A:\ell P=0\}$ と置く。$R_\ell=\mathrm{ZMod}(\ell)$ と置く。これは $\ell>0$ のとき環 $\mathbb Z/\ell\mathbb Z$、$\ell=0$ のとき環 $\mathbb Z$ である。定義 `ModEllRepData` は四つのフィールドを持つレコード型 $C.\mathrm{ModEllRepData}(\ell):\mathrm{Type}(u)$ を指定する。第一の `torsionBasis` は加法群同型 $b:A[\ell]\xrightarrow{\sim}(\{0,1\}\to R_\ell)$ である。その宣言された型は加法的な同型であり、線形写像やベクトル空間の基底を与える別のフィールドはない。第二の `rep` は群準同型 $\rho:\mathrm{Aut}_F(\overline F)\to\mathrm{GL}_2(R_\ell)$ であり、定義域は $\overline F$ の $F$-代数自己同型全体、終域は $R_\ell$ 上の $2$ 次正方行列環の単元群である。第三の `rep_spec` は、すべての $\sigma\in\mathrm{Aut}_F(\overline F)$ とすべての $P\in A[\ell]$ に対して $b(\sigma_*P)=\rho(\sigma)b(P)$ を要求する。右辺は列ベクトル $b(P)$ に対する通常の行列積であり、$\sigma_*$ は $\sigma$ の基礎にある $F$-代数準同型が誘導する加法的な点写像である。この写像は無限遠点を固定し、二つのアフィン座標にそれぞれ $\sigma$ を適用する。左辺では、この点写像が $\ell P=0$ を保つことを述べる証明 `galPointMap_torsionBy` を用いて、$\sigma_*P$ を $A[\ell]$ の元と見なす。第四の `ker_isOpen` は、$\ker\rho=\{\sigma:\rho(\sigma)=1\}$ が、クルル位相を持つ $\mathrm{Aut}_F(\overline F)$ の開部分集合であることを要求する。この位相の単位元における近傍基は、$\overline F/F$ の有限次元中間拡大を各点ごとに固定する部分群からなる。$\ell$ が素数であるという仮定も、下限に関する仮定もない。零、一および合成数もパラメータの範囲に含まれる。$\ell=0$ のとき、定義中のねじれ部分群は $A$ 全体であり、座標群は $\mathbb Z^2$ である。$\ell=1$ のとき、ねじれ部分群も座標群も自明である。この宣言はレコードのデータと条件を指定し、いずれの $\ell$ に対してもそのようなレコードの存在を主張しない。宣言された宇宙変数 $v$ はパラメータには現れない。

## 論文原文の背景

望月新一、*Arithmetic Elliptic Curves in General Position*、2009 年 2 月版、第 3 節、局所的な設定の段落、印刷・PDF ファイルページ 14–15、ページ 15 の「Let $l$」から「Also」の前の連続作用に関する完全な文まで、補題 3.2 の前の「The Tate parameter is」で始まる完全な文、およびページ 15 の定義 3.3 全文。正確な英文は上の英語部分でそれぞれ引用した。間にある正確列と補題の引用していない部分は省略した。

公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(c) の最初の文から $K$ の定義まで、印刷・PDF ファイルページ 62。正確な英文は英語部分に示した。続く「Also」で始まる文と、この項の残りは引用しない。

公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

## 移植の範囲

論文の局所的設定は、局所整数環上の一次元半アーベルスキームであり、その特殊ファイバーは乗法群である。これはテイト・パラメータとその正の離散的な位数の背景を与える。実際の `TateInputs` レコードは、`badAll` のすべての素点上で四つの族を与える。テイト・パラメータ、そのテイト曲線の j 不変量と格納された曲線の j 不変量の埋込みによる像との等式、選ばれた一様化元、およびその一様化元の完全なノルムの冪条件である。このレコードは曲線の同型やテイト一様化を与えない。この四フィールドのインターフェースと明示的な j 不変量の等式を、論文の逐語的なフィールド一覧とはしない。

論文は整数値付値を全射となるよう正規化する。`qOrder` では、与えられた一様化元を用いて正規化する。選ばれた整数 $n_w$ は $\lVert q_w\rVert=\lVert\pi_w\rVert^{n_w}$ を満たし、自然数への変換後も正である。これはここで用いる離散的な局所の位数であり、有理剰余標数での値を 1 にする付値ではない。一行の補題は、順序を付したパラメータのレコードにある正値性のフィールドを用いる。与えられたデータの補助的帰結であり、データの存在定理ではない。

論文の局所的な等分点の段落は $l$ を素数と仮定し、非標準的な加群同型と連続作用を述べる。大域的な段落は、選ばれた素数 $l\geq5$、特殊線形群の像条件、および核で定まる有限ガロア拡大を用いる。これらは原文の数学的背景である。一方、実際の `ModEllRepData` レコードは任意の自然数 $\ell$ を受け取り、四つのフィールドを与える。`ZMod ℓ` の二つの座標への**加法群同型**、行列群に値を取る群準同型、各等分点で座標作用と両立する等式、およびクルル位相での核の開性である。第一のフィールドは、別に宣言された線形な基底ではない。これらの引用によって、素数という仮定、特殊線形群の像条件、存在の主張をレコードへ加えない。

二つのレコードは同じ固定した楕円曲線データと指定された代数閉包に関するものであるが、別々の型の入力データである。悪い素点の集合は空でもよい。この定義はデータを選ばず、その存在を証明せず、高さの評価や abc の結論も主張しない。

## 直観的説明（非厳密）

局所レコードは各乗法的還元素点で小さなテイト・パラメータと、その離散的な位数を測る尺度を保持する。表現レコードは等分点群の座標と、その座標でガロア作用を記述する行列を保持する。両立条件をレコードに含めることで、後の利用は同じ入力の選択に関するものになる。

