## Original paper context

Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position* (February 2009), §3, local-setting paragraph spanning printed/PDF pages 14–15:

> Next, we consider the local theory at nonarchimedean primes. Let $K$ be a finite extension of $\mathbb Q_p$ [where $p$ is a prime number] with residue field $k$, maximal ideal $\mathfrak m_K\subseteq\mathcal O_K$, and valuation map $v_K:K^{\times}\to\mathbb Z$ [which we normalize so that $v_K$ is surjective]; $\overline K$ an algebraic closure of $K$; $G_K\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline K/K)$; $E\to\operatorname{Spec}(\mathcal O_K)$ a one-dimensional semi-abelian scheme over $\mathcal O_K$ such that the generic fiber $E_K$ of $E$ is proper, while the special fiber $E_k$ of $E$ is isomorphic to $(\mathbb G_m)_k$, the multiplicative group over $k$.

On printed/PDF page 15, the paragraph beginning “Let $l$”, through the complete continuous-action sentence before “Also”, states:

> Let $l$ be a prime number [possibly equal to $p$]; write
> 
> $$M_l(E)\overset{\mathrm{def}}{=}\operatorname{Hom}(\mathbb Z/l\cdot\mathbb Z,E(\overline K))$$
> 
> for the “mod $l$” Tate module of $E_K$. Thus, $M_l(E)$ is [noncanonically] isomorphic as an $\mathbb F_l$-module to $\mathbb F_l\times\mathbb F_l$ and, moreover, is equipped with a continuous action by $G_K$ induced by the natural action of $G_K$ on $\overline K$.

The same page, in the paragraph before Lemma 3.2, gives the following complete sentence about the Tate parameter:

> The Tate parameter is an element of $\mathfrak m_K$ that is naturally associated to $E$ and has the property that the subscheme $\mathcal O_K/(q_E)$ is equal to the pull-back via the classifying morphism $\operatorname{Spec}(\mathcal O_K)\to\overline{\mathcal M}_{\mathrm{ell}}$ — where we write $\overline{\mathcal M}_{\mathrm{ell}}$ for the moduli stack of one-dimensional semi-abelian varieties over $\mathbb Z$ — of the divisor at infinity $\infty_{\mathcal M}\subseteq\overline{\mathcal M}_{\mathrm{ell}}$.

Definition 3.3 on printed/PDF page 15 states, in full:

> We shall refer to the positive integer $v_K(q_E)\in\mathbb Z_{>0}$ as the local height of $E$ [or $E_K$].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`. These excerpts are separate; the unquoted exact-sequence and lemma passages between them are omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(c), first sentence through the definition of $K$, printed/PDF page 62:

> $l$ is a prime number $\geq5$ such that the image of the outer homomorphism
> 
> $$G_F\to GL_2(\mathbb F_l)$$
> 
> determined by the $l$-torsion points of $E_F$ contains the subgroup $SL_2(\mathbb F_l)\subseteq GL_2(\mathbb F_l)$; write $K\subseteq\overline F$ for the finite Galois extension of $F$ determined by the kernel of this homomorphism.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf. The subsequent sentence beginning “Also” and the rest of item (c) are omitted.

## Adaptation scope

The local paper setting is a split multiplicative semi-abelian model over a local integer ring. It supplies background for the Tate parameter and its positive discrete order. The actual `TateInputs` record supplies four families over all places in `badAll`: a Tate parameter, equality of its Tate j-invariant with the embedded j-invariant of the stored curve, a chosen uniformizer, and the full norm-power condition for that uniformizer. The record does not supply an isomorphism of curves or a Tate uniformization. The four-field interface and its explicit j-invariant equality are not presented as a verbatim paragraph of the paper.

The paper normalizes its integer-valued valuation to be surjective. In the definition `qOrder`, the normalization is expressed through the supplied uniformizer: the chosen integer $n_w$ satisfies $\lVert q_w\rVert=\lVert\pi_w\rVert^{n_w}$. Its conversion to a natural number is positive. This is the discrete local order used here; it is not a valuation normalized to take value 1 on the rational residue characteristic. The one-line lemma uses the positive-order field of the ordered parameter. It is a supporting consequence of the supplied data, not an existence theorem for those data.

The paper's local torsion passage assumes that $l$ is prime and states a noncanonical module isomorphism and a continuous action. The global passage uses a chosen prime $l\geq5$, a special-linear image condition, and a finite Galois extension determined by the kernel. These are the original mathematical backgrounds. The actual `ModEllRepData` record instead accepts any natural number $\ell$ and supplies four fields: an **additive-group isomorphism** to two coordinates over `ZMod ℓ`, a matrix-valued group homomorphism, equality with the coordinate action on every torsion point, and openness of its kernel in the Krull topology. The first field is not a separately declared linear basis. No primality assumption, special-linear image condition, or existence statement is added to that record by these quotations.

Both records concern the same fixed elliptic-curve data and selected closure, but are separate types of supplied data. The bad set may be empty. This definition does not choose the data, prove their existence, or assert a height estimate or an abc conclusion.

## Intuitive explanation (non-rigorous)

The local record keeps a small Tate parameter and a scale for measuring its discrete order at each multiplicative place. The representation record keeps coordinates on the torsion group and matrices describing the Galois action in those coordinates. Keeping the compatibility conditions in the records makes each later use refer to the same supplied choices.

