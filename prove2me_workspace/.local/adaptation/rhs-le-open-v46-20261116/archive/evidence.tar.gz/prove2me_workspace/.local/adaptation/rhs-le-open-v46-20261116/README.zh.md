本包只准备 `AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.rhs_le` 的**开放陈述类型验收**。没有 native proof、solution proof、proof oracle新任务或四角色证明审查，也没有运行CI/API/Git或改主区。

最小目标stub在 `stub/Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_LocalEstimate_rhs_le.lean`；平台payload在 `payload.not-ready.json`。stub只导入已发布LogVolumeBound Definition及精确Mathlib记号/π模块，保留原平均体积不等式。完整telescope是：

```lean
{AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
{X : Corollary312VariantData.{u,v} AG TG} {inv : Theorem110Invariants X}
(est : inv.LocalEstimate) :
  X.rhsData.rhs ≤
    (∑ i, (∑ p ∈ inv.dst,
       inv.capsuleBound (X.rhsData.container.proc.capsule i).card p +
       (X.rhsData.container.proc.capsule i).card * Real.log Real.pi)) /
    X.rhsData.container.proc.length
```

**inv隐式、est显式**。来源先`variable {inv}`再`include est`，即使结论不出现est也必须保留。完整原namespace/variable/include/options/AST offset及SHA见`source/context-and-ast.json`。此telescope尚未用真实source compiler TYPE复验，最终以实际Expr/BinderInfo为准。

已有该节点metadata的`graphCompilerType`/`graphCompilerTelescope`为null，未发现有效单节点TYPE回执。因此`source/QueryOriginalType.lean`复用既有源TYPE exporter，唯一import改为原`Iut.Implication.LogVolumeBound`；配置为`source/type-config.json`，环境键`PURE_TYPE_SOURCE_CONFIG`，使用原4.35环境。它只读cached theorem TYPE，不读选定定理proof value。这类读取完整源模块与“独立证明oracle”不同，不能把它算proof通过。

`maps/data-map.candidate.json`完整映射当前graphTypeDependencies的28个项目常量，没有缺项；映射来自main5既有current-owned176/current-source-log32 projectMaps，分别记录实际owner、当前Definition ID和W源码SHA。它只是candidate，须用实际TYPE Expr常量清单收缩/确认，不能把graph当compiler TYPE。没有新增数据identity门。

目标审查为`target/AuditOpenStatementType.lean`和`target/type-config.template.json`，环境键`OPEN_STATEMENT_TYPE_CONFIG`，使用目标4.33环境。root源TYPE、stub leaf/artifact通过后，用`bind_type_audit.py --source-facts ... --source-receipt ... --stub-leaf ... --stub-artifact ...`生成bound config；binder检查实际source Expr中所有项目常量都有映射，额外private或新名字会明确拒绝。之后query进行完整TYPE kernel equality、universe数量、全树BinderInfo位置/顺序及TYPE标准公理检查。stub body仍sorry；输出明确`proofAccepted=false`、`fourRoleProofAuditPerformed=false`。若source TYPE出现closed proof值，草稿会停止并要求单独明确处理，不能默默丢弃。

自然语言必须纠正reader来源：该节点属于现有冻结 **Reader A**，并不在Reader B的13条中。`readbacks/frozen-selected-A.json`逐字段选取原`trilingual-a.json`节点，原英文/中日译文未改。`handoff.json`记录冻结原文件pins，不把另一reader冒充该节点独立读回。冻结文本中对sorry的历史状态描述保留。

论文只复用已有视觉核验Mochizuki IUT IV Theorem1.10 proof Steps(iv)–(vii)引文，包括local objective、有限处、非区分处零界及无穷处界，见`paper/context.json`。它是父证明来源上下文，不是构造LocalEstimate或证明论文theta locus/measure身份的证明。真正paper实例仍是未来数学输入。

缺门见`handoff.json`：source actual TYPE回执、stub叶/产物、目标完整TYPE/BinderInfo审查、实际Expr map选择、TYPE公理、最终冻结来源读回/论文核对及项目必须的生产门/现有mission绑定。payload **not-ready**，不附可冒充闭合证明的solution。将来真正父归约另做；本包通过只表示开放命题的准确类型，不代表rhs_le证明、theorem110、c2、S2-04或Joshi内容已证。
