#!/usr/bin/env python3
"""Bind actual source TYPE/stub receipts; no compilation, API, or proof acceptance."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import argparse,json,hashlib
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bound(p):p=Path(p).resolve();return {'path':str(p),'sha256':sha(p),'contents':read(p)}
def receipt(p):
 b=bound(p);j=b['contents'];assert j['status']=='succeeded'and j['result']['exit_code']==0 and j['request']['workspace']==str(W)and j['request']['exclusive']is True;assert j['result']['snapshot']['workspace_mode']=='exclusive_worktree'and j['result']['snapshot']['snapshot_id']is None;return b
ap=argparse.ArgumentParser();ap.add_argument('--source-facts',type=Path,required=True);ap.add_argument('--source-receipt',type=Path,required=True);ap.add_argument('--stub-leaf',type=Path,required=True);ap.add_argument('--stub-artifact',type=Path,required=True);a=ap.parse_args();c=read(D/'target/type-config.template.json');f=bound(a.source_facts);j=f['contents'];assert j['rootTheoremProofsRead']is False and j['closedTypeProofValues']==[];r,=j['records'];assert r['name']=='Iut.Theorem110Invariants.LocalEstimate.rhs_le';sr=receipt(a.source_receipt);sp=Path(sr['contents']['request']['environment']['PURE_TYPE_SOURCE_CONFIG']);assert read(sp)==j['configuration'];assert sr['contents']['request']['worktree_manifest']['input_hashes'].get(str(sp))==sha(sp)
# Names are taken from the actual Expr; extra source project/private names block acceptance.
def name(n):return ''if not n else name(n[0])+('.'if n[0]else'')+str(n[2])
names=set()
def walk(x):
 if isinstance(x,dict):
  if x.get('kind')in ['const','proj']:
   n=name(x['name'])
   if n.startswith(('Iut.','_private.','Genl.')):names.add(n)
  for y in x.values():walk(y)
 elif isinstance(x,list):
  for y in x:walk(y)
walk(r['elaboratedExpr']);mapping=read(D/'maps/data-map.candidate.json');allowed={x['original']for x in mapping['rows']};assert names<=allowed,('Actual TYPE has unmapped project names',names-allowed)
installed=Path(c['installedSource']);assert installed.read_text()==c['expectedStubText']
for k,p in [('stubLeafReceipt',a.stub_leaf),('stubArtifactReceipt',a.stub_artifact)]:
 b=receipt(p);assert b['contents']['request']['worktree_manifest']['input_hashes'].get(str(installed))==sha(installed);c[k]=b
c['sourceFacts']=str(a.source_facts.resolve());c['sourceTypeReceipt']=sr;c['sourceFactsBinding']=f;c['status']='Bound type-only inputs; root must execute target audit. No proof is claimed.';out=D/'target/type-config.bound.json';out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(D/'maps/actual-type-map-selection.json').write_text(json.dumps({'actualSourceProjectConstants':sorted(names),'sourceFacts':{'path':f['path'],'sha256':f['sha256']},'allActualConstantsHaveExistingNamedMap':True,'candidateMap':{'path':str(D/'maps/data-map.candidate.json'),'sha256':sha(D/'maps/data-map.candidate.json')},'mathematicalGateClaimed':False},ensure_ascii=False,indent=2)+'\n');print(out,sha(out))
