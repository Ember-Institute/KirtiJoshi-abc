from pathlib import Path
import sys
sys.dont_write_bytecode=True
import json,hashlib
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';G=A/'main-chain-open-20261116/tools/generated';N='Iut.Theorem110Invariants.LocalEstimate.rhs_le';T='AbcAdaptation.Reference.'+N;S=N.replace('.','_');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();pin=lambda p:{'path':str(p),'sha256':sha(p)}
def save(p,j):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def en(n):
 x=[]
 for a in n.split('.'):x=[x,'str',a]
 return x
m=read(G/'metadata'/f'{S}.json');r=Path(m['originalCoordinateSource']).read_bytes();contexts=[]
for c in m['allSourceContexts']:
 x=c['range'];contexts.append({**c,'exactText':r[x['start']['offset']:x['end']['offset']].decode()})
save(D/'source/context-and-ast.json',{'metadata':pin(G/'metadata'/f'{S}.json'),'source':pin(m['originalCoordinateSource']),'parserJob':m['parserJob'],'allExactContexts':contexts,'sourceStatementDeclaration':pin(G/'OriginalCommands'/f'{S}.lean'),'sourceIncludedEst':'include est','invBinder':'implicit due to variable {inv}','statementOnlyScope':True})
pre='''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Fintype.BigOperators

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
open AbcAdaptation.Reference.Iut
open AbcAdaptation.Reference.Iut.Theorem110Invariants
universe u v

'''
formal='''theorem AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.rhs_le
    {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
    {X : Corollary312VariantData.{u, v} AG TG} {inv : Theorem110Invariants X}
    (est : inv.LocalEstimate) :
    X.rhsData.rhs ≤
      (∑ i, (∑ p ∈ inv.dst, inv.capsuleBound (X.rhsData.container.proc.capsule i).card p +
        (X.rhsData.container.proc.capsule i).card * Real.log Real.pi)) /
        X.rhsData.container.proc.length := by
  sorry
'''
rel='Theorems/Thm_'+T.replace('.','_')+'.lean';p=D/'stub'/Path(rel).name;p.parent.mkdir();p.write_text(pre+formal)
map1=A/'main5-local-dossier-v27-20261116/current-owned176-config.json';map2=A/'main5-local-dossier-v27-20261116/current-source-log32-config.json';a={x['original']:x for x in read(map1)['projectMap']};b={x['original']:x for x in read(map2)['projectMap']};regpath=A/'platform-node-registry.json';registry=read(regpath)['reference_source_preparation'];defs={x['name']:x for x in registry['definitions']};rows=[];missing=[]
for n in m['graphTypeDependencies']:
 mp=map1 if n in a else map2;row=(a if n in a else b).get(n)
 if row is None:missing.append(n);continue
 owner=row['targetOwner'];f=W/Path(owner.replace('.','/')+'.lean');rows.append({'original':n,'target':row['target'],'originalName':row['originalName'],'targetName':row['targetName'],'targetOwner':owner,'targetToSourceUniverseIndices':row.get('targetToSourceUniverseIndices'),'existingMap':pin(mp),'existingMapRow':row,'publishedDefinition':defs[owner.removeprefix('Definitions.Def_')],'currentSource':pin(f)})
save(D/'maps/data-map.candidate.json',{'graphTypeDependencies':m['graphTypeDependencies'],'count':len(rows),'missing':missing,'rows':rows,'actualSourceTYPEConfirmed':False,'note':'Source graph/AST-derived candidate mapping; actual compiler TYPE export must confirm complete constants and BinderInfo. No new data identity acceptance claimed.','registry':pin(regpath)})
# Existing exporter reads selected cached theorem TYPE only, and never selected theorem value.
q=A/'independent-two-four-role-v25-20261116/QueryIndependentTypeFacts.lean';s=q.read_text().replace('import Iut.Implication.Theorem110','import Iut.Implication.LogVolumeBound');(D/'source/QueryOriginalType.lean').write_text(s)
cfg={'schema':'pure-arithmetic-type-source-config/v9','publish':False,'roots':[{'name':N,'nameExpr':en(N)}],'expectedRootCount':1,'sourceModule':'Iut.Implication.LogVolumeBound','sourceSha256':m['originalCoordinateSha256'],'source':pin(m['originalCoordinateSource']),'allowedDataNames':m['graphTypeDependencies'],'outputFile':str(D/'actual/source-type.json'),'mode':'TYPE ONLY; cached original theorem type; no selected theorem proof read.'};save(D/'source/type-config.json',cfg)
# Use stable actual Expr codec and kernel/BinderInfo primitives, with explicit maps.
base=(A/'main-pure-type-identity-20261116/AuditP5GlobalSolution.lean').read_text();common=base[base.index('/-! Stable JSON'):base.index('def pureArithmeticTypeAudit :')];pairs=[]
for x in rows:pairs.extend([(x['original'],x['target']),(x['target'],x['target'])])
mt='def typeNames : TypeNames := #[\n'+',\n'.join('  (`'+x+', `'+y+')'for x,y in pairs)+']\n';query='import Lean\nimport '+rel[:-5].replace('/','.')+'\n\n'+common+mt+'''
run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33 open-statement audit"
  let cfg ← jsonFile (← absoluteEnv "OPEN_STATEMENT_TYPE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "rhs-open-statement-type-config/v45" do throwError "Wrong open-statement config"
  let facts ← jsonFile (← checked (stringField cfg "sourceFacts"))
  unless (← checked (facts.getObjValAs? Bool "rootTheoremProofsRead")) == false do throwError "Selected proof must not be read"
  let records ← checked (arrayField facts "records")
  unless records.size == 1 do throwError "Expected one source TYPE"
  let r := records[0]!
  unless (← checked (stringField r "name")) == "Iut.Theorem110Invariants.LocalEstimate.rhs_le" do throwError "Wrong source type root"
  let proofRows ← checked (arrayField facts "closedTypeProofValues")
  unless proofRows.isEmpty do throwError "Unexpected TYPE proof values need explicit source-backed handling before acceptance"
  let target := `AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.rhs_le
  let ci ← getConstInfo target
  unless moduleOf (← getEnv) target == some `Theorems.Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_LocalEstimate_rhs_le do throwError "Wrong target stub owner"
  let source ← checked (decodeType typeNames #[] #[] true (← checked (field r "elaboratedExpr")))
  let ps ← namesFromJson (← checked (field r "levelParams"))
  unless ps.length == ci.levelParams.length do throwError "Universe arity differs"
  let us := (canonicalLevels ps.length).map Level.param
  let st := source.instantiateLevelParams ps us
  let tt := ci.type.instantiateLevelParams ci.levelParams us
  kernelTypeEq "complete open source/target statement TYPE" st tt
  unless binderInventory st == binderInventory tt && binderPlacement st == binderPlacement tt do throwError "Complete BinderInfo differs"
  let taxs ← expressionAxioms ci.type
  ensureStandard "open statement TYPE only" taxs
  let text ← IO.FS.readFile (← checked (stringField cfg "installedSource"))
  unless text == (← checked (stringField cfg "expectedStubText")) do throwError "Installed stub differs"
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "rhs-open-statement-type-audit/v45"),("statementTypeAccepted",toJson true),
    ("sourceTypeName",toJson "Iut.Theorem110Invariants.LocalEstimate.rhs_le"),
    ("targetName",toJson target.toString),("completeKernelTypeEqual",toJson true),
    ("binderInventoryEqual",toJson true),("binderPlacementEqual",toJson true),
    ("sourceTypeExpr",← checked (field r "elaboratedExpr")),("targetTypeExpr",← checked (encodeExpr ci.type)),
    ("typeAxioms",toJson (taxs.map Name.toString)),("proofAccepted",toJson false),
    ("fourRoleProofAuditPerformed",toJson false),("expectedOpenSorry",toJson true),
    ("configuration",cfg)]).pretty ++ "\\n")
  logInfo "Open statement TYPE/BinderInfo accepted; no proof or four-role acceptance claimed"
end FoundationAudit
''';(D/'target').mkdir();(D/'target/AuditOpenStatementType.lean').write_text(query)
save(D/'target/type-config.template.json',{'schema':'rhs-open-statement-type-config/v45','sourceFacts':str(D/'actual/source-type.json'),'installedSource':str(W/rel),'expectedStubText':pre+formal,'outputFile':str(D/'actual/target-type-audit.json'),'sourceTypeReceipt':None,'stubLeafReceipt':None,'stubArtifactReceipt':None,'mapEvidence':pin(D/'maps/data-map.candidate.json'),'status':'pending actual source TYPE and target compilation; not a proof audit'})
# Correct frozen reader is A; B has no such node.
RB=A/'main-chain-open-20261116/independent-readbacks-v9';ta=read(RB/'trilingual-a.json');rb=next(x for x in ta['nodes']if x['sourceName']==N);save(D/'readbacks/frozen-selected-A.json',rb)
Q=A/'reference-main-bound-carriers-20261115/paper-materials-v1/quotations-and-evidence.json';qd=read(Q);selected=[x for x in qd['quotations']if x['id']in ['IV-local-objective','IV-capsule-bound','IV-zero-bound','IV-infinite-bound']];save(D/'paper/context.json',{'existingMaterials':pin(Q),'paperIV':qd['paper_sources']['IV'],'quotations':selected,'scope':'Mochizuki IUT IV Theorem1.10 proof Steps(iv)-(vii) parent context. The source conditional bound is not a proof that a genuine LocalEstimate exists or that supplied regions/weights are paper objects.','newVisualAuditClaimed':False})
lang=rb['readbacks'];tr='\n\n'.join('**'+title+'**\n\n'+lang[key]for key,title in [('en','English'),('zh_Hans'if'zh_Hans'in lang else'zh-Hans','简体中文'),('ja','日本語')]);quotes='\n\n'.join('**'+x['locator']+'**\n\n> '+x['quote_markdown'].replace('\n','\n> ')for x in selected)
source='https://github.com/lana-agents/iut/blob/07cb1da58f6d428a670dbb5dd6093d428bcbcdd8/Iut/Implication/LogVolumeBound.lean#L203-L212'
payload={'theorem_name':T,'theorem_title':'Conditional global log-volume upper bound — 条件性全局对数体积上界 — 条件付き大域対数体積上界','preamble':pre,'formal_statement':formal.rstrip(),'natural_language_statement':tr+'\n\n**Paper source context**\n\n'+read(D/'paper/context.json')['scope']+'\n\n'+quotes,'source':source,'env':'0df444a360eaa60ab8c11dca51a86af692955474','private':True};save(D/'payload.not-ready.json',payload)
save(D/'handoff.json',{'sourceName':N,'targetName':T,'statementOnly':True,'proofAccepted':False,'nativeProofCreated':False,'sourceTYPEExistingAcceptedReceipt':None,'sourceTYPEExportNeeded':True,'sourceGraphProjectConstants':len(m['graphTypeDependencies']),'mappedGraphConstants':len(rows),'unmappedGraphConstants':missing,'invBinder':'implicit','estBinder':'explicit included argument','actualConsumerEdges':m['actualConsumerEdges'],'sourceReadbackReader':'A; B does not contain this node','frozenReadbackOriginals':[pin(RB/x)for x in ['readback-a-en.json','trilingual-a.json','terminology-a.json','coverage.json']],'futureParentReduction':'Separate later task. Does not change this payload from Open to Proved.','missingGates':['source actual TYPE export successful receipt','native target stub leaf+artifact successful receipts','source/target complete kernel TYPE and BinderInfo audit','bind map to actual source Expr constants (not graph alone)','type-only standard axiom audit','final frozen readback/paper/provenance review','project required Checks/ImportAudit/Act1Scene1/AxiomAudit/diff or valid reuse binding','explicit existing-private-mission payload publication scope binding'],'preamble':pin(p),'dataMap':pin(D/'maps/data-map.candidate.json'),'canonicalC22Connected':False,'S204Completed':False,'CIInvoked':False,'APIInvoked':False,'GitInvoked':False,'mainWorkspaceModified':False})
print('Open rhs_le stub generated; graph constants mapped',len(rows),'missing',missing,'reader A. No native proof.')
