import Lean
import Theorems.Thm_AbcAdaptation_Tripod_legendre_isElliptic
import Solutions.Sol_AbcAdaptation_Tripod_legendre_isElliptic
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_LegendreModel

open WeierstrassCurve
open AbcAdaptation.Tripod

universe u

theorem LegendrePlatformShape.platform_shape
    {K : Type u} [Field K] [NeZero (2 : K)] {l : K}
    (h0 : l ≠ 0) (h1 : l ≠ 1) :
    (AbcAdaptation.Tripod.legendre l).IsElliptic := by exact AbcAdaptation.Tripod.legendre_isElliptic h0 h1

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare
namespace LegendreSevenReview
open Lean Elab Term Meta FoundationAudit BasicNativeCompare

end LegendreSevenReview

namespace LegendreFourRoleReview
open Lean Elab Term Meta FoundationAudit BasicNativeCompare
partial def findKind (stx : Syntax) (k : Name) : Option Syntax :=
  if stx.getKind == k then some stx else stx.getArgs.findSome? (findKind · k)

def rows (path : String) : MetaM (Array Json) := do
  let mut output := #[]
  for line in (← IO.FS.readFile path).splitOn "\n" do
    unless line.isEmpty do output := output.push (← checked (Json.parse line))
  return output

def typeEq (label : String) (a b : Expr) : MetaM Unit := do
  match Kernel.isDefEq (← getEnv) {} a b with
  | .ok true => pure ()
  | .ok false => throwError "Four-role TYPE mismatch {label}"
  | .error ex => throwKernelException ex

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_LEGENDRE_FOUR_ROLE_CONFIG")
  unless (← checked (cfg.getObjValAs? String "schema")) == "B1-Legendre-four-role-config/v140" do throwError "Wrong four-role configuration"
  let payload ← jsonFile (← checked (cfg.getObjValAs? String "payloadFile"))
  let preamble ← checked (payload.getObjValAs? String "preamble")
  let statement ← checked (payload.getObjValAs? String "formal_statement")
  unless preamble == (← checked (cfg.getObjValAs? String "exactPreamble")) &&
    statement == (← checked (cfg.getObjValAs? String "exactFormalStatement")) do
      throwError "Payload source text differs from frozen query input"
  -- Check the recorded two byte edits against actual parser-owned syntax spans.
  let parsed ← checked (Parser.runParserCategory (← getEnv) `command statement)
  let some declNode := findKind parsed `Lean.Parser.Command.declId | throwError "Missing payload root declId"
  let some bodyNode := findKind parsed `Lean.Parser.Term.byTactic | throwError "Missing payload root proof term"
  let patches ← checked (arrayField cfg "edits")
  unless patches.size == 2 do throwError "Expected only root-declId/proof edits"
  for entry in #[(declNode,patches[0]!), (bodyNode,patches[1]!)] do
    let (syntaxNode,patch) := entry
    let some spanStart := syntaxNode.getPos? | throwError "Missing AST start"
    let some spanEnd := syntaxNode.getTailPos? | throwError "Missing AST tail"
    unless spanStart.byteIdx == (← checked (patch.getObjValAs? Nat "start")) &&
      spanEnd.byteIdx == (← checked (patch.getObjValAs? Nat "end")) do
        throwError "Recorded platform edit differs from actual AST span"
  for requirement in ← checked (arrayField cfg "acceptedReceipts") do
    let receipt ← jsonFile (← checked (requirement.getObjValAs? String "path"))
    unless (← checked (receipt.getObjValAs? String "status")) == "succeeded" &&
      (← checked (receipt.getObjValAs? String "job_id")) == (← checked (requirement.getObjValAs? String "job_id")) do
        throwError "Prior source proof closure receipt not accepted"
  let allSource ← rows (← checked (cfg.getObjValAs? String "sourceFacts"))
  let sourceName ← checked (decodeName (← checked (field cfg "sourceRootNameExpr")))
  let sourceRows := allSource.filter fun r => (field r "nameExpr").toOption == some (encodeName sourceName)
  unless sourceRows.size == 1 do throwError "Source root actual fact is not unique"
  let source := sourceRows[0]!
  unless (← checked (source.getObjValAs? Bool "valueRead")) &&
    (← checked (source.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
      throwError "Source full original proof evidence missing"
  let sourceValue ← checked (field source "actualValueExpr")
  if sourceValue == Json.null then throwError "Source original proof identity missing"
  let modelSource ← checked (decodeName (← checked (field cfg "sourceModelNameExpr")))
  let modelTarget ← checked (decodeName (← checked (field cfg "targetModelNameExpr")))
  let sourceTYPE ← checked (relocateExpr #[(modelSource,modelTarget)] #[] #[] false
    (← checked (field source "actualTypeExpr")))
  let sourceLevels ← namesFromJson (← checked (field source "levelParams"))
  if ← checked (source.getObjValAs? Bool "hasSorryAx") then throwError "sorryAx flagged in source actual proof"
  for axiomKey in #["typeAxioms","valueAxioms"] do
    for axiomName in ← checked (source.getObjValAs? (Array String) axiomKey) do
      unless #["propext","Classical.choice","Quot.sound"].contains axiomName do throwError "Nonstandard source actual axiom {axiomName}"
  let sourceAxioms ← checked (source.getObjValAs? (Array String) "axioms")
  if sourceAxioms.contains "sorryAx" then throwError "sorryAx in source proof"
  for ax in sourceAxioms do
    unless #["propext","Classical.choice","Quot.sound"].contains ax do throwError "Nonstandard source proof axiom {ax}"
  let names := #[`AbcAdaptation.Tripod.legendre_isElliptic, `solution, `LegendrePlatformShape.platform_shape]
  let labels := #["canonical","solution","platform_shape"]
  let reference ← getConstInfo names[0]!
  let targetLevels := reference.levelParams.map Level.param
  let normalizedSourceTYPE := sourceTYPE.instantiateLevelParams sourceLevels targetLevels
  let _ ← kernelCheck "source actual root TYPE" normalizedSourceTYPE
  let mut reports : Array Json := #[Json.mkObj [
    ("role",toJson "source"),("nameExpr",encodeName sourceName),
    ("actualTYPE",← checked (encodeExpr normalizedSourceTYPE)),
    ("sourceOriginalLevelParams",Json.arr (sourceLevels.toArray.map encodeName)),
    ("fullTYPEBinderInventory",toJson (binderInventory normalizedSourceTYPE)),
    ("originalFullProofReadAndRetainedInSourceFacts",toJson true),
    ("proofKernelCheckReusedFromAcceptedSourceAndCanonical7Receipts",toJson true),
    ("originalProofTermIdentityNotReplaced",toJson true),
    ("axioms",toJson sourceAxioms),("hasSorryAx",toJson false)]]
  for idx in [:names.size] do
    let ci ← getConstInfo names[idx]!
    if idx < 2 then
      let ownerKey := if idx == 0 then "canonicalOwnerNameExpr" else "solutionOwnerNameExpr"
      let expectedOwner ← checked (decodeName (← checked (field cfg ownerKey)))
      unless moduleOf (← getEnv) ci.name == some expectedOwner do throwError "Role owner differs {ci.name}"
    unless ci.levelParams.length == sourceLevels.length do throwError "Universe arity mismatch {ci.name}"
    let normalizedTYPE := ci.type.instantiateLevelParams ci.levelParams targetLevels
    unless binderInventory normalizedTYPE == binderInventory normalizedSourceTYPE &&
      binderPlacement normalizedTYPE == binderPlacement normalizedSourceTYPE do
        throwError "Full TYPE BinderInfo differs {ci.name}"
    typeEq ci.name.toString normalizedTYPE normalizedSourceTYPE
    let some value := ci.value? (allowOpaque := true) | throwError "Missing full actual proof {ci.name}"
    let normalizedValue := value.instantiateLevelParams ci.levelParams targetLevels
    let inferred ← kernelCheck s!"actual proof {ci.name}" normalizedValue
    typeEq s!"proof TYPE {ci.name}" inferred normalizedTYPE
    let axioms ← collectAxioms ci.name
    ensureStandard ci.name.toString axioms
    ensureStandard s!"proof body {ci.name}" (← expressionAxioms normalizedValue)
    reports := reports.push (Json.mkObj [
      ("role",toJson labels[idx]!),("nameExpr",encodeName ci.name),
      ("ownerNameExpr",(moduleOf (← getEnv) ci.name).map encodeName |>.getD Json.null),
      ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
      ("actualTYPE",← checked (encodeExpr ci.type)),
      ("fullTYPEBinderInventory",toJson (binderInventory ci.type)),
      ("TYPEBinderInfoPlacementEqualsSource",toJson true),
      ("TYPEKernelEqualsSource",toJson true),
      ("fullActualProofKernelChecked",toJson true),
      ("actualProofInferredTYPEKernelEqual",toJson true),
      ("axioms",toJson (axioms.map Name.toString)),("hasSorryAx",toJson false)])
  let output ← checked (cfg.getObjValAs? String "outputFile")
  unless output.startsWith "/" do throwError "Output must be absolute"
  if let some parent := (System.FilePath.mk output).parent then IO.FS.createDirAll parent
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "B1-Legendre-four-role-review/v140"),("configuration",cfg),
    ("roles",Json.arr reports),("allFourTYPEsKernelEqual",toJson true),
    ("allFourProofAxiomChecksPassed",toJson true),
    ("platformOriginalTYPEPreservedExceptRecordedRootName",toJson true),
    ("allFourProofsSorryAxFree",toJson true)]).pretty ++ "\n")
  logInfo "Source/canonical/solution/platform payload TYPE and proof audit passed"
end LegendreFourRoleReview
