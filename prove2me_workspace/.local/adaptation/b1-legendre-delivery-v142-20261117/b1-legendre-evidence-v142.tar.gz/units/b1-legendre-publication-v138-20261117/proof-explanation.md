# English

Let $K$ be a field with $2\ne0$, and let $\lambda\in K$ satisfy $\lambda\ne0,1$. For the Legendre model, we prove

$$\Delta(E_\lambda)=16\lambda^2(\lambda-1)^2\ne0,$$

so its discriminant is a unit and the model is elliptic. Evaluate the Weierstrass invariants: $b_2=-4(1+\lambda)$, $b_4=2\lambda$, $b_6=0$, and $b_8=-\lambda^2$. Substitution into the discriminant formula gives the displayed identity. Since $16=2^4\ne0$ and both parameter factors are nonzero, their product is nonzero. Over a field this is equivalent to being a unit.

The Legendre-family background is Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV*, April 2020, §2, Corollary 2.2, opening paragraph, printed/PDF page 41: “the Legendre form ‘$y^2=x(x-1)(x-\lambda)$’ of the Weierstrass equation defining an elliptic curve”. The explicit field-uniform discriminant calculation above is the supporting algebraic argument of the formal source; the quotation supplies the family, rather than this calculation.

# 简体中文

设 $K$ 为满足 $2\ne0$ 的域，$\lambda\in K$ 且 $\lambda\ne0,1$。对 Legendre 模型，证明

$$\Delta(E_\lambda)=16\lambda^2(\lambda-1)^2\ne0,$$

即可知其判别式为单位，从而得到椭圆性。直接计算 Weierstrass 不变量，有 $b_2=-4(1+\lambda)$、$b_4=2\lambda$、$b_6=0$ 和 $b_8=-\lambda^2$。代入判别式公式即得所示恒等式。由于 $16=2^4\ne0$，且两个参数因子均非零，乘积非零；域中非零元恰为单位。

曲线族的原文背景见望月新一《集合论多宇宙间算术 Teichmüller 理论》第四篇，2020 年 4 月版，第 2 节推论 2.2 开头，印刷及文件第 41 页。上述任意域上的判别式计算是形式源码中的辅助代数论证，不将该计算归于所引原文段落。

# 日本語

$K$ を $2\ne0$ を満たす体とし、$\lambda\in K$ は $\lambda\ne0,1$ を満たすとする。ルジャンドルモデルについて

$$\Delta(E_\lambda)=16\lambda^2(\lambda-1)^2\ne0$$

を示せば、判別式は単元となり、楕円性が従う。ワイエルシュトラス不変量を計算すると、$b_2=-4(1+\lambda)$、$b_4=2\lambda$、$b_6=0$、$b_8=-\lambda^2$ である。判別式の公式への代入により、表示した恒等式が得られる。$16=2^4\ne0$ であり、二つのパラメータ因子も零でないため、積は零でない。体において非零元は単元である。

曲線族の出典は望月新一『宇宙際 Teichmüller 理論 IV』2020 年 4 月版、第 2 節、系 2.2 冒頭、印刷・ファイル第 41 ページである。任意の体上の判別式計算は形式ソースの補助的な代数的論証であり、引用した段落そのものの主張とはしない。
