# Translations of the frozen English read-backs

Derived from original-readback.en.md, SHA-256 ec80e761e9fc9f833dc2e24567ba1237c5063cec71eb032579cc61506004ed88. These translations are not separate independent read-backs. Translator: the same agent in a translation phase after the English freeze.

## Definition — 简体中文

对每个宇宙层级 $u$、该宇宙中每个带有交换环结构的类型 $R$，以及每个参数 $\lambda\in R$，Legendre 模型 $E_\lambda$ 定义为 $R$ 上的 Weierstrass 系数记录，其五个系数为 $a_1=0$、$a_2=-(1+\lambda)$、$a_3=0$、$a_4=\lambda$ 和 $a_6=0$。因此，对坐标 $x,y\in R$，其对应的 Weierstrass 方程 $y^2+a_1xy+a_3y=x^3+a_2x^2+a_4x+a_6$ 为 $y^2=x^3-(1+\lambda)x^2+\lambda x=x(x-1)(x-\lambda)$。环是隐式参数，参数 $\lambda$ 是显式参数；此定义没有要求 $R$ 非平凡，没有限制其特征，也没有排除 $\lambda=0$ 或 $\lambda=1$。

## Definition — 日本語

任意の宇宙レベル $u$、その宇宙に属する可換環構造を備えた任意の型 $R$、および任意のパラメータ $\lambda\in R$ に対し、ルジャンドルモデル $E_\lambda$ は、五つの係数が $a_1=0$、$a_2=-(1+\lambda)$、$a_3=0$、$a_4=\lambda$、$a_6=0$ である $R$ 上のワイエルシュトラス係数レコードとして定義される。したがって、座標 $x,y\in R$ に対するワイエルシュトラス方程式 $y^2+a_1xy+a_3y=x^3+a_2x^2+a_4x+a_6$ は $y^2=x^3-(1+\lambda)x^2+\lambda x=x(x-1)(x-\lambda)$ である。環は暗黙のパラメータ、$\lambda$ は明示的なパラメータである。この定義は、$R$ が非自明であることを仮定せず、標数を制限せず、$\lambda=0$ および $\lambda=1$ を除外しない。

## Theorem — 简体中文

对每个宇宙层级 $u$、底层类型位于该宇宙中的每个域 $K$，在另有 $K$ 中 $2\ne0$ 的假设下，对每个 $\lambda\in K$，显式假设 $h_0:\lambda\ne0$ 和 $h_1:\lambda\ne1$ 推出：Legendre Weierstrass 系数记录 $E_\lambda=(0,-(1+\lambda),0,\lambda,0)$ 满足此处称为“椭圆”的性质，其中该记录对 $x,y\in K$ 的方程为 $y^2=x^3-(1+\lambda)x^2+\lambda x$；该性质的实际含义是其判别式 $\Delta(E_\lambda)$ 为 $K$ 的可逆元，即存在 $d\in K$ 使得 $\Delta(E_\lambda)d=d\Delta(E_\lambda)=1$。这里，$K$ 和 $\lambda$ 是隐式参数，域结构及条件 $2\ne0$ 是类型类假设。用这些系数表示，判别式为 $\Delta(E_\lambda)=16\lambda^2(\lambda-1)^2$；因此，所断言的可逆元条件在该域中等价于 $16\lambda^2(\lambda-1)^2\ne0$。该陈述允许任何与 $2\ne0$ 相容的域特征，包括特征 $3$，并且不对域或 $\lambda$ 施加其他条件。

## Theorem — 日本語

任意の宇宙レベル $u$ と、台となる型がその宇宙に属する任意の体 $K$ に対し、さらに $K$ において $2\ne0$ を仮定すると、任意の $\lambda\in K$ について、明示的な仮定 $h_0:\lambda\ne0$ と $h_1:\lambda\ne1$ から、ルジャンドルのワイエルシュトラス係数レコード $E_\lambda=(0,-(1+\lambda),0,\lambda,0)$ が、ここで「楕円的」と呼ばれる性質を満たすことが従う。このレコードの $x,y\in K$ に対する方程式は $y^2=x^3-(1+\lambda)x^2+\lambda x$ であり、この性質の実際の内容は、判別式 $\Delta(E_\lambda)$ が $K$ の単元であること、すなわち $\Delta(E_\lambda)d=d\Delta(E_\lambda)=1$ を満たす $d\in K$ が存在することである。ここで、$K$ と $\lambda$ は暗黙のパラメータであり、体構造と条件 $2\ne0$ は型クラスの仮定である。これらの係数を用いると判別式は $\Delta(E_\lambda)=16\lambda^2(\lambda-1)^2$ であるため、主張される単元条件は、この体において $16\lambda^2(\lambda-1)^2\ne0$ と同値である。この命題では、標数 $3$ を含めて $2\ne0$ と両立する任意の体の標数が許され、体または $\lambda$ にそれ以外の条件は課されない。
