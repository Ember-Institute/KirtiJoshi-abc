Independent two-unit blind read-back package.

- original-readback.en.md: frozen English originals (two paragraphs).
- freeze.json: original English SHA-256 and freeze record.
- translations.md / translations.json: aligned Simplified Chinese and Japanese translations.
- readback-fields.json: two locally prepared readback/readback_model records.
- field-quantifier-correspondence.md: binder, field, conclusion, terminology, and formal dependency mapping.
- input-manifest.json: full input file SHA-256 values.
- startup-record.json: reader model and permitted action record.
- Two .lean files: exact copies of the two audited source files.

No compilation, CI, API, Git command, or main-workspace edit was performed.
