# Field and quantifier correspondence

These are two public units: one definition and one theorem. The private auxiliary lemmas in the theorem file are formal proof context; they have not been made into public read-back units. The English original was frozen before the translations were produced.

## Definition: `AbcAdaptation.Tripod.legendre`

| Formal component | Literal content | English / 简体中文 / 日本語 alignment |
| --- | --- | --- |
| `{R : Type*}` | Implicit type parameter, universe-polymorphic | Every universe level and every type in it / 每个宇宙层级及其中每个类型 / 任意の宇宙レベルとその宇宙に属する任意の型 |
| `[CommRing R]` | Commutative ring structure, a typeclass argument | A commutative ring / 交换环 / 可換環 |
| `(l : R)` | Explicit parameter | Every $\lambda\in R$ / 每个 $\lambda\in R$ / 任意の $\lambda\in R$ |
| `: WeierstrassCurve R` | Output is a five-field coefficient record over the same ring | Weierstrass coefficient record / Weierstrass 系数记录 / ワイエルシュトラス係数レコード |
| First constructor field | $a_1=0$ | Same formula in all three languages |
| Second constructor field | $a_2=-(1+\lambda)$ | Same formula in all three languages |
| Third constructor field | $a_3=0$ | Same formula in all three languages |
| Fourth constructor field | $a_4=\lambda$ | Same formula in all three languages |
| Fifth constructor field | $a_6=0$ | Same formula in all three languages |
| Associated equation | $y^2=x^3-(1+\lambda)x^2+\lambda x=x(x-1)(x-\lambda)$ | $x,y$ are explanatory coordinates over $R$, not additional definition arguments |
| No nontriviality restriction | `CommRing` allows the zero ring | Explicitly retained in all three languages |
| No restriction on characteristic or parameter | Definition applies also at $\lambda=0$ or $\lambda=1$ | Explicitly retained in all three languages |

## Theorem: `AbcAdaptation.Tripod.legendre_isElliptic`

| Binder order or conclusion | Literal content | English / 简体中文 / 日本語 alignment |
| --- | --- | --- |
| Universe | Arbitrary universe of the underlying field type | Every universe level / 每个宇宙层级 / 任意の宇宙レベル |
| Root section `{K : Type*}` | Implicit field carrier parameter | Every field $K$ with its underlying type in that universe / 底层类型位于该宇宙中的每个域 $K$ / その宇宙に属する型を台とする任意の体 $K$ |
| Root section `[Field K]` | Field structure, typeclass argument | Field / 域 / 体 |
| `[NeZero (2 : K)]` | Typeclass assumption that $2\ne0$ in $K$ | Stated literally as $2\ne0$ in all three languages |
| `{l : K}` | Implicit scalar parameter | Every $\lambda\in K$, implicit / 每个 $\lambda\in K$，隐式 / 任意の $\lambda\in K$、暗黙 |
| `(h0 : l ≠ 0)` | First explicit hypothesis | $h_0:\lambda\ne0$ in all three languages |
| `(h1 : l ≠ 1)` | Second explicit hypothesis | $h_1:\lambda\ne1$ in all three languages |
| `(legendre l).IsElliptic` | The coefficient record's discriminant is a unit | Unit / 可逆元 / 単元, explicitly expanded by an inverse $d$ |
| `IsElliptic.isUnit : IsUnit W.Δ` | Sole field of the proposition-valued class | Existence of $d\in K$ with $\Delta d=d\Delta=1$ in all three languages |
| Private discriminant calculation | $\Delta(E_\lambda)=16\lambda^2(\lambda-1)^2$ | Included only to expand the conclusion's mathematical content, not as a new public theorem |
| Field equivalence | Being a unit is equivalent to being nonzero | $16\lambda^2(\lambda-1)^2\ne0$ in all three languages |
| Characteristic scope | Requires $2\ne0$; no characteristic-$3$ exclusion | Explicitly retained in all three languages |

## Formal dependency content used

For a general coefficient record $W$, mathlib defines

$$b_2=a_1^2+4a_2,\qquad b_4=2a_4+a_1a_3,\qquad b_6=a_3^2+4a_6,$$
$$b_8=a_1^2a_6+4a_2a_6-a_1a_3a_4+a_2a_3^2-a_4^2,$$
$$\Delta(W)=-b_2^2b_8-8b_4^3-27b_6^2+9b_2b_4b_6.$$

The class `WeierstrassCurve.IsElliptic` has exactly the field `isUnit : IsUnit W.Δ`. The private auxiliary declarations in the given theorem file specialize these invariants to the given coefficients. No geometric consequence beyond the stated unit condition has been added to the read-back.

## Terminology and translation provenance

English $\lambda$ corresponds to the Lean identifier `l` throughout. Standard terms used here are: commutative ring / 交换环 / 可換環; field / 域 / 体; discriminant / 判别式 / 判別式; unit / 可逆元 / 単元; implicit parameter / 隐式参数 / 暗黙のパラメータ. Chinese preserves `Legendre` and `Weierstrass` in Latin spelling. Japanese uses the conventional name forms ルジャンドル and ワイエルシュトラス and the neutral explanatory plain style. No unknown technical term requiring a translation placeholder was encountered. No external terminology or paper source was consulted; this is not a claim of external terminology verification.

The original English has one self-contained paragraph for each declaration. The Chinese and Japanese paragraphs are translations of those frozen English paragraphs, not three independent audit conclusions. The stored read-back fields use actual keys `readback` and `readback_model`; per-language keys inside the local translation JSON are local archival data, not claimed platform fields. No platform action was performed.
