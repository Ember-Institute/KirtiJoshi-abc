已使用 source parser ci-018604-c1b9825d 的终态 succeeded 输出，生成两片 AST 来源源码。

verified-freeze.json 绑定 source／normalized source／AST／request／receipt 与输出 pins；12个数学声明命令全部按字节与原 source 相同，含模型1项和椭圆性证明链11项。仅上下文 namespace identifier 由 Iut.Tripod 重定位为 AbcAdaptation.Tripod。

本目录两片替代早先 Definitions 中 raw-pinned Legendre 候选。原目录保留作历史，本目录已补齐 AST 证据，不代表 source 完整 proof Expr 或 native correspondence 已通过。主智能体下一步统一取得完整 source proof，再做目标编译和 actual 对应。子智能体未编译、CI、API、Git、主区写。
