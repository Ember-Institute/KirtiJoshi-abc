import Lean
import Solutions.Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_LocalEstimate_rhs_le
import Theorems.Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_LocalEstimate_rhs_le

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

def valueOf (ci : ConstantInfo) : Option Expr :=
  match ci with
  | .thmInfo i => some i.value
  | .defnInfo i => some i.value
  | .opaqueInfo i => some i.value
  | _ => none

run_meta do
  let cfg ← jsonFile (← absoluteEnv "RHS_LE_FULL_PROOF_AUDIT_CONFIG")
  unless (← checked (cfg.getObjValAs? String "schema")) == "rhs-le-full-source-proof-audit/v54" do
    throwError "Wrong rhs_le full source proof audit configuration"
  unless Lean.versionString == (← checked (cfg.getObjValAs? String "expectedCompiler")) do
    throwError "Wrong compiler version"
  let text ← IO.FS.readFile (← checked (cfg.getObjValAs? String "installedSolution"))
  unless text == (← checked (cfg.getObjValAs? String "expectedSolutionText")) do
    throwError "Installed solution source differs from pinned full source proof"
  let root := (← checked (cfg.getObjValAs? String "root")).toName
  let ownModule := (← checked (cfg.getObjValAs? String "rootModule")).toName
  let forbidden := (← checked (cfg.getObjValAs? String "forbiddenParent")).toName
  let publicProofs ← checked (cfg.getObjValAs? (Array Json) "publicProofs")
  let expectedHelpers ← checked (cfg.getObjValAs? (Array String) "expectedPrivateHelperSuffixes")
  let requiredFields ← checked (cfg.getObjValAs? (Array String) "requiredLocalEstimateFields")
  let env ← getEnv
  let ci ← getConstInfo root
  let parent ← getConstInfo forbidden
  unless moduleOf env root == some ownModule do throwError "Wrong solution module"
  unless ci.levelParams.length == parent.levelParams.length do throwError "Universe arity differs"
  let us := (canonicalLevels ci.levelParams.length).map Level.param
  kernelTypeEq "complete rhs_le parent/solution TYPE"
    (ci.type.instantiateLevelParams ci.levelParams us)
    (parent.type.instantiateLevelParams parent.levelParams us)
  unless binderInventory ci.type == binderInventory parent.type &&
      binderPlacement ci.type == binderPlacement parent.type do
    throwError "Complete BinderInfo placement differs"
  -- Compare against the immutable accepted actual-source/parent TYPE audit. The
  -- parent theorem is imported only for TYPE comparison; its proof is never read.
  let binding ← checked (cfg.getObjVal? "acceptedParentTypeAuditBinding")
  let facts ← jsonFile (← checked (binding.getObjValAs? String "path"))
  unless facts == (← checked (binding.getObjVal? "contents")) do
    throwError "Accepted parent TYPE facts changed"
  unless (← checked (facts.getObjValAs? String "targetName")) == forbidden.toString do
    throwError "Wrong accepted parent TYPE binding"
  for key in #["statementTypeAccepted", "completeKernelTypeEqual", "binderPlacementEqual", "binderInventoryEqual"] do
    unless ← checked (facts.getObjValAs? Bool key) do throwError "Parent source TYPE audit did not pass {key}"
  unless (← checked (encodeExpr parent.type)) == (← checked (facts.getObjVal? "targetTypeExpr")) do
    throwError "Current parent compiler TYPE differs from the accepted source TYPE audit"
  let expectedBI ← checked (cfg.getObjValAs? (Array String) "expectedTopLevelBinderInfo")
  let expectedNames ← checked (cfg.getObjValAs? (Array String) "expectedTopLevelBinderNames")
  let telescope ← forallTelescope ci.type fun xs result => do
    unless xs.size == (← checked (cfg.getObjValAs? Nat "expectedTopLevelBinders")) do
      throwError "Expected full five-binder rhs_le TYPE"
    let mut bs := #[]
    let mut bis := #[]
    let mut names := #[]
    for x in xs do
      let d ← x.fvarId!.getDecl
      bis := bis.push (encodeBinder d.binderInfo)
      names := names.push d.userName.toString
      bs := bs.push (Json.mkObj [("name",toJson d.userName.toString),
        ("binderInfo",toJson (encodeBinder d.binderInfo)),
        ("type",toJson (← ppExpr d.type).pretty)])
    unless bis == expectedBI && names == expectedNames do
      throwError "The original implicit inv / explicit est input binding changed"
    return Json.mkObj [("binders",Json.arr bs),("result",toJson (← ppExpr result).pretty),
      ("topLevelBinderCount",toJson xs.size)]
  let mut queue := #[root]
  let mut checkedNames : Array Name := #[]
  let mut referenced : Array Name := #[]
  let mut importedPublic : Array Json := #[]
  let mut definitionsRows : Array Json := #[]
  let mut ownProofs : Array Json := #[]
  let mut i := 0
  while i < queue.size do
    let n := queue[i]!
    i := i + 1
    unless checkedNames.contains n do
      checkedNames := checkedNames.push n
      let info ← getConstInfo n
      let some value := valueOf info | throwError "Missing own-module proof value {n}"
      let actualType ← kernelCheck s!"own-module proof {n}" value
      kernelTypeEq s!"own-module proof inferred TYPE {n}" actualType info.type
      let proofUsed := value.getUsedConstants
      let typeUsed := info.type.getUsedConstants
      if proofUsed.contains `sorryAx || typeUsed.contains `sorryAx then
        throwError "Direct sorryAx in own-module declaration {n}"
      let axs ← collectAxioms n
      ensureStandard s!"own-module proof {n}" axs
      ownProofs := ownProofs.push (Json.mkObj [
        ("name",toJson n.toString),("type",toJson (← ppExpr info.type).pretty),
        ("proofDirectConstants",toJson (proofUsed.map Name.toString)),
        ("typeDirectConstants",toJson (typeUsed.map Name.toString)),
        ("axioms",toJson ((axs.qsort Name.lt).map Name.toString))])
      for dep in proofUsed ++ typeUsed do
        if dep == forbidden then throwError "Parent rhs_le occurs in its own proof closure"
        unless referenced.contains dep do referenced := referenced.push dep
        if moduleOf env dep == some ownModule then
          unless queue.contains dep do queue := queue.push dep
        else if let some owner := moduleOf env dep then
          if owner.toString.startsWith "Theorems." then
            let some row := publicProofs.find? (fun row =>
              (row.getObjValAs? String "name").toOption == some dep.toString)
              | throwError "Unclassified public theorem dependency {dep} from {owner}"
            unless (← checked (row.getObjValAs? String "module")) == owner.toString do
              throwError "Wrong public proof owner {dep}"
            unless (← checked (row.getObjValAs? String "status")) == "ACCEPTED" do
              throwError "Public proof is not classified ACCEPTED {dep}"
            unless importedPublic.contains row do importedPublic := importedPublic.push row
          else if owner.toString.startsWith "Definitions." then
            let row := Json.mkObj [("name",toJson dep.toString),("module",toJson owner.toString),
              ("kind",toJson (kind (← getConstInfo dep)))]
            unless definitionsRows.contains row do definitionsRows := definitionsRows.push row
          else if #[`Iut,`Genl,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf dep) then
            throwError "Original project constant remains in target proof: {dep}"
  for row in publicProofs do
    let n := (← checked (row.getObjValAs? String "name")).toName
    unless referenced.contains n do throwError "ACCEPTED finsum proof is not actually consumed {n}"
  for suffix in expectedHelpers do
    unless checkedNames.any (fun n => n.toString.endsWith suffix) do
      throwError "Private complete source helper is not consumed: {suffix}"
  for field in requiredFields do
    unless referenced.any (fun n => n.toString == field) do
      throwError "Original LocalEstimate field is not consumed: {field}"
  let rootAxioms ← collectAxioms root
  ensureStandard "complete rhs_le solution closure" rootAxioms
  let typeAxioms ← expressionAxioms ci.type
  ensureStandard "complete rhs_le solution TYPE" typeAxioms
  IO.FS.writeFile (← checked (cfg.getObjValAs? String "outputFile")) ((Json.mkObj [
    ("schema",toJson "rhs-le-full-source-proof-audit-facts/v54"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("root",toJson root.toString),("telescope",telescope),
    ("typeExpr",← checked (encodeExpr ci.type)),
    ("completeParentKernelTypeEqual",toJson true),
    ("completeBinderInventoryEqual",toJson true),("completeBinderPlacementEqual",toJson true),
    ("acceptedOriginalSourceTypeBindingEqual",toJson true),
    ("originalFiveBindersPreserved",toJson true),("parentValueRead",toJson false),
    ("parentProofReferenceAbsent",toJson true),("allLocalEstimateFieldsConsumed",toJson true),
    ("ownModuleProofs",Json.arr ownProofs),("allNineSourceHelpersConsumed",toJson true),
    ("importedPublicProofs",Json.arr importedPublic),
    ("definitionsConstants",Json.arr definitionsRows),
    ("allOwnModuleProofsKernelChecked",toJson true),
    ("typeAxioms",toJson (typeAxioms.map Name.toString)),
    ("proofAxioms",toJson ((rootAxioms.qsort Name.lt).map Name.toString)),
    ("standardAxiomsOnly",toJson true),("sorryAxAbsent",toJson true),
    ("closedConditionalRhsLeKernelProof",toJson true),
    ("localEstimateConstructed",toJson false),
    ("platformProofAcceptedByThisQuery",toJson false)]).pretty ++ "\n")
  logInfo "rhs_le complete five-binder TYPE, private/public consumption and standard axioms checked"
end FoundationAudit
