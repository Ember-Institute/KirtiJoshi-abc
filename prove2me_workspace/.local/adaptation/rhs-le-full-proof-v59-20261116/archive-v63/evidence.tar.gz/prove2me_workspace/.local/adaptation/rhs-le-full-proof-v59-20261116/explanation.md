**English**

For the given local-estimate record, the averaged right-hand log-volume is bounded by the average of the summed local bounds:

$$\operatorname{rhs}(X)\leq\frac{1}{m}\sum_{i<m}\left(\sum_{p\in S} B(|C_i|,p)+|C_i|\log\pi\right).$$

Here $m$ is the length of the supplied increasing family of label sets, $C_i$ its $i$-th label set, $S$ the distinguished-prime set, and $B$ the local bound in the statement. Minimality puts the hull of each theta-pilot region inside its supplied container. Monotonicity of packet log-volume then bounds that hull by the container volume. At distinguished finite primes use the supplied finite-prime estimate; at other primes the container is integral and has log-volume zero; at the infinite place use the supplied archimedean estimate. These bounds have finite support. Sum them and divide by the nonnegative family length. The local-estimate record is an explicit input; this proof does not construct it.

**简体中文**

对于给定的局部估计记录，右侧对数体积的平均值满足

$$\operatorname{rhs}(X)\leq\frac{1}{m}\sum_{i<m}\left(\sum_{p\in S} B(|C_i|,p)+|C_i|\log\pi\right).$$

其中，$m$ 是给定标签集递增族的长度，$C_i$ 是其中第 $i$ 个标签集，$S$ 是区分素数集，$B$ 是陈述中的局部界。包络的最小性说明，各个 theta 引导区域的包络包含在给定容器中；分量积包对数体积的单调性进一步给出容器体积上界。在区分的有限素数处使用给定局部估计，在其他有限素数处使用整区域的对数体积为零，在无穷处使用给定阿基米德估计。上界只有有限支撑，因而可以求和，再除以非负的递增族长度。局部估计记录仍是显式输入，本证明不构造它。

**日本語**

与えられた局所評価のレコードに対し、右辺の対数体積の平均は

$$\operatorname{rhs}(X)\leq\frac{1}{m}\sum_{i<m}\left(\sum_{p\in S} B(|C_i|,p)+|C_i|\log\pi\right)$$

を満たす。ここで、$m$ は与えられたラベル集合の増大族の長さ、$C_i$ は第 $i$ のラベル集合、$S$ は区別された素数の集合、$B$ は命題中の局所上界である。包絡の最小性によって、各 theta-pilot 領域の包絡は与えられた容器に含まれる。成分の積の対数体積の単調性により、その体積は容器の体積以下となる。区別された有限素数では仮定された局所評価を用い、その他の有限素数では整領域の対数体積が零であることを用いる。無限素点では仮定されたアルキメデス評価を用いる。上界の台は有限であるため和を取り、非負の増大族の長さで割ることができる。局所評価のレコードは明示的な入力として残り、この証明はそれを構成しない。

