from pathlib import Path
import json,hashlib,re,difflib
D=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/rhs-le-full-proof-v59-20261116');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';G=A/'main-chain-open-20261116/tools/generated';R=Path('/home/admin-wsl/Coq/abc/refer/iut');E=A/'reference-extraction-20261115'
for x in ['solution','source','queries','actual','frozen-imports']:(D/x).mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):
 p=D/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(x if isinstance(x,str)else json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p,dest):
 b=p.read_bytes();q=D/dest;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return {'path':str(p),'sha256':sha(b),'bytes':len(b),'frozenCopy':str(q)}
sourceBodyMaps=[];commands={};maps=[]
mainNames=['support_placeBound_subset','infinite_notMem_dstPlaces','finsum_placeBound','hull_subset_cont','packetVol_hull_le','globalVol_thetaHull_le','rhs_le'];prefix='Iut.Theorem110Invariants.LocalEstimate.'
for n in mainNames:
 key=(prefix+n).replace('.','_');mp=G/'metadata'/(key+'.json');m=json.loads(mp.read_text());p=Path(m['originalCoordinateSource']);b=p.read_bytes();span=m['originalRange'];c=b[span['start']['offset']:span['end']['offset']].decode();bp=m['oracleOriginalBodyByteMaps'][0];br=bp['originalRange'];body=b[br['start']['offset']:br['end']['offset']];assert sha(body)==bp['sha256'];commands[n]=c
 maps.append({'sourceName':prefix+n,'sourceModule':'Iut.Implication.LogVolumeBound','sourceMetadata':pin(mp,'source/'+key+'.metadata.json'),'coordinateSource':pin(p,'source/LogVolumeBound.normalized.lean'),'sourceRange':span,'sourceBodyRange':br,'sourceBodySHA256':sha(body),'sourceBodyBytes':len(body),'originalCommand':c,'edits':[],'proofBodyByteIdentical':True,'classification':'root'if n=='rhs_le'else'private_closed_source_proof'})
# Read complete accepted AST command/bodies for auxiliary modules.
for folder,mname,ns,shorts in [('reference-packet-field-carriers-20261115','Iut-Cor312-HolomorphicHull','Iut.HullSystem',['hull_mem_hullRegions','isHullRegion_hull']),('reference-volume-tate-carriers-20261115','Iut-Cor312-LogVolume','Iut.LogVolumeData',['finite_support_packetVol'])]:
 jp=A/folder/'parser-output'/(mname+'.jsonl');rs=[json.loads(l)for l in jp.open()];p=A/folder/'parser-output'/(mname+'.normalized.lean');b=p.read_bytes()
 for n in shorts:
  cd=next(r for r in rs if r.get('kind')=='compilerDecl'and r.get('name')==ns+'.'+n);index=cd['containingCommandIndices'][0];decl=next(r for r in rs if r.get('kind')=='decl'and r['commandIndex']==index);span=decl['range'];c=b[span['start']['offset']:span['end']['offset']].decode();br=decl['proofAndDefinitionBodyRanges'][0];body=b[br['start']['offset']:br['end']['offset']];commands[n]=c
  maps.append({'sourceName':ns+'.'+n,'sourceModule':mname.replace('-','.'),'sourceParserFacts':pin(jp,'source/'+mname+'.jsonl'),'coordinateSource':pin(p,'source/'+mname+'.normalized.lean'),'sourceRange':span,'sourceBodyRange':br,'sourceBodySHA256':sha(body),'sourceBodyBytes':len(body),'originalCommand':c,'edits':[],'proofBodyByteIdentical':True,'classification':'private_closed_source_proof'})
root='AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.rhs_le';public='AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.finsum_le_finsum_of_le';pubmod='Theorems.Thm_'+public.replace('.','_');solmod='Solutions.Sol_'+root.replace('.','_');solfile='solution/Sol_'+root.replace('.','_')+'.lean'
stubpath=W/('Theorems/Thm_'+root.replace('.','_')+'.lean');stub=stubpath.read_text();signature=stub[stub.index('theorem '+root):stub.index(':= by')].replace('theorem '+root,'theorem solution',1)
imports=['Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound',pubmod,'Mathlib.Algebra.BigOperators.Finprod','Mathlib.Algebra.Order.BigOperators.Group.Finset','Mathlib.Algebra.Order.Field.Basic','Mathlib.Data.Fintype.BigOperators','Mathlib.Data.Set.Finite.Lattice','Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic']
preamble='''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Full original rhs_le source proof. Internal source lemmas remain private.
   The complete original LocalEstimate input is retained. -/
'''+''.join('import '+i+'\n'for i in imports)+'''
set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
open NumberField
open AbcAdaptation.Reference.Iut
open AbcAdaptation.Reference.Iut.Theorem110Invariants
universe u v u₁ u₂

'''
sol=preamble
def private(n):
 global sol
 c=commands[n];pos=c.index('lemma '+n);adapt=c[:pos]+'private '+c[pos:];line=sol.count('\n')+1;sol+=adapt+'\n\n';row=next(x for x in maps if x['sourceName'].endswith('.'+n));row['targetCommand']=adapt;row['targetCommandStartLine']=line;row['edits'].append({'kind':'visibility','before':'lemma','after':'private lemma'});row['targetBodySHA256']=sha(adapt[adapt.index(':='):].encode())
sol+='''namespace AbcAdaptation.Reference.Iut.HullSystem
variable {C : Type u} {P : DirectSumPresentation.{u, v} C} (H : HullSystem P)
variable {U V : Set P.Total}

'''
private('hull_mem_hullRegions');private('isHullRegion_hull');sol+='end AbcAdaptation.Reference.Iut.HullSystem\n\n'
sol+='''namespace AbcAdaptation.Reference.Iut.LogVolumeData
open scoped Pointwise
variable {ι : Type u₁} {V : Type u₂}
variable {D : LargeVolumeContainerData.{u₁, u₂, v} ι V} (vol : LogVolumeData D)

''';private('finite_support_packetVol');sol+='end AbcAdaptation.Reference.Iut.LogVolumeData\n\n'
sol+='''namespace AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate
variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
variable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)
variable (est : inv.LocalEstimate)

-- Restore the local equation simplification context of the published Definitions.
attribute [local simp] dstPlaces.eq_1 placeBound.eq_1 placeBound.eq_2

'''
for n in mainNames[:3]:private(n)
sol+='variable {inv}\ninclude est\n\n'
for n in mainNames[3:6]:private(n)
sol+='end AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate\n\n'
sol+='open AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate\n\n'+signature
bodyrow=next(x for x in maps if x['classification']=='root');body=Path(bodyrow['coordinateSource']['frozenCopy']).read_bytes()[bodyrow['sourceBodyRange']['start']['offset']:bodyrow['sourceBodyRange']['end']['offset']];rootBodyStart=len(sol.encode());sol+=body.decode()+'\n';write(solfile,sol)
for row in maps:
 c=row.get('targetCommand',commands['rhs_le']);br=row['sourceBodyRange'];bb=Path(row['coordinateSource']['frozenCopy']).read_bytes()[br['start']['offset']:br['end']['offset']];assert bb==c[c.index(':='):].encode(),row['sourceName'];row['targetBodySHA256']=sha(bb);row['targetContextChange']='Only adapted namespace and original inherited parameters restored; no mathematical input added.'
bodyrow['targetCommandStartLine']=sol[:sol.index('theorem solution')].count('\n')+1;bodyrow['targetBodyStartByte']=rootBodyStart;bodyrow['canonicalParentSignatureExactExceptDeclarationName']=True
write('proof-source-map.json',maps)
registry=A/'platform-node-registry.json';r=json.loads(registry.read_text());pub=next(x for x in r['reference_source_preparation']['proved_nodes']if x['name']==public);assert pub['verification_status']=='ACCEPTED';pubpath=W/(pubmod.replace('.','/')+'.lean')
write('dependencies.json',{'schema':'rhs-le-full-source-proof-dependencies/v54','registry':pin(registry,'source/platform-node-registry.json'),'acceptedPublicProofs':[{'name':public,'module':pubmod,'platform':pub,'canonicalFile':pin(pubpath,'frozen-imports/'+pubmod.replace('.','/')+'.lean'),'localCanonicalContainsSorry':bool(re.search(r'\bsorry\b',pubpath.read_text()))}],'privateClosedSourceProofs':[x['sourceName']for x in maps if x['classification']=='private_closed_source_proof'],'semanticOpenChildren':[],'parentInputTelescope':['AG implicit','TG implicit','X implicit','inv implicit','est explicit'],'newMathematicalParameters':[],'localEstimateFieldsPreserved':['cont','cont_mem_hullRegions','thetaPilot_subset','cont_eq_integral','vol_finite','vol_infinite','packetVol_mono'],'allFieldsActuallyConsumedExpected':True,'publicImports':imports,'dependencyStatus':'source AST/graph closure; compiled proof-term dependency audit pending'})
# Preserve graph classification for all requested local proofs and every project dependency.
graph=[json.loads(l)for l in(E/'c22-decl-graph.jsonl').open()];gmap={x['name']:x for x in graph if x.get('record')=='decl'};selected={x['sourceName']for x in maps}|{'Iut.Theorem110Invariants.LocalEstimate.finsum_le_finsum_of_le'};grows=[gmap[x]for x in sorted(selected)];project=set()
for g in grows:project.update(x for x in g['directTypeDeps']+g['directValueDeps']if x.startswith(('Iut.','Genl.')))
classified=[]
for n in sorted(project):
 owner=gmap.get(n);cl='private-source-proof'if n in selected and n not in ['Iut.Theorem110Invariants.LocalEstimate.rhs_le','Iut.Theorem110Invariants.LocalEstimate.finsum_le_finsum_of_le']else'accepted-public-proof'if n.endswith('.finsum_le_finsum_of_le')else'source-root'if n.endswith('.rhs_le')else'data/projection/definition/retained-Definitions-proof'
 classified.append({'sourceName':n,'classification':cl,'owner':owner.get('module')if owner else None,'kind':owner.get('kind')if owner else None,'axioms':owner.get('axioms')if owner else None,'nativeMappedPrefix':'AbcAdaptation.Reference.'+n})
write('source-graph-closure.json',{'schema':'rhs-le-source-actual-graph-closure/v54','graph':pin(E/'c22-decl-graph.jsonl','source/c22-decl-graph.jsonl'),'selectedRows':grows,'classifiedProjectDirectConstants':classified,'note':'Actual accepted source compiler graph. Native target consumption remains pending; private/generated proof term closure is checked by query.'})
# Static target import closure excludes parent and original source imports.
seen={};todo=imports.copy();external=set()
while todo:
 m=todo.pop()
 if m in seen or m in external:continue
 p=W/(m.replace('.','/')+'.lean')
 if not p.exists():external.add(m);continue
 txt=p.read_text();im=re.findall(r'^import\s+(\S+)',txt,re.M);seen[m]={'source':pin(p,'frozen-imports/'+m.replace('.','/')+'.lean'),'imports':im};todo.extend(im)
assert 'Theorems.Thm_'+root.replace('.','_')not in seen
assert all(not m.startswith(('Iut.','Genl.'))for m in seen)
mathroot=Path('/home/admin-wsl/Coq/mathlib4-0df444a');missing=[m for m in external if m.startswith('Mathlib.')and not(mathroot/(m.replace('.','/')+'.lean')).exists()];assert not missing,missing
write('static-import-audit.json',{'compiled':False,'parentImportAbsent':True,'originalProjectImportAbsent':True,'projectModules':seen,'externalModules':sorted(external),'missingMathlibSourceImports':missing})
up=R/'Iut/Implication/LogVolumeBound.lean';eff=Path(bodyrow['coordinateSource']['frozenCopy']);write('source/upstream-effective.diff',''.join(difflib.unified_diff(up.read_text().splitlines(True),eff.read_text().splitlines(True),fromfile=str(up),tofile=str(eff))))
write('source/root-source.json',{'schema':'rhs-le-full-source-proof-pins/v54','canonicalParentStub':pin(stubpath,'source/canonical-parent-stub.lean'),'upstreamSource':pin(up,'source/upstream-LogVolumeBound.lean'),'effectiveSource':bodyrow['coordinateSource'],'sourceRoot':'Iut.Theorem110Invariants.LocalEstimate.rhs_le','targetParent':root,'mainBodyBytes':len(body),'mainBodySHA256':sha(body),'mainBodyByteExact':True,'mainBodyStartByte':rootBodyStart,'sourceTypeFacts':pin(A/'rhs-le-open-v46-20261116/actual/source-type.json','source/source-type.json'),'targetTypeAuditFacts':pin(A/'rhs-le-open-v46-20261116/actual/target-type-audit.json','source/target-type-audit.json'),'receiptPolicy':'Facts pinned; parent agent retains accepted CI receipt authority.'})
write('adaptation-differences.json',{'schema':'rhs-le-full-source-proof-adaptations/v54','mainProofBodyByteExact':True,'allNinePrivateProofBodiesByteExact':True,'canonicalFullFiveBinderSignatureExactExceptName':True,'sourceEffectiveDifference':'Original effective LogVolumeBound inserts relaxedAutoImplicit/maxSynthPendingDepth options. Source proof bodies retained. Exact diff included.','namespaceVisibilityChanges':'Original names in adapted namespaces; helper lemmas private; top-level root renamed solution.','localCompatibilityContext':[{'text':'attribute [local simp] dstPlaces.eq_1 placeBound.eq_1 placeBound.eq_2','reason':'Published native Definitions declares these local equation simp attributes internally; local attributes are not exported to importers, so restore them here for original simp proofs.'}],'originalContextRetained':['open NumberField','universe u v (extra u₁,u₂ for complete original LogVolumeData helper)','{AG} {TG} {X} (inv) (est)','variable {inv}; include est before estimator proofs'],'extraMathAssumptions':[],'deletedLocalEstimateFields':[],'additionalClosedHelpersRecovered':['HullSystem.hull_mem_hullRegions','HullSystem.isHullRegion_hull','LogVolumeData.finite_support_packetVol'],'compilationStatus':'not compiled'})
# Save shared native audit support without importing the old c2 solution.
q=Path('/tmp/p2m-c2-parent-reduction-v49-20261116/queries/audit-support-prefix.lean.txt').read_text();q=q.replace('import Solutions.Sol_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2','import '+solmod).replace('import Theorems.Thm_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2','import Theorems.Thm_'+root.replace('.','_'));write('queries/audit-support-prefix.lean.txt',q)
# Runtime classification includes standard Definitions data and complete retained proof values.
fields=['cont','cont_mem_hullRegions','thetaPilot_subset','cont_eq_integral','vol_finite','vol_infinite','packetVol_mono']
config={'schema':'rhs-le-full-source-proof-audit/v54','expectedCompiler':'4.33.1','root':'solution','rootModule':solmod,'forbiddenParent':root,'expectedTopLevelBinders':5,'expectedTopLevelBinderInfo':['implicit','implicit','implicit','implicit','default'],'expectedTopLevelBinderNames':['AG','TG','X','inv','est'],'requireStandardAxiomsOnly':True,'publicProofs':[{'name':public,'module':pubmod,'theoremId':pub['theorem_id'],'status':'ACCEPTED'}],'expectedPrivateHelperSuffixes':['AbcAdaptation.Reference.'+x['sourceName']for x in maps if x['classification']=='private_closed_source_proof'],'requiredLocalEstimateFields':['AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.'+x for x in fields],'installedSolution':str(W/'Solutions'/Path(solfile).name),'expectedSolutionText':sol,'acceptedParentTypeAuditBinding':{'path':str(D/'source/target-type-audit.json'),'contents':json.loads((D/'source/target-type-audit.json').read_text())},'outputFile':str(D/'actual/proof-audit.json')};write('queries/proof-audit.config.json',config)
write('queries/install-map.json',{'solutionSource':str(D/solfile),'solutionDestination':config['installedSolution'],'auditSource':str(D/'queries/QueryRhsLeFullProofAudit.lean'),'configSource':str(D/'queries/proof-audit.config.json'),'structuredEnvironment':{'RHS_LE_FULL_PROOF_AUDIT_CONFIG':str(D/'queries/proof-audit.config.json')},'mainAgentMustUpdateIfRelocated':['installedSolution','expectedSolutionText if source edited','acceptedParentTypeAuditBinding.path','outputFile'],'compilationSubmitted':False})
print(json.dumps({'directory':str(D),'solutionSHA256':sha(sol.encode()),'mainProofSHA256':sha(body),'mainProofBytes':len(body),'privateHelpers':9,'publicAcceptedHelpers':1,'projectImportCount':len(seen)},ensure_ascii=False,indent=2))
