这是 rhs_le 的完整来源证明草稿，仅写入本临时目录。未编译，未调用 CI/API/Git，未修改主工作区及其 parser 输入。

入口：`solution/Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_LocalEstimate_rhs_le.lean`。它定义顶层 `solution`，完整复制当前父 stub 的五参数类型：`{AG} {TG} {X} {inv} (est : inv.LocalEstimate)`，只改声明名。主证明（含 `:= by`）173 bytes，SHA256 `ab28a6f0187a9ec79e1a557a1639eaa47b86f85ca07baca823ce164847f2905e`；与来源 AST 的完整 body 逐字相同。最终 solution SHA256 为 `8d8023a0700dd3d9f76a5354ab0c2f3f08c431058d3e0a2487fe98232a8f4b9c`。

实际闭包的九项完整辅助均保持私有：LogVolumeBound 的 support_placeBound_subset、infinite_notMem_dstPlaces、finsum_placeBound、hull_subset_cont、packetVol_hull_le、globalVol_thetaHull_le；加上当前 Definitions 未携带但被实际消费的 HullSystem.hull_mem_hullRegions、HullSystem.isHullRegion_hull、LogVolumeData.finite_support_packetVol。这三项也直接复制已接受 AST 中的原始完整命令。`proof-source-map.json` 记录十个证明的完整原命令、精确范围、body hashes、目标行号与继承绑定上下文。

公开证明只导入真实 canonical `AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.finsum_le_finsum_of_le`，平台 ID `74897806-a937-47a4-bb31-e5d27dc5f24c`、submission `a58c4f44-6386-411d-84b3-3030a0393079`、ACCEPTED；该 canonical 本地含完整证明。`dependencies.json` 固定 registry 和 canonical 文件。`source-graph-closure.json` 保留已接受来源编译图中的直接类型/值依赖，并分类私有来源证明、公开 ACCEPTED 证明、Definitions 数据/投影/完整证明及重新生成的 compiler auxiliaries。没有新增 Open 语义子节点或数学假设。

原有 `LocalEstimate` 七字段全部保持；此证明消费这些字段，但不构造 LocalEstimate。必要兼容上下文已明确记录：恢复当前 published Definitions 内部使用的 `attribute [local simp] dstPlaces.eq_1 placeBound.eq_1 placeBound.eq_2`，以及一般 LogVolumeData helper 的原 Pointwise scope。没有修改任何 proof body，没有替换或新建局部实例；`RationalPlace` 的原 DecidableEq 来自当前 canonical 数据模块。effective source 相对上游只多两个项目选项，精确差异见 `source/upstream-effective.diff`。

`queries/QueryRhsLeFullProofAudit.lean` 与 `queries/proof-audit.config.json` 供主智能体整合后经 MCP-CI 执行。结构化环境变量：`RHS_LE_FULL_PROOF_AUDIT_CONFIG`。查询要求：安装源码固定文本一致；solution/父 stub 完整 kernel TYPE、universe arity、全部 BinderInfo 位置一致；原五个绑定及 `{inv}`/显式 est 保留；当前父 TYPE 与已接受原源码 TYPE 审查 facts 精确绑定；展开同模块 private/generated proofs 并 kernel check；九个私有辅助、唯一公开 ACCEPTED proof、七个 LocalEstimate 字段都实际消费；无父 rhs_le 自引用；无未分类 Theorems 依赖；TYPE/完整 proof axiom 闭包仅 Lean 标准公理，禁止 sorryAx。父 rhs_le 只为 TYPE 比较导入，审查不读其证明值。输出区分“条件 rhs_le 的封闭 kernel 证明”与“构造 est/平台已验收”，后两项不由本查询宣称。

`queries/install-map.json` 给出安装指针。主智能体如更换目录，须同步 config 的 installedSolution、source TYPE facts path 和 outputFile；如修改源码，须重新固定 expectedSolutionText 并更新差异/hash，不能沿用旧输入版本的审查。

`static-validation.json` 只记录静态验收：10/10 proof bodies byte exact，完整类型签名复制、无 sorry token、29个项目模块导入闭包无父目标/原项目导入、Mathlib 导入源均存在。全部 Lean 兼容性和公理/实际消费检查仍待主智能体完成。`artifact-manifest.json` 固定本交付包。
