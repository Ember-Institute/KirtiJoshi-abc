/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Theorems.Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators

theorem AbcAdaptation.Reference.Iut.Theorem110Invariants.sum_arch (L : ℕ) :
    ∑ i : Fin L, (((i : ℕ) + 2 : ℕ) : ℝ) * Real.log Real.pi =
      Real.log Real.pi * (L * (L + 3) / 2) := by sorry
