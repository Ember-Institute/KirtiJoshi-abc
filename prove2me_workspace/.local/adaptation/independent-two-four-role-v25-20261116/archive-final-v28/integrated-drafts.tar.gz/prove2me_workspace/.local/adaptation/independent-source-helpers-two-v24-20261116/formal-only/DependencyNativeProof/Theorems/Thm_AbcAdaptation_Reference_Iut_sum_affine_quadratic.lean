import Mathlib.Data.Real.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
namespace AbcAdaptation.Reference
namespace Iut


lemma sum_affine_quadratic (L : ℕ) (a b c : ℝ) :
    ∑ i : Fin L, (a * ((i : ℝ) + 2) + b * ((i : ℝ) + 1) ^ 2 + c) =
      a * (L * (L + 3) / 2) + b * (L * (L + 1) * (2 * L + 1) / 6) + c * L := by
  rw [Fin.sum_univ_eq_sum_range (fun i => a * ((i : ℝ) + 2) + b * ((i : ℝ) + 1) ^ 2 + c) L]
  induction L with
  | zero => simp
  | succ n ih =>
    rw [Finset.sum_range_succ, ih]
    push_cast
    ring
end Iut
end AbcAdaptation.Reference
