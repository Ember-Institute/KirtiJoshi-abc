#!/usr/bin/env python3
"""Rebuild only this task's offline audit configs and private packet drafts."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent


def prepare():
    modules = []
    for name in ['prepare_audits', 'prepare_packets', 'append_context']:
        spec = importlib.util.spec_from_file_location(name, D / (name + '.py'))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        modules.append(module)
    modules[0].prepare()
    modules[1].prepare()
    return modules[2].append()


if __name__ == '__main__':
    prepare()
    print('Prepared two offline four-role/private packets; actual facts and all gates remain unbound.')
