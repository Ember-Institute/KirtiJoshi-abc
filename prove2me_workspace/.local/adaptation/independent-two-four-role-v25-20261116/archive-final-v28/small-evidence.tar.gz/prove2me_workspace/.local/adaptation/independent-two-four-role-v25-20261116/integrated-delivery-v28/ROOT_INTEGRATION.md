两个完整 canonical proof 候选已由 root 整合；这里没有写主区、运行 CI/compiler/API/Git。

最终 artifact 已由 root 完成：

- finsum：ci-017123-d18b1bad；当前候选 SHA `93b27971ff2c96a2611dc2672621cd9901b8297eeb37d792a78ab7b10df5db7a`。
- sum_arch：ci-017124-fb3a7f3f；当前候选 SHA `a72be08d12c27b8249616530dabf1062e4ac0bb5098ace0fdd191c5748e31b6a`。

候选由实际 NativeAuditProof 源码只将声明名去 `_nativeProof` 并保留整个 signature/proof，另加来源 URL/authors/Apache 注记；原许可头完整保留。两条 proof SHA 仍为 `7ddf322563074c7a4c38a05ea183e6170f7b9609d9b33ed848c1121e6c7d1545`、`3ced837de08f1613c75fb2e924618ffb81f68ac080c42609a2aadcf808e6926c`。没有新 alias 或证明改写。

最终公理审查入口：`FinalIntegratedAxioms.lean`。仅导入两个真实 canonical 模块，输出两个最终定理及其真实父 `sum_affine_quadratic` 的三个 `#print axioms`。root 将此文件放入稳定主区任务目录后通过 MCP-CI `task_type=review,target=file,parameters.source=<确切路径>` 验收，沿用既有纯 helper 集成流程，不重复四角色或新增检查链。

该 review 的 worktree_manifest.input_hashes 应明确包括本 review 源、两个实际 canonical 源与父模块当前源码 SHA；这样 cleanup 能追溯最后一次公理审查覆盖的精确版本。root-ci-entry.json 给出了结构化入口草稿，实际 session/agent/worktree_manifest/LEAN_PATH/幂等键由 root 填入。

归档清理脚本：`archive_cleanup.py`，本次未执行。平台两条 ACCEPTED 已从实际 journal 读取；脚本在任何删除前再次验证：

- finsum theorem `74897806-a937-47a4-bb31-e5d27dc5f24c`／submission `a58c4f44-6386-411d-84b3-3030a0393079`。
- sum_arch theorem `23fcdf5e-a84d-49ff-ade0-03f044c5286d`／submission `45db90fb-0b49-4b1e-8c4a-ba312f7ff96d`。
- root 图前后相同；两个最终 canonical SHA 和最终 artifact 回执严格对应；已有 final review 成功、无 sorryAx，且输入pin包含两个最终 canonical。

root 在最终 axiom review 成功后调用：

```
python3 /tmp/p2m-independent-two-integrated-delivery-v28-20261116/archive_cleanup.py --artifact-receipt /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/main-chain-open-20261116/independent-finsum-integrated-accepted-artifact-v28-result.json --artifact-receipt /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/main-chain-open-20261116/independent-sum-arch-integrated-accepted-artifact-v28-result.json --axiom-receipt /最终公理审查-result.json
```

默认只报告。核对后相同命令加 `--apply`：生成主区 `independent-two-four-role-v25-20261116/archive-final-v28/`，写 small-evidence.tar.gz、integrated-drafts.tar.gz 和 archive-manifest.json；重开两 tar，按统一仓库相对成员名逐项验 SHA，再核对源输入未变化，最后删除25项白名单。输出目录存在时停止，不覆盖旧归档。

delete-whitelist.json 固定25文件、22,490 bytes：W临时 NativeAuditProof两条、W/Solutions两条；发布packet/staging六条；原来源单位中已集成的 native/stub/solution六条；对应 formal-only六条；已恢复父 proof 的原候选／formal-only副本和 obsolete旧stub三条。每项精确路径与 SHA 已列出。canonical Theorems和真实父模块不会删除，缓存产物不清理；ProcessionSupport和未集成其他证明既不清理，也不混入本归档范围。

小证据归档包括：当前完整四角色/发布单元；本任务候选与集成说明；两原证明的原命令、source probes、runtime/type configs、真实小型InfoTree、TYPE facts、冻结A/B三语和p30原段落图文；实际审计/native facts/bound配置；全部相关 attempt request/submit/result、首次失败源码、取消与obsolete分类。ci-017052 失败、ci-017055 cancelled、ci-016954 obsolete statement-only分别保留且不记为proof通过。

归档只递归当前小型单元和明确的两条来源目录，不递归父供应单位、全项目或巨大export。每文件≤16MiB、输入总量≤96MiB；遇大材料会停止而不会读或重哈希巨dump。不会读取凭据。原14 gate、冻结读回、p30 metadata、canonicalC22=false／all200=false均不更改。docs/registry/提交推送由 root 按批量授权统一安排。

脚本未执行，只做Python AST与候选/白名单的离线字节核对。平台上传历史stub路径及临时角色会在tar中保留原repo-relative成员；历史JSON不静默改写。
