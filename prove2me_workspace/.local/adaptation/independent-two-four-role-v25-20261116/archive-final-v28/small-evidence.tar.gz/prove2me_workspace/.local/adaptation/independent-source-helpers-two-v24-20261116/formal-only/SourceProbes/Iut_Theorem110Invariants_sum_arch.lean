import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
namespace Iut


lemma sum_affine_quadratic (L : ℕ) (a b c : ℝ) :
    ∑ i : Fin L, (a * ((i : ℝ) + 2) + b * ((i : ℝ) + 1) ^ 2 + c) =
      a * (L * (L + 3) / 2) + b * (L * (L + 1) * (2 * L + 1) / 6) + c * L := by
  rw [Fin.sum_univ_eq_sum_range (fun i => a * ((i : ℝ) + 2) + b * ((i : ℝ) + 1) ^ 2 + c) L]
  induction L with
  | zero => simp
  | succ n ih =>
    rw [Finset.sum_range_succ, ih]
    push_cast
    ring
namespace Theorem110Invariants

lemma sum_arch (L : ℕ) :
    ∑ i : Fin L, (((i : ℕ) + 2 : ℕ) : ℝ) * Real.log Real.pi =
      Real.log Real.pi * (L * (L + 3) / 2) := by
  have := sum_affine_quadratic L (Real.log Real.pi) 0 0
  simp only [zero_mul, add_zero] at this
  rw [← this]
  refine Finset.sum_congr rfl fun i _ => ?_
  push_cast
  ring

end Theorem110Invariants
end Iut
