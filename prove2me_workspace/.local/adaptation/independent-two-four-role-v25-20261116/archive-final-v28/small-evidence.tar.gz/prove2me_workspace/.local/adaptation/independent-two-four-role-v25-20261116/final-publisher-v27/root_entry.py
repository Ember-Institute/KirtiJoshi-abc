#!/usr/bin/env python3
"""Explicit root calls to the unchanged private publisher. No query regeneration."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
DEFAULT = W / '.local/adaptation/independent-two-four-role-v25-20261116'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['collect-scope', 'check', 'deliver'])
    parser.add_argument('--delivery', type=Path, default=DEFAULT)
    args = parser.parse_args()
    delivery = args.delivery.resolve()
    publisher = load('existing_independent_two_publisher', delivery / 'publisher.py')
    directory = delivery / 'platform'
    if args.command == 'check':
        publisher.preflight(delivery / 'packet.json', delivery / 'ready.final.json')
        print('Original private publisher preflight passed; no API invoked.')
    elif args.command == 'collect-scope':
        # Same existing private mission validation as delivery, with no POST.
        old = publisher.old
        api = old.load_api()
        directory.mkdir(exist_ok=True)
        listing = api.request('/missions?q=Arithmetic%20Teichmuller&limit=100')
        old.save(directory / 'mission-list-readback.json', listing)
        mission = old.mission_from_listing(listing)
        root = api.request('/theorems/' + old.ROOT)
        assert root['visibility'] == 'private' and root['mathlib_rev'] == old.ENV
        old.save(directory / 'mission-scope.json', {'scope': old.SCOPE, 'mission': mission,
            'root_graph_membership': False, 'root_id': old.ROOT, 'environment': old.ENV})
        parent = api.request('/theorems/0570f628-ffa3-4ecf-8447-83221d12a56e')
        assert parent['theorem_name'] == 'AbcAdaptation.Reference.Iut.sum_affine_quadratic'
        assert parent['status'] == 'Proved' and parent['visibility'] == 'private'
        old.save(directory / 'live-proved-parent-readback.json', parent)
        print('Existing private mission and proved parent read back; no POST.')
    else:
        result = publisher.deliver(delivery / 'packet.json', delivery / 'ready.final.json', directory)
        print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
