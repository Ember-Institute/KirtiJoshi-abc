from pathlib import Path
import json,hashlib,shutil
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');G=W/'.local/adaptation/main-chain-open-20261116/tools/generated';O=Path('/tmp/p2m-main-next-independent-two-v10-20261116');O.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dg(b):return hashlib.sha256(b).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def walk(x):
 yield x
 for y in x.get('children',[]):yield from walk(y)
notice=b'''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
'''
config={
'Iut.Theorem110Invariants.LocalEstimate.finsum_le_finsum_of_le':{
 'native':['Mathlib.Algebra.BigOperators.Finprod','Mathlib.Algebra.Order.BigOperators.Group.Finset','Mathlib.Data.Real.Basic','Mathlib.Data.Set.Finite.Lattice'],
 'source':['Mathlib.Algebra.BigOperators.Finprod','Mathlib.Algebra.Order.BigOperators.Group.Finset','Mathlib.Basic.Real.Basic','Mathlib.Data.Set.Finite.Lattice'],
 'deps':[]},
'Iut.Theorem110Invariants.sum_arch':{
 'native':['Mathlib.Analysis.SpecialFunctions.Log.Basic','Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic','Mathlib.Data.Fintype.BigOperators','Mathlib.Tactic.NormNum','Mathlib.Tactic.Ring','Theorems.Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic'],
 'source':['Mathlib.Analysis.SpecialFunctions.Log.Basic','Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic','Mathlib.Data.Fintype.BigOperators','Mathlib.Tactic.NormNum','Mathlib.Tactic.Ring'],
 'deps':['Iut.sum_affine_quadratic']}}
helper_meta=W/'.local/adaptation/main-c22-numeric-helpers-20261115/OriginalCommands/Iut_sum_affine_quadratic.json';helper=read(helper_meta)['selectedNode'];helper_raw=helper['commandText'].encode();assert dg(helper_raw)==helper['wholeCommandSha256']
helper_native=notice+b'import Mathlib.Data.Real.Basic\nimport Mathlib.Data.Fintype.BigOperators\nimport Mathlib.Tactic.NormNum\nimport Mathlib.Tactic.Ring\n\nset_option relaxedAutoImplicit false\nset_option maxSynthPendingDepth 3\nnamespace AbcAdaptation.Reference\nnamespace Iut\n'+helper_raw+b'\nend Iut\nend AbcAdaptation.Reference\n'
write(O/'DependencyNativeProof/Theorems/Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean',helper_native)
write(O/'OriginalCommands/Iut_sum_affine_quadratic.lean',helper_raw+b'\n')
records=[];frozen=[]
a=read('/tmp/p2m-main-proof-trilingual-a-v9-20261116/trilingual.json');b=read('/tmp/p2m-main-proof-trilingual-b-v9-20261116/trilingual-readbacks.json');readbacks={r['sourceName']:r for r in a['nodes']+b['nodes']}
for name,cfg in config.items():
 key=name.replace('.','_');m=read(G/'metadata'/f'{key}.json');coord=Path(m['originalCoordinateSource']).read_bytes();assert dg(coord)==m['originalCoordinateSha256'];raw=Path(m['originalWholeCommand']['path']).read_bytes();ds,de=[m['originalRange'][k]['offset'] for k in ['start','end']];assert raw==coord[ds:de]+b'\n';pr=m['proofAndDefinitionBodyRanges'][0];pa,pb=[pr[k]['offset'] for k in ['start','end']];body=coord[pa:pb];assert dg(body)==m['originalBodyHashes'][0]
 parser=readbacks[name]['formalOnly'];parserfile=Path(m['parserEvidence']['path']);facts=[json.loads(l) for l in parserfile.read_text().splitlines()];decl=next(r for r in facts if r.get('kind')=='decl' and r.get('range')==m['originalRange']);nr=decl['nameRanges'][0];na=nr['start']['offset'];nb=nr['end']['offset'];sig=coord[nb:pa];ns=name.rsplit('.',1)[0];target='AbcAdaptation.Reference.'+name
 imports='\n'.join('import '+p for p in cfg['native']).encode();base=notice+imports+b'\n\nset_option relaxedAutoImplicit false\nset_option maxSynthPendingDepth 3\nopen scoped BigOperators\n\n';open_ns=('namespace AbcAdaptation.Reference\nnamespace '+ns+'\n').encode();close=('\nend '+ns+'\nend AbcAdaptation.Reference\n').encode();native_raw=raw[:na-ds]+(name.rsplit('.',1)[-1]+'_nativeProof').encode()+raw[nb-ds:];native=base+open_ns+native_raw+close
 fn='Thm_'+target.replace('.','_')+'.lean';stub=base+b'theorem '+target.encode()+sig+b':= by sorry\n';solbase=base+b'open AbcAdaptation.Reference.Iut\n\n' if cfg['deps'] else base
 solprefix=solbase+b'theorem solution'+sig;sol=solprefix+body+b'\n';assert b'sorry' not in sol.split();write(O/'NativeProofs'/fn,native);write(O/'Theorems'/fn,stub);write(O/'Solutions'/('Sol_'+target.replace('.','_')+'.lean'),sol);write(O/'OriginalCommands'/f'{key}.lean',raw)
 source=notice+'\n'.join('import '+p for p in cfg['source']).encode()+b'\n\nset_option relaxedAutoImplicit false\nset_option maxSynthPendingDepth 3\nopen scoped BigOperators\nnamespace Iut\n'
 if cfg['deps']:source+=helper_raw+b'\n'
 nested=ns.removeprefix('Iut.');source+=('namespace '+nested+'\n').encode()+raw+('\nend '+nested+'\nend Iut\n').encode();source_path=O/'SourceProbes'/f'{key}.lean';write(source_path,source)
 oracle={'outputDir':str(O/'oracle-output'/key),'namePrefixes':[],'options':[{'name':'relaxedAutoImplicit','type':'bool','value':False},{'name':'maxSynthPendingDepth','type':'nat','value':3}],'files':[{'module':'AbcSourceOracle.NextMainPure.'+key,'file':'ProofCommands/'+key+'.lean','source':str(source_path),'sourceSha256':dg(source),'normalizedSha256':dg(source)}]};save(O/'OracleConfigs'/f'{key}.json',oracle)
 frozen.append(readbacks[name]);records.append({'sourceName':name,'targetName':target,'nativeProof':str(O/'NativeProofs'/fn),'nativeProofName':target+'_nativeProof','theoremStub':str(O/'Theorems'/fn),'globalSolution':str(O/'Solutions'/('Sol_'+target.replace('.','_')+'.lean')),'sourceProofSha256':dg(body),'globalSolutionProofRange':[len(solprefix),len(solprefix)+len(body)],'sourceMetadata':{'path':str(G/'metadata'/f'{key}.json'),'sha256':sha(G/'metadata'/f'{key}.json')},'originalRange':m['originalRange'],'sourceProofRange':pr,'sourceProbeWholeCommandBytesUnchanged':True,'nativeProofBindingRenameOnly':{'originalNameRange':nr,'newShortName':name.rsplit('.',1)[-1]+'_nativeProof'},'signatureAndProofBytesUnchanged':True,'graphTypeDependencies':m['graphTypeDependencies'],'graphValueDependencies':m['graphValueDependencies'],'actualConsumerEdges':m['actualConsumerEdges'],'directRegisteredReuse':cfg['deps'],'sourceProbe':str(source_path),'sourceProbeSha256':dg(source),'oracleConfig':str(O/'OracleConfigs'/f'{key}.json'),'oracleRuntimeDriver':m['oracleRuntimeDriver'],'nativeImports':cfg['native'],'sourceImports':cfg['source'],'acceptance':'all compilation, actual source type facts, and four-role kernel checks pending root'})
save(O/'source-proof-evidence.json',records);save(O/'frozen-readbacks-exact.json',{'selection':list(config),'nodes':frozen,'originalInputs':[{'path':'/tmp/p2m-main-proof-trilingual-a-v9-20261116/trilingual.json','sha256':sha('/tmp/p2m-main-proof-trilingual-a-v9-20261116/trilingual.json')},{'path':'/tmp/p2m-main-proof-trilingual-b-v9-20261116/trilingual-readbacks.json','sha256':sha('/tmp/p2m-main-proof-trilingual-b-v9-20261116/trilingual-readbacks.json')}],'frozenStringsModified':False})
save(O/'run-plan.json',{'unit':'independent next two source helpers','roleFiles':records,'firstEachNewLeaf':{'expected_duration':'60s','expected_memory':'16GiB'},'sourceOracleProcedure':'Reuse each given oracleRuntimeDriver with the generated OracleConfigs through root MCP-CI, original4.35 environment. No original full source module/goal imported; the sum_arch source probe contains only actual completed sum_affine_quadratic ancestor before the goal.','nativeProcedure':'Root stages theorem stub/native proof/global solution and, for sum_arch, restores or imports the already source-proved sum_affine_quadratic native dependency. Native4.33 leaf jobs remain separate.','fourRoleGate':'Original source compiled type + native statement type + native named-proof type + global solution type, including complete BinderInfo and standard axiom audit. Reuse existing pure2 role query/audit tools after updating imports/config; no giant source export.','mainFiveCarrierDependency':False,'sourceConsumerIdentity':'Preserve complete generic original types. Unused AG/TG/X/inv/est section variables are absent from actual source graph type dependencies for these2; do not invent them as new hypotheses.','apiCalls':False,'compileCalled':False})
print(O)
