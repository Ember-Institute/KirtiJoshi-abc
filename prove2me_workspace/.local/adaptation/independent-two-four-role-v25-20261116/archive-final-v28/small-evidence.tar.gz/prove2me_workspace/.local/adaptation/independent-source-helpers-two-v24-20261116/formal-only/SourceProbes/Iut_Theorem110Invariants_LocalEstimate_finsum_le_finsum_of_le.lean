import Mathlib.Algebra.BigOperators.Finprod
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Basic.Real.Basic
import Mathlib.Data.Set.Finite.Lattice

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
namespace Iut
namespace Theorem110Invariants.LocalEstimate


lemma finsum_le_finsum_of_le {α : Type*} {f g : α → ℝ} (h : ∀ a, f a ≤ g a)
    (hf : (Function.support f).Finite) (hg : (Function.support g).Finite) :
    ∑ᶠ a, f a ≤ ∑ᶠ a, g a := by
  rw [finsum_eq_sum_of_support_subset f (s := (hf.union hg).toFinset) (by
      intro a ha; simp only [Set.Finite.coe_toFinset]; exact Or.inl ha),
    finsum_eq_sum_of_support_subset g (s := (hf.union hg).toFinset) (by
      intro a ha; simp only [Set.Finite.coe_toFinset]; exact Or.inr ha)]
  exact Finset.sum_le_sum fun a _ => h a

end Theorem110Invariants.LocalEstimate
end Iut
