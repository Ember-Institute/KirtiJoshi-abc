from pathlib import Path
import json,hashlib,copy
root=Path('/home/admin-wsl/Coq/abc')
out=Path('/tmp/p2m-independent-helpers-mochizuki-context-v26-20261116')
packet_path=Path('/tmp/p2m-independent-two-four-role-packets-v25-20261116/packet.json')
gaps_path=packet_path.with_name('paper-context-gaps.json')
pdf=root/'refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf'
materials=root/'prove2me_workspace/.local/adaptation/reference-main-bound-carriers-20261115/paper-materials-v1'
supplier=root/'prove2me_workspace/.local/adaptation/supplier-carriers-delivery-20261116/paper-context/paper-context.json'
url='https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf'
def sha(b): return hashlib.sha256(b).hexdigest()
def rec(p):return {'path':str(p),'sha256':sha(p.read_bytes())}
def write(n,d): (out/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
sup=json.loads(supplier.read_text());packet=json.loads(packet_path.read_text());gaps=json.loads(gaps_path.read_text())
assert rec(pdf)['sha256']==sup['paper_sources']['IV']['sha256']
q_sum=r'''[…] it suffices to sum over $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}$ the various local “procession-normalized upper bounds” obtained in Steps (v), (vi), (vii) for $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}$.'''
q_arch=r'''One may then compute a “weighted average upper bound” and then a “procession-normalized upper bound”, as was done in Step (v). The resulting “procession-normalized upper bound” is given by

$\frac{l+5}{4}\cdot\log(\pi)\leq\frac{l+1}{4}\cdot4$

— cf. (E1), (E6); the fact that $l\geq5$.'''
quotes=[
 {'id':'IV-Theorem110-sum-local-bounds','locator':'§1, proof of Theorem 1.10, Step (viii), opening paragraph','printed_page':30,'pdf_file_page':30,'quote_markdown':q_sum,'scope_note':'A contiguous final clause of the second sentence in the opening paragraph; the preceding clause identifying the desired upper bound is explicitly omitted. This is the parent proof’s local-to-global summation context, not the statement of the Lean finite-support monotonicity helper.'},
 {'id':'IV-Theorem110-arch-average','locator':'§1, proof of Theorem 1.10, Step (vii), paragraph after the local archimedean bound (j+1)·log(π), its final display, and the following cross-reference','printed_page':30,'pdf_file_page':30,'quote_markdown':q_arch,'scope_note':'Two complete sentences, the resulting display, and its following cross-reference. The earlier geometric construction of the container and the normalization argument are not quoted. This is the archimedean averaging context, not a paper statement of the Lean sum_arch identity.'}
]
for q in quotes:
 q.update({'author':'Shinichi Mochizuki','paper':'IV','title':'Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations','version':'April 2020','official_url':url,'normalization':'Manually checked against the existing rendered original p.30. Line breaks and line-end hyphenation are joined; typography is represented in Unicode and mathematical notation in LaTeX.','quote_utf8_sha256':sha(q['quote_markdown'].encode()),'evidence':[rec(out/'evidence/IV-030.png'),rec(out/'evidence/IV-030.raw.txt')],'existing_extraction_source':[rec(materials/'evidence/IV-030.png'),rec(materials/'evidence/IV-030.raw.txt')]})
intro='\n\n**Mochizuki paper context for the actual consumer (English)**\n\n'
append0=intro+r'''In the reference Lean code, `finsum_le_finsum_of_le` is the general finite-support monotonicity step used by `LocalEstimate.globalVol_thetaHull_le`: it sums the pointwise local bound over rational places. That result feeds `LocalEstimate.rhs_le` and then `Theorem110Invariants.theorem110`. Mochizuki’s parent proof describes the summation in IUT IV, Theorem 1.10, Step (viii):

> '''+q_sum+r'''

— Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (viii), opening paragraph, printed/PDF p. 30.

This is the consumption context for the finite-support comparison. The Lean helper is a general real-valued finite-sum inequality under its explicit support-finiteness and pointwise-order hypotheses. The paper does not state a separate lemma with this name or this general functional type. The quotation supplies no geometric data or additional hypothesis to the formal statement.

Original paper: '''+url
append1=intro+r'''In the reference Lean code, `Theorem110Invariants.theorem110` applies `sum_arch` when evaluating the summed local bounds over the standard procession. The sum over capsule indices has terms $(i+2)\log\pi$. Mochizuki’s corresponding Step (vii) starts from the archimedean bound $(j+1)\log(\pi)$ and then computes its procession average:

> '''+q_arch.replace('\n\n','\n>\n> ')+r'''

— Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §1, proof of Theorem 1.10, Step (vii), final averaging paragraph and display, printed/PDF p. 30.

This quotation gives the consumption context. The Lean helper evaluates the unnormalized finite sum for any natural $L$, including $L=0$. The paper’s displayed bound concerns a normalized procession with its surrounding geometric hypotheses and indexing. It does not separately state this general finite-sum identity or a lemma named `sum_arch`. The quotation supplies no extra hypothesis to the formal statement.

Original paper: '''+url
appends=[append0,append1]
records=[];ops=[];preview=copy.deepcopy(packet)
for i,app in enumerate(appends):
 payload=packet['publications'][i]['payload'];old=payload['natural_language_statement'];new=old+app
 name=payload['theorem_name'];ptr=f'/publications/{i}/payload/natural_language_statement'
 assert ('finsum_le_finsum_of_le' if i==0 else 'sum_arch') in name
 assert gaps['availableContextQuote']['quote_markdown'] in old
 frozen=old.split('\n\n**Implementation and proof-status context',1)[0]
 assert new.split('\n\n**Implementation and proof-status context',1)[0]==frozen
 preview['publications'][i]['payload']['natural_language_statement']=new
 records.append({'theorem_name':name,'json_pointer':ptr,'append_markdown':app,'old_utf8_sha256':sha(old.encode()),'append_utf8_sha256':sha(app.encode()),'new_utf8_sha256':sha(new.encode()),'frozen_prefix_utf8_sha256':sha(frozen.encode()),'quotation_id':quotes[i]['id']})
 ops.extend([{'op':'test','path':ptr,'value':old},{'op':'replace','path':ptr,'value':new}])
restored=copy.deepcopy(preview)
for i in range(2):restored['publications'][i]['payload']['natural_language_statement']=packet['publications'][i]['payload']['natural_language_statement']
assert restored==packet
write('metadata-append-patch.json',{'schema':'independent-helpers-mochizuki-consumer-context-append/v1','status':'optional-draft-not-applied','source_packet':rec(packet_path),'appends':records,'application_note':'Existing p.23 parent-Theorem1.10 quotation and scope note are already accurate and sufficient as parent context. These p.30 quotations are optional, closer consumer explanations. They do not create a new acceptance requirement.'})
write('rfc6902-patch.json',ops)
write('packet.preview.json',preview)
write('quotations-evidence.json',{'schema':'independent-helpers-mochizuki-context-evidence/v1','local_original_pdf':rec(pdf),'paper_version':'April 2020','official_url':url,'quotations':quotes,'existing_parent_context':gaps['availableContextQuote'],'existing_parent_quote_verified_against_supplier':gaps['availableContextQuote']['quote_markdown']==next(x for x in sup['quotations'] if x['id']=='IV-theorem110-bound')['quote_markdown'],'source_inputs':[rec(supplier),rec(gaps_path),rec(materials/'paper-context.json'),rec(root/'refer/iut/Iut/Implication/LogVolumeBound.lean'),rec(root/'refer/iut/Iut/Implication/Theorem110.lean')],'code_consumption':{'finsum_le_finsum_of_le':{'source':'refer/iut/Iut/Implication/LogVolumeBound.lean','declaration_line':151,'direct_call_line':199,'direct_consumer':'Iut.Theorem110Invariants.LocalEstimate.globalVol_thetaHull_le','consumer_chain':'globalVol_thetaHull_le -> LocalEstimate.rhs_le -> Theorem110Invariants.theorem110'},'sum_arch':{'source':'refer/iut/Iut/Implication/Theorem110.lean','declaration_line':158,'direct_call_line':258,'direct_consumer':'Iut.Theorem110Invariants.theorem110'}}})
write('context-assessment.json',{'existing_parent_context_sufficient':True,'existing_context_accurate':True,'helper_verbatim_paper_theorem_claim':False,'source_split_blocked':False,'new_acceptance_gate':False,'recommendation':'Retain the existing p.23 Theorem1.10 quotation and its scope note. The optional p.30 append gives closer consumer context; no exact paper theorem with either Lean helper name is required or asserted.','existing_gap_file_interpretation':'The statement that there is no directly stated original-paper theorem matching the two general Lean helpers is compatible with correct parent-proof context. It need not block source splitting.','existing_scope_notes_unchanged':True,'frozen_readbacks_unchanged':True,'original_payloads_not_modified':True,'download_needed':False})
write('validation.json',{'passed':True,'scope':'Metadata-only provenance/string validation','all_existing_natural_language_bytes_preserved':True,'all_frozen_trilingual_readback_bytes_preserved':True,'only_changed_preview_paths':[r['json_pointer'] for r in records],'all_other_fields_unchanged':True,'code_written':False,'compiler_invoked':False,'ci_invoked':False,'api_invoked':False,'git_invoked':False,'main_workspace_written':False,'network_downloaded':False,'only_output_directory':str(out),'rendered_page_30_visually_inspected':True,'existing_page_extraction_and_PDF_SHA_rechecked':True})
write('sha256-manifest.json',{str(p.relative_to(out)):sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='sha256-manifest.json'})
print(json.dumps({'output':str(out),'existing_context_sufficient':True,'quote_sha256':[q['quote_utf8_sha256'] for q in quotes],'pdf_sha256':rec(pdf)['sha256'],'p30_extraction_sha256':rec(out/'evidence/IV-030.raw.txt')['sha256']},ensure_ascii=False,indent=2))
