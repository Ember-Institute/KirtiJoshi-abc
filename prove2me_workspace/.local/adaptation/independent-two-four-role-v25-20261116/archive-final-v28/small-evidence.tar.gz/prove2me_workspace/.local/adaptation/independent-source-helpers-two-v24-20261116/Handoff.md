立即可交的两节点已备妥：`Iut.Theorem110Invariants.LocalEstimate.finsum_le_finsum_of_le` 和 `Iut.Theorem110Invariants.sum_arch`。两者源图 typeDeps 都没有 AG/TG/X/inv/est；未人为添加这些未使用参数。所有原声明参数、有限支撑条件和完整原 proof body 保持，source AST 已绑定，所有编译/实际语义 oracle/四角色 kernel 验收仍 pending root。

入口为 `run-plan.json`、`source-proof-evidence.json`、`four-role-bindings.template.json`。四角色分开放置：`OriginalCommands/` 保留完整来源；`SourceProbes/` 为原4.35 proof oracle；`Theorems/` 为真实目标 by-sorry stub；`NativeProofs/` 为独立 `_nativeProof` 名称的完整原证明；`Solutions/` 为顶层 `theorem solution`。命名角色分开，避免与 stub 重复声明；两个 global solution 分别审查，不在同一环境同时导入。

原proof oracle最小配置在 `OracleConfigs/`，直接复用记录的现有 ExtractSmallRuntimeOracle；它不导入原 LogVolumeBound/Theorem110 全模块或自己的目标。sum_arch 的 source probe 只额外复制唯一真实直接祖先 `Iut.sum_affine_quadratic` 的完整原证明。来源 TYPE oracle 在 `QueryIndependentTypeFacts.lean` + `TypeOracleConfigs/`，仅从缓存的原 Theorem110 环境读取实际 TYPE，严格不读 selected root theorem proof。这是现有 pure2 QueryPureArithmeticTypeFacts 的固定1根小改版，每次只查询一个确切实际源 Name/owner；不做巨export。Root通过MCP-CI执行，环境变量沿用 PURE_TYPE_SOURCE_CONFIG。原proof oracle与原type oracle是两项证据，不互相冒充。

finsum 节点仅需明确 Mathlib 模块。sum_arch 只复用已发布的 sum_affine_quadratic；当前本地该 Theorems 文件仍是sorry stub，而saved平台为Proved。为让root轻量恢复真实native依赖，`DependencyNativeProof/Theorems/Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean` 已复制其已有完整来源proof，未改proof bytes，未新增数学。Root可按先前pure2恢复依赖方式重建这个小模块，再编译sum_arch。不得把本地stub的传递sorryAx声称为实际闭合证明。

`frozen-readbacks-exact.json` 对两条现有三语完整row做原样复制，未改英文或翻译，也未重写stub proof状态句；代码的真实sourceproof、root编译/平台状态另记。`formal-only/` 仅含代码，未混入读回答案。`source-citation-entries.json` 通过整命令唯一字节匹配定位真实仓库原文行号，并单列effective AST范围与既有论文说明入口。

每个新leaf首次60s/16GiB，所有CI只由root统一exclusive执行。推荐顺序：finsum原source proof/type + native namedproof/stub/global solution；sum_arch先恢复已有sum_affine_quadratic真实native proof，再做相同四角色。无需等待主界五carrier identity。这里没有编译、CI、API、Git或主区写。
