#!/usr/bin/env python3
"""Bind existing successful two-helper results without regenerating queries or facts.
Default reports only. Root uses --apply to write packet/ready metadata in --delivery.
No compiler, CI, API, or Git calls.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
sys.dont_write_bytecode = True

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A = W / '.local/adaptation'
C = A / 'main-chain-open-20261116'
DEFAULT = A / 'independent-two-four-role-v25-20261116'
CONTEXT = Path('/tmp/p2m-independent-helpers-mochizuki-context-v26-20261116')
OLD_TMP = Path('/tmp/p2m-independent-two-four-role-packets-v25-20261116')
JOB_PREFIXES = {'finsum': 'ci-017069-', 'sum-arch': 'ci-017068-'}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    path = Path(path)
    assert path.stat().st_size < 16 * 1024 ** 2, 'Use compact evidence; do not rehash giant exports'
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def success(path):
    result = read(path)
    assert result['status'] == 'succeeded' and result['result']['exit_code'] == 0, str(path)
    return result


def load_publisher(delivery):
    spec = importlib.util.spec_from_file_location('existing_independent_two_final_publisher', delivery / 'publisher.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build(delivery, diff_path, scope_path):
    packet = read(delivery / 'packet.json')
    ready = read(delivery / 'ready.template.json')
    publisher = load_publisher(delivery)
    assert packet['canonicalC22Connected'] is False and packet['all200FormalAccepted'] is False
    # Idempotent p30 append, using only the already checked exact strings.
    patch = read(CONTEXT / 'metadata-append-patch.json')
    for addition in patch['appends']:
        row, = [row for row in packet['publications'] if row['payload']['theorem_name'] == addition['theorem_name']]
        payload = row['payload']
        text = payload['natural_language_statement']
        digest = hashlib.sha256(text.encode()).hexdigest()
        if digest == addition['old_utf8_sha256']:
            payload['natural_language_statement'] += addition['append_markdown']
        else:
            assert digest == addition['new_utf8_sha256'], 'Neither original nor exact appended metadata'
        assert hashlib.sha256(payload['natural_language_statement'].encode()).hexdigest() == addition['new_utf8_sha256']
        for frozen in packet['frozenReadbacks'][addition['theorem_name']]['readbacks'].values():
            assert frozen in payload['natural_language_statement']
    # Rebase only our task-local metadata references. Never write queries,
    # bound configs, actual outputs, audit-index, or source/type oracle files.
    metadata = {}
    for name, digest in packet['metadata_sha256'].items():
        path = Path(name)
        if path.name == 'paper-context-gaps.json':
            continue
        if path.is_relative_to(OLD_TMP):
            live = delivery / path.relative_to(OLD_TMP)
            if live.is_file():
                metadata[str(live)] = sha(live)
                continue
        assert sha(path) == digest, 'Changed historical evidence: ' + str(path)
        metadata[str(path)] = digest
    packet['metadata_sha256'] = metadata
    evidence = metadata.copy()
    receipt_paths = []
    all_results = []
    audits = {}
    for node in read(delivery / 'audit-index.json')['nodes']:
        target, source_name = node['targetName'], node['sourceName']
        short = source_name.split('.')[-1]
        tag = 'finsum' if short == 'finsum_le_finsum_of_le' else 'sum-arch'
        key = source_name.replace('.', '_')
        actual_path = delivery / 'actual' / (key + '-four-role-audit.json')
        actual = read(actual_path)
        assert actual['targetName'] == target and actual['sourceName'] == source_name
        assert all(actual[flag] is True for flag in publisher.AUDIT_FLAGS)
        assert all(actual[flag] is False for flag in publisher.NO_SORRY_FLAGS)
        for field in ['nativeAxioms', 'solutionAxioms', 'registeredDependencyAxioms']:
            assert set(actual[field]) <= {'propext', 'Classical.choice', 'Quot.sound'}
        final_receipt_path = C / ('independent-' + tag + '-four-role-final-v26-result.json')
        final_receipt = success(final_receipt_path)
        assert final_receipt['job_id'].startswith(JOB_PREFIXES[tag])
        actual_config_path = Path(final_receipt['request']['environment']['PURE_FOUR_ROLE_CONFIG'])
        assert read(actual_config_path) == actual['configuration']
        config = actual['configuration']
        native_facts_path = Path(config['nativeFactsBinding']['path'])
        native = read(native_facts_path)
        native_config = native['configuration']
        for role in ['Stub', 'Solution']:
            installed = Path(config[role.lower() + 'InstalledSource'])
            assert installed.read_text() == config['expected' + role + 'Text']
        assert Path(config['nativeInstalledSource']).read_text() == native['nativeSourceText']
        roles = {}
        for label, bindings in [('native', native_config['nativeReceiptBindings']),
                ('stub', config['stubReceiptBindings']), ('solution', config['solutionReceiptBindings'])]:
            assert len(bindings) == 2
            for suffix, binding in zip(['leaf', 'artifact'], bindings):
                path = Path(binding['path'])
                result = success(path)
                assert result == binding['contents']
                roles[label + '_' + suffix] = str(path)
                receipt_paths.append(path)
        proof_receipt = Path(config['sourceBinding']['oracleReceipt']['path'])
        assert success(proof_receipt)['job_id'] == actual['sourceOracleJob']
        type_receipt = Path(config['sourceTypeReceipt']['path'])
        type_facts_path = Path(config['sourceTypeFactsBinding']['path'])
        success(type_receipt)
        ready['source_oracle_receipts'][target] = str(proof_receipt)
        ready['source_type_receipts'][target] = str(type_receipt)
        ready['source_type_facts'][target] = str(type_facts_path)
        ready['kernel_audits'][target] = str(actual_path)
        packet['sourceOracleJobs'][target] = actual['sourceOracleJob']
        packet['actualSourceTypeFacts'][target] = {'path': str(type_facts_path), 'sha256': sha(type_facts_path)}
        required = dict(roles, source_proof_oracle=str(proof_receipt),
            source_native_stub_solution_kernel_audit=str(actual_path),
            recursive_axiom_audit=str(final_receipt_path),
            registered_dependency_closure_audit=str(final_receipt_path))
        assert set(required) == publisher.REQUIRED_PER_NODE
        ready['required_inputs'][target] = required
        math_paths = [actual_path, final_receipt_path, actual_config_path, native_facts_path,
            Path(config['nativeFactsBinding']['receipt']['path']), proof_receipt, type_receipt, type_facts_path]
        math_paths += [Path(binding['path']) for binding in config['dependencyReceiptBindings']]
        for path in math_paths:
            evidence[str(path)] = sha(path)
        receipt_paths += [final_receipt_path, Path(config['nativeFactsBinding']['receipt']['path'])]
        all_results.append({'targetName': target, 'fourRoleReceipt': str(final_receipt_path),
            'job_id': final_receipt['job_id'], 'actualAudit': str(actual_path), 'actualAuditSha256': sha(actual_path)})
        audits[target] = actual
    # Existing production check reuse, with its actual input/config pins only.
    production_path = A / 'reference-initial-theta-carriers-20261115/production-gates-v2-result.json'
    production = success(production_path)
    manifest = production['request']['worktree_manifest']
    current_pins = []
    for path, digest in manifest['input_hashes'].items():
        assert sha(path) == digest
        current_pins.append({'path': path, 'sha256': digest})
    for relative, digest in manifest['configuration_hashes'].items():
        assert sha(W / relative) == digest
        current_pins.append({'path': str(W / relative), 'sha256': digest})
    reuse = {'production_job': production['job_id'], 'productionSourceAndConfigurationUnchanged': True,
        'currentPins': current_pins, 'scope': 'Same existing production gate; no new build or global claim.'}
    evidence[str(production_path)] = sha(production_path)
    diff = read(diff_path)
    assert diff.get('passed') is True or diff.get('exit_code') == 0
    scope = read(scope_path)
    assert scope['scope'] == packet['scope'] and scope['root_id'] == packet['root_id']
    assert scope['environment'] == packet['environment'] and scope['root_graph_membership'] is False
    assert scope['mission']['id'] == packet['mission_id'] and scope['mission']['visibility'] == 'private'
    evidence[str(diff_path)] = sha(diff_path)
    evidence[str(scope_path)] = sha(scope_path)
    parent_relative = 'Theorems/Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean'
    ready['dependency_source_sha256'] = {parent_relative: sha(W / parent_relative)}
    ready['shared_required_inputs'] = {'production_checks': str(production_path),
        'import_audit': str(delivery / 'production-gate-reuse.final.json'),
        'git_diff_check': str(diff_path), 'existing_private_mission': str(scope_path)}
    ready['ci_receipts'] = list(dict.fromkeys(str(path) for path in receipt_paths))
    for path in ready['ci_receipts']:
        evidence[path] = sha(path)
    ready['explanations'] = packet['explanations']
    ready['gates'] = {gate: True for gate in ready['gates']}
    ready['passed'] = True
    ready['note'] = 'Bound to actual successful source/native/stub/solution and dependency results. Corrected main queries and bound facts were not regenerated.'
    ready['evidence_sha256'] = evidence
    packet['allGatesAccepted'] = True
    return packet, ready, reuse, all_results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--delivery', type=Path, default=DEFAULT)
    parser.add_argument('--git-diff-check', type=Path, required=True)
    parser.add_argument('--mission-scope', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    delivery = args.delivery.resolve()
    packet, ready, reuse, results = build(delivery, args.git_diff_check.resolve(), args.mission_scope.resolve())
    print(json.dumps({'apply': args.apply, 'delivery': str(delivery), 'actualResults': results,
        'metadataOnly': True, 'queriesConfigsAndFactsWritten': False}, ensure_ascii=False, indent=2))
    if not args.apply:
        return
    # Copy only the checked context evidence; never regenerate role/query files.
    for source in CONTEXT.rglob('*'):
        if source.is_file():
            target = delivery / 'paper-context-v26' / source.relative_to(CONTEXT)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                assert target.read_bytes() == source.read_bytes()
            else:
                shutil.copyfile(source, target)
    write(delivery / 'production-gate-reuse.final.json', reuse)
    ready['evidence_sha256'][str(delivery / 'production-gate-reuse.final.json')] = sha(delivery / 'production-gate-reuse.final.json')
    for path in (delivery / 'paper-context-v26').rglob('*'):
        if path.is_file():
            packet['metadata_sha256'][str(path)] = sha(path)
    # Rebase current payload metadata and refresh packet binding after evidence.
    for row in packet['publications']:
        write(delivery / 'payloads' / (row['tag'] + '.json'), row['payload'])
    write(delivery / 'packet.json', packet)
    ready['packet_sha256'] = sha(delivery / 'packet.json')
    ready['evidence_sha256'].update(packet['metadata_sha256'])
    write(delivery / 'ready.final.json', ready)
    old_gap = delivery / 'paper-context-gaps.json'
    if old_gap.exists():
        old_gap.unlink()
    publisher = load_publisher(delivery)
    publisher.preflight(delivery / 'packet.json', delivery / 'ready.final.json')
    print('Original private publisher preflight passed. No API invoked.')


if __name__ == '__main__':
    main()
