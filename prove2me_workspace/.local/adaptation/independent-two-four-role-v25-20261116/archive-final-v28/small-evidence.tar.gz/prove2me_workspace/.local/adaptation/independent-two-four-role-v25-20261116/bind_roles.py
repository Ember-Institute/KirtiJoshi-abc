#!/usr/bin/env python3
"""Bind root-produced facts/receipts to the existing four-role config. No CI/API/Git.
The unbound templates remain unaccepted. Output is restricted to this task directory.
"""
from pathlib import Path
import argparse
import hashlib
import json

D = Path(__file__).resolve().parent
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')


def read(path):
    return json.loads(Path(path).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    path = Path(path).resolve()
    assert path.stat().st_size < 16 * 1024 ** 2, 'Use the compact actual facts, not a giant export'
    return {'path': str(path), 'sha256': sha(path.read_bytes()), 'contents': read(path)}


def receipt(path, source=None, expected_sha=None):
    bound = binding(path)
    actual = bound['contents']
    assert actual['status'] == 'succeeded' and actual['result']['exit_code'] == 0
    snapshot = actual['result']['snapshot']
    assert snapshot['workspace_mode'] == 'exclusive_worktree' and snapshot['snapshot_id'] is None
    if source is not None:
        assert actual['request']['worktree_manifest']['input_hashes'][str(source)] == expected_sha
    return bound


def unique(data, part):
    assert part and data.count(part) == 1, 'Source signature/proof must be a unique exact byte slice'
    start = data.index(part)
    return [start, start + len(part)]


def source_binding(config, receipt_path, index_path):
    bound_receipt = receipt(receipt_path)
    index_bound = binding(index_path)
    index = index_bound['contents']
    assert index['complete'] is True and index['requestedFiles'] == index['finishedFiles'] == 1
    row, = index['results']
    assert row['status'] == 'success'
    diagnostic = binding(row['diagnostics'])
    assert diagnostic['contents']['hasErrors'] is False
    configured = read(index['configPath'])
    assert configured == index['config']
    actual = bound_receipt['contents']
    assert actual['request']['parameters']['args'][-1] == index['configPath']
    assert actual['result']['actual_arguments'] == ['lean', *actual['request']['parameters']['args']]
    coordinate = Path(row['coordinateSource'])
    raw = coordinate.read_bytes()
    assert sha(raw) == configured['files'][0]['normalizedSha256']
    assert sha(Path(row['source']).read_bytes()) == configured['files'][0]['sourceSha256']
    facts_path = Path(row['output'])
    records = [json.loads(line) for line in facts_path.read_text().splitlines() if line]
    assert records[-1]['kind'] == 'summary' and records[-1]['status'] == 'success'
    assert sum(record['kind'] == 'decl' for record in records) == row['declarationCount']
    assert sum(record['kind'] == 'ref' for record in records) == row['referenceCount']
    declaration, = [record for record in records if record['kind'] == 'decl' and record.get('nameText') == config['short']]
    assert declaration['generationIssue'] is None
    start = declaration['valStart']['offset']
    end = declaration['declEnd']['offset']
    assert declaration['valueRange']['start']['offset'] == start and declaration['valueRange']['end']['offset'] == end
    name_end = declaration['nameRange']['end']['offset']
    body, signature = raw[start:end], raw[name_end:start]
    assert sha(body) == config['proofByteEvidence']['sourceProofSha256']
    assert sha(signature) == config['proofByteEvidence']['signatureSha256']
    command = raw[declaration['declStart']['offset']:end]
    original = Path(config['proofByteEvidence']['originalCommand']['path']).read_bytes()
    assert original == command or original == command + b'\n'
    forbidden = {config['sourceName'], config['targetName'], config['nativeName'],
        'Iut.Corollary22Inputs.c2', 'Iut.c2_final', 'Iut.assembly'}
    refs = [record for record in records if record['kind'] == 'ref' and
        start <= record['start']['offset'] <= record['end']['offset'] <= end]
    assert not any(record['const'] in forbidden for record in refs)
    return {'oracleReceipt': bound_receipt, 'oracleIndex': index_bound,
        'oracleDiagnostics': diagnostic, 'oracleFactsPath': str(facts_path),
        'oracleFactsSha256': sha(facts_path.read_bytes()), 'oracleFactsText': facts_path.read_text(),
        'oracleCoordinateSource': str(coordinate), 'oracleCoordinateSha256': sha(raw),
        'oracleCoordinateText': raw.decode(), 'actualDecl': declaration,
        'sourceProofText': body.decode(), 'sourceSignatureText': signature.decode(),
        'sourceCommandSha256': sha(command), 'actualProofReferenceCount': len(refs)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--helper', choices=['finsum_le_finsum_of_le', 'sum_arch'], required=True)
    parser.add_argument('--phase', choices=['native', 'final'], required=True)
    for name in ['source-type-facts', 'source-type-receipt', 'source-proof-receipt', 'source-oracle-index']:
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ['native-leaf', 'native-artifact', 'stub-leaf', 'stub-artifact',
            'solution-leaf', 'solution-artifact', 'native-facts', 'native-facts-receipt', 'out']:
        parser.add_argument('--' + name, type=Path)
    parser.add_argument('--dependency-receipt', type=Path, action='append', default=[])
    args = parser.parse_args()
    index = read(D / 'audit-index.json')
    node, = [row for row in index['nodes'] if row['sourceName'].split('.')[-1] == args.helper]
    config = read(node['configTemplate']['path'])
    assert not config['registeredDependencyNames'] or args.dependency_receipt, 'Bind the restored sum_affine_quadratic actual closure receipt'
    config['sourceFacts'] = {'path': str(args.source_type_facts.resolve()), 'sha256': sha(args.source_type_facts.read_bytes())}
    config['sourceTypeReceipt'] = receipt(args.source_type_receipt)
    config['sourceTypeFactsBinding'] = binding(args.source_type_facts)
    facts = config['sourceTypeFactsBinding']['contents']
    assert facts['schema'] == 'pure-arithmetic-original-type-facts/v9' and facts['rootTheoremProofsRead'] is False
    assert len(facts['records']) == 1 and facts['records'][0]['name'] == config['sourceName']
    type_receipt = config['sourceTypeReceipt']['contents']
    source_type_config = Path(type_receipt['request']['environment']['PURE_TYPE_SOURCE_CONFIG'])
    assert facts['configuration'] == read(source_type_config)
    assert type_receipt['request']['worktree_manifest']['input_hashes'][str(source_type_config)] == sha(source_type_config.read_bytes())
    config['sourceBinding'] = source_binding(config, args.source_proof_receipt, args.source_oracle_index)
    dependencies = config.get('registeredDependencySourcePins', [])
    for dependency in dependencies:
        assert sha(Path(dependency['path']).read_bytes()) == dependency['sha256'], 'Regenerate from the actual restored parent version'
    config['dependencyReceiptBindings'] = [receipt(path) for path in args.dependency_receipt]
    for bound_receipt in config['dependencyReceiptBindings']:
        manifest_hashes = bound_receipt['contents']['request']['worktree_manifest']['input_hashes']
        for dependency in dependencies:
            assert manifest_hashes.get(dependency['path']) == dependency['sha256'], 'Obsolete statement-only parent receipt is not proof evidence'
    config['expectedStubText'] = Path(config['expectedStubSource']['path']).read_text()
    config['expectedSolutionText'] = Path(config['expectedSolutionSource']['path']).read_text()
    if args.phase == 'native':
        assert args.native_leaf and args.native_artifact
        installed = Path(config['nativeInstalledSource'])
        data = installed.read_bytes()
        assert sha(data) == config['expectedNativeSource']['sha256']
        signature = config['sourceBinding']['sourceSignatureText'].encode()
        body = config['sourceBinding']['sourceProofText'].encode()
        sr, pr = unique(data, signature), unique(data, body)
        assert sr[1] == pr[0]
        config['expectedNativeText'] = data.decode()
        config['proofByteEvidence']['nativeSignatureByteRange'] = sr
        config['proofByteEvidence']['nativeProofByteRange'] = pr
        config['nativeReceiptBindings'] = [receipt(path, installed, sha(data)) for path in [args.native_leaf, args.native_artifact]]
    else:
        assert all([args.stub_leaf, args.stub_artifact, args.solution_leaf, args.solution_artifact, args.native_facts_receipt])
        history = (args.native_facts or Path(config['nativeFactsOutput'])).resolve()
        bound = binding(history)
        native = bound['contents']
        assert native['schema'] == 'pure-historical-native-type-facts/v13'
        assert native['targetName'] == config['targetName'] and native['nativeName'] == config['nativeName']
        bound['receipt'] = receipt(args.native_facts_receipt)
        native_config_path = Path(bound['receipt']['contents']['request']['environment']['PURE_FOUR_ROLE_CONFIG'])
        assert read(native_config_path) == native['configuration']
        assert bound['receipt']['contents']['request']['worktree_manifest']['input_hashes'][str(native_config_path)] == sha(native_config_path.read_bytes())
        config['nativeFactsBinding'] = bound
        config['proofByteEvidence'] = native['configuration']['proofByteEvidence']
        config['expectedNativeText'] = native['nativeSourceText']
        for role, paths in [('stub', [args.stub_leaf, args.stub_artifact]),
                ('solution', [args.solution_leaf, args.solution_artifact])]:
            installed = Path(config[role + 'InstalledSource'])
            expected = config['expected' + role.title() + 'Text'].encode()
            assert installed.read_bytes() == expected
            config[role + 'ReceiptBindings'] = [receipt(path, installed, sha(expected)) for path in paths]
    output = (args.out or D / 'bound' / (args.helper + '-' + args.phase + '.json')).resolve()
    assert output.is_relative_to(D)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(config, ensure_ascii=False, indent=2) + '\n')
    print(str(output), sha(output.read_bytes()))


if __name__ == '__main__':
    main()
