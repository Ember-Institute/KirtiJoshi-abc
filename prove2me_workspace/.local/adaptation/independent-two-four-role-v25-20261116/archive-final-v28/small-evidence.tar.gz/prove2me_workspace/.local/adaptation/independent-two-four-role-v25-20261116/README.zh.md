本目录只为两条已给出的原证明准备四角色 query/config 生成器和私有 problem+proof 草稿。没有调用 API、CI、Lean 编译、Git，没有写主区，没有生成新的数学证明或泛化审查层。

两节点：

- `Iut.Theorem110Invariants.LocalEstimate.finsum_le_finsum_of_le`
- `Iut.Theorem110Invariants.sum_arch`

真实源码、source probe、原 TYPE query、stub、native proof 和 global solution 全由 `fermat_remaining_source_split_v7` 在 `/tmp/p2m-main-next-independent-two-v10-20261116/` 交付。本目录不改这些 `.lean` 字节；root 已将原稿放在主区 `W/.local/adaptation/independent-source-helpers-two-v24-20261116/`。root 只重定位了其 OracleConfigs/TypeOracleConfigs 的本任务路径；实际 source facts 与 InfoTree 必须绑定 root 运行所得配置，不能拿未运行的模板当事实。

root 最终指定的实际 placement：

| 角色 | finsum 文件／模块末段 | sum_arch 文件／模块末段 |
| --- | --- | --- |
| native proof | `Theorems/Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_LocalEstimate_finsum_le_finsum_of_le_NativeAuditProof.lean` | `Theorems/Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_arch_NativeAuditProof.lean` |
| target stub | 同上去掉 `_NativeAuditProof` | 同上去掉 `_NativeAuditProof` |
| global solution | `Solutions/Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_LocalEstimate_finsum_le_finsum_of_le.lean` | `Solutions/Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_arch.lean` |

native artifact 模块名由文件路径去 `.lean`、把 `/` 换成 `.` 得到。常量名仍是原作者已经给出的 `...finsum_le_finsum_of_le_nativeProof` 与 `...sum_arch_nativeProof`，没有增加第二个 proof alias。stub 常量名去 `_nativeProof`；每个 solution 模块单独使用顶层 `solution`。两个 global solution 不能导入同一检查环境。

`audit-index.json` 精确给出这两个 source/native/stub/solution 的实际 Name、module、源/查询/配置位置与源码 SHA。`configs/*-config.template.json` 已按 root 的实际 role-placement 清单 fresh 读取角色文件；实际 source facts/回执/历史 native facts 保持 null。

`queries/NativeFacts_*.lean` 和 `queries/FourRoles_*.lean` 复用已经验收过的 pure-two-four-role-v13 模板。仅作以下定点参数调整：

1. native collector 使用真实 `_nativeProof` Name 和 `_NativeAuditProof` 模块 owner；historical native facts 保留 canonical targetName，并另记真实 nativeName。
2. 两条 TYPE 没有项目数据依赖，`nativeDataNames` 为空；没有引入 epsilonE 或任何新数据替换。
3. source InfoTree 自引用检查使用这两条真实完整 source/target/native Name。
4. finsum 没有项目依赖，因此没有伪造 dependency receipt；sum_arch 仍只审查 `sum_affine_quadratic` 的真实已导入证明闭包。

六对完整编译类型／BinderInfo 比较、原 proof/signature 字节身份、native/global solution/父模块的递归标准公理检查，仍是原来的检查内容；publisher 使用相同 12 个 true 和 5 个 false 字段，没有新增 gate。模板不代表已经通过，`configs/*-audit.not-run.json` 中实际审查字段均为 null。

root 运行顺序（所有编译仍经 MCP-CI，本目录不提交任务）：

1. 原 4.35 环境执行作者的一个根 TYPE query，环境变量 `PURE_TYPE_SOURCE_CONFIG` 指实际 root TypeOracleConfig。输出应为 `pure-arithmetic-original-type-facts/v9`、records=1、rootTheoremProofsRead=false。单独执行 source proof oracle，取得真实 InfoTree index/result。这两类证据不能互相替代。
2. 原生 4.33 环境分别验收 native proof、target stub、global solution 的叶和 artifact；sum_arch 先恢复父 `sum_affine_quadratic` 的真实完整证明和对应 artifact。
3. `bind_roles.py --helper finsum_le_finsum_of_le|sum_arch --phase native` 绑定实际 source type/proof、native leaf/artifact 和真实父回执，产生 root 所指定的 bound config；root 通过 MCP-CI 执行对应 NativeFacts query，环境变量为 `PURE_FOUR_ROLE_CONFIG`。
4. `bind_roles.py --phase final` 另外绑定 native facts 与其 receipt、stub/solution 的 leaf/artifact；root 通过 MCP-CI 执行对应 FourRoles query，仍使用 `PURE_FOUR_ROLE_CONFIG`。

两个 bind phase 的共同参数：

```
--helper <finsum_le_finsum_of_le 或 sum_arch>
--phase <native 或 final>
--source-type-facts <实际一个根 TYPE facts.json>
--source-type-receipt <该 TYPE 查询的实际成功回执.json>
--source-proof-receipt <实际 proof oracle 成功回执.json>
--source-oracle-index <该实际 proof oracle index.json>
```

native phase 另加 `--native-leaf`、`--native-artifact`；final phase 另加 `--native-facts`、`--native-facts-receipt`、`--stub-leaf`、`--stub-artifact`、`--solution-leaf`、`--solution-artifact`。sum_arch 两阶段还需 `--dependency-receipt <fresh 父 artifact/实际闭包成功回执>`，可重复；finsum 不需。输出用 `--out` 指定本工具目录内路径。工具只绑定 root 已有的真实结果，不运行 compiler/CI/API/Git。

父模块 current source pin 从主区 fresh 读取，本次为 `ba7f73fa1d3f12b37f42666acf12d5ddefc26d0e7ac4d0c2272339bdf7ef9c95`。root 已说明 ci-016954 是 obsolete statement-only，不是 proof 验收；不得将它填入 dependency receipt。bind 工具要求所填父回执的实际输入清单含当前源码 SHA；实际 Lean collector 还会检查导入 artifact 的真实 value/type/axiom 闭包。因此旧 stub olean 不会被当成完整 native proof。若父 artifact 未刷新，先由 root 完成刷新，不能据源文件看起来闭合来勾选。

发布草稿：`packet.json`、`payloads/`、`ready.template.json`、`publisher.py`、`delivery_with_proved_parent.py`。沿用已成功发布 pure-two 的原协议；只把 theorem 名、冻结输入 schema 和每节点精确父白名单替换为本两条。finsum 的父白名单为空；sum_arch 仅含已发表 `sum_affine_quadratic`。当前 passed=false，全部十四个原 gate=false，actualSourceTypeFacts 与 sourceOracleJobs 均为空，绝不提前声称无 transitive sorry。

pub payload 的 stub 和 global solution 是作者文件原样副本；完整 proof SHA 分别为 `7ddf322563074c7a4c38a05ea183e6170f7b9609d9b33ed848c1121e6c7d1545`、`3ced837de08f1613c75fb2e924618ffb81f68ac080c42609a2aadcf808e6926c`。未给声明添加 AG/TG/X/inv/est 参数或其他假设，没有等待 main-five carriers。

`frozen-readbacks-exact.json` 原样保留完整 A/B 读回 row。finsum 使用原 A 三语（含原 open_source_sorry 句子）；sum_arch 使用原 B 三语（含 sourceOpen=true 与原 by-sorry 状态句）。英文没有改写；实际 closed source/native/global proof 的状态放在独立元数据／原有状态说明段。

Mochizuki 材料只复用既有 `IV-theorem110-bound` 原引用、locator、scope_note、证据 SHA 和官方 URL。没有找到直接陈述这两条有限求和引理的原文段落；`paper-context-gaps.json` 只列明这个缺口。没有重写英文补造引文，也没有把 Theorem1.10 的整体不等式说成这两个 helper 的逐字论文陈述。没有下载新材料或加入论文门。

所有 packet 均为既有私有任务的 detached source-consumer preparation；canonicalC22Connected、root_graph_membership、all200FormalAccepted 均 false。root 负责提交所有任务，后续累积批量提交推送；本目录没有 Git 动作。后续 ProcessionSupport 等其他节点没有混入本两节点包。

`prepare.py` 只重建本目录内草稿，不应覆盖 root 以后完成的 ready.final 或实际绑定。`offline-validation.json` 和 `artifact-manifest.json` 只表示本次离线字节／JSON／语法与未就绪拒绝合同检查，不表示 Lean typecheck 或数学验收。
