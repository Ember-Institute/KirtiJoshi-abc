#!/usr/bin/env python3
"""Apply the existing checked p30 metadata append, preserving Lean/frozen strings."""
from pathlib import Path
import hashlib
import json

D = Path(__file__).resolve().parent
C = D / 'paper-context-v26'


def read(path):
    return json.loads(Path(path).read_text())


def text_sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def append():
    packet_path, ready_path = D / 'packet.json', D / 'ready.template.json'
    packet, ready = read(packet_path), read(ready_path)
    patch = read(C / 'metadata-append-patch.json')
    metadata_paths = [path for path in C.rglob('*') if path.is_file()]
    evidence = read(C / 'quotations-evidence.json')
    for quote in evidence['quotations']:
        for pin in quote['evidence']:
            assert file_sha(pin['path']) == pin['sha256']
    for row in patch['appends']:
        publication, = [p for p in packet['publications'] if p['payload']['theorem_name'] == row['theorem_name']]
        payload = publication['payload']
        old = payload['natural_language_statement']
        assert text_sha(old) == row['old_utf8_sha256']
        assert text_sha(row['append_markdown']) == row['append_utf8_sha256']
        updated = old + row['append_markdown']
        assert text_sha(updated) == row['new_utf8_sha256']
        payload['natural_language_statement'] = updated
        for text in packet['frozenReadbacks'][row['theorem_name']]['readbacks'].values():
            assert text in old and text in updated
        save(D / 'payloads' / (publication['tag'] + '.json'), payload)
    for path in metadata_paths + [Path(__file__).resolve()]:
        packet['metadata_sha256'][str(path)] = file_sha(path)
        ready['evidence_sha256'][str(path)] = file_sha(path)
    # Remove the resolved gap entry without rewriting its historical originals
    # inside the supplied context evidence/source_packet snapshot.
    old_gap = str(D / 'paper-context-gaps.json')
    packet['metadata_sha256'].pop(old_gap, None)
    ready['evidence_sha256'].pop(old_gap, None)
    save(packet_path, packet)
    ready['packet_sha256'] = file_sha(packet_path)
    save(ready_path, ready)
    return packet


if __name__ == '__main__':
    append()
    print('Applied existing p30 appends only; all acceptance remains pending.')
