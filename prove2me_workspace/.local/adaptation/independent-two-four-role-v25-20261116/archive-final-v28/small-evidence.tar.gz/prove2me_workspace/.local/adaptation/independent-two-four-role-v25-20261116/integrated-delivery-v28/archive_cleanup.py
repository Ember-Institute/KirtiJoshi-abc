#!/usr/bin/env python3
"""Root-run small-evidence archive and exact integrated-draft cleanup.
Default reports only. --apply requires both platform ACCEPTED records plus final
canonical artifact and axiom receipts. No CI, compiler, API, or Git calls.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import tarfile

TASK = Path(__file__).resolve().parent
ROOT = Path('/home/admin-wsl/Coq/abc')
W = ROOT / 'prove2me_workspace'
A = W / '.local/adaptation'
UNIT = A / 'independent-two-four-role-v25-20261116'
SOURCE = A / 'independent-source-helpers-two-v24-20261116'
CHAIN = A / 'main-chain-open-20261116'
OUTPUT = UNIT / 'archive-final-v28'
MAX_FILE = 16 * 1024 ** 2
MAX_TOTAL = 96 * 1024 ** 2


def read(path):
    return json.loads(Path(path).read_text())


def checked(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), 'Missing/symlink input: ' + str(path)
    assert path.stat().st_size <= MAX_FILE, 'Do not read/hash a giant export: ' + str(path)
    assert not any(token in path.name.lower() for token in ['credentials', 'access_token', 'refresh_token']), 'Exclude credentials'
    assert path.name != '.env'
    return path


def sha(path):
    return hashlib.sha256(checked(path).read_bytes()).hexdigest()


def member(path):
    path = Path(path)
    if path.is_relative_to(ROOT):
        key = path.relative_to(ROOT).as_posix()
    else:
        assert path.is_relative_to('/tmp'), 'Unreviewed external evidence'
        key = (OUTPUT.relative_to(ROOT) / 'external-evidence/tmp' / path.relative_to('/tmp')).as_posix()
    assert not PurePosixPath(key).is_absolute() and '..' not in PurePosixPath(key).parts
    return key


def success(path):
    result = read(checked(path))
    assert result['status'] == 'succeeded' and result['result']['exit_code'] == 0
    assert result['request']['workspace'] == str(W) and result['request']['exclusive'] is True
    snapshot = result['result']['snapshot']
    assert snapshot['workspace_mode'] == 'exclusive_worktree' and snapshot['snapshot_id'] is None
    return result


def accepted_and_integrated(manifest, artifact_paths, axiom_path):
    summary = read(UNIT / 'platform/delivery-summary.json')
    assert summary['both_direct_proofs'] == 'ACCEPTED'
    assert summary['root_graph_unchanged'] is True and summary['canonicalC22Connected'] is False
    assert read(UNIT / 'platform/root-graph-before.json') == read(UNIT / 'platform/root-graph-after.json')
    artifacts = [success(path) for path in artifact_paths]
    assert len(artifacts) == 2
    final = []
    for row in manifest['nodes']:
        target = row['targetName']
        verification = read(UNIT / 'platform' / ('verify-' + target.replace('.', '_') + '-result.json'))
        assert verification['status'] == 'ACCEPTED'
        assert verification['theorem_id'] == row['theorem_id'] and verification['id'] == row['submission_id']
        canonical = Path(row['canonicalTarget'])
        assert sha(canonical) == row['candidateSha256'], 'Final canonical proof differs from reviewed candidate'
        raw = canonical.read_bytes()
        a, b = row['canonicalProofByteRange']
        assert hashlib.sha256(raw[a:b]).hexdigest() == row['originalProofSha256']
        matching = [receipt for receipt in artifacts if receipt['request']['worktree_manifest'].get('source_sha256') == row['candidateSha256']]
        receipt, = matching
        relative = str(canonical.relative_to(W))
        assert receipt['result']['actual_arguments'] == ['lean', relative, '-o', '.lake/build/lib/lean/' + relative[:-5] + '.olean']
        assert receipt['request']['worktree_manifest']['input_hashes'][str(canonical)] == row['candidateSha256']
        final.append({'targetName': target, 'platformTheorem': verification['theorem_id'],
            'platformSubmission': verification['id'], 'artifactJob': receipt['job_id'],
            'canonicalSha256': row['candidateSha256']})
    review = success(axiom_path)
    assert review['request']['task_type'] == 'review'
    report = review['result']['review']
    assert report['passed'] is True and report['checks']['no_sorryAx'] is True
    assert report['violations'] == []
    hashes = review['request']['worktree_manifest']['input_hashes']
    for row in manifest['nodes']:
        assert hashes[row['canonicalTarget']] == row['candidateSha256'], 'Final axiom review must bind both actual canonical proofs'
    # This is the existing post-integration axioms receipt, not another proof obligation.
    return final, review


def current_attempt(path):
    return any(token in path.name for token in ['independent-finsum', 'independent-sum-arch',
        'independent-two-Iut_Theorem110Invariants_LocalEstimate_finsum_le_finsum_of_le',
        'independent-two-Iut_Theorem110Invariants_sum_arch', 'restored-sum-affine-quadratic'])


def collect(remove, final_receipts):
    files = set()
    # Full current unit is compact. Exclude this output and bytecode caches.
    for directory in [UNIT, TASK]:
        files.update(checked(path) for path in directory.rglob('*')
            if path.is_file() and '__pycache__' not in path.parts and not path.is_relative_to(OUTPUT))
    files.update(checked(path) for path in SOURCE.glob('*') if path.is_file())
    # Exact directories for these two original proofs; ProcessionSupport is
    # intentionally outside the selection and cleanup scope.
    for directory in ['OriginalCommands', 'SourceProbes', 'OracleConfigs', 'TypeOracleConfigs',
            'oracle-output', 'type-facts', 'Theorems', 'NativeProofs', 'Solutions',
            'DependencyNativeProof', 'formal-only']:
        files.update(checked(path) for path in (SOURCE / directory).rglob('*') if path.is_file())
    attempts = {path for path in CHAIN.glob('*.json') if current_attempt(path)}
    for path in final_receipts:
        path = Path(path)
        assert path.name.endswith('-result.json')
        stem = path.name.removesuffix('-result.json')
        attempts.update(checked(path.parent / (stem + suffix)) for suffix in ['-request.json', '-submit.json', '-result.json'])
    files.update(checked(path) for path in attempts)
    packet, ready = read(UNIT / 'packet.json'), read(UNIT / 'ready.final.json')
    # Follow only known small metadata file pins, never configuration-internal
    # environment exports or arbitrary dependency graphs.
    for path in {**packet['metadata_sha256'], **ready['evidence_sha256']}:
        if Path(path).name != 'paper-context-gaps.json':
            files.add(checked(path))
    for row in read(TASK / 'integration-manifest.json')['nodes']:
        files.add(checked(row['canonicalTarget']))
    files.add(checked(W / 'Theorems/Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean'))
    files.add(checked(ROOT / 'refer/iut/LICENSE'))
    return sorted(files - set(remove), key=str), sorted(attempts, key=str)


def write_tar(destination, entries):
    with tarfile.open(destination, 'w:gz') as archive:
        for entry in entries:
            archive.add(entry['source'], arcname=entry['archive_path'], recursive=False)
    with tarfile.open(destination, 'r:gz') as archive:
        assert {item.name for item in archive.getmembers()} == {entry['archive_path'] for entry in entries}
        for entry in entries:
            stream = archive.extractfile(entry['archive_path'])
            assert stream is not None and hashlib.sha256(stream.read()).hexdigest() == entry['sha256']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifact-receipt', type=Path, action='append', required=True)
    parser.add_argument('--axiom-receipt', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    assert not OUTPUT.exists(), 'Inspect an existing completed/partial archive rather than overwriting it'
    integration = read(TASK / 'integration-manifest.json')
    final, review = accepted_and_integrated(integration, args.artifact_receipt, args.axiom_receipt)
    whitelist = read(TASK / 'delete-whitelist.json')
    assert len(whitelist) == 25
    remove = {}
    for row in whitelist:
        path = ROOT / row['path']
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], 'Draft changed: ' + str(path)
        if path.is_relative_to(W / 'Theorems'):
            assert path.name.endswith('_NativeAuditProof.lean'), 'Never delete a canonical theorem or parent'
        remove[path] = row
    evidence, attempts = collect(remove, args.artifact_receipt + [args.axiom_receipt])
    all_paths = evidence + list(remove)
    total = sum(path.stat().st_size for path in all_paths)
    assert total <= MAX_TOTAL, 'Selected small evidence exceeds bounded 96 MiB; inspect without adding giant dumps'
    assert len({member(path) for path in all_paths}) == len(all_paths)
    attempt_rows = []
    for path in attempts:
        if path.name.endswith('-result.json'):
            receipt = read(path)
            classification = ('obsolete-statement-only-not-proof' if receipt['job_id'].startswith('ci-016954-') or
                path.name == 'restored-sum-affine-quadratic-native-leaf-v24-result.json' else
                'cancelled-old-query-not-passed' if receipt['job_id'].startswith('ci-017055-') else
                'failed-old-query-not-passed' if receipt['job_id'].startswith('ci-017052-') else 'actual-attempt')
            attempt_rows.append({'source': str(path), 'archive_path': member(path), 'job_id': receipt['job_id'],
                'status': receipt['status'], 'classification': classification,
                'exit_code': receipt['result']['exit_code'], 'resources': receipt.get('resources'),
                'compile_time_seconds': receipt.get('compile_time_seconds')})
    entries = [{'source': str(path), 'archive_path': member(path), 'bytes': path.stat().st_size,
                'sha256': sha(path)} for path in evidence]
    duplicates = [{'source': str(path), 'archive_path': member(path), 'bytes': row['bytes'],
                'sha256': row['sha256'], 'category': row['category']} for path, row in remove.items()]
    manifest = {'schema': 'independent-two-accepted-integrated-archive/v28', 'completed': False,
        'finalIntegration': final, 'axiomReviewJob': review['job_id'], 'input_bytes': total,
        'input_mib': total / 1024 ** 2, 'evidence': entries, 'duplicates': duplicates,
        'attempts': attempt_rows, 'canonicalArchiveNames': 'Uniform repo-relative add/getmember keys; /tmp inputs use external-evidence/tmp mapping.',
        'scope': 'Only these two accepted/integrated helpers and their restored parent evidence. ProcessionSupport and every unintegrated proof remain untouched.',
        'canonicalC22Connected': False, 'all200FormalAccepted': False}
    print(json.dumps({'apply': args.apply, 'output': str(OUTPUT), 'evidenceFiles': len(entries),
        'deleteFiles': len(duplicates), 'deleteBytes': sum(row['bytes'] for row in duplicates),
        'input_bytes': total, 'input_mib': total / 1024 ** 2, 'attemptResults': len(attempt_rows)}, ensure_ascii=False, indent=2))
    if not args.apply:
        return
    OUTPUT.mkdir()
    write(OUTPUT / 'archive-manifest.json', manifest)
    write_tar(OUTPUT / 'small-evidence.tar.gz', entries)
    write_tar(OUTPUT / 'integrated-drafts.tar.gz', duplicates)
    for entry in entries + duplicates:
        assert sha(entry['source']) == entry['sha256'], 'Input changed while archiving'
    # Both archives were reopened and all bytes verified before any unlink.
    for path in remove:
        path.unlink()
    manifest['completed'] = True
    manifest['archiveBytes'] = {name: (OUTPUT / name).stat().st_size for name in ['small-evidence.tar.gz', 'integrated-drafts.tar.gz']}
    write(OUTPUT / 'archive-manifest.json', manifest)


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__':
    main()
