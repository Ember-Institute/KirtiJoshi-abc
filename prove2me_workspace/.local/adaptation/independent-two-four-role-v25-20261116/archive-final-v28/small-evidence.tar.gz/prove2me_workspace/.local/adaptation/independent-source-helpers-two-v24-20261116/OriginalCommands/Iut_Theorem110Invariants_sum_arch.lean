/-- The sum over the capsules of the archimedean bound `(j+1)·log π`, via (E1). -/
lemma sum_arch (L : ℕ) :
    ∑ i : Fin L, (((i : ℕ) + 2 : ℕ) : ℝ) * Real.log Real.pi =
      Real.log Real.pi * (L * (L + 3) / 2) := by
  have := sum_affine_quadratic L (Real.log Real.pi) 0 0
  simp only [zero_mul, add_zero] at this
  rw [← this]
  refine Finset.sum_congr rfl fun i _ => ?_
  push_cast
  ring
