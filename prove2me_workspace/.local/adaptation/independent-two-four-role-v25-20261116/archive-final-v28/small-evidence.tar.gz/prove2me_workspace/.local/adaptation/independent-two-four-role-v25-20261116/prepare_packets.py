#!/usr/bin/env python3
"""Reuse the accepted pure-two packet/protocol for two supplied independent proofs.
Only offline task-local files are written. All actual acceptance stays pending.
"""
from pathlib import Path
import ast
import hashlib
import json
import shutil

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A = W / '.local/adaptation'
D = Path(__file__).resolve().parent
SOURCE = Path('/tmp/p2m-main-next-independent-two-v10-20261116')
PREVIOUS = A / 'pure-two-platform-packets-v13-20261116'
PAPER = A / 'supplier-carriers-delivery-20261116/paper-context/paper-context.json'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    path = Path(path)
    assert path.stat().st_size < 16 * 1024 ** 2
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(D)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def prepare():
    audit = read(D / 'audit-index.json')
    nodes = audit['nodes']
    names = [row['targetName'] for row in nodes]
    suffixes = [name.removeprefix('AbcAdaptation.Reference.Iut.') for name in names]
    parent_module = 'Theorems.Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic'
    approved = {names[0]: set(), names[1]: {parent_module}}
    # Exactly the existing per-node proved-parent whitelist, specialized only
    # to these two real theorem names and their actual direct import sets.
    protocol_source = (PREVIOUS / 'delivery_with_proved_parents.py').read_text()
    tree = ast.parse(protocol_source)
    assignment, = [node for node in ast.walk(tree) if isinstance(node, ast.Assign) and
        any(isinstance(target, ast.Name) and target.id == 'approved' for target in node.targets)]
    lines = protocol_source.splitlines(keepends=True)
    indent = lines[assignment.lineno - 1][:assignment.col_offset]
    lines[assignment.lineno - 1:assignment.end_lineno] = [indent + 'approved = ' + repr(approved) + '\n']
    protocol_output = D / 'delivery_with_proved_parent.py'
    protocol_output.write_text(''.join(lines))
    publisher = (PREVIOUS / 'publisher.py').read_text()
    publisher = publisher.replace("OUT = Path('/tmp/p2m-pure-two-platform-packets-v13-20261116')", 'OUT = Path(__file__).resolve().parent')
    publisher = publisher.replace("PROTOCOL = W / '.local/adaptation/pure-two-platform-packets-v13-20261116/delivery_with_proved_parents.py'", "PROTOCOL = OUT / 'delivery_with_proved_parent.py'")
    publisher = publisher.replace("SHORT = ['log_ell_bound', 'epsilonE_le']", 'SHORT = ' + repr(suffixes))
    old_dependencies = "EXPECTED_DEPENDENCY_PATHS = {\n    'Theorems/Thm_AbcAdaptation_Reference_Iut_log_le_self_of_pos.lean',\n    'Theorems/Thm_AbcAdaptation_Reference_Iut_log_le_four_mul_sqrt_sqrt.lean',\n    'Definitions/Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs.lean'}"
    assert publisher.count(old_dependencies) == 1
    publisher = publisher.replace(old_dependencies, "EXPECTED_DEPENDENCY_PATHS = {'Theorems/Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean'}")
    old_frozen = """        assert frozen['sourceOpen'] is True
        assert frozen['readbacks']['en'] == frozen['originalEnglish'] == frozen['readback']
        assert hashlib.sha256(frozen['readbacks']['en'].encode()).hexdigest() == frozen['english_readback_utf8_sha256']"""
    new_frozen = """        assert packet['frozenInputSourceOpen'][name] is True
        english = frozen['readbacks']['en']
        original_english = frozen.get('originalEnglish', frozen.get('readback_en', frozen.get('readback')))
        assert english == original_english
        expected_english_sha = frozen.get('english_readback_utf8_sha256', frozen.get('english_text_sha256'))
        assert hashlib.sha256(english.encode()).hexdigest() == expected_english_sha"""
    assert publisher.count(old_frozen) == 1
    publisher = publisher.replace(old_frozen, new_frozen)
    (D / 'publisher.py').write_text(publisher)
    frozen_all = read(SOURCE / 'frozen-readbacks-exact.json')
    frozen = {row['sourceName']: row for row in frozen_all['nodes']}
    citations = {row['sourceName']: row for row in read(SOURCE / 'source-citation-entries.json')}
    paper_all = read(PAPER)
    quotation, = [row for row in paper_all['quotations'] if row['id'] == 'IV-theorem110-bound']
    original_inputs = frozen_all['originalInputs']
    for item in original_inputs:
        assert sha(item['path']) == item['sha256']
    metadata_paths = [D / 'prepare.py', D / 'prepare_audits.py', D / 'prepare_packets.py',
        D / 'publisher.py', protocol_output, D / 'audit-index.json', D / 'bind_roles.py',
        SOURCE / 'frozen-readbacks-exact.json', SOURCE / 'source-proof-evidence.json',
        SOURCE / 'source-citation-entries.json', SOURCE / 'run-plan.json', PAPER,
        D / 'LICENSE.iut.Apache-2.0'] + [Path(item['path']) for item in original_inputs]
    for evidence in quotation['evidence']:
        for item in evidence.values():
            if isinstance(item, dict) and 'path' in item and 'sha256' in item:
                assert sha(item['path']) == item['sha256']
                metadata_paths.append(Path(item['path']))
    publications, verification, source_hashes, staged_sources, frozen_by_target, explanations = [], [], {}, {}, {}, {}
    proof_rows = []
    titles = [
        'Monotonicity of a real finite-support sum — 实数有限支撑和的单调性 — 実数値有限台和の単調性',
        'A scalar finite sum of archimedean terms — 阿基米德项的标量有限和 — アルキメデス項のスカラー有限和']
    for node, title in zip(nodes, titles):
        source_name, target = node['sourceName'], node['targetName']
        frozen_row = frozen[source_name]
        en = frozen_row['readbacks']['en']
        assert en == frozen_row.get('originalEnglish', frozen_row.get('readback_en', frozen_row.get('readback')))
        assert hashlib.sha256(en.encode()).hexdigest() == frozen_row.get('english_readback_utf8_sha256', frozen_row.get('english_text_sha256'))
        frozen_by_target[target] = frozen_row
        rb = frozen_row['readbacks']
        zh_key = 'zh_Hans' if 'zh_Hans' in rb else 'zh-Hans'
        trilingual = '\n\n'.join('**' + title + '**\n\n' + rb[key] for key, title in
            [('en', 'English'), (zh_key, '简体中文'), ('ja', '日本語')])
        stub_relative = node['stubModule'].replace('.', '/') + '.lean'
        solution_relative = node['solutionModule'].replace('.', '/') + '.lean'
        stub_path = Path(node['stagedSources'][stub_relative]['path'])
        solution_path = Path(node['stagedSources'][solution_relative]['path'])
        stub = stub_path.read_text()
        marker = 'theorem ' + target
        assert stub.count(marker) == 1
        offset = stub.index(marker)
        preamble, formal = stub[:offset], stub[offset:].rstrip('\n')
        assert formal.endswith(':= by sorry')
        # Existing frozen-input status wording is separate from the supplied
        # source/native/global proof files; no original readback is rewritten.
        status = ('The independent readback above was frozen from a statement stub and its '
            'original proof-status sentences are preserved. The separate solution file copies '
            'the complete reference proof body. Source/target compiled-type identity, native '
            'typechecking and axiom acceptance are separate root-supplied gates; the frozen '
            'readback itself is not evidence that those gates have passed.')
        context = citations[source_name]['role']
        quote_text = quotation['quote_markdown']
        description = ('**Independent formal-code readback (frozen statement-stub input)**\n\n' + trilingual +
            '\n\n**Implementation and proof-status context (separate from frozen readback)**\n\n' + status +
            '\n\n**Existing reference source context**\n\n' + context +
            '\n\n**Original paper context**\n\n> ' + quote_text + '\n\n— Shinichi Mochizuki, '
            '*Inter-universal Teichmüller Theory IV*, ' + quotation['locator'] +
            ', printed p. ' + str(quotation['printed_pages'][0]) + '.\n\n' + quotation['scope_note'] +
            '\n\n' + paper_all['paper_sources']['IV']['official_url'])
        payload = {'theorem_name': target, 'theorem_title': title, 'preamble': preamble,
            'formal_statement': formal, 'natural_language_statement': description,
            'source': citations[source_name]['repositoryOriginal']['url'],
            'env': '0df444a360eaa60ab8c11dca51a86af692955474', 'private': True}
        tag = target.replace('.', '_')
        save(D / 'payloads' / (tag + '.json'), payload)
        publications.append({'tag': tag, 'endpoint': '/submit-problem', 'payload': payload})
        verification.append({'tag': tag, 'theorem_name': target, 'source': solution_relative})
        for relative, path in [(stub_relative, stub_path), (solution_relative, solution_path)]:
            source_hashes[relative] = sha(path)
            staged_sources[relative] = str(path)
            metadata_paths.append(path)
        proof_rows.append(node['proofByteEvidence'])
        explanations[target] = trilingual + '\n\n' + status + '\n\n' + context
    helper_journal = A / 'main-c22-numeric-helpers-20261115/delivery-journal'
    helper_name = 'AbcAdaptation.Reference.Iut.sum_affine_quadratic'
    helper_result = helper_journal / 'verify-AbcAdaptation_Reference_Iut_sum_affine_quadratic-result.json'
    helper_intent = helper_journal / 'verify-AbcAdaptation_Reference_Iut_sum_affine_quadratic-intent.json'
    helper = read(helper_result)
    assert helper['status'] == 'ACCEPTED'
    metadata_paths += [helper_result, helper_intent]
    save(D / 'registered-dependencies.json', {'finsumProjectDependencies': [],
        'sumArchProjectDependencies': [{'name': helper_name, 'theorem_id': helper['theorem_id'],
            'submission_id': helper['id'], 'verification_status': helper['status'],
            'actualNativeClosureAccepted': False,
            'restorationSource': str(SOURCE / 'DependencyNativeProof/Theorems/Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean')}],
        'note': 'The installed local parent may still be a sorry stub. Platform ACCEPTED does not assert its local recursive closure.'})
    save(D / 'paper-context-assessment.json', {'availableParentContextQuote': quotation,
        'parentContextSufficient': True, 'blockingDeliveryGap': False,
        'optionalCloserConsumerContext': str(D / 'paper-context-v26/metadata-append-patch.json'),
        'scope_zh': '沿用已独立核对的p23父引文，并原样追加已核对的p30真实消费上下文；不伪称论文另有同名generic lemma。',
        'newGateAdded': False, 'newMaterialsDownloaded': False})
    save(D / 'source-proof-evidence.bound-draft.json', {'nodes': proof_rows})
    # Existing publisher expects this filename; keep author's original full
    # rows separately in source-proof-evidence.original.json.
    shutil.copyfile(SOURCE / 'source-proof-evidence.json', D / 'source-proof-evidence.original.json')
    save(D / 'source-proof-evidence.json', {'nodes': proof_rows})
    metadata_paths += [D / 'registered-dependencies.json', D / 'paper-context-assessment.json', D / 'source-proof-evidence.json']
    packet = {'schema': 'independent-two-private-problem-proof-draft/v25', 'workspace': str(W),
        'mission_id': 'eeb5193f-68c0-41d0-9263-4a5ff7c801ee',
        'root_id': 'e33ff731-60a7-43ef-87ae-c12aeba23cb5',
        'environment': '0df444a360eaa60ab8c11dca51a86af692955474',
        'scope': 'detached-source-consumer-preparation-for-existing-private-mission',
        'root_graph_membership': False, 'canonicalC22Connected': False, 'all200FormalAccepted': False,
        'mathematical_scope': 'Two original independent finite-sum helpers; no main-five carrier parameter is introduced.',
        'publications': publications, 'verification': verification, 'source_sha256': source_hashes,
        'staged_sources': staged_sources, 'metadata_sha256': {str(path): sha(path) for path in metadata_paths},
        'frozenReadbacks': frozen_by_target, 'frozenInputSourceOpen': {name: True for name in names},
        'explanations': explanations, 'sourceOracleJobs': {name: None for name in names},
        'actualSourceTypeFacts': {name: None for name in names}, 'allGatesAccepted': False}
    save(D / 'packet.json', packet)
    old_ready = read(PREVIOUS / 'ready.template.json')
    ready = {'passed': False, 'packet_sha256': sha(D / 'packet.json'), 'source_sha256': source_hashes,
        'gates': {gate: False for gate in old_ready['gates']}, 'ci_receipts': [],
        'evidence_sha256': packet['metadata_sha256'].copy(), 'explanations': explanations,
        'kernel_audits': {name: None for name in names}, 'source_oracle_receipts': {name: None for name in names},
        'source_type_facts': {name: None for name in names}, 'source_type_receipts': {name: None for name in names},
        'dependency_source_sha256': {},
        'required_inputs': {name: {key: None for key in next(iter(old_ready['required_inputs'].values()))} for name in names},
        'shared_required_inputs': {key: None for key in old_ready['shared_required_inputs']},
        'note': 'All existing gates are false. Actual source TYPE facts, separate source proof InfoTree and four-role audit output must be bound by root. No new gate or generic audit layer is introduced.'}
    save(D / 'ready.template.json', ready)
    return packet


if __name__ == '__main__':
    print(json.dumps({'preparedNodes': len(prepare()['publications']), 'allGatesAccepted': False}))
