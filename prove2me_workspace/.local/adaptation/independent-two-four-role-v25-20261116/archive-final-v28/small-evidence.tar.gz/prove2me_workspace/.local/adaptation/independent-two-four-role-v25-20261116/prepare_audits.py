#!/usr/bin/env python3
"""Prepare the existing pure-two four-role checks for exactly two supplied roles.
Offline task-local generation only. No compiler, CI, API, Git, or W writes.
"""
from pathlib import Path
import ast
import hashlib
import json
import shutil

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A = W / '.local/adaptation'
D = Path(__file__).resolve().parent
SOURCE = Path('/tmp/p2m-main-next-independent-two-v10-20261116')
TEMPLATE = A / 'pure-two-four-role-audit-v13-20261116'


def read(path):
    return json.loads(Path(path).read_text())


def pin(path):
    path = Path(path)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(D)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def encode_name(text):
    result = []
    for part in text.split('.'):
        result = [result, 'str', part]
    return result


def unique(data, part):
    assert part and data.count(part) == 1
    start = data.index(part)
    return [start, start + len(part)]


def prepare():
    (D / 'actual').mkdir(exist_ok=True)
    placement_path = A / 'independent-source-helpers-two-v24-20261116/actual-role-placement.json'
    placement = read(placement_path) if placement_path.exists() else None
    roles = read(SOURCE / 'four-role-bindings.template.json')['fourRoles']
    proofs = {row['sourceName']: row for row in read(SOURCE / 'source-proof-evidence.json')}
    original = A / 'main-pure-type-identity-20261116/AuditP5GlobalSolution.lean'
    source = original.read_text()
    common = source[source.index('/-! Stable JSON'):source.index('def pureArithmeticTypeAudit :')]
    extra = (TEMPLATE / 'common-extra.lean.txt').read_text()
    old_map = 'def nativeDataNames : TypeNames := #[( `Iut.epsilonE, `AbcAdaptation.Reference.Iut.epsilonE),\n  (`AbcAdaptation.Reference.Iut.epsilonE, `AbcAdaptation.Reference.Iut.epsilonE)]'
    assert extra.count(old_map) == 1
    extra = extra.replace(old_map, 'def nativeDataNames : TypeNames := #[]')
    extra = extra.replace('n != `AbcAdaptation.Reference.Iut.epsilonE && ', '')
    extra = extra.replace('dep != `AbcAdaptation.Reference.Iut.epsilonE && ', '')
    old_forbidden = '#["Iut." ++ short,"AbcAdaptation.Reference.Iut." ++ short,"Iut.Corollary22Inputs.c2","Iut.c2_final","Iut.assembly"]'
    new_forbidden = '#[(← checked (stringField cfg "sourceName")),(← checked (stringField cfg "targetName")),(← checked (stringField cfg "nativeName")),"Iut.Corollary22Inputs.c2","Iut.c2_final","Iut.assembly"]'
    assert extra.count(old_forbidden) == 1
    extra = extra.replace(old_forbidden, new_forbidden)
    common += extra
    native_body = (TEMPLATE / 'native-body.lean.txt').read_text()
    native_body = native_body.replace('stringField cfg "schema"', 'stringField cfg "schema"')
    assert native_body.count('field cfg "targetNameExpr"') == 1 and native_body.count('field cfg "theoremModule"') == 1
    native_body = native_body.replace('field cfg "targetNameExpr"', 'field cfg "nativeNameExpr"')
    native_body = native_body.replace('field cfg "theoremModule"', 'field cfg "nativeModule"')
    old_output = '("targetName", toJson n.toString), ("owner", encodeName owner),'
    assert native_body.count(old_output) == 1
    native_body = native_body.replace(old_output,
        '("targetName", ← checked (field cfg "targetName")), ("nativeName", toJson n.toString), ("owner", encodeName owner),')
    final_body = (TEMPLATE / 'final-body.lean.txt').read_text()
    receipt_line = '  requireReceipts (← checked (field cfg "dependencyReceiptBindings"))'
    guarded = ('  if !(← checked (cfg.getObjValAs? (Array String) "registeredDependencyNames")).isEmpty then\n'
        '    requireReceipts (← checked (field cfg "dependencyReceiptBindings"))')
    assert native_body.count(receipt_line) == final_body.count(receipt_line) == 1
    native_body = native_body.replace(receipt_line, guarded)
    final_body = final_body.replace(receipt_line, guarded)
    previous_publisher = A / 'pure-two-platform-packets-v13-20261116/publisher.py'
    flag_values = {}
    for node in ast.parse(previous_publisher.read_text()).body:
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id in ['AUDIT_FLAGS', 'NO_SORRY_FLAGS'] for target in node.targets):
            flag_values[node.targets[0].id] = ast.literal_eval(node.value)
    assert len(flag_values['AUDIT_FLAGS']) == 12 and len(flag_values['NO_SORRY_FLAGS']) == 5
    outputs = []
    for role in roles:
        source_name = role['sourceName']
        proof = proofs[source_name]
        short = source_name.split('.')[-1]
        key = source_name.replace('.', '_')
        native_rel = 'Theorems/' + Path(role['nativeNamedProofFile']).stem + '_NativeAuditProof.lean'
        stub_rel = 'Theorems/' + Path(role['targetStubFile']).name
        solution_rel = 'Solutions/' + Path(role['globalSolutionFile']).name
        native_module = native_rel[:-5].replace('/', '.')
        stub_module = stub_rel[:-5].replace('/', '.')
        solution_module = solution_rel[:-5].replace('/', '.')
        staging = {}
        for relative, path in [(native_rel, role['nativeNamedProofFile']), (stub_rel, role['targetStubFile']), (solution_rel, role['globalSolutionFile'])]:
            target = D / 'staging' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
            staging[relative] = pin(target)
            installed = W / relative
            if placement is not None:
                assert installed.read_bytes() == target.read_bytes()
                assert pin(installed)['sha256'] == placement['sourceSHA256'][str(installed)]
        native = Path(role['nativeNamedProofFile']).read_bytes()
        solution = Path(role['globalSolutionFile']).read_bytes()
        original_command = (SOURCE / 'OriginalCommands' / (key + '.lean')).read_bytes()
        source_name_end = original_command.index(('lemma ' + short).encode()) + len(('lemma ' + short).encode())
        source_value_start = original_command.index(b':= by', source_name_end)
        signature = original_command[source_name_end:source_value_start]
        a, b = proof['globalSolutionProofRange']
        body = solution[a:b]
        assert hashlib.sha256(body).hexdigest() == proof['sourceProofSha256']
        nr = unique(native, body)
        sr = unique(native, signature)
        ss = unique(solution, signature)
        assert sr[1] == nr[0] and ss[1] == a
        byte_evidence = {'sourceName': source_name, 'targetName': role['targetStubName'],
            'nativeName': role['nativeNamedProofName'], 'sourceProofSha256': proof['sourceProofSha256'],
            'signatureSha256': hashlib.sha256(signature).hexdigest(),
            'nativeSignatureByteRange': sr, 'nativeProofByteRange': nr,
            'solutionSignatureByteRange': ss, 'solutionProofByteRange': [a, b],
            'originalCommand': pin(SOURCE / 'OriginalCommands' / (key + '.lean'))}
        names = [] if short == 'finsum_le_finsum_of_le' else ['AbcAdaptation.Reference.Iut.sum_affine_quadratic']
        dependency_sources = [pin(W / 'Theorems/Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean')] if names else []
        expected_native = pin(W / native_rel) if placement is not None else staging[native_rel]
        expected_stub = pin(W / stub_rel) if placement is not None else staging[stub_rel]
        expected_solution = pin(W / solution_rel) if placement is not None else staging[solution_rel]
        cfg = {'schema': 'pure-four-role-config/v13', 'publish': False, 'short': short,
            'sourceName': source_name, 'targetName': role['targetStubName'],
            'nativeName': role['nativeNamedProofName'],
            'targetNameExpr': encode_name(role['targetStubName']), 'nativeNameExpr': encode_name(role['nativeNamedProofName']),
            'nativeModule': encode_name(native_module), 'theoremModule': encode_name(stub_module),
            'solutionModule': encode_name(solution_module),
            'sourceFacts': None, 'sourceTypeReceipt': None, 'sourceTypeFactsBinding': None,
            'nativeInstalledSource': str(W / native_rel), 'stubInstalledSource': str(W / stub_rel),
            'solutionInstalledSource': str(W / solution_rel),
            'expectedNativeSource': expected_native, 'expectedStubSource': expected_stub,
            'expectedSolutionSource': expected_solution,
            'expectedNativeText': None, 'expectedStubText': None, 'expectedSolutionText': None,
            'proofByteEvidence': byte_evidence, 'registeredDependencyNames': names,
            'registeredDependencySourcePins': dependency_sources,
            'actualRolePlacement': pin(placement_path) if placement is not None else None,
            'sourceBinding': None, 'nativeReceiptBindings': None, 'nativeFactsBinding': None,
            'stubReceiptBindings': None, 'solutionReceiptBindings': None, 'dependencyReceiptBindings': None,
            'nativeFactsOutput': str(D / 'actual' / (key + '-native-facts.json')),
            'finalOutput': str(D / 'actual' / (key + '-four-role-audit.json')),
            'publisherAuditFlags': flag_values['AUDIT_FLAGS'], 'publisherNoSorryFlags': flag_values['NO_SORRY_FLAGS'],
            'pending': 'Root binds actual one-root source TYPE facts and separate source proof InfoTree, then native facts and final stub/global solution receipts. No gate is preaccepted.'}
        save(D / 'configs' / (key + '-config.template.json'), cfg)
        for phase, imports, body_text in [('NativeFacts', [native_module], native_body),
                ('FourRoles', [stub_module, solution_module], final_body)]:
            query = D / 'queries' / (phase + '_' + key + '.lean')
            query.parent.mkdir(exist_ok=True)
            query.write_text('import Lean\n' + ''.join('import ' + module + '\n' for module in imports) + '\n' + common + body_text)
        save(D / 'configs' / (key + '-audit.not-run.json'), {'sourceName': source_name,
            'targetName': role['targetStubName'], 'publish': False, 'passed': False,
            'sourceOracleJob': None, 'sourceProofSha256': proof['sourceProofSha256'],
            'auditFlags': {flag: None for flag in flag_values['AUDIT_FLAGS']},
            'noSorryFlags': {flag: None for flag in flag_values['NO_SORRY_FLAGS']}})
        outputs.append({'sourceName': source_name, 'targetName': role['targetStubName'],
            'nativeName': role['nativeNamedProofName'], 'nativeModule': native_module,
            'stubModule': stub_module, 'solutionModule': solution_module,
            'configTemplate': pin(D / 'configs' / (key + '-config.template.json')),
            'nativeFactsQuery': pin(D / 'queries' / ('NativeFacts_' + key + '.lean')),
            'fourRoleQuery': pin(D / 'queries' / ('FourRoles_' + key + '.lean')),
            'sourceTypeQuery': pin(SOURCE / 'QueryIndependentTypeFacts.lean'),
            'sourceTypeConfig': pin(role['typeConfig']), 'sourceProofConfig': pin(proof['oracleConfig']),
            'proofByteEvidence': byte_evidence, 'stagedSources': staging,
            'registeredDependencyNames': names})
    save(D / 'audit-index.json', {'schema': 'independent-two-four-role-draft/v25', 'nodes': outputs,
        'environmentVariable': 'PURE_FOUR_ROLE_CONFIG',
        'sourceTypeEnvironmentVariable': 'PURE_TYPE_SOURCE_CONFIG',
        'templateSource': pin(TEMPLATE / 'prepare.py'), 'publisherFlags': flag_values,
        'queryTemplateEdits': ['exact native name/module owner fields',
            'canonical targetName plus explicit historical nativeName',
            'empty project data-name mapping: these two source types have no project data dependencies',
            'actual fully qualified source/native/target self-reference names',
            'no artificial dependency receipt when the actual dependency list is empty'],
        'APIInvoked': False, 'CIInvoked': False, 'compilerInvoked': False, 'GitInvoked': False,
        'mainWorkspaceModified': False, 'actualFactsBound': False})
    return outputs


if __name__ == '__main__':
    print(json.dumps({'preparedNodes': len(prepare()), 'actualFactsBound': False}))
