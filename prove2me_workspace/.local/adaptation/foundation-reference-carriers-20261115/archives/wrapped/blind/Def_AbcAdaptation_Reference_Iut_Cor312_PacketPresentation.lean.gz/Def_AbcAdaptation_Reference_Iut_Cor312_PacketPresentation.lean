import Mathlib.Algebra.Group.Pointwise.Set.Scalar
import Mathlib.Algebra.Group.Units.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Data.Set.Defs
import Mathlib.Topology.Constructions
import Mathlib.Topology.Defs.Basic

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



open scoped Pointwise

namespace Iut

universe u v


structure DirectSumPresentation (C : Type u) : Type (max u (v + 1)) where
  
  Summand : C → Type v
  
  [ring_summand : ∀ c, CommRing (Summand c)]
  
  [topology_summand : ∀ c, TopologicalSpace (Summand c)]
  
  integral : ∀ c, Set (Summand c)

attribute [instance] DirectSumPresentation.ring_summand
  DirectSumPresentation.topology_summand

namespace DirectSumPresentation

variable {C : Type u} (P : DirectSumPresentation.{u, v} C)


def Total : Type (max u v) := ∀ c, P.Summand c

instance : TopologicalSpace P.Total := inferInstanceAs (TopologicalSpace (∀ c, P.Summand c))


def integralRegion : Set P.Total := {x | ∀ c, x c ∈ P.integral c}


def IsProductRegion (R : Set P.Total) : Prop :=
  ∃ U : ∀ c, Set (P.Summand c), R = {x | ∀ c, x c ∈ U c}


def productRegion (U : ∀ c, Set (P.Summand c)) : Set P.Total := {x | ∀ c, x c ∈ U c}


def scaledIntegral (a : P.Total) : Set P.Total :=
  {x | ∀ c, x c ∈ a c • P.integral c}


def IsHullRegion (R : Set P.Total) : Prop :=
  ∃ a : P.Total, (∀ c, IsUnit (a c)) ∧ R = P.scaledIntegral a

end DirectSumPresentation

end Iut

end AbcAdaptation.Reference
