/-- The nonarchimedean place attached to a finite place. -/
def finite (w : FinitePlace k) : Place k := Sum.inl w