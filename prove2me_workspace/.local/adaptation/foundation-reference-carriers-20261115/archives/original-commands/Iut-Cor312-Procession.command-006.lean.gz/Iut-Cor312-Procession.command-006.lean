/-- A **capsule** of labels drawn from `ι`: a finite collection of labels
(IUT I, §4). The objects indexed by a capsule (prime strips, log-shells, …) are
attached on top of this combinatorial datum by the container modules. -/
structure Capsule (ι : Type*) where
  /-- The finite set of labels of the capsule. -/
  labels : Finset ι