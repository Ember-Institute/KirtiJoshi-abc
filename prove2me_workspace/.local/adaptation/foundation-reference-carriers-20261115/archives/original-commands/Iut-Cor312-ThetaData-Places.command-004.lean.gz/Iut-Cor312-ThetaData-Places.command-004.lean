/-- The set of places `V(k)` of a number field: finite (nonarchimedean) places and
infinite (archimedean) places (IUT I, Definition 3.1(b): `V_mod = V(F_mod)`). -/
def Place : Type _ := FinitePlace k ⊕ InfinitePlace k