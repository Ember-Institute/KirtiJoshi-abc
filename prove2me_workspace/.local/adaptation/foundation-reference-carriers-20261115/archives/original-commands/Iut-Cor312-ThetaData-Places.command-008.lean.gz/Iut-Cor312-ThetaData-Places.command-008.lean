/-- The archimedean place attached to an infinite place. -/
def infinite (w : InfinitePlace k) : Place k := Sum.inr w