/-- The number of labels of a capsule. -/
def card (S : Capsule ι) : ℕ := S.labels.card