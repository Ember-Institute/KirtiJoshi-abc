/-- The total space of a direct-sum-of-fields presentation. Since the component index is
finite in every intended instantiation, the direct sum is the plain dependent product. -/
def Total : Type (max u v) := ∀ c, P.Summand c