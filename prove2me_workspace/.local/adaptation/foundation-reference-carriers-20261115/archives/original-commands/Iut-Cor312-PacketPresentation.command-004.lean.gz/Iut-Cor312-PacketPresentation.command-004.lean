/-- A **direct-sum-of-fields presentation** with integral structures: for each component
`c` of a finite index type `C`, a topological field `Summand c` with a designated
integral structure `integral c` (the *holomorphic integral structure* `O` of the
summand).

In the intended instantiation `C` is the set of tuples `(v_j)_{j ∈ S}` of places
`v_j ∣ v_Q` indexed by the labels of a capsule `S`, and `Summand c` is the corresponding
tensor factor field of the semisimple decomposition of the tensor-packet
(IUT III, Remark 3.9.5). -/
structure DirectSumPresentation (C : Type u) : Type (max u (v + 1)) where
  /-- The summand field at component `c`. -/
  Summand : C → Type v
  /-- Each summand is a commutative ring: a field, or — for the tensor products of
  local fields that present the tensor-packets (IUT III, Proposition 3.1) — a finite
  product of fields. Nonzero components of hull regions are accordingly *units*. -/
  [ring_summand : ∀ c, CommRing (Summand c)]
  /-- Each summand carries a topology (used for the relative-compactness hypotheses of
  the holomorphic hull, taxis #45). -/
  [topology_summand : ∀ c, TopologicalSpace (Summand c)]
  /-- The holomorphic integral structure `O` of each summand: the ring of integers of a
  nonarchimedean summand (a subring), the unit ball of an archimedean one (a subset,
  IUT IV, Proposition 1.5(iii)). Carried as a set so that both cases are covered. -/
  integral : ∀ c, Set (Summand c)