/-- The label set of a capsule, as a type. -/
def LabelType (S : Capsule ι) : Type _ := S.labels