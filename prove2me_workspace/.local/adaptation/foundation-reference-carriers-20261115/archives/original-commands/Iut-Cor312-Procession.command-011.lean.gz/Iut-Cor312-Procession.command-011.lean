instance [DecidableEq ι] (S : Capsule ι) : DecidableEq S.LabelType :=
  inferInstanceAs (DecidableEq S.labels)