/-- The group homomorphism on points induced by a ring homomorphism of fields
(`WeierstrassCurve.Affine.Point.map` for the base change `E.map f`). -/
noncomputable def pointMap (E : WeierstrassCurve k) (f : k →+* K) :
    E.toAffine.Point →+ (E.map f).toAffine.Point :=
  letI := f.toAlgebra
  Affine.Point.map (W' := E) (S := k) (F := k) (K := K) (Algebra.ofId k K)