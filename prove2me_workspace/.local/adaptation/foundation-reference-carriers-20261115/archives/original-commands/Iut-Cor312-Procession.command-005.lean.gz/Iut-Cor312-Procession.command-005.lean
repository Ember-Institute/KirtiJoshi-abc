lemma procLabels_mono {i j : ℕ} (h : i ≤ j) : procLabels i ⊆ procLabels j :=
  Finset.Iic_subset_Iic.mpr h