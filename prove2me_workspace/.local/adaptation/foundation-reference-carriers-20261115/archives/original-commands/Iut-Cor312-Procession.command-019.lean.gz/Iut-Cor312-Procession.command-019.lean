/-- The **standard procession** of the tensor-packet construction: the chain
`S_2 ⊆ S_3 ⊆ ⋯ ⊆ S_{n+1}` of label sets, where the `i`-th capsule (`i = 0, …, n-1`,
corresponding to the paper's index `j = i + 1 ∈ {1, …, ℓ*}`) has label set
`S_{j+1} = {0, 1, …, j}`. In the intended instantiation `n = ℓ* = (ℓ - 1)/2` for the
prime `ℓ` of the initial Θ-data (IUT III, Propositions 3.1–3.3). -/
def standard (n : ℕ) : Procession ℕ where
  length := n
  capsule i := ⟨procLabels (i + 1)⟩
  labels_mono i j h := procLabels_mono (by exact Nat.add_le_add_right h 1)