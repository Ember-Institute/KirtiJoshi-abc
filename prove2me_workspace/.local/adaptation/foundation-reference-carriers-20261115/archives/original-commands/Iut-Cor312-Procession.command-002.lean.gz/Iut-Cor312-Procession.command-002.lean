/-- The label set `S_{j+1} = {0, 1, …, j}` of IUT III, Propositions 3.1–3.3, a finite
set of `j + 1` labels. The index convention follows the papers: the *subscript* of `S`
is the cardinality, so `procLabels j` is the set called `S_{j+1}`. -/
def procLabels (j : ℕ) : Finset ℕ := Finset.Iic j