/-- The residue characteristic of a nonarchimedean rational place, and (by the junk
convention, documented here) `0` at the archimedean place. -/
def residueChar : RationalPlace → ℕ
  | finite p => p
  | infinite => 0