/-- A **procession** of capsules (IUT I, §§4–6): a finite increasing chain of capsules.
The inclusion maps of the chain are recorded by `labels_mono`; see
`Procession.inclusion` for the induced maps of label types. -/
structure Procession (ι : Type*) where
  /-- The number of capsules in the procession. -/
  length : ℕ
  /-- The capsules of the procession. -/
  capsule : Fin length → Capsule ι
  /-- Monotonicity: the labels of the capsules form an increasing chain. This datum
  encodes the inclusion maps of the procession. -/
  labels_mono : ∀ ⦃i j : Fin length⦄, i ≤ j → (capsule i).labels ⊆ (capsule j).labels