/-- The residue characteristic of a finite place: the characteristic of its residue
field. For a place over the rational prime `p` this is `p`. -/
noncomputable def residueChar (w : FinitePlace k) : ℕ :=
  ringChar (𝓞 k ⧸ w.maximalIdeal.asIdeal)