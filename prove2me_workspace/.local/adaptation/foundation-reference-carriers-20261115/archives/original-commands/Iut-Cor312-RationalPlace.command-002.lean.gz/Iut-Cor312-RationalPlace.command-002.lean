/-- A place of `ℚ`: either the nonarchimedean place attached to a rational prime `p`,
or the archimedean place `∞`. This is the index set `V_Q` of the `v_Q`-indexed local
tensor-packets of IUT III, Propositions 3.1–3.3. -/
inductive RationalPlace : Type
  /-- The nonarchimedean place of `ℚ` attached to the rational prime `p`. -/
  | finite (p : Nat.Primes) : RationalPlace
  /-- The archimedean place of `ℚ`. -/
  | infinite : RationalPlace
  deriving DecidableEq