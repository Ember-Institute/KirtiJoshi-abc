/-- The **lies over** relation between finite places of an extension `K/k`: the prime of
`𝓞_K` attached to `w` lies over the prime of `𝓞_k` attached to `v` (`Ideal.LiesOver`; the
normalized absolute value of `w` restricts to a *power* of that of `v`, so the relation
is stated on the primes). -/
def FinitePlace.LiesOver {K : Type*} [Field K] [NumberField K] [Algebra k K]
    (w : FinitePlace K) (v : FinitePlace k) : Prop :=
  w.maximalIdeal.asIdeal.LiesOver v.maximalIdeal.asIdeal