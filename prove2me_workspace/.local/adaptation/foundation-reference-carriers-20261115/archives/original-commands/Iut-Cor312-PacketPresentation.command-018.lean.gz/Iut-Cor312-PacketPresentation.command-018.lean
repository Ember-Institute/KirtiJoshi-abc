/-- The scaled integral region `a · O`: the set of vectors whose `c`-component lies in
`a c • O_c` for every component `c`. For `a` with every component nonzero these are the
candidate holomorphic hulls of IUT III, Remark 3.9.5(i). -/
def scaledIntegral (a : P.Total) : Set P.Total :=
  {x | ∀ c, x c ∈ a c • P.integral c}