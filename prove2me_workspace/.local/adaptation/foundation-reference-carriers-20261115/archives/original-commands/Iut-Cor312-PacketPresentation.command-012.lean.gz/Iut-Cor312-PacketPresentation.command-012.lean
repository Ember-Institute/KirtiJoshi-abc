/-- A **direct-product [pre-]region**: a region of the total space which is the product
of one region in each summand field (IUT III, Remark 3.9.5(ii) distinguishes these from
arbitrary regions). -/
def IsProductRegion (R : Set P.Total) : Prop :=
  ∃ U : ∀ c, Set (P.Summand c), R = {x | ∀ c, x c ∈ U c}