/-- A rational place is nonarchimedean if it is attached to a rational prime. -/
def IsFinite : RationalPlace → Prop
  | finite _ => True
  | infinite => False