/-- The holomorphic integral region `⊕_c O_c` of the presentation: the set of vectors
with every component in the integral structure of its summand. -/
def integralRegion : Set P.Total := {x | ∀ c, x c ∈ P.integral c}