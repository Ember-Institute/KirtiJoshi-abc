/-- The product region attached to a family of component regions. -/
def productRegion (U : ∀ c, Set (P.Summand c)) : Set P.Total := {x | ∀ c, x c ∈ U c}