/-- A **hull region**: a region of the form `a · O` with every component of `a` a
unit — nonzero in every field factor (IUT III, Remark 3.9.5(i)). The holomorphic hull
of a region `U` is the least hull region containing `U`; see `Iut.HullSystem`. -/
def IsHullRegion (R : Set P.Total) : Prop :=
  ∃ a : P.Total, (∀ c, IsUnit (a c)) ∧ R = P.scaledIntegral a