from pathlib import Path
import json,hashlib
P=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/theorem110-open-v47-20261116');A=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation')
base=(A/'iota-nonneg-v41-20261116/QueryIotaOriginalTypeFacts.lean').read_text()
common=base[base.index('namespace FoundationAudit'):base.index('def kind (ci : ConstantInfo)')]
telescope=base[base.index('def telescopeJson (type : Expr)'):base.index('end FoundationAudit')]
common+=telescope+'end FoundationAudit\n'
roles=(A/'iota-nonneg-v41-20261116/roles-v42/queries/FourRolesIota.lean').read_text()
kernel=roles[roles.index('namespace FoundationAudit\nopen Lean Elab Term Meta',roles.index('end FoundationAudit')):roles.index('def actualTargetProof')]
# This reused decoder has no proof bodies; all project data is an explicit map.
def write(rel,x):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2)+'\n')
mapdata=json.loads((P/'type-owner-map.json').read_text())
def name_expr(s):
 n=[]
 for x in s.split('.'):n=[n,'str',x]
 return n
root='Iut.Theorem110Invariants.theorem110';target='AbcAdaptation.Reference.'+root
source_cfg={'schema':'theorem110-source-TYPE-only/v45','root':root,'rootNameExpr':name_expr(root),'expectedCompiler':'4.35.0-rc3','sourceModule':'Iut.Implication.Theorem110','sourceProofValueRead':False,'sourceWholeCommand':json.loads((P/'SOURCE_LEDGER.json').read_text())['originalSource']['source/OriginalCommand.lean'],'outputFile':str(P/'actual/source-type.json')}
write('queries/source-type.config.json',source_cfg)
source_body=r'''
namespace Theorem110SourceType
open Lean Elab Term Meta FoundationAudit
run_meta do
  let cfg ← jsonFile (← absoluteEnv "THEOREM110_TYPE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "theorem110-source-TYPE-only/v45" do
    throwError "Wrong source TYPE configuration"
  unless Lean.versionString == (← checked (stringField cfg "expectedCompiler")) do
    throwError "Wrong source compiler: {Lean.versionString}"
  let root ← checked (decodeName (← checked (field cfg "rootNameExpr")))
  let ci ← getConstInfo root
  let env ← getEnv
  unless moduleOf env root == some (← checked (stringField cfg "sourceModule")).toName do
    throwError "Wrong source owner"
  unless ← isProp ci.type do throwError "Expected theorem TYPE"
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let taxs ← expressionAxioms cache ci.type
  ensureStandard "source TYPE" taxs
  let constants := ci.type.getUsedConstants.qsort Name.lt
  let owners ← constants.mapM fun n => do
    return Json.mkObj [("name",toJson n.toString),("nameExpr",encodeName n),
      ("owner",(moduleOf env n).map (toJson ·.toString) |>.getD Json.null)]
  let record := Json.mkObj [
    ("schema",toJson "theorem110-source-TYPE-only-facts/v45"),
    ("configuration",cfg),("compilerVersion",toJson Lean.versionString),
    ("name",toJson root.toString),("nameExpr",encodeName root),
    ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("typeExpr",← checked (encodeExpr ci.type)),
    ("typeDisplay",toJson (← ppExpr ci.type).pretty),
    ("telescope",← telescopeJson ci.type),
    ("binderInventory",toJson (binderInventory ci.type)),
    ("typeAxioms",toJson (taxs.map Name.toString)),
    ("typeConstantCount",toJson constants.size),
    ("projectTypeConstantCount",toJson (constants.filter (`Iut).isPrefixOf).size),
    ("typeConstantOwners",Json.arr owners),
    ("rootTheoremProofValueRead",toJson false),
    ("rootTheoremAxiomClosureRead",toJson false)]
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) (record.pretty ++ "\n")
  logInfo s!"Exported exact source TYPE only: {constants.size} constants; no root proof value read"
end Theorem110SourceType
'''
write('queries/QueryTheorem110SourceType.lean','import Lean\nimport Iut.Implication.Theorem110\n\n'+common+source_body)
source_facts=str(P/'actual/source-type.json')
target_cfg={'schema':'theorem110-target-open-statement-audit/v45','root':target,'rootNameExpr':name_expr(target),'expectedCompiler':'4.33.1','sourceTypeFacts':source_facts,'sourceTypeFactsSha256':None,'sourceTypeFactsPinRequiredBeforeCI':True,'nameMap':[{'source':x['source'],'sourceNameExpr':x['sourceNameExpr'],'target':x['target'],'targetNameExpr':x['targetNameExpr']} for x in mapdata['rows']],'expectedLevelParams':[name_expr('u'),name_expr('v')],'expectedBinderNames':['AG','TG','X','inv','cert','est','pnt','h312'],'expectedBinderInfo':['implicit','implicit','implicit','default','default','default','default','default'],'allowOpenSorryAx':True,'outputFile':str(P/'actual/target-audit.json')}
write('queries/target-audit.config.json',target_cfg)
target_body=r'''
end FoundationAudit
namespace Theorem110OpenStatementAudit
open Lean Elab Term Meta FoundationAudit
run_meta do
  let cfg ← jsonFile (← absoluteEnv "THEOREM110_TYPE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "theorem110-target-open-statement-audit/v45" do
    throwError "Wrong target audit configuration"
  unless Lean.versionString == (← checked (stringField cfg "expectedCompiler")) do
    throwError "Wrong target compiler: {Lean.versionString}"
  let root ← checked (decodeName (← checked (field cfg "rootNameExpr")))
  let ci ← getConstInfo root
  let source ← jsonFile (← checked (stringField cfg "sourceTypeFacts"))
  unless (← checked (source.getObjValAs? Bool "rootTheoremProofValueRead")) == false do
    throwError "Source facts must be TYPE only"
  let nameMap ← (← checked (arrayField cfg "nameMap")).mapM fun row => do
    let n ← checked (decodeName (← checked (field row "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field row "targetNameExpr")))
    return (n,t)
  let imported ← checked (decodeType nameMap #[] #[] false (← checked (field source "typeExpr")))
  kernelTypeEq "source TYPE mapped to exact target TYPE" imported ci.type
  unless binderPlacement imported == binderPlacement ci.type do
    throwError "Source/target BinderInfo placement differs"
  unless binderInventory imported == binderInventory ci.type do
    throwError "Source/target BinderInfo inventory differs"
  let sourceLevels ← checked (arrayField source "levelParams")
  unless sourceLevels == ci.levelParams.toArray.map encodeName do
    throwError "Source/target universe parameter order differs"
  let tel ← telescopeJson ci.type
  let bs ← checked (arrayField tel "binders")
  let names ← bs.mapM fun b => checked (stringField b "name")
  let bis ← bs.mapM fun b => checked (stringField b "binderInfo")
  unless names == (← checked (cfg.getObjValAs? (Array String) "expectedBinderNames")) do
    throwError "Target telescope names differ"
  unless bis == (← checked (cfg.getObjValAs? (Array String) "expectedBinderInfo")) do
    throwError "Target telescope binding modes differ"
  let env ← getEnv
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let taxs ← expressionAxioms cache ci.type
  ensureStandard "target TYPE" taxs
  -- Audit the admitted statement closure explicitly. No source proof is imported.
  let axs ← collectAxioms root
  for ax in axs do
    unless standardAxioms.contains ax || ax == `sorryAx do
      throwError "Unexpected target open-statement axiom {ax}"
  unless axs.contains `sorryAx do throwError "Expected explicitly open theorem stub"
  let constants := ci.type.getUsedConstants.qsort Name.lt
  let owners ← constants.mapM fun n => do
    if (`Iut).isPrefixOf n then throwError "Original project TYPE constant leaked: {n}"
    return Json.mkObj [("name",toJson n.toString),("nameExpr",encodeName n),
      ("owner",(moduleOf env n).map (toJson ·.toString) |>.getD Json.null)]
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "theorem110-target-open-statement-audit-facts/v45"),
    ("configuration",cfg),("compilerVersion",toJson Lean.versionString),
    ("name",toJson root.toString),("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("typeExpr",← checked (encodeExpr ci.type)),("typeDisplay",toJson (← ppExpr ci.type).pretty),
    ("telescope",tel),("binderInventory",toJson (binderInventory ci.type)),
    ("binderPlacement",toJson (binderPlacement ci.type)),
    ("kernelMappedSourceTypeEqual",toJson true),
    ("binderInfoPlacementEqual",toJson true),("levelParamsOrderEqual",toJson true),
    ("typeConstantCount",toJson constants.size),
    ("projectTypeConstantCount",toJson (constants.filter (`AbcAdaptation).isPrefixOf).size),
    ("typeConstantOwners",Json.arr owners),
    ("typeAxioms",toJson (taxs.map Name.toString)),
    ("openStatementAxioms",toJson ((axs.qsort Name.lt).map Name.toString)),
    ("hasSorryAx",toJson (axs.contains `sorryAx)),
    ("status",toJson "exact open statement; proof remains open; no completed proof acceptance")]).pretty ++ "\n")
  logInfo "Theorem110 exact TYPE/BinderInfo/open-axiom audit passed; proof remains open"
end Theorem110OpenStatementAudit
'''
write('queries/QueryTheorem110TargetAudit.lean','import Lean\nimport Theorems.Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110\n\n'+common+kernel+target_body)
# CI execution belongs to the main agent. Deliberately no fabricated clean manifest or job receipt.
write('ci/handoff.json',{'schema':'theorem110-main-agent-CI-handoff/v45','compilePerformed':False,'mainWorkspaceTouched':False,'source':{'query':str(P/'queries/QueryTheorem110SourceType.lean'),'config':str(P/'queries/source-type.config.json'),'version':'4.35.0-rc3','useExistingCache':True,'priorSourceGraphJob':'ci-012771-ee109b3e','noProofOracleRequired':True},'target':{'installStubTo':'Theorems/Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110.lean','query':str(P/'queries/QueryTheorem110TargetAudit.lean'),'config':str(P/'queries/target-audit.config.json'),'version':'4.33.1','mathlib':'0df444a360eaa60ab8c11dca51a86af692955474'},'requestFields':{'language':'lean','project_id':'ArithmeticTeichmullerSpaces','workspace':'/home/admin-wsl/Coq/abc/prove2me_workspace','task_type':'leaf','target':'file','exclusive':True,'expected_duration':'60s','expected_memory':'16GiB'},'requiredMainAgentFields':['parameters.source','environment.LEAN_PATH','environment.THEOREM110_TYPE_CONFIG','session_id','agent_id','accurate current worktree_manifest','fresh idempotency_key'],'sequence':['Finish current frozen iota CI job before installing anything.','Install only the new target stub and query/config; retain existing published Definition modules.','Run source TYPE-only query on existing 4.35 cache (or reuse a verified exact TYPE Expr artifact if one is found).','Pin source-type.json SHA256 into target config and immutable manifest; the Lean query reads that pinned artifact.','Run target stub leaf and produce its olean through MCP-CI.','Run target TYPE/BinderInfo/open-axiom audit; accept only terminal succeeded receipt and inspected actual artifact.','Complete owning Checks/Axioms, ImportAudit, Act1Scene1 aggregate, AxiomAudit as required by applicable project workflow.','Run git diff --check in main workspace.','Review payload against actual platform create-theorem schema; publish private open statement and exact readback under existing authorization.','Read back actual platform fields and Open status; record node id and actual c2 consumer edge status.'], 'proofGate':'No four-role complete-proof audit for this open-statement publication. A future proof/reduction gets its own audit. sorryAx is expected for this stub and must remain labelled open.'})
print('queries prepared')
