本包准备 `AbcAdaptation.Reference.Iut.Theorem110Invariants.theorem110` 的精确开放陈述。父消费者为 `Iut.Corollary22Inputs.c2`；后续语义切口为 `LocalEstimate.rhs_le`，归约另做。仅在此临时目录写入；未编译、未调用 MCP-CI/API、未修改主工作区或 Git。

`stub/` 是最小目标文件，仅导入已发布的 LogVolumeBound 定义包装，包含显式 `by sorry`。AG、TG、X 保持隐式；inv、cert、est、pnt、h312 保持显式。宇宙顺序 u、v、完整 1/6、20 系数、自然数到实数转换及完整结论均保留。`binder-contract.json` 保存来源的八项 BinderInfo。

`context/manifest.json` 冻结传递导入的 28 个目标定义模块及摘要、平台定义编号和外部模块名；登记总定义数为 34。`type-owner-map.json` 保存已通过来源编译器图的 40 个直接 TYPE 常量，其中 17 个为项目常量，其余 23 个为共享 Lean/Mathlib 常量。不要将“28 个上下文定义模块”和“17 个项目类型常量”误记为 28 个直接 TYPE 常量。新查询会报告实际目标计数。

`source/` 保留完整原始命令、原 proof-oracle 查询配置及探针字节，作为出处。旧的有效类型与宇宙查询事实已 pin；完整原证明的公理输出不能当作本次开放节点的证明验收。旧事实没有 encoded TYPE Expr，因此 `queries/QueryTheorem110SourceType.lean` 用现有 4.35 缓存只读取 root TYPE，并不读取 root 证明值或 root 公理闭包。`queries/QueryTheorem110TargetAudit.lean` 在 Lean 4.33.1 中将 TYPE 的具名常量按精确 map 重定位，进行内核类型相等、宇宙顺序、BinderInfo 位置及开放公理审查。目标 TYPE 只准标准公理；目标 stub 的完整公理闭包必须显式报告 sorryAx。两份查询均未编译。

`readbacks/` 逐字冻结 B 组原英文、三语、完整上下文和术语状态；本节点确由 B 审读。现有材料未记录实际运行模型，`actualModel` 留 null，不编造 readback_model。没有新增未知中文译名；TERM-015 是原有待定项，现有正文按范数条件展开描述，没有插入一个未确认的译名。

`paper/context.json` 复用望月新一 IUT IV（April 2020）的原始段落、原文页面证据及定位。引用保留原省略/转写说明；本地数值陈述与论文完整数学身份分开。素数计数证书中 3/2 与论文 4/3 的差异继续明示。原 proof 字节保留不构成本次 open-statement 的四角色完整证明门。

`publication/payload.json` 是私有开放定理创建候选，不含 proof submission。`publication/readback-fields.json` 另列读回字段供主智能体按实际 API 支持绑定。发布前先完成 CI 与模型归属记录核对，上传后精确回读字段、编号和 Open 状态。`ci/handoff.json` 列出顺序和剩余门：当前 iota CI 终态后才可整合；源码 TYPE 提取、目标叶/产物、TYPE/BinderInfo/开放公理审查、项目所需 Checks/Axioms、ImportAudit、Act1Scene1、AxiomAudit 和 git diff --check。叶首次估计固定 60s/16GiB，由主智能体提交 exclusive:true 的准确脏工作区 manifest。

本包不声称 theorem110 证明完成、theorem110→c2 归约完成、规范推论 2.2 已接回、S2-04 关闭或 abc 根目标闭合。
