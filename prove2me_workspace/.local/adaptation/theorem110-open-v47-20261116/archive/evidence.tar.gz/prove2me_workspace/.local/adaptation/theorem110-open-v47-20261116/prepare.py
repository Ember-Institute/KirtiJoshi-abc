from pathlib import Path
import json,hashlib,shutil,re
P=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/theorem110-open-v47-20261116')
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A=W/'.local/adaptation';G=A/'main-chain-open-20261116/tools/generated';R=A/'reference-extraction-20261115'
NAME='Iut_Theorem110Invariants_theorem110';root='Iut.Theorem110Invariants.theorem110';target='AbcAdaptation.Reference.'+root
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(rel,x):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p,rel=None):
 p=Path(p); d={'path':str(p),'sha256':sha(p)}
 if rel:
  out=P/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out);d['frozenCopy']=str(out)
 return d
def name_expr(s):
 n=[]
 for x in s.split('.'):n=[n,'str',x]
 return n
m=json.loads((G/f'metadata/{NAME}.json').read_text()); old=json.loads((R/'Iut-Theorem110Invariants-theorem110-compiler-type.json').read_text())
# Preserve complete original command and probe bytes without treating them as proof acceptance.
source={}
for src,rel in [(G/f'metadata/{NAME}.json','source/SourceMetadata.json'),(G/f'OriginalCommands/{NAME}.lean','source/OriginalCommand.lean'),(G/f'OracleConfigs/{NAME}.json','source/OriginalProofOracleConfig.json'),(G/f'OracleSourceProbes/{NAME}.lean','source/OriginalProofOracleProbe.lean'),(G/f'formal-only/{NAME}.lean','source/FormalOnlySourceStub.lean'),(R/'Iut-Theorem110Invariants-theorem110-compiler-type.json','source/PriorCompilerType.json'),(R/'root-universe-types/theorem110.json','source/PriorRootUniverses.json'),(R/'QueryC22RootUniverses.lean','source/PriorRootQuery.lean'),(R/'LICENSE.iut.Apache-2.0','source/LICENSE.iut.Apache-2.0')]:source[rel]=pin(src,rel)
# Exact target context includes the transitive local Definition files, not theorem proofs.
start='Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound'
queue=[start];seen=set();ctx=[]; external=set()
registry=json.loads((A/'platform-node-registry.json').read_text());published={x['name']:x for x in registry['reference_source_preparation']['definitions']}
while queue:
 mod=queue.pop(0)
 if mod in seen:continue
 seen.add(mod);p=W/(mod.replace('.','/')+'.lean');text=p.read_text();q=pin(p,'context/'+mod.replace('.','/')+'.lean');q['module']=mod;q['publication']=published.get(mod.removeprefix('Definitions.Def_'));ctx.append(q)
 for imp in re.findall(r'^import\s+(\S+)',text,re.M):
  if imp.startswith('Definitions.'):queue.append(imp)
  else:external.add(imp)
write('context/manifest.json',{'schema':'theorem110-exact-context/v45','minimalImport':start,'localDefinitionCount':len(ctx),'definitions':ctx,'externalImportModules':sorted(external),'registry':pin(A/'platform-node-registry.json'),'publishedDefinitionRegistryCount':len(published),'environment':registry['environment'],'note':'Frozen context copies are review inputs; install only the new theorem stub. Existing definitions have private platform publications. No claim of final root graph connection.'})
# Source map uses the accepted actual compiler declaration graph and native named wrappers.
lookup={}
for l in (R/'c22-decl-graph.jsonl').read_text().splitlines():
 x=json.loads(l)
 if x.get('name'):lookup[x['name']]=x
ex={x['name']:x.get('module') for x in old['externalDependencies']}
rows=[]
for n in old['directTypeDeps']:
 owner=lookup.get(n,{}).get('module',ex.get(n));project=n.startswith('Iut.');to='AbcAdaptation.Reference.'+n if project else n
 tm='Definitions.Def_AbcAdaptation_Reference_'+owner.replace('.','_') if project else owner
 row={'source':n,'sourceNameExpr':name_expr(n),'sourceOwner':owner,'target':to,'targetNameExpr':name_expr(to),'targetOwnerExpected':tm,'role':'project-data-or-interface' if project else 'shared-Lean-Mathlib','evidence':'accepted c22-decl-graph.jsonl / PriorCompilerType.directTypeDeps'}
 if project:row['publishedDefinition']=published.get(tm.removeprefix('Definitions.Def_'))
 rows.append(row)
assert sum(x['role']=='project-data-or-interface' for x in rows)==17
write('type-owner-map.json',{'schema':'theorem110-type-owner-map/v45','observedSourceDirectTypeConstants':len(rows),'observedSourceProjectTypeConstants':17,'observedSharedTypeConstants':len(rows)-17,'countPolicy':'40/17 are actual prior compiler directTypeDeps/typeDeps, not a guessed 28/17. Fresh source/target Expr queries must report their actual counts. Compiler representation can differ across 4.35 and 4.33.','sourceEvidence':source['source/PriorCompilerType.json'],'graphEvidence':pin(R/'c22-decl-graph.jsonl'),'rows':rows})
header='''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Open Act1 statement adapted from Iut/Implication/Theorem110.lean at commit
07cb1da58f6d428a670dbb5dd6093d428bcbcdd8. Original proof bytes are preserved in
source/OriginalCommand.lean. This file deliberately contains an open proof. -/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open AbcAdaptation.Reference.Iut
open AbcAdaptation.Reference.Iut.Theorem110Invariants
universe u v

'''
formal='''theorem AbcAdaptation.Reference.Iut.Theorem110Invariants.theorem110
    {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
    {X : Corollary312VariantData.{u, v} AG TG}
    (inv : Theorem110Invariants X)
    (cert : Theorem110Certificate inv) (est : inv.LocalEstimate)
    (pnt : PrimeCountingBound) (h312 : Corollary312Variant X) :
    1 / 6 * X.qPilot.logQ ≤
      (1 + 20 * (X.dmod : ℝ) / X.ℓ) * (inv.logDtpd + inv.logFtpd) +
        20 * ((inv.eStar : ℝ) * X.ℓ + pnt.η) := by
  sorry
'''
stubfile='Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110.lean'
write('stub/'+stubfile,header+formal);write('stub/preamble.lean.txt',header);write('stub/formal_statement.lean.txt',formal.rstrip())
write('binder-contract.json',{'source':root,'target':target,'levelParamsInOrder':['u','v'],'telescope':m['graphCompilerTelescope'],'allowedAdaptation':'Only project namespace, imports, and explicit rendering of inherited inv; preserve all eight BinderInfo positions.','sourceEvidence':source['source/PriorRootUniverses.json'],'numericConclusionPreserved':True,'status':'target-compiler-comparison-pending'})
# Keep source formal readback exact and all provided formal context/dependency pointers.
B=A/'main-chain-open-20261116/independent-readbacks-v9'
for f in ['readback-b-en.json','trilingual-b.json','terminology-b.json','coverage.json']:pin(B/f,'readbacks/'+f)
en=json.loads((B/'readback-b-en.json').read_text());tri=json.loads((B/'trilingual-b.json').read_text());node=next(x for x in tri['nodes'] if x['sourceName']==root)
assert node['originalEnglish']==node['readbacks']['en']==en['readbacks'][root]
assert sha(G/f'formal-only/{NAME}.lean')==node['formalOnly']['sha256']
write('readbacks/selected-node.json',node)
write('readbacks/provenance.json',{'schema':'theorem110-frozen-readback-provenance/v45','actualReader':en['reader'],'actualModel':None,'actualModelEvidence':'Frozen B files do not record runtime model. Do not infer the model from policy or label A as B. Recover runtime/session evidence before assigning readback_model.','frozenEnglish':pin(B/'readback-b-en.json'),'frozenTrilingual':pin(B/'trilingual-b.json'),'englishReadbackSHA256':hashlib.sha256(node['readbacks']['en'].encode()).hexdigest(),'formalOnlyHashVerified':True,'namespaceImportAdaptationRequiresTargetTypeComparison':True,'newIndependentAuditPerformed':False,'terminology':{'newUnknownChineseTerms':[],'existingPending':['TERM-015 uniformizer'],'bodyUsesPendingTranslationPlaceholder':any('【译名待定' in s for s in node['readbacks'].values()),'note':'Existing B record expands the norm conditions and does not insert the unresolved technical noun into this node prose. Existing TERM-015 remains pending in context.'},'formalContextGaps':node['formal_context_gaps']})
# Source authorship/paper context is separate from the frozen blind readback.
pc=A/'reference-main-bound-carriers-20261115/paper-context.json';paper=json.loads(pc.read_text());ids={'IV-invariants','IV-q-normalization','IV-prime-counting'}
selected=[x for x in paper['quotations'] if x['id'] in ids]
write('paper/context.json',{'schema':'theorem110-reused-Mochizuki-context/v45','author':'Shinichi Mochizuki','paper':paper['paper_sources']['IV'],'contextSource':pin(pc),'quotations':selected,'sourceDescription':next(x for x in json.loads((R/'paper-source-descriptions.en.json').read_text()) if x['declaration']==root),'formalRelationship':'This open node is the exact conditional numerical implication of refer/iut. Arithmetic identities, certificate, local estimate, prime-counting bound and Corollary312Variant remain supplied inputs. This statement is not an unconditional realization of the paper theorem. The paper factor 4/3 and source factor 3/2 remain distinct.','quoteReuse':'Exact existing quotations, including omission/transcription notes, copied without introducing a new paper quotation.'})
readback='\n\n'.join('**'+lab+'**\n\n'+node['readbacks'][key] for lab,key in [('English','en'),('简体中文','zh_Hans'),('日本語','ja')])
quote='\n\n'.join(x['locator']+' (printed and PDF file pp. '+','.join(map(str,x['printed_pages']))+')\n\n'+'\n'.join('> '+line for line in x['quote_markdown'].splitlines())+'\n\n'+x['quote_scope'] for x in selected)
nls='**Open conditional statement / 开放的条件陈述 / 未解決の条件付き命題**\n\n'+readback+'\n\n**Mochizuki original paper context**\n\nShinichi Mochizuki, Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations, April 2020.\n\n'+quote+'\n\nThe reference implementation uses the explicit prime-counting certificate with factor 3/2; the paper Proposition 1.6 has 4/3. The numeric theorem, arithmetic certificate, local estimates, and the Corollary 3.12 comparison retain their exact source interfaces. The original proof is preserved locally; no complete-proof audit or platform proof acceptance is asserted.'
write('publication/payload.json',{'theorem_name':target,'theorem_title':'Conditional numerical estimate from the Corollary 3.12 variant — 推论 3.12 变体下的条件数值估计 — 系 3.12 の変種に基づく条件付き数値評価','preamble':header,'formal_statement':formal.rstrip(),'natural_language_statement':nls,'source':'https://github.com/lana-agents/iut/blob/07cb1da58f6d428a670dbb5dd6093d428bcbcdd8/Iut/Implication/Theorem110.lean#L233-L331','env':'0df444a360eaa60ab8c11dca51a86af692955474','private':True})
write('publication/readback-fields.json',{'readback':readback,'readback_model':None,'status':'fill supported fields from actual platform schema; actual B reader model unrecorded, not fabricated','provenance':'readbacks/provenance.json'})
write('SOURCE_LEDGER.json',{'producerSourceName':root,'targetName':target,'status':'open-statement-packet-awaiting-main-integration-and-CI','sourceModule':m['module'],'sourceCommit':'07cb1da58f6d428a670dbb5dd6093d428bcbcdd8','license':'Apache-2.0','actualConsumers':m['actualConsumerEdges'],'nextSemanticCut':{'source':'Iut.Theorem110Invariants.LocalEstimate.rhs_le','edge':'value','status':'subsequent reduction; not implemented here'},'originalSource':source,'proofRangeAndDigest':{'bodyRanges':m['proofAndDefinitionBodyRanges'],'bodyHashes':m['originalBodyHashes'],'oracleByteMaps':m['oracleOriginalBodyByteMaps']},'fidelity':'Complete inherited telescope, four supplied interface inputs, universes, casts and numerical conclusion retained. Exact compiled target comparison pending. Raw proof bytes preserved solely as provenance, not a proof-acceptance gate.','proofValuesInspectedForTypeQueries':False,'platformPublished':False,'rootConnected':False})
print(json.dumps({'localDefinitionCount':len(ctx),'sourceTypeConstants':len(rows),'sourceProjectTypeConstants':17,'stub':str(P/'stub'/stubfile),'readbackReader':en['reader']},ensure_ascii=False))
