import Lean
import Theorems.Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_theorem110

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  -- moduleNames maps the entire module array; use the indexed record directly.
  let imported ← env.header.modules[index.toNat]?
  return imported.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

abbrev TypeNames := Array (Name × Name)

-- Proof bodies are substituted only for explicitly exported, closed Prop
-- constants in the original TYPE. Data constants require an actual named map.
partial def decodeType (names : TypeNames) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := decodeType names proofs visiting expandProofs
  let relocate : Name → Except String Name := fun n => do
    if let some p := names.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`Definitions,`Theorems,`Solutions].any (·.isPrefixOf n) then
      throw s!"Unmapped TYPE project constant: {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    let levels ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName original)) then
      unless levels.isEmpty do throw "Closed source proof unexpectedly has universe arguments"
      if !expandProofs then return .const original levels.toList
      if visiting.contains original then throw s!"Cyclic proof-only resolution: {original}"
      return ← decodeType names proofs (visiting.push original) true (← field p "actualProofExpr")
    return .const (← relocate original) levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"


end FoundationAudit
namespace Theorem110OpenStatementAudit
open Lean Elab Term Meta FoundationAudit
run_meta do
  let cfg ← jsonFile (← absoluteEnv "THEOREM110_TYPE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "theorem110-target-open-statement-audit/v45" do
    throwError "Wrong target audit configuration"
  unless Lean.versionString == (← checked (stringField cfg "expectedCompiler")) do
    throwError "Wrong target compiler: {Lean.versionString}"
  let root ← checked (decodeName (← checked (field cfg "rootNameExpr")))
  let ci ← getConstInfo root
  let source ← jsonFile (← checked (stringField cfg "sourceTypeFacts"))
  unless (← checked (source.getObjValAs? Bool "rootTheoremProofValueRead")) == false do
    throwError "Source facts must be TYPE only"
  let nameMap ← (← checked (arrayField cfg "nameMap")).mapM fun row => do
    let n ← checked (decodeName (← checked (field row "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field row "targetNameExpr")))
    return (n,t)
  let imported ← checked (decodeType nameMap #[] #[] false (← checked (field source "typeExpr")))
  kernelTypeEq "source TYPE mapped to exact target TYPE" imported ci.type
  unless binderPlacement imported == binderPlacement ci.type do
    throwError "Source/target BinderInfo placement differs"
  unless binderInventory imported == binderInventory ci.type do
    throwError "Source/target BinderInfo inventory differs"
  let sourceLevels ← checked (arrayField source "levelParams")
  unless sourceLevels == ci.levelParams.toArray.map encodeName do
    throwError "Source/target universe parameter order differs"
  let tel ← telescopeJson ci.type
  let bs ← checked (arrayField tel "binders")
  let names ← bs.mapM fun b => checked (stringField b "name")
  let bis ← bs.mapM fun b => checked (stringField b "binderInfo")
  unless names == (← checked (cfg.getObjValAs? (Array String) "expectedBinderNames")) do
    throwError "Target telescope names differ"
  unless bis == (← checked (cfg.getObjValAs? (Array String) "expectedBinderInfo")) do
    throwError "Target telescope binding modes differ"
  let env ← getEnv
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let taxs ← expressionAxioms cache ci.type
  ensureStandard "target TYPE" taxs
  -- Audit the admitted statement closure explicitly. No source proof is imported.
  let axs ← collectAxioms root
  for ax in axs do
    unless standardAxioms.contains ax || ax == `sorryAx do
      throwError "Unexpected target open-statement axiom {ax}"
  unless axs.contains `sorryAx do throwError "Expected explicitly open theorem stub"
  let constants := ci.type.getUsedConstants.qsort Name.lt
  let owners ← constants.mapM fun n => do
    if (`Iut).isPrefixOf n then throwError "Original project TYPE constant leaked: {n}"
    return Json.mkObj [("name",toJson n.toString),("nameExpr",encodeName n),
      ("owner",(moduleOf env n).map (toJson ·.toString) |>.getD Json.null)]
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "theorem110-target-open-statement-audit-facts/v45"),
    ("configuration",cfg),("compilerVersion",toJson Lean.versionString),
    ("name",toJson root.toString),("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("typeExpr",← checked (encodeExpr ci.type)),("typeDisplay",toJson (← ppExpr ci.type).pretty),
    ("telescope",tel),("binderInventory",toJson (binderInventory ci.type)),
    ("binderPlacement",toJson (binderPlacement ci.type)),
    ("kernelMappedSourceTypeEqual",toJson true),
    ("binderInfoPlacementEqual",toJson true),("levelParamsOrderEqual",toJson true),
    ("typeConstantCount",toJson constants.size),
    ("projectTypeConstantCount",toJson (constants.filter fun n => (`AbcAdaptation).isPrefixOf n).size),
    ("typeConstantOwners",Json.arr owners),
    ("typeAxioms",toJson (taxs.map Name.toString)),
    ("openStatementAxioms",toJson ((axs.qsort Name.lt).map Name.toString)),
    ("hasSorryAx",toJson (axs.contains `sorryAx)),
    ("status",toJson "exact open statement; proof remains open; no completed proof acceptance")]).pretty ++ "\n")
  logInfo "Theorem110 exact TYPE/BinderInfo/open-axiom audit passed; proof remains open"
end Theorem110OpenStatementAudit
