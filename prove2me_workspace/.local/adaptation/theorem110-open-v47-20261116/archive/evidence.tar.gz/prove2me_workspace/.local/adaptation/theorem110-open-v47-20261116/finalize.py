from pathlib import Path
import json,hashlib
P=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/theorem110-open-v47-20261116'); W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';R=A/'reference-extraction-20261115'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(rel,x):
 p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2)+'\n')
for f in ['queries/QueryTheorem110SourceType.lean','queries/QueryTheorem110TargetAudit.lean']:
 p=P/f;s=p.read_text().replace('(constants.filter (`Iut).isPrefixOf).size','(constants.filter fun n => (`Iut).isPrefixOf n).size').replace('(constants.filter (`AbcAdaptation).isPrefixOf).size','(constants.filter fun n => (`AbcAdaptation).isPrefixOf n).size');p.write_text(s)
# Prior valid extraction: pin evidence without turning its full-source axiom result into this open node's proof acceptance.
prior=[]
for name in ['c22-graph-result.json','c22-graph-request.json','c22-graph-source-receipt.json','source-build-plan.json','QueryC22RootUniverses.lean']:
 p=R/name;prior.append({'path':str(p),'sha256':sha(p)})
mod=next(x for x in json.loads((R/'source-build-plan.json').read_text())['modules'] if x['module']=='Iut.Implication.Theorem110') if isinstance(json.loads((R/'source-build-plan.json').read_text()),dict) and 'modules' in json.loads((R/'source-build-plan.json').read_text()) else None
write('source/prior-type-evidence.json',{'status':'valid-existing-source-compiler-type-and-universe-telescope-pinned','acceptedSourceGraphJob':'ci-012771-ee109b3e','compilerVersion':'4.35.0-rc3','directTypeConstants':40,'projectTypeConstants':17,'priorFacts':'source/PriorCompilerType.json and source/PriorRootUniverses.json','proofAcceptanceClaim':False,'typeExprAvailableInPinnedPriorFacts':False,'freshQueryReason':'Need encoded exact TYPE Expr for mapped kernel comparison in platform Lean4.33.1; existing prior facts retain pretty type and exact telescope but no encoded TYPE Expr.','evidence':prior,'sourceBuildModule':mod})
ctx=json.loads((P/'context/manifest.json').read_text());ledger=json.loads((P/'SOURCE_LEDGER.json').read_text());pub=json.loads((P/'publication/payload.json').read_text());node=json.loads((P/'readbacks/selected-node.json').read_text());manifest=json.loads((P/'type-owner-map.json').read_text())
formal=(P/'stub/formal_statement.lean.txt').read_text();preamble=(P/'stub/preamble.lean.txt').read_text();stub=next((P/'stub').glob('Thm_*.lean'))
assert stub.read_text()==preamble+formal+'\n'
assert pub['preamble']==preamble and pub['formal_statement']==formal
assert len(manifest['rows'])==40 and len([x for x in manifest['rows'] if x['source'].startswith('Iut.')])==17
assert all(x['targetOwnerExpected'] in {r['module'] for r in ctx['definitions']} for x in manifest['rows'] if x['source'].startswith('Iut.'))
assert all(sha(x['path'])==x['sha256']==sha(x['frozenCopy']) for x in ctx['definitions'])
assert hashlib.sha256(node['originalEnglish'].encode()).hexdigest()==node['english_readback_utf8_sha256']
assert node['originalEnglish']==node['readbacks']['en']
assert 'cert : Theorem110Certificate inv' in formal and 'est : inv.LocalEstimate' in formal and 'pnt : PrimeCountingBound' in formal and 'h312 : Corollary312Variant X' in formal
assert 'sorry' in formal and not any(x in formal for x in ['axiom ', 'by exact '])
checks={'schema':'theorem110-packet-static-check/v45','allJSONParsed':True,'stubEqualsPayloadPreamblePlusFormal':True,'sourceTypeCount':40,'projectTypeCount':17,'sourceAndFrozenContextHashMatch':True,'allProjectTypeOwnersInExactTargetDefinitionContext':True,'localDefinitionContextCount':len(ctx['definitions']),'registeredPublishedDefinitionCount':ctx['publishedDefinitionRegistryCount'],'englishFrozenHashVerified':True,'readbackActualReader':'independent English reader B','actualReadbackModelKnown':False,'formalOnlyStubHashVerified':True,'targetLeanCompiled':False,'McpCiCalled':False,'APIcalled':False,'mainWorkspaceWritten':False,'newUnknownChineseTerms':[],'existingPendingChineseTerms':['TERM-015 uniformizer'],'existingPendingTermInsertedInNodeProse':False,'proofStatus':'open','proofFourRoleAuditRequiredForThisPacket':False}
write('static-check.json',checks)
write('README.zh.md',f'''本包准备 `AbcAdaptation.Reference.Iut.Theorem110Invariants.theorem110` 的精确开放陈述。父消费者为 `Iut.Corollary22Inputs.c2`；后续语义切口为 `LocalEstimate.rhs_le`，归约另做。仅在此临时目录写入；未编译、未调用 MCP-CI/API、未修改主工作区或 Git。

`stub/` 是最小目标文件，仅导入已发布的 LogVolumeBound 定义包装，包含显式 `by sorry`。AG、TG、X 保持隐式；inv、cert、est、pnt、h312 保持显式。宇宙顺序 u、v、完整 1/6、20 系数、自然数到实数转换及完整结论均保留。`binder-contract.json` 保存来源的八项 BinderInfo。

`context/manifest.json` 冻结传递导入的 {len(ctx['definitions'])} 个目标定义模块及摘要、平台定义编号和外部模块名；登记总定义数为 {ctx['publishedDefinitionRegistryCount']}。`type-owner-map.json` 保存已通过来源编译器图的 40 个直接 TYPE 常量，其中 17 个为项目常量，其余 23 个为共享 Lean/Mathlib 常量。不要将“28 个上下文定义模块”和“17 个项目类型常量”误记为 28 个直接 TYPE 常量。新查询会报告实际目标计数。

`source/` 保留完整原始命令、原 proof-oracle 查询配置及探针字节，作为出处。旧的有效类型与宇宙查询事实已 pin；完整原证明的公理输出不能当作本次开放节点的证明验收。旧事实没有 encoded TYPE Expr，因此 `queries/QueryTheorem110SourceType.lean` 用现有 4.35 缓存只读取 root TYPE，并不读取 root 证明值或 root 公理闭包。`queries/QueryTheorem110TargetAudit.lean` 在 Lean 4.33.1 中将 TYPE 的具名常量按精确 map 重定位，进行内核类型相等、宇宙顺序、BinderInfo 位置及开放公理审查。目标 TYPE 只准标准公理；目标 stub 的完整公理闭包必须显式报告 sorryAx。两份查询均未编译。

`readbacks/` 逐字冻结 B 组原英文、三语、完整上下文和术语状态；本节点确由 B 审读。现有材料未记录实际运行模型，`actualModel` 留 null，不编造 readback_model。没有新增未知中文译名；TERM-015 是原有待定项，现有正文按范数条件展开描述，没有插入一个未确认的译名。

`paper/context.json` 复用望月新一 IUT IV（April 2020）的原始段落、原文页面证据及定位。引用保留原省略/转写说明；本地数值陈述与论文完整数学身份分开。素数计数证书中 3/2 与论文 4/3 的差异继续明示。原 proof 字节保留不构成本次 open-statement 的四角色完整证明门。

`publication/payload.json` 是私有开放定理创建候选，不含 proof submission。`publication/readback-fields.json` 另列读回字段供主智能体按实际 API 支持绑定。发布前先完成 CI 与模型归属记录核对，上传后精确回读字段、编号和 Open 状态。`ci/handoff.json` 列出顺序和剩余门：当前 iota CI 终态后才可整合；源码 TYPE 提取、目标叶/产物、TYPE/BinderInfo/开放公理审查、项目所需 Checks/Axioms、ImportAudit、Act1Scene1、AxiomAudit 和 git diff --check。叶首次估计固定 60s/16GiB，由主智能体提交 exclusive:true 的准确脏工作区 manifest。

本包不声称 theorem110 证明完成、theorem110→c2 归约完成、规范推论 2.2 已接回、S2-04 关闭或 abc 根目标闭合。
''')
files=[]
for p in sorted(P.rglob('*')):
 if p.is_file() and p.name!='artifact-manifest.json':files.append({'path':str(p.relative_to(P)),'sha256':sha(p),'bytes':p.stat().st_size})
write('artifact-manifest.json',{'schema':'theorem110-open-statement-packet-manifest/v45','packetRoot':str(P),'files':files,'fileCount':len(files),'mainWorkspaceTouched':False,'compiled':False,'published':False})
print(json.dumps({'stubSHA256':sha(stub),'payloadSHA256':sha(P/'publication/payload.json'),'manifestSHA256':sha(P/'artifact-manifest.json'),'fileCount':len(files),'staticChecks':checks},ensure_ascii=False))
