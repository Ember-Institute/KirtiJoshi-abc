# Formal-to-read-back alignment

Model: `gpt-6.1-sol`. Read-back scope: only the two specified canonical Lean declarations, necessary imported definitions, and the two read-back rule documents. The English original was frozen before writing the translations. The Chinese and Japanese texts are translations of that original, not additional independent audits.

| Declaration | Formal item | English | 简体中文 | 日本語 |
| --- | --- | --- | --- | --- |
| `torsionCoords_finite` | `{l : Qbar}` | Every λ in the algebraic closure of ℚ; implicit universal parameter. | 代数闭包中的任意 λ，隐式全称参数。 | 代数閉包の任意の λ、暗黙の全称パラメータ。 |
| `torsionCoords_finite` | `{n : ℕ}` | Every natural number n, including 0; implicit universal parameter. | 任意自然数 n，包括 0，隐式全称参数。 | 0 を含む任意の自然数 n、暗黙の全称パラメータ。 |
| `torsionCoords_finite` | `(h : TorsionFinite l n)` | Assumes finiteness of `{P : Gλ | nP = O}`. | 假设满足 nP=O 的点集有限。 | nP=O を満たす点の集合が有限であると仮定する。 |
| `torsionCoords_finite` | `(torsionCoords l n).Finite` | Finite union of coordinates contributed by torsion points: O contributes ∅ and an affine point contributes {x,y}. | 扭点坐标的并为有限集；O 贡献空集，仿射点贡献 {x,y}。 | 捩れ点の座標の和集合が有限。O は空集合、アフィン点は {x,y} を寄与する。 |
| `torsionCoords_finite` | No `n ≠ 0` | n=0 is within the quantifier; then the assumption is finiteness of all of Gλ. | n=0 在量词范围内；此时假设要求整个 Gλ 有限。 | n=0 も量化範囲に含み、その場合の仮定は Gλ 全体の有限性。 |
| `finiteDimensional_fieldOf'` | `{l : Qbar}` | Every λ in the algebraic closure of ℚ; implicit universal parameter. | 代数闭包中的任意 λ，隐式全称参数。 | 代数閉包の任意の λ、暗黙の全称パラメータ。 |
| `finiteDimensional_fieldOf'` | `(h3 : TorsionFinite l 3)` | Separate first hypothesis: `{P : Gλ | 3P = O}` is finite. | 第一个独立前提：三倍为 O 的点集有限。 | 第一の独立した仮定：3P=O の点の集合が有限。 |
| `finiteDimensional_fieldOf'` | `(h5 : TorsionFinite l 5)` | Separate second hypothesis: `{P : Gλ | 5P = O}` is finite. | 第二个独立前提：五倍为 O 的点集有限。 | 第二の独立した仮定：5P=O の点の集合が有限。 |
| `finiteDimensional_fieldOf'` | `FiniteDimensional ℚ (fieldOf' l)` | Under h3 and h5, the defined intermediate field has finite dimension over ℚ. No dimension value or separately selected number-field instance is supplied. | 在 h3、h5 下，已定义中间域在 ℚ 上有限维；未给出维数或另选的数域实例。 | h3 と h5 の下で、定義済みの中間体が ℚ 上有限次元。次元や別途選定した数体インスタンスは与えない。 |
| `finiteDimensional_fieldOf'` | No `{n : ℕ}` binder | Torsion orders are fixed at 3 and 5; no n=0 case. | 扭点阶数固定为 3、5，无 n=0 情形。 | 捩れの次数は 3 と 5 に固定され、n=0 の場合はない。 |
| Both | No `l ≠ 0`, no `l ≠ 1` | λ=0 and λ=1 are allowed parameters; the relevant finiteness assumptions remain. | λ=0、1 均允许，相应有限性前提仍须保留。 | λ=0、1 ともに許され、対応する有限性の仮定を保持する。 |
| Both | Imported `Affine.Point` | The point type contains O and nonsingular affine points, including when the curve parameter is degenerate. | 即使参数退化，点类型也只包括 O 和非奇异仿射点。 | パラメータが退化する場合も、点の型は O と非特異アフィン点からなる。 |

# Expanded definitions

`Qbar` is `AlgebraicClosure ℚ`. The Legendre Weierstrass coefficients are `(0, -(1+l), 0, l, 0)`, giving the equation $y^2=x(x-1)(x-\lambda)$. The relevant point type is Mathlib's `WeierstrassCurve.Affine.Point`, whose constructors are the point at infinity and affine coordinates with a proof of nonsingularity. No global ellipticity hypothesis is added.

`TorsionFinite λ m` means that the set of points killed by multiplication by the natural number m is finite. `torsionCoords λ m` is a subset of the algebraic closure, formed by taking the union of the coordinate sets of these points. It is not a set of ordered coordinate pairs.

`fieldOf' λ` is the intermediate-field adjunction over ℚ of λ, the fixed selected square root of −1, the fixed selected square root of λ, the fixed selected square root of 1−λ, all the coordinate entries of the 3-torsion points, and all the coordinate entries of the 5-torsion points. The roots are choices made in the definitions; the theorem does not quantify universally over arbitrary replacement choices of roots. Adjunction means the smallest intermediate field containing these generators, not their linear span alone.

# Logical boundary

Both conclusions are implications from their displayed hypotheses. Neither statement asserts unconditionally that its torsion finiteness hypotheses hold. There is no existentially quantified parameter or field in either conclusion. The second statement concerns finite dimensionality of the already defined intermediate field; it does not expose a chosen basis, a numerical extension degree, or a new declaration of a number-field instance.

No compilation, MCP-CI job, API call, Git command, or workspace modification was performed for this read-back. All created files are within the requested temporary output directory. English statements and translations are semantic read-backs, not compilation or axiom-audit receipts.
