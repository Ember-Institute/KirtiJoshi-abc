译文依据：冻结英文原始读回 `readback.en.raw.md`，SHA-256 为 `7da001dc378ea51a6edad58fafefeaea617162f0672fa972c5059bfa97ebe8cf`。本文件是该读回的简体中文译文，不是另一份独立盲审。

# torsionCoords_finite

对有理数域 $\mathbb Q$ 的代数闭包 $\overline{\mathbb Q}$ 中的任意元素 $\lambda$ 和任意自然数 $n$（包括 $0$），令 $G_\lambda$ 为由无穷远点 $O$ 及 Weierstrass 曲线 $y^2=x(x-1)(x-\lambda)$ 在 $\overline{\mathbb Q}$ 上的非奇异仿射点 $(x,y)$ 组成的群。令 $T_{\lambda,n}=\{P\in G_\lambda\mid nP=O\}$，其中 $nP$ 表示群中自然数 $n$ 对点的倍乘。假设 $T_{\lambda,n}$ 是有限集；这就是声明中名为 `TorsionFinite` 的假设。给 $O$ 配以空坐标集，给每个仿射点 $(x,y)$ 配以坐标集 $\{x,y\}$。那么，对所有 $P\in T_{\lambda,n}$ 取这些坐标集的并所得的集合，即名为 `torsionCoords` 的集合，是 $\overline{\mathbb Q}$ 的有限子集。这里没有 $\lambda\ne0$ 或 $\lambda\ne1$ 的限制：这些参数值也在范围内，此时点群仍只采用非奇异仿射点和无穷远点。这里也没有 $n\ne0$ 的假设；当 $n=0$ 时，$T_{\lambda,0}=G_\lambda$，所以仍须满足的有限性假设要求整个点群为有限集。此断言以该假设为前提，本身并未断言该假设成立。

# finiteDimensional_fieldOf'

对有理数域 $\mathbb Q$ 的代数闭包 $\overline{\mathbb Q}$ 中的任意元素 $\lambda$，令 $G_\lambda$ 为由无穷远点 $O$ 及 Weierstrass 曲线 $y^2=x(x-1)(x-\lambda)$ 在 $\overline{\mathbb Q}$ 上的非奇异仿射点 $(x,y)$ 组成的群。对自然数 $m$，记 $T_{\lambda,m}=\{P\in G_\lambda\mid mP=O\}$，并令 $C_{\lambda,m}$ 为所有 $(x,y)\in T_{\lambda,m}$ 的仿射坐标集 $\{x,y\}$ 的并，其中 $O$ 贡献空集。分别假设 $T_{\lambda,3}$ 为有限集（假设 $h_3$）且 $T_{\lambda,5}$ 为有限集（假设 $h_5$）；这正是在 $3$ 和 $5$ 处的 `TorsionFinite`。固定各定义所采用的已选元素 $i_0,s_\lambda,t_\lambda\in\overline{\mathbb Q}$，它们满足 $i_0^2=-1$、$s_\lambda^2=\lambda$ 和 $t_\lambda^2=1-\lambda$。令 $F_\lambda$ 为由集合 $\{\lambda,i_0,s_\lambda,t_\lambda\}\cup C_{\lambda,3}\cup C_{\lambda,5}$ 生成的 $\overline{\mathbb Q}/\mathbb Q$ 的中间域，即 $\overline{\mathbb Q}$ 中包含 $\mathbb Q$ 的像及该集合中每个元素的最小子域；这就是定义为 `fieldOf'` 的域。那么，$F_\lambda$ 作为 $\mathbb Q$ 上的向量空间是有限维的。参数值 $\lambda=0$ 和 $\lambda=1$ 均未被排除，对这些值也仍须满足两个有限性假设。该声明没有可变扭点阶数 $n$，也没有 $n=0$ 的情形：其中的扭点阶数固定为 $3$ 和 $5$。它在这两个假设下断言这个已定义中间域的有限维性；它没有断言这些假设成立，没有给出维数，也没有构造一个另外选定的数域实例。
