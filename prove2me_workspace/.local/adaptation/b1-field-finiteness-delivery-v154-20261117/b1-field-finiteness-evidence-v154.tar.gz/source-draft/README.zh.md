先取 torsionCoords_finite/canonical 与 solution 两片：唯一公开原定理／全局solution，直接import已验收纯FieldsData，完整原proof，参数仍{l}{n}(h:TorsionFinite l n)。source-root-full-actual-fact.json已含实际TYPE和完整原proof，valueRead及kernelTYPE检查均true，universe参数为空；不需另开source proof导出。

下一片 finiteDimensional_fieldOfPrime（文件label）公开定理原名 finiteDimensional_fieldOf'。它直接import首定理，完整保持隐式l及显式h3:TorsionFinite l 3、h5:TorsionFinite l 5，不假设任意有限维证书。首定理须先验收，第二片不能提前伪称所有边界已通过。

canonical数学command bytes与acceptedAST逐字相同；Sol只改AST rootdeclId为全局solution。stub仅供平台formalize，sorry不得当完整proof验收。source-provenance.json记录AST spans、sourceactual/输出pins；每片actual-dependencies.json记录精确项目map与真实consumer边，首片无pending，次片仅前一公开定理pending。没有把证明藏纯Definition，没有新dummyproof／数学假设。

后续顺序及原anonymous实例精确actual源名见dependency-order.json与next-source-exact-dependency-facts.jsonl：membership原theorem先行，gen'原纯subtype定义后行；有限维/h3h5用于数域组装，两个原instance proof另行审核，再构造完整curveOf。没有凭名称猜recursor。

只/tmp草稿，未编译/CI/API/Git/主区写。root首次叶按60s/16GiB独占MCP-CI；nativeactual与source完整proof对应、各角色TYPE/axioms、检查聚合及平台验收仍待root。
