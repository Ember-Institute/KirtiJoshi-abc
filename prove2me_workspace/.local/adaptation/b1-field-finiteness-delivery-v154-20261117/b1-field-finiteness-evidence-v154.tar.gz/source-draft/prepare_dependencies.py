import pathlib,json,hashlib
W=pathlib.Path('/home/admin-wsl/Coq/abc/prove2me_workspace');D=pathlib.Path('/tmp/p2m-b1-curveof-field-properties-v148-20261117')
def nm(n):return '' if n==[] else (nm(n[0])+'.' if n[0] else '')+str(n[2])
def name(s):
 n=[]
 for t in s.split('.'):n=[n,'str',t]
 return n
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
C=pathlib.Path('/tmp/p2m-b1-curveof-fields-correspondence-v144-20261117/thirteen-review.bound.config.json');j=json.loads(C.read_text());existing={nm(x['sourceNameExpr']):{'sourceNameExpr':x['sourceNameExpr'],'targetNameExpr':x['targetNameExpr'],'targetOwnerNameExpr':x['targetOwnerNameExpr'],'acceptedReviewJob':'ci-018685','evidence':'source13 full actual correspondence accepted; root reported ci018685'} for x in j['pairs']}
for x in j['acceptedBoundaryPairs']:existing[nm(x['sourceNameExpr'])]=x
B=pathlib.Path('/tmp/p2m-b1-curveof-draft-v118-20261117/basic55-reuse-actualNamedMap.json');bj=json.loads(B.read_text());x=next(x for x in bj['namedPairs'] if x['sourceName']=='Iut.Tripod.isIntegral');existing[x['sourceName']]={'sourceNameExpr':x['sourceNameExpr'],'targetNameExpr':x['targetNameExpr'],'targetOwnerNameExpr':name(x['targetOwner']),'acceptedReviewJob':x['acceptedReviewJob']}
E=W/'.local/adaptation/b1-source-replay-v104-20261117/actual/closure-v111/actual-edges.jsonl';edges=[json.loads(l) for l in E.open()];allrows=[]
for label in ['torsionCoords_finite','finiteDimensional_fieldOfPrime']:
 O=D/label;f=json.loads((O/'source-root-full-actual-fact.json').read_text());deps=sorted({nm(n) for key in ['directTypeConstants','directValueConstants'] for n in f[key] if nm(n).startswith(('Iut.','Genl.','TateCurvesTheta.','_private.'))});pairs=[];pending=[]
 for n in deps:
  if n in existing:pairs.append({'source':n,**existing[n]})
  elif n=='Iut.Tripod.torsionCoords_finite':pending.append({'source':n,'sourceNameExpr':name(n),'targetNameExprCandidate':name('AbcAdaptation.Tripod.torsionCoords_finite'),'targetOwnerCandidate':'Theorems.Thm_AbcAdaptation_Tripod_torsionCoords_finite','state':'prior theorem in this delivery must be accepted first; no assumed proof'})
  else:raise AssertionError(n)
 consumer=[x for x in edges if nm(x['to'])==f['name']];out={'schema':'B1-field-property-actual-dependencies/v148','root':f['name'],'projectDependencies':deps,'acceptedBoundaryPairs':pairs,'pendingPreviousTheorem':pending,'actualRootConsumers':consumer,'sourceRootFullProofAvailable':True,'newSourceQueryRequired':False,'telescope':f['telescope']};(O/'actual-dependencies.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');allrows.append({'label':label,'projectDeps':deps,'pending':pending})
(D/'dependency-order.json').write_text(json.dumps({'schema':'B1-field-properties-order/v148','theorems':allrows,'nextOrder':[{'step':1,'name':'mem_fieldOf\'_self','kind':'independent source theorem; complete proof already exported'},{'step':2,'name':'gen\'','kind':'pure original definition using accepted mem_fieldOf\'_self; no NumberField instance required just to form subtype'},{'step':3,'name':'finiteDimensional_fieldOf\'','kind':'this delivery second theorem; h3/h5 required for actual NumberField assembly'},{'step':4,'name':'original anonymous IsTorsionFree / IsAlgClosure instances','kind':'proof-bearing instance declarations; exact actual source names saved; separate audited theorem/instance support before curveOf'},{'step':5,'name':'curveOf','kind':'full original nine-field carrier record; no provider existence assertion'}],'boundaryMapPins':[pin(C),pin(B)]},ensure_ascii=False,indent=2)+'\n');print(allrows)
