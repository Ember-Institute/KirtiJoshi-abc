import pathlib,json,hashlib
W=pathlib.Path('/home/admin-wsl/Coq/abc/prove2me_workspace');D=pathlib.Path('/tmp/p2m-b1-curveof-field-properties-v148-20261117');P=W/'.local/adaptation/b1-source-parser-v93-20261117/parser-output/Iut-Tripod-CurveOf.jsonl';B=P.with_suffix('.normalized.lean').read_bytes();AST={}
for l in P.open():
 x=json.loads(l)
 if x.get('commandSyntax'):AST[x['commandIndex']]=x
F=W/'.local/adaptation/b1-source-replay-v104-20261117/actual/closure-v111/actual-facts.jsonl';facts={}
for l in F.open():
 x=json.loads(l)
 if x.get('name'):facts[x['name']]=x
M=W/'.local/adaptation/b1-source-replay-v104-20261117/compat-v105/source-replay-spans-map.json';AM={x['originalCommandIndex']:x for x in json.loads(M.read_text())['commands'] if x['sourceModule']=='Iut.Tripod.CurveOf'};A=F.parent.parent.parent/'source-project/B1SourceReplay.lean';AB=A.read_bytes()
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def nodes(n):
 yield n
 for c in n.get('children',[]):yield from nodes(c)
notice='''/-
Adaptation provenance: original accepted Iut source AST command spans.
Original repository: https://github.com/lana-agents/iut
Original commit: 07cb1da58f6d428a670dbb5dd6093d428bcbcdd8
Original source: Iut/Tripod/CurveOf.lean
-/
/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
'''
head='import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData\n';ctx='\nnamespace AbcAdaptation.Tripod\nopen WeierstrassCurve NumberField\nopen scoped IntermediateField\n\n';records=[]
for idx,short,label in [(19,'torsionCoords_finite','torsionCoords_finite'),(30,"finiteDimensional_fieldOf'",'finiteDimensional_fieldOfPrime')]:
 c=AST[idx];r=c['range'];a,z=r['start']['offset'],r['end']['offset'];raw=B[a:z];ac=AM[idx];er=ac['effectiveReplayRange'];assert hashlib.sha256(raw).hexdigest()==ac['originalSHA256'];assert hashlib.sha256(AB[er['start']['offset']:er['end']['offset']]).hexdigest()==ac['effectiveSHA256']
 out=D/label
 for sub in ['canonical','solution','stub']:(out/sub).mkdir(parents=True,exist_ok=True)
 base='AbcAdaptation_Tripod_'+label;imports=head+('import Theorems.Thm_AbcAdaptation_Tripod_torsionCoords_finite\n' if idx==30 else '')
 canonical=notice+imports+ctx+raw.decode()+'\n\nend AbcAdaptation.Tripod\n';cp=out/'canonical'/('Thm_'+base+'.lean');cp.write_text(canonical)
 ident=next(n for n in nodes(c['commandSyntax']) if n.get('identifier')==short);rr=ident['range'];i,j=rr['start']['offset']-a,rr['end']['offset']-a;solraw=raw[:i]+b'solution'+raw[j:];solution=notice+imports+'\nopen AbcAdaptation.Tripod\nopen WeierstrassCurve NumberField\nopen scoped IntermediateField\n\n'+solraw.decode()+'\n';sp=out/'solution'/('Sol_'+base+'.lean');sp.write_text(solution)
 assign=next(n for n in nodes(c['commandSyntax']) if n.get('atom')==':=');endSig=assign['range']['start']['offset']-a;stub=notice+imports+ctx+raw[:endSig].decode()+':= by\n  sorry\n\nend AbcAdaptation.Tripod\n';tp=out/'stub'/('Thm_'+base+'.lean');tp.write_text(stub)
 fact=facts['Iut.Tripod.'+short];assert fact['record']=='fullActualFact' and fact['valueRead'] and fact['kernelValueTypeMatchesActualTYPE'];(out/'source-root-full-actual-fact.json').write_text(json.dumps(fact,ensure_ascii=False,indent=2)+'\n')
 records.append({'sourceName':fact['name'],'sourceNameExpr':fact['nameExpr'],'sourceOwner':fact['owner'],'sourceOwnerNameExpr':fact['ownerNameExpr'],'sourceLevelParams':fact['levelParams'],'sourceBinderInventory':fact['binderInventory'],'sourceASTRange':r,'sourceCommandIndex':idx,'sourceCommandSHA256':hashlib.sha256(raw).hexdigest(),'acceptedReplayHashMatches':True,'sourceOriginalStatementAndProofBytesRetainedInCanonical':True,'solutionOnlyDeclIdReplacement':{'source':short,'target':'solution','startWithinCommand':i,'endWithinCommand':j},'sourceFullActualValueAlreadyRead':True,'sourceKernelValueTypeCheckAlreadyPassed':True,'newSource4_35QueryRequiredForRoot':False,'outputs':[pin(p) for p in [cp,sp,tp]]})
(D/'source-provenance.json').write_text(json.dumps({'schema':'B1-field-properties-source-provenance/v148','inputs':[pin(p) for p in [P,P.with_suffix('.normalized.lean'),F,M,A,W/'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData.lean']],'theorems':records,'conditionsPreserved':'torsionCoords_finite keeps implicit l,n and explicit h:TorsionFinite l n; finiteDimensional keeps implicit l and explicit h3:TorsionFinite l 3,h5:TorsionFinite l 5.','sourceProofDummyUsed':False},ensure_ascii=False,indent=2)+'\n')
# Exact real source declarations for the next ordering decisions; no guessed recursor.
names=["Iut.Tripod.mem_fieldOf'_self","Iut.Tripod.gen'",'Iut.Tripod.instIsTorsionFreeSubtypeQbarMemIntermediateFieldRat_b1SourceReplay','Iut.Tripod.instIsAlgClosureSubtypeQbarMemIntermediateFieldRat_b1SourceReplay']
with (D/'next-source-exact-dependency-facts.jsonl').open('w') as o:
 for n in names:o.write(json.dumps(facts[n],ensure_ascii=False,separators=(',',':'))+'\n')
print({'directory':str(D),'canonicalTheorems':2,'firstCanonicalBytes':records[0]['outputs'][0]['bytes'],'firstSolutionBytes':records[0]['outputs'][1]['bytes'],'sourceFullRootProofsAlreadyAvailable':True})
