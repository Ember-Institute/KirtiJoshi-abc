import pathlib,json,hashlib
D=pathlib.Path('/tmp/p2m-b1-field-finiteness-ascii-v154-20261117');Old=pathlib.Path('/tmp/p2m-b1-curveof-field-properties-v148-20261117/finiteDimensional_fieldOfPrime');W=pathlib.Path('/home/admin-wsl/Coq/abc/prove2me_workspace');P=W/'.local/adaptation/b1-source-parser-v93-20261117/parser-output/Iut-Tripod-CurveOf.jsonl';B=P.with_suffix('.normalized.lean').read_bytes()
def walk(x):
 yield x
 for c in x.get('children',[]):yield from walk(c)
C=next(x for l in P.open() if (x:=json.loads(l)).get('commandIndex')==30 and x.get('commandSyntax'));r=C['range'];a,z=r['start']['offset'],r['end']['offset'];raw=B[a:z];decl=next(q for q in walk(C['commandSyntax']) if q.get('syntaxKind')=='Lean.Parser.Command.declId');ident=next(q for q in walk(decl) if 'identifier'in q);rr=ident['range'];i,j=rr['start']['offset']-a,rr['end']['offset']-a;assert raw[i:j]==b"finiteDimensional_fieldOf'";target='finiteDimensional_fieldOfExtended';newraw=raw[:i]+target.encode()+raw[j:];base='AbcAdaptation_Tripod_'+target
for folder,prefix in [('canonical','Thm_'),('solution','Sol_'),('stub','Thm_')]:
 O=D/folder;O.mkdir(exist_ok=True);src=next((Old/folder).iterdir()).read_bytes()
 if folder=='canonical':assert raw in src;out=src.replace(raw,newraw,1)
 elif folder=='solution':out=src
 else:
  old=b"theorem finiteDimensional_fieldOf' ";new=b'theorem finiteDimensional_fieldOfExtended ';assert src.count(old)==1;out=src.replace(old,new,1)
 (O/(prefix+base+'.lean')).write_bytes(out)
(D/'source-root-full-actual-fact.json').write_bytes((Old/'source-root-full-actual-fact.json').read_bytes())
(D/'actual-dependencies.json').write_bytes((Old/'actual-dependencies.json').read_bytes())
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
M={'schema':'B1-field-finiteness-ASCII-root-rename/v154','sourceName':"Iut.Tripod.finiteDimensional_fieldOf'",'targetCanonicalName':'AbcAdaptation.Tripod.'+target,'targetCanonicalOwner':'Theorems.Thm_'+base,'targetSolutionRoot':'solution','targetSolutionOwner':'Solutions.Sol_'+base,'acceptedSourceAST':pin(P),'sourceASTCommandRange':r,'rootDeclIdASTRange':rr,'rootDeclIdWithinSourceCommand':{'start':i,'end':j},'canonicalEdit':{'old':"finiteDimensional_fieldOf'",'new':target},'sourceMathematicalProofBodyBytesChanged':False,'sourceTYPEConditionBytesChanged':False,'dataFieldOfPrimeNameChanged':False,'solutionBytesUnchangedFromOldFaithfulGlobalSolution':True,'aliasIntroduced':False,'outputs':[pin(p) for f in ['canonical','solution','stub'] for p in (D/f).iterdir()]};(D/'rename-map.json').write_text(json.dumps(M,ensure_ascii=False,indent=2)+'\n');print({'directory':str(D),'canonical':str(next((D/'canonical').iterdir())),'solution':str(next((D/'solution').iterdir()))})
