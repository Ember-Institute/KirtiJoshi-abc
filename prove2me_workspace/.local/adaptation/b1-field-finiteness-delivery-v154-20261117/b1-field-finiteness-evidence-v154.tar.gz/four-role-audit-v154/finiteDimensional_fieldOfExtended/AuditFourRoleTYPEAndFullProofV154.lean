import Lean
import Theorems.Thm_AbcAdaptation_Tripod_finiteDimensional_fieldOfExtended
import Solutions.Sol_AbcAdaptation_Tripod_finiteDimensional_fieldOfExtended
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData

open AbcAdaptation.Tripod

theorem FieldFinitenessPlatformShape.finiteDimensional_fieldOfExtended {l : AbcAdaptation.Tripod.Qbar} (h3 : AbcAdaptation.Tripod.TorsionFinite l 3) (h5 : AbcAdaptation.Tripod.TorsionFinite l 5) : FiniteDimensional ℚ (AbcAdaptation.Tripod.fieldOf' l) := by exact AbcAdaptation.Tripod.finiteDimensional_fieldOfExtended h3 h5

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare
namespace LegendreSevenReview
open Lean Elab Term Meta FoundationAudit BasicNativeCompare

end LegendreSevenReview

namespace FieldFinitenessFourRole
open Lean Elab Term Meta FoundationAudit BasicNativeCompare
partial def findKind (stx : Syntax) (k : Name) : Option Syntax :=
  if stx.getKind == k then some stx else stx.getArgs.findSome? (findKind · k)
def assertEq (label : String) (a b : Expr) : MetaM Unit := do
  match Kernel.isDefEq (← getEnv) {} a b with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inequality {label}"
  | .error ex => throwKernelException ex
run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_FIELD_OF_EXTENDED_FOUR_ROLE_CONFIG")
  unless (← checked (cfg.getObjValAs? String "schema")) == "B1-finiteDimensional_fieldOfExtended-four-role-config/v154" do throwError "Wrong field finiteness configuration"
  let payload ← jsonFile (← checked (cfg.getObjValAs? String "payloadFile"))
  let preamble ← checked (payload.getObjValAs? String "preamble")
  let statement ← checked (payload.getObjValAs? String "formal_statement")
  unless preamble == (← checked (cfg.getObjValAs? String "exactPreamble")) &&
    statement == (← checked (cfg.getObjValAs? String "exactFormalStatement")) do throwError "Expected exact platform payload strings"
  let canonicalMetadataName ← checked (decodeName (← checked (field cfg "canonicalNameExpr")))
  unless (← checked (payload.getObjValAs? String "theorem_name")) == canonicalMetadataName.toString do
    throwError "Platform theorem_name must match the complete canonical declaration name"
  let parsed ← checked (Parser.runParserCategory (← getEnv) `command statement)
  let some declNode := findKind parsed `Lean.Parser.Command.declId | throwError "Missing platform declId"
  let some bodyNode := findKind parsed `Lean.Parser.Term.byTactic | throwError "Missing platform proof AST"
  let edits ← checked (arrayField cfg "edits")
  unless edits.size == 2 do throwError "Expected root identifier and proof edits only"
  for entry in #[(declNode,edits[0]!), (bodyNode,edits[1]!)] do
    let (syntaxNode,edit) := entry
    let some startPos := syntaxNode.getPos? | throwError "No AST start"
    let some endPos := syntaxNode.getTailPos? | throwError "No AST end"
    unless startPos.byteIdx == (← checked (edit.getObjValAs? Nat "start")) &&
      endPos.byteIdx == (← checked (edit.getObjValAs? Nat "end")) do throwError "Payload edit AST span differs"
  let source ← jsonFile (← checked (cfg.getObjValAs? String "sourceFact"))
  unless (← checked (source.getObjValAs? String "record")) == "fullActualFact" &&
    (← checked (source.getObjValAs? Bool "valueRead")) &&
    (← checked (source.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do throwError "Source original full proof evidence missing"
  let mut maps : NameMap := #[]
  for pair in ← checked (arrayField cfg "projectMap") do
    let a ← checked (decodeName (← checked (field pair "sourceNameExpr")))
    let b ← checked (decodeName (← checked (field pair "targetNameExpr")))
    let expectedOwner ← checked (decodeName (← checked (field pair "targetOwnerNameExpr")))
    unless moduleOf (← getEnv) b == some expectedOwner do throwError "Actual boundary owner differs {b}"
    unless (maps.find? (·.1 == a)).isNone do throwError "Duplicate actual project map {a}"
    maps := maps.push (a,b)
  let sourceLevels ← namesFromJson (← checked (field source "levelParams"))
  let stRaw ← checked (relocateExpr maps #[] #[] false (← checked (field source "actualTypeExpr")))
  let svRaw ← checked (relocateExpr maps #[] #[] false (← checked (field source "actualValueExpr")))
  let canonicalName ← checked (decodeName (← checked (field cfg "canonicalNameExpr")))
  let shapeName ← checked (decodeName (← checked (field cfg "shapeNameExpr")))
  let roles := #[canonicalName,`solution,shapeName]
  let labels := #["canonical","solution","platform_exactshape"]
  let reference ← getConstInfo canonicalName
  let levels := reference.levelParams.map Level.param
  unless sourceLevels.length == reference.levelParams.length do throwError "Source/native universe arity differs"
  let sourceTYPE := stRaw.instantiateLevelParams sourceLevels levels
  let sourceProof := svRaw.instantiateLevelParams sourceLevels levels
  let _ ← kernelCheck "full source TYPE" sourceTYPE
  let inferredSourceTYPE ← kernelCheck "complete relocated original source proof" sourceProof
  assertEq "source original proof TYPE" inferredSourceTYPE sourceTYPE
  ensureStandard "complete original source proof" (← expressionAxioms sourceProof)
  for key in #["axioms","typeAxioms","valueAxioms"] do
    for ax in ← checked (source.getObjValAs? (Array String) key) do
      unless #["propext","Classical.choice","Quot.sound"].contains ax do throwError "Source nonstandard axiom {ax}"
  if ← checked (source.getObjValAs? Bool "hasSorryAx") then throwError "Source sorryAx"
  let mut reports : Array Json := #[Json.mkObj [
    ("role",toJson "source"),("actualTYPE",← checked (encodeExpr sourceTYPE)),
    ("fullOriginalActualProofRead",toJson true),("fullSourceProofKernelChecked",toJson true),
    ("sourceProofInferredTYPEKernelEqual",toJson true),("standardAxiomsOnly",toJson true),
    ("hasSorryAx",toJson false)]]
  for idx in [:roles.size] do
    let ci ← getConstInfo roles[idx]!
    if idx < 2 then
      let expectedOwner ← checked (decodeName (← checked (field cfg (if idx == 0 then "canonicalOwnerNameExpr" else "solutionOwnerNameExpr"))))
      unless moduleOf (← getEnv) ci.name == some expectedOwner do throwError "Role owner differs {ci.name}"
    unless ci.levelParams.length == sourceLevels.length do throwError "Universe arity differs {ci.name}"
    let targetTYPE := ci.type.instantiateLevelParams ci.levelParams levels
    unless binderInventory sourceTYPE == binderInventory targetTYPE &&
      binderPlacement sourceTYPE == binderPlacement targetTYPE do throwError "Full TYPE BinderInfo differs {ci.name}"
    assertEq s!"four-role TYPE {ci.name}" sourceTYPE targetTYPE
    let some proof := ci.value? (allowOpaque := true) | throwError "Missing complete role proof {ci.name}"
    let targetProof := proof.instantiateLevelParams ci.levelParams levels
    let inferred ← kernelCheck s!"complete role proof {ci.name}" targetProof
    assertEq s!"role proof TYPE {ci.name}" inferred targetTYPE
    assertEq s!"complete source/native proof {ci.name}" sourceProof targetProof
    let axioms ← collectAxioms ci.name
    ensureStandard ci.name.toString axioms
    ensureStandard s!"full proof body {ci.name}" (← expressionAxioms targetProof)
    reports := reports.push (Json.mkObj [
      ("role",toJson labels[idx]!),("nameExpr",encodeName ci.name),
      ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
      ("actualTYPE",← checked (encodeExpr ci.type)),
      ("fullTYPEBinderInventory",toJson (binderInventory ci.type)),
      ("fullTYPEKernelEqualSource",toJson true),("fullTYPEBinderPlacementEqual",toJson true),
      ("fullActualProofKernelChecked",toJson true),("actualProofTYPEKernelEqual",toJson true),
      ("fullProofKernelEqualSource",toJson true),("proofStructurallyEqualSource",toJson (sourceProof == targetProof)),
      ("proofTermIdentityClaimed",toJson false),("axioms",toJson (axioms.map Name.toString)),
      ("hasSorryAx",toJson false)])
  let output ← checked (cfg.getObjValAs? String "outputFile")
  unless output.startsWith "/" do throwError "Absolute output required"
  if let some parent := (System.FilePath.mk output).parent then IO.FS.createDirAll parent
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "B1-finiteDimensional_fieldOfExtended-four-role-review/v154"),("configuration",cfg),
    ("fourRoles",Json.arr reports),("allFourTYPEAndFullProofChecksPassed",toJson true),
    ("allFourProofsSorryAxFree",toJson true)]).pretty ++ "\n")
  logInfo "Field finiteness source/canonical/solution/platform TYPE and complete proof audit passed"
end FieldFinitenessFourRole
