# English

The hypotheses at 3 and 5 make both torsion-coordinate sets finite by the first lemma. Their union with the four selected elements is therefore finite. Every element of the fixed algebraic closure is algebraic over the rational field, hence integral over that field. Adjoining this finite set of integral elements gives a finite-dimensional extension, which is exactly the already defined field.

# 简体中文

由第一条引理，关于 3 和 5 的两个假设分别使两个挠点坐标集合有限。它们与四个选定元素的集合取并后仍有限。固定代数闭包中的每个元素都在有理数域上代数，因而在该域上整。向有理数域添加这一有限集中的整元素，得到有限维扩张，恰好就是已定义的域。

# 日本語

最初の補題により、3 と 5 に関する二つの仮定から、それぞれの等分点座標集合が有限となる。これらと四つの選択済みの元の集合との和集合も有限である。固定した代数閉包の各元は有理数体上代数的であり、したがって有理数体上整である。この有限個の整な元を添加すると有限次元拡大が得られ、それが既に定義された体に一致する。
