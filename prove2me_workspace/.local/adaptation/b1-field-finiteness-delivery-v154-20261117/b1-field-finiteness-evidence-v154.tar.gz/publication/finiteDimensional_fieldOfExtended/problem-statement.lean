import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData

open AbcAdaptation.Tripod

theorem AbcAdaptation.Tripod.finiteDimensional_fieldOfExtended {l : AbcAdaptation.Tripod.Qbar} (h3 : AbcAdaptation.Tripod.TorsionFinite l 3) (h5 : AbcAdaptation.Tripod.TorsionFinite l 5) : FiniteDimensional ℚ (AbcAdaptation.Tripod.fieldOf' l) := by sorry
