Original English read-back: `readback.en.frozen.md`.

Simplified Chinese and Japanese translations: `readback.zh-Hans.md` and `readback.ja.md`. The translations derive from the frozen English and are not independent audits.

`metadata.json` records the actual model supplied in the startup record, exact source-file codeSHA, hashes and summaries of formal inputs, review-rule hashes, and the translation relationship. `codeSHA.txt` contains the target file SHA-256.

No compilation, CI submission, API call or main-workspace edit was performed.
