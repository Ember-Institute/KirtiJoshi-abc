from pathlib import Path
import json,hashlib,shutil,re
from datetime import datetime,timezone
O=Path('/tmp/p2m-b1-field-finiteness-publication-v150-20261117');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');B=Path('/tmp/p2m-b1-curveof-field-properties-v148-20261117');F=Path('/tmp/p2m-b1-torsion-field-finite-fresh-blind-v148-20261117')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
frozen={str(p):sha(p) for p in F.rglob('*') if p.is_file()};rb=json.loads((F/'readbacks.json').read_text());bm=json.loads((F/'manifest.json').read_text())
assert sha(F/'readback.en.raw.md')==bm['english_original_sha256']
pcpath=Path('/tmp/p2m-b1-curveof-fields-publication-v146-20261117/paper-context.json');pc=json.loads(pcpath.read_text());quotes={q['id']:q['quote_markdown'] for q in pc['quotations']};IV=pc['papers']['IV'];I=pc['papers']['I']
source_en='''## Original paper background and scope

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

> '''+quotes['IV-Legendre-line']+'''

Official original: '''+IV['official_url']+'''. Local original: `'''+IV['local_pdf']+'''`. Later corollary material is omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

> '''+quotes['I-field-closure']+'''

Definition 3.1(c), first sentence through the definition of $K$, printed/PDF page 62:

> '''+quotes['I-torsion-extension'].replace('\n','\n> ')+'''

Official original: '''+I['official_url']+'''. Local original: `'''+I['local_pdf']+'''`. The intervening material and the remainder of (c) are omitted.

These passages provide the Legendre family, selected algebraic closure, and torsion-field background. They do not state the finite-union argument or the finite-dimensional-adjoin argument below. These two lemmas are supporting mathematical deductions in the reference source. In particular, the paper's finite Galois extension attached to a prime-level representation is not silently identified with the explicitly generated $F_\\lambda$. Each lemma retains its actual finiteness hypotheses; neither proves that the torsion sets are finite.
'''
source_zh='''## 论文原文背景与范围

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2 开头、“Let”之前的完整两句，印刷页与文件页均为第 41 页。精确英文引文见英文部分；该推论后续内容未引用。官方原文：'''+IV['official_url']+'''。本地原文：`'''+IV['local_pdf']+'''`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页；定义 3.1(c) 首句至定义 $K$ 为止，印刷页与文件页均为第 62 页。精确英文引文见英文部分；中间内容及 (c) 的其余部分已省略。官方原文：'''+I['official_url']+'''。本地原文：`'''+I['local_pdf']+'''`。

这些段落提供 Legendre 曲线族、选定代数闭包和挠点域的背景，没有陈述下面的有限并论证或有限维生成扩张论证。两条引理是参考源码中的辅助数学推论。特别地，不把原文中由模素数表示确定的有限 Galois 扩张悄然等同于显式生成的 $F_\\lambda$。每条引理都保留实际的有限性假设，均不证明挠点集合有限。
'''
source_ja='''## 論文原文の背景と範囲

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示した。系の後続部分は引用しない。公式原文：'''+IV['official_url']+'''。ローカル原文：`'''+IV['local_pdf']+'''`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61、および定義 3.1(c) の最初の文から $K$ の定義まで、同 62。正確な英文は英語部分に示した。中間の部分と (c) の残りは省略した。公式原文：'''+I['official_url']+'''。ローカル原文：`'''+I['local_pdf']+'''`。

これらの段落は、ルジャンドル曲線族、選ばれた代数閉包、等分点体の背景を与える。以下の有限和集合の論証や有限次元の生成拡大の論証を述べるものではない。この二つの補題は参照ソース中の補助的な数学的帰結である。特に、素数レベルの表現で定まる論文の有限ガロア拡大を、明示的に生成した $F_\\lambda$ と暗黙に同一視しない。各補題は実際の有限性仮定を保ち、等分点集合の有限性自体は証明しない。
'''
proofs={
 'torsionCoords_finite':{'en':'The hypothesis gives a finite indexing set of torsion points. The identity contributes the empty coordinate set, and each nonsingular affine point contributes a set with at most two elements. A union of these finite sets over the finite indexing set is finite.','zh-Hans':'假设给出由挠点组成的有限指标集。单位元贡献空坐标集，每个非奇异仿射点贡献至多含两个元素的集合。在有限指标集上取这些有限集合的并，结果仍为有限集。','ja':'仮定により、等分点からなる添字集合は有限である。単位元の座標集合は空であり、各非特異アフィン点の座標集合は高々二つの元を持つ。有限な添字集合にわたるこれらの有限集合の和集合も有限である。'},
 "finiteDimensional_fieldOf'":{'en':'The hypotheses at 3 and 5 make both torsion-coordinate sets finite by the first lemma. Their union with the four selected elements is therefore finite. Every element of the fixed algebraic closure is algebraic over the rational field, hence integral over that field. Adjoining this finite set of integral elements gives a finite-dimensional extension, which is exactly the already defined field.','zh-Hans':'由第一条引理，关于 3 和 5 的两个假设分别使两个挠点坐标集合有限。它们与四个选定元素的集合取并后仍有限。固定代数闭包中的每个元素都在有理数域上代数，因而在该域上整。向有理数域添加这一有限集中的整元素，得到有限维扩张，恰好就是已定义的域。','ja':'最初の補題により、3 と 5 に関する二つの仮定から、それぞれの等分点座標集合が有限となる。これらと四つの選択済みの元の集合との和集合も有限である。固定した代数閉包の各元は有理数体上代数的であり、したがって有理数体上整である。この有限個の整な元を添加すると有限次元拡大が得られ、それが既に定義された体に一致する。'}}
intuition={
 'torsionCoords_finite':{'en':'A finite collection of points can contribute only finitely many coordinate values. The hypothesis supplies the finiteness of the collection.','zh-Hans':'有限多个点只能贡献有限多个坐标值。点的集合有限这一事实来自假设。','ja':'有限個の点から得られる座標値も有限個である。点集合の有限性は仮定から与えられる。'},
 "finiteDimensional_fieldOf'":{'en':'Only finitely many algebraic values need to be adjoined once the two torsion sets are finite. This is why the resulting field has finite degree.','zh-Hans':'一旦两个挠点集合有限，就只需添加有限多个代数值，因此生成的域具有有限次数。','ja':'二つの等分点集合が有限なら、添加する代数的な値は有限個で足りる。そのため生成体の次数は有限となる。'}}
commonpre='''import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData
'''
configs=[('torsionCoords_finite','torsionCoords_finite','Thm_AbcAdaptation_Tripod_torsionCoords_finite.lean','Sol_AbcAdaptation_Tripod_torsionCoords_finite.lean','Finiteness of torsion coordinate values — 挠点坐标值的有限性 — 等分点座標値の有限性',commonpre+'\nopen AbcAdaptation.Tripod\nopen WeierstrassCurve NumberField\nopen scoped IntermediateField\n','theorem AbcAdaptation.Tripod.torsionCoords_finite {l : Qbar} {n : ℕ} (h : TorsionFinite l n) :\n    (torsionCoords l n).Finite := by sorry'),('finiteDimensional_fieldOfPrime',"finiteDimensional_fieldOf'",'Thm_AbcAdaptation_Tripod_finiteDimensional_fieldOfPrime.lean','Sol_AbcAdaptation_Tripod_finiteDimensional_fieldOfPrime.lean','Finite degree of the generated field under torsion finiteness — 挠点有限性假设下生成域的有限次数 — 等分点の有限性を仮定した生成体の有限次数',commonpre+'import Theorems.Thm_AbcAdaptation_Tripod_torsionCoords_finite\n\nopen AbcAdaptation.Tripod\nopen WeierstrassCurve NumberField\nopen scoped IntermediateField\n',"theorem AbcAdaptation.Tripod.finiteDimensional_fieldOf' {l : Qbar}\n    (h3 : TorsionFinite l 3) (h5 : TorsionFinite l 5) :\n    FiniteDimensional ℚ (fieldOf' l) := by sorry")]
units=[]
for label,key,filename,solfile,title,pre,formal in configs:
 dest=O/label;dest.mkdir(exist_ok=True);can=B/label/'canonical'/filename;sol=B/label/'solution'/solfile;stub=B/label/'stub'/filename
 bkey='finiteDimensional_fieldOf_prime' if key.endswith("'") else key
 assert sha(can)==bm['codeactualSHA'][bkey]
 texts=rb['declarations'][key];parts=[]
 for lang,heading,src,pheading,iheading in [('en','English',source_en,'Proof explanation','Intuitive explanation (non-rigorous)'),('zh-Hans','简体中文',source_zh,'证明说明','直观解释（非严格）'),('ja','日本語',source_ja,'証明の説明','直観的説明（非厳密）')]:
  parts.append('# '+heading+'\n\n'+texts[lang]+'\n\n'+src+'\n## '+pheading+'\n\n'+proofs[key][lang]+'\n\n## '+iheading+'\n\n'+intuition[key][lang])
 statement='\n\n'.join(parts)+'\n';name='AbcAdaptation.Tripod.'+key
 payload={'theorem_name':name,'theorem_title':title,'preamble':pre,'formal_statement':formal,'natural_language_statement':statement,'source':'Supporting lemma from the reference source Iut/Tripod/CurveOf.lean. Mathematical background only: Shinichi Mochizuki, Inter-universal Teichmüller Theory IV, April 2020, §2, Corollary 2.2 opening, printed/PDF p. 41; Inter-universal Teichmüller Theory I, May 2020, §3, Definition 3.1(a), p. 61, and first sentence of (c) through K, p. 62. The finite-union and finite-dimensional-adjoin proofs are source-code supporting deductions, not quoted paper theorems. '+IV['official_url']+' '+I['official_url'],'env':'0df444a360eaa60ab8c11dca51a86af692955474','private':True}
 (dest/'payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');(dest/'natural-language-statement.md').write_text(statement);(dest/'problem-statement.lean').write_text(pre+'\n'+formal+'\n');(dest/'proof-explanation.json').write_text(json.dumps(proofs[key],ensure_ascii=False,indent=2)+'\n')
 for p in [can,sol,stub]:shutil.copyfile(p,dest/(p.parent.name+'-'+p.name))
 assert formal.startswith('theorem '+payload['theorem_name']+' ') and formal.endswith(':= by sorry')
 assert all(t in statement for t in texts.values())
 assert not re.search(r'ci-\d|gpt-|SHA.?256|\bhash\b|\bCI\b|编译|コンパイル',statement,re.I)
 units.append({'label':label,'Lean_and_API_theorem_name':name,'payload':rec(dest/'payload.json'),'canonical':rec(can),'solution':rec(sol),'stub':rec(stub),'source_complete_actual_fact':rec(B/label/'source-root-full-actual-fact.json'),'proof_explanation':rec(dest/'proof-explanation.json'),'new_problem_form_compiled_by_editor':False})
(O/'independent-readback').mkdir(exist_ok=True)
for p in F.iterdir():
 if p.is_file():shutil.copyfile(p,O/'independent-readback'/p.name)
shutil.copyfile(pcpath,O/'paper-context-background.json')
metadata={'schema':'B1-field-finiteness-private-problems-academic-draft/v150','created_utc':datetime.now(timezone.utc).isoformat(),'editorial_model':'gpt-6.1-sol','status':'DRAFT_NOT_POSTED_PENDING_PARENT_FOUR_ROLE_REVIEW','editorial_not_new_independent_readback':True,'units':units,'independent_readback':{'directory':str(F),'all_frozen_file_hashes':frozen,'original_files_unchanged':all(sha(Path(p))==h for p,h in frozen.items()),'all_three_language_math_texts_reused_verbatim':True,'English_frozen_sha256':bm['english_original_sha256'],'translations_not_additional_independent_audits':True},'paper_background':rec(pcpath),'paper_evidence':'Original page renderings visually checked earlier in this editorial session, as recorded by the inherited paper context. No new paper claim is inferred.','API_name_rules':{'input':rec(W/'references/contribute.md'),'lines':'33–35 require theorem_name to match the Lean declaration with namespace; line153 restricts definition_name only','apostrophe':'Retain the actual Lean theorem name with final apostrophe. No separate exclusion for apostrophes in theorem_name was found in the supplied rules. No API acceptance test performed.','file_label_second':'finiteDimensional_fieldOfPrime','theorem_and_metadata_full_names_match':True},'binder_inventory':{'torsionCoords_finite':['{l : Qbar}','{n : ℕ}','(h : TorsionFinite l n)'],"finiteDimensional_fieldOf'":['{l : Qbar}','(h3 : TorsionFinite l 3)','(h5 : TorsionFinite l 5)']},'proof_scope':'Short mathematical proof explanations describe the supplied canonical proofs, without tactic transcripts. They do not replace the actual proofs.','acceptance_boundary':'The parent reported the first canonical leaf passed and source original proof closure exists; four-role review remains pending. This draft does not declare the logical units finished.','operations':{'CI_compiler_API_Git_executed':False,'main_workspace_written':False,'blind_originals_changed':False,'published':False}}
(O/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
assert all(sha(Path(p))==h for p,h in frozen.items())
(O/'validation.json').write_text(json.dumps({'two_private_payloads':True,'environment':'0df444a360eaa60ab8c11dca51a86af692955474','full_names_match_Lean_including_apostrophe':True,'first_implicit_l_n_and_explicit_h_preserved':True,'second_implicit_l_and_explicit_h3_h5_preserved':True,'first_preamble_import_is_FieldsData':True,'frozen_readbacks_unchanged':True,'product_body_no_CI_model_hash':True,'proof_explanations_three_languages':True,'not_posted':True,'four_role_terminal_acceptance_not_claimed':True},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'name':u['Lean_and_API_theorem_name'],'payload_sha256':u['payload']['sha256']} for u in units],ensure_ascii=False,indent=2))
