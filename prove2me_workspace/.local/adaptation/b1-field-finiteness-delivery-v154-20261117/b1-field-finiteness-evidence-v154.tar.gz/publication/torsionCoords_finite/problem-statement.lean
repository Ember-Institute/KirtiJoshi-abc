import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData

open AbcAdaptation.Tripod
open WeierstrassCurve NumberField
open scoped IntermediateField

theorem AbcAdaptation.Tripod.torsionCoords_finite {l : Qbar} {n : ℕ} (h : TorsionFinite l n) :
    (torsionCoords l n).Finite := by sorry
