# English

For every element $\lambda$ of the algebraic closure $\overline{\mathbb Q}$ of $\mathbb Q$ and every natural number $n$, including $0$, let $G_\lambda$ be the group consisting of the point at infinity $O$ and the nonsingular affine points $(x,y)$ of the Weierstrass curve $y^2=x(x-1)(x-\lambda)$ over $\overline{\mathbb Q}$. Let $T_{\lambda,n}=\{P\in G_\lambda\mid nP=O\}$, where $nP$ denotes multiplication by the natural number $n$ in this group. Assume $T_{\lambda,n}$ is finite; this is the hypothesis named `TorsionFinite` in the declaration. Give $O$ the empty coordinate set and give each affine point $(x,y)$ the coordinate set $\{x,y\}$. Then the union of these coordinate sets over all $P\in T_{\lambda,n}$, namely the set called `torsionCoords`, is a finite subset of $\overline{\mathbb Q}$. There is no restriction $\lambda\ne0$ or $\lambda\ne1$: these parameter values are included, with the point group still using only nonsingular affine points and the point at infinity. There is also no hypothesis $n\ne0$; when $n=0$, $T_{\lambda,0}=G_\lambda$, so the retained finiteness hypothesis requires the entire point group to be finite. The assertion is conditional on that hypothesis and does not itself assert that it holds.

## Original paper background and scope

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

> Suppose that $X=\mathbb P^1_{\mathbb Q}$ is the projective line over $\mathbb Q$, and that $D\subseteq X$ is the divisor consisting of the three points “$0$”, “$1$”, and “$\infty$”. We shall regard $X$ as the “$\lambda$-line” — i.e., we shall regard the standard coordinate on $X=\mathbb P^1_{\mathbb Q}$ as the “$\lambda$” in the Legendre form “$y^2=x(x-1)(x-\lambda)$” of the Weierstrass equation defining an elliptic curve — and hence as being equipped with a natural classifying morphism $U_X\to(\mathcal M_{\mathrm{ell}})_{\mathbb Q}$ [cf. the discussion preceding Proposition 1.8].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`. Later corollary material is omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

> $F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.

Definition 3.1(c), first sentence through the definition of $K$, printed/PDF page 62:

> $l$ is a prime number $\geq5$ such that the image of the outer homomorphism
> 
> $$G_F\to GL_2(\mathbb F_l)$$
> 
> determined by the $l$-torsion points of $E_F$ contains the subgroup $SL_2(\mathbb F_l)\subseteq GL_2(\mathbb F_l)$; write $K\subseteq\overline F$ for the finite Galois extension of $F$ determined by the kernel of this homomorphism.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`. The intervening material and the remainder of (c) are omitted.

These passages provide the Legendre family, selected algebraic closure, and torsion-field background. They do not state the finite-union argument or the finite-dimensional-adjoin argument below. These two lemmas are supporting mathematical deductions in the reference source. In particular, the paper's finite Galois extension attached to a prime-level representation is not silently identified with the explicitly generated $F_\lambda$. Each lemma retains its actual finiteness hypotheses; neither proves that the torsion sets are finite.

## Proof explanation

The hypothesis gives a finite indexing set of torsion points. The identity contributes the empty coordinate set, and each nonsingular affine point contributes a set with at most two elements. A union of these finite sets over the finite indexing set is finite.

## Intuitive explanation (non-rigorous)

A finite collection of points can contribute only finitely many coordinate values. The hypothesis supplies the finiteness of the collection.

# 简体中文

对有理数域 $\mathbb Q$ 的代数闭包 $\overline{\mathbb Q}$ 中的任意元素 $\lambda$ 和任意自然数 $n$（包括 $0$），令 $G_\lambda$ 为由无穷远点 $O$ 及 Weierstrass 曲线 $y^2=x(x-1)(x-\lambda)$ 在 $\overline{\mathbb Q}$ 上的非奇异仿射点 $(x,y)$ 组成的群。令 $T_{\lambda,n}=\{P\in G_\lambda\mid nP=O\}$，其中 $nP$ 表示群中自然数 $n$ 对点的倍乘。假设 $T_{\lambda,n}$ 是有限集；这就是声明中名为 `TorsionFinite` 的假设。给 $O$ 配以空坐标集，给每个仿射点 $(x,y)$ 配以坐标集 $\{x,y\}$。那么，对所有 $P\in T_{\lambda,n}$ 取这些坐标集的并所得的集合，即名为 `torsionCoords` 的集合，是 $\overline{\mathbb Q}$ 的有限子集。这里没有 $\lambda\ne0$ 或 $\lambda\ne1$ 的限制：这些参数值也在范围内，此时点群仍只采用非奇异仿射点和无穷远点。这里也没有 $n\ne0$ 的假设；当 $n=0$ 时，$T_{\lambda,0}=G_\lambda$，所以仍须满足的有限性假设要求整个点群为有限集。此断言以该假设为前提，本身并未断言该假设成立。

## 论文原文背景与范围

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2 开头、“Let”之前的完整两句，印刷页与文件页均为第 41 页。精确英文引文见英文部分；该推论后续内容未引用。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页；定义 3.1(c) 首句至定义 $K$ 为止，印刷页与文件页均为第 62 页。精确英文引文见英文部分；中间内容及 (c) 的其余部分已省略。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

这些段落提供 Legendre 曲线族、选定代数闭包和挠点域的背景，没有陈述下面的有限并论证或有限维生成扩张论证。两条引理是参考源码中的辅助数学推论。特别地，不把原文中由模素数表示确定的有限 Galois 扩张悄然等同于显式生成的 $F_\lambda$。每条引理都保留实际的有限性假设，均不证明挠点集合有限。

## 证明说明

假设给出由挠点组成的有限指标集。单位元贡献空坐标集，每个非奇异仿射点贡献至多含两个元素的集合。在有限指标集上取这些有限集合的并，结果仍为有限集。

## 直观解释（非严格）

有限多个点只能贡献有限多个坐标值。点的集合有限这一事实来自假设。

# 日本語

有理数体 $\mathbb Q$ の代数閉包 $\overline{\mathbb Q}$ の任意の元 $\lambda$ と、$0$ を含む任意の自然数 $n$ に対し、$G_\lambda$ を、無限遠点 $O$ と Weierstrass 曲線 $y^2=x(x-1)(x-\lambda)$ の $\overline{\mathbb Q}$ 上の非特異アフィン点 $(x,y)$ からなる群とする。$T_{\lambda,n}=\{P\in G_\lambda\mid nP=O\}$ とおく。ここで $nP$ は、この群における自然数 $n$ による倍算を表す。$T_{\lambda,n}$ が有限集合であると仮定する。これが宣言で `TorsionFinite` と呼ばれる仮定である。$O$ の座標集合を空集合とし、各アフィン点 $(x,y)$ の座標集合を $\{x,y\}$ とする。このとき、すべての $P\in T_{\lambda,n}$ にわたるこれらの座標集合の和集合、すなわち `torsionCoords` と呼ばれる集合は、$\overline{\mathbb Q}$ の有限部分集合である。$\lambda\ne0$ または $\lambda\ne1$ という制限はなく、これらのパラメータ値も含まれる。その場合も点の群には非特異アフィン点と無限遠点のみを用いる。また、$n\ne0$ という仮定もない。$n=0$ のときは $T_{\lambda,0}=G_\lambda$ であるため、引き続き必要となる有限性の仮定は、点の群全体が有限集合であることを要求する。この主張はその仮定を条件とするものであり、その仮定が成り立つこと自体を主張するものではない。

## 論文原文の背景と範囲

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示した。系の後続部分は引用しない。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61、および定義 3.1(c) の最初の文から $K$ の定義まで、同 62。正確な英文は英語部分に示した。中間の部分と (c) の残りは省略した。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

これらの段落は、ルジャンドル曲線族、選ばれた代数閉包、等分点体の背景を与える。以下の有限和集合の論証や有限次元の生成拡大の論証を述べるものではない。この二つの補題は参照ソース中の補助的な数学的帰結である。特に、素数レベルの表現で定まる論文の有限ガロア拡大を、明示的に生成した $F_\lambda$ と暗黙に同一視しない。各補題は実際の有限性仮定を保ち、等分点集合の有限性自体は証明しない。

## 証明の説明

仮定により、等分点からなる添字集合は有限である。単位元の座標集合は空であり、各非特異アフィン点の座標集合は高々二つの元を持つ。有限な添字集合にわたるこれらの有限集合の和集合も有限である。

## 直観的説明（非厳密）

有限個の点から得られる座標値も有限個である。点集合の有限性は仮定から与えられる。
