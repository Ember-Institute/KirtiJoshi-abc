# English

The hypothesis gives a finite indexing set of torsion points. The identity contributes the empty coordinate set, and each nonsingular affine point contributes a set with at most two elements. A union of these finite sets over the finite indexing set is finite.

# 简体中文

假设给出由挠点组成的有限指标集。单位元贡献空坐标集，每个非奇异仿射点贡献至多含两个元素的集合。在有限指标集上取这些有限集合的并，结果仍为有限集。

# 日本語

仮定により、等分点からなる添字集合は有限である。単位元の座標集合は空であり、各非特異アフィン点の座標集合は高々二つの元を持つ。有限な添字集合にわたるこれらの有限集合の和集合も有限である。
