import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData
import Theorems.Thm_AbcAdaptation_Tripod_torsionCoords_finite

open AbcAdaptation.Tripod
open WeierstrassCurve NumberField
open scoped IntermediateField

theorem AbcAdaptation.Tripod.finiteDimensional_fieldOf' {l : Qbar}
    (h3 : TorsionFinite l 3) (h5 : TorsionFinite l 5) :
    FiniteDimensional ℚ (fieldOf' l) := by sorry
