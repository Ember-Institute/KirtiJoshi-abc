import Mathlib.Algebra.Algebra.Defs
import Mathlib.Algebra.Algebra.Equiv
import Mathlib.Algebra.Algebra.IsSimpleRing
import Mathlib.Algebra.Algebra.Rat
import Mathlib.Algebra.CharP.IntermediateField
import Mathlib.Algebra.CharZero.Infinite
import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Field.Rat
import Mathlib.Algebra.Field.Subfield.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Hom.Defs
import Mathlib.Algebra.Group.Subgroup.Defs
import Mathlib.Algebra.Group.TypeTags.Basic
import Mathlib.Algebra.Group.WithOne.Defs
import Mathlib.Algebra.Order.AbsoluteValue.Basic
import Mathlib.Algebra.Order.GroupWithZero.Canonical
import Mathlib.Algebra.Ring.Defs
import Mathlib.Algebra.Ring.Hom.Defs
import Mathlib.Algebra.Ring.Rat
import Mathlib.Algebra.Ring.Subring.Defs
import Mathlib.Algebra.Ring.Subsemiring.Defs
import Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass
import Mathlib.Analysis.Complex.Basic
import Mathlib.Analysis.Normed.Field.Basic
import Mathlib.Analysis.Normed.Ring.WithAbs
import Mathlib.Data.Complex.Basic
import Mathlib.Data.FunLike.Basic
import Mathlib.Data.Int.Cast.Defs
import Mathlib.Data.Real.Basic
import Mathlib.Data.Set.Defs
import Mathlib.Data.SetLike.Basic
import Mathlib.FieldTheory.IntermediateField.Basic
import Mathlib.FieldTheory.KrullTopology
import Mathlib.FieldTheory.Perfect
import Mathlib.FieldTheory.Separable
import Mathlib.LinearAlgebra.Basis.VectorSpace
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace
import Mathlib.NumberTheory.NumberField.InfinitePlace.Basic
import Mathlib.NumberTheory.NumberField.InfinitePlace.Embeddings
import Mathlib.RingTheory.Algebraic.Integral
import Mathlib.RingTheory.DedekindDomain.AdicValuation
import Mathlib.RingTheory.DedekindDomain.Basic
import Mathlib.RingTheory.Flat.FaithfullyFlat.Algebra
import Mathlib.RingTheory.Flat.FaithfullyFlat.Basic
import Mathlib.RingTheory.Flat.TorsionFree
import Mathlib.RingTheory.Henselian
import Mathlib.RingTheory.IntegralClosure.Algebra.Basic
import Mathlib.RingTheory.LocalRing.Defs
import Mathlib.RingTheory.Localization.FractionRing
import Mathlib.RingTheory.RegularLocalRing.Defs
import Mathlib.RingTheory.SimpleRing.Basic
import Mathlib.RingTheory.SimpleRing.Principal
import Mathlib.RingTheory.Valuation.RankOne
import Mathlib.Topology.Algebra.Category.ProfiniteGrp.Basic
import Mathlib.Topology.Algebra.Valued.ValuationTopology
import Mathlib.Topology.Category.CompHausLike.Basic
import Mathlib.Topology.Category.TopCat.Basic
import Mathlib.Topology.Connected.TotallyDisconnected
import Mathlib.Topology.Defs.Basic
import Mathlib.Topology.UniformSpace.Cauchy
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

universe u

open NumberField IsDedekindDomain WeierstrassCurve OrbicurveDataSection



section TorsionFieldFinite

variable {F : Type u} [Field F] [NumberField F] {E : WeierstrassCurve F} [E.IsElliptic]

variable {Fbar : Type u} [Field Fbar] [Algebra F Fbar] [IsAlgClosure F Fbar]

variable {VBad : Set (FinitePlace ↥(fieldOfModuli F E))}

end TorsionFieldFinite




structure TemperedGeometry (AG : AnabelianGeometry.{u}) : Type (u + 1) where
  
  tempPi1 : {k : Type u} → [Field k] → AG.Orbicurve k → Type u
  
  tempPi1Group : ∀ {k : Type u} [Field k] (X : AG.Orbicurve k), Group (tempPi1 X)
  
  tempPi1Topology : ∀ {k : Type u} [Field k] (X : AG.Orbicurve k),
    TopologicalSpace (tempPi1 X)
  
  tempToEtale : ∀ {k : Type u} [Field k] (X : AG.Orbicurve k),
    letI := tempPi1Group X; tempPi1 X →* AG.pi1 X
  
  tempToEtale_continuous : ∀ {k : Type u} [Field k] (X : AG.Orbicurve k),
    letI := tempPi1Group X; letI := tempPi1Topology X
    Continuous (tempToEtale X)
  
  IsThetaRootModel : {k : Type u} → [Field k] → [Valued k (WithZero (Multiplicative ℤ))] →
    [Valuation.RankOne (Valued.v : Valuation k (WithZero (Multiplicative ℤ)))] → [CompleteSpace k] →
    (ℓ : ℕ) → (X : AG.Orbicurve k) → AG.TateStructure X → Prop
  
  canonicalGraphCusp : {k : Type u} → [Field k] → [Valued k (WithZero (Multiplicative ℤ))] →
    [Valuation.RankOne (Valued.v : Valuation k (WithZero (Multiplicative ℤ)))] → [CompleteSpace k] →
    (X : AG.Orbicurve k) → AG.TateStructure X → AG.Cusp X



section LocalData

variable (AG : AnabelianGeometry.{u}) (TG : TemperedGeometry AG)

variable (F : Type u) [Field F] [NumberField F] (E : WeierstrassCurve F) [E.IsElliptic]

variable (Fbar : Type u) [Field Fbar] [Algebra F Fbar]

variable (VBad : Set (FinitePlace ↥(fieldOfModuli F E)))

variable (P : AdmissiblePrimeData F E Fbar VBad)

variable [NumberField ↥P.torsionField]

variable [Algebra ↥(fieldOfModuli F E) ↥P.torsionField]


structure ValuationSection : Type u where
  
  sectFin : FinitePlace ↥(fieldOfModuli F E) → FinitePlace ↥P.torsionField
  
  sectInf : InfinitePlace ↥(fieldOfModuli F E) → InfinitePlace ↥P.torsionField
  
  sectFin_liesOver : ∀ v, FinitePlace.LiesOver (sectFin v) v
  
  sectInf_liesOver : ∀ v, (sectInf v).1.LiesOver v.1

namespace ValuationSection

variable {AG TG F E Fbar VBad P}

variable (S : ValuationSection F E Fbar VBad P)

end ValuationSection

variable {AG TG F E Fbar VBad P} in

noncomputable def localize (v : FinitePlace ↥P.torsionField)
    (X : AG.Orbicurve ↥P.torsionField) : AG.Orbicurve (localCompletion v) :=
  AG.baseChange (FinitePlace.embedding v.maximalIdeal) X


structure LocalThetaData (O : OrbicurveData AG F E Fbar VBad P) : Type u where
  
  sect : ValuationSection F E Fbar VBad P
  
  local_diagram_cartesian : ∀ v : FinitePlace ↥(fieldOfModuli F E),
    AG.IsCartesianSquare
      (AG.coverBaseChange (FinitePlace.embedding (sect.sectFin v).maximalIdeal)
        O.XKu_to_XK)
      (AG.coverBaseChange (FinitePlace.embedding (sect.sectFin v).maximalIdeal)
        O.XK_to_CK)
      (AG.coverBaseChange (FinitePlace.embedding (sect.sectFin v).maximalIdeal)
        O.XKu_to_CKu)
      (AG.coverBaseChange (FinitePlace.embedding (sect.sectFin v).maximalIdeal)
        O.CKu_to_CK)
  
  decomp : ∀ _ : FinitePlace ↥P.torsionField, Subgroup (Fbar ≃ₐ[↥P.torsionField] Fbar)
  
  decomp_isClosed : ∀ v, IsClosed ((decomp v) : Set (Fbar ≃ₐ[↥P.torsionField] Fbar))
  
  tateX : ∀ v ∈ VBad, AG.TateStructure (localize (sect.sectFin v) O.XKu)
  
  tateC : ∀ v ∈ VBad, AG.TateStructure (localize (sect.sectFin v) O.CKu)
  
  bad_type : ∀ v (hv : v ∈ VBad),
    AG.IsTypeOneZModPM P.ℓ (localize (sect.sectFin v) O.XKu) (tateX v hv)
  
  bad_theta_model : ∀ v (hv : v ∈ VBad),
    TG.IsThetaRootModel P.ℓ (localize (sect.sectFin v) O.XKu) (tateX v hv)
  
  epsilon_graph : ∀ v (hv : v ∈ VBad),
    AG.cuspBaseChange (FinitePlace.embedding (sect.sectFin v).maximalIdeal) O.epsilon =
      TG.canonicalGraphCusp (localize (sect.sectFin v) O.CKu) (tateC v hv)

namespace LocalThetaData

variable {AG TG F E Fbar VBad P} {O : OrbicurveData AG F E Fbar VBad P}

variable (L : LocalThetaData AG TG F E Fbar VBad P O)

end LocalThetaData

end LocalData

end Iut

end AbcAdaptation.Reference
