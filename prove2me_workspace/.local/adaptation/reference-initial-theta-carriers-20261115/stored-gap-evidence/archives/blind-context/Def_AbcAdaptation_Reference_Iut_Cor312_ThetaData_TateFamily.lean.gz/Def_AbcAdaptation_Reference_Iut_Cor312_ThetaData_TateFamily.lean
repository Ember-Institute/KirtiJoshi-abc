import Mathlib.Algebra.Algebra.Defs
import Mathlib.Algebra.Algebra.Equiv
import Mathlib.Algebra.Algebra.Rat
import Mathlib.Algebra.CharP.IntermediateField
import Mathlib.Algebra.CharZero.Infinite
import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Field.Rat
import Mathlib.Algebra.Field.Subfield.Defs
import Mathlib.Algebra.Group.Action.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Hom.Defs
import Mathlib.Algebra.Group.Subgroup.Defs
import Mathlib.Algebra.Group.Subgroup.Map
import Mathlib.Algebra.Group.Submonoid.Defs
import Mathlib.Algebra.GroupWithZero.Action.Defs
import Mathlib.Algebra.Module.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Algebra.Ring.Hom.Defs
import Mathlib.Algebra.Ring.Subring.Defs
import Mathlib.Algebra.Ring.Subsemiring.Defs
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Basic
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Point
import Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass
import Mathlib.Data.FunLike.Basic
import Mathlib.Data.Int.Cast.Defs
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Data.Set.Defs
import Mathlib.Data.SetLike.Basic
import Mathlib.FieldTheory.IntermediateField.Basic
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace
import Mathlib.RingTheory.DedekindDomain.AdicValuation
import Mathlib.RingTheory.DedekindDomain.Basic
import Mathlib.RingTheory.Localization.FractionRing
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PlacesOver
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PointMap
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateStructure

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

open WeierstrassCurve NumberField Iut.Anabelian

open scoped Classical

universe u

noncomputable section

variable {F : Type u} [Field F] [NumberField F] (E : WeierstrassCurve F) [E.IsElliptic]

variable {Fbar : Type u} [Field Fbar] [Algebra F Fbar]

variable (K : IntermediateField F Fbar) [NumberField ↥K]


local instance (priority := 1100) instDecidableEqIntermediateField : DecidableEq ↥K :=
  fun a b => Classical.propDecidable (a = b)


abbrev curveK : WeierstrassCurve ↥K := E.map (algebraMap F ↥K)


abbrev emb (w : FinitePlace ↥K) : ↥K →+* localCompletion w :=
  FinitePlace.embedding w.maximalIdeal


abbrev curveKw (w : FinitePlace ↥K) : WeierstrassCurve (localCompletion w) :=
  (curveK E K).map (emb K w)


def galK (σ : ↥K ≃ₐ[F] ↥K) : (curveK E K).toAffine.Point →+ (curveK E K).toAffine.Point :=
  Affine.Point.map (W' := E) (S := F) (σ : ↥K →ₐ[F] ↥K)

variable (ℓ : ℕ) (VBad : Set (FinitePlace ↥(fieldOfModuli F E)))


def IsBadPlace (w : FinitePlace ↥K) : Prop := ∃ v ∈ VBad, FinitePlace.LiesOver w v

lemma isBadPlace_galPlace {w : FinitePlace ↥K} (hw : IsBadPlace E K VBad w)
    (σ : ↥K ≃ₐ[F] ↥K) : IsBadPlace E K VBad (galPlace σ w) := by
  obtain ⟨v, hv, hwv⟩ := hw
  exact ⟨v, hv, galPlace_liesOver (fun _ => rfl) σ hwv⟩


structure TateFamily : Type u where
  
  S : ∀ w : FinitePlace ↥K, IsBadPlace E K VBad w → TateStructure (curveKw E K w)
  
  graphLine_galPlace : ∀ (w : FinitePlace ↥K) (hw : IsBadPlace E K VBad w) (σ : ↥K ≃ₐ[F] ↥K),
    ((S (galPlace σ w) (isBadPlace_galPlace E K VBad hw σ)).graphLine ℓ).comap
        (pointMap (curveK E K) (emb K (galPlace σ w))) =
      (((S w hw).graphLine ℓ).comap (pointMap (curveK E K) (emb K w))).map (galK E K σ)
  
  isCanonical_galPlace : ∀ (w : FinitePlace ↥K) (hw : IsBadPlace E K VBad w)
    (σ : ↥K ≃ₐ[F] ↥K) (R : (curveK E K).toAffine.Point),
    (S (galPlace σ w) (isBadPlace_galPlace E K VBad hw σ)).IsCanonical ℓ
        (pointMap (curveK E K) (emb K (galPlace σ w)) (galK E K σ R)) ↔
      (S w hw).IsCanonical ℓ (pointMap (curveK E K) (emb K w) R)

namespace TateFamily

variable {E K ℓ VBad} (TF : TateFamily E K ℓ VBad)

end TateFamily

end

end Iut

end AbcAdaptation.Reference
