import Mathlib.Algebra.Algebra.Defs
import Mathlib.Algebra.Algebra.Rat
import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Field.Rat
import Mathlib.Algebra.Field.Subfield.Defs
import Mathlib.Algebra.Group.Action.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Hom.Defs
import Mathlib.Algebra.Group.TypeTags.Basic
import Mathlib.Algebra.Group.WithOne.Defs
import Mathlib.Algebra.GroupWithZero.Action.Defs
import Mathlib.Algebra.GroupWithZero.Defs
import Mathlib.Algebra.Module.Defs
import Mathlib.Algebra.Order.GroupWithZero.Canonical
import Mathlib.Algebra.Ring.Defs
import Mathlib.Algebra.Ring.Hom.Defs
import Mathlib.Algebra.Ring.Subring.Defs
import Mathlib.Algebra.Ring.Subsemiring.Defs
import Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass
import Mathlib.Data.FunLike.Basic
import Mathlib.Data.FunLike.Equiv
import Mathlib.Data.Set.Defs
import Mathlib.Data.SetLike.Basic
import Mathlib.Data.ZMod.Defs
import Mathlib.FieldTheory.IntermediateField.Basic
import Mathlib.Logic.Equiv.Defs
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace
import Mathlib.RingTheory.Valuation.RankOne
import Mathlib.Topology.Algebra.Category.ProfiniteGrp.Basic
import Mathlib.Topology.Algebra.Valued.ValuationTopology
import Mathlib.Topology.Category.CompHausLike.Basic
import Mathlib.Topology.Category.TopCat.Basic
import Mathlib.Topology.Connected.TotallyDisconnected
import Mathlib.Topology.Defs.Basic
import Mathlib.Topology.Defs.Induced
import Mathlib.Topology.UniformSpace.Cauchy
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

universe u

open WeierstrassCurve


structure AnabelianGeometry : Type (u + 1) where
  
  Orbicurve : (k : Type u) → [Field k] → Type u
  
  Cover : {k : Type u} → [Field k] → Orbicurve k → Orbicurve k → Type u
  
  coverComp : {k : Type u} → [Field k] → {X Y Z : Orbicurve k} →
    Cover X Y → Cover Y Z → Cover X Z
  
  baseChange : {k K : Type u} → [Field k] → [Field K] → (k →+* K) →
    Orbicurve k → Orbicurve K
  
  coverBaseChange : {k K : Type u} → [Field k] → [Field K] → (f : k →+* K) →
    {X Y : Orbicurve k} → Cover X Y → Cover (baseChange f X) (baseChange f Y)
  
  oncePunctured : {k : Type u} → [Field k] → (E : WeierstrassCurve k) →
    [E.IsElliptic] → Orbicurve k
  
  pmQuotient : {k : Type u} → [Field k] → Orbicurve k → Orbicurve k
  
  pi1 : {k : Type u} → [Field k] → Orbicurve k → ProfiniteGrp.{u}
  
  pi1Cover : {k : Type u} → [Field k] → {X Y : Orbicurve k} → Cover X Y →
    (pi1 X →* pi1 Y)
  
  pi1Cover_continuous : ∀ {k : Type u} [Field k] {X Y : Orbicurve k} (f : Cover X Y),
    Continuous (pi1Cover f)
  
  pi1Cover_isOpenEmbedding : ∀ {k : Type u} [Field k] {X Y : Orbicurve k}
    (f : Cover X Y), Topology.IsOpenEmbedding (pi1Cover f)
  
  IsCartesianSquare : {k : Type u} → [Field k] → {A B C D : Orbicurve k} →
    Cover A B → Cover B D → Cover A C → Cover C D → Prop
  
  Cusp : {k : Type u} → [Field k] → Orbicurve k → Type u
  
  cuspBaseChange : {k K : Type u} → [Field k] → [Field K] → (f : k →+* K) →
    {X : Orbicurve k} → Cusp X → Cusp (baseChange f X)
  
  HasCore : {k : Type u} → [Field k] → (X C : Orbicurve k) → Prop
  
  IsTypeOneEllTors : {k : Type u} → [Field k] → (ℓ : ℕ) → Orbicurve k → Prop
  
  IsTypeOneEllTorsPM : {k : Type u} → [Field k] → (ℓ : ℕ) → Orbicurve k → Prop
  
  TateStructure : {k : Type u} → [Field k] → [Valued k (WithZero (Multiplicative ℤ))] →
    [Valuation.RankOne (Valued.v : Valuation k (WithZero (Multiplicative ℤ)))] → [CompleteSpace k] →
    Orbicurve k → Type u
  
  IsTypeOneZModPM : {k : Type u} → [Field k] → [Valued k (WithZero (Multiplicative ℤ))] →
    [Valuation.RankOne (Valued.v : Valuation k (WithZero (Multiplicative ℤ)))] → [CompleteSpace k] →
    (ℓ : ℕ) → (X : Orbicurve k) → TateStructure X → Prop
  
  RankOneQuotient : {k : Type u} → [Field k] → Orbicurve k → (ℓ : ℕ) → Type u
  
  cuspOfQuotient : {k : Type u} → [Field k] → (X : Orbicurve k) → (ℓ : ℕ) →
    RankOneQuotient X ℓ → Cusp X

namespace OrbicurveDataSection

variable (AG : AnabelianGeometry.{u})

variable (F : Type u) [Field F] [NumberField F] (E : WeierstrassCurve F) [E.IsElliptic]

variable (Fbar : Type u) [Field Fbar] [Algebra F Fbar]

variable (VBad : Set (NumberField.FinitePlace ↥(fieldOfModuli F E)))


noncomputable def CF : AG.Orbicurve F := AG.pmQuotient (AG.oncePunctured E)

variable (P : AdmissiblePrimeData F E Fbar VBad)


noncomputable def XK : AG.Orbicurve ↥P.torsionField :=
  AG.baseChange (algebraMap F ↥P.torsionField) (AG.oncePunctured E)


noncomputable def CK : AG.Orbicurve ↥P.torsionField :=
  AG.baseChange (algebraMap F ↥P.torsionField) (CF AG F E)


structure OrbicurveData : Type u where
  
  CKu : AG.Orbicurve ↥P.torsionField
  
  CKu_type : AG.IsTypeOneEllTorsPM P.ℓ CKu
  
  CKu_core : AG.HasCore CKu (CK AG F E Fbar VBad P)
  
  XKu : AG.Orbicurve ↥P.torsionField
  
  XKu_type : AG.IsTypeOneEllTors P.ℓ XKu
  
  XKu_to_XK : AG.Cover XKu (XK AG F E Fbar VBad P)
  
  XKu_to_CKu : AG.Cover XKu CKu
  
  XK_to_CK : AG.Cover (XK AG F E Fbar VBad P) (CK AG F E Fbar VBad P)
  
  CKu_to_CK : AG.Cover CKu (CK AG F E Fbar VBad P)
  
  diagram_cartesian : AG.IsCartesianSquare XKu_to_XK XK_to_CK XKu_to_CKu CKu_to_CK
  
  QIso : AG.RankOneQuotient CKu P.ℓ ≃ ZMod P.ℓ
  
  q : AG.RankOneQuotient CKu P.ℓ
  
  q_ne_zero : QIso q ≠ 0
  
  epsilon : AG.Cusp CKu
  
  epsilon_spec : epsilon = AG.cuspOfQuotient CKu P.ℓ q

namespace OrbicurveData

variable {AG F E Fbar VBad P} (O : OrbicurveData AG F E Fbar VBad P)

end OrbicurveData

end OrbicurveDataSection

end Iut

end AbcAdaptation.Reference
