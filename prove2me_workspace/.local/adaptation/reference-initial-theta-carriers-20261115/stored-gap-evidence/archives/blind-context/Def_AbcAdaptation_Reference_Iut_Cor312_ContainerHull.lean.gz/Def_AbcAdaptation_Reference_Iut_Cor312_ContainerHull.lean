import Mathlib.Data.Finite.Defs
import Mathlib.Data.Set.Defs
import Mathlib.Data.Set.Finite.Basic
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Container
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_HolomorphicHull
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_PacketPresentation
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RationalPlace

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

universe u₁ u₂ v

variable {ι : Type u₁} {V : Type u₂}

open LargeVolumeContainerData


structure ContainerHullSystem (D : LargeVolumeContainerData.{u₁, u₂, v} ι V) :
    Type (max u₁ u₂ v) where
  
  system : ∀ (i : Fin D.proc.length) (vQ : RationalPlace), HullSystem (D.packet i vQ)
  
  integral_admissible :
    ∀ i vQ, (D.packet i vQ).integralRegion ∈ (system i vQ).Admissible

namespace ContainerHullSystem

variable {D : LargeVolumeContainerData.{u₁, u₂, v} ι V} (H : ContainerHullSystem D)

variable {i : Fin D.proc.length}


def IsAdmissible (R : D.AdmissibleRegion i) : Prop :=
  ∀ vQ, R.region vQ ∈ (H.system i vQ).Admissible


lemma hull_integralRegion (vQ : RationalPlace) :
    (H.system i vQ).hull (D.packet i vQ).integralRegion =
      (D.packet i vQ).integralRegion :=
  (H.system i vQ).hull_eq_self (H.integral_admissible i vQ) (H.system i vQ).integralRegion_mem


def hullAdmissible (R : D.AdmissibleRegion i) : D.AdmissibleRegion i where
  region vQ := (H.system i vQ).hull (R.region vQ)
  finiteSupport := by
    refine R.finiteSupport.subset fun vQ hvQ h => ?_
    apply hvQ
    rw [h]
    exact H.hull_integralRegion vQ


def hullFamily (R : ∀ i : Fin D.proc.length, D.AdmissibleRegion i) :
    ∀ i : Fin D.proc.length, D.AdmissibleRegion i :=
  fun i => H.hullAdmissible (R i)

end ContainerHullSystem

end Iut

end AbcAdaptation.Reference
