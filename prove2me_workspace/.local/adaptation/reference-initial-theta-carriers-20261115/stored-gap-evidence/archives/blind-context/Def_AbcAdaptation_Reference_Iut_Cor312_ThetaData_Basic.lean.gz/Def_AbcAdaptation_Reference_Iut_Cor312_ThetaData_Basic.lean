import Mathlib.Algebra.Algebra.Defs
import Mathlib.Algebra.Algebra.Rat
import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Field.Rat
import Mathlib.Algebra.Field.Subfield.Defs
import Mathlib.Algebra.Group.Action.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.GroupWithZero.Action.Defs
import Mathlib.Algebra.Module.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Algebra.Ring.Subring.Defs
import Mathlib.Algebra.Ring.Subsemiring.Defs
import Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass
import Mathlib.Data.Set.Defs
import Mathlib.Data.SetLike.Basic
import Mathlib.FieldTheory.IntermediateField.Basic
import Mathlib.FieldTheory.IsAlgClosed.Basic
import Mathlib.LinearAlgebra.Basis.VectorSpace
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace
import Mathlib.RingTheory.DedekindDomain.Basic
import Mathlib.RingTheory.Flat.FaithfullyFlat.Basic
import Mathlib.RingTheory.Flat.TorsionFree
import Mathlib.RingTheory.Henselian
import Mathlib.RingTheory.LocalRing.Defs
import Mathlib.RingTheory.RegularLocalRing.Defs
import Mathlib.RingTheory.SimpleRing.Basic
import Mathlib.RingTheory.SimpleRing.Principal
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateFamily

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

universe u

open NumberField WeierstrassCurve OrbicurveDataSection


structure InitialThetaData (AG : AnabelianGeometry.{u}) (TG : TemperedGeometry AG) :
    Type (u + 1) where
  
  F : Type u
  
  [fieldF : Field F]
  
  [numberFieldF : NumberField F]
  
  Fbar : Type u
  
  [fieldFbar : Field Fbar]
  
  [algebraFbar : Algebra F Fbar]
  
  [isAlgClosure : IsAlgClosure F Fbar]
  
  E : WeierstrassCurve F
  
  [isElliptic : E.IsElliptic]
  
  VBad : Set (FinitePlace ↥(fieldOfModuli F E))
  
  global : IsInitialThetaGlobalData F E Fbar VBad
  
  prime : AdmissiblePrimeData F E Fbar VBad
  
  [numberFieldK : NumberField ↥prime.torsionField]
  
  [algebraModK : Algebra ↥(fieldOfModuli F E) ↥prime.torsionField]
  
  [towerModK : IsScalarTower ↥(fieldOfModuli F E) F ↥prime.torsionField]
  
  tate : TateFamily E prime.torsionField prime.ℓ VBad
  
  orb : OrbicurveData AG F E Fbar VBad prime
  
  localData : LocalThetaData AG TG F E Fbar VBad prime orb

namespace InitialThetaData

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}

attribute [instance] fieldF numberFieldF fieldFbar algebraFbar isAlgClosure isElliptic
  numberFieldK algebraModK towerModK

variable (D : InitialThetaData AG TG)


def ℓ : ℕ := D.prime.ℓ

end InitialThetaData

end Iut

end AbcAdaptation.Reference
