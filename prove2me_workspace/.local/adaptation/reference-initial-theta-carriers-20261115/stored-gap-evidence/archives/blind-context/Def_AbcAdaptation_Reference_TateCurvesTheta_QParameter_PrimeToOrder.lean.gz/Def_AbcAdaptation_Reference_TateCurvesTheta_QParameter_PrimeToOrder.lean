import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Group.Units.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Analysis.Normed.Field.Basic
import Mathlib.Analysis.Normed.Group.Defs
import Mathlib.Data.Real.Basic
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace TateCurvesTheta


def PrimeToOrder (ℓ n : ℕ) : Prop := Nat.Coprime ℓ n

namespace PrimeToOrder

variable {ℓ n : ℕ}

instance decidable (ℓ n : ℕ) : Decidable (PrimeToOrder ℓ n) :=
  inferInstanceAs (Decidable (Nat.Coprime ℓ n))

end PrimeToOrder

variable (K : Type*) [NormedField K]


structure OrderedTateParameter extends TateParameter K where
  
  orderNat : ℕ
  
  orderNat_pos : 0 < orderNat

namespace OrderedTateParameter

variable {K}

variable (t : OrderedTateParameter K)


def PrimeToOrder (ℓ : ℕ) : Prop := TateCurvesTheta.PrimeToOrder ℓ t.orderNat

instance decidable (ℓ : ℕ) : Decidable (t.PrimeToOrder ℓ) :=
  inferInstanceAs (Decidable (Nat.Coprime ℓ t.orderNat))

end OrderedTateParameter

end TateCurvesTheta

end AbcAdaptation.Reference
