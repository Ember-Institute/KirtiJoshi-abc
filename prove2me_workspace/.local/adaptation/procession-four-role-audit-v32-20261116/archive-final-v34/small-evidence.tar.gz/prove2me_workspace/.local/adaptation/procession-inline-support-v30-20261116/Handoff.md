本轮以一个目标节点 sum_card_standard 为单位，不额外扩张成三个平台节点。两条真实source support `Iut.card_procLabels` 和 `Iut.Procession.standard_capsule_card` 完整proof内联为 private lemma，分别放在 named-native-proof 与 global solution 模块里。原 @[simp] 属性作用于私有 card_procLabels；原两个proof body字节不改。它们只是闭合证明内部，原 sum_card 类型没有新增support假设，也不需要为两个内部lemma重做公开独立自然语言读回来阻塞消费者。今后若出现额外实际消费者，可另按真实需求升为具名共享theorem；本轮不先机械发布。

立即入口 `root-ready-plan.json` 包含精确文件、角色名称、源AST和哈希、两种查询配置、现有Definition哈希以及root stage owner。`Theorems/` 是目标by-sorry stub，不含私有support；`NativeProofs/` 是完整原proof的 sum_card_standard_nativeProof（root可字节不变stage到W/Theorems/Thm_<target>_NativeAuditProof.lean）；`Solutions/` 是顶层 theorem solution，含相同闭合private support、无sorry。原类型仍量化任意Procession ℕ、L、原hP等式以及任意ℕ→ℝ函数；未引入AG/TG/X/inv/est，也未把Procession替成裸Fin标量问题。

已发表 `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession` 完全只读，源码SHA为root-ready-plan记录值，本轮不补改Definition。native imports只有该既有Definition、Mathlib.Data.Real.Basic、Mathlib.Data.Fintype.BigOperators、Mathlib.Order.Interval.Finset.Nat，无Theorems依赖、自目标或原完整Iut/Genl模块。两private helper在source与native中的区别仅为private修饰和外层namespace适配，proof/value SHA保持原样；sum_card root完整signature/body也保持。

`SourceProbes/ProcessionCardAndConsumer.lean` 是小型真实source carrier+两条完成support+消费者，使用已有正式来源carrier命令，不导入原Procession/Theorem110全模块和自己的目标。`source-proof-oracle-config.json` 复用主区已有ExtractSmallRuntimeOracle，root在原4.35环境通过MCP-CI执行即可。它将输出原support/目标的actual AST/InfoTree refs，不做巨export。

`QuerySourceTypeFacts.lean` 是root当前已通过独立两节点1根type-only工具的字节副本，三个 `TypeOracleConfigs/*.json` 每次只取一个actual public源名称、确切source owner。它可在cached原Theorem110环境读source TYPE，但严格不读selected root theorem proof；此行为与独立proof oracle区分。allowedDataNames由实际graph directTypeDeps选出，仅是真实Procession数据常量，必须在native审查时映到未变已发表carrier，不能用data allowlist代替身份。返回schema沿用pure-arithmetic-original-type-facts/v9、records=1。actual source helperproof本身由独立InfoTree源码执行供应。

四角色门仍由root验收：实际source TYPE、target stub、named native proof、global solution。Root在native elaboration后按actual userName+owner解析两条_private helper的真实Name，不能手工猜numeric private前缀；将两条完整source proof映到这些actual私有声明审查type/标准公理闭包。闭合proof内部不需要新增假设，也不降低原parent目标。

`actual-parent-reverse-dependencies.json` 从实际c22声明graph逐项取type/value反向边，记录support API的实际source消费者及sum_card被原theorem110消费的边。此次实际c22闭包中每条source helper各有一个直接value消费者；本轮只在sum_card证明模块内部复制proof，不改变其它owner或把该闭包结果扩大为仓库全域引用统计。原source DAG是 card_procLabels → standard_capsule_card → sum_card_standard → theorem110。

`frozen-consumer-readback.json` 原样复制已有Reader B冻结三语row，英文/中文/日文及proof状态句完全不改，不夹入新support说明。`formal-only/` 只含三个角色代码、source probe和实际carrier定义，无论文说明/此前读回答案。OriginalCommands与LICENSE留原证据。所有proof body保持，已离线核对global/namedproof末段SHA与原一致，两个support完整原命令保留在source probe中。

每个新leaf首次expected_duration=60s、expected_memory=16GiB。所有源码/TYPE/角色编译和资源调度均由root统一exclusive MCP-CI；本轮没有CI、编译、API、Git或主区写。所有实际类型/BinderInfo/公理/平台验收仍pending，不等待main5，也不自行填Act2数学。
