from pathlib import Path
import importlib.util
def prepare():
    p=Path(__file__).resolve().parent.parent/'prepare_platform.py'
    s=importlib.util.spec_from_file_location('offline_procession_platform_prepare',p)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    return m.prepare()
