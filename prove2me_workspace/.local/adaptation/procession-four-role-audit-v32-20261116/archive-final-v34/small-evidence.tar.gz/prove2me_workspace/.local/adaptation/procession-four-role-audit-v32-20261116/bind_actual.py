#!/usr/bin/env python3
"""Bind existing successful Procession receipts and source facts; no CI/API/Git.
Only the chosen task-local output config is written. Private actual Names remain
runtime lookups by userName and owner, never guessed numeric prefixes.
"""
from pathlib import Path
import argparse
import hashlib
import json

D = Path(__file__).resolve().parent
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A = W / '.local/adaptation'
C = A / 'main-chain-open-20261116'
DEFAULT_UNIT = A / 'procession-inline-support-v30-20261116'


def read(path):
    return json.loads(Path(path).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    path = Path(path).resolve()
    assert path.stat().st_size < 16 * 1024 ** 2, 'Use the actual compact facts, not a giant export'
    return {'path': str(path), 'sha256': sha(path.read_bytes()), 'contents': read(path)}


def receipt(path, expected_source=None):
    row = binding(path)
    result = row['contents']
    assert result['status'] == 'succeeded' and result['result']['exit_code'] == 0
    assert result['result']['snapshot']['workspace_mode'] == 'exclusive_worktree'
    assert result['result']['snapshot']['snapshot_id'] is None
    if expected_source is not None:
        assert result['request']['worktree_manifest']['input_hashes'][str(expected_source)] == sha(expected_source.read_bytes())
    return row


def unique(raw, piece):
    assert piece and raw.count(piece) == 1, 'Signature/proof source must have one exact byte slice'
    start = raw.index(piece)
    return [start, start + len(piece)]


def source_type(unit, source_name):
    key = source_name.replace('.', '_')
    path = unit / 'type-facts' / (key + '.json')
    result_path = C / ('procession-' + key + '-source-type-v30-result.json')
    row, result = binding(path), receipt(result_path)
    facts = row['contents']
    assert facts['schema'] == 'pure-arithmetic-original-type-facts/v9'
    assert facts['rootTheoremProofsRead'] is False and len(facts['records']) == 1
    assert facts['records'][0]['name'] == source_name
    config_path = Path(result['contents']['request']['environment']['PURE_TYPE_SOURCE_CONFIG'])
    assert read(config_path) == facts['configuration']
    assert result['contents']['request']['worktree_manifest']['input_hashes'][str(config_path)] == sha(config_path.read_bytes())
    return row, result


def bind(unit, output, final_output):
    cfg = read(D / 'config.template.json')
    native_path = Path(cfg['nativeInstalledSource'])
    stub_path = Path(cfg['stubInstalledSource'])
    solution_path = Path(cfg['solutionInstalledSource'])
    native, stub, solution = [path.read_bytes() for path in [native_path, stub_path, solution_path]]
    cfg['expectedNativeText'], cfg['expectedStubText'], cfg['expectedSolutionText'] = [raw.decode() for raw in [native, stub, solution]]
    cfg['nativeReceiptBindings'] = [receipt(C / name, native_path) for name in [
        'procession-sum-card-native-leaf-v30-result.json', 'procession-sum-card-native-artifact-v31-result.json']]
    cfg['stubReceiptBindings'] = [receipt(C / name, stub_path) for name in [
        'procession-sum-card-stub-leaf-v30-result.json', 'procession-sum-card-stub-artifact-v31-result.json']]
    cfg['solutionReceiptBindings'] = [receipt(C / name, solution_path) for name in [
        'procession-sum-card-solution-leaf-v30-result.json', 'procession-sum-card-solution-artifact-v31-result.json']]
    subset = binding(D / 'accepted-data-map-subset.json')
    original_map = subset['contents']['sourceMap']
    assert sha(Path(original_map['path']).read_bytes()) == original_map['sha256']
    accepted_pairs = read(original_map['path'])['namedPairs']
    assert all(pair in accepted_pairs for pair in subset['contents']['namedPairs'])
    foundation_path = Path(subset['contents']['acceptedReceipt']['path'])
    cfg['acceptedFoundationReceipt'] = receipt(foundation_path)
    assert cfg['acceptedFoundationReceipt']['contents']['job_id'] == 'ci-013377-98675e26'
    cfg['acceptedDataMapBinding'] = subset
    cfg['dependencyReceiptBindings'] = [cfg['acceptedFoundationReceipt']]
    definition = Path(cfg['definitionSource'])
    expected = read(unit / 'root-ready-plan.json')['existingDefinition']['sha256']
    assert sha(definition.read_bytes()) == expected == '3b39ff044c0cf2bcc03e79c6bb6a5b8a852535aa381103f3731a60e026b910d5'
    cfg['expectedDefinitionText'] = definition.read_text()
    source_root = cfg['sourceName']
    cfg['sourceTypeFactsBinding'], cfg['sourceTypeReceipt'] = source_type(unit, source_root)
    oracle_receipt = receipt(C / 'procession-source-proof-original-context-v31-result.json')
    assert oracle_receipt['contents']['job_id'] == 'ci-017230-2e01fd2b'
    index_path = unit / 'oracle-output-context-fixed-v31/index.json'
    index = binding(index_path)
    ix = index['contents']
    assert ix['complete'] is True and ix['requestedFiles'] == ix['finishedFiles'] == 1
    result, = ix['results']
    assert result['status'] == 'success'
    diag = binding(result['diagnostics'])
    assert diag['contents']['hasErrors'] is False
    assert read(ix['configPath']) == ix['config']
    assert oracle_receipt['contents']['request']['parameters']['args'][-1] == ix['configPath']
    coordinate_path = Path(result['coordinateSource'])
    coordinate = coordinate_path.read_bytes()
    assert sha(coordinate) == ix['config']['files'][0]['normalizedSha256']
    facts_path = Path(result['output'])
    rows = [json.loads(line) for line in facts_path.read_text().splitlines() if line]
    assert rows[-1]['kind'] == 'summary' and rows[-1]['status'] == 'success'
    assert sum(row['kind'] == 'decl' for row in rows) == result['declarationCount']
    assert sum(row['kind'] == 'ref' for row in rows) == result['referenceCount']
    commands = {row['name']: row for row in read(unit / 'root-ready-plan.json')['sourceCommands']}
    extracts = {}
    for original in [source_root, 'Iut.card_procLabels', 'Iut.Procession.standard_capsule_card']:
        short = original.split('.')[-1]
        decl, = [row for row in rows if row['kind'] == 'decl' and row.get('nameText') == short]
        assert decl['generationIssue'] is None
        name_end = decl['nameRange']['end']['offset']
        value_start = decl['valStart']['offset']
        value_end = decl['declEnd']['offset']
        signature, proof = coordinate[name_end:value_start], coordinate[value_start:value_end]
        assert sha(proof) == commands[original]['proofSha256']
        # The root proof starts with := by, while card_procLabels is an exact
        # term proof. Preserve both actual source forms unchanged.
        extracts[original] = {'decl': decl, 'signature': signature, 'proof': proof,
            'signatureRange': [name_end, value_start], 'proofRange': [value_start, value_end]}
    root = extracts[source_root]
    cfg['sourceBinding'] = {'oracleReceipt': oracle_receipt, 'oracleIndex': index,
        'oracleDiagnostics': diag, 'oracleFactsPath': str(facts_path),
        'oracleFactsText': facts_path.read_text(), 'oracleFactsSha256': sha(facts_path.read_bytes()),
        'oracleCoordinateSource': str(coordinate_path), 'oracleCoordinateText': coordinate.decode(),
        'oracleCoordinateSha256': sha(coordinate), 'actualDecl': root['decl'],
        'sourceSignatureText': root['signature'].decode(), 'sourceProofText': root['proof'].decode()}
    cfg['proofByteEvidence'] = {'sourceProofSha256': sha(root['proof']),
        'nativeSignatureByteRange': unique(native, root['signature']),
        'nativeProofByteRange': unique(native, root['proof']),
        'solutionSignatureByteRange': unique(solution, root['signature']),
        'solutionProofByteRange': unique(solution, root['proof'])}
    supports = []
    direct_names = set()
    for name in [source_root, 'Iut.card_procLabels', 'Iut.Procession.standard_capsule_card']:
        type_facts, type_receipt = source_type(unit, name)
        direct_names.update(type_facts['contents']['configuration']['allowedDataNames'])
        if name == source_root:
            continue
        part = extracts[name]
        user_name = 'AbcAdaptation.Reference.' + name
        encoded = []
        for piece in user_name.split('.'):
            encoded = [encoded, 'str', piece]
        supports.append({'sourceName': name, 'targetUserNameExpr': encoded,
            'sourceTypeFactsBinding': type_facts, 'sourceTypeReceipt': type_receipt,
            'sourceSignatureText': part['signature'].decode(), 'sourceProofText': part['proof'].decode(),
            'sourceSignatureByteRange': part['signatureRange'], 'sourceProofByteRange': part['proofRange'],
            'nativeSignatureByteRange': unique(native, part['signature']),
            'nativeProofByteRange': unique(native, part['proof']),
            'solutionSignatureByteRange': unique(solution, part['signature']),
            'solutionProofByteRange': unique(solution, part['proof']),
            'actualPrivateName': None})
    assert direct_names == {'Iut.procLabels','Iut.Capsule.card','Iut.Procession',
        'Iut.Procession.capsule','Iut.Procession.length','Iut.Procession.standard'}
    cfg['inlineSupportBindings'] = supports
    cfg['finalOutput'] = str(final_output.resolve())
    output = output.resolve()
    assert output.is_relative_to(D), 'Only write this temporary task directory'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + '\n')
    return {'config': str(output), 'sha256': sha(output.read_bytes()), 'actualSourceJob': 'ci-017230-2e01fd2b',
        'threeRoleArtifactsBound': True, 'privateNames': 'runtime userName+owner lookup pending actual query',
        'queryCompiledByThisAgent': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--unit', type=Path, default=DEFAULT_UNIT)
    parser.add_argument('--out', type=Path, default=D / 'bound/config.actual.json')
    parser.add_argument('--final-output', type=Path, default=D / 'actual/procession-four-role-audit.json')
    args = parser.parse_args()
    print(json.dumps(bind(args.unit.resolve(), args.out, args.final_output), ensure_ascii=False, indent=2))
