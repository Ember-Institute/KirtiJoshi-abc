#!/usr/bin/env python3
"""Specialize the corrected existing four-role query to one Procession consumer.
Only task-local generation. Does not compile, invoke CI/API/Git, or edit W.
"""
from pathlib import Path
import hashlib
import json

D = Path(__file__).resolve().parent
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A = W / '.local/adaptation'
TEMPLATE = A / 'independent-two-four-role-v25-20261116/queries/FourRoles_Iut_Theorem110Invariants_sum_arch.lean'
U = A / 'procession-inline-support-v30-20261116'


def read(path):
    return json.loads(Path(path).read_text())


def pin(path):
    path = Path(path)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def enc(name):
    result = []
    for part in name.split('.'):
        result = [result, 'str', part]
    return result


def prepare():
    (D / 'actual').mkdir(exist_ok=True)
    source = TEMPLATE.read_text()
    body_start = source.index('def fourRoleAudit :')
    common = source[source.index('/-! Stable JSON'):source.index('def dependencyAudit (cfg : Json)')]
    pairs = read(D / 'accepted-data-map-subset.json')['namedPairs']
    mapping = [(row['original'], row['target']) for row in pairs] + [(row['target'], row['target']) for row in pairs]
    literal = '#[' + ',\n  '.join('(`' + original + ', `' + target + ')' for original, target in mapping) + ']'
    assert common.count('def nativeDataNames : TypeNames := #[]') == 1
    common = common.replace('def nativeDataNames : TypeNames := #[]', 'def nativeDataNames : TypeNames := ' + literal)
    assert common.count('!queue.contains n then queue := queue.push n') == 1
    assert common.count('!queue.contains dep then queue := queue.push dep') == 1
    common = common.replace('!queue.contains n then queue := queue.push n',
        '!(nativeDataNames.any fun pair => pair.2 == n) && !queue.contains n then queue := queue.push n')
    common = common.replace('!queue.contains dep then queue := queue.push dep',
        '!(nativeDataNames.any fun pair => pair.2 == dep) && !queue.contains dep then queue := queue.push dep')
    # Existing approved Definition identity is reused; this checks only the
    # installed accepted data owner/axiom closure, not a fresh identity proof.
    common += '''def dependencyAudit (cfg : Json) : MetaM (Array Name × Array Json) := do
  discard (passedReceipt (← checked (field cfg "acceptedFoundationReceipt")))
  let accepted ← boundJson (← checked (field cfg "acceptedDataMapBinding"))
  let definitionText ← IO.FS.readFile (← checked (stringField cfg "definitionSource"))
  unless definitionText == (← checked (stringField cfg "expectedDefinitionText")) do
    throwError "Existing published Procession Definition source changed"
  let owner := `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
  let mut axs : Array Name := #[]
  let mut rows := #[]
  for pair in ← checked (arrayField accepted "namedPairs") do
    unless (← checked (stringField pair "acceptedJob")) == "ci-013377-98675e26" do
      throwError "Unaccepted source data mapping"
    let n ← checked (decodeName (← checked (field pair "targetName")))
    unless moduleOf (← getEnv) n == some owner do throwError "Wrong accepted Procession data owner {n}"
    let actual ← collectAxioms n
    ensureStandard s!"accepted Procession data closure {n}" actual
    for ax in actual do unless axs.contains ax do axs := axs.push ax
    rows := rows.push (Json.mkObj [("name",toJson n.toString),("owner",encodeName owner),
      ("acceptedJob",toJson "ci-013377-98675e26"),("axioms",toJson (actual.map Name.toString))])
  unless rows.size == 7 do throwError "Keep the existing six direct TYPE data names plus Capsule type closure"
  return (axs.qsort Name.lt, rows)

'''
    common += (D / 'inline-support.lean.txt').read_text() + '\n'
    body = source[body_start:]
    start = body.index('  let nativeBinding ←')
    end = body.index('  let n ←', start)
    direct = '''  requireReceipts (← checked (field cfg "nativeReceiptBindings"))
  let nativeName ← checked (decodeName (← checked (field cfg "nativeNameExpr")))
  let nativeOwner ← checked (decodeName (← checked (field cfg "nativeModule")))
  let nativeCi ← getConstInfo nativeName
  unless moduleOf (← getEnv) nativeName == some nativeOwner do throwError "Wrong actual native proof owner"
  let nativeValue ← actualTargetProof nativeCi
  let directNativeAxioms ← collectAxioms nativeName
  let directNativeTypeAxioms ← expressionAxioms nativeCi.type
  let directNativeValueAxioms ← expressionAxioms nativeValue
  for xs in #[directNativeAxioms,directNativeTypeAxioms,directNativeValueAxioms] do ensureStandard "actual native role" xs
  let directNativeSorry := nativeValue.getUsedConstants.contains `sorryAx
  unless !directNativeSorry && !directNativeAxioms.contains `sorryAx do throwError "Actual native proof has sorry"
  let nativeText ← IO.FS.readFile (← checked (stringField cfg "nativeInstalledSource"))
  unless nativeText == (← checked (stringField cfg "expectedNativeText")) do throwError "Installed native source changed"
  let directNativeTypeProofs ← typeProofRows #[nativeCi.type]
  validateProofRows directNativeTypeProofs
  let native := Json.mkObj [("schema",toJson "pure-historical-native-type-facts/v13"),
    ("targetName",← checked (field cfg "targetName")),("nativeName",toJson nativeName.toString),
    ("actualRawTypeExpr",← checked (encodeExpr nativeCi.type)),
    ("levelParams",Json.arr (nativeCi.levelParams.toArray.map encodeName)),
    ("typeProofValues",Json.arr directNativeTypeProofs),("nativeSourceText",toJson nativeText),
    ("nativeAxioms",toJson (directNativeAxioms.map Name.toString)),
    ("nativeBodyDirectSorryAx",toJson directNativeSorry),
    ("nativeHasTransitiveSorryAx",toJson (directNativeAxioms.contains `sorryAx))]
  let inlineSupportRows ← actualPrivateSupportAudit cfg
'''
    body = body[:start] + direct + body[end:]
    old_output = '("schema",toJson "pure-source-native-stub-global-solution-audit/v13"),'
    assert body.count(old_output) == 1
    body = body.replace(old_output, old_output + '\n    ("inlinePrivateSupportRows",Json.arr inlineSupportRows),')
    imports = ['Theorems.Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_card_standard_NativeAuditProof',
        'Theorems.Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_card_standard',
        'Solutions.Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_card_standard']
    query = D / 'AuditProcessionFourRoles.lean'
    query.write_text('import Lean\n' + ''.join('import ' + module + '\n' for module in imports) + '\n' + common + body)
    target = 'AbcAdaptation.Reference.Iut.Theorem110Invariants.sum_card_standard'
    cfg = {'schema': 'pure-four-role-config/v13', 'publish': False,
        'short': 'sum_card_standard', 'sourceName': 'Iut.Theorem110Invariants.sum_card_standard',
        'targetName': target, 'targetNameExpr': enc(target),
        'nativeName': target + '_nativeProof', 'nativeNameExpr': enc(target + '_nativeProof'),
        'nativeModule': enc(imports[0]), 'theoremModule': enc(imports[1]), 'solutionModule': enc(imports[2]),
        'nativeInstalledSource': str(W / Path(imports[0].replace('.', '/')).with_suffix('.lean')),
        'stubInstalledSource': str(W / Path(imports[1].replace('.', '/')).with_suffix('.lean')),
        'solutionInstalledSource': str(W / Path(imports[2].replace('.', '/')).with_suffix('.lean')),
        'sourceTypeReceipt': None, 'sourceTypeFactsBinding': None, 'sourceBinding': None,
        'nativeReceiptBindings': None, 'stubReceiptBindings': None, 'solutionReceiptBindings': None,
        'expectedNativeText': None, 'expectedStubText': None, 'expectedSolutionText': None,
        'proofByteEvidence': None, 'acceptedFoundationReceipt': None, 'acceptedDataMapBinding': None,
        'definitionSource': str(W / 'Definitions/Def_AbcAdaptation_Reference_Iut_Cor312_Procession.lean'),
        'expectedDefinitionText': None, 'dependencyReceiptBindings': None,
        'registeredDependencyNames': [], 'inlineSupportBindings': None,
        'finalOutput': str(D / 'actual/procession-four-role-audit.json'),
        'actualAcceptedFlags': None,
        'note': 'One target only; two private support Names are discovered by userName+actual owner. No numeric private prefix or new data identity is invented.'}
    (D / 'config.template.json').write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + '\n')
    (D / 'query-manifest.json').write_text(json.dumps({'query': pin(query), 'template': pin(TEMPLATE),
        'discardCorrectionReused': True, 'fourRoleSchemaUnchanged': True, 'dataMap': pin(D / 'accepted-data-map-subset.json'),
        'supportImplementation': pin(D / 'inline-support.lean.txt'),
        'sourceTypeRoots': ['Iut.card_procLabels','Iut.Procession.standard_capsule_card','Iut.Theorem110Invariants.sum_card_standard'],
        'configurationEnvironmentVariable': 'PURE_FOUR_ROLE_CONFIG', 'typecheckStatus': 'not run by this agent',
        'platformTargets': [target], 'supportPlatformTargets': [], 'newIdentityGate': False}, ensure_ascii=False, indent=2) + '\n')
    return cfg


if __name__ == '__main__':
    prepare()
    print('Prepared one unbound Procession four-role query; no compiler or CI invoked.')
