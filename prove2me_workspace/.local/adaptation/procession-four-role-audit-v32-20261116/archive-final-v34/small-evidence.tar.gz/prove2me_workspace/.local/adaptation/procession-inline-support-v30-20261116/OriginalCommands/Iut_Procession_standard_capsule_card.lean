/-- The `i`-th capsule of the standard procession has `i + 2` labels: it is the label
set `S_{j+1}` with `j = i + 1`, of cardinality `j + 1`. -/
lemma standard_capsule_card (n : ℕ) (i : Fin n) :
    ((standard n).capsule i).card = i + 2 := by
  simp [Capsule.card, standard]
