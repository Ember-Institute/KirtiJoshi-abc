@[simp]
lemma card_procLabels (j : ℕ) : (procLabels j).card = j + 1 := Nat.card_Iic j
