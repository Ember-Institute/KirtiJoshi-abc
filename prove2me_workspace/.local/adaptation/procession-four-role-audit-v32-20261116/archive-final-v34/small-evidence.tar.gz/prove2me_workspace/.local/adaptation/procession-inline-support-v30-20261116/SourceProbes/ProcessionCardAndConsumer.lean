/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Mathlib.Basic.Real.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Basic.SetLike.Basic
import Mathlib.Data.Finset.Attach
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Defs
import Mathlib.Data.Fintype.Defs
import Mathlib.Data.Nat.Basic
import Mathlib.Order.Defs.PartialOrder
import Mathlib.Order.Interval.Finset.Basic
import Mathlib.Order.Interval.Finset.Defs
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Order.Nat
set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators

namespace Iut


def procLabels (j : ℕ) : Finset ℕ := Finset.Iic j

lemma procLabels_mono {i j : ℕ} (h : i ≤ j) : procLabels i ⊆ procLabels j :=
  Finset.Iic_subset_Iic.mpr h


structure Capsule (ι : Type*) where
  
  labels : Finset ι

namespace Capsule

variable {ι : Type*}


def card (S : Capsule ι) : ℕ := S.labels.card


def LabelType (S : Capsule ι) : Type _ := S.labels

instance [DecidableEq ι] (S : Capsule ι) : DecidableEq S.LabelType :=
  inferInstanceAs (DecidableEq S.labels)

instance (S : Capsule ι) : Fintype S.LabelType :=
  inferInstanceAs (Fintype S.labels)

end Capsule


structure Procession (ι : Type*) where
  
  length : ℕ
  
  capsule : Fin length → Capsule ι
  
  labels_mono : ∀ ⦃i j : Fin length⦄, i ≤ j → (capsule i).labels ⊆ (capsule j).labels

namespace Procession

variable {ι : Type*} (P : Procession ι)


def standard (n : ℕ) : Procession ℕ where
  length := n
  capsule i := ⟨procLabels (i + 1)⟩
  labels_mono i j h := procLabels_mono (by exact Nat.add_le_add_right h 1)

end Procession

end Iut

namespace Iut
@[simp]
lemma card_procLabels (j : ℕ) : (procLabels j).card = j + 1 := Nat.card_Iic j
namespace Procession
/-- The `i`-th capsule of the standard procession has `i + 2` labels: it is the label
set `S_{j+1}` with `j = i + 1`, of cardinality `j + 1`. -/
lemma standard_capsule_card (n : ℕ) (i : Fin n) :
    ((standard n).capsule i).card = i + 2 := by
  simp [Capsule.card, standard]
end Procession
namespace Theorem110Invariants
/-- The sum over the capsules of the standard procession of a function of the capsule
cardinalities. -/
lemma sum_card_standard {P : Procession ℕ} {L : ℕ} (hP : P = Procession.standard L)
    (f : ℕ → ℝ) :
    ∑ i : Fin P.length, f (P.capsule i).card = ∑ i : Fin L, f (i + 2) := by
  subst hP
  change (∑ i : Fin L, f ((Procession.standard L).capsule i).card) =
    ∑ i : Fin L, f (i + 2)
  exact Finset.sum_congr rfl fun i _ =>
    congrArg f (Procession.standard_capsule_card L i)
end Theorem110Invariants
end Iut
