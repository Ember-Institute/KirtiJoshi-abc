"""Offline three-source-command port; support proofs stay private in proof modules."""
from pathlib import Path
import json, hashlib, shutil
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
O=Path('/tmp/p2m-procession-inline-support-v26-20261116')
G=W/'.local/adaptation/main-chain-open-20261116/tools/generated'
N='Iut.Theorem110Invariants.sum_card_standard'
T='AbcAdaptation.Reference.'+N
P=W/'.local/adaptation/foundation-reference-carriers-20261115/parser-output/Iut-Cor312-Procession.jsonl'
DEF=W/'Definitions/Def_AbcAdaptation_Reference_Iut_Cor312_Procession.lean'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dg(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def walk(x):
 yield x
 for y in x.get('children',[]):yield from walk(y)
def load_decl(facts,short):
 return next(r for r in facts if r.get('kind')=='decl' and (r.get('nameText')==short or any(n.get('identifier')==short for i in r.get('declarationIds',[]) for n in walk(i))))

def prepare():
 facts=[json.loads(l) for l in P.read_text().splitlines()];coord=Path(next(r for r in facts if r['kind']=='source')['coordinateSource']);data=coord.read_bytes();entries=[]
 for name in ['Iut.card_procLabels','Iut.Procession.standard_capsule_card']:
  d=load_decl(facts,name.rsplit('.',1)[-1]);r=d['range'];a,b=[r[k]['offset'] for k in ['start','end']];pr=d['proofAndDefinitionBodyRanges'][0];pa,pb=[pr[k]['offset'] for k in ['start','end']];nr=d['nameRanges'][0];na=nr['start']['offset'];raw=data[a:b]
  # The keyword is an actual AST atom. Insert private at the lemma token only.
  keyword=next(k for k in d['keywordSyntax'] if k.get('atom')=='lemma');ka=keyword['range']['start']['offset'];assert data[ka:ka+5]==b'lemma';private=raw[:ka-a]+b'private '+raw[ka-a:]
  entries.append({'name':name,'raw':raw,'private':private,'range':r,'proofRange':pr,'proofSha256':dg(data[pa:pb]),'privateInsertionUtf8Offset':ka,'nameExpr':next(x['nameExpr'] for x in read(W/'.local/adaptation/main-pure-type-identity-20261116/source-config.json')['roots'] if False) if False else None})
 m=read(G/'metadata/Iut_Theorem110Invariants_sum_card_standard.json');parent_coord=Path(m['originalCoordinateSource']);parent_bytes=parent_coord.read_bytes();a,b=[m['originalRange'][k]['offset'] for k in ['start','end']];pr=m['proofAndDefinitionBodyRanges'][0];pa,pb=[pr[k]['offset'] for k in ['start','end']];raw=parent_bytes[a:b];assert raw+b'\n'==Path(m['originalWholeCommand']['path']).read_bytes();assert dg(parent_bytes[pa:pb])==m['originalBodyHashes'][0]
 parser=Path(m['parserEvidence']['path']);pf=[json.loads(l) for l in parser.read_text().splitlines()];d=load_decl(pf,'sum_card_standard');nr=d['nameRanges'][0];na,nb=[nr[k]['offset'] for k in ['start','end']];sig=parent_bytes[nb:pa];body=parent_bytes[pa:pb]
 notice=b'''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
'''
 base=notice+b'''import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Mathlib.Data.Real.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Order.Interval.Finset.Nat

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators

'''
 inline=b'namespace AbcAdaptation.Reference.Iut\n'+entries[0]['private']+b'\nnamespace Procession\n'+entries[1]['private']+b'\nend Procession\nend AbcAdaptation.Reference.Iut\n\nopen AbcAdaptation.Reference.Iut\n\n'
 nativeprefix=base+inline+b'theorem '+(T+'_nativeProof').encode()+sig
 solutionprefix=base+inline+b'theorem solution'+sig
 stub=base+b'open AbcAdaptation.Reference.Iut\n\ntheorem '+T.encode()+sig+b':= by sorry\n'
 files={'Theorems/Thm_'+T.replace('.','_')+'.lean':stub,'NativeProofs/Thm_'+T.replace('.','_')+'_NativeAuditProof.lean':nativeprefix+body+b'\n','Solutions/Sol_'+T.replace('.','_')+'.lean':solutionprefix+body+b'\n'}
 for rel,code in files.items():write(O/rel,code)
 for e in entries:write(O/'OriginalCommands'/(e['name'].replace('.','_')+'.lean'),e['raw']+b'\n')
 write(O/'OriginalCommands/Iut_Theorem110Invariants_sum_card_standard.lean',raw+b'\n')
 # Reuse the already created, small exact-source carrier/proof bundle. It imports no
 # original Procession/Theorem110 module, and contains only carrier+two actual helpers+consumer.
 old=Path('/tmp/p2m-main-next-independent-two-v10-20261116/ProcessionSupport/SourceProbes/ProcessionCardAndConsumer.lean');source=old.read_bytes();write(O/'SourceProbes/ProcessionCardAndConsumer.lean',source)
 source_path=O/'SourceProbes/ProcessionCardAndConsumer.lean';oracle={'outputDir':str(O/'oracle-output'),'namePrefixes':[],'options':[{'name':'relaxedAutoImplicit','type':'bool','value':False},{'name':'maxSynthPendingDepth','type':'nat','value':3}],'files':[{'module':'AbcSourceOracle.ProcessionInlineSupport','file':'ProcessionCardAndConsumer.lean','source':str(source_path),'sourceSha256':dg(source),'normalizedSha256':dg(source)}]};save(O/'source-proof-oracle-config.json',oracle)
 # Reuse the existing one-root type-only query. It may import cached full source for
 # TYPE only; proof oracles above remain independent and never import the goal.
 query=W/'.local/adaptation/independent-source-helpers-two-v24-20261116/QueryIndependentTypeFacts.lean';shutil.copyfile(query,O/'QuerySourceTypeFacts.lean')
 graph=[]
 for line in (W/'.local/adaptation/reference-extraction-20261115/c22-decl-graph.jsonl').read_text().splitlines():graph.append(json.loads(line))
 by={r.get('name'):r for r in graph};names=[e['name'] for e in entries]+[N];configs=[]
 for name in names:
  g=by[name];owner=g['module'];src_coord=coord if owner=='Iut.Cor312.Procession' else parent_coord;source_path=W.parent/'refer/iut'/(owner.replace('.','/')+'.lean');rootsyntax=[]
  # Name components are existing actual compiler graph display strings for these public names.
  # Bind the exact AST identifier and owner; source exporter serializes actual Name from env.
  expr=[]
  for part in name.split('.'):expr=[expr,'str',part]
  cfg={'schema':'pure-arithmetic-type-source-config/v9','publish':False,'roots':[{'name':name,'nameExpr':expr}],'expectedRootCount':1,'sourceModule':owner,'sourceSha256':sha(source_path),'allowedDataNames':[x for x in g['directTypeDeps'] if x.startswith('Iut.')],'outputFile':str(O/'type-facts'/(name.replace('.','_')+'.json')),'mode':'TYPE ONLY; one real source theorem signature; no selected theorem proof value read. Project data names must be mapped to the unchanged published Procession carrier at native audit.','source':{'path':str(source_path),'sha256':sha(source_path)},'effectiveAstCoordinate':{'path':str(src_coord),'sha256':sha(src_coord)}};p=O/'TypeOracleConfigs'/(name.replace('.','_')+'.json');save(p,cfg);configs.append(str(p))
 # Full reverse actual dependency slice; do not infer a paper theorem or global closure.
 reverse=[]
 for name in names:
  users=[]
  for g in graph:
   for edge,key in [('type','typeDeps'),('value','valueDeps')]:
    if name in g.get(key,[]):users.append({'name':g['name'],'module':g['module'],'edge':edge})
  reverse.append({'sourceName':name,'consumers':users})
 save(O/'actual-parent-reverse-dependencies.json',{'graph':{'path':str(W/'.local/adaptation/reference-extraction-20261115/c22-decl-graph.jsonl'),'sha256':sha(W/'.local/adaptation/reference-extraction-20261115/c22-decl-graph.jsonl')},'rows':reverse,'consumerPreserved':'Iut.Theorem110Invariants.theorem110 uses sum_card_standard; original Procession support public names remain source-side, native copies are private inline proof details.'})
 # Frozen consumer text, byte/JSON equality; no separate platform publication/readback of supports.
 rbpath=Path('/tmp/p2m-main-proof-trilingual-b-v9-20261116/trilingual-readbacks.json');rb=next(r for r in read(rbpath)['nodes'] if r['sourceName']==N);save(O/'frozen-consumer-readback.json',rb)
 summary={'schema':'procession-inline-support-3source-1target/v26','decision':'Inline the two closed original support proofs as private lemma declarations in each named-native-proof/global-solution module. Publish/reuse only sum_card_standard. No new Definition or support platform theorem nodes.', 'sourceCommands':[ {k:v for k,v in e.items() if k not in ['raw','private','nameExpr']} for e in entries]+[{'name':N,'range':m['originalRange'],'proofRange':pr,'proofSha256':dg(body)}], 'sourceAst':{'path':str(P),'sha256':sha(P),'coordinate':str(coord),'coordinateSha256':sha(coord)},'consumerSourceAst':m['parserEvidence'],'roleFiles':{k:{'path':str(O/k),'sha256':dg(v)} for k,v in files.items()},'nativeRoleName':T+'_nativeProof','targetRoleName':T,'solutionRoleName':'solution','nativePhysicalStage':'Theorems/Thm_'+T.replace('.','_')+'_NativeAuditProof.lean','nativeOwner':'Theorems.Thm_'+T.replace('.','_')+'_NativeAuditProof','namedProofBodyRange':[len(nativeprefix),len(nativeprefix)+len(body)],'solutionProofBodyRange':[len(solutionprefix),len(solutionprefix)+len(body)],'existingDefinition':{'path':str(DEF),'sha256':sha(DEF),'modified':False},'sourceProofOracleConfig':str(O/'source-proof-oracle-config.json'),'sourceRuntimeDriver':{'path':str(W/'.local/adaptation/reference-volume-tate-carriers-20261115/ExtractSmallRuntimeOracle.lean'),'sha256':sha(W/'.local/adaptation/reference-volume-tate-carriers-20261115/ExtractSmallRuntimeOracle.lean')},'sourceTypeQuery':str(O/'QuerySourceTypeFacts.lean'),'sourceTypeEnvironmentVariable':'PURE_TYPE_SOURCE_CONFIG','sourceTypeConfigs':configs,'privateTargetNamePolicy':'Root resolves actual compiler private Names by userName+owner after elaboration; do not guess numeric _private names. Map original two helper proofs to those actual private declarations for closure/source audit.','rootFourRoleGate':'source TYPE + stub + named native proof + global solution; preserve BinderInfo and actual inline helper source/type/standard-axiom closure. Helpers are proof internals, not hidden assumptions.','frozenReadback':{'path':str(rbpath),'sha256':sha(rbpath),'stringsChanged':False},'firstEveryNewLeaf':{'expected_duration':'60s','expected_memory':'16GiB'},'mainFiveRequired':False,'compiled':False,'CIInvoked':False,'apiInvoked':False}
 save(O/'root-ready-plan.json',summary)
 assert all(b'sorry' not in v.split() for k,v in files.items() if not k.startswith('Theorems/'))
 return summary
if __name__=='__main__':print(json.dumps({'prepared':prepare()['targetRoleName'],'compiled':False}))
