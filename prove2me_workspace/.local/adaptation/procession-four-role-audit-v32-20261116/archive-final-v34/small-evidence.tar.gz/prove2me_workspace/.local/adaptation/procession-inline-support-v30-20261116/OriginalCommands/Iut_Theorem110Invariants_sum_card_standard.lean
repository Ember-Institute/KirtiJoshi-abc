/-- The sum over the capsules of the standard procession of a function of the capsule
cardinalities. -/
lemma sum_card_standard {P : Procession ℕ} {L : ℕ} (hP : P = Procession.standard L)
    (f : ℕ → ℝ) :
    ∑ i : Fin P.length, f (P.capsule i).card = ∑ i : Fin L, f (i + 2) := by
  subst hP
  change (∑ i : Fin L, f ((Procession.standard L).capsule i).card) =
    ∑ i : Fin L, f (i + 2)
  exact Finset.sum_congr rfl fun i _ =>
    congrArg f (Procession.standard_capsule_card L i)
