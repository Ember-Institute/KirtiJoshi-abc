单目标 Procession sum_card_standard 的最小四角色实际审查包。没有 CI、编译、API、Git 或主区写，没有新 Definition/平台 support theorem/证明 alias。

可直接消费：

- `AuditProcessionFourRoles.lean`：已有独立两 helper 修正后四角色模板的定点适配，保留原六对实际类型／完整 BinderInfo 比较、源 proof bytes 和 native/global 公理闭包。已复用 discard(action) 修正。
- `bound/config.actual.json`：真实已保存 source/type/role 结果绑定，SHA `055280f93368f1606ea8b3a51ca50b80cca41f84fe580f911244ec67578b4996`。实际审查尚未运行，actualAcceptedFlags=null。
- `bind_actual.py`：root 可重新从实际主区生成 task-local bound config；仅写本临时目录，不运行调度器或编译器。

已有真实任务：sourceproof ci-017230-2e01fd2b；sourceTYPE ci-017179-8a163bd8、ci-017180-16e7e336、ci-017181-d5f012fe；native/stub/solution原叶 ci-017182/183/184；三个artifact ci-017229-4023322d、ci-017232-791e079b、ci-017233-95d1ec22。配置使用 `oracle-output-context-fixed-v31/index.json`；失败的旧 oracle-output 不作为成功证据。

root 的直接 MCP-CI 入口：

```
task_type: review
target: file
parameters.source: <root实际稳定stage目录>/AuditProcessionFourRoles.lean
environment.PURE_FOUR_ROLE_CONFIG: <实际bound/config.actual.json绝对路径>
expected_duration: 60s
expected_memory: 16GiB
exclusive: true
workspace: /home/admin-wsl/Coq/abc/prove2me_workspace
```

session、agent、worktree_manifest、当前实际query/config与传递输入pin、LEAN_PATH、幂等键由 root 按现流程填写。两个旧模板时代的历史 NativeFacts 阶段在这里不再需要：nativeProof 和 stub 是不同常量，三个现有角色模块可同时导入，故一个 query 直接取得四角色当前实际 TYPE。没有新增数学审查阶段。

root 可将本目录 query/config 稳定复制到其实际工作目录，保留config输入和语义字段，只将 finalOutput 重定位到稳定目录。重新绑定的离线命令：

```
python3 /tmp/p2m-procession-four-role-audit-v32-20261116/bind_actual.py --unit /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/procession-inline-support-v30-20261116 --out /tmp/p2m-procession-four-role-audit-v32-20261116/bound/config.actual.json --final-output /实际稳定目录/procession-four-role-audit.json
```

输出目录应先存在。本次默认 `/tmp/.../actual/` 已建立。工具没有把未运行query称为 passed；query有待root实际编译。该审查输出沿用 `pure-source-native-stub-global-solution-audit/v13` 的12true/5sorryfalse字段，另记录四个实际 private support 对照 row，不新增publisher gate。

Procession 数据映射完全复用既有 `reference-volume-tate-carriers-20261115/accepted-prior-identity-map.json` 的 ci-013377-98675e26 已接受 namedPairs：procLabels、Capsule、Capsule.card、Procession、Procession.capsule、Procession.length、Procession.standard。三条 source TYPE 的直接项目常量并集是6项，不含Capsule；第7项 Capsule 只为结构类型闭包。`accepted-data-map-subset.json` 保留原pair及来源receipt pin，未改已发表Procession Definition，源码仍 SHA `3b39ff044c0cf2bcc03e79c6bb6a5b8a852535aa381103f3731a60e026b910d5`。

两个真正内联support只为原完整证明内部：

- source `Iut.card_procLabels` → userName `AbcAdaptation.Reference.Iut.card_procLabels`。
- source `Iut.Procession.standard_capsule_card` → userName `AbcAdaptation.Reference.Iut.Procession.standard_capsule_card`。

query在native owner `Theorems.Thm_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_card_standard_NativeAuditProof` 和 solution owner `Solutions.Sol_AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_card_standard` 中，按 `privateToUserName? + moduleOf` 从实际环境查各一条常量。输出真正Name的结构编码（含实际numeric组件），从未拼造 `_private` 前缀。stub不含private helpers。

每条support对应其实际sourceTYPE（各1root、原proof读取false），对照真实私有常量完整类型/BinderInfo、源签名/proof UTF8范围，以及值/type的标准公理闭包。原proof形式也保留：card_procLabels是直接 `:= Nat.card_Iic j`，不是另造by证明；其余两条是原by proof。3个源body SHA分别a15b7c56…、6875f92b…、81dfb285…。不把support改成额外假设、公开theorem或平台节点。

private支持检查使用实际已证明Definition的类型常量映射，未建立新的source→target data身份门。根目标原 P/L/hP/f 量化完整保留，没有替换成裸Fin类型或添加AG/TG/X/inv/est。

`frozen-consumer-readback.json` 是原消费节点三语row的逐字节副本；`existing-consumer-context.json` 保留既有Mochizuki Theorem1.10父引用。这里只复用消费上下文，不声称论文另有同名generic lemma，不新增support读回或论文材料。

本包仅做Python语法/配置/字节与既有结果绑定核对；没有执行Lean query，因此不把static-validation当数学验收。canonicalC22/全200完成仍未声称。
