#!/usr/bin/env python3
"""Root entry to the existing Procession single-problem/single-proof protocol."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
sys.dont_write_bytecode = True

DEFAULT = Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/procession-four-role-audit-v32-20261116/final-publisher-v33')
DRAFT = Path('/tmp/p2m-procession-four-role-audit-v32-20261116/platform-draft')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['collect-scope', 'check', 'deliver'])
    parser.add_argument('--delivery', type=Path, default=DEFAULT)
    args = parser.parse_args()
    delivery = args.delivery.resolve()
    source = delivery if (delivery / 'publisher.py').exists() else DRAFT
    spec = importlib.util.spec_from_file_location('existing_procession_publisher', source / 'publisher.py')
    publisher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(publisher)
    directory = delivery / 'platform'
    if args.command == 'check':
        publisher.preflight(delivery / 'packet.json', delivery / 'ready.final.json')
        print('Original private publisher preflight passed. No API invoked.')
    elif args.command == 'collect-scope':
        old = publisher.old
        api = old.load_api()
        directory.mkdir(parents=True, exist_ok=True)
        listing = api.request('/missions?q=Arithmetic%20Teichmuller&limit=100')
        old.save(directory / 'mission-list-readback.json', listing)
        mission = old.mission_from_listing(listing)
        root = api.request('/theorems/' + old.ROOT)
        assert root['visibility'] == 'private' and root['mathlib_rev'] == old.ENV
        old.save(directory / 'mission-scope.json', {'scope': old.SCOPE, 'mission': mission,
            'root_graph_membership': False, 'root_id': old.ROOT, 'environment': old.ENV})
        print('Existing private mission scope read back. No POST.')
    else:
        print(json.dumps(publisher.deliver(delivery / 'packet.json',
            delivery / 'ready.final.json', directory), ensure_ascii=False))


if __name__ == '__main__':
    main()
