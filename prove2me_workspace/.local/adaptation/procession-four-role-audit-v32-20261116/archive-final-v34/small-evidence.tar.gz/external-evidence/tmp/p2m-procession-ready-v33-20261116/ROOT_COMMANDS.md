Root commands (existing publisher; one private problem and one proof):

```sh
python3 /tmp/p2m-procession-ready-v33-20261116/root_entry.py collect-scope
python3 /tmp/p2m-procession-ready-v33-20261116/finalize_ready.py --mission-scope /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/procession-four-role-audit-v32-20261116/final-publisher-v33/platform/mission-scope.json --apply
python3 /tmp/p2m-procession-ready-v33-20261116/root_entry.py deliver
```

The second command runs the original publisher preflight. No separate check or
new compilation is needed. The first command uses GET only. The third command
uses the existing mutation journal and problem/proof API protocol.

Default delivery: `/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/procession-four-role-audit-v32-20261116/final-publisher-v33`.
Only publication metadata and ready evidence are written there. CI inputs,
configuration, actual report, role sources, and frozen readbacks remain unchanged.

The offline sample under `offline-check/` passed the original publisher preflight
with the historical two-helper mission scope. It is a local validation sample;
the commands above bind the new online scope readback.

There are exactly 14 existing gates and one publication row. The two support
proofs stay private in the native and solution modules. The editorial sentence
after the frozen readbacks now identifies the effective context-adapted proof
from ci-017230-2e01fd2b and states that its proof bytes differ from raw upstream.
The unchanged actual audit means effective-source proof identity. It does not
assert raw GitHub proof identity.

SHA-256:

```text
e2dc000ea74fa24c2f9aff9edffc1f60af69abbbe8a429cf1e516262d928dea0  finalize_ready.py
3bf36de428937a7c5832cb156be45001ef91044d51a41ee638ff6d9b132ff982  root_entry.py
c6382b5b5e22a61bddbccebea4c8eb94e955bd2ae7280ab440ca5da461ec22b5  actual/procession-four-role-audit.json
0037cb2d8f91a748b793d62a298bbe55278215970cdc3ebcfbb5f5859f73fab0  procession-sum-card-four-role-final-v32-result.json
11661f67dc4a9bff7d7b826b6a89cea3ce386627f41ae3833a51bc28e7cbdb38  procession-source-proof-original-context-v31-result.json
53eb012849cd4c776c78cc4089d9c158face953854143c3188d8c8f0d47a094a  local-basic-complete-gitdiff-v33-20261116.json
cf82a64cbbaee0dd9528a525a0e2be8cd849268ed7c89ab5b7452f30c3aa53f7  payload.json
f4ee1287849183506b097ab6972456cb54a1d23672f4f894edf33c6eae40ee56  frozen-consumer-readback.json
d10cca6296d78400dae385f2ec40402865d394af290701d46ec0ce5fc9a4a80c  source-provenance.json
```

The final packet and ready hashes depend on the chosen delivery path and mission
scope readback. Sample hashes are recorded in `offline-check/sha256.json`.
