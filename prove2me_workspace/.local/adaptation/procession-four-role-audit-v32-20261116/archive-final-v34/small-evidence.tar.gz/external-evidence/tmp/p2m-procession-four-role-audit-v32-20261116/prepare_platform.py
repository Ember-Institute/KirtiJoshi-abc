#!/usr/bin/env python3
"""Prepare only one not-ready private Procession problem/proof packet offline."""
from pathlib import Path
import ast
import hashlib
import json
import shutil

D = Path(__file__).resolve().parent
P = D / 'platform-draft'
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A = W / '.local/adaptation'
U = A / 'procession-inline-support-v30-20261116'
PRIOR = A / 'independent-two-four-role-v25-20261116'
TARGET = 'AbcAdaptation.Reference.Iut.Theorem110Invariants.sum_card_standard'
DEF_REL = 'Definitions/Def_AbcAdaptation_Reference_Iut_Cor312_Procession.lean'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(D)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def prepare():
    P.mkdir(exist_ok=True)
    protocol = (PRIOR / 'delivery_with_proved_parent.py').read_text()
    assignment, = [node for node in ast.walk(ast.parse(protocol)) if isinstance(node, ast.Assign) and
        any(isinstance(target, ast.Name) and target.id == 'approved' for target in node.targets)]
    lines = protocol.splitlines(keepends=True)
    indent = lines[assignment.lineno - 1][:assignment.col_offset]
    lines[assignment.lineno - 1:assignment.end_lineno] = [indent + 'approved = ' + repr({TARGET: set()}) + '\n']
    (P / 'delivery_with_proved_parent.py').write_text(''.join(lines))
    publisher = (PRIOR / 'publisher.py').read_text()
    publisher = publisher.replace("SHORT = ['Theorem110Invariants.LocalEstimate.finsum_le_finsum_of_le', 'Theorem110Invariants.sum_arch']",
        "SHORT = ['Theorem110Invariants.sum_card_standard']")
    publisher = publisher.replace("EXPECTED_DEPENDENCY_PATHS = {'Theorems/Thm_AbcAdaptation_Reference_Iut_sum_affine_quadratic.lean'}",
        "EXPECTED_DEPENDENCY_PATHS = {'" + DEF_REL + "'}")
    publisher = publisher.replace("assert len(packet['publications']) == len(packet['verification']) == 2",
        "assert len(packet['publications']) == len(packet['verification']) == 1")
    publisher = publisher.replace("save(Path(directory) / 'pure-two-exact-readback.json'", "save(Path(directory) / 'procession-exact-readback.json'")
    publisher = publisher.replace('    return result\n', '''    result.pop('both_direct_proofs', None)
    result['direct_proof'] = 'ACCEPTED'
    result['published_theorem_count'] = 1
    save(Path(directory) / 'delivery-summary.json', result)
    return result
''')
    (P / 'publisher.py').write_text(publisher)
    stub_rel = 'Theorems/Thm_' + TARGET.replace('.', '_') + '.lean'
    solution_rel = 'Solutions/Sol_' + TARGET.replace('.', '_') + '.lean'
    for relative in [stub_rel, solution_rel]:
        destination = P / 'staging' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(W / relative, destination)
    stub = (W / stub_rel).read_text()
    marker = 'theorem ' + TARGET
    assert stub.count(marker) == 1
    offset = stub.index(marker)
    preamble, formal = stub[:offset], stub[offset:].rstrip('\n')
    assert formal.endswith(':= by sorry')
    frozen = read(U / 'frozen-consumer-readback.json')
    assert frozen['readbacks']['en'] == frozen['originalEnglish'] == frozen['readback']
    assert hashlib.sha256(frozen['readbacks']['en'].encode()).hexdigest() == frozen['english_readback_utf8_sha256']
    assert frozen['sourceOpen'] is True
    rb = frozen['readbacks']
    trilingual = '\n\n'.join('**' + title + '**\n\n' + rb[key] for key, title in
        [('en', 'English'), ('zh_Hans', '简体中文'), ('ja', '日本語')])
    prior_packet = read(PRIOR / 'packet.json')
    old_metadata = prior_packet['publications'][1]['payload']['natural_language_statement']
    heading = '**Original paper context**'
    assert old_metadata.count(heading) == 1
    paper_part = old_metadata[old_metadata.index(heading):]
    # Keep the existing p23 Theorem1.10 quotation and its scope note, not the
    # other helper's appended p30 explanation.
    if '**Mochizuki paper context for the actual consumer (English)**' in paper_part:
        paper_part = paper_part.split('\n\n**Mochizuki paper context for the actual consumer (English)**', 1)[0]
    status = ('The independent readback above was frozen from a statement stub and its '
        'original proof-status sentences are preserved. The separate solution file copies '
        'the complete reference proof body. Source/target compiled-type identity, native '
        'typechecking and axiom acceptance are separate root-supplied gates; the frozen '
        'readback itself is not evidence that those gates have passed.')
    context = ('The actual reference consumer is Iut.Theorem110Invariants.theorem110. '
        'The two original support proofs are private proof internals in the native and global '
        'solution modules. Only sum_card_standard is a platform target; the existing Procession '
        'Definition is reused unchanged. The quoted Theorem 1.10 paragraph supplies the parent '
        'consumer context and does not state a separate lemma with this generic Lean type.')
    command = (U / 'OriginalCommands/Iut_Theorem110Invariants_sum_card_standard.lean').read_bytes().rstrip(b'\n')
    repository = W.parent / 'refer/iut/Iut/Implication/Theorem110.lean'
    raw = repository.read_bytes()
    signature_prefix = command.split(b':= by', 1)[0]
    assert raw.count(signature_prefix) == 1
    start = raw.index(signature_prefix)
    # The upstream raw proof differs from the effective normalized proof.
    # Locate the original declaration, while retaining both exact provenance
    # records instead of claiming upstream proof byte identity.
    end = raw.index(b'\n\n', start)
    first, last = raw[:start].count(b'\n') + 1, raw[:end].count(b'\n') + 1
    source_url = ('https://github.com/lana-agents/iut/blob/07cb1da58f6d428a670dbb5dd6093d428bcbcdd8/'
        'Iut/Implication/Theorem110.lean#L' + str(first) + '-L' + str(last))
    provenance_note = ('The source link identifies the upstream declaration. The supplied closed proof is '
        'copied from the effective normalized source bound to the successful source oracle. Its proof '
        'body differs from the upstream file; the signature and the complete effective proof body '
        'are preserved in the native and global solution roles.')
    save(P / 'source-provenance.json', {'repositorySource': str(repository), 'repositorySha256': sha(repository),
        'repositoryDeclarationRange': [first, last], 'repositorySignatureByteIdentity': True,
        'repositoryWholeProofByteIdentity': raw.count(command) == 1,
        'effectiveOriginalCommand': {'path': str(U / 'OriginalCommands/Iut_Theorem110Invariants_sum_card_standard.lean'),
            'sha256': sha(U / 'OriginalCommands/Iut_Theorem110Invariants_sum_card_standard.lean')},
        'effectiveProofBodyPreserved': True, 'note': provenance_note})
    payload = {'theorem_name': TARGET,
        'theorem_title': 'Summation over Procession.standard capsules — Procession.standard 的分量积包求和 — Procession.standardのカプセルにわたる和',
        'preamble': preamble, 'formal_statement': formal,
        'natural_language_statement': '**Independent formal-code readback (frozen statement-stub input)**\n\n' + trilingual +
            '\n\n**Implementation and proof-status context (separate from frozen readback)**\n\n' + status +
            '\n\n**Actual reference consumer context**\n\n' + context + '\n\n' + paper_part +
            '\n\n**Source provenance**\n\n' + provenance_note,
        'source': source_url, 'env': '0df444a360eaa60ab8c11dca51a86af692955474', 'private': True}
    save(P / 'payload.json', payload)
    save(P / 'frozen-consumer-readback.json', frozen)
    cfg = read(D / 'bound/config.actual.json')
    source_proof = cfg['proofByteEvidence']
    row = {'targetName': TARGET, 'sourceName': cfg['sourceName'],
        'sourceProofSha256': source_proof['sourceProofSha256'],
        'signatureSha256': hashlib.sha256(cfg['sourceBinding']['sourceSignatureText'].encode()).hexdigest(),
        **source_proof}
    save(P / 'source-proof-evidence.json', {'nodes': [row]})
    save(P / 'registered-dependencies.json', {'existingDefinition': {'path': str(W / DEF_REL), 'sha256': sha(W / DEF_REL)},
        'acceptedDataMap': read(D / 'accepted-data-map-subset.json'),
        'supportPlatformTargets': [], 'supportActualNames': 'runtime userName/owner resolution pending review',
        'actualClosureAccepted': False})
    tag = TARGET.replace('.', '_')
    metadata_paths = [P / 'publisher.py', P / 'delivery_with_proved_parent.py', P / 'payload.json',
        P / 'frozen-consumer-readback.json', P / 'source-proof-evidence.json', P / 'registered-dependencies.json',
        P / 'source-provenance.json',
        Path(__file__), D / 'query-manifest.json', D / 'accepted-data-map-subset.json',
        U / 'frozen-consumer-readback.json', W / DEF_REL]
    packet = {'schema': 'single-procession-private-problem-proof-draft/v32', 'workspace': str(W),
        'mission_id': prior_packet['mission_id'], 'root_id': prior_packet['root_id'],
        'environment': prior_packet['environment'], 'scope': prior_packet['scope'],
        'root_graph_membership': False, 'canonicalC22Connected': False, 'all200FormalAccepted': False,
        'publications': [{'tag': tag, 'endpoint': '/submit-problem', 'payload': payload}],
        'verification': [{'tag': tag, 'theorem_name': TARGET, 'source': solution_rel}],
        'source_sha256': {relative: sha(W / relative) for relative in [stub_rel, solution_rel]},
        'staged_sources': {relative: str(P / 'staging' / relative) for relative in [stub_rel, solution_rel]},
        'metadata_sha256': {str(path): sha(path) for path in metadata_paths},
        'frozenReadbacks': {TARGET: frozen}, 'frozenInputSourceOpen': {TARGET: True},
        'explanations': {TARGET: trilingual + '\n\n' + status + '\n\n' + context},
        'sourceOracleJobs': {TARGET: cfg['sourceBinding']['oracleReceipt']['contents']['job_id']},
        'actualSourceTypeFacts': {TARGET: {'path': cfg['sourceTypeFactsBinding']['path'], 'sha256': cfg['sourceTypeFactsBinding']['sha256']}},
        'allGatesAccepted': False}
    save(P / 'packet.json', packet)
    previous_ready = read(PRIOR / 'ready.final.json')
    ready = {'passed': False, 'packet_sha256': sha(P / 'packet.json'), 'source_sha256': packet['source_sha256'],
        'gates': {gate: False for gate in previous_ready['gates']}, 'ci_receipts': [],
        'evidence_sha256': packet['metadata_sha256'].copy(), 'explanations': packet['explanations'],
        'kernel_audits': {TARGET: None},
        'source_oracle_receipts': {TARGET: cfg['sourceBinding']['oracleReceipt']['path']},
        'source_type_receipts': {TARGET: cfg['sourceTypeReceipt']['path']},
        'source_type_facts': {TARGET: cfg['sourceTypeFactsBinding']['path']},
        'dependency_source_sha256': {DEF_REL: sha(W / DEF_REL)},
        'required_inputs': {TARGET: {key: None for key in next(iter(previous_ready['required_inputs'].values()))}},
        'shared_required_inputs': {key: None for key in previous_ready['shared_required_inputs']},
        'note': 'Not ready. Root binds the one actual four-role review after success. Two private support rows stay proof-internal; no new gate or public theorem is introduced.'}
    save(P / 'ready.template.json', ready)
    (P / 'prepare.py').write_text('''from pathlib import Path
import importlib.util
def prepare():
    p=Path(__file__).resolve().parent.parent/'prepare_platform.py'
    s=importlib.util.spec_from_file_location('offline_procession_platform_prepare',p)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    return m.prepare()
''')
    return packet


if __name__ == '__main__':
    prepare()
    print('Prepared one not-ready Procession platform target; no helper nodes.')
