#!/usr/bin/env python3
"""Archive this accepted Procession node and delete its exact integrated drafts.
Default reports only. Root adds --apply after its canonical leaf, artifact, and
axiom review succeed. No compiler, CI, API, or Git calls.
"""
from pathlib import Path
import argparse
import hashlib
import json
import tarfile

TASK = Path(__file__).resolve().parent
ROOT = Path('/home/admin-wsl/Coq/abc')
W = ROOT / 'prove2me_workspace'
A = W / '.local/adaptation'
UNIT = A / 'procession-four-role-audit-v32-20261116'
SOURCE = A / 'procession-inline-support-v30-20261116'
DELIVERY = UNIT / 'final-publisher-v33'
PLATFORM = DELIVERY / 'platform'
CHAIN = A / 'main-chain-open-20261116'
OUTPUT = UNIT / 'archive-final-v34'
TAG = 'AbcAdaptation_Reference_Iut_Theorem110Invariants_sum_card_standard'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def member(path):
    path = Path(path)
    if path.is_relative_to(ROOT):
        return path.relative_to(ROOT).as_posix()
    assert path.is_relative_to('/tmp')
    return 'external-evidence/tmp/' + path.relative_to('/tmp').as_posix()


def success(path):
    receipt = read(path)
    assert receipt['status'] == 'succeeded' and receipt['result']['exit_code'] == 0
    assert receipt['request']['workspace'] == str(W) and receipt['request']['exclusive'] is True
    snapshot = receipt['result']['snapshot']
    assert snapshot['workspace_mode'] == 'exclusive_worktree' and snapshot['snapshot_id'] is None
    return receipt


def accepted_and_integrated(integration, receipts):
    summary = read(PLATFORM / 'delivery-summary.json')
    assert summary['direct_proof'] == 'ACCEPTED' and summary['published_theorem_count'] == 1
    assert summary['root_graph_unchanged'] is True and summary['canonicalC22Connected'] is False
    assert read(PLATFORM / 'root-graph-before.json') == read(PLATFORM / 'root-graph-after.json')
    verification = read(PLATFORM / ('verify-' + TAG + '-result.json'))
    assert verification['status'] == 'ACCEPTED'
    assert verification['id'] == integration['submission_id']
    assert verification['theorem_id'] == integration['theorem_id']
    canonical = Path(integration['canonicalTarget'])
    assert sha(canonical) == integration['candidateSha256']
    a, b = integration['canonicalProofByteRange']
    assert hashlib.sha256(canonical.read_bytes()[a:b]).hexdigest() == integration['effectiveSourceProofSha256']
    leaf, artifact, review = [success(path) for path in receipts]
    relative = str(canonical.relative_to(W))
    assert leaf['result']['actual_arguments'] == ['lean', relative]
    assert artifact['result']['actual_arguments'] == [
        'lean', relative, '-o', '.lake/build/lib/lean/' + relative[:-5] + '.olean']
    for receipt in [leaf, artifact]:
        assert receipt['request']['worktree_manifest']['source_sha256'] == integration['candidateSha256']
    for receipt in [leaf, artifact, review]:
        assert receipt['request']['worktree_manifest']['input_hashes'][str(canonical)] == integration['candidateSha256']
    assert review['request']['task_type'] == 'review'
    checks = review['result']['review']
    assert checks['passed'] is True and checks['checks']['no_sorryAx'] is True and checks['violations'] == []
    return {'targetName': integration['targetName'], 'theorem_id': verification['theorem_id'],
        'submission_id': verification['id'], 'canonicalSha256': integration['candidateSha256'],
        'leafJob': leaf['job_id'], 'artifactJob': artifact['job_id'], 'axiomReviewJob': review['job_id']}


def collect(receipts, remove):
    files = set()
    # Both complete units are compact; include actual report/config, source
    # failure evidence, TYPE/oracle outputs, Theorem 1.10 quote and all journals.
    for directory in [UNIT, SOURCE, TASK]:
        files.update(path for path in directory.rglob('*') if path.is_file()
            and '__pycache__' not in path.parts and not path.is_relative_to(OUTPUT))
    packet, ready = read(DELIVERY / 'packet.json'), read(DELIVERY / 'ready.final.json')
    files.update(Path(path) for path in packet['metadata_sha256'] | ready['evidence_sha256'])
    files.update(Path(path) for path in remove)
    files.add(Path(read(TASK / 'integration-manifest.json')['canonicalTarget']))
    files.update([ROOT / 'refer/iut/Iut/Implication/Theorem110.lean',
        ROOT / 'refer/iut/Iut/Cor312/Procession.lean', ROOT / 'refer/iut/LICENSE'])
    files.add(Path('/tmp/p2m-procession-four-role-audit-v32-20261116/ROOT_QUERY.md'))
    files.update(path for path in Path('/tmp/p2m-procession-ready-v33-20261116').glob('*') if path.is_file())
    attempts = set(CHAIN.glob('procession-*.json'))
    for path in receipts:
        path = Path(path)
        assert path.name.endswith('-result.json')
        stem = path.name.removesuffix('-result.json')
        attempts.update(path.parent / (stem + suffix) for suffix in ['-request.json', '-submit.json', '-result.json'])
    files.update(attempts)
    for path in files:
        assert path.is_file() and not path.is_symlink(), str(path)
        assert path.stat().st_size < 16 * 1024 ** 2, ('Unexpected giant input', str(path))
    return sorted(files, key=str), sorted(attempts, key=str)


def attempt_history(paths):
    rows = []
    for path in paths:
        if not path.name.endswith('-result.json'):
            continue
        receipt = read(path)
        result = receipt.get('result') or {}
        status = receipt['status']
        classification = ('failed-source-context-not-accepted' if receipt['job_id'] == 'ci-017178-4c8572cf'
            else 'successful-effective-context-source-proof' if receipt['job_id'] == 'ci-017230-2e01fd2b'
            else 'historical-statement-stub-only' if 'stub-' in path.name
            else 'actual-successful-attempt' if status == 'succeeded' else 'actual-' + status + '-attempt')
        rows.append({'source': str(path), 'archive_path': member(path), 'job_id': receipt['job_id'],
            'status': status, 'classification': classification, 'exit_code': result.get('exit_code'),
            'resources': receipt.get('resources'), 'compile_time_seconds': receipt.get('compile_time_seconds'),
            'diagnostics': result.get('diagnostics'), 'stderr': result.get('stderr')})
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--leaf-receipt', type=Path, required=True)
    parser.add_argument('--artifact-receipt', type=Path, required=True)
    parser.add_argument('--axiom-receipt', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    assert not OUTPUT.exists(), 'Inspect any existing archive before another run; do not overwrite it'
    receipts = [args.leaf_receipt.resolve(), args.artifact_receipt.resolve(), args.axiom_receipt.resolve()]
    integration = read(TASK / 'integration-manifest.json')
    final = accepted_and_integrated(integration, receipts)
    remove = read(TASK / 'delete-whitelist.json')
    assert len(remove) == 16
    for row in remove:
        path = Path(row['path'])
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], ('Changed draft', str(path))
    files, attempts = collect(receipts, [row['path'] for row in remove])
    entries = [{'source': str(path), 'archive_path': member(path),
        'bytes': path.stat().st_size, 'sha256': sha(path)} for path in files]
    assert len({row['archive_path'] for row in entries}) == len(entries)
    manifest = {'schema': 'procession-accepted-canonical-archive/v34', 'completed': False,
        'finalIntegration': final, 'evidence': entries, 'deleteAfterArchive': remove,
        'attempts': attempt_history(attempts), 'rawUpstreamProofByteIdentity': False,
        'effectiveSourceProofSha256': integration['effectiveSourceProofSha256'],
        'sourceOracleJob': integration['sourceOracleJob'], 'fourRoleAuditJob': integration['fourRoleAuditJob'],
        'paperContext': 'IUT IV Theorem 1.10 parent quote; not an independently stated generic sum lemma.',
        'historicalReferences': 'Historical JSON paths are preserved; deleted draft bytes are present at archive_path.',
        'canonicalC22Connected': False, 'all200FormalAccepted': False}
    print(json.dumps({'apply': args.apply, 'output': str(OUTPUT), 'archiveFiles': len(entries),
        'archiveInputBytes': sum(row['bytes'] for row in entries), 'deleteFiles': len(remove),
        'deleteBytes': sum(row['bytes'] for row in remove), 'finalIntegration': final}, ensure_ascii=False, indent=2))
    if not args.apply:
        return
    OUTPUT.mkdir()
    write(OUTPUT / 'archive-manifest.json', manifest)
    archive_path = OUTPUT / 'small-evidence.tar.gz'
    with tarfile.open(archive_path, 'w:gz') as archive:
        for entry in entries:
            archive.add(entry['source'], arcname=entry['archive_path'], recursive=False)
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert {item.name for item in archive.getmembers()} == {entry['archive_path'] for entry in entries}
        for entry in entries:
            with archive.extractfile(entry['archive_path']) as stream:
                assert hashlib.sha256(stream.read()).hexdigest() == entry['sha256']
    for entry in entries:
        assert sha(entry['source']) == entry['sha256'], ('Input changed while archiving', entry['source'])
    # Archive bytes were reopened and verified before these exact draft deletions.
    for row in remove:
        Path(row['path']).unlink()
    manifest['completed'] = True
    manifest['archiveBytes'] = archive_path.stat().st_size
    manifest['archiveSha256'] = sha(archive_path)
    write(OUTPUT / 'archive-manifest.json', manifest)


if __name__ == '__main__':
    main()
