Canonical integration is already present in the main workspace. Its SHA-256 is
`8269eb5041d864f987167fa0471a6a55d303fe3d7cd61e31c3ee528f42af885a`.
The candidate in `Theorems/` differs from the actual accepted solution only by
renaming the top-level `solution` theorem to its original fully qualified name.
All private support code, signatures, and proof bodies are unchanged. The main
proof byte range is `[1205, 1415]`, with SHA-256
`81dfb2854ed61e020d082950ceb65c28ef5897813de79c6106450c2629abe8a4`.

Use the root's existing `integrated-v33/FinalAxioms.lean` entry. No additional
query, theorem, or check gate is introduced here. After its review succeeds:

```sh
python3 /tmp/p2m-procession-integrated-v34-20261116/archive_cleanup.py --leaf-receipt /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/main-chain-open-20261116/procession-integrated-canonical-leaf-v33-result.json --artifact-receipt /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/main-chain-open-20261116/procession-integrated-canonical-artifact-v33-result.json --axiom-receipt /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/main-chain-open-20261116/procession-integrated-final-axioms-v33-result.json
```

The default prints the exact archive/deletion scope. Add `--apply` to the same
command to write `procession-four-role-audit-v32-20261116/archive-final-v34/`.
It creates one `small-evidence.tar.gz` and `archive-manifest.json`. It reopens the
archive, verifies every member's SHA-256, confirms stable source inputs, then
deletes the 16 files in `delete-whitelist.json` (17,438 bytes). The list contains:

- Main workspace native and solution roles: 2 files.
- Source unit native, solution, stub and their formal-only versions: 6 files.
- Final publisher staging native-free stub and solution: 2 files.
- The root's saved pre-integration stub: 1 file.
- Earlier `/tmp` platform staging stub/solution pairs: 4 files.
- This task's integrated canonical candidate duplicate: 1 file.

The accepted upload in `platform/verify-...-solution.lean` is retained as part of
the verification journal. The actual canonical theorem and all cache artifacts
remain present. Historical JSON paths are not rewritten: deleted draft files
remain recoverable at their repo-relative or `external-evidence/tmp/` tar members.

Archive evidence contains the complete actual four-role report and bound config;
all native/stub/solution, source TYPE and source proof receipts; failed v30 and
successful v31 source contexts and diagnostics; published/verify mutation journal;
frozen trilingual readbacks; Theorem 1.10 parent quote and provenance; raw upstream
Theorem110/Procession source and license; and all final canonical CI receipts.
The failed ci-017178 source-context attempt is classified as failed, not accepted.
The statement-only stub receipts remain historical open-statement checks.

The raw upstream proof uses `subst` then `Finset.sum_congr` with `rw`. The effective
context-adapted proof bound to ci-017230 uses `subst`, `change`, and `congrArg`.
They have the same statement; their proof bytes differ. The four-role audit's
proof-identity result refers to the complete effective source proof. The payload's
editorial correction and unchanged provenance JSON both preserve this distinction.
The generic sum lemma is a helper for the Theorem 1.10 consumer; it is not a
separate quoted paper theorem. `canonicalC22Connected` and `all200FormalAccepted`
remain false.

No compiler, MCP-CI, API, Git, or main-workspace write was performed by this task.
The archive/deletion command is prepared for root execution only.
