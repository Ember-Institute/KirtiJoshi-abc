#!/usr/bin/env python3
"""Bind existing Procession results offline. No compiler, CI, API, or Git calls.

Default: validate and report. --apply copies the existing platform draft into
--delivery, updates only publication metadata, and writes ready.final.json.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
sys.dont_write_bytecode = True

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A = W / '.local/adaptation'
C = A / 'main-chain-open-20261116'
UNIT = A / 'procession-four-role-audit-v32-20261116'
DRAFT = Path('/tmp/p2m-procession-four-role-audit-v32-20261116/platform-draft')
DEFAULT = UNIT / 'final-publisher-v33'
AUDIT = UNIT / 'actual/procession-four-role-audit.json'
FINAL = C / 'procession-sum-card-four-role-final-v32-result.json'
DIFF = A / 'local-basic-complete-gitdiff-v33-20261116.json'
PRODUCTION = A / 'reference-initial-theta-carriers-20261115/production-gates-v2-result.json'
NAME = 'AbcAdaptation.Reference.Iut.Theorem110Invariants.sum_card_standard'
PINS = {
    AUDIT: 'c6382b5b5e22a61bddbccebea4c8eb94e955bd2ae7280ab440ca5da461ec22b5',
    FINAL: '0037cb2d8f91a748b793d62a298bbe55278215970cdc3ebcfbb5f5859f73fab0',
    DIFF: '53eb012849cd4c776c78cc4089d9c158face953854143c3188d8c8f0d47a094a',
}
OLD_SENTENCE = 'The separate solution file copies the complete reference proof body.'
NEW_SENTENCE = (
    'The separate solution file preserves the complete effective context-adapted proof '
    'bound to source oracle ci-017230-2e01fd2b. The upstream GitHub proof uses '
    '`subst hP` followed by `Finset.sum_congr` and `rw`; the effective proof uses '
    '`subst hP`, `change`, and `congrArg`. The statement is unchanged; the raw '
    'upstream proof body is not byte-identical to the effective proof body.')


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def success(path):
    result = read(path)
    assert result['status'] == 'succeeded' and result['result']['exit_code'] == 0, str(path)
    return result


def publisher_at(directory):
    spec = importlib.util.spec_from_file_location('existing_procession_publisher', directory / 'publisher.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def editorial(text):
    assert text.count(OLD_SENTENCE) == 1
    return text.replace(OLD_SENTENCE, NEW_SENTENCE)


def build(delivery, scope_path):
    for path, digest in PINS.items():
        assert sha(path) == digest, ('Changed fixed evidence', str(path))
    packet, ready = read(DRAFT / 'packet.json'), read(DRAFT / 'ready.template.json')
    publisher = publisher_at(DRAFT)
    assert len(ready['gates']) == 14 and set(ready['gates']) == publisher.old.GATES
    assert packet['canonicalC22Connected'] is False and packet['all200FormalAccepted'] is False
    assert len(packet['publications']) == len(packet['verification']) == 1
    assert packet['publications'][0]['payload']['theorem_name'] == NAME
    payload = packet['publications'][0]['payload']
    payload['natural_language_statement'] = editorial(payload['natural_language_statement'])
    packet['explanations'][NAME] = editorial(packet['explanations'][NAME])
    for text in packet['frozenReadbacks'][NAME]['readbacks'].values():
        assert text in payload['natural_language_statement'] and text in packet['explanations'][NAME]
    # Rebase platform metadata only. Preserve all historical source/config/facts paths.
    metadata = {}
    for path_string, digest in packet['metadata_sha256'].items():
        path = Path(path_string)
        assert sha(path) == digest, ('Changed historical evidence', str(path))
        live = delivery / path.relative_to(DRAFT) if path.is_relative_to(DRAFT) else path
        metadata[str(live)] = digest
    packet['metadata_sha256'] = metadata
    packet['staged_sources'] = {
        key: str(delivery / Path(value).relative_to(DRAFT))
        for key, value in packet['staged_sources'].items()}
    evidence = {str(path): digest for path, digest in PINS.items()}
    receipt_paths = []

    def bind(binding, receipt=False):
        path = Path(binding['path'])
        assert sha(path) == binding['sha256'], ('Changed bound evidence', str(path))
        if 'contents' in binding:
            assert read(path) == binding['contents'], ('Changed bound contents', str(path))
        evidence[str(path)] = binding['sha256']
        if receipt:
            success(path)
        return path

    actual = read(AUDIT)
    assert actual['targetName'] == NAME and actual['sourceName'] == 'Iut.Theorem110Invariants.sum_card_standard'
    assert all(actual[key] is True for key in publisher.AUDIT_FLAGS)
    assert all(actual[key] is False for key in publisher.NO_SORRY_FLAGS)
    for key in ['nativeAxioms', 'solutionAxioms', 'registeredDependencyAxioms']:
        assert set(actual[key]) <= {'propext', 'Classical.choice', 'Quot.sound'}
    final = success(FINAL)
    assert final['job_id'] == 'ci-017276-ab0b5907'
    assert final['result']['review']['passed'] is True
    config_path = Path(final['request']['environment']['PURE_FOUR_ROLE_CONFIG'])
    config = actual['configuration']
    assert read(config_path) == config
    for path, digest in final['request']['worktree_manifest']['input_hashes'].items():
        assert sha(path) == digest
        evidence[path] = digest
    for role in ['Stub', 'Solution', 'Native']:
        assert Path(config[role.lower() + 'InstalledSource']).read_text() == config['expected' + role + 'Text']
    assert Path(config['definitionSource']).read_text() == config['expectedDefinitionText']
    roles = {}
    for role in ['native', 'stub', 'solution']:
        bindings = config[role + 'ReceiptBindings']
        assert len(bindings) == 2
        for suffix, binding in zip(['leaf', 'artifact'], bindings):
            path = bind(binding, receipt=True)
            roles[role + '_' + suffix] = str(path)
            receipt_paths.append(str(path))
    source = config['sourceBinding']
    oracle_path = bind(source['oracleReceipt'], receipt=True)
    oracle = success(oracle_path)
    assert oracle['job_id'] == actual['sourceOracleJob'] == 'ci-017230-2e01fd2b'
    bind(source['oracleIndex'])
    bind(source['oracleDiagnostics'])
    for path_key, digest_key in [('oracleFactsPath', 'oracleFactsSha256'),
                                 ('oracleCoordinateSource', 'oracleCoordinateSha256')]:
        path = Path(source[path_key])
        assert sha(path) == source[digest_key]
        evidence[str(path)] = source[digest_key]
    type_receipt = bind(config['sourceTypeReceipt'], receipt=True)
    type_facts = bind(config['sourceTypeFactsBinding'])
    # These are already checked private proof internals, never publication rows.
    assert len(actual['sixPairComparisons']) == 6 and len(actual['inlinePrivateSupportRows']) == 4
    assert len(config['inlineSupportBindings']) == 2
    for support in config['inlineSupportBindings']:
        bind(support['sourceTypeReceipt'], receipt=True)
        bind(support['sourceTypeFactsBinding'])
    for binding in config['dependencyReceiptBindings']:
        bind(binding, receipt=True)
    bind(config['acceptedFoundationReceipt'], receipt=True)
    bind(config['acceptedDataMapBinding'])
    map_source = read(config['acceptedDataMapBinding']['path'])['sourceMap']
    bind(map_source)
    for path in [AUDIT, FINAL, config_path]:
        evidence[str(path)] = sha(path)
    required = dict(roles, source_proof_oracle=str(oracle_path),
        source_native_stub_solution_kernel_audit=str(AUDIT),
        recursive_axiom_audit=str(FINAL), registered_dependency_closure_audit=str(FINAL))
    assert set(required) == publisher.REQUIRED_PER_NODE
    ready['required_inputs'] = {NAME: required}
    ready['kernel_audits'] = {NAME: str(AUDIT)}
    ready['source_oracle_receipts'] = {NAME: str(oracle_path)}
    ready['source_type_receipts'] = {NAME: str(type_receipt)}
    ready['source_type_facts'] = {NAME: str(type_facts)}
    packet['sourceOracleJobs'] = {NAME: oracle['job_id']}
    packet['actualSourceTypeFacts'] = {NAME: {'path': str(type_facts), 'sha256': sha(type_facts)}}

    production = success(PRODUCTION)
    manifest = production['request']['worktree_manifest']
    pins = []
    for path, digest in manifest['input_hashes'].items():
        assert sha(path) == digest
        pins.append({'path': path, 'sha256': digest})
    for relative, digest in manifest['configuration_hashes'].items():
        assert sha(W / relative) == digest
        pins.append({'path': str(W / relative), 'sha256': digest})
    reuse = {'production_job': production['job_id'],
        'productionSourceAndConfigurationUnchanged': True, 'currentPins': pins,
        'scope': 'Same existing production gate; no new build or global claim.'}
    evidence.update({pin['path']: pin['sha256'] for pin in pins})
    diff = read(DIFF)
    assert diff['passed'] is True and diff['workspace'] == str(W.parent)
    assert [row['argv'] for row in diff['checks']] == [
        ['git', 'diff', '--check'], ['git', 'diff', '--cached', '--check']]
    assert all(row['exit_code'] == 0 for row in diff['checks'])
    scope = read(scope_path)
    assert scope['scope'] == packet['scope'] and scope['root_id'] == packet['root_id']
    assert scope['environment'] == packet['environment'] and scope['root_graph_membership'] is False
    assert scope['mission']['id'] == packet['mission_id'] and scope['mission']['visibility'] == 'private'
    assert scope['mission']['creator']['id'] == publisher.old.CREATOR
    assert scope['mission']['main_theorem']['theorem_id'] == packet['root_id']
    for path in [PRODUCTION, scope_path]:
        evidence[str(path)] = sha(path)
    ready['shared_required_inputs'] = {'production_checks': str(PRODUCTION),
        'import_audit': str(delivery / 'production-gate-reuse.final.json'),
        'git_diff_check': str(DIFF), 'existing_private_mission': str(scope_path)}
    ready['ci_receipts'] = receipt_paths + [str(FINAL)]
    ready['evidence_sha256'] = evidence
    ready['explanations'] = packet['explanations']
    ready['gates'] = {gate: True for gate in ready['gates']}
    ready['passed'] = True
    ready['note'] = ('Existing Procession source/native/stub/solution results bound offline. '
        'Proof identity refers to the effective context-adapted source proof from ci-017230-2e01fd2b; '
        'raw upstream proof bytes differ. Frozen readback proof-status sentences describe the historical stub.')
    packet['allGatesAccepted'] = True
    return packet, ready, reuse


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--delivery', type=Path, default=DEFAULT)
    parser.add_argument('--mission-scope', type=Path, required=True)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    delivery = args.delivery.resolve()
    assert delivery != DRAFT and not DRAFT.is_relative_to(delivery)
    packet, ready, reuse = build(delivery, args.mission_scope.resolve())
    if args.apply:
        # Copy only the pre-existing offline platform assets. CI inputs are never written.
        delivery.mkdir(parents=True, exist_ok=True)
        for name in ['publisher.py', 'delivery_with_proved_parent.py', 'prepare.py',
                     'frozen-consumer-readback.json', 'source-proof-evidence.json',
                     'registered-dependencies.json', 'source-provenance.json']:
            shutil.copyfile(DRAFT / name, delivery / name)
        shutil.copytree(DRAFT / 'staging', delivery / 'staging', dirs_exist_ok=True)
        write(delivery / 'payload.json', packet['publications'][0]['payload'])
        write(delivery / 'production-gate-reuse.final.json', reuse)
        ready['evidence_sha256'][str(delivery / 'production-gate-reuse.final.json')] = sha(delivery / 'production-gate-reuse.final.json')
        packet['metadata_sha256'][str(delivery / 'payload.json')] = sha(delivery / 'payload.json')
        for path in packet['metadata_sha256']:
            assert sha(path) == packet['metadata_sha256'][path]
        write(delivery / 'packet.json', packet)
        ready['packet_sha256'] = sha(delivery / 'packet.json')
        ready['evidence_sha256'].update(packet['metadata_sha256'])
        write(delivery / 'ready.final.json', ready)
        publisher_at(delivery).preflight(delivery / 'packet.json', delivery / 'ready.final.json')
    print(json.dumps({'apply': args.apply, 'delivery': str(delivery),
        'job_id': 'ci-017276-ab0b5907', 'sourceOracleJob': 'ci-017230-2e01fd2b',
        'auditSha256': sha(AUDIT), 'gateCount': len(ready['gates']),
        'publicationCount': len(packet['publications']), 'metadataOnly': True,
        'originalPublisherPreflightPassed': True if args.apply else None,
        'queriesConfigsFactsAndFrozenReadbacksWritten': False}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
