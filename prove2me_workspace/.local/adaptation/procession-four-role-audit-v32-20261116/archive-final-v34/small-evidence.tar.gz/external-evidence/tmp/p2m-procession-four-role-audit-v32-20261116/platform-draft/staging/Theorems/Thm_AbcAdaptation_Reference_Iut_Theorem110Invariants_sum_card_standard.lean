/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Mathlib.Data.Real.Basic
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Order.Interval.Finset.Nat

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators

open AbcAdaptation.Reference.Iut

theorem AbcAdaptation.Reference.Iut.Theorem110Invariants.sum_card_standard {P : Procession ℕ} {L : ℕ} (hP : P = Procession.standard L)
    (f : ℕ → ℝ) :
    ∑ i : Fin P.length, f (P.capsule i).card = ∑ i : Fin L, f (i + 2) := by sorry
