# statementII_bridge — v104 independent readback

readback_model: `gpt-6.1-sol`

inputhash (SHA-256): `a715289c96cfdd00043c2aba1cf78b0555821f010e0ab3434a684a29309b9a8c`

Frozen English SHA-256: `900e9d8227c05eee9ae466b66af4f073f94c83ee8d7a396735248b45e4a41d32`

English is the frozen independent readback. Chinese and Japanese are aligned translations of that English readback. All formal inputs and source hashes appear in `formal-input.lean.txt` and `input-manifest.json`.

---
# English — independent formal readback

Declaration: the private theorem `statementII_bridge` in `QueryNativeStatementIIAudit.lean`.

The theorem has no external mathematical parameters or hypotheses. It asserts
\[
\texttt{tripodTheory.StatementII}
\quad\Longleftrightarrow\quad
\texttt{AbcAdaptation.Tripod.StatementII}.
\]
Here `tripodTheory` is the particular imported definition, not an arbitrary height theory.

## Objects and functions fixed by the definitions

Let \(\overline{\mathbb Q}\) denote the specified algebraic closure `AlgebraicClosure ℚ`. The point type is
\[
P=\{z\in\overline{\mathbb Q}:z\ne0\text{ and }z\ne1\}.
\]
For \(x\in P\), write \(z=x.1\), \(F_z=\mathbb Q(z)\), and \(a_z\in F_z\) for the specified generator whose image is \(z\). Define
\[
D(z)=\operatorname{natDegree}(\operatorname{minpoly}_{\mathbb Q}(z)).
\]
The imported code proves \(D(z)>0\). Each denominator below means the real coercion of \(D(z)\).

The three real-valued functions are exactly
\[
\begin{aligned}
h(x)&=\frac{\texttt{Height.logHeight₁}(a_z)}{D(z)},\\
\delta(x)&=\frac{\log|\operatorname{discr}(F_z)|}{D(z)},\\
\kappa(x)&=\frac{1}{D(z)}
 \sum_{v\in B_z}\log\!\left(\operatorname{absNorm}(\mathfrak m_v)\right),
\end{aligned}
\]
where \(\operatorname{discr}\) is the imported number-field discriminant, \(v\) ranges over finite places of \(F_z\), and
\[
B_z=\{v:v(a_z)\ne1\ \text{or}\ v(a_z-1)\ne1\}.
\]
Here \(\mathfrak m_v\) is the ideal `v.maximalIdeal.asIdeal`. The code defines the last numerator as a `finsum`, with summand zero outside \(B_z\). It proves that \(B_z\) is finite and that this numerator equals the displayed finite sum.

An object \(K\) of type `CompactlyBounded` consists of a finite set \(V\subseteq\mathbb N\) of primes, with \(2\in V\), and a real number \(c\). There is no positivity requirement on \(c\). Its associated set \(S_K\subseteq P\) consists exactly of the points satisfying both conditions:

1. For every finite place \(v\) of \(F_z\), if the characteristic of \(\mathcal O_{F_z}/\mathfrak m_v\) belongs to \(V\), then
   \[
   |\log(v(a_z))|\le c\quad\text{and}\quad|\log(v(a_z-1))|\le c.
   \]
2. For every infinite place \(w\) of \(F_z\),
   \[
   |\log(w(a_z))|\le c\quad\text{and}\quad|\log(w(a_z-1))|\le c.
   \]

All logarithms here are the real logarithm used in the code. These formulas specify the functions and membership conditions; their names add no further geometric hypotheses.

## The two propositions

The concrete `tripodTheory` has curve type `Unit` and distinguished element `()`. At that element, its points, degree sets, functions, and objects \(K\) are precisely those above. It sets `Hyperbolic` to `True` and `DivisorFree` to `False`; these labels impose no extra geometric assumption in this theorem.

The left proposition says: for every \(d\in\mathbb N\), every \(\varepsilon\in\mathbb R\) with \(\varepsilon>0\), and every such \(K\), there exists \(C\in\mathbb R\) such that
\[
\forall x\in S_K\cap\{x\in P:D(x.1)\le d\},\qquad
h(x)\le (1+\varepsilon)(\delta(x)+\kappa(x))+C.
\]
This follows the actual meaning of \(f\lesssim_S g\): there exists a real \(C\) such that \(f(x)\le g(x)+C\) for every \(x\in S\). Addition and scalar multiplication of functions are pointwise.

The right proposition says: for every \(d\in\mathbb N\), every \(\varepsilon\in\mathbb R\) with \(\varepsilon>0\), and every such \(K\), there exists \(C\in\mathbb R\) such that, for every \(x\in P\),
\[
x\in S_K\ \Longrightarrow\ D(x.1)\le d\ \Longrightarrow\
h(x)\le(1+\varepsilon)(\delta(x)+\kappa(x))+C.
\]

In both propositions, \(d=0\) is allowed. Its degree condition has no solutions because \(D(z)>0\), so the pointwise requirement is vacuous. The constant \(C\) is any real number; the statement does not require \(C>0\) or \(C\ge0\). It may depend on \(d\), \(\varepsilon\), and \(K\), but the same \(C\) must work for all qualifying points \(x\).

Membership in the intersection means exactly the conjunction of membership in \(S_K\) and the degree bound. A requirement under that conjunction is equivalent to the two successive implications above. Thus, both sides express the same height inequality on the same fixed data. The private, closed bridge proves their equivalence. It supplies no standalone proof of either proposition.


---

# 简体中文——英文独立形式读回的译文

本译文对应已冻结的 `readback.en.md`，不是另一次独立审读。术语 `compactly bounded subset` 的中文译名保留为 `【译名待定：compactly-bounded-subset】`；下文以代码类型名 `CompactlyBounded` 精确指代相关数据。

所读声明：`QueryNativeStatementIIAudit.lean` 中的私有定理 `statementII_bridge`。

该定理没有外部数学参数或假设。它断言
\[
\texttt{tripodTheory.StatementII}
\quad\Longleftrightarrow\quad
\texttt{AbcAdaptation.Tripod.StatementII}.
\]
这里的 `tripodTheory` 是导入代码中指定的定义，并非任意一个高度理论。

## 定义已固定的对象和函数

令 \(\overline{\mathbb Q}\) 表示指定的代数闭包 `AlgebraicClosure ℚ`。点的类型为
\[
P=\{z\in\overline{\mathbb Q}:z\ne0\text{ 且 }z\ne1\}.
\]
对于 \(x\in P\)，记 \(z=x.1\)、\(F_z=\mathbb Q(z)\)，并记 \(a_z\in F_z\) 为指定的生成元，其像为 \(z\)。定义
\[
D(z)=\operatorname{natDegree}(\operatorname{minpoly}_{\mathbb Q}(z)),
\]
即 \(z\) 在有理数域上的最小多项式的自然数次数。导入代码证明了 \(D(z)>0\)。下列每个分母都表示 \(D(z)\) 在实数中的像。

三个实值函数恰好为
\[
\begin{aligned}
h(x)&=\frac{\texttt{Height.logHeight₁}(a_z)}{D(z)},\\
\delta(x)&=\frac{\log|\operatorname{discr}(F_z)|}{D(z)},\\
\kappa(x)&=\frac{1}{D(z)}
 \sum_{v\in B_z}\log\!\left(\operatorname{absNorm}(\mathfrak m_v)\right).
\end{aligned}
\]
其中 \(\operatorname{discr}\) 是导入的数域判别式，\(v\) 遍历 \(F_z\) 的有限位，且
\[
B_z=\{v:v(a_z)\ne1\ \text{或}\ v(a_z-1)\ne1\}.
\]
这里 \(\mathfrak m_v\) 是理想 `v.maximalIdeal.asIdeal`，\(\operatorname{absNorm}\) 表示理想的绝对范数。代码以 `finsum` 定义最后一个分子，在 \(B_z\) 外将求和项取为零。代码证明 \(B_z\) 有限，并证明该分子等于所展示的有限和。

类型 `CompactlyBounded` 中的对象 \(K\) 由一个有限集 \(V\subseteq\mathbb N\) 和一个实数 \(c\) 组成；\(V\) 的所有元素都是素数，且 \(2\in V\)。代码不要求 \(c\) 为正。其对应集合 \(S_K\subseteq P\) 恰好由同时满足以下两项条件的点组成：

1. 对 \(F_z\) 的每个有限位 \(v\)，若商环 \(\mathcal O_{F_z}/\mathfrak m_v\) 的特征属于 \(V\)，则
   \[
   |\log(v(a_z))|\le c\quad\text{且}\quad|\log(v(a_z-1))|\le c.
   \]
2. 对 \(F_z\) 的每个无限位 \(w\)，有
   \[
   |\log(w(a_z))|\le c\quad\text{且}\quad|\log(w(a_z-1))|\le c.
   \]

这里所有对数都是代码所用的实对数。这些公式给出了函数和集合成员条件；名称不额外附加几何假设。

## 两边的命题

具体定义 `tripodTheory` 的曲线类型为 `Unit`，指定元素为 `()`。在该元素处，它的点、次数集合、函数和对象 \(K\) 恰好是上述对象。它将 `Hyperbolic` 定义为 `True`，将 `DivisorFree` 定义为 `False`；这些标签没有为本定理增加几何假设。

左边的命题是：对每个 \(d\in\mathbb N\)、每个满足 \(\varepsilon>0\) 的 \(\varepsilon\in\mathbb R\)，以及每个上述 \(K\)，存在 \(C\in\mathbb R\)，使得
\[
\forall x\in S_K\cap\{x\in P:D(x.1)\le d\},\qquad
h(x)\le (1+\varepsilon)(\delta(x)+\kappa(x))+C.
\]
这里使用了 \(f\lesssim_S g\) 的实际定义：存在一个实数 \(C\)，使每个 \(x\in S\) 都满足 \(f(x)\le g(x)+C\)。函数的加法和数乘均逐点定义。

右边的命题是：对每个 \(d\in\mathbb N\)、每个满足 \(\varepsilon>0\) 的 \(\varepsilon\in\mathbb R\)，以及每个上述 \(K\)，存在 \(C\in\mathbb R\)，使每个 \(x\in P\) 都满足
\[
x\in S_K\ \Longrightarrow\ D(x.1)\le d\ \Longrightarrow\
h(x)\le(1+\varepsilon)(\delta(x)+\kappa(x))+C.
\]

两边都允许 \(d=0\)。由于 \(D(z)>0\)，此时没有点满足次数条件，因而对点的不等式要求空真。常数 \(C\) 可以是任意实数；命题不要求 \(C>0\) 或 \(C\ge0\)。它可以依赖 \(d\)、\(\varepsilon\) 和 \(K\)，但同一个 \(C\) 必须适用于所有满足条件的点 \(x\)。

属于上述交集，恰好等价于同时满足“属于 \(S_K\)”和次数上界这两个条件。以该合取为前提的要求，等价于上面的两个连续蕴含。因此，两边在同一份固定数据上表达同一个高度不等式。这个私有、闭合的桥接定理证明了二者等价，但没有单独证明其中任一命题。


---

# 日本語 — 英語の独立した形式的読解の翻訳

本訳は凍結済みの `readback.en.md` に対応する翻訳であり、別個の独立審読ではない。以下では、関連するデータをコードの型名 `CompactlyBounded` で正確に指す。

対象の宣言は、`QueryNativeStatementIIAudit.lean` にある非公開定理 `statementII_bridge` である。

この定理には外部の数学的パラメータも仮定もない。主張は
\[
\texttt{tripodTheory.StatementII}
\quad\Longleftrightarrow\quad
\texttt{AbcAdaptation.Tripod.StatementII}
\]
である。ここで `tripodTheory` はインポートされた特定の定義であり、任意の高さの理論ではない。

## 定義によって固定された対象と関数

\(\overline{\mathbb Q}\) を、指定された代数閉包 `AlgebraicClosure ℚ` とする。点の型は
\[
P=\{z\in\overline{\mathbb Q}:z\ne0\text{ かつ }z\ne1\}
\]
である。\(x\in P\) に対し、\(z=x.1\)、\(F_z=\mathbb Q(z)\) と書く。\(a_z\in F_z\) は、像が \(z\) となる指定の生成元である。また、
\[
D(z)=\operatorname{natDegree}(\operatorname{minpoly}_{\mathbb Q}(z))
\]
とする。これは \(z\) の有理数体上の最小多項式の自然数値の次数である。インポートされたコードは \(D(z)>0\) を証明する。以下の各分母は \(D(z)\) の実数への標準的な写像による像を表す。

三つの実数値関数は、正確には
\[
\begin{aligned}
h(x)&=\frac{\texttt{Height.logHeight₁}(a_z)}{D(z)},\\
\delta(x)&=\frac{\log|\operatorname{discr}(F_z)|}{D(z)},\\
\kappa(x)&=\frac{1}{D(z)}
 \sum_{v\in B_z}\log\!\left(\operatorname{absNorm}(\mathfrak m_v)\right)
\end{aligned}
\]
である。\(\operatorname{discr}\) はインポートされた数体の判別式であり、\(v\) は \(F_z\) の有限素点を動く。また、
\[
B_z=\{v:v(a_z)\ne1\ \text{または}\ v(a_z-1)\ne1\}
\]
である。ここで \(\mathfrak m_v\) はイデアル `v.maximalIdeal.asIdeal` であり、\(\operatorname{absNorm}\) はイデアルの絶対ノルムを表す。コードは最後の分子を `finsum` で定義し、\(B_z\) の外では被加算項をゼロとする。コードは \(B_z\) が有限であることと、この分子が表示した有限和に等しいことを証明する。

型 `CompactlyBounded` の対象 \(K\) は、素数からなる有限集合 \(V\subseteq\mathbb N\) と実数 \(c\) からなる。さらに \(2\in V\) を満たす。\(c\) に正値性の条件はない。対応する集合 \(S_K\subseteq P\) は、次の二条件をともに満たす点全体である。

1. \(F_z\) の任意の有限素点 \(v\) に対し、\(\mathcal O_{F_z}/\mathfrak m_v\) の標数が \(V\) に属するならば、
   \[
   |\log(v(a_z))|\le c\quad\text{かつ}\quad|\log(v(a_z-1))|\le c.
   \]
2. \(F_z\) の任意の無限素点 \(w\) に対し、
   \[
   |\log(w(a_z))|\le c\quad\text{かつ}\quad|\log(w(a_z-1))|\le c.
   \]

ここで対数はすべて、コードで用いる実対数である。これらの式が関数と集合への所属条件を規定する。その名称から幾何学的仮定が追加されることはない。

## 両辺の命題

具体的な定義 `tripodTheory` の曲線の型は `Unit` であり、指定された元は `()` である。この元における点、次数で定まる集合、関数、および対象 \(K\) は、正確に上記のものである。`Hyperbolic` は `True`、`DivisorFree` は `False` と定義される。これらの名称は、この定理に追加の幾何学的仮定を課さない。

左辺の命題は次のとおりである。任意の \(d\in\mathbb N\)、\(\varepsilon>0\) を満たす任意の \(\varepsilon\in\mathbb R\)、および上記の任意の \(K\) に対し、ある \(C\in\mathbb R\) が存在して、
\[
\forall x\in S_K\cap\{x\in P:D(x.1)\le d\},\qquad
h(x)\le (1+\varepsilon)(\delta(x)+\kappa(x))+C
\]
となる。これは \(f\lesssim_S g\) の実際の意味による。すなわち、ある実数 \(C\) が存在して、すべての \(x\in S\) が \(f(x)\le g(x)+C\) を満たすという意味である。関数の加法とスカラー倍は各点で定義される。

右辺の命題は次のとおりである。任意の \(d\in\mathbb N\)、\(\varepsilon>0\) を満たす任意の \(\varepsilon\in\mathbb R\)、および上記の任意の \(K\) に対し、ある \(C\in\mathbb R\) が存在して、すべての \(x\in P\) が
\[
x\in S_K\ \Longrightarrow\ D(x.1)\le d\ \Longrightarrow\
h(x)\le(1+\varepsilon)(\delta(x)+\kappa(x))+C
\]
を満たす。

両命題とも \(d=0\) を許す。\(D(z)>0\) であるため、この場合に次数条件を満たす点はなく、点ごとの要求は空虚に真となる。定数 \(C\) は任意の実数でよく、\(C>0\) も \(C\ge0\) も要求されない。\(C\) は \(d\)、\(\varepsilon\)、\(K\) に依存してよい。ただし、条件を満たすすべての点 \(x\) に対して、同じ \(C\) が使えなければならない。

交わりに属することは、\(S_K\) に属することと次数の上限条件との連言に正確に等しい。この連言を前提とする要求は、上記の二つの含意を順に適用する形式と同値である。したがって両辺は、同一の固定データ上の同じ高さの不等式を表す。この非公開で閉じた橋渡し定理は、両者の同値性を証明する。いずれか一方の命題を単独で証明するものではない。
