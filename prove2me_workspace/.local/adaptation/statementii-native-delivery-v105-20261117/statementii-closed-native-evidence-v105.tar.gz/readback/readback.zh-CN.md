# 简体中文——英文独立形式读回的译文

本译文对应已冻结的 `readback.en.md`，不是另一次独立审读。术语 `compactly bounded subset` 的中文译名保留为 `【译名待定：compactly-bounded-subset】`；下文以代码类型名 `CompactlyBounded` 精确指代相关数据。

所读声明：`QueryNativeStatementIIAudit.lean` 中的私有定理 `statementII_bridge`。

该定理没有外部数学参数或假设。它断言
\[
\texttt{tripodTheory.StatementII}
\quad\Longleftrightarrow\quad
\texttt{AbcAdaptation.Tripod.StatementII}.
\]
这里的 `tripodTheory` 是导入代码中指定的定义，并非任意一个高度理论。

## 定义已固定的对象和函数

令 \(\overline{\mathbb Q}\) 表示指定的代数闭包 `AlgebraicClosure ℚ`。点的类型为
\[
P=\{z\in\overline{\mathbb Q}:z\ne0\text{ 且 }z\ne1\}.
\]
对于 \(x\in P\)，记 \(z=x.1\)、\(F_z=\mathbb Q(z)\)，并记 \(a_z\in F_z\) 为指定的生成元，其像为 \(z\)。定义
\[
D(z)=\operatorname{natDegree}(\operatorname{minpoly}_{\mathbb Q}(z)),
\]
即 \(z\) 在有理数域上的最小多项式的自然数次数。导入代码证明了 \(D(z)>0\)。下列每个分母都表示 \(D(z)\) 在实数中的像。

三个实值函数恰好为
\[
\begin{aligned}
h(x)&=\frac{\texttt{Height.logHeight₁}(a_z)}{D(z)},\\
\delta(x)&=\frac{\log|\operatorname{discr}(F_z)|}{D(z)},\\
\kappa(x)&=\frac{1}{D(z)}
 \sum_{v\in B_z}\log\!\left(\operatorname{absNorm}(\mathfrak m_v)\right).
\end{aligned}
\]
其中 \(\operatorname{discr}\) 是导入的数域判别式，\(v\) 遍历 \(F_z\) 的有限位，且
\[
B_z=\{v:v(a_z)\ne1\ \text{或}\ v(a_z-1)\ne1\}.
\]
这里 \(\mathfrak m_v\) 是理想 `v.maximalIdeal.asIdeal`，\(\operatorname{absNorm}\) 表示理想的绝对范数。代码以 `finsum` 定义最后一个分子，在 \(B_z\) 外将求和项取为零。代码证明 \(B_z\) 有限，并证明该分子等于所展示的有限和。

类型 `CompactlyBounded` 中的对象 \(K\) 由一个有限集 \(V\subseteq\mathbb N\) 和一个实数 \(c\) 组成；\(V\) 的所有元素都是素数，且 \(2\in V\)。代码不要求 \(c\) 为正。其对应集合 \(S_K\subseteq P\) 恰好由同时满足以下两项条件的点组成：

1. 对 \(F_z\) 的每个有限位 \(v\)，若商环 \(\mathcal O_{F_z}/\mathfrak m_v\) 的特征属于 \(V\)，则
   \[
   |\log(v(a_z))|\le c\quad\text{且}\quad|\log(v(a_z-1))|\le c.
   \]
2. 对 \(F_z\) 的每个无限位 \(w\)，有
   \[
   |\log(w(a_z))|\le c\quad\text{且}\quad|\log(w(a_z-1))|\le c.
   \]

这里所有对数都是代码所用的实对数。这些公式给出了函数和集合成员条件；名称不额外附加几何假设。

## 两边的命题

具体定义 `tripodTheory` 的曲线类型为 `Unit`，指定元素为 `()`。在该元素处，它的点、次数集合、函数和对象 \(K\) 恰好是上述对象。它将 `Hyperbolic` 定义为 `True`，将 `DivisorFree` 定义为 `False`；这些标签没有为本定理增加几何假设。

左边的命题是：对每个 \(d\in\mathbb N\)、每个满足 \(\varepsilon>0\) 的 \(\varepsilon\in\mathbb R\)，以及每个上述 \(K\)，存在 \(C\in\mathbb R\)，使得
\[
\forall x\in S_K\cap\{x\in P:D(x.1)\le d\},\qquad
h(x)\le (1+\varepsilon)(\delta(x)+\kappa(x))+C.
\]
这里使用了 \(f\lesssim_S g\) 的实际定义：存在一个实数 \(C\)，使每个 \(x\in S\) 都满足 \(f(x)\le g(x)+C\)。函数的加法和数乘均逐点定义。

右边的命题是：对每个 \(d\in\mathbb N\)、每个满足 \(\varepsilon>0\) 的 \(\varepsilon\in\mathbb R\)，以及每个上述 \(K\)，存在 \(C\in\mathbb R\)，使每个 \(x\in P\) 都满足
\[
x\in S_K\ \Longrightarrow\ D(x.1)\le d\ \Longrightarrow\
h(x)\le(1+\varepsilon)(\delta(x)+\kappa(x))+C.
\]

两边都允许 \(d=0\)。由于 \(D(z)>0\)，此时没有点满足次数条件，因而对点的不等式要求空真。常数 \(C\) 可以是任意实数；命题不要求 \(C>0\) 或 \(C\ge0\)。它可以依赖 \(d\)、\(\varepsilon\) 和 \(K\)，但同一个 \(C\) 必须适用于所有满足条件的点 \(x\)。

属于上述交集，恰好等价于同时满足“属于 \(S_K\)”和次数上界这两个条件。以该合取为前提的要求，等价于上面的两个连续蕴含。因此，两边在同一份固定数据上表达同一个高度不等式。这个私有、闭合的桥接定理证明了二者等价，但没有单独证明其中任一命题。
