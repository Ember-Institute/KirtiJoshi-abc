# English — independent formal readback

Declaration: the private theorem `statementII_bridge` in `QueryNativeStatementIIAudit.lean`.

The theorem has no external mathematical parameters or hypotheses. It asserts
\[
\texttt{tripodTheory.StatementII}
\quad\Longleftrightarrow\quad
\texttt{AbcAdaptation.Tripod.StatementII}.
\]
Here `tripodTheory` is the particular imported definition, not an arbitrary height theory.

## Objects and functions fixed by the definitions

Let \(\overline{\mathbb Q}\) denote the specified algebraic closure `AlgebraicClosure ℚ`. The point type is
\[
P=\{z\in\overline{\mathbb Q}:z\ne0\text{ and }z\ne1\}.
\]
For \(x\in P\), write \(z=x.1\), \(F_z=\mathbb Q(z)\), and \(a_z\in F_z\) for the specified generator whose image is \(z\). Define
\[
D(z)=\operatorname{natDegree}(\operatorname{minpoly}_{\mathbb Q}(z)).
\]
The imported code proves \(D(z)>0\). Each denominator below means the real coercion of \(D(z)\).

The three real-valued functions are exactly
\[
\begin{aligned}
h(x)&=\frac{\texttt{Height.logHeight₁}(a_z)}{D(z)},\\
\delta(x)&=\frac{\log|\operatorname{discr}(F_z)|}{D(z)},\\
\kappa(x)&=\frac{1}{D(z)}
 \sum_{v\in B_z}\log\!\left(\operatorname{absNorm}(\mathfrak m_v)\right),
\end{aligned}
\]
where \(\operatorname{discr}\) is the imported number-field discriminant, \(v\) ranges over finite places of \(F_z\), and
\[
B_z=\{v:v(a_z)\ne1\ \text{or}\ v(a_z-1)\ne1\}.
\]
Here \(\mathfrak m_v\) is the ideal `v.maximalIdeal.asIdeal`. The code defines the last numerator as a `finsum`, with summand zero outside \(B_z\). It proves that \(B_z\) is finite and that this numerator equals the displayed finite sum.

An object \(K\) of type `CompactlyBounded` consists of a finite set \(V\subseteq\mathbb N\) of primes, with \(2\in V\), and a real number \(c\). There is no positivity requirement on \(c\). Its associated set \(S_K\subseteq P\) consists exactly of the points satisfying both conditions:

1. For every finite place \(v\) of \(F_z\), if the characteristic of \(\mathcal O_{F_z}/\mathfrak m_v\) belongs to \(V\), then
   \[
   |\log(v(a_z))|\le c\quad\text{and}\quad|\log(v(a_z-1))|\le c.
   \]
2. For every infinite place \(w\) of \(F_z\),
   \[
   |\log(w(a_z))|\le c\quad\text{and}\quad|\log(w(a_z-1))|\le c.
   \]

All logarithms here are the real logarithm used in the code. These formulas specify the functions and membership conditions; their names add no further geometric hypotheses.

## The two propositions

The concrete `tripodTheory` has curve type `Unit` and distinguished element `()`. At that element, its points, degree sets, functions, and objects \(K\) are precisely those above. It sets `Hyperbolic` to `True` and `DivisorFree` to `False`; these labels impose no extra geometric assumption in this theorem.

The left proposition says: for every \(d\in\mathbb N\), every \(\varepsilon\in\mathbb R\) with \(\varepsilon>0\), and every such \(K\), there exists \(C\in\mathbb R\) such that
\[
\forall x\in S_K\cap\{x\in P:D(x.1)\le d\},\qquad
h(x)\le (1+\varepsilon)(\delta(x)+\kappa(x))+C.
\]
This follows the actual meaning of \(f\lesssim_S g\): there exists a real \(C\) such that \(f(x)\le g(x)+C\) for every \(x\in S\). Addition and scalar multiplication of functions are pointwise.

The right proposition says: for every \(d\in\mathbb N\), every \(\varepsilon\in\mathbb R\) with \(\varepsilon>0\), and every such \(K\), there exists \(C\in\mathbb R\) such that, for every \(x\in P\),
\[
x\in S_K\ \Longrightarrow\ D(x.1)\le d\ \Longrightarrow\
h(x)\le(1+\varepsilon)(\delta(x)+\kappa(x))+C.
\]

In both propositions, \(d=0\) is allowed. Its degree condition has no solutions because \(D(z)>0\), so the pointwise requirement is vacuous. The constant \(C\) is any real number; the statement does not require \(C>0\) or \(C\ge0\). It may depend on \(d\), \(\varepsilon\), and \(K\), but the same \(C\) must work for all qualifying points \(x\).

Membership in the intersection means exactly the conjunction of membership in \(S_K\) and the degree bound. A requirement under that conjunction is equivalent to the two successive implications above. Thus, both sides express the same height inequality on the same fixed data. The private, closed bridge proves their equivalence. It supplies no standalone proof of either proposition.
