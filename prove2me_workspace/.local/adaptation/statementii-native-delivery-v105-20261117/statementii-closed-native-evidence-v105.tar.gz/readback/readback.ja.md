# 日本語 — 英語の独立した形式的読解の翻訳

本訳は凍結済みの `readback.en.md` に対応する翻訳であり、別個の独立審読ではない。以下では、関連するデータをコードの型名 `CompactlyBounded` で正確に指す。

対象の宣言は、`QueryNativeStatementIIAudit.lean` にある非公開定理 `statementII_bridge` である。

この定理には外部の数学的パラメータも仮定もない。主張は
\[
\texttt{tripodTheory.StatementII}
\quad\Longleftrightarrow\quad
\texttt{AbcAdaptation.Tripod.StatementII}
\]
である。ここで `tripodTheory` はインポートされた特定の定義であり、任意の高さの理論ではない。

## 定義によって固定された対象と関数

\(\overline{\mathbb Q}\) を、指定された代数閉包 `AlgebraicClosure ℚ` とする。点の型は
\[
P=\{z\in\overline{\mathbb Q}:z\ne0\text{ かつ }z\ne1\}
\]
である。\(x\in P\) に対し、\(z=x.1\)、\(F_z=\mathbb Q(z)\) と書く。\(a_z\in F_z\) は、像が \(z\) となる指定の生成元である。また、
\[
D(z)=\operatorname{natDegree}(\operatorname{minpoly}_{\mathbb Q}(z))
\]
とする。これは \(z\) の有理数体上の最小多項式の自然数値の次数である。インポートされたコードは \(D(z)>0\) を証明する。以下の各分母は \(D(z)\) の実数への標準的な写像による像を表す。

三つの実数値関数は、正確には
\[
\begin{aligned}
h(x)&=\frac{\texttt{Height.logHeight₁}(a_z)}{D(z)},\\
\delta(x)&=\frac{\log|\operatorname{discr}(F_z)|}{D(z)},\\
\kappa(x)&=\frac{1}{D(z)}
 \sum_{v\in B_z}\log\!\left(\operatorname{absNorm}(\mathfrak m_v)\right)
\end{aligned}
\]
である。\(\operatorname{discr}\) はインポートされた数体の判別式であり、\(v\) は \(F_z\) の有限素点を動く。また、
\[
B_z=\{v:v(a_z)\ne1\ \text{または}\ v(a_z-1)\ne1\}
\]
である。ここで \(\mathfrak m_v\) はイデアル `v.maximalIdeal.asIdeal` であり、\(\operatorname{absNorm}\) はイデアルの絶対ノルムを表す。コードは最後の分子を `finsum` で定義し、\(B_z\) の外では被加算項をゼロとする。コードは \(B_z\) が有限であることと、この分子が表示した有限和に等しいことを証明する。

型 `CompactlyBounded` の対象 \(K\) は、素数からなる有限集合 \(V\subseteq\mathbb N\) と実数 \(c\) からなる。さらに \(2\in V\) を満たす。\(c\) に正値性の条件はない。対応する集合 \(S_K\subseteq P\) は、次の二条件をともに満たす点全体である。

1. \(F_z\) の任意の有限素点 \(v\) に対し、\(\mathcal O_{F_z}/\mathfrak m_v\) の標数が \(V\) に属するならば、
   \[
   |\log(v(a_z))|\le c\quad\text{かつ}\quad|\log(v(a_z-1))|\le c.
   \]
2. \(F_z\) の任意の無限素点 \(w\) に対し、
   \[
   |\log(w(a_z))|\le c\quad\text{かつ}\quad|\log(w(a_z-1))|\le c.
   \]

ここで対数はすべて、コードで用いる実対数である。これらの式が関数と集合への所属条件を規定する。その名称から幾何学的仮定が追加されることはない。

## 両辺の命題

具体的な定義 `tripodTheory` の曲線の型は `Unit` であり、指定された元は `()` である。この元における点、次数で定まる集合、関数、および対象 \(K\) は、正確に上記のものである。`Hyperbolic` は `True`、`DivisorFree` は `False` と定義される。これらの名称は、この定理に追加の幾何学的仮定を課さない。

左辺の命題は次のとおりである。任意の \(d\in\mathbb N\)、\(\varepsilon>0\) を満たす任意の \(\varepsilon\in\mathbb R\)、および上記の任意の \(K\) に対し、ある \(C\in\mathbb R\) が存在して、
\[
\forall x\in S_K\cap\{x\in P:D(x.1)\le d\},\qquad
h(x)\le (1+\varepsilon)(\delta(x)+\kappa(x))+C
\]
となる。これは \(f\lesssim_S g\) の実際の意味による。すなわち、ある実数 \(C\) が存在して、すべての \(x\in S\) が \(f(x)\le g(x)+C\) を満たすという意味である。関数の加法とスカラー倍は各点で定義される。

右辺の命題は次のとおりである。任意の \(d\in\mathbb N\)、\(\varepsilon>0\) を満たす任意の \(\varepsilon\in\mathbb R\)、および上記の任意の \(K\) に対し、ある \(C\in\mathbb R\) が存在して、すべての \(x\in P\) が
\[
x\in S_K\ \Longrightarrow\ D(x.1)\le d\ \Longrightarrow\
h(x)\le(1+\varepsilon)(\delta(x)+\kappa(x))+C
\]
を満たす。

両命題とも \(d=0\) を許す。\(D(z)>0\) であるため、この場合に次数条件を満たす点はなく、点ごとの要求は空虚に真となる。定数 \(C\) は任意の実数でよく、\(C>0\) も \(C\ge0\) も要求されない。\(C\) は \(d\)、\(\varepsilon\)、\(K\) に依存してよい。ただし、条件を満たすすべての点 \(x\) に対して、同じ \(C\) が使えなければならない。

交わりに属することは、\(S_K\) に属することと次数の上限条件との連言に正確に等しい。この連言を前提とする要求は、上記の二つの含意を順に適用する形式と同値である。したがって両辺は、同一の固定データ上の同じ高さの不等式を表す。この非公開で閉じた橋渡し定理は、両者の同値性を証明する。いずれか一方の命題を単独で証明するものではない。
