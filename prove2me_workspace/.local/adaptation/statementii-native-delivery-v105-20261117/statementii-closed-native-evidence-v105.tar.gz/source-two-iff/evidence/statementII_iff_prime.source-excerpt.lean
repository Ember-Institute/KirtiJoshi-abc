/-- `Genl.HeightTheory.StatementII` for the tripod, fully unfolded: the existence of
some `C` with `h(λ) ≤ (1 + ε) (log-diff(λ) + log-cond(λ)) + C` on `K ∩ U_ℙ(ℚ̄)^{≤ d}`. -/
theorem statementII_iff' :
    tripodTheory.StatementII ↔
      ∀ (d : ℕ) (ε : ℝ), 0 < ε → ∀ K : CompactlyBounded, ∃ C : ℝ,
        ∀ x : Pt, x ∈ K.set → deg x.1 ≤ d →
          htCan x ≤ (1 + ε) * (logDiff x + logCond x) + C := by
  rw [statementII_iff]
  refine forall_congr' fun d ↦ forall_congr' fun ε ↦ imp_congr_right fun _ ↦
    forall_congr' fun K ↦ exists_congr fun C ↦ ?_
  simp only [Set.mem_inter_iff, mem_ptLE, and_imp, Pi.smul_apply, Pi.add_apply, smul_eq_mul]
