/-- **The ABC conjecture for compactly bounded subsets of the tripod**, concretely:
`Genl.HeightTheory.StatementII` for `tripodTheory` says that for every `d`, every `ε > 0`
and every compactly bounded subset `K`, the absolute logarithmic Weil height satisfies
`h(λ) ≤ (1 + ε) (log|disc(ℚ(λ))| + ∑_{v bad} log N(v))/[ℚ(λ) : ℚ] + C` for all `λ ∈ K` of
degree `≤ d`, for some `C = C(d, ε, K)`. -/
theorem statementII_iff :
    tripodTheory.StatementII ↔
      ∀ (d : ℕ) (ε : ℝ), 0 < ε → ∀ K : CompactlyBounded,
        htCan ≲[K.set ∩ ptLE d] (1 + ε) • (logDiff + logCond) :=
  Iff.rfl
