from pathlib import Path
import json, hashlib
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
D=Path('/tmp/p2m-statementii-native-audit-v100-20261117')
BASE=W/'.local/adaptation/basic-native-identity-v75-20261116/queries/AuditBasicNativeComparison.lean'
s=BASE.read_text()
foundation=s[s.index('/-! Stable JSON'):s.index('namespace BasicNativeCompare')]
imports='''import Lean
import Definitions.Def_TripodStatementIIInputs
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_Theory
import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII
'''
replay='''
/- CI-only closed formal bridge replay. No platform node or production theorem. -/
set_option autoImplicit false
open AbcAdaptation.Reference
open AbcAdaptation.Tripod
namespace AbcAdaptation.Tripod.NativeStatementIIReplayV100

private theorem statementII_bridge : tripodTheory.StatementII ↔ AbcAdaptation.Tripod.StatementII := by
  unfold AbcAdaptation.Tripod.StatementII
  rw [show tripodTheory.StatementII ↔
      ∀ (d : ℕ) (ε : ℝ), 0 < ε → ∀ K : CompactlyBounded,
        htCan ≲[K.set ∩ ptLE d] (1 + ε) • (logDiff + logCond) from Iff.rfl]
  refine forall_congr' fun d ↦ forall_congr' fun ε ↦ imp_congr_right fun _ ↦
    forall_congr' fun K ↦ exists_congr fun C ↦ ?_
  simp only [Set.mem_inter_iff, mem_ptLE, and_imp, Pi.smul_apply, Pi.add_apply, smul_eq_mul]
'''
(D/'queries/NativeStatementIIReplay.lean').write_text(imports.replace('import Lean\n','')+replay+'\nend AbcAdaptation.Tripod.NativeStatementIIReplayV100\n')
(D/'queries/QueryNativeStatementIIInventory.lean').write_text(imports+foundation+replay+(D/'inventory-fragment.lean.txt').read_text())
cfg={'schema':'StatementII-native-inventory-config/v100','outputFile':str(D/'actual/native-inventory.json'),'rootResolution':'same-file elaboration of private statementII_bridge; Expr.const actual Name','sourceFacts':str(W/'.local/adaptation/basic-statementii-bridge-v86-20261117/actual/source-two-roots-and-aux.json'),'closedFormalBridgeOnly':True,'canonicalStatementIIClaimed':False}
(D/'configs/native-inventory.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
manifest={str(p.relative_to(D)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in [D/'queries/NativeStatementIIReplay.lean',D/'queries/QueryNativeStatementIIInventory.lean',D/'configs/native-inventory.json']}
(D/'evidence/prepared-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
