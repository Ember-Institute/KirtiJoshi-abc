import Lean
import Definitions.Def_TripodStatementIIInputs
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_Theory
import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII
/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit

/- CI-only closed formal bridge replay. No platform node or production theorem. -/
set_option autoImplicit false
open AbcAdaptation.Reference
open AbcAdaptation.Tripod
namespace AbcAdaptation.Tripod.NativeStatementIIReplayV100

private theorem statementII_bridge : tripodTheory.StatementII ↔ AbcAdaptation.Tripod.StatementII := by
  unfold AbcAdaptation.Tripod.StatementII
  rw [show tripodTheory.StatementII ↔
      ∀ (d : ℕ) (ε : ℝ), 0 < ε → ∀ K : CompactlyBounded,
        htCan ≲[K.set ∩ ptLE d] (1 + ε) • (logDiff + logCond) from Iff.rfl]
  refine forall_congr' fun d ↦ forall_congr' fun ε ↦ imp_congr_right fun _ ↦
    forall_congr' fun K ↦ exists_congr fun C ↦ ?_
  simp only [Set.mem_inter_iff, mem_ptLE, and_imp, Pi.smul_apply, Pi.add_apply, smul_eq_mul]

open Lean Elab Term Meta FoundationAudit

-- An imported declaration uses the module table; a declaration elaborated in
-- this file belongs to the actual current mainModule. No Name text is decoded.
private def actualOwner (env : Environment) (n : Name) : MetaM Name := do
  unless env.contains n do throwError "Missing actual declaration {n}"
  return (moduleOf env n).getD env.mainModule

private def inventoryRow (ci : ConstantInfo) : MetaM Json := do
  let env ← getEnv
  let owner ← actualOwner env ci.name
  let some v := ci.value? (allowOpaque := true) | throwError "Missing actual value {ci.name}"
  for e in #[ci.type,v] do
    if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open actual expression {ci.name}"
  let axs ← collectAxioms ci.name
  let taxs ← expressionAxioms ci.type
  let vaxs ← expressionAxioms v
  for xs in #[axs,taxs,vaxs] do ensureStandard s!"native inventory {ci.name}" xs
  return Json.mkObj [
    ("name",toJson ci.name.toString),("nameExpr",encodeName ci.name),
    ("owner",toJson owner.toString),("ownerExpr",encodeName owner),
    ("ownerFromImportedModuleTable",toJson ((moduleOf env ci.name).isSome)),
    ("constantKind",toJson (kind ci)),
    ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("actualTypeExpr",← checked (encodeExpr ci.type)),
    ("actualValueExpr",← checked (encodeExpr v)),
    ("isProposition",toJson (← isProp ci.type)),
    ("typeBinderInventory",toJson (binderInventory ci.type)),
    ("valueBinderInventory",toJson (binderInventory v)),
    ("axioms",toJson (axs.map Name.toString)),("typeAxioms",toJson (taxs.map Name.toString)),
    ("valueAxioms",toJson (vaxs.map Name.toString)),
    ("hasSorryAx",toJson (axs.contains `sorryAx))]

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected target4.33.1"
  let cfg ← jsonFile (← absoluteEnv "STATEMENTII_NATIVE_INVENTORY_CONFIG")
  unless (← checked (stringField cfg "schema")) == "StatementII-native-inventory-config/v100" do
    throwError "Wrong inventory config"
  -- Crucial: elaboration resolves the private Name; there is no _private guess.
  let rootExpr ← elabTerm (← `(statementII_bridge)) none
  let .const rootName rootLevels := rootExpr | throwError "Elaborated root is not a constant"
  let env ← getEnv
  let rootOwner ← actualOwner env rootName
  let mut queue : Array Name := #[rootName]
  let mut seen : Array Name := #[]
  let mut roots : Array Json := #[]
  let mut auxiliaries : Array Json := #[]
  let mut boundaries : Array Json := #[]
  let mut boundarySeen : Array Name := #[]
  let mut i := 0
  while i < queue.size do
    let n := queue[i]!
    i := i + 1
    unless seen.contains n do
      seen := seen.push n
      let ci ← getConstInfo n
      let row ← inventoryRow ci
      if n == rootName then roots := roots.push row else auxiliaries := auxiliaries.push row
      let some v := ci.value? (allowOpaque := true) | throwError "Missing actual value {n}"
      for e in #[ci.type,v] do
        for dep in e.getUsedConstants do
          let owner ← actualOwner env dep
          if owner == rootOwner then
            unless seen.contains dep || queue.contains dep do queue := queue.push dep
          else unless boundarySeen.contains dep do
            boundarySeen := boundarySeen.push dep
            let dci ← getConstInfo dep
            boundaries := boundaries.push (Json.mkObj [
              ("name",toJson dep.toString),("nameExpr",encodeName dep),
              ("owner",toJson owner.toString),("ownerExpr",encodeName owner),
              ("constantKind",toJson (kind dci)),
              ("levelParams",Json.arr (dci.levelParams.toArray.map encodeName))])
  let output ← checked (stringField cfg "outputFile")
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "StatementII-native-root-owned-inventory/v100"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("rootElaboratedExpr",← checked (encodeExpr rootExpr)),
    ("rootElaboratedLevelArguments",Json.arr (← checked (rootLevels.toArray.mapM encodeLevel))),
    ("actualRootOwnerExpr",encodeName rootOwner),
    ("rootRows",Json.arr roots),("ownedGeneratedDependencyRows",Json.arr auxiliaries),
    ("externalBoundaryRows",Json.arr boundaries),
    ("privateNameResolvedByElaboration",toJson true),
    ("helperCountGuessed",toJson false),("targetMappingAccepted",toJson false),
    ("closedFormalBridgeOnly",toJson true),("canonicalStatementIIClaimed",toJson false)]).pretty ++ "\n")
  logInfo "Actual private root and actual owned dependencies exported; mapping audit remains pending"

end AbcAdaptation.Tripod.NativeStatementIIReplayV100
