import Definitions.Def_TripodStatementIIInputs
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_Theory
import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII

/- CI-only closed formal bridge replay. No platform node or production theorem. -/
set_option autoImplicit false
open AbcAdaptation.Reference
open AbcAdaptation.Tripod
namespace AbcAdaptation.Tripod.NativeStatementIIReplayV100

private theorem statementII_bridge : tripodTheory.StatementII ↔ AbcAdaptation.Tripod.StatementII := by
  unfold AbcAdaptation.Tripod.StatementII
  rw [show tripodTheory.StatementII ↔
      ∀ (d : ℕ) (ε : ℝ), 0 < ε → ∀ K : CompactlyBounded,
        htCan ≲[K.set ∩ ptLE d] (1 + ε) • (logDiff + logCond) from Iff.rfl]
  refine forall_congr' fun d ↦ forall_congr' fun ε ↦ imp_congr_right fun _ ↦
    forall_congr' fun K ↦ exists_congr fun C ↦ ?_
  simp only [Set.mem_inter_iff, mem_ptLE, and_imp, Pi.smul_apply, Pi.add_apply, smul_eq_mul]

end AbcAdaptation.Tripod.NativeStatementIIReplayV100
