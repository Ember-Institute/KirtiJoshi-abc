本目录只提供 CI-only closed formal bridge portable evidence 草稿。未调用 Lean、MCP-CI、平台 API 或 Git；未修改生产定理、未新增平台节点。主智能体负责整合与实际 CI 验收。

第一步最小可跑输入：`queries/QueryNativeStatementIIInventory.lean`，环境 `STATEMENTII_NATIVE_INVENTORY_CONFIG` 指向 `configs/native-inventory.json` 绝对路径。只接受目标 Lean 4.33.1、现有锁定 Mathlib 和已发布 Definitions。首次叶检查按仓库规则 60s/16GiB。实际依赖路径、manifest、exclusive 工作区和 job 记录由主智能体提交时填写；本目录不提交 CI。

该文件保留原 `statementII_iff'` 的 rw/refine/simp only，原 root1 的 `Iff.rfl` 内联，RHS 为既有 `AbcAdaptation.Tripod.StatementII`。在同文件中通过 `elabTerm` 解析私有根，从真实 `Expr.const` 读取 Name。owner 来自导入 module 表或实际当前 `env.mainModule`；沿实际根 TYPE/value 递归收集同 owner 依赖，输出所有实际 helper 的完整 TYPE/value、levelParams、binderInfo 和公理。没有预设 target helper 数量。

第二步审查输入：`queries/QueryNativeStatementIIAudit.lean`。同时设置上述 inventory 环境与 `STATEMENTII_NATIVE_AUDIT_CONFIG` 指向 `configs/native-audit.bound.json`。它在自己的同文件模块重新解析实际私有根，重做 inventory；不会复用另一个主 module 的 `_private` 名称。源实际 facts、map70、旧九个 proofSupport 的完整内容已绑定进 config，运行时核对文件内容。复制本目录到主区时可保留 config 的 /tmp 输出路径，或同步调整绝对路径再用 prepare/prepare_audit 脚本重建。

动态候选匹配遍历实际 target helper，以完整 TYPE 的 kernel definitional equality、完整 binderInfo/path 和实际 universe arity 查找唯一对应。源 aux1 的多态宇宙被两侧按位置实例化到同一个新鲜抽象 Level.param；源根中该常量的实际 `.{0}` 保留原状，辅助项走普通具名 Name map。旧 relocateExpr 的零宇宙 proofSupport 守卫完整复制，不作全局放宽。无唯一候选、额外 target helper、owner 变动或非标准公理均报错，不静默接受。

审查分别执行完整 TYPE 和 proof 的 Kernel.check、推导 TYPE 对比、完整 TYPE definitional equality、完整 proof kernel equality、公理审查，并导出 raw Expr、全树 binderInfo 路径、精确表达式/忽略 binder 名后的结构相等标志。proof kernel equality 可能来自 proof irrelevance，因此只按独立结构标志声明 proof 树相同。原始源 root2 proof 和仅展开实际 root1 的比较视图均保留。另有只展开现有具名 StatementII 纯定义的 TYPE 视图；它不影响实际 raw TYPE 输出。

CI 终态验收后运行 `python3 review_actual.py`，会从真实审查回执产物生成所有 raw TYPE/proof 差异和 binderInfo 路径；不会从未运行的草稿制造通过。最终证据只覆盖形式桥，不能据此声称 canonical C22、具体 StatementII 或 S2-04 完成。
