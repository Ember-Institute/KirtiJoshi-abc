import Lean
import Definitions.Def_TripodStatementIIInputs
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_Theory
import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII
/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit

/- CI-only closed formal bridge replay. No platform node or production theorem. -/
set_option autoImplicit false
open AbcAdaptation.Reference
open AbcAdaptation.Tripod
namespace AbcAdaptation.Tripod.NativeStatementIIReplayV100

private theorem statementII_bridge : tripodTheory.StatementII ↔ AbcAdaptation.Tripod.StatementII := by
  unfold AbcAdaptation.Tripod.StatementII
  rw [show tripodTheory.StatementII ↔
      ∀ (d : ℕ) (ε : ℝ), 0 < ε → ∀ K : CompactlyBounded,
        htCan ≲[K.set ∩ ptLE d] (1 + ε) • (logDiff + logCond) from Iff.rfl]
  refine forall_congr' fun d ↦ forall_congr' fun ε ↦ imp_congr_right fun _ ↦
    forall_congr' fun K ↦ exists_congr fun C ↦ ?_
  simp only [Set.mem_inter_iff, mem_ptLE, and_imp, Pi.smul_apply, Pi.add_apply, smul_eq_mul]

open Lean Elab Term Meta FoundationAudit

-- An imported declaration uses the module table; a declaration elaborated in
-- this file belongs to the actual current mainModule. No Name text is decoded.
private def actualOwner (env : Environment) (n : Name) : MetaM Name := do
  unless env.contains n do throwError "Missing actual declaration {n}"
  return (moduleOf env n).getD env.mainModule

private def inventoryRow (ci : ConstantInfo) : MetaM Json := do
  let env ← getEnv
  let owner ← actualOwner env ci.name
  let some v := ci.value? (allowOpaque := true) | throwError "Missing actual value {ci.name}"
  for e in #[ci.type,v] do
    if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open actual expression {ci.name}"
  let axs ← collectAxioms ci.name
  let taxs ← expressionAxioms ci.type
  let vaxs ← expressionAxioms v
  for xs in #[axs,taxs,vaxs] do ensureStandard s!"native inventory {ci.name}" xs
  return Json.mkObj [
    ("name",toJson ci.name.toString),("nameExpr",encodeName ci.name),
    ("owner",toJson owner.toString),("ownerExpr",encodeName owner),
    ("ownerFromImportedModuleTable",toJson ((moduleOf env ci.name).isSome)),
    ("constantKind",toJson (kind ci)),
    ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("actualTypeExpr",← checked (encodeExpr ci.type)),
    ("actualValueExpr",← checked (encodeExpr v)),
    ("isProposition",toJson (← isProp ci.type)),
    ("typeBinderInventory",toJson (binderInventory ci.type)),
    ("valueBinderInventory",toJson (binderInventory v)),
    ("axioms",toJson (axs.map Name.toString)),("typeAxioms",toJson (taxs.map Name.toString)),
    ("valueAxioms",toJson (vaxs.map Name.toString)),
    ("hasSorryAx",toJson (axs.contains `sorryAx))]

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected target4.33.1"
  let cfg ← jsonFile (← absoluteEnv "STATEMENTII_NATIVE_INVENTORY_CONFIG")
  unless (← checked (stringField cfg "schema")) == "StatementII-native-inventory-config/v100" do
    throwError "Wrong inventory config"
  -- Crucial: elaboration resolves the private Name; there is no _private guess.
  let rootExpr ← elabTerm (← `(statementII_bridge)) none
  let .const rootName rootLevels := rootExpr | throwError "Elaborated root is not a constant"
  let env ← getEnv
  let rootOwner ← actualOwner env rootName
  let mut queue : Array Name := #[rootName]
  let mut seen : Array Name := #[]
  let mut roots : Array Json := #[]
  let mut auxiliaries : Array Json := #[]
  let mut boundaries : Array Json := #[]
  let mut boundarySeen : Array Name := #[]
  let mut i := 0
  while i < queue.size do
    let n := queue[i]!
    i := i + 1
    unless seen.contains n do
      seen := seen.push n
      let ci ← getConstInfo n
      let row ← inventoryRow ci
      if n == rootName then roots := roots.push row else auxiliaries := auxiliaries.push row
      let some v := ci.value? (allowOpaque := true) | throwError "Missing actual value {n}"
      for e in #[ci.type,v] do
        for dep in e.getUsedConstants do
          let owner ← actualOwner env dep
          if owner == rootOwner then
            unless seen.contains dep || queue.contains dep do queue := queue.push dep
          else unless boundarySeen.contains dep do
            boundarySeen := boundarySeen.push dep
            let dci ← getConstInfo dep
            boundaries := boundaries.push (Json.mkObj [
              ("name",toJson dep.toString),("nameExpr",encodeName dep),
              ("owner",toJson owner.toString),("ownerExpr",encodeName owner),
              ("constantKind",toJson (kind dci)),
              ("levelParams",Json.arr (dci.levelParams.toArray.map encodeName))])
  let output ← checked (stringField cfg "outputFile")
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "StatementII-native-root-owned-inventory/v100"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("rootElaboratedExpr",← checked (encodeExpr rootExpr)),
    ("rootElaboratedLevelArguments",Json.arr (← checked (rootLevels.toArray.mapM encodeLevel))),
    ("actualRootOwnerExpr",encodeName rootOwner),
    ("rootRows",Json.arr roots),("ownedGeneratedDependencyRows",Json.arr auxiliaries),
    ("externalBoundaryRows",Json.arr boundaries),
    ("privateNameResolvedByElaboration",toJson true),
    ("helperCountGuessed",toJson false),("targetMappingAccepted",toJson false),
    ("closedFormalBridgeOnly",toJson true),("canonicalStatementIIClaimed",toJson false)]).pretty ++ "\n")
  logInfo "Actual private root and actual owned dependencies exported; mapping audit remains pending"

end AbcAdaptation.Tripod.NativeStatementIIReplayV100
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]

def validateSupport (maps : NameMap) (rows : Array Json) : MetaM Unit := do
  for p in rows do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) && (← checked (p.getObjValAs? Bool "isClosed")) && (← checked (arrayField p "levelParams")).isEmpty do
      throwError "Invalid actual closed proof support {n}"
    let t ← checked (relocateExpr maps rows #[] true (← checked (field p "actualTypeExpr")))
    let v ← checked (relocateExpr maps rows #[n] true (← checked (field p "actualProofExpr")))
    let vt ← kernelCheck s!"proof support {n}" v
    unless ← isProp vt do throwError "Support proof would replace data {n}"
    kernelEq s!"proof support TYPE {n}" vt t
    ensureStandard s!"expanded proof support {n}" (← expressionAxioms v)


end BasicNativeCompare
namespace AbcAdaptation.Tripod.NativeStatementIIReplayV100
open Lean Elab Term Meta FoundationAudit BasicNativeCompare

private def getBound (cfg : Json) (key : String) : MetaM Json := do
  let binding ← checked (field (← checked (field cfg "bindings")) key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do throwError "Bound input changed: {key}"
  return actual

-- This is a separate, single-root inlining view. The legacy zero-universe
-- proofSupport algorithm above is unchanged. Polymorphic auxiliaries are maps.
private partial def inlineOnlyFirstRoot (root : Name) (value : Json) (j : Json) : Except String Json := do
  match j with
  | .obj kvs =>
    if (stringField j "kind").toOption == some "const" &&
        (field j "name").toOption == some (encodeName root) then
      unless (← arrayField j "levels").isEmpty do throw "First source root has universe arguments"
      return value
    return Json.mkObj (← kvs.toArray.toList.mapM fun (k,v) => do
      return (k,← inlineOnlyFirstRoot root value v))
  | .arr xs => return .arr (← xs.mapM (inlineOnlyFirstRoot root value))
  | _ => return j

private def freshUniverses (n : Nat) : List Level :=
  (List.range n).map fun i => Level.param (.num (.str .anonymous "_StatementIIBridgeUniverse") i)

private def checkedValue (ci : ConstantInfo) : MetaM Expr := do
  let some v := ci.value? (allowOpaque := true) | throwError "No actual value {ci.name}"
  return v

private def sourceName (r : Json) : MetaM Name := checked (decodeName (← checked (field r "nameExpr")))

private def axiomJson (label : String) (e : Expr) : MetaM Json := do
  let xs ← expressionAxioms e
  ensureStandard label xs
  return toJson (xs.map Name.toString)

-- Alpha comparison preserves constructors, full binderInfo, universe arguments,
-- and all proof steps. Raw named trees are exported separately without erasure.
private partial def eraseBinderNames : Expr → Expr
  | .lam _ t b bi => .lam .anonymous (eraseBinderNames t) (eraseBinderNames b) bi
  | .forallE _ t b bi => .forallE .anonymous (eraseBinderNames t) (eraseBinderNames b) bi
  | .letE _ t v b nd => .letE .anonymous (eraseBinderNames t) (eraseBinderNames v) (eraseBinderNames b) nd
  | .app f a => .app (eraseBinderNames f) (eraseBinderNames a)
  | .mdata _ b => eraseBinderNames b
  | .proj n i b => .proj n i (eraseBinderNames b)
  | e => e

private def comparisonReport (label : String) (st sv tt tv : Expr) : MetaM Json := do
  -- Kernel.check of values and Kernel.isDefEq of complete inferred types are
  -- separate gates. Value defeq alone can hold by proof irrelevance.
  let sk ← kernelCheck s!"source TYPE {label}" st
  let tk ← kernelCheck s!"target TYPE {label}" tt
  let svi ← kernelCheck s!"source full proof {label}" sv
  let tvi ← kernelCheck s!"target full proof {label}" tv
  kernelEq s!"source proof inferred full TYPE {label}" svi st
  kernelEq s!"target proof inferred full TYPE {label}" tvi tt
  kernelEq s!"source/target complete TYPE {label}" st tt
  kernelEq s!"source/target complete proof value {label}" sv tv
  let typeBindersEqual := binderInventory st == binderInventory tt && binderPlacement st == binderPlacement tt
  let valueBindersEqual := binderInventory sv == binderInventory tv && binderPlacement sv == binderPlacement tv
  return Json.mkObj [
    ("label",toJson label),("sourceFullTypeKernelChecked",toJson true),
    ("targetFullTypeKernelChecked",toJson true),("sourceFullProofKernelChecked",toJson true),
    ("targetFullProofKernelChecked",toJson true),("completeTypeKernelEqual",toJson true),
    ("sourceProofInferredCompleteTypeEqual",toJson true),("targetProofInferredCompleteTypeEqual",toJson true),
    ("fullProofKernelEqualDespiteProofIrrelevance",toJson true),
    ("rawTypeBinderInfoAndPlacementEqual",toJson typeBindersEqual),
    ("rawProofBinderInfoAndPlacementEqual",toJson valueBindersEqual),
    ("fullTypeAlphaStructureEqual",toJson (eraseBinderNames st == eraseBinderNames tt)),
    ("fullProofAlphaStructureEqual",toJson (eraseBinderNames sv == eraseBinderNames tv)),
    ("fullTypeExactExprEqual",toJson (st == tt)),("fullProofExactExprEqual",toJson (sv == tv)),
    ("sourceFullTypeExpr",← checked (encodeExpr st)),("targetFullTypeExpr",← checked (encodeExpr tt)),
    ("sourceFullProofExpr",← checked (encodeExpr sv)),("targetFullProofExpr",← checked (encodeExpr tv)),
    ("sourceTypeBinderPlacement",toJson (binderPlacement st)),
    ("targetTypeBinderPlacement",toJson (binderPlacement tt)),
    ("sourceProofBinderPlacement",toJson (binderPlacement sv)),
    ("targetProofBinderPlacement",toJson (binderPlacement tv)),
    ("sourceTypeAxioms",← axiomJson label st),("targetTypeAxioms",← axiomJson label tt),
    ("sourceProofAxioms",← axiomJson label sv),("targetProofAxioms",← axiomJson label tv),
    ("sourceTypeSortExpr",← checked (encodeExpr sk)),("targetTypeSortExpr",← checked (encodeExpr tk))]

run_meta do
  let cfg ← jsonFile (← absoluteEnv "STATEMENTII_NATIVE_AUDIT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "StatementII-native-audit-config/v100" do
    throwError "Wrong native audit config"
  let facts ← getBound cfg "sourceFacts"
  let mapFacts ← getBound cfg "map70"
  let proofFacts ← getBound cfg "oldNineProofs"
  let sourceRoots ← checked (arrayField facts "rootRows")
  let sourceAux ← checked (arrayField facts "ownedGeneratedDependencyRows")
  unless sourceRoots.size == 2 && sourceAux.size == 3 do throwError "Source root/aux facts changed"
  let pairs ← checked (arrayField mapFacts "rows")
  unless pairs.size == 70 do throwError "Expected original Basic69 + global DiscrepancyLE map70"
  let mut maps : NameMap := #[]
  let env ← getEnv
  for p in pairs do
    let s ← checked (decodeName (← checked (field p "sourceNameExpr")))
    let t ← checked (decodeName (← checked (field p "targetNameExpr")))
    let _ ← getConstInfo t
    unless ((moduleOf env t).map Name.toString) == some (← checked (stringField p "targetOwner")) do
      throwError "Actual mapped target owner changed {t}"
    maps := maps.push (s,t)
    maps := maps.push (t,t)
  let oldProofs ← checked (arrayField proofFacts "closedSourceProofSupport")
  unless oldProofs.size == 9 do throwError "Preserved source proofSupport is not exactly nine"
  validateSupport maps oldProofs
  -- Resolve the root again in THIS audit module. The separate inventory module's
  -- private Name is not reused, and no generated helper number is predicted.
  let rootExpr ← elabTerm (← `(statementII_bridge)) none
  let .const targetRoot _ := rootExpr | throwError "Root elaboration is not const"
  let owner ← actualOwner env targetRoot
  let targetRootCI ← getConstInfo targetRoot
  let mut queue := #[targetRoot]
  let mut seen : Array Name := #[]
  let mut targetAux : Array Name := #[]
  let mut i := 0
  while i < queue.size do
    let n := queue[i]!
    i := i + 1
    unless seen.contains n do
      seen := seen.push n
      let ci ← getConstInfo n
      for e in #[ci.type,← checkedValue ci] do
        for dep in e.getUsedConstants do
          if (← actualOwner env dep) == owner && !seen.contains dep && !queue.contains dep then
            queue := queue.push dep
            if dep != targetRoot then targetAux := targetAux.push dep
  -- Candidate discovery uses actual full TYPEs at fresh abstract universes and
  -- full BinderInfo placement, not suffix spelling or guessed helper counts.
  let mut auxReports : Array Json := #[]
  let mut accepted : Array Name := #[]
  for sr in sourceAux do
    let sn ← sourceName sr
    unless (← checked (sr.getObjValAs? Bool "isProposition")) do
      throwError "Source auxiliary is not a proposition {sn}"
    let ps ← namesFromJson (← checked (field sr "levelParams"))
    let us := freshUniverses ps.length
    let st ← checked (relocateExpr maps oldProofs #[] true (← checked (field sr "actualTypeExpr")))
    let st := st.instantiateLevelParams ps us
    let sv ← checked (relocateExpr maps oldProofs #[] true (← checked (field sr "actualValueExpr")))
    let sv := sv.instantiateLevelParams ps us
    let _ ← kernelCheck s!"source auxiliary full TYPE {sn}" st
    let svi ← kernelCheck s!"source auxiliary full value {sn}" sv
    kernelEq s!"source auxiliary value TYPE {sn}" svi st
    let mut candidates : Array Name := #[]
    for tn in targetAux do
      unless accepted.contains tn do
        let ci ← getConstInfo tn
        if ps.length == ci.levelParams.length && kind ci == (← checked (stringField sr "constantKind")) then
          let tt := ci.type.instantiateLevelParams ci.levelParams us
          let eq ← match Kernel.isDefEq env {} st tt with
            | .ok b => pure b | .error ex => throwKernelException ex
          if eq && binderInventory st == binderInventory tt && binderPlacement st == binderPlacement tt then
            candidates := candidates.push tn
    unless candidates.size == 1 do
      throwError "Full TYPE/BinderInfo candidate search is not unique for {sn}: {candidates}"
    let tn := candidates[0]!
    let ci ← getConstInfo tn
    unless ← isProp ci.type do throwError "Actual target auxiliary is not a proposition {tn}"
    let tt := ci.type.instantiateLevelParams ci.levelParams us
    let tv := (← checkedValue ci).instantiateLevelParams ci.levelParams us
    let report ← comparisonReport sn.toString st sv tt tv
    auxReports := auxReports.push (Json.mkObj [
      ("sourceNameExpr",encodeName sn),("targetNameExpr",encodeName tn),
      ("actualTargetOwnerExpr",encodeName (← actualOwner env tn)),
      ("sourceLevelParams",Json.arr (ps.toArray.map encodeName)),
      ("targetLevelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
      ("freshCommonUniverseArguments",Json.arr (← checked (us.toArray.mapM encodeLevel))),
      ("uniqueFullTypeBinderCandidate",toJson true),("report",report)])
    accepted := accepted.push tn
    maps := maps.push (sn,tn)
    maps := maps.push (tn,tn)
  unless accepted.size == targetAux.size do
    throwError "Additional actual generated target helpers need explicit review: {targetAux.size} versus {accepted.size}"
  -- Actual source root1 is validated and inlined only at its original constant
  -- occurrences. There is deliberately no synthetic target root1 Name mapping.
  let firsts := sourceRoots.filter fun r =>
    (stringField r "name").toOption == some "Iut.Tripod.statementII_iff"
  let seconds := sourceRoots.filter fun r =>
    (stringField r "name").toOption == some "Iut.Tripod.statementII_iff'"
  unless firsts.size == 1 && seconds.size == 1 do throwError "Source root identities changed"
  let first := firsts[0]!
  let second := seconds[0]!
  let fn ← sourceName first
  let firstValue ← checked (field first "actualValueExpr")
  let fst ← checked (relocateExpr maps oldProofs #[] true (← checked (field first "actualTypeExpr")))
  let fsv ← checked (relocateExpr maps oldProofs #[] true firstValue)
  match fsv with
  | .app (.const n []) _ => unless n == `Iff.rfl do throwError "First source root value changed"
  | _ => throwError "First source root is not the actual closed Iff.rfl application"
  let fstInferred ← kernelCheck "first source root actual Iff.rfl" fsv
  kernelEq "first source root complete TYPE" fstInferred fst
  let _ ← axiomJson "first source root TYPE" fst
  let _ ← axiomJson "first source root value" fsv
  let st ← checked (relocateExpr maps oldProofs #[] true (← checked (field second "actualTypeExpr")))
  let sourceRootView ← checked (inlineOnlyFirstRoot fn firstValue (← checked (field second "actualValueExpr")))
  let sv ← checked (relocateExpr maps oldProofs #[] true sourceRootView)
  let tv ← checkedValue targetRootCI
  let rootReport ← comparisonReport "actual source second root / actual private native root" st sv targetRootCI.type tv
  -- A second comparison view expands exactly the existing concrete StatementII
  -- pure definition. Raw actual root TYPE/value above remain available.
  let statementCI ← getConstInfo `AbcAdaptation.Tripod.StatementII
  let statementValue ← checkedValue statementCI
  let targetTypeView := targetRootCI.type.replace fun e => match e with
    | .const n [] => if n == statementCI.name then some statementValue else none
    | _ => none
  kernelEq "exact named StatementII unfolding" targetRootCI.type targetTypeView
  let typeViewReport ← comparisonReport "source / target with exact named RHS unfolded" st sv targetTypeView tv
  let actualTargetRows ← (#[targetRoot] ++ targetAux).mapM fun n => inventoryRow (← getConstInfo n)
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "StatementII-closed-native-portable-audit/v100"),("configuration",cfg),
    ("actualTargetRows",Json.arr actualTargetRows),
    ("auxiliaryMappings",Json.arr auxReports),("rootReport",rootReport),
    ("exactNamedRhsUnfoldingReport",typeViewReport),
    ("firstSourceRootNameExpr",encodeName fn),("firstSourceRootFullTypeExpr",← checked (encodeExpr fst)),
    ("firstSourceRootFullValueExpr",← checked (encodeExpr fsv)),
    ("firstSourceRootHasSyntheticTargetName",toJson false),
    ("firstSourceRootInlinedOnlyAtExactActualConstant",toJson true),
    ("sourceSecondRootRawFullValueExpr",← checked (field second "actualValueExpr")),
    ("sourceSecondRootWithOnlyFirstRootInlined",sourceRootView),
    ("oldZeroUniverseProofSupportAlgorithmChanged",toJson false),
    ("oldProofSupportCount",toJson oldProofs.size),("map70Count",toJson pairs.size),
    ("newAuxiliaryConstantUniverseArgumentsPreserved",toJson true),
    ("closedFormalBridgeTargetMappingAccepted",toJson true),
    ("fullProofTreeIdentityRequiresReportedStructuralEquality",toJson true),
    ("productionStatementIITheoremChanged",toJson false),("platformNodesPublished",toJson false),
    ("canonicalC22OrS204Claimed",toJson false)]).pretty ++ "\n")
  logInfo "Closed formal bridge full source proof accepted by native kernel; raw TYPE/proof differences retained"

#print axioms statementII_bridge

end AbcAdaptation.Tripod.NativeStatementIIReplayV100
