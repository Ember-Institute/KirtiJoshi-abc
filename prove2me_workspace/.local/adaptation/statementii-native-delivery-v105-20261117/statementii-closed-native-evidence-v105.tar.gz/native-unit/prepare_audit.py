from pathlib import Path
import json, hashlib
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');D=Path('/tmp/p2m-statementii-native-audit-v100-20261117')
base=(W/'.local/adaptation/basic-native-identity-v75-20261116/queries/AuditBasicNativeComparison.lean').read_text()
alg=base[base.index('namespace BasicNativeCompare'):base.index('run_meta do\n  unless Lean.versionString == "4.33.1"')]
# Strict legacy zero-universe proof expansion is copied without any changes.
alg+='\nend BasicNativeCompare\n'
query=(D/'queries/QueryNativeStatementIIInventory.lean').read_text()
query=query.removesuffix('\nend AbcAdaptation.Tripod.NativeStatementIIReplayV100\n')
# Audit definitions are at top level; same-file private root is resolved in its namespace below.
query+='\nend AbcAdaptation.Tripod.NativeStatementIIReplayV100\n'+alg
query+=(D/'audit-fragment.lean.txt').read_text()
(D/'queries/QueryNativeStatementIIAudit.lean').write_text(query)
paths={
 'sourceFacts':W/'.local/adaptation/basic-statementii-bridge-v86-20261117/actual/source-two-roots-and-aux.json',
 'map70':W/'.local/adaptation/basic-statementii-bridge-v86-20261117/evidence/actual-name-map-70.json',
 'oldNineProofs':W/'.local/adaptation/basic-statementii-bridge-v86-20261117/evidence/preserved-nine-actual-proofs.json'}
cfg={'schema':'StatementII-native-audit-config/v100','outputFile':str(D/'actual/native-audit.json'),'bindings':{k:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'contents':json.loads(p.read_text())} for k,p in paths.items()},'claimScope':'closed-formal-bridge-portable-evidence-only','canonicalStatementIIClaimed':False}
(D/'configs/native-audit.bound.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
