#!/usr/bin/env python3
"""Review actual CI evidence only. Never compile or infer acceptance from static files."""
from pathlib import Path
import argparse, hashlib, json
D=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def name(n):
 if not n:return ''
 p,k,x=n
 return (name(p)+'.' if p else '')+str(x)
def differences(a,b,path='root'):
 if type(a) is not type(b):yield {'path':path,'source':a,'target':b};return
 if isinstance(a,dict):
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:yield {'path':path+'.'+k,'source':a.get(k),'target':b.get(k)}
   else:yield from differences(a[k],b[k],path+'.'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):yield {'path':path+'.length','source':len(a),'target':len(b)}
  for i,(x,y) in enumerate(zip(a,b)):yield from differences(x,y,f'{path}[{i}]')
 elif a!=b:yield {'path':path,'source':a,'target':b}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--audit',type=Path,default=D/'actual/native-audit.json');ap.add_argument('--output',type=Path,default=D/'actual/review.json');args=ap.parse_args()
 j=json.loads(args.audit.read_text())
 assert j['schema']=='StatementII-closed-native-portable-audit/v100'
 assert j['closedFormalBridgeTargetMappingAccepted'] is True
 assert j['canonicalC22OrS204Claimed'] is False
 assert j['oldZeroUniverseProofSupportAlgorithmChanged'] is False
 assert j['oldProofSupportCount']==9 and j['map70Count']==70
 rows=j['actualTargetRows'];names={name(r['nameExpr']) for r in rows}
 assert len(names)==len(rows)
 for r in rows:
  assert not r['hasSorryAx']
  for k in ['axioms','typeAxioms','valueAxioms']:assert set(r[k]) <= {'propext','Classical.choice','Quot.sound'}
 reps=[('root',j['rootReport']),('root-exact-named-RHS-unfolded',j['exactNamedRhsUnfoldingReport'])]
 mappings=[]
 for a in j['auxiliaryMappings']:
  assert a['uniqueFullTypeBinderCandidate']
  mappings.append({'source':name(a['sourceNameExpr']),'target':name(a['targetNameExpr']),'sourceLevelParams':a['sourceLevelParams'],'targetLevelParams':a['targetLevelParams']})
  reps.append((name(a['sourceNameExpr']),a['report']))
 out=[]
 for label,r in reps:
  for k in ['sourceFullTypeKernelChecked','targetFullTypeKernelChecked','sourceFullProofKernelChecked','targetFullProofKernelChecked','completeTypeKernelEqual','sourceProofInferredCompleteTypeEqual','targetProofInferredCompleteTypeEqual']:assert r[k] is True
  out.append({'label':label,'fullProofAlphaStructureEqual':r['fullProofAlphaStructureEqual'],'fullProofExactExprEqual':r['fullProofExactExprEqual'],'rawTypeBinderInfoAndPlacementEqual':r['rawTypeBinderInfoAndPlacementEqual'],'rawProofBinderInfoAndPlacementEqual':r['rawProofBinderInfoAndPlacementEqual'],'typeRawDifferences':list(differences(r['sourceFullTypeExpr'],r['targetFullTypeExpr'])),'proofRawDifferences':list(differences(r['sourceFullProofExpr'],r['targetFullProofExpr'])),'sourceTypeBinderPlacement':r['sourceTypeBinderPlacement'],'targetTypeBinderPlacement':r['targetTypeBinderPlacement'],'sourceProofBinderPlacement':r['sourceProofBinderPlacement'],'targetProofBinderPlacement':r['targetProofBinderPlacement']})
 result={'schema':'StatementII-actual-native-review/v100','auditPath':str(args.audit.resolve()),'auditSHA256':sha(args.audit),'actualAuxiliaryMappings':mappings,'completeTypeAndProofKernelAcceptance':True,'proofTreeIdentitySeparateFromKernelEquality':True,'reports':out,'canonicalC22OrS204Claimed':False,'sourceIffFirstRootActualValueInlinedOnly':True}
 args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'auditSHA256':result['auditSHA256'],'reports':len(out),'auxiliaryMappings':mappings,'proofAlphaStructureEqual':[{'label':x['label'],'equal':x['fullProofAlphaStructureEqual']} for x in out]},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
