from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
base=(W/'.local/adaptation/basic-native-identity-v75-20261116/queries/AuditBasicNativeComparison.lean').read_text()
alg=base[base.index('namespace BasicNativeCompare'):base.index('run_meta do\n  unless Lean.versionString == "4.33.1"')]
audit=(D/'queries/QueryNativeStatementIIAudit.lean').read_text()
assert alg in audit
assert 'unless us.isEmpty do throw s!"Closed proof has universe args {n}"' in audit
for fn in ['NativeStatementIIReplay.lean','QueryNativeStatementIIInventory.lean','QueryNativeStatementIIAudit.lean']:
 s=(D/'queries'/fn).read_text()
 assert 'rw [show tripodTheory.StatementII ↔' in s and 'from Iff.rfl]' in s
 assert "  refine forall_congr' fun d ↦ forall_congr' fun ε ↦ imp_congr_right fun _ ↦\n    forall_congr' fun K ↦ exists_congr fun C ↦ ?_" in s
 assert '  simp only [Set.mem_inter_iff, mem_ptLE, and_imp, Pi.smul_apply, Pi.add_apply, smul_eq_mul]' in s
 assert 'import Mathlib\n' not in s and 'sorry' not in s.replace('`sorryAx','')
 assert 'maxHeartbeats' not in s
 assert 'example (h' not in s
 assert 'String.toName' not in s.replace('-- Preserve actual Name components, including numeric components; do not use String.toName.','')
source=W/'.local/adaptation/basic-statementii-bridge-v86-20261117/actual/source-two-roots-and-aux.json'
j=json.loads(source.read_text());assert len(j['rootRows'])==2 and len(j['ownedGeneratedDependencyRows'])==3
assert j['rootRows'][0]['actualValueExpr']['fn']['name']==[ [[], 'str','Iff'],'str','rfl']
manifest={str(p.relative_to(D)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in D.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.name!='draft-manifest.json'}
(D/'evidence/draft-manifest.json').write_text(json.dumps({'schema':'StatementII-native-v100-draft-manifest','compiled':False,'ciSubmitted':False,'productionFilesModified':False,'legacyRelocationAlgorithmByteIdentical':True,'sourceFactsSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'files':manifest},ensure_ascii=False,indent=2)+'\n')
print('static draft checks passed; not Lean compilation or target mapping acceptance')
