import Lean
import Iut.Tripod.Basic

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  let m ← env.header.modules[index.toNat]?
  return m.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicMapExport
open Lean Elab Term Meta FoundationAudit

def sourceProject (n : Name) : Bool :=
  #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n)

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open Expr in {label}"

def getValue (ci : ConstantInfo) : MetaM Expr := do
  let some v := ci.value? (allowOpaque := true) | throwError "No actual value for {ci.name}"
  return v

def structureJson (ci : ConstantInfo) : MetaM Json := do
  match getStructureInfo? (← getEnv) ci.name with
  | none => pure Json.null
  | some info => do
    let aps ← info.fieldInfo.mapM fun p => match p.autoParam? with
      | none => pure Json.null
      | some e => checked (encodeExpr e)
    return Json.mkObj [
      ("completeMetadata",← checked (structureShape info pure)),
      ("fieldAutoParamExprs",Json.arr aps),
      ("fieldsInConstructorOrder",toJson (info.fieldNames.map Name.toString)),
      ("projections",Json.arr (info.fieldInfo.map fun p => encodeName p.projFn))]

def record (ci : ConstantInfo) (readProofValue : Bool) : MetaM Json := do
  let env ← getEnv
  let prop ← isProp ci.type
  let axs ← collectAxioms ci.name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"actual declaration {ci.name}" axs
  ensureStandard s!"actual TYPE {ci.name}" taxs
  let value ← if prop && !readProofValue then pure none else pure (ci.value? (allowOpaque := true))
  let vaxs ← match value with
    | none => pure #[]
    | some v => do
      requireClosed s!"actual value {ci.name}" v
      expressionAxioms v
  ensureStandard s!"actual value {ci.name}" vaxs
  let rules ← match ci with
    | .recInfo r => r.rules.toArray.mapM fun rule => checked (encodeExpr rule.rhs)
    | _ => pure #[]
  return Json.mkObj [
    ("name",toJson ci.name.toString),("nameExpr",encodeName ci.name),
    ("module",toJson ((moduleOf env ci.name).map Name.toString)),
    ("constantKind",toJson (kind ci)),
    ("levelParams",Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr",← checked (encodeExpr ci.type)),
    ("valueExpr",← match value with | none => pure Json.null | some v => checked (encodeExpr v)),
    ("isProposition",toJson prop),("isInstance",toJson (Lean.Meta.isInstanceCore env ci.name)),
    ("axioms",toJson (axs.map Name.toString)),("typeAxioms",toJson (taxs.map Name.toString)),
    ("valueAxioms",toJson (vaxs.map Name.toString)),
    ("binderInventory",toJson (binderInventory ci.type)),
    ("valueBinderInventory",toJson (match value with | none => #[] | some v => binderInventory v)),
    ("recursorRuleRhs",Json.arr rules),
    ("computationShape",← checked (computationShape ci pure)),
    ("structure",← structureJson ci),
    ("hasSorryAx",toJson (axs.contains `sorryAx)),
    ("theoremProofValueRead",toJson (prop && value.isSome))]

-- Only real, closed, zero-universe Prop values can fill unmapped proof support.
-- A non-Prop dependency always requires an explicit data map.
def proofClosure (initial : Array Name) (mapped : Array Name) : MetaM (Array Json) := do
  let mut queue := initial
  let mut seen : Array Name := #[]
  let mut out : Array Json := #[]
  let mut i := 0
  while i < queue.size do
    let n := queue[i]!
    i := i + 1
    unless seen.contains n do
      seen := seen.push n
      let ci ← getConstInfo n
      unless ci.levelParams.isEmpty && (← isProp ci.type) do
        throwError "Unmapped support is not closed zero-universe Prop; actual data mapping required: {n}"
      let v ← getValue ci
      requireClosed s!"proof support {n}" v
      let axs ← collectAxioms n
      let taxs ← expressionAxioms ci.type
      let vaxs ← expressionAxioms v
      for xs in #[axs,taxs,vaxs] do ensureStandard s!"proof support {n}" xs
      for e in #[ci.type,v] do
        for dep in e.getUsedConstants do
          if sourceProject dep && !mapped.contains dep && !seen.contains dep && !queue.contains dep then
            queue := queue.push dep
      out := out.push (Json.mkObj [
        ("name",toJson n.toString),("nameExpr",encodeName n),
        ("actualTypeExpr",← checked (encodeExpr ci.type)),
        ("actualProofExpr",← checked (encodeExpr v)),
        ("levelParams",Json.arr #[]),("isProposition",toJson true),("isClosed",toJson true),
        ("axioms",toJson (axs.map Name.toString)),("typeAxioms",toJson (taxs.map Name.toString)),
        ("proofAxioms",toJson (vaxs.map Name.toString))])
  return out
end BasicMapExport

namespace BasicSourceEnrichment
open Lean Elab Term Meta FoundationAudit BasicMapExport
run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected source4.35.0-rc3"
  let cfg ← jsonFile (← absoluteEnv "BASIC_SOURCE_ENRICH_CONFIG")
  unless (← checked (stringField cfg "schema")) == "Basic-source-enrichment-config/v63" do
    throwError "Wrong source enrichment config"
  let expected ← namesFromJson (← checked (field cfg "sourceExpectedOwnedNames"))
  let owner ← checked (decodeName (← checked (field cfg "expectedSourceOwner")))
  let env ← getEnv
  let owned := (env.constants.fold (fun a n _ =>
    if moduleOf env n == some owner then a.push n else a) (#[] : Array Name)).qsort Name.lt
  unless owned == expected.toArray.qsort Name.lt && owned.size == 99 do
    throwError "The actual Basic-owned inventory changed"
  let supportRows ← checked (arrayField cfg "requiredSourceProofSupport")
  let seeds ← supportRows.mapM fun r => do checked (decodeName (← checked (field r "nameExpr")))
  let mapped ← namesFromJson (← checked (field cfg "knownMappedSourceNames"))
  -- The complete prior 69 pairs are retained; the sole new explicit data map is
  -- resolved from actual compiler Names/owners rather than parsing display strings.
  let pairs ← checked (arrayField cfg "actualNameMapRetained")
  let pairNames ← pairs.mapM fun r => do checked (decodeName (← checked (field r "sourceNameExpr")))
  unless pairNames.qsort Name.lt == mapped.toArray.qsort Name.lt do
    throwError "Complete actual name map does not match mapped source Names"
  for r in pairs do
    let n ← checked (decodeName (← checked (field r "sourceNameExpr")))
    let ci ← getConstInfo n
    unless ci.name.toString == (← checked (stringField r "sourceName")) do
      throwError "Actual source Name differs from recorded display: {n}"
  let extraRows ← checked (arrayField cfg "explicitSourceDataMaps")
  let extraRecords ← extraRows.mapM fun r => do
    let n ← checked (decodeName (← checked (field r "sourceNameExpr")))
    let owner ← checked (decodeName (← checked (field r "sourceOwnerExpr")))
    let ci ← getConstInfo n
    unless moduleOf env n == some owner && kind ci == (← checked (stringField r "sourceKind")) do
      throwError "Explicit mapped data Name/owner/kind changed: {n}"
    unless ci.levelParams == (← namesFromJson (← checked (field r "sourceLevelParams"))) do
      throwError "Explicit mapped data universes changed: {n}"
    if ← isProp ci.type then throwError "Expected explicit non-Prop data: {n}"
    record ci false
  let preservedRows ← checked (arrayField cfg "preservedProofSeeds")
  let preserved ← preservedRows.mapM fun r => do checked (decodeName (← checked (field r "nameExpr")))
  let newRoots ← namesFromJson (← checked (field cfg "newRootNames"))
  unless preserved.size == 9 && newRoots.length == 2 && seeds == preserved ++ newRoots.toArray do
    throwError "Expected exactly nine preserved proof seeds followed by two new roots"
  for n in newRoots do
    unless moduleOf env n == some owner do throwError "New root is not owned by Basic: {n}"
  let proofs ← proofClosure seeds mapped.toArray
  let proofNames ← proofs.mapM fun p => do checked (decodeName (← checked (field p "nameExpr")))
  let records ← owned.mapM fun n => do record (← getConstInfo n) (proofNames.contains n)
  IO.FS.createDirAll (← checked (stringField cfg "outputDirectory"))
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "Basic99-source-enriched/v63"),("compilerVersion",toJson Lean.versionString),
    ("configuration",cfg),("actualOwnedCount",toJson owned.size),("sourceModule",encodeName owner),
    ("records",Json.arr records),("closedSourceProofSupport",Json.arr proofs),
    ("explicitMappedSourceDataRecords",Json.arr extraRecords),
    ("actualNameMapRetained",Json.arr pairs),
    ("rootProofExprExportCompleted",toJson true),
    ("allOriginalTheoremProofValuesRead",toJson false),
    ("onlyExplicitSupportTheoremValuesSerialized",toJson true),
    ("targetCorrespondenceAccepted",toJson false)]).pretty ++ "\n")
  logInfo "Source Basic99 enriched and exact proof-support values exported; target identity remains pending"
end BasicSourceEnrichment
