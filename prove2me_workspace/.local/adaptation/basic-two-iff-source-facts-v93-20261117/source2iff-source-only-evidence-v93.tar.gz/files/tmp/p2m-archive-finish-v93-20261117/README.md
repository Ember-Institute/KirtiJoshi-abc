# v93 只读证据归档入口

此目录所有脚本只读既有证据，仅写本目录的子目录。不调用 CI、编译器、API、Git，不删除文件，不修改主工作区。

## 可先交付的 source2iff 来源事实单元

```bash
python3 /tmp/p2m-archive-finish-v93-20261117/prepare_source2iff_archive.py \
  --evidence-directory /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/basic-two-iff-source-facts-v93-20261117 \
  --output /tmp/p2m-archive-finish-v93-20261117/source2iff-dryrun
```

加 `--archive` 即在该输出目录生成 `source2iff-source-only-evidence-v93.tar.gz`，重开归档逐成员核对 SHA256。`--evidence-directory` 仅用于登记建议，不在该路径写入。主智能体审查后可复制输出到持久目录；应用 registry 前核对 `registry-merge-preconditions.json` 的 base SHA256，保留其余键、图计数、定义、证明节点和边。base 发生变化时重跑。

可参数化 `--final-receipt`、`--query`、`--config`、`--actual`、`--registry`、`--source-ledger`。默认对应真实成功的 `ci-018232-250e8c03`。门控逐项核对回执输入 SHA、exclusive 工作区、实际参数、资源、配置绑定与实际输出 schema；TYPE/value、公理闭包和 BinderInfo 为真实 source4.35.0-rc3 Expr，保留一项辅助的宇宙参数 `u`。旧 99 项 inventory 和九条 support proof 不重算。

交付范围仅 `sourceFactsOnly`：两个来源 iff 和三个生成辅助均为 theorem；没有未映射的项目边界。实际 TYPE/证明值来源于已编译环境读取，本脚本不额外宣称进行目标证明重放或新的内核证明重检。目标匹配／接合与平台发布都没有完成；registry 的 `basic_two_iff_source_facts_unit` 不增加 proved nodes、definitions 或 dependency edges。Basic55、55 项之外的 44 项、S2-04、初始数据存在性及无条件 abc 均不据此关闭。

`SOURCE_LEDGER.json` 记录来源 producer → 实际输出 JSON 指针及审计 query 消费者；尚无 target consumer。主区原有 `SOURCE_LEDGER.json` 不用本文件整份覆盖；在持久单元保留本账本，并让 registry 引用它。计划只勾选“来源提取”，目标 iff 对应另留待办。中文 `[术语待定：compactly bounded subset]` 精确保留。

## Basic55 与 definition 发布

`prepare_archive.py` 接续 v91。`--final-receipt`、`--query`、`--config` 仍可参数化。Definition 发布继续绑定 Basic55 最终验收门；不会因新定义本身已通过 leaf/artifact 就声称来源保真发布完成。新定义私有发布流程及实见 API schema 见 `definition-publication-workflow.md`。

v90 heartbeat fail、v91 same-module initialize abort、v92 unknown constant 均为负证据；必须保留其回执、query/config 回放输入，不能把 v92 当通过。待办计划文字不写“已齐备”。
