#!/usr/bin/env python3
"""Read existing source-only evidence; write exclusively below this task directory.
No CI, compiler, API, Git, deletion, or primary-workspace mutation.
"""
import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
import tarfile

TASK = Path('/tmp/p2m-archive-finish-v93-20261117')
ROOT = Path('/home/admin-wsl/Coq/abc')
W = ROOT / 'prove2me_workspace'
A = W / '.local/adaptation'
BRIDGE = A / 'basic-statementii-bridge-v86-20261117'
CI = A / 'main-chain-open-20261116'
STANDARD = {'propext', 'Classical.choice', 'Quot.sound'}
ROOTS = {'Iut.Tripod.statementII_iff', "Iut.Tripod.statementII_iff'"}
AUX = {"Iut.Tripod.statementII_iff'._simp_1_" + str(i) for i in (1, 2, 3)}
PREBUILT = {'.olean', '.ilean', '.ir', '.o', '.a', '.so'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def name(n):
    return '.'.join(filter(None, [name(n[0]), str(n[2])])) if n else ''


def walk(x):
    if isinstance(x, dict):
        yield x
        for v in x.values():
            yield from walk(v)
    elif isinstance(x, list):
        for v in x:
            yield from walk(v)


def resources(d):
    r = d.get('resources') or d.get('result', {}).get('resources') or {}
    total, user, system = [r.get(k) for k in ('cpu_time_seconds', 'cpu_user_seconds', 'cpu_system_seconds')]
    return {**r, 'cpu_total_equals_user_plus_system': None if None in (total, user, system) else abs(total-user-system) < .02,
            'peak_rss_GiB': r.get('peak_rss_bytes') / 1024**3 if r.get('peak_rss_bytes') is not None else None,
            'peak_pss_GiB': r.get('peak_pss_bytes') / 1024**3 if r.get('peak_pss_bytes') is not None else None,
            'resource_source': r.get('resource_source', r.get('source')), 'resource_degraded': r.get('degraded'),
            'memory_basis': 'MCP-CI process-tree physical RSS/PSS; bytes. Missing source/degraded/PSS are unknown.'}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--final-receipt', type=Path, default=CI / 'basic-statementii-narrow-two-root-aux-v89-result.json')
    ap.add_argument('--query', type=Path, default=BRIDGE / 'queries/QuerySourceTwoRootsAndAuxFacts.lean')
    ap.add_argument('--config', type=Path, default=BRIDGE / 'configs/source-two-roots-aux-facts.json')
    ap.add_argument('--actual', type=Path, default=BRIDGE / 'actual/source-two-roots-and-aux.json')
    ap.add_argument('--registry', type=Path, default=A / 'platform-node-registry.json')
    ap.add_argument('--source-ledger', type=Path, default=A / 'reference-extraction-20261115/SOURCE_LEDGER.json')
    ap.add_argument('--evidence-directory', type=Path, help='Intended persistent location, used in proposals only; no writes there')
    ap.add_argument('--output', type=Path, default=TASK / 'source2iff-dryrun')
    ap.add_argument('--archive', action='store_true', help='Require source-only gates; make and reopen content archive')
    args = ap.parse_args()
    out = args.output.resolve()
    assert TASK in out.parents and out != TASK, 'output must be a child of the task directory'
    assert not out.is_symlink()
    out.mkdir(parents=True, exist_ok=True)
    evidence = args.evidence_directory.resolve() if args.evidence_directory else out
    cfg, actual, receipt = read(args.config), read(args.actual), read(args.final_receipt)
    gates, errors = {}, {}

    def gate(key, f):
        try:
            f()
            gates[key] = True
        except (AssertionError, OSError, ValueError, TypeError, KeyError) as e:
            gates[key] = False
            errors[key] = str(e)

    def accepted_source_job():
        q, r = receipt['request'], receipt['result']
        assert receipt['status'] == 'succeeded' and r['exit_code'] == 0
        assert q['language'] == 'lean' and q['task_type'] == 'leaf' and q['target'] == 'file'
        assert Path(q['workspace']).resolve() == W.resolve() and q['exclusive'] is True
        assert r['snapshot']['workspace_mode'] == 'exclusive_worktree' and r['snapshot']['snapshot_id'] is None
        assert (W / q['parameters']['source']).resolve() == args.query.resolve()
        assert r['actual_arguments'] == ['lean', q['parameters']['source']]
        assert Path(q['environment']['BASIC_SOURCE_ROOT_AUX_CONFIG']).resolve() == args.config.resolve()
        assert not [d for d in r.get('diagnostics', []) if d.get('severity') == 'error']
        rss = resources(receipt)['peak_rss_bytes']
        assert rss is not None and rss <= 16 * 1024**3
        assert resources(receipt)['cpu_total_equals_user_plus_system'] is True
        for p, digest in q['worktree_manifest']['input_hashes'].items():
            assert sha(p) == digest, 'accepted source input changed: ' + p
        for p in (args.query, args.config):
            assert q['worktree_manifest']['input_hashes'][str(p.resolve())] == sha(p)
    gate('accepted_source_leaf_and_unchanged_recorded_inputs', accepted_source_job)

    def actual_source_schema():
        assert actual['schema'] == 'Basic-two-root-generated-aux-source-facts/v87'
        assert actual['compilerVersion'] == '4.35.0-rc3'
        assert cfg['schema'] == 'Basic-two-root-aux-source-config/v87' and actual['configuration'] == cfg
        assert Path(cfg['outputFile']).resolve() == args.actual.resolve()
        assert name(actual['sourceOwnerExpr']) == 'Iut.Tripod.Basic'
        assert {name(n) for n in cfg['rootNames']} == ROOTS
        assert len(actual['rootRows']) == 2 and {r['name'] for r in actual['rootRows']} == ROOTS
        assert len(actual['ownedGeneratedDependencyRows']) == 3 and {r['name'] for r in actual['ownedGeneratedDependencyRows']} == AUX
        assert actual['unmappedExternalProjectBoundaries'] == []
        assert actual['rootProofExprExportCompleted'] is True
        assert actual['recomputedBasic99Inventory'] is False and actual['recomputedOldNineProofSupport'] is False
        assert actual['nonPropValuesAreSourceFactsOnly'] is True
        assert actual['targetMappingAccepted'] is False and actual['targetCorrespondenceAccepted'] is False
        for k in ('baseBasic99InventoryUnchanged', 'oldProofClosureUnchanged'):
            assert cfg[k] is True
        for k in ('preservedNineActualProofFacts', 'baseBasic99AndOldNineSourceFacts'):
            b = cfg[k]
            assert sha(b['path']) == b['sha256'], 'preserved source facts changed: ' + k
        source_inputs = receipt['request']['worktree_manifest']['input_hashes']
        assert cfg['sourceEffectiveSHA256SuppliedByRoot'] in source_inputs.values()
    gate('source_only_schema_two_roots_three_aux_no_missing_boundary', actual_source_schema)

    def theorem_facts():
        rows = actual['rootRows'] + actual['ownedGeneratedDependencyRows']
        for row in rows:
            assert name(row['nameExpr']) == row['name'] and row['owner'] == 'Iut.Tripod.Basic'
            assert row['constantKind'] == 'theorem' and row['isProposition'] is True
            assert row['typeIsClosed'] is True and row['valueIsClosed'] is True
            assert row['targetMappingAccepted'] is False and row['usableAsArbitraryProofSupport'] is False
            for field in ('axioms', 'typeAxioms', 'valueAxioms'):
                assert set(row[field]) <= STANDARD, 'nonstandard axiom: ' + row['name']
            for field in ('actualTypeExpr', 'actualValueExpr'):
                assert isinstance(row[field], dict) and 'kind' in row[field]
                for node in walk(row[field]):
                    assert node.get('kind') not in ('fvar', 'mvar'), 'open expression'
                    assert not (node.get('kind') == 'const' and name(node['name']) == 'sorryAx'), 'sorryAx expression'
            assert isinstance(row['typeBinderInventory'], list) and isinstance(row['valueBinderInventory'], list)
        universe = [r for r in rows if r['levelParams']]
        assert len(universe) == 1 and universe[0]['name'] == "Iut.Tripod.statementII_iff'._simp_1_1"
        assert [name(n) for n in universe[0]['levelParams']] == ['u']
    gate('actual_source_theorem_type_value_binders_axioms_and_universe_retained', theorem_facts)
    complete = all(gates.values())
    state = {'schema': 'Basic-two-iff-source-only-archive-gates/v93', 'complete': complete,
             'gates': gates, 'errors': errors, 'sourceFactsOnly': True,
             'targetMappingAccepted': False, 'targetCorrespondenceAccepted': False, 'platformPublicationPerformed': False,
             'Basic55Accepted': False, 'Basic99Integrated': False, 'S2_04Completed': False,
             'initialDataExistenceProved': False, 'unconditionalABCProved': False,
             'mainWorkspaceWritten': False, 'compilationOrAPIOrGitExecuted': False}
    write(out / 'completion-gates.json', state)
    rows = actual['rootRows'] + actual['ownedGeneratedDependencyRows']
    ledger = {'schema': 'Basic-two-iff-source-consumer-ledger/v93',
              'status': 'ACCEPTED_SOURCE_FACTS_ONLY' if complete else 'PENDING_SOURCE_FACT_GATES',
              'sourceFactsOnly': True, 'jobId': receipt['job_id'], 'sourceModule': 'Iut.Tripod.Basic',
              'actual': str(args.actual), 'actualSHA256': sha(args.actual), 'config': str(args.config), 'configSHA256': sha(args.config),
              'query': str(args.query), 'querySHA256': sha(args.query), 'rootCount': 2, 'ownedGeneratedAuxCount': 3,
              'unmappedExternalProjectBoundaries': actual['unmappedExternalProjectBoundaries'],
              'producerConsumers': [{'source': row['name'], 'kind': row['constantKind'], 'levelParams': row['levelParams'],
                    'sourceFactConsumer': str(args.actual) + ('#/rootRows/' if i < 2 else '#/ownedGeneratedDependencyRows/') + str(i if i < 2 else i-2),
                    'auditConsumer': str(args.query), 'targetConsumer': None,
                    'fidelity': 'Actual source compiler TYPE and proof value, owner, universe parameters, binders and standard-axiom closure. Target mapping pending.',
                    'targetMappingAccepted': False} for i, row in enumerate(rows)],
              'priorSourceLedger': str(args.source_ledger), 'priorSourceLedgerSHA256': sha(args.source_ledger),
              'sourceTheoremProofBodiesRead': True, 'targetProofReplayAccepted': False,
              'oldNineProofSupportRecomputed': False, 'Basic99InventoryRecomputed': False,
              'terminology': {'english': 'compactly bounded subset', 'zh-CN': '[术语待定：compactly bounded subset]', 'status': 'OPEN_TERMINOLOGY_DECISION'},
              'mathematicalParentClosed': False, 'S2_04Completed': False, 'platformPublicationPerformed': False}
    write(out / 'SOURCE_LEDGER.json', ledger)
    write(out / 'ci-history.json', [{'path': str(args.final_receipt), **receipt, 'normalizedResources': resources(receipt)}])
    unit = {'schema': 'Basic-two-iff-source-only-progress/v93', 'status': ledger['status'],
            'sourceFactsOnly': True, 'sourceModule': 'Iut.Tripod.Basic', 'rootCount': 2, 'ownedGeneratedAuxCount': 3,
            'universeAuxRetained': "Iut.Tripod.statementII_iff'._simp_1_1.{u}",
            'unmappedExternalProjectBoundaryCount': 0, 'evidenceDirectory': str(evidence),
            'sourceLedger': str(evidence / 'SOURCE_LEDGER.json'), 'archive': str(evidence / 'source2iff-source-only-evidence-v93.tar.gz'),
            'jobId': receipt['job_id'], 'actualSHA256': sha(args.actual), 'targetMappingAccepted': False,
            'targetCorrespondenceAccepted': False, 'platformPublicationPerformed': False, 'rootGraphMembership': False,
            'S2_04Completed': False, 'mathematicalParentClosed': False}
    fragment = {'reference_source_preparation': {'basic_two_iff_source_facts_unit': unit}}
    write(out / 'registry-merge-fragment.json', fragment)
    registry = read(args.registry)
    merged = copy.deepcopy(registry)
    merged['reference_source_preparation'].update(fragment['reference_source_preparation'])
    write(out / 'platform-node-registry.merged.json', merged)
    write(out / 'registry-merge-preconditions.json', {'basePath': str(args.registry), 'baseSHA256': sha(args.registry),
        'replaceExactPaths': ['/reference_source_preparation/basic_two_iff_source_facts_unit'],
        'mayApplySourceOnlyProgress': complete, 'preserveAllOtherKeysAndGraphCounts': True,
        'doesNotAppendDefinitionsOrProvedNodesOrEdges': True})
    (out / 'plan-append-proposal.md').write_text(
        '- [' + ('x' if complete else ' ') + '] 单独提取 `Iut.Tripod.Basic` 中两个 `statementII_iff` 来源定理及三项真实生成辅助定理的完整类型与证明值，保留模块归属、绑定信息、公理闭包和一项辅助的宇宙参数 `u`；源叶回执 `'
        + receipt['job_id'] + '`。仅验收来源事实，无未映射项目边界；未执行平台发布。\n'
        '- [ ] 完成上述两个 iff 与实际目标及其生成辅助的对应和接合验收。Basic55 对应仍待通过；其余 44 项未因此验收。S2-04、初始数据存在性和无条件 abc 证明仍开放。\n'
        '- [ ] 保留中文术语 `[术语待定：compactly bounded subset]`，定译另行核对。\n')
    files, pins = {}, {}
    def add(path):
        p = Path(path).absolute()
        if not p.is_file():
            return
        item = {'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}
        if '.lake' in p.parts or p.suffix in PREBUILT or p.is_symlink():
            pins[str(p)] = {**item, 'copied': False}
        else:
            files[str(p)] = {**item, 'member': 'files/' + str(p).lstrip('/')}
    for p in (args.final_receipt, args.query, args.config, args.actual, args.registry, args.source_ledger,
              Path(__file__), TASK / 'README.md', ROOT / 'docs/开发计划.Prove2Me适配.md'):
        add(p)
    for p in receipt['request']['worktree_manifest']['input_hashes']:
        add(p)
    for k in ('preservedNineActualProofFacts', 'baseBasic99AndOldNineSourceFacts'):
        add(cfg[k]['path'])
    # Preserve failed source-only attempts, their receipts and exact stated replay inputs.
    # Never scan unrelated proof trees or artifact-store internals.
    previous = []
    prefixes = {p['job_id'] for p in cfg.get('previousAttempts', [])}
    for p in CI.glob('basic-statementii-*-result.json'):
        d = read(p)
        if any(str(d.get('job_id', '')).startswith(prefix) for prefix in prefixes):
            add(p)
            previous.append({'path': str(p), 'jobId': d['job_id'], 'status': d['status'],
                             'resources': resources(d), 'recordedInputHashes': d['request']['worktree_manifest'].get('input_hashes', {})})
            for f in d['request']['worktree_manifest'].get('input_hashes', {}):
                add(f)
    write(out / 'failed-source-attempts.json', previous)
    for artifact in receipt['result'].get('artifacts', []):
        pins[str(artifact)] = {'path': str(artifact), 'copied': False, 'reason': 'MCP-CI artifact-store reference retained from receipt; not accessed'}
    write(out / 'prebuilt-pins.json', list(pins.values()))
    for p in out.iterdir():
        if p.is_file() and p.suffix in ('.json', '.md') and p.name != 'archive-manifest.json':
            add(p)
    manifest = {'schema': 'Basic-two-iff-source-only-content-archive/v93', 'sourceFactsOnly': True,
        'complete': complete, 'archiveCreated': False, 'files': [files[k] for k in sorted(files)],
        'policy': 'Source-only immutable receipt and TYPE/value evidence; no target-matching acceptance, publication, cache traversal, deletion, API, CI, Git or main-workspace write.'}
    write(out / 'archive-manifest.json', manifest)
    if args.archive:
        assert complete, 'source-only archive gates failed; inspect completion-gates.json'
        archive = out / 'source2iff-source-only-evidence-v93.tar.gz'
        index = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
        with tarfile.open(archive, 'w:gz') as t:
            info = tarfile.TarInfo('archive-index.json'); info.size = len(index)
            t.addfile(info, io.BytesIO(index))
            for item in manifest['files']:
                assert sha(item['path']) == item['sha256'], 'input changed during archiving'
                t.add(item['path'], arcname=item['member'], recursive=False)
        with tarfile.open(archive, 'r:gz') as t:
            assert len(t.getmembers()) == len(manifest['files']) + 1
            assert t.extractfile('archive-index.json').read() == index
            for item in manifest['files']:
                assert hashlib.sha256(t.extractfile(item['member']).read()).hexdigest() == item['sha256']
                assert sha(item['path']) == item['sha256'], 'input changed after archiving'
        manifest.update(archiveCreated=True, archive=str(archive), archiveSHA256=sha(archive),
                        archiveBytes=archive.stat().st_size, allMembersReopenedSHA256Verified=True)
        write(out / 'archive-manifest.json', manifest)
    print(json.dumps({'complete': complete, 'sourceFactsOnly': True, 'gates': gates, 'errors': errors,
                      'fileCount': len(files), 'output': str(out), 'archiveCreated': manifest['archiveCreated']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
