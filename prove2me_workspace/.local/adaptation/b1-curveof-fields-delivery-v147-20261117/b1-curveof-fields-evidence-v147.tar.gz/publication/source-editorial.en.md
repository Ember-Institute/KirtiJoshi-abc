## Original paper context

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

> Suppose that $X=\mathbb P^1_{\mathbb Q}$ is the projective line over $\mathbb Q$, and that $D\subseteq X$ is the divisor consisting of the three points “$0$”, “$1$”, and “$\infty$”. We shall regard $X$ as the “$\lambda$-line” — i.e., we shall regard the standard coordinate on $X=\mathbb P^1_{\mathbb Q}$ as the “$\lambda$” in the Legendre form “$y^2=x(x-1)(x-\lambda)$” of the Weierstrass equation defining an elliptic curve — and hence as being equipped with a natural classifying morphism $U_X\to(\mathcal M_{\mathrm{ell}})_{\mathbb Q}$ [cf. the discussion preceding Proposition 1.8].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`. The later hypotheses and conclusions of this corollary are outside the excerpt.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

> $F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.

The final sentence of Definition 3.1(b), spanning printed/PDF pages 61–62, states:

> Here, we suppose further that the field extension $F/F_{\mathrm{mod}}$ is Galois of degree prime to $l$, and that the $2\cdot3$-torsion points of $E_F$ are rational over $F$.

Definition 3.1(c), first sentence through the definition of $K$, printed/PDF page 62:

> $l$ is a prime number $\geq5$ such that the image of the outer homomorphism
> 
> $$G_F\to GL_2(\mathbb F_l)$$
> 
> determined by the $l$-torsion points of $E_F$ contains the subgroup $SL_2(\mathbb F_l)\subseteq GL_2(\mathbb F_l)$; write $K\subseteq\overline F$ for the finite Galois extension of $F$ determined by the kernel of this homomorphism.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`. These are separate excerpts. The intervening material in (b) and the later material in (c) are omitted.

## Adaptation scope

The Legendre passage supplies the curve-family background. The number field, selected closure, field-of-moduli extension, and torsion passages supply the arithmetic setting. In those passages, the parameter avoids $0,1$ on the open parameter line, and the selected prime has the stated restrictions. These hypotheses are not silently added to the eight definitions, which accept every algebraic parameter and every natural torsion index where those arguments occur.

The full field

$$F_\lambda=\mathbb Q\bigl(\lambda,i,s(\lambda),t(\lambda),C_{\lambda,3},C_{\lambda,5}\bigr),$$

with $i^2=-1$, $s(\lambda)^2=\lambda$, and $t(\lambda)^2=1-\lambda$, is the reference project's explicit construction. Here $C_{\lambda,n}$ collects **both affine coordinate values** of all nonsingular points killed by $n$; the point at infinity contributes no values. The full generating set, including all three selected square roots, is not presented as a verbatim formula of the quotations. The field is defined as the intermediate-field adjoin, not as a proved minimal field of definition of the curve.

The root choices specify no signs or compatibility rules. `coords` retains an unordered set of coordinate values. `torsionSet` means killed by $n$, not exact order $n$; `TorsionFinite` is the proposition that this set is finite. `torsionCoords` is its union of coordinate sets. `fieldOf'` uses the indices 3 and 5 and requires no proof of this finiteness predicate. None of these pure definitions proves torsion finiteness, finite extension degree, a number-field structure, the Galois property, or independence from the selected roots. Such statements require separate mathematical results.

## Intuitive explanation (non-rigorous)

The definitions collect a parameter, selected square roots, and the coordinates of two specified torsion sets into one subfield of a fixed algebraic closure. Adjoining these values gives a place to express the chosen equation and those coordinate values together. The properties of that field are separate questions.

