# English

## sqrtNegOne

Let $\overline{\mathbb Q}$ be the algebraic closure of the rational field used in the code. The declaration defines a single element $i\in\overline{\mathbb Q}$ by choosing a witness to the existence of an element whose square is $-1$. Thus $i^2=-1$. This is a noncomputable choice, with no input parameter and no rule selecting a particular sign; it does not assert uniqueness of the square root.

## sqrtLam

For every $\lambda\in\overline{\mathbb Q}$, where $\overline{\mathbb Q}$ is the algebraic closure of the rational field used in the code, the declaration defines $s(\lambda)\in\overline{\mathbb Q}$ by choosing a witness to $s(\lambda)^2=\lambda$. This is a noncomputable function of $\lambda$, with no nonzero or other restriction on $\lambda$. In particular, $\lambda=0$ is allowed and its square root must be $0$. No sign rule or additional compatibility among the selected roots is specified, and no uniqueness of a square root for general $\lambda$ is asserted.

## sqrtOneSubLam

For every $\lambda\in\overline{\mathbb Q}$, where $\overline{\mathbb Q}$ is the algebraic closure of the rational field used in the code, the declaration defines $t(\lambda)\in\overline{\mathbb Q}$ by choosing a witness to $t(\lambda)^2=1-\lambda$. This is a noncomputable function of $\lambda$, with no exclusion of $\lambda=0$ or $\lambda=1$. At $\lambda=1$ the selected root must be $0$. No sign rule, additional compatibility with the other root selections, or uniqueness of a square root for general $\lambda$ is asserted.

## coords

For every implicit parameter $\lambda\in\overline{\mathbb Q}$, the declaration defines a function from the point type of the Weierstrass curve $y^2=x^3-(1+\lambda)x^2+\lambda x$ to subsets of $\overline{\mathbb Q}$, where $\overline{\mathbb Q}$ is the algebraic closure of the rational field. This point type consists of the point at infinity $O$ and the nonsingular affine points $(x,y)$ on that equation; here nonsingularity means that $3x^2-2(1+\lambda)x+\lambda\ne0$ or $2y\ne0$. The function sends $O$, which is also the group identity denoted by $0$, to the empty set, and sends each such affine point $(x,y)$ to the unordered set $\{x,y\}$. This is a set of coordinate values, not an ordered pair; if $x=y$, it is a singleton. The parameter may equal $0$ or $1$, and even for these parameters the input point type includes only nonsingular affine points together with $O$.

## torsionSet

For every $\lambda\in\overline{\mathbb Q}$ and every natural number $n\ge0$, the declaration defines $T_{\lambda,n}=\{P\in G_\lambda:nP=O\}$ as a subset of $G_\lambda$. Here $\overline{\mathbb Q}$ is the algebraic closure of the rational field, and $G_\lambda$ is the commutative group consisting of the point at infinity $O$ and the nonsingular affine points on $y^2=x^3-(1+\lambda)x^2+\lambda x$, with the imported Weierstrass point addition; an affine point is nonsingular when $3x^2-2(1+\lambda)x+\lambda\ne0$ or $2y\ne0$. The expression $nP$ means repeated group addition, and $O$ is the identity. Membership requires that $P$ be killed by $n$, not that $P$ have exact order $n$. There is no exclusion of $\lambda=0,1$ and no assumption $n\ne0$: $T_{\lambda,0}$ is all of $G_\lambda$, $T_{\lambda,1}=\{O\}$, and $O$ belongs for every $n$. The definition does not assert finiteness of these sets.

## TorsionFinite

For every $\lambda\in\overline{\mathbb Q}$ and every natural number $n\ge0$, the declaration defines a proposition that the set $\{P\in G_\lambda:nP=O\}$ is finite. Here $\overline{\mathbb Q}$ is the algebraic closure of the rational field, and $G_\lambda$ is the commutative group of the point at infinity $O$ and the nonsingular affine points on $y^2=x^3-(1+\lambda)x^2+\lambda x$, with the imported Weierstrass addition; nonsingularity of an affine point means $3x^2-2(1+\lambda)x+\lambda\ne0$ or $2y\ne0$. The parameter $\lambda$ may be $0$ or $1$, and $nP$ denotes repeated group addition, with $O$ as identity. This declares a finiteness condition, not a proof that the condition holds. There is no hypothesis $n\ne0$; when $n=0$, the condition says that the whole group $G_\lambda$ is finite. For $n=1$ the set in the condition is $\{O\}$.

## torsionCoords

For every $\lambda\in\overline{\mathbb Q}$ and every natural number $n\ge0$, the declaration defines a subset $C_{\lambda,n}$ of $\overline{\mathbb Q}$ as the union of the coordinate sets of all $P\in G_\lambda$ such that $nP=O$. Here $\overline{\mathbb Q}$ is the algebraic closure of the rational field, and $G_\lambda$ is the commutative group consisting of the point at infinity $O$ and the nonsingular affine points on $y^2=x^3-(1+\lambda)x^2+\lambda x$, with the imported Weierstrass addition; nonsingularity means $3x^2-2(1+\lambda)x+\lambda\ne0$ or $2y\ne0$. The coordinate set of $O$ is empty, and that of an affine point $(x,y)$ is $\{x,y\}$. Equivalently, $a\in C_{\lambda,n}$ precisely when there is a nonsingular affine point $(x,y)$ killed by $n$ such that $a=x$ or $a=y$. Thus the set retains coordinate values, without ordering, multiplicities, or their pairing into points. No restriction excludes $\lambda=0,1$ or $n=0$. When $n=0$ this collects the coordinates of all nonsingular affine points; when $n=1$ it is empty. The definition assumes no finiteness condition and proves none.

## fieldOf'

For every $\lambda\in\overline{\mathbb Q}$, the declaration defines an intermediate field $F_\lambda$ between $\mathbb Q$ and its algebraic closure $\overline{\mathbb Q}$: it is the smallest subfield of $\overline{\mathbb Q}$ containing the image of $\mathbb Q$, $\lambda$, the previously chosen element $i$ with $i^2=-1$, the previously chosen elements $s(\lambda),t(\lambda)$ with $s(\lambda)^2=\lambda$ and $t(\lambda)^2=1-\lambda$, and every coordinate value of every point killed by $3$ or killed by $5$ in $G_\lambda$. Here $G_\lambda$ is the commutative group, with the imported Weierstrass point addition and identity $O$, consisting of $O$ and the nonsingular affine points on $y^2=x^3-(1+\lambda)x^2+\lambda x$; nonsingularity means $3x^2-2(1+\lambda)x+\lambda\ne0$ or $2y\ne0$. An affine point contributes both values $x,y$, as a set, and $O$ contributes no values. The torsion conditions are $3P=O$ and $5P=O$, rather than exact order $3$ or $5$; the generating set is their union with $\{\lambda,i,s(\lambda),t(\lambda)\}$. This is a noncomputable construction using the stated root selections, with no assertion that those selections are unique or that the result is independent of them. It accepts $\lambda=0,1$ as well as every other element of $\overline{\mathbb Q}$. It takes no torsion-finiteness, finite-degree, number-field, or Galois hypothesis, and the declaration itself supplies no theorem of torsion finiteness, finite degree, number-field structure, or the Galois property.

## Original paper context

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

> Suppose that $X=\mathbb P^1_{\mathbb Q}$ is the projective line over $\mathbb Q$, and that $D\subseteq X$ is the divisor consisting of the three points “$0$”, “$1$”, and “$\infty$”. We shall regard $X$ as the “$\lambda$-line” — i.e., we shall regard the standard coordinate on $X=\mathbb P^1_{\mathbb Q}$ as the “$\lambda$” in the Legendre form “$y^2=x(x-1)(x-\lambda)$” of the Weierstrass equation defining an elliptic curve — and hence as being equipped with a natural classifying morphism $U_X\to(\mathcal M_{\mathrm{ell}})_{\mathbb Q}$ [cf. the discussion preceding Proposition 1.8].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`. The later hypotheses and conclusions of this corollary are outside the excerpt.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

> $F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.

The final sentence of Definition 3.1(b), spanning printed/PDF pages 61–62, states:

> Here, we suppose further that the field extension $F/F_{\mathrm{mod}}$ is Galois of degree prime to $l$, and that the $2\cdot3$-torsion points of $E_F$ are rational over $F$.

Definition 3.1(c), first sentence through the definition of $K$, printed/PDF page 62:

> $l$ is a prime number $\geq5$ such that the image of the outer homomorphism
> 
> $$G_F\to GL_2(\mathbb F_l)$$
> 
> determined by the $l$-torsion points of $E_F$ contains the subgroup $SL_2(\mathbb F_l)\subseteq GL_2(\mathbb F_l)$; write $K\subseteq\overline F$ for the finite Galois extension of $F$ determined by the kernel of this homomorphism.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`. These are separate excerpts. The intervening material in (b) and the later material in (c) are omitted.

## Adaptation scope

The Legendre passage supplies the curve-family background. The number field, selected closure, field-of-moduli extension, and torsion passages supply the arithmetic setting. In those passages, the parameter avoids $0,1$ on the open parameter line, and the selected prime has the stated restrictions. These hypotheses are not silently added to the eight definitions, which accept every algebraic parameter and every natural torsion index where those arguments occur.

The full field

$$F_\lambda=\mathbb Q\bigl(\lambda,i,s(\lambda),t(\lambda),C_{\lambda,3},C_{\lambda,5}\bigr),$$

with $i^2=-1$, $s(\lambda)^2=\lambda$, and $t(\lambda)^2=1-\lambda$, is the reference project's explicit construction. Here $C_{\lambda,n}$ collects **both affine coordinate values** of all nonsingular points killed by $n$; the point at infinity contributes no values. The full generating set, including all three selected square roots, is not presented as a verbatim formula of the quotations. The field is defined as the intermediate-field adjoin, not as a proved minimal field of definition of the curve.

The root choices specify no signs or compatibility rules. `coords` retains an unordered set of coordinate values. `torsionSet` means killed by $n$, not exact order $n$; `TorsionFinite` is the proposition that this set is finite. `torsionCoords` is its union of coordinate sets. `fieldOf'` uses the indices 3 and 5 and requires no proof of this finiteness predicate. None of these pure definitions proves torsion finiteness, finite extension degree, a number-field structure, the Galois property, or independence from the selected roots. Such statements require separate mathematical results.

## Intuitive explanation (non-rigorous)

The definitions collect a parameter, selected square roots, and the coordinates of two specified torsion sets into one subfield of a fixed algebraic closure. Adjoining these values gives a place to express the chosen equation and those coordinate values together. The properties of that field are separate questions.


# 简体中文

## sqrtNegOne

设 $\overline{\mathbb Q}$ 为代码使用的有理数域的代数闭包。该声明从平方等于 $-1$ 的元素存在性命题中选取一个见证，定义单个元素 $i\in\overline{\mathbb Q}$，因而 $i^2=-1$。这是不带输入参数的非可计算选择，没有指定选取哪一个符号，也没有断言平方根唯一。

## sqrtLam

对代码所用的有理数域的代数闭包 $\overline{\mathbb Q}$ 中的每个 $\lambda$，该声明通过选取 $s(\lambda)^2=\lambda$ 的一个见证，定义元素 $s(\lambda)\in\overline{\mathbb Q}$。这是以 $\lambda$ 为参数的非可计算函数，不要求 $\lambda$ 非零，也没有其他限制。特别地，允许 $\lambda=0$，此时平方根必为 $0$。该声明没有指定符号规则或所选各平方根之间的额外相容关系，也没有断言一般 $\lambda$ 的平方根唯一。

## sqrtOneSubLam

对代码所用的有理数域的代数闭包 $\overline{\mathbb Q}$ 中的每个 $\lambda$，该声明通过选取 $t(\lambda)^2=1-\lambda$ 的一个见证，定义元素 $t(\lambda)\in\overline{\mathbb Q}$。这是以 $\lambda$ 为参数的非可计算函数，不排除 $\lambda=0$ 或 $\lambda=1$。在 $\lambda=1$ 时，所选平方根必为 $0$。该声明没有指定符号规则或与其他平方根选择的额外相容关系，也没有断言一般 $\lambda$ 的平方根唯一。

## coords

对每个隐式参数 $\lambda\in\overline{\mathbb Q}$，该声明定义一个从 Weierstrass 曲线 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 的点类型到 $\overline{\mathbb Q}$ 的子集的函数，其中 $\overline{\mathbb Q}$ 为有理数域的代数闭包。该点类型由无穷远点 $O$ 和此方程上的非奇异仿射点 $(x,y)$ 组成；这里非奇异是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。函数把无穷远点 $O$ 映为空集；$O$ 也是记为 $0$ 的群单位元。函数把每个这样的仿射点 $(x,y)$ 映为无序集合 $\{x,y\}$。这是坐标值的集合，不是有序对；若 $x=y$，则为单元素集合。参数可以等于 $0$ 或 $1$；即使在这些参数下，输入点类型仍然只含非奇异仿射点与 $O$。

## torsionSet

对每个 $\lambda\in\overline{\mathbb Q}$ 和每个自然数 $n\ge0$，该声明定义 $G_\lambda$ 的子集 $T_{\lambda,n}=\{P\in G_\lambda:nP=O\}$。这里 $\overline{\mathbb Q}$ 为有理数域的代数闭包；$G_\lambda$ 是由无穷远点 $O$ 和方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上的非奇异仿射点组成的交换群，采用导入的 Weierstrass 点加法；仿射点的非奇异性是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。式中 $nP$ 表示反复施行群加法，$O$ 为单位元。属于该集合的条件是 $P$ 的 $n$ 倍为单位元，而不是 $P$ 的阶恰为 $n$。定义不排除 $\lambda=0,1$，也不要求 $n\ne0$：$T_{\lambda,0}$ 是整个 $G_\lambda$，$T_{\lambda,1}=\{O\}$，并且每个 $n$ 的情形都包含 $O$。该定义没有断言这些集合有限。

## TorsionFinite

对每个 $\lambda\in\overline{\mathbb Q}$ 和每个自然数 $n\ge0$，该声明定义一个命题：集合 $\{P\in G_\lambda:nP=O\}$ 有限。这里 $\overline{\mathbb Q}$ 为有理数域的代数闭包；$G_\lambda$ 是由无穷远点 $O$ 和方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上的非奇异仿射点组成的交换群，采用导入的 Weierstrass 加法；仿射点的非奇异性是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。允许参数 $\lambda$ 为 $0$ 或 $1$，$nP$ 表示反复施行群加法，$O$ 为单位元。该声明定义有限性条件，没有证明此条件成立。它不带 $n\ne0$ 的假设；当 $n=0$ 时，此条件表示整个群 $G_\lambda$ 有限。当 $n=1$ 时，条件中的集合为 $\{O\}$。

## torsionCoords

对每个 $\lambda\in\overline{\mathbb Q}$ 和每个自然数 $n\ge0$，该声明定义 $\overline{\mathbb Q}$ 的子集 $C_{\lambda,n}$，即所有满足 $nP=O$ 的点 $P\in G_\lambda$ 的坐标集合之并。这里 $\overline{\mathbb Q}$ 为有理数域的代数闭包；$G_\lambda$ 是由无穷远点 $O$ 和方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上的非奇异仿射点组成的交换群，采用导入的 Weierstrass 加法；非奇异性是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。$O$ 的坐标集合为空集，仿射点 $(x,y)$ 的坐标集合为 $\{x,y\}$。等价地，$a\in C_{\lambda,n}$ 当且仅当存在一个 $n$ 倍为单位元的非奇异仿射点 $(x,y)$，使得 $a=x$ 或 $a=y$。因此，该集合保留坐标值，不保留顺序、重数或坐标配成点的方式。定义没有排除 $\lambda=0,1$ 或 $n=0$。当 $n=0$ 时，它收集所有非奇异仿射点的坐标；当 $n=1$ 时，它为空集。该定义没有假设任何有限性条件，也没有证明有限性。

## fieldOf'

对每个 $\lambda\in\overline{\mathbb Q}$，该声明定义有理数域 $\mathbb Q$ 与其代数闭包 $\overline{\mathbb Q}$ 之间的中间域 $F_\lambda$：它是 $\overline{\mathbb Q}$ 中包含 $\mathbb Q$ 的像、$\lambda$、此前所选满足 $i^2=-1$ 的元素 $i$、此前所选满足 $s(\lambda)^2=\lambda$ 及 $t(\lambda)^2=1-\lambda$ 的元素 $s(\lambda),t(\lambda)$，以及 $G_\lambda$ 中每个 $3$ 倍为单位元或 $5$ 倍为单位元的点的所有坐标值的最小子域。这里 $G_\lambda$ 采用导入的 Weierstrass 点加法，以 $O$ 为单位元，是由 $O$ 和方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上的非奇异仿射点组成的交换群；非奇异性是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。仿射点以集合的形式提供两个坐标值 $x,y$，而 $O$ 不提供任何坐标值。扭点条件是 $3P=O$ 和 $5P=O$，不是阶恰为 $3$ 或 $5$；生成集合由这两个坐标集合与 $\{\lambda,i,s(\lambda),t(\lambda)\}$ 的并组成。这是使用上述平方根选择的非可计算构造；它没有断言这些选择唯一，也没有断言结果与这些选择无关。它接受 $\lambda=0,1$，也接受 $\overline{\mathbb Q}$ 中的所有其他元素。该声明不带扭点有限性、扩张次数有限、数域或 Galois 性质的假设，本身也没有给出关于扭点有限性、扩张次数有限、数域结构或 Galois 性质的定理。

## 论文原文背景

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2 开头、“Let”之前的完整两句，印刷页与文件页均为第 41 页。精确英文引文见英文部分。该推论后续的前提与结论不在节录中。

官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页；定义 3.1(b) 跨第 61–62 页的末句；定义 3.1(c) 首句至定义 $K$ 为止，印刷页与文件页均为第 62 页。三个精确英文引文块见英文部分，(b) 中间部分及 (c) 后续部分已省略。

官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

## 适配范围

Legendre 段落提供曲线族背景。数域、选定代数闭包、模域上的扩张及挠点段落提供算术设定。在这些段落中，开参数直线的参数避开 $0,1$，选定素数也满足原文限制。这些前提不被悄然加入八个定义；各定义在出现相应参数时，接受所有代数参数及所有自然数挠点指标。

完整的域

$$F_\lambda=\mathbb Q\bigl(\lambda,i,s(\lambda),t(\lambda),C_{\lambda,3},C_{\lambda,5}\bigr),$$

其中 $i^2=-1$、$s(\lambda)^2=\lambda$、$t(\lambda)^2=1-\lambda$，是参考工程的显式构造。这里 $C_{\lambda,n}$ 收集所有被 $n$ 杀死的非奇异点的**两个仿射坐标值**，无穷远点不贡献坐标值。包括三个选定平方根的完整生成集合不称为引文中的逐字公式。该域用中间域生成运算定义，并没有证明它是曲线的最小定义数域。

平方根选择没有规定符号或相容规则。`coords` 保留无序坐标值集合。`torsionSet` 表示被 $n$ 杀死，不是阶恰为 $n$；`TorsionFinite` 是该集合有限这一命题。`torsionCoords` 是其坐标集合之并。`fieldOf'` 使用指标 3 和 5，不要求上述有限性命题的证明。这些纯定义都不证明挠点有限性、扩张次数有限、数域结构、Galois 性质或结果与平方根选择无关；这些结论需要另行证明。

## 直观解释（非严格）

这些定义把参数、选定平方根及两个指定挠点集合的坐标收集到固定代数闭包的一个子域中。添加这些值后，可以在同一个域中表达所选方程与这些坐标值。该域具有什么性质，仍是另一个问题。


# 日本語

## sqrtNegOne

$\overline{\mathbb Q}$ を、コードで用いる有理数体の代数閉包とする。この宣言は、平方が $-1$ となる元の存在命題から一つの証人を選び、単一の元 $i\in\overline{\mathbb Q}$ を定義する。したがって $i^2=-1$ である。これは入力パラメータを持たない非計算的な選択であり、どちらの符号を選ぶかを指定する規則はなく、平方根の一意性も主張しない。

## sqrtLam

コードで用いる有理数体の代数閉包 $\overline{\mathbb Q}$ の各元 $\lambda$ に対し、この宣言は $s(\lambda)^2=\lambda$ の証人を一つ選ぶことにより、元 $s(\lambda)\in\overline{\mathbb Q}$ を定義する。これは $\lambda$ の非計算的な関数であり、$\lambda$ が零でないという条件も、その他の制限もない。特に $\lambda=0$ が許され、この場合の平方根は必ず $0$ である。符号の選択規則や、選ばれた平方根の間の追加の整合条件は指定されておらず、一般の $\lambda$ に対する平方根の一意性も主張しない。

## sqrtOneSubLam

コードで用いる有理数体の代数閉包 $\overline{\mathbb Q}$ の各元 $\lambda$ に対し、この宣言は $t(\lambda)^2=1-\lambda$ の証人を一つ選ぶことにより、元 $t(\lambda)\in\overline{\mathbb Q}$ を定義する。これは $\lambda$ の非計算的な関数であり、$\lambda=0$ も $\lambda=1$ も除外しない。$\lambda=1$ の場合、選ばれる平方根は必ず $0$ である。符号の選択規則、他の平方根の選択との追加の整合条件、一般の $\lambda$ に対する平方根の一意性は主張されていない。

## coords

各暗黙パラメータ $\lambda\in\overline{\mathbb Q}$ に対し、この宣言は、ワイエルシュトラス曲線 $y^2=x^3-(1+\lambda)x^2+\lambda x$ の点の型から $\overline{\mathbb Q}$ の部分集合への関数を定義する。ここで $\overline{\mathbb Q}$ は有理数体の代数閉包である。この点の型は、無限遠点 $O$ と、この方程式を満たす非特異なアフィン点 $(x,y)$ からなる。非特異であるとは、$3x^2-2(1+\lambda)x+\lambda\ne0$ または $2y\ne0$ であることをいう。この関数は、$0$ とも記される群の単位元である $O$ を空集合に送り、各非特異アフィン点 $(x,y)$ を順序のない集合 $\{x,y\}$ に送る。これは座標値の集合であり、順序対ではない。$x=y$ の場合には一元集合となる。パラメータは $0$ または $1$ でもよく、その場合にも入力の点の型に含まれるのは、非特異アフィン点と $O$ のみである。

## torsionSet

各 $\lambda\in\overline{\mathbb Q}$ と各自然数 $n\ge0$ に対し、この宣言は $G_\lambda$ の部分集合 $T_{\lambda,n}=\{P\in G_\lambda:nP=O\}$ を定義する。ここで $\overline{\mathbb Q}$ は有理数体の代数閉包であり、$G_\lambda$ は、無限遠点 $O$ と方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上の非特異アフィン点からなる可換群で、インポートされたワイエルシュトラスの点の加法を持つ。アフィン点が非特異であるとは、$3x^2-2(1+\lambda)x+\lambda\ne0$ または $2y\ne0$ であることをいう。$nP$ は群の加法の反復を表し、$O$ は単位元である。所属条件は $P$ の $n$ 倍が単位元であることであり、$P$ の位数がちょうど $n$ であることではない。$\lambda=0,1$ は除外されず、$n\ne0$ という仮定もない。$T_{\lambda,0}$ は $G_\lambda$ 全体、$T_{\lambda,1}=\{O\}$ であり、すべての $n$ に対して $O$ が含まれる。この定義はこれらの集合の有限性を主張しない。

## TorsionFinite

各 $\lambda\in\overline{\mathbb Q}$ と各自然数 $n\ge0$ に対し、この宣言は、集合 $\{P\in G_\lambda:nP=O\}$ が有限であるという命題を定義する。ここで $\overline{\mathbb Q}$ は有理数体の代数閉包であり、$G_\lambda$ は、無限遠点 $O$ と方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上の非特異アフィン点からなる可換群で、インポートされたワイエルシュトラスの加法を持つ。アフィン点の非特異性とは、$3x^2-2(1+\lambda)x+\lambda\ne0$ または $2y\ne0$ であることをいう。$\lambda$ は $0$ または $1$ でもよく、$nP$ は群の加法の反復を表し、$O$ は単位元である。これは有限性の条件の定義であり、その条件が成立するという証明ではない。$n\ne0$ という仮定はなく、$n=0$ の場合、この条件は群 $G_\lambda$ 全体が有限であることを意味する。$n=1$ の場合、条件中の集合は $\{O\}$ である。

## torsionCoords

各 $\lambda\in\overline{\mathbb Q}$ と各自然数 $n\ge0$ に対し、この宣言は、$nP=O$ を満たすすべての点 $P\in G_\lambda$ の座標集合の合併として、$\overline{\mathbb Q}$ の部分集合 $C_{\lambda,n}$ を定義する。ここで $\overline{\mathbb Q}$ は有理数体の代数閉包であり、$G_\lambda$ は、無限遠点 $O$ と方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上の非特異アフィン点からなる可換群で、インポートされたワイエルシュトラスの加法を持つ。非特異性とは、$3x^2-2(1+\lambda)x+\lambda\ne0$ または $2y\ne0$ であることをいう。$O$ の座標集合は空集合、アフィン点 $(x,y)$ の座標集合は $\{x,y\}$ である。同値な記述として、$a\in C_{\lambda,n}$ であるのは、$n$ 倍が単位元となる非特異アフィン点 $(x,y)$ が存在して、$a=x$ または $a=y$ が成立する場合に限る。この集合が保持するのは座標値であり、順序、重複度、各座標値を点へ組み合わせる情報は保持しない。$\lambda=0,1$ も $n=0$ も除外されない。$n=0$ の場合にはすべての非特異アフィン点の座標を集め、$n=1$ の場合には空集合となる。この定義は有限性を仮定せず、有限性を証明もしない。

## fieldOf'

各 $\lambda\in\overline{\mathbb Q}$ に対し、この宣言は、有理数体 $\mathbb Q$ とその代数閉包 $\overline{\mathbb Q}$ の間の中間体 $F_\lambda$ を定義する。それは、$\mathbb Q$ の像、$\lambda$、既に選ばれた $i^2=-1$ を満たす元 $i$、既に選ばれた $s(\lambda)^2=\lambda$ および $t(\lambda)^2=1-\lambda$ を満たす元 $s(\lambda),t(\lambda)$、ならびに $G_\lambda$ において $3$ 倍または $5$ 倍が単位元となるすべての点のすべての座標値を含む、$\overline{\mathbb Q}$ の最小の部分体である。ここで $G_\lambda$ は、インポートされたワイエルシュトラスの点の加法を持ち、$O$ を単位元とする可換群で、$O$ と方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上の非特異アフィン点からなる。非特異性とは、$3x^2-2(1+\lambda)x+\lambda\ne0$ または $2y\ne0$ であることをいう。アフィン点は二つの値 $x,y$ を集合として提供し、$O$ は座標値を提供しない。ねじれ点の条件は $3P=O$ と $5P=O$ であり、位数がちょうど $3$ または $5$ であることではない。生成集合は、この二つの座標集合と $\{\lambda,i,s(\lambda),t(\lambda)\}$ の合併である。これは上記の平方根の選択を用いる非計算的な構成であり、その選択の一意性も、結果がその選択に依存しないことも主張しない。$\lambda=0,1$ も、$\overline{\mathbb Q}$ の他のすべての元も入力として許される。この宣言は、ねじれ点集合の有限性、有限次数、数体であること、ガロア性に関する仮定を取らず、それ自体では、ねじれ点集合の有限性、有限次数、数体構造、ガロア性の定理を与えない。

## 論文原文の背景

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示した。系の後続の仮定と結論は引用しない。

公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61、定義 3.1(b) の最後の文、同 61–62、および定義 3.1(c) の最初の文から $K$ の定義まで、同 62。三つの正確な英文の引用は英語部分に示した。(b) の中間部分と (c) の後続部分は省略した。

公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

## 移植の範囲

ルジャンドルの段落は曲線族の背景を与える。数体、選ばれた代数閉包、モジュライ体上の拡大、および等分点の段落は算術的設定を与える。これらの段落では、開いたパラメータ直線上のパラメータは $0,1$ を避け、選んだ素数にも原文の制限がある。これらの仮定を八つの定義へ暗黙に加えない。対応する引数を持つ定義は、すべての代数的パラメータとすべての自然数の等分点指数を許す。

完全な体

$$F_\lambda=\mathbb Q\bigl(\lambda,i,s(\lambda),t(\lambda),C_{\lambda,3},C_{\lambda,5}\bigr),$$

ただし $i^2=-1$、$s(\lambda)^2=\lambda$、$t(\lambda)^2=1-\lambda$、は参照プロジェクトの明示的な構成である。ここで $C_{\lambda,n}$ は、$n$ 倍が零となるすべての非特異点の**二つのアフィン座標値**を集める。無限遠点は座標値を与えない。三つの選ばれた平方根を含む完全な生成集合を、引用中の逐語的な式とはしない。この体は中間体の生成操作で定義され、曲線の最小定義体であることが証明されるわけではない。

平方根の選択は符号や整合性の規則を指定しない。`coords` は順序のない座標値集合を保持する。`torsionSet` は $n$ 倍が零となることを意味し、位数がちょうど $n$ であることではない。`TorsionFinite` はその集合が有限であるという命題である。`torsionCoords` はその座標集合の合併である。`fieldOf'` は指数 3 と 5 を用い、その有限性命題の証明を要求しない。これらの純粋な定義は、等分点集合の有限性、有限拡大次数、数体構造、ガロア性、または平方根の選択からの独立性を証明しない。それらには別の数学的結果が必要である。

## 直観的説明（非厳密）

これらの定義は、パラメータ、選ばれた平方根、および二つの指定された等分点集合の座標を、固定した代数閉包の一つの部分体に集める。これらの値を添加すると、選んだ方程式と座標値を同じ体で表せる。その体が持つ性質は別の問題である。

