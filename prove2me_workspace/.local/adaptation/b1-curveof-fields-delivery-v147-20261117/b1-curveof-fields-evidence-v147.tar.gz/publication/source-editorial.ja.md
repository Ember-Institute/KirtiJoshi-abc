## 論文原文の背景

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示した。系の後続の仮定と結論は引用しない。

公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61、定義 3.1(b) の最後の文、同 61–62、および定義 3.1(c) の最初の文から $K$ の定義まで、同 62。三つの正確な英文の引用は英語部分に示した。(b) の中間部分と (c) の後続部分は省略した。

公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

## 移植の範囲

ルジャンドルの段落は曲線族の背景を与える。数体、選ばれた代数閉包、モジュライ体上の拡大、および等分点の段落は算術的設定を与える。これらの段落では、開いたパラメータ直線上のパラメータは $0,1$ を避け、選んだ素数にも原文の制限がある。これらの仮定を八つの定義へ暗黙に加えない。対応する引数を持つ定義は、すべての代数的パラメータとすべての自然数の等分点指数を許す。

完全な体

$$F_\lambda=\mathbb Q\bigl(\lambda,i,s(\lambda),t(\lambda),C_{\lambda,3},C_{\lambda,5}\bigr),$$

ただし $i^2=-1$、$s(\lambda)^2=\lambda$、$t(\lambda)^2=1-\lambda$、は参照プロジェクトの明示的な構成である。ここで $C_{\lambda,n}$ は、$n$ 倍が零となるすべての非特異点の**二つのアフィン座標値**を集める。無限遠点は座標値を与えない。三つの選ばれた平方根を含む完全な生成集合を、引用中の逐語的な式とはしない。この体は中間体の生成操作で定義され、曲線の最小定義体であることが証明されるわけではない。

平方根の選択は符号や整合性の規則を指定しない。`coords` は順序のない座標値集合を保持する。`torsionSet` は $n$ 倍が零となることを意味し、位数がちょうど $n$ であることではない。`TorsionFinite` はその集合が有限であるという命題である。`torsionCoords` はその座標集合の合併である。`fieldOf'` は指数 3 と 5 を用い、その有限性命題の証明を要求しない。これらの純粋な定義は、等分点集合の有限性、有限拡大次数、数体構造、ガロア性、または平方根の選択からの独立性を証明しない。それらには別の数学的結果が必要である。

## 直観的説明（非厳密）

これらの定義は、パラメータ、選ばれた平方根、および二つの指定された等分点集合の座標を、固定した代数閉包の一つの部分体に集める。これらの値を添加すると、選んだ方程式と座標値を同じ体で表せる。その体が持つ性質は別の問題である。

