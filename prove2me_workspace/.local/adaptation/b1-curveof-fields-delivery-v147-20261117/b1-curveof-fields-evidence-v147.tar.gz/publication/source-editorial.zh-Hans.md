## 论文原文背景

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2 开头、“Let”之前的完整两句，印刷页与文件页均为第 41 页。精确英文引文见英文部分。该推论后续的前提与结论不在节录中。

官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页；定义 3.1(b) 跨第 61–62 页的末句；定义 3.1(c) 首句至定义 $K$ 为止，印刷页与文件页均为第 62 页。三个精确英文引文块见英文部分，(b) 中间部分及 (c) 后续部分已省略。

官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

## 适配范围

Legendre 段落提供曲线族背景。数域、选定代数闭包、模域上的扩张及挠点段落提供算术设定。在这些段落中，开参数直线的参数避开 $0,1$，选定素数也满足原文限制。这些前提不被悄然加入八个定义；各定义在出现相应参数时，接受所有代数参数及所有自然数挠点指标。

完整的域

$$F_\lambda=\mathbb Q\bigl(\lambda,i,s(\lambda),t(\lambda),C_{\lambda,3},C_{\lambda,5}\bigr),$$

其中 $i^2=-1$、$s(\lambda)^2=\lambda$、$t(\lambda)^2=1-\lambda$，是参考工程的显式构造。这里 $C_{\lambda,n}$ 收集所有被 $n$ 杀死的非奇异点的**两个仿射坐标值**，无穷远点不贡献坐标值。包括三个选定平方根的完整生成集合不称为引文中的逐字公式。该域用中间域生成运算定义，并没有证明它是曲线的最小定义数域。

平方根选择没有规定符号或相容规则。`coords` 保留无序坐标值集合。`torsionSet` 表示被 $n$ 杀死，不是阶恰为 $n$；`TorsionFinite` 是该集合有限这一命题。`torsionCoords` 是其坐标集合之并。`fieldOf'` 使用指标 3 和 5，不要求上述有限性命题的证明。这些纯定义都不证明挠点有限性、扩张次数有限、数域结构、Galois 性质或结果与平方根选择无关；这些结论需要另行证明。

## 直观解释（非严格）

这些定义把参数、选定平方根及两个指定挠点集合的坐标收集到固定代数闭包的一个子域中。添加这些值后，可以在同一个域中表达所选方程与这些坐标值。该域具有什么性质，仍是另一个问题。

