from pathlib import Path
import json,hashlib,shutil,re
from datetime import datetime,timezone
O=Path('/tmp/p2m-b1-curveof-fields-publication-v146-20261117');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');F=Path('/tmp/p2m-b1-curveof-fields-fresh-blind-v144-20261117');S=W/'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData.lean'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
frozen={str(p):sha(p) for p in F.rglob('*') if p.is_file()};bm=json.loads((F/'manifest.json').read_text())
assert sha(S)==bm['actualSHA']
assert sha(F/'readback.en.frozen.md')==bm['english_freeze']['sha256']
pc=json.loads((O/'paper-context.json').read_text());q={v['id']:v['quote_markdown'] for v in pc['quotations']};I=pc['papers']['I'];IV=pc['papers']['IV']
source_en='''## Original paper context

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

> '''+q['IV-Legendre-line']+'''

Official original: '''+IV['official_url']+'''. Local original: `'''+IV['local_pdf']+'''`. The later hypotheses and conclusions of this corollary are outside the excerpt.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

> '''+q['I-field-closure']+'''

The final sentence of Definition 3.1(b), spanning printed/PDF pages 61–62, states:

> '''+q['I-field-extension-and-six-torsion']+'''

Definition 3.1(c), first sentence through the definition of $K$, printed/PDF page 62:

> '''+q['I-torsion-extension'].replace('\n','\n> ')+'''

Official original: '''+I['official_url']+'''. Local original: `'''+I['local_pdf']+'''`. These are separate excerpts. The intervening material in (b) and the later material in (c) are omitted.

## Adaptation scope

The Legendre passage supplies the curve-family background. The number field, selected closure, field-of-moduli extension, and torsion passages supply the arithmetic setting. In those passages, the parameter avoids $0,1$ on the open parameter line, and the selected prime has the stated restrictions. These hypotheses are not silently added to the eight definitions, which accept every algebraic parameter and every natural torsion index where those arguments occur.

The full field

$$F_\\lambda=\\mathbb Q\\bigl(\\lambda,i,s(\\lambda),t(\\lambda),C_{\\lambda,3},C_{\\lambda,5}\\bigr),$$

with $i^2=-1$, $s(\\lambda)^2=\\lambda$, and $t(\\lambda)^2=1-\\lambda$, is the reference project's explicit construction. Here $C_{\\lambda,n}$ collects **both affine coordinate values** of all nonsingular points killed by $n$; the point at infinity contributes no values. The full generating set, including all three selected square roots, is not presented as a verbatim formula of the quotations. The field is defined as the intermediate-field adjoin, not as a proved minimal field of definition of the curve.

The root choices specify no signs or compatibility rules. `coords` retains an unordered set of coordinate values. `torsionSet` means killed by $n$, not exact order $n$; `TorsionFinite` is the proposition that this set is finite. `torsionCoords` is its union of coordinate sets. `fieldOf'` uses the indices 3 and 5 and requires no proof of this finiteness predicate. None of these pure definitions proves torsion finiteness, finite extension degree, a number-field structure, the Galois property, or independence from the selected roots. Such statements require separate mathematical results.

## Intuitive explanation (non-rigorous)

The definitions collect a parameter, selected square roots, and the coordinates of two specified torsion sets into one subfield of a fixed algebraic closure. Adjoining these values gives a place to express the chosen equation and those coordinate values together. The properties of that field are separate questions.
'''
source_zh='''## 论文原文背景

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2 开头、“Let”之前的完整两句，印刷页与文件页均为第 41 页。精确英文引文见英文部分。该推论后续的前提与结论不在节录中。

官方原文：'''+IV['official_url']+'''。本地原文：`'''+IV['local_pdf']+'''`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页；定义 3.1(b) 跨第 61–62 页的末句；定义 3.1(c) 首句至定义 $K$ 为止，印刷页与文件页均为第 62 页。三个精确英文引文块见英文部分，(b) 中间部分及 (c) 后续部分已省略。

官方原文：'''+I['official_url']+'''。本地原文：`'''+I['local_pdf']+'''`。

## 适配范围

Legendre 段落提供曲线族背景。数域、选定代数闭包、模域上的扩张及挠点段落提供算术设定。在这些段落中，开参数直线的参数避开 $0,1$，选定素数也满足原文限制。这些前提不被悄然加入八个定义；各定义在出现相应参数时，接受所有代数参数及所有自然数挠点指标。

完整的域

$$F_\\lambda=\\mathbb Q\\bigl(\\lambda,i,s(\\lambda),t(\\lambda),C_{\\lambda,3},C_{\\lambda,5}\\bigr),$$

其中 $i^2=-1$、$s(\\lambda)^2=\\lambda$、$t(\\lambda)^2=1-\\lambda$，是参考工程的显式构造。这里 $C_{\\lambda,n}$ 收集所有被 $n$ 杀死的非奇异点的**两个仿射坐标值**，无穷远点不贡献坐标值。包括三个选定平方根的完整生成集合不称为引文中的逐字公式。该域用中间域生成运算定义，并没有证明它是曲线的最小定义数域。

平方根选择没有规定符号或相容规则。`coords` 保留无序坐标值集合。`torsionSet` 表示被 $n$ 杀死，不是阶恰为 $n$；`TorsionFinite` 是该集合有限这一命题。`torsionCoords` 是其坐标集合之并。`fieldOf'` 使用指标 3 和 5，不要求上述有限性命题的证明。这些纯定义都不证明挠点有限性、扩张次数有限、数域结构、Galois 性质或结果与平方根选择无关；这些结论需要另行证明。

## 直观解释（非严格）

这些定义把参数、选定平方根及两个指定挠点集合的坐标收集到固定代数闭包的一个子域中。添加这些值后，可以在同一个域中表达所选方程与这些坐标值。该域具有什么性质，仍是另一个问题。
'''
source_ja='''## 論文原文の背景

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示した。系の後続の仮定と結論は引用しない。

公式原文：'''+IV['official_url']+'''。ローカル原文：`'''+IV['local_pdf']+'''`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61、定義 3.1(b) の最後の文、同 61–62、および定義 3.1(c) の最初の文から $K$ の定義まで、同 62。三つの正確な英文の引用は英語部分に示した。(b) の中間部分と (c) の後続部分は省略した。

公式原文：'''+I['official_url']+'''。ローカル原文：`'''+I['local_pdf']+'''`。

## 移植の範囲

ルジャンドルの段落は曲線族の背景を与える。数体、選ばれた代数閉包、モジュライ体上の拡大、および等分点の段落は算術的設定を与える。これらの段落では、開いたパラメータ直線上のパラメータは $0,1$ を避け、選んだ素数にも原文の制限がある。これらの仮定を八つの定義へ暗黙に加えない。対応する引数を持つ定義は、すべての代数的パラメータとすべての自然数の等分点指数を許す。

完全な体

$$F_\\lambda=\\mathbb Q\\bigl(\\lambda,i,s(\\lambda),t(\\lambda),C_{\\lambda,3},C_{\\lambda,5}\\bigr),$$

ただし $i^2=-1$、$s(\\lambda)^2=\\lambda$、$t(\\lambda)^2=1-\\lambda$、は参照プロジェクトの明示的な構成である。ここで $C_{\\lambda,n}$ は、$n$ 倍が零となるすべての非特異点の**二つのアフィン座標値**を集める。無限遠点は座標値を与えない。三つの選ばれた平方根を含む完全な生成集合を、引用中の逐語的な式とはしない。この体は中間体の生成操作で定義され、曲線の最小定義体であることが証明されるわけではない。

平方根の選択は符号や整合性の規則を指定しない。`coords` は順序のない座標値集合を保持する。`torsionSet` は $n$ 倍が零となることを意味し、位数がちょうど $n$ であることではない。`TorsionFinite` はその集合が有限であるという命題である。`torsionCoords` はその座標集合の合併である。`fieldOf'` は指数 3 と 5 を用い、その有限性命題の証明を要求しない。これらの純粋な定義は、等分点集合の有限性、有限拡大次数、数体構造、ガロア性、または平方根の選択からの独立性を証明しない。それらには別の数学的結果が必要である。

## 直観的説明（非厳密）

これらの定義は、パラメータ、選ばれた平方根、および二つの指定された等分点集合の座標を、固定した代数閉包の一つの部分体に集める。これらの値を添加すると、選んだ方程式と座標値を同じ体で表せる。その体が持つ性質は別の問題である。
'''
raw={'en':(F/'readback.en.frozen.md').read_text(),'zh-Hans':(F/'readback.zh-Hans.md').read_text(),'ja':(F/'readback.ja.md').read_text()};math={k:v[v.index('## sqrtNegOne'): ] for k,v in raw.items()}
statement='\n\n'.join('# '+label+'\n\n'+math[k].rstrip()+'\n\n'+s for k,label,s in [('en','English',source_en),('zh-Hans','简体中文',source_zh),('ja','日本語',source_ja)])+'\n'
for k,s in [('en',source_en),('zh-Hans',source_zh),('ja',source_ja)]:(O/f'source-editorial.{k}.md').write_text(s+'\n')
(O/'natural-language-statement.md').write_text(statement)
payload={'definition_name':'AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData','definition_title':'Chosen roots, torsion coordinates, and their generated field — 选定平方根、挠点坐标及其生成域 — 選ばれた平方根・等分点座標・その生成体','definition':S.read_text(),'natural_language_statement':statement,'source':'Shinichi Mochizuki, Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations, April 2020, §2, Corollary 2.2 opening, printed/PDF p. 41; Inter-universal Teichmüller Theory I: Construction of Hodge Theaters, May 2020, §3, Definition 3.1(a), p. 61, final sentence of (b), pp. 61–62, and first sentence of (c) through K, p. 62. Original background only: the complete field generated by the selected roots and 3/5-torsion coordinates is this reference project’s explicit construction, not a verbatim formula or a proof of finite degree or Galoisness in these excerpts. '+IV['official_url']+' '+I['official_url'],'env':'0df444a360eaa60ab8c11dca51a86af692955474','private':True}
(O/'payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
(O/'independent-readback').mkdir(exist_ok=True)
for p in F.iterdir():
 if p.is_file():shutil.copyfile(p,O/'independent-readback'/p.name)
shutil.copyfile(S,O/'definition-source.lean')
meta={'schema':'B1-CurveOfFieldsData-private-definition-academic-draft/v146','status':'DRAFT_NOT_POSTED_PENDING_PARENT_ACTUAL13_AUDIT','created_utc':datetime.now(timezone.utc).isoformat(),'editorial_model':'gpt-6.1-sol','editorial_not_new_independent_readback':True,'source':rec(S),'payload':rec(O/'payload.json'),'paper_context':rec(O/'paper-context.json'),'independent_readback':{'directory':str(F),'model':'gpt-6.1-sol','all_frozen_file_hashes':frozen,'mathematical_bodies_reused_verbatim':True,'only_prefaces_before_first_definition_removed_from_product_body':True,'original_files_unchanged':all(sha(Path(p))==h for p,h in frozen.items()),'Chinese_original_fieldOf_torsion_spelling':'Original frozen translation uses 扭点 in its final unit; copied unchanged. New editorial explanation uses 挠点.','translations_not_additional_independent_audits':True},'declaration_inventory':pc['scope']['eight_definitions'],'definition_scope':pc['scope'],'publication':{'env':payload['env'],'private':True,'definition_name':payload['definition_name'],'posted':False,'actual13_audit':'Pending per parent task message; this editor does not run or infer CI acceptance.'},'operations':{'CI_compiler_API_Git_executed':False,'main_workspace_written':False,'frozen_readbacks_changed':False,'publication_performed':False},'body_process_metadata_separated':True}
(O/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
assert len(payload)==7 and payload['definition']==S.read_text()
assert all(v.rstrip() in statement for v in math.values())
assert all(sha(Path(p))==h for p,h in frozen.items())
assert not re.search(r'ci-\d|gpt-|SHA.?256|\bhash\b|\bCI\b|编译|コンパイル',statement,re.I)
validation={'payload_seven_keys':list(payload),'requested_name_env_private':True,'canonical_definition_byte_identical':True,'eight_pure_definitions_present':all('## '+x in statement for x in pc['scope']['eight_definitions']),'frozen_math_text_unmodified':True,'frozen_all_files_hashes_unchanged':True,'paper_interface_distinction_explicit':True,'no_finiteness_NumberField_Galois_proof_claimed':True,'process_information_only_metadata':True,'not_posted':True}
(O/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'payload_sha256':sha(O/'payload.json'),'source_sha256':sha(S),'directory':str(O)},ensure_ascii=False,indent=2))
