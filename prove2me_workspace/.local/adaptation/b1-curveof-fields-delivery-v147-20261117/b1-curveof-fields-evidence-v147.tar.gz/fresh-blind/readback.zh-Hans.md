# 简体中文译文

译自冻结的独立英文读回 `readback.en.frozen.md`，其摘要为 `977b9e1d7daa5d2137cc38f761a9f6802f8e6816faab7f477cdfc16ce7507673`。本译文不是另一份独立审计结论。

## sqrtNegOne

设 $\overline{\mathbb Q}$ 为代码使用的有理数域的代数闭包。该声明从平方等于 $-1$ 的元素存在性命题中选取一个见证，定义单个元素 $i\in\overline{\mathbb Q}$，因而 $i^2=-1$。这是不带输入参数的非可计算选择，没有指定选取哪一个符号，也没有断言平方根唯一。

## sqrtLam

对代码所用的有理数域的代数闭包 $\overline{\mathbb Q}$ 中的每个 $\lambda$，该声明通过选取 $s(\lambda)^2=\lambda$ 的一个见证，定义元素 $s(\lambda)\in\overline{\mathbb Q}$。这是以 $\lambda$ 为参数的非可计算函数，不要求 $\lambda$ 非零，也没有其他限制。特别地，允许 $\lambda=0$，此时平方根必为 $0$。该声明没有指定符号规则或所选各平方根之间的额外相容关系，也没有断言一般 $\lambda$ 的平方根唯一。

## sqrtOneSubLam

对代码所用的有理数域的代数闭包 $\overline{\mathbb Q}$ 中的每个 $\lambda$，该声明通过选取 $t(\lambda)^2=1-\lambda$ 的一个见证，定义元素 $t(\lambda)\in\overline{\mathbb Q}$。这是以 $\lambda$ 为参数的非可计算函数，不排除 $\lambda=0$ 或 $\lambda=1$。在 $\lambda=1$ 时，所选平方根必为 $0$。该声明没有指定符号规则或与其他平方根选择的额外相容关系，也没有断言一般 $\lambda$ 的平方根唯一。

## coords

对每个隐式参数 $\lambda\in\overline{\mathbb Q}$，该声明定义一个从 Weierstrass 曲线 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 的点类型到 $\overline{\mathbb Q}$ 的子集的函数，其中 $\overline{\mathbb Q}$ 为有理数域的代数闭包。该点类型由无穷远点 $O$ 和此方程上的非奇异仿射点 $(x,y)$ 组成；这里非奇异是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。函数把无穷远点 $O$ 映为空集；$O$ 也是记为 $0$ 的群单位元。函数把每个这样的仿射点 $(x,y)$ 映为无序集合 $\{x,y\}$。这是坐标值的集合，不是有序对；若 $x=y$，则为单元素集合。参数可以等于 $0$ 或 $1$；即使在这些参数下，输入点类型仍然只含非奇异仿射点与 $O$。

## torsionSet

对每个 $\lambda\in\overline{\mathbb Q}$ 和每个自然数 $n\ge0$，该声明定义 $G_\lambda$ 的子集 $T_{\lambda,n}=\{P\in G_\lambda:nP=O\}$。这里 $\overline{\mathbb Q}$ 为有理数域的代数闭包；$G_\lambda$ 是由无穷远点 $O$ 和方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上的非奇异仿射点组成的交换群，采用导入的 Weierstrass 点加法；仿射点的非奇异性是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。式中 $nP$ 表示反复施行群加法，$O$ 为单位元。属于该集合的条件是 $P$ 的 $n$ 倍为单位元，而不是 $P$ 的阶恰为 $n$。定义不排除 $\lambda=0,1$，也不要求 $n\ne0$：$T_{\lambda,0}$ 是整个 $G_\lambda$，$T_{\lambda,1}=\{O\}$，并且每个 $n$ 的情形都包含 $O$。该定义没有断言这些集合有限。

## TorsionFinite

对每个 $\lambda\in\overline{\mathbb Q}$ 和每个自然数 $n\ge0$，该声明定义一个命题：集合 $\{P\in G_\lambda:nP=O\}$ 有限。这里 $\overline{\mathbb Q}$ 为有理数域的代数闭包；$G_\lambda$ 是由无穷远点 $O$ 和方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上的非奇异仿射点组成的交换群，采用导入的 Weierstrass 加法；仿射点的非奇异性是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。允许参数 $\lambda$ 为 $0$ 或 $1$，$nP$ 表示反复施行群加法，$O$ 为单位元。该声明定义有限性条件，没有证明此条件成立。它不带 $n\ne0$ 的假设；当 $n=0$ 时，此条件表示整个群 $G_\lambda$ 有限。当 $n=1$ 时，条件中的集合为 $\{O\}$。

## torsionCoords

对每个 $\lambda\in\overline{\mathbb Q}$ 和每个自然数 $n\ge0$，该声明定义 $\overline{\mathbb Q}$ 的子集 $C_{\lambda,n}$，即所有满足 $nP=O$ 的点 $P\in G_\lambda$ 的坐标集合之并。这里 $\overline{\mathbb Q}$ 为有理数域的代数闭包；$G_\lambda$ 是由无穷远点 $O$ 和方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上的非奇异仿射点组成的交换群，采用导入的 Weierstrass 加法；非奇异性是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。$O$ 的坐标集合为空集，仿射点 $(x,y)$ 的坐标集合为 $\{x,y\}$。等价地，$a\in C_{\lambda,n}$ 当且仅当存在一个 $n$ 倍为单位元的非奇异仿射点 $(x,y)$，使得 $a=x$ 或 $a=y$。因此，该集合保留坐标值，不保留顺序、重数或坐标配成点的方式。定义没有排除 $\lambda=0,1$ 或 $n=0$。当 $n=0$ 时，它收集所有非奇异仿射点的坐标；当 $n=1$ 时，它为空集。该定义没有假设任何有限性条件，也没有证明有限性。

## fieldOf'

对每个 $\lambda\in\overline{\mathbb Q}$，该声明定义有理数域 $\mathbb Q$ 与其代数闭包 $\overline{\mathbb Q}$ 之间的中间域 $F_\lambda$：它是 $\overline{\mathbb Q}$ 中包含 $\mathbb Q$ 的像、$\lambda$、此前所选满足 $i^2=-1$ 的元素 $i$、此前所选满足 $s(\lambda)^2=\lambda$ 及 $t(\lambda)^2=1-\lambda$ 的元素 $s(\lambda),t(\lambda)$，以及 $G_\lambda$ 中每个 $3$ 倍为单位元或 $5$ 倍为单位元的点的所有坐标值的最小子域。这里 $G_\lambda$ 采用导入的 Weierstrass 点加法，以 $O$ 为单位元，是由 $O$ 和方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 上的非奇异仿射点组成的交换群；非奇异性是指 $3x^2-2(1+\lambda)x+\lambda\ne0$ 或 $2y\ne0$。仿射点以集合的形式提供两个坐标值 $x,y$，而 $O$ 不提供任何坐标值。扭点条件是 $3P=O$ 和 $5P=O$，不是阶恰为 $3$ 或 $5$；生成集合由这两个坐标集合与 $\{\lambda,i,s(\lambda),t(\lambda)\}$ 的并组成。这是使用上述平方根选择的非可计算构造；它没有断言这些选择唯一，也没有断言结果与这些选择无关。它接受 $\lambda=0,1$，也接受 $\overline{\mathbb Q}$ 中的所有其他元素。该声明不带扭点有限性、扩张次数有限、数域或 Galois 性质的假设，本身也没有给出关于扭点有限性、扩张次数有限、数域结构或 Galois 性质的定理。
