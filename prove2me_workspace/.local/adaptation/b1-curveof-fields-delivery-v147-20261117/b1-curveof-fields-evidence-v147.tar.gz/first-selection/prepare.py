import pathlib,json,hashlib,collections
W=pathlib.Path('/home/admin-wsl/Coq/abc/prove2me_workspace');D=pathlib.Path('/tmp/p2m-b1-curveof-fields-first-v138-20261117')
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def nm(n):return '' if n==[] else (nm(n[0])+'.' if n[0] else '')+str(n[2])
def name(s):
 n=[]
 for t in s.split('.'):n=[n,'str',t]
 return n
def dump(n,x):(D/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
P=W/'.local/adaptation/b1-source-parser-v93-20261117/parser-output/Iut-Tripod-CurveOf.jsonl';S=P.with_suffix('.normalized.lean');B=S.read_bytes();ast={}
for l in P.open():
 x=json.loads(l)
 if x.get('commandSyntax'):ast[x['commandIndex']]=x
M=W/'.local/adaptation/b1-source-replay-v104-20261117/compat-v105/source-replay-spans-map.json';maps=json.loads(M.read_text());am={x['originalCommandIndex']:x for x in maps['commands'] if x['sourceModule']=='Iut.Tripod.CurveOf'};A=W/'.local/adaptation/b1-source-replay-v104-20261117/source-project/B1SourceReplay.lean';AB=A.read_bytes();commands=[]
def nodes(x):
 yield x
 for c in x.get('children',[]):yield from nodes(c)
def emit(i):
 c=ast[i];r=c['range'];a,z=r['start']['offset'],r['end']['offset'];raw=B[a:z];out=raw;edit=[]
 if i==1:
  q=next(n for n in nodes(c['commandSyntax']) if n.get('identifier')=='Iut.Tripod');rr=q['range'];s,e=rr['start']['offset']-a,rr['end']['offset']-a;out=raw[:s]+b'AbcAdaptation.Tripod'+raw[e:];edit=[{'start':s,'end':e,'source':'Iut.Tripod','target':'AbcAdaptation.Tripod'}]
 ac=am[i];er=ac['effectiveReplayRange'];assert hashlib.sha256(raw).hexdigest()==ac['originalSHA256'];assert hashlib.sha256(AB[er['start']['offset']:er['end']['offset']]).hexdigest()==ac['effectiveSHA256'];commands.append({'index':i,'originalRange':r,'originalSHA256':hashlib.sha256(raw).hexdigest(),'targetSHA256':hashlib.sha256(out).hexdigest(),'namespaceRelocation':edit,'acceptedReplayHashMatches':True});return out.decode()
head='''/-
Adaptation provenance: accepted source AST command selection, original declaration bytes unchanged.
Original repository: https://github.com/lana-agents/iut
Original commit: 07cb1da58f6d428a670dbb5dd6093d428bcbcdd8
Original source: Iut/Tripod/CurveOf.lean
-/
/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Definitions.Def_AbcTripod
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_LegendreModel
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Point
import Mathlib.FieldTheory.IntermediateField.Adjoin.Basic
import Mathlib.FieldTheory.IsAlgClosed.AlgebraicClosure

'''
indices=[1,2,3,5,7,9,12,15,16,18,22];code=head+'\n\n'.join(emit(i) for i in indices)+'\n\nend AbcAdaptation.Tripod\n';O=D/'Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData.lean';O.write_text(code)
F=A.parent.parent/'actual/closure-v111/actual-facts.jsonl';facts={}
for l in F.open():
 x=json.loads(l)
 if 'name'in x:facts[x['name']]=x
E=F.with_name('actual-edges.jsonl');edges=[json.loads(l) for l in E.open()];by=collections.defaultdict(list)
for e in edges:by[nm(e['from'])].append(e)
roots=['Iut.Tripod.'+x for x in ['sqrtNegOne','sqrtLam','sqrtOneSubLam','coords','torsionSet','TorsionFinite','torsionCoords',"fieldOf'"]];q=collections.deque(roots);own=set();boundary=set();kept=[]
while q:
 n=q.popleft()
 if n in own or n in boundary:continue
 f=facts.get(n)
 if not f or f.get('owner')!='B1SourceReplay':boundary.add(n);continue
 own.add(n)
 for e in by[n]:
  kept.append(e);q.append(nm(e['to']))
project=[n for n in sorted(boundary) if n.startswith(('Iut.','Genl.','TateCurvesTheta.'))];assert project==['Iut.Tripod.Qbar','Iut.Tripod.legendre'],project
with (D/'source-first-leaf-full-actual-facts.jsonl').open('w') as f:
 for n in sorted(own|set(project)):f.write(json.dumps(facts[n],ensure_ascii=False,separators=(',',':'))+'\n')
dump('actual-dependency-slice.json',{'schema':'B1-CurveOfFieldsData-first-leaf/v138','roots':roots,'sourceOwnedFullFacts':sorted(own),'sourceOwnedFullFactCount':len(own),'projectBoundaries':project,'edges':kept,'unmappedProjectBoundaryNames':[],'QbarAcceptedVia':'Basic55 ci-018396-b29fa0e0','legendreAcceptedVia':'canonical7 full actual review ci-018653-3a41ee43 covers model row; native model leaf ci-018627 and artifact ci-018640 (root reports)','platformPublicationReceiptForModelObserved':False,'fullCurveOfPackageClaimed':False})
modelRecord=None
for l in (W/'.local/adaptation/b1-legendre-platform-v133-20261117/actual/canonical/actual-facts.jsonl').open():
 x=json.loads(l)
 if x.get('name')=='AbcAdaptation.Tripod.legendre':modelRecord=x
assert modelRecord and modelRecord['owner']=='Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_LegendreModel'
base=json.loads(pathlib.Path('/tmp/p2m-b1-curveof-draft-v118-20261117/basic55-reuse-actualNamedMap.json').read_text());qb=next(x for x in base['namedPairs'] if x['sourceName']=='Iut.Tripod.Qbar')
dump('actual-project-boundary-map.json',{'schema':'B1-CurveOfFieldsData-boundaries/v138','namedPairs':[{'source':qb['sourceName'],'sourceNameExpr':qb['sourceNameExpr'],'target':qb['targetName'],'targetNameExpr':qb['targetNameExpr'],'targetOwner':qb['targetOwner'],'acceptedReviewJob':qb['acceptedReviewJob']},{'source':'Iut.Tripod.legendre','sourceNameExpr':facts['Iut.Tripod.legendre']['nameExpr'],'target':modelRecord['name'],'targetNameExpr':modelRecord['nameExpr'],'targetOwner':modelRecord['owner'],'acceptedReviewJob':'ci-018653-3a41ee43','nativeInventoryJob':'ci-018648-52cbf7b2'}],'publicationStateNotInferredFromName':True})
dump('source-command-map.json',{'schema':'B1-CurveOfFieldsData-AST-selection/v138','commands':commands,'publicMathematicalDefinitionCount':8,'sourceProofDeclarationCountInThisLeaf':0,'noFieldOfCarrierReplacement':True})
dump('pins.json',{'schema':'B1-CurveOfFieldsData-pins/v138','inputs':[pin(p) for p in [P,S,M,A,F,E,W/'Definitions/Def_AbcTripod.lean',W/'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_LegendreModel.lean']],'output':pin(O)})
print({'code':str(O),'bytes':len(code.encode()),'sourceOwnFullFacts':len(own),'projectBoundaries':project,'dataDefinitions':8,'sourceProofDeclarations':0})
