import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfFieldsData

namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare
namespace CurveOfFieldsThirteenReview
open Lean Elab Term Meta FoundationAudit BasicNativeCompare

def readRows (path : String) : MetaM (Array Json) := do
  unless path.startsWith "/" do throwError "Facts path must be absolute"
  let lines := (← IO.FS.readFile path).splitOn "\n"
  let mut rows := #[]
  for line in lines do
    unless line.isEmpty do rows := rows.push (← checked (Json.parse line))
  return rows

def findActual (rows : Array Json) (n : Name) : MetaM Json := do
  let matchingRows := rows.filter fun r => (field r "nameExpr").toOption == some (encodeName n)
  unless matchingRows.size == 1 do throwError "Expected one pinned actual record {n}"
  return matchingRows[0]!

def defeq (label : String) (a b : Expr) : MetaM Unit := do
  match Kernel.isDefEq (← getEnv) {} a b with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inequality {label}"
  | .error ex => throwKernelException ex

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33.1"
  let cfg ← jsonFile (← absoluteEnv "B1_CURVEOF_FIELDS_REVIEW_CONFIG")
  unless (← checked (cfg.getObjValAs? String "schema")) == "B1-CurveOfFields-thirteen-review-bound/v144" do
    throwError "Use bound native actual inventory configuration"
  let src ← readRows (← checked (cfg.getObjValAs? String "sourceFacts"))
  let native ← readRows (← checked (cfg.getObjValAs? String "nativeFacts"))
  let pairs ← checked (arrayField cfg "pairs")
  unless src.size == 13 && pairs.size == 13 do throwError "Expected thirteen complete source facts and pairs"
  let mut maps : NameMap := #[]
  for pair in pairs do
    let a ← checked (decodeName (← checked (field pair "sourceNameExpr")))
    let b ← checked (decodeName (← checked (field pair "targetNameExpr")))
    let expectedOwner ← checked (decodeName (← checked (field pair "targetOwnerNameExpr")))
    unless moduleOf (← getEnv) b == some expectedOwner do throwError "Actual target owner differs {b}"
    let user ← checked (decodeName (← checked (field pair "targetUserNameExpr")))
    let privateExpected ← checked (pair.getObjValAs? Bool "targetPrivate")
    if privateExpected then
      unless Lean.privateToUserName? b == some user do throwError "Actual private user name differs {b}"
    else
      unless b == user && !Lean.isPrivateName b do throwError "Expected exact public name {b}"
    unless (maps.find? (·.1 == a)).isNone do throwError "Duplicate source map {a}"
    maps := maps.push (a,b)
  let boundaries ← checked (arrayField cfg "acceptedBoundaryPairs")
  unless boundaries.size == 2 do throwError "Expected exact Qbar and LegendreModel boundaries"
  for boundary in boundaries do
    let sourceBoundary ← checked (decodeName (← checked (field boundary "sourceNameExpr")))
    let targetBoundary ← checked (decodeName (← checked (field boundary "targetNameExpr")))
    let targetOwner ← checked (decodeName (← checked (field boundary "targetOwnerNameExpr")))
    unless moduleOf (← getEnv) targetBoundary == some targetOwner do throwError "Boundary owner differs {targetBoundary}"
    unless (maps.find? (·.1 == sourceBoundary)).isNone do throwError "Boundary duplicates producer map"
    maps := maps.push (sourceBoundary,targetBoundary)
  let mut reports : Array Json := #[]
  for pair in pairs do
    let a ← checked (decodeName (← checked (field pair "sourceNameExpr")))
    let b ← checked (decodeName (← checked (field pair "targetNameExpr")))
    let source ← findActual src a
    let pinned ← findActual native b
    let ci ← getConstInfo b
    let expectedUser ← checked (decodeName (← checked (field pair "targetUserNameExpr")))
    unless Lean.privateToUserName b == expectedUser do throwError "Compiler-owned user name differs {b}"
    let sourceMetadata ← checked (field source "metadata")
    let targetMetadata ← checked (field pinned "metadata")
    unless sourceMetadata == targetMetadata do throwError "Definition/proof computation metadata differs {a}"
    unless (← checked (field sourceMetadata "structure")) == Json.null &&
      (← checked (arrayField sourceMetadata "recursorRules")).isEmpty do
        throwError "Unexpected source structure/recursor; extend this finite reviewer instead of dropping metadata"
    unless (← checked (field sourceMetadata "computationShape")) ==
      (← checked (computationShape ci pure)) do throwError "Current native computation shape differs {b}"
    unless (getStructureInfo? (← getEnv) b).isNone do throwError "Unexpected native structure {b}"
    unless (← checked (source.getObjValAs? String "record")) == "fullActualFact" do
      throwError "Source record is not complete {a}"
    unless (← checked (source.getObjValAs? Bool "valueRead")) &&
      (← checked (source.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
      throwError "Source lacks accepted complete kernel-checked value {a}"
    for record in #[source,pinned] do
      if ← checked (record.getObjValAs? Bool "hasSorryAx") then throwError "sorryAx in actual record {b}"
      for key in #["axioms","typeAxioms","valueAxioms"] do
        let axs ← checked (record.getObjValAs? (Array String) key)
        for ax in axs do
          unless #["propext","Classical.choice","Quot.sound"].contains ax do throwError "Nonstandard source/native axiom {ax}"
    unless (← checked (source.getObjValAs? String "kind")) == kind ci do throwError "Constant kind differs {a}"
    let sourceLevels ← namesFromJson (← checked (field source "levelParams"))
    unless sourceLevels.length == ci.levelParams.length do throwError "Universe arity differs {a}"
    let targetLevels := ci.levelParams.map Level.param
    let stRaw ← checked (relocateExpr maps #[] #[] false (← checked (field source "actualTypeExpr")))
    let svRaw ← checked (relocateExpr maps #[] #[] false (← checked (field source "actualValueExpr")))
    let st := stRaw.instantiateLevelParams sourceLevels targetLevels
    let sv := svRaw.instantiateLevelParams sourceLevels targetLevels
    let some tv := ci.value? (allowOpaque := true) | throwError "Missing native actual value {b}"
    unless (← checked (encodeExpr ci.type)) == (← checked (field pinned "actualTypeExpr")) do
      throwError "Current native TYPE differs from pinned inventory {b}"
    unless (← checked (encodeExpr tv)) == (← checked (field pinned "actualValueExpr")) do
      throwError "Current native value differs from pinned inventory {b}"
    unless binderInventory st == binderInventory ci.type &&
      binderPlacement st == binderPlacement ci.type do throwError "Source/native TYPE BinderInfo differs {a}"
    let _ ← kernelCheck s!"relocated actual source TYPE {a}" st
    defeq s!"actual TYPE {a}" st ci.type
    let svType ← kernelCheck s!"complete relocated source value {a}" sv
    defeq s!"source proof/value TYPE {a}" svType st
    let tvType ← kernelCheck s!"complete native value {b}" tv
    defeq s!"native value TYPE {b}" tvType ci.type
    let prop ← isProp ci.type
    unless prop == (← checked (source.getObjValAs? Bool "isProposition")) do throwError "Prop/data differs {a}"
    defeq s!"actual value {a}" sv tv
    let axs ← collectAxioms b
    ensureStandard b.toString axs
    ensureStandard s!"relocated source actual value {a}" (← expressionAxioms sv)
    let expectedInstance ← checked (source.getObjValAs? Bool "isInstance")
    unless Lean.Meta.isInstanceCore (← getEnv) b == expectedInstance do throwError "Instance attribute differs {a}"
    reports := reports.push (Json.mkObj [
      ("source",encodeName a),("target",encodeName b),
      ("actualTYPEKernelEqual",toJson true),("TYPEBinderInfoPlacementEqual",toJson true),
      ("fullSourceProofOrDataValueRead",toJson true),
      ("relocatedActualSourceValueKernelChecked",toJson true),
      ("nativeActualValueKernelChecked",toJson true),
      ("actualValueKernelEqual",toJson true),
      ("completeSourceMetadataCompared",toJson true),
      ("sourceAndTargetHaveNoStructureOrRecursorRules",toJson true),
      ("actualValueStructurallyEqual",toJson (sv == tv)),
      ("isProposition",toJson prop),("standardAxiomsOnly",toJson true),
      ("sourceNativeProofTermIdentityClaimed",toJson false)])
  let output ← checked (cfg.getObjValAs? String "outputFile")
  unless output.startsWith "/" do throwError "Output file must be absolute"
  if let some parent := (System.FilePath.mk output).parent then IO.FS.createDirAll parent
  IO.FS.writeFile output ((Json.mkObj [
    ("schema",toJson "B1-CurveOfFields-thirteen-correspondence/v144"),
    ("configuration",cfg),("reports",Json.arr reports),
    ("actualSourceFactsCompared",toJson reports.size),
    ("allRequiredCorrespondenceChecksPassed",toJson true),
    ("newMathematicalAssumptionsIntroduced",toJson false)]).pretty ++ "\n")
  logInfo "Thirteen CurveOfFieldsData actual TYPE/full values and computation metadata correspond"
end CurveOfFieldsThirteenReview
