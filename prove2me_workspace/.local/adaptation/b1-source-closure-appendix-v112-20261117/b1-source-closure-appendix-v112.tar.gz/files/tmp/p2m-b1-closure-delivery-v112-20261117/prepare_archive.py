#!/usr/bin/env python3
"""Independent B1 closure appendix; task /tmp writes only; no CI/compiler/API/Git."""
import argparse,copy,hashlib,io,json,tarfile
from collections import Counter
from pathlib import Path
T=Path('/tmp/p2m-b1-closure-delivery-v112-20261117');R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation';D=A/'b1-source-replay-v104-20261117';C=A/'main-chain-open-20261116'
S={'propext','Classical.choice','Quot.sound'}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def name(n):return '' if not n else name(n[0])+('.' if n[0] else '')+str(n[2])
def resource(d):
 r=d.get('resources') or d.get('result',{}).get('resources') or {};t,u,s=[r.get(k) for k in ['cpu_time_seconds','cpu_user_seconds','cpu_system_seconds']]
 return {**r,'cpu_total_equals_user_plus_system':None if None in (t,u,s) else abs(t-u-s)<.02,'peak_rss_GiB':r.get('peak_rss_bytes')/1024**3 if r.get('peak_rss_bytes') is not None else None,'peak_pss_GiB':r.get('peak_pss_bytes')/1024**3 if r.get('peak_pss_bytes') is not None else None,'resource_source':r.get('resource_source',r.get('source')),'resource_degraded':r.get('degraded'),'memory_basis':'process-tree physical RSS/PSS; bytes; missing fields remain unknown'}
def accept(d,review=False):
 q,r=d['request'],d['result'];assert d['status']=='succeeded' and r['exit_code']==0
 assert Path(q['workspace'])==W and q['exclusive'] is True
 assert r['snapshot']['workspace_mode']=='exclusive_worktree' and r['snapshot']['snapshot_id'] is None
 assert resource(d)['peak_rss_bytes']<=16*1024**3 and resource(d)['cpu_total_equals_user_plus_system'] is True
 if review:
  v=r['review'];assert v['passed'] is True and v['checks']['no_sorryAx'] is True and v['checks']['assumptions_reported'] is True and not v['violations']

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,default=T/'dryrun');ap.add_argument('--evidence-directory',type=Path,default=A/'b1-source-closure-appendix-v112-20261117');ap.add_argument('--registry',type=Path,default=A/'platform-node-registry.json');ap.add_argument('--prior-root-directory',type=Path,default=A/'b1-source-delivery-v110-20261117');ap.add_argument('--receipt',type=Path,default=C/'b1-source-actual-closure-v112-result.json');ap.add_argument('--closure-directory',type=Path,default=D/'actual/closure-v111');ap.add_argument('--archive',action='store_true');x=ap.parse_args();out=x.output.resolve();assert T in out.parents;out.mkdir(parents=True,exist_ok=True)
 success=read(x.receipt);q=success['request'];query=W/q['parameters']['source'];config=Path(q['environment']['B1_SOURCE_CLOSURE_FACTS_CONFIG']);cfg=read(config);binding_path=Path(cfg['successfulRootBindingFile']);binding=read(binding_path);summary=read(x.closure_directory/'summary.json');prior=read(x.prior_root_directory/'archive-manifest.json');ledger0=read(x.prior_root_directory/'SOURCE_LEDGER.json');rootfacts=Path(binding['completeRootFacts']['path']);source=Path(binding['effectiveSource']['path']);artifact=Path(binding['actualSourceArtifact']['path']);rootreceipt=Path(binding['successfulReceipt']['path']);gates={};errors={};files={};pins=[]
 def add(p):
  p=Path(p).absolute();assert p.is_file();files[str(p)]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'member':'files/'+str(p).lstrip('/')}
 def gate(k,f):
  try:f();gates[k]=True
  except (AssertionError,OSError,KeyError,TypeError,ValueError) as e:gates[k]=False;errors[k]=str(e)
 def prior_binding():
  assert prior['sourceOnlyComplete'] is True and prior['allMembersReopenedSHA256Verified'] is True
  assert sha(prior['archive'])==prior['archiveSHA256']
  assert prior['fullCarrierClosureExported'] is False
  for key in ['successfulReceipt','completeRootFacts','actualSourceArtifact','effectiveSource']:
   pin=binding[key];assert sha(pin['path'])==pin['sha256'];pins.append({**pin,'copied':False,'reason':'existing accepted root/source/artifact pin; root proof not re-exported'})
  assert binding['schema']=='B1-successful-source-root-fact-binding/v111'
  assert binding['successfulRootQueryJob']=='ci-018542-4dae4da4'
  assert binding['priorKernelProofTypeMatchesActualTYPE'] is True and binding['priorStandardAxiomAuditPassed'] is True and binding['priorHasSorryAx'] is False
  assert set(binding['priorAxioms'])==S and binding['rootLevelParams']==[]
  rf=read(rootfacts);assert rf['root']['kernelInferredTypeStructurallyEqual'] is False and rf['root']['kernelProofTypeMatchesActualTYPE'] is True
  assert binding['actualTypeExpr']==rf['root']['actualTypeExpr']
  for k in ['directTypeConstants','directValueConstants']:assert binding[k]==rf['root'][k]
  root=read(rootreceipt);accept(root,True);assert root['job_id']==binding['successfulRootQueryJob']
  for n,jid in [('b1-source-replay-leaf-v106-result.json','ci-018534-6a278498'),('b1-source-replay-artifact-v107-result.json','ci-018538-2c5490b3')]:
   p=C/n;d=read(p);accept(d);assert d['job_id']==jid;assert d['request']['worktree_manifest']['input_hashes'][str(source)]==binding['effectiveSource']['sha256'];add(p)
  members={r['path']:r for r in prior['files']}
  assert members[str(rootfacts)]['sha256']==binding['completeRootFacts']['sha256']
  assert ledger0['actualFacts']['sha256']==binding['completeRootFacts']['sha256']
  add(rootreceipt)
 gate('previous_root_archive_actual_proof_receipt_and_artifact_pins',prior_binding)
 def success_inputs():
  accept(success);assert success['job_id']=='ci-018560-1db29f6e'
  assert q['task_type']=='leaf' and q['target']=='file'
  assert success['result']['actual_arguments']==['lean',q['parameters']['source']]
  hashes=q['worktree_manifest']['input_hashes']
  for p in [query,config,binding_path,rootfacts,source,artifact,rootreceipt]:assert hashes[str(p)]==sha(p),'success input changed: '+str(p)
  assert sha(binding_path)=='f9369ca582b58939985bb2d07bcf3f1f9edf301ee9711ad110a2d992ba82520b'
  assert cfg==summary['configuration']
  assert cfg['successfulRootFactsSHA256']==binding['completeRootFacts']['sha256']
  assert cfg['sourceArtifactSHA256']==binding['actualSourceArtifact']['sha256']
  assert cfg['effectiveSourceSHA256']==binding['effectiveSource']['sha256']
  assert not any('maxHeartbeats' in line for line in query.read_text().splitlines() if line.strip().startswith('set_option'))
 gate('successful_optimized_query_configuration_and_root_binding',success_inputs)
 counts=Counter();names=set();edges=0
 def actual_closure():
  nonlocal edges
  assert summary['schema']=='B1-source-actual-closure/v106' and summary['compilerVersion']=='4.35.0-rc3'
  assert summary['traversalCompleteUnderDeclaredBoundaryPolicy'] is True and summary['nativeTargetComparisonAccepted'] is False
  assert summary['priorVerifiedRootReferenceUsed'] is True and summary['allMathlibProofBodiesExported'] is False
  reference=read(x.closure_directory/'root-first-reference.json');assert reference['successfulRootBinding']==binding
  assert reference['rootProofReexported'] is False and reference['rootProofKernelAuditReused'] is True and reference['currentActualTYPEAndDirectDependenciesMatch'] is True and reference['completeRootFactsMustBeReadByConsumers'] is True
  with (x.closure_directory/'actual-facts.jsonl').open() as f:
   for line in f:
    r=json.loads(line);kind=r['record'];counts[kind]+=1;n=name(r['nameExpr']);assert n not in names;names.add(n)
    if kind=='priorKernelVerifiedRootReference':
     assert r==reference and name(r['ownerNameExpr'])=='B1SourceReplay';counts['sourceOwned']+=1
    elif kind=='fullActualFact':
     assert r['hasSorryAx'] is False and set(r['axioms'])<=S
     for k in ['typeAxioms','valueAxioms']:assert set(r[k])<=S
     if r['owner']=='B1SourceReplay':counts['sourceOwned']+=1
     if r['traversalMode']=='cached-project-closed-zero-universe-Prop-support':
      assert r['closedZeroUniversePropSupport'] is True;counts['closedProp']+=1
     if r['valueRead']:assert r['actualValueExpr'] is not None and r['kernelValueTypeMatchesActualTYPE'] is True
    else:assert 'boundary' in kind.lower()
  with (x.closure_directory/'actual-edges.jsonl').open() as f:
   for line in f:
    e=json.loads(line);assert name(e['from']) in names and name(e['to']) in names;edges+=1
  assert len(names)==summary['uniqueActualConstants']==1444
  assert counts['fullActualFact']+counts['priorKernelVerifiedRootReference']==summary['fullFactCount']==249
  assert len(names)-249==summary['explicitBoundaryCount']==1195
  assert counts['sourceOwned']==summary['sourceOwnedFullFactCount']==215
  assert counts['closedProp']==summary['closedPropSupportCount']==6
  assert edges==summary['actualEdgeCount']==14718
 gate('actual_BFS_complete_under_declared_boundary_policy_counts_and_edges',actual_closure)
 failures=[]
 def failed_inputs():
  for ver,jid,diagnostic,folder in [('v110','ci-018549-cdc80819','heartbeats','source-facts-v106'),('v111','ci-018555-a4072de9',"expected 'then'",'source-facts-v111')]:
   p=C/('b1-source-actual-closure-'+ver+'-result.json');d=read(p);assert d['job_id']==jid and d['status']=='failed';assert diagnostic in json.dumps(d['result'])
   old=Path('/tmp/p2m-b1-source-replay-v100-20261117')/folder
   for filename,original in [('QueryB1SourceActualClosure.lean',query),('closure-source-facts.config.json',config)]:
    pin=old/filename
    if ver=='v111' and filename=='QueryB1SourceActualClosure.lean':pin=T/'history-v111'/filename;add(T/'history-v111/reconstruction-provenance.json')
    assert sha(pin)==d['request']['worktree_manifest']['input_hashes'][str(original)];add(pin)
   add(p);failures.append((p,d))
 gate('v110_heartbeat_and_v111_if_do_failures_exact_inputs',failed_inputs)
 complete=all(gates.values());state={'schema':'B1-source-closure-appendix-gates/v112','completeUnderDeclaredBoundaryPolicy':complete,'gates':gates,'errors':errors,'nativeTargetComparisonAccepted':False,'platformPublished':False,'rootProofReexported':False,'rootProofKernelAuditReused':True,'allMathlibProofBodiesExported':False,'Height603FirstClassOpen':True,'mainWorkspaceWritten':False,'CICompilerAPIGitExecuted':False};write(out/'completion-gates.json',state)
 for p in [x.receipt,query,config,binding_path,T/'README.md',T/'citation-context.json',Path('/tmp/p2m-b1-GenEll-page15.png'),Path(__file__)]:add(p)
 citation=read(T/'citation-context.json');assert sha(citation['pdf']['path'])==citation['pdf']['sha256'] and sha(citation['image']['path'])==citation['image']['sha256'];write(out/'citation-context.json',citation)
 for n in ['summary.json','root-first-reference.json','actual-facts.jsonl','actual-edges.jsonl']:add(x.closure_directory/n)
 # Prior root archive is an external immutable reference, never copied into this appendix.
 write(out/'prior-root-archive-pin.json',{'archive':prior['archive'],'archiveSHA256':prior['archiveSHA256'],'archiveBytes':prior['archiveBytes'],'priorRootDeliveryPath':str(x.prior_root_directory),'actualRootFacts':binding['completeRootFacts'],'actualRootFactsMember':'files/'+str(rootfacts).lstrip('/'),'rootProofReexported':False,'rootProofKernelAuditReused':True})
 write(out/'prebuilt-and-previous-input-pins.json',pins)
 ci=[]
 for p,d in [(x.receipt,success)]+failures+[(rootreceipt,read(rootreceipt))]:
  qq,rr=d['request'],d['result'];ci.append({'jobId':d['job_id'],'status':d['status'],'rawReceipt':str(p),'sha256':sha(p),'exitCode':rr.get('exit_code'),'resources':resource(d),'actualArguments':rr.get('actual_arguments'),'diagnostics':rr.get('diagnostics'),'workspaceMode':rr.get('snapshot',{}).get('workspace_mode'),'snapshotId':rr.get('snapshot',{}).get('snapshot_id'),'inputManifestPointer':str(p)+'#/request/worktree_manifest'})
 write(out/'ci-history.json',ci)
 pointers=[{'path':str(x.closure_directory/n),'sha256':sha(x.closure_directory/n),'bytes':(x.closure_directory/n).stat().st_size,'archiveMember':'files/'+str(x.closure_directory/n).lstrip('/')} for n in ['actual-facts.jsonl','actual-edges.jsonl','root-first-reference.json']];write(out/'large-evidence-pointers.json',pointers)
 ledger={'schema':'B1-source-closure-compact-ledger/v112','sourceFactsOnly':True,'closureSuccess':complete,'traversalCompleteUnderDeclaredBoundaryPolicy':complete,'policy':cfg['policy'],'uniqueActualConstants':1444,'fullFactCountIncludingPriorRootReference':249,'explicitBoundaryCount':1195,'sourceOwnedFullFactCount':215,'closedPropSupportCount':6,'actualEdgeCount':14718,'actualEvidence':pointers,'querySHA256':sha(query),'successfulRootBindingSHA256':sha(binding_path),'rootProofReexported':False,'rootProofKernelAuditReused':True,'completeRootFactsMustBeReadByConsumers':True,'priorRootArchiveSHA256':prior['archiveSHA256'],'rootFactsSHA256':binding['completeRootFacts']['sha256'],'sourceArtifactSHA256':binding['actualSourceArtifact']['sha256'],'sourceSHA256':binding['effectiveSource']['sha256'],'sourceJob':success['job_id'],'defaultHeartbeatBudget':200000,'nativeTargetComparisonAccepted':False,'platformPublished':False,'allMathlibProofBodiesExported':False,'Height603FirstClassOpen':True,'mathematicalParentClosed':False,'paperCitationContext':{'path':str(x.evidence_directory/'citation-context.json'),'paperQuotedParagraph':read(T/'citation-context.json')['paperQuotedParagraph'],'globalRootTheoremClaimedAsPaperDefinition':False,'originalIndependentReadbackUnchanged':True},'producerConsumers':[{'producer':'optimized actual source Expr/metadata BFS','consumer':'actual-facts.jsonl and actual-edges.jsonl under declared explicit boundary policy','targetConsumer':None}]};write(out/'SOURCE_LEDGER.json',ledger)
 registry=read(x.registry);merged=copy.deepcopy(registry);prep=merged['reference_source_preparation'];key='b1_source_replay_and_root_facts_unit'
 base_unit=copy.deepcopy(prep.get(key) or read(x.prior_root_directory/'registry-merge-fragment.json')['reference_source_preparation'][key]);unit=copy.deepcopy(base_unit);unit.update(closureSuccess=complete,fullCarrierClosureExported=complete,closureCompleteUnderDeclaredBoundaryPolicy=complete,allMathlibProofBodiesExported=False,nativeTargetComparisonAccepted=False,platformPublished=False,Height603FirstClassOpen=True,closureAppendix={'evidenceDirectory':str(x.evidence_directory),'sourceLedger':str(x.evidence_directory/'SOURCE_LEDGER.json'),'archive':str(x.evidence_directory/'b1-source-closure-appendix-v112.tar.gz'),'jobId':success['job_id'],'uniqueActualConstants':1444,'fullFactCountIncludingPriorRootReference':249,'explicitBoundaryCount':1195,'sourceOwnedFullFactCount':215,'closedPropSupportCount':6,'actualEdgeCount':14718,'rootProofReexported':False,'rootProofKernelAuditReused':True});prep[key]=unit
 write(out/'registry-merge-fragment.json',{'reference_source_preparation':{key:unit}});write(out/'platform-node-registry.merged.json',merged);write(out/'registry-merge-preconditions.json',{'basePath':str(x.registry),'baseSHA256':sha(x.registry),'replaceExactPaths':['/reference_source_preparation/'+key],'mayApply':complete,'sourceUnitAlreadyInRegistry':key in registry['reference_source_preparation'],'priorSourceUnitPreserved':True,'doesNotAddProofNodesDefinitionsEdgesOrRootGraphCounts':True})
 (out/'plan-append-proposal.md').write_text('- ['+('x' if complete else ' ')+'] 完成 B1 来源实际闭包在已声明边界政策下的遍历，ci018560：1444 个实际常量，249 份 full facts（含既有 root 验收引用）、1195 显式边界，215 来源 owner 项、6 条闭合 Prop support、14718 条边。默认 200k heartbeat；既有 root 证明沿 ci018542 完整事实及 source artifact SHA 承接，未重新导出 root proof；原 kernelInferredTypeStructurallyEqual=false 保留。\n- [ ] B1 目标版本对应及平台验收仍开放；Mathlib 等显式边界的证明体未全部导出。Height603 第一类与数学父义务不因来源闭包完成而关闭。\n')
 for p in out.iterdir():
  if p.is_file() and p.suffix in ['.json','.md'] and p.name!='archive-manifest.json':add(p)
 manifest={'schema':'B1-source-closure-appendix-archive/v112','completeUnderDeclaredBoundaryPolicy':complete,'archiveCreated':False,'files':[files[k] for k in sorted(files)],'priorRootArchiveSHA256':prior['archiveSHA256'],'rootFactsDuplicated':False};write(out/'archive-manifest.json',manifest)
 if x.archive:
  assert complete,'appendix gates failed';archive=out/'b1-source-closure-appendix-v112.tar.gz';idx=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
  with tarfile.open(archive,'w:gz') as t:
   i=tarfile.TarInfo('archive-index.json');i.size=len(idx);t.addfile(i,io.BytesIO(idx))
   for r in manifest['files']:assert sha(r['path'])==r['sha256'];t.add(r['path'],arcname=r['member'],recursive=False)
  with tarfile.open(archive,'r:gz') as t:
   assert len(t.getmembers())==len(manifest['files'])+1 and t.extractfile('archive-index.json').read()==idx
   for r in manifest['files']:
    h=hashlib.sha256();f=t.extractfile(r['member'])
    for b in iter(lambda:f.read(1048576),b''):h.update(b)
    assert h.hexdigest()==r['sha256'] and sha(r['path'])==r['sha256']
  assert archive.stat().st_size<100*1024**2
  manifest.update(archiveCreated=True,archive=str(archive),archiveSHA256=sha(archive),archiveBytes=archive.stat().st_size,allMembersReopenedSHA256Verified=True);write(out/'archive-manifest.json',manifest)
 print(json.dumps({'completeUnderDeclaredBoundaryPolicy':complete,'gates':gates,'errors':errors,'output':str(out),'archiveCreated':manifest['archiveCreated']},ensure_ascii=False))
if __name__=='__main__':main()
