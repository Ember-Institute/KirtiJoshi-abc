# B1 来源闭包独立附录

```bash
python3 /tmp/p2m-b1-closure-delivery-v112-20261117/prepare_archive.py \
  --archive \
  --output /tmp/p2m-b1-closure-delivery-v112-20261117/final \
  --evidence-directory /home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/b1-source-closure-appendix-v112-20261117
```

只读主区，只写任务 /tmp；不 CI、编译、API、Git 或删除。原 root-only 持久目录 `A/b1-source-delivery-v110-20261117` 保持冻结，原 source/AST/readback 和 77MB root facts 不重复打包。可覆盖 `--prior-root-directory` 指向 root 已复制的原交付；它的 archive 及 actual facts SHA 必须一致。

成功 ci018560 的实际 source Expr／metadata BFS：1444 unique、249 full（其中根为既有完整事实引用）、1195 显式边界、215 source owner full facts、6 条 closed Prop support、14718 edges。政策明确 Mathlib/Lean/外部库为边界；不声称这些库所有证明体已导出。

校验当前 optimized query 与配置、f936... binding 文件（此 SHA 属于 successful-root-binding，不是 query）、77MB root facts、根 query 成功审查 ci018542、source leaf ci018534 及 artifact ci018538。完整根证明由旧 facts 和 exact artifact/source SHA 承接；`rootProofReexported=false`、`rootProofKernelAuditReused=true`。原 kernelInferredTypeStructurallyEqual=false 不改为 true。

v110 ci018549 heartbeat 与 v111 ci018555 if-do syntax 失败输入均保留并核对原回执 hash。v111 的旧 /tmp 已被 then 修复覆盖；附录只在新 /tmp 恢复单个 then→do token，重构整文件 SHA 精确匹配 ci018555 原 input，另保留 reconstruction-provenance 明示来源，不称旧草稿未改变。默认 200k heartbeat；不重标失败尝试。

巨大 closure JSONL 仅放在压缩 tar，外部保留 summary/pointers/compact ledger；tar 强制小于 100MiB，逐成员重开 SHA。原 root archive 通过 external pin 引用，不复制其 tar 或 root JSON。CI history 保留原资源字段，total/user/system/wall/RSS/PSS 及 source/degraded 未知值不删。

root 审查后复制 final 至 evidence-directory。核对 registry base SHA 后应用 merged registry：只更新原 `reference_source_preparation.b1_source_replay_and_root_facts_unit`，补 `closureSuccess`／`closureCompleteUnderDeclaredBoundaryPolicy` 及附录指针。若原来源单元尚未应用，沿 prior fragment 保留全部原字段后补闭包，不丢失原 source-only 账本。追加 plan 仅勾选真实来源闭包；target 对应、平台发布、Height603 第一类和数学父义务仍开放。不覆盖旧 ledger，不删除 query/source。
