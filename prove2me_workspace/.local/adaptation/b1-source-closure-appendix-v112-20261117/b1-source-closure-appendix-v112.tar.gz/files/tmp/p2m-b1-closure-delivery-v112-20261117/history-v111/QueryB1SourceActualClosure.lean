import Lean
import B1SourceReplay

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  -- moduleNames maps the entire module array; use the indexed record directly.
  let imported ← env.header.modules[index.toNat]?
  return imported.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace B1SourceRootActualFacts
open Lean Elab Term Meta FoundationAudit

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open actual Expr {label}"

def checkedValueType (label : String) (value type : Expr) : MetaM Expr := do
  requireClosed label value
  requireClosed s!"TYPE of {label}" type
  let inferred ← match Kernel.check (← getEnv) {} value with
    | .ok t => pure t
    | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} inferred type with
  | .ok true => pure ()
  | .ok false => throwError "Kernel actual value/TYPE mismatch {label}"
  | .error ex => throwKernelException ex
  return inferred

end B1SourceRootActualFacts
namespace B1SourceActualClosure
open Lean Elab Term Meta FoundationAudit B1SourceRootActualFacts

structure WorkItem where
  name : Name
  parent : Name
  reason : String
  deriving Inhabited

def foundationOwner (n : Name) : Bool :=
  #[`Init,`Lean,`Std,`Mathlib,`Batteries].any (·.isPrefixOf n)

def cachedProjectOwner (n : Name) : Bool :=
  #[`Iut,`Genl].any (·.isPrefixOf n)

def namesJson (ns : Array Name) : Json := Json.arr (ns.map encodeName)

abbrev RecursorIndex := Std.HashMap Name (Array Name)

def actualMetadata (recursorsByInduct : RecursorIndex) (ci : ConstantInfo) : MetaM (Json × Array Name × Array Expr) := do
  let env ← getEnv
  let mut dependencies : Array Name := #[]
  let mut expressions : Array Expr := #[]
  let structureFacts ← match getStructureInfo? env ci.name with
    | none => pure Json.null
    | some info => do
      let mut fieldAutoParams : Array Json := #[]
      for f in info.fieldInfo do
        match f.autoParam? with
        | none => fieldAutoParams := fieldAutoParams.push Json.null
        | some e =>
          expressions := expressions.push e
          fieldAutoParams := fieldAutoParams.push (← checked (encodeExpr e))
      for f in info.fieldInfo do
        dependencies := dependencies.push f.projFn
        if let some p := f.subobject? then dependencies := dependencies.push p
      for p in info.parentInfo do
        dependencies := dependencies.push p.structName |>.push p.projFn
      pure (Json.mkObj [
        ("completeMetadata",← checked (structureShape info pure)),
        ("fieldAutoParamExprs",Json.arr fieldAutoParams)])
  let mut recursorRules : Array Json := #[]
  match ci with
  | .inductInfo i =>
    dependencies := dependencies ++ i.all.toArray ++ i.ctors.toArray
    -- Find compiler-owned recursor names from actual recursor metadata. Never synthesize .rec names.
    dependencies := dependencies ++ (recursorsByInduct[ci.name]?).getD #[]
  | .ctorInfo c => dependencies := dependencies.push c.induct
  | .recInfo r =>
    dependencies := dependencies ++ r.all.toArray
    for rule in r.rules do
      dependencies := dependencies.push rule.ctor
      expressions := expressions.push rule.rhs
      recursorRules := recursorRules.push (Json.mkObj [
        ("constructor",encodeName rule.ctor),("numFields",toJson rule.nfields),
        ("rhs",← checked (encodeExpr rule.rhs))])
  | _ => pure ()
  return (Json.mkObj [
    ("computationShape",← checked (computationShape ci pure)),
    ("structure",structureFacts),("recursorRules",Json.arr recursorRules)], dependencies, expressions)

def fullRecord (recursorsByInduct : RecursorIndex) (cache : AxiomCache) (ci : ConstantInfo) (mode : String)
    (readValue : Bool) : MetaM (Json × Array (Name × String)) := do
  let env ← getEnv
  requireClosed s!"actual TYPE {ci.name}" ci.type
  let value := if readValue then ci.value? (allowOpaque := true) else none
  let mut inferredType := Json.null
  if let some v := value then
    inferredType := ← checked (encodeExpr (← checkedValueType ci.name.toString v ci.type))
  let axs ← cachedAxioms cache ci.name
  let taxs ← expressionAxioms cache ci.type
  let vaxs ← match value with
    | none => pure #[]
    | some v => expressionAxioms cache v
  for xs in #[axs,taxs,vaxs] do ensureStandard ci.name.toString xs
  let (metadata, metadataNames, metadataExprs) ← actualMetadata recursorsByInduct ci
  let mut deps : Array (Name × String) := #[]
  for n in ci.type.getUsedConstants do deps := deps.push (n,"actual-TYPE")
  if let some v := value then
    for n in v.getUsedConstants do deps := deps.push (n,"actual-value")
  for n in metadataNames do deps := deps.push (n,"compiler-metadata")
  for e in metadataExprs do
    for n in e.getUsedConstants do deps := deps.push (n,"metadata-Expr")
  let prop ← isProp ci.type
  let owner := moduleOf env ci.name
  let closedSupport := prop && ci.levelParams.isEmpty && value.isSome
  let record := Json.mkObj [
    ("record",toJson "fullActualFact"),("name",toJson ci.name.toString),("nameExpr",encodeName ci.name),
    ("owner",toJson (owner.map Name.toString)),("ownerNameExpr",owner.map encodeName |>.getD Json.null),
    ("traversalMode",toJson mode),("kind",toJson (kind ci)),
    ("levelParams",namesJson ci.levelParams.toArray),
    ("actualTypeExpr",← checked (encodeExpr ci.type)),
    ("actualValueExpr",← match value with | none => pure Json.null | some v => checked (encodeExpr v)),
    ("valueRead",toJson value.isSome),("isProposition",toJson prop),
    ("closedZeroUniversePropSupport",toJson closedSupport),
    ("isInstance",toJson (Lean.Meta.isInstanceCore env ci.name)),
    ("binderInventory",toJson (binderInventory ci.type)),("telescope",← telescopeJson ci.type),
    ("directTypeConstants",namesJson (ci.type.getUsedConstants.qsort Name.lt)),
    ("directValueConstants",namesJson ((value.map Expr.getUsedConstants).getD #[] |>.qsort Name.lt)),
    ("metadata",metadata),
    ("kernelInferredValueTypeExpr",inferredType),
    ("kernelValueTypeMatchesActualTYPE",toJson value.isSome),
    ("axioms",toJson (axs.qsort Name.lt |>.map Name.toString)),
    ("typeAxioms",toJson (taxs.qsort Name.lt |>.map Name.toString)),
    ("valueAxioms",toJson (vaxs.qsort Name.lt |>.map Name.toString)),
    ("hasSorryAx",toJson (axs.contains `sorryAx))]
  return (record,deps)

def boundaryRecord (ci : ConstantInfo) (mode : String) : MetaM Json := do
  let env ← getEnv
  let owner := moduleOf env ci.name
  return Json.mkObj [
    ("record",toJson "actualBoundary"),("name",toJson ci.name.toString),("nameExpr",encodeName ci.name),
    ("owner",toJson (owner.map Name.toString)),("ownerNameExpr",owner.map encodeName |>.getD Json.null),
    ("traversalMode",toJson mode),("kind",toJson (kind ci)),
    ("levelParams",namesJson ci.levelParams.toArray),("isProposition",toJson (← isProp ci.type)),
    ("directTypeConstants",namesJson (ci.type.getUsedConstants.qsort Name.lt)),
    ("proofBodyExported",toJson false),
    ("boundaryReason",toJson "Shared foundation owner, or cached project polymorphic proof. Root standard-axiom audit covers proof dependence; this boundary is explicitly retained.")]

run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected source4.35 compiler"
  let cfg ← jsonFile (← absoluteEnv "B1_SOURCE_CLOSURE_FACTS_CONFIG")
  unless (← checked (cfg.getObjValAs? String "schema")) == "B1-source-actual-closure-config/v106" do
    throwError "Wrong actual closure query config"
  let outputDir ← checked (cfg.getObjValAs? String "outputDir")
  IO.FS.createDirAll outputDir
  let display ← checked (cfg.getObjValAs? String "rootDisplayName")
  let binding ← jsonFile (← checked (cfg.getObjValAs? String "successfulRootBindingFile"))
  unless (← checked (binding.getObjValAs? String "schema")) == "B1-successful-source-root-fact-binding/v111" do
    throwError "Wrong successful root binding"
  unless (← checked (binding.getObjValAs? String "successfulRootQueryJob")) == "ci-018542-4dae4da4" do
    throwError "Wrong successful root query job"
  let receiptPin ← checked (binding.getObjVal? "successfulReceipt")
  unless (← checked (receiptPin.getObjValAs? String "sha256")) ==
      (← checked (cfg.getObjValAs? String "successfulReceiptSHA256")) do
    throwError "Bound successful receipt pin mismatch"
  let receipt ← jsonFile (← checked (receiptPin.getObjValAs? String "path"))
  unless (← checked (receipt.getObjValAs? String "job_id")) == "ci-018542-4dae4da4" &&
      (← checked (receipt.getObjValAs? String "status")) == "succeeded" do
    throwError "Bound root query receipt is not the successful receipt"
  unless (← checked ((← checked (receipt.getObjVal? "result")).getObjValAs? Nat "exit_code")) == 0 do
    throwError "Bound root query receipt exit code is not zero"
  for key in #["priorKernelProofTypeMatchesActualTYPE", "priorStandardAxiomAuditPassed"] do
    unless (← checked (binding.getObjValAs? Bool key)) do throwError "Root receipt audit missing {key}"
  if (← checked (binding.getObjValAs? Bool "priorHasSorryAx")) do throwError "Bound root contains sorryAx"
  let factsPin ← checked (binding.getObjVal? "completeRootFacts")
  unless (← checked (factsPin.getObjValAs? String "sha256")) ==
      (← checked (cfg.getObjValAs? String "successfulRootFactsSHA256")) do
    throwError "Bound root facts pin mismatch"
  let artifactPin ← checked (binding.getObjVal? "actualSourceArtifact")
  unless (← checked (artifactPin.getObjValAs? String "sha256")) ==
      (← checked (cfg.getObjValAs? String "sourceArtifactSHA256")) do
    throwError "Bound source artifact pin mismatch"
  let sourcePin ← checked (binding.getObjVal? "effectiveSource")
  unless (← checked (sourcePin.getObjValAs? String "sha256")) ==
      (← checked (cfg.getObjValAs? String "effectiveSourceSHA256")) do
    throwError "Bound effective source pin mismatch"
  -- The compact binding preserves the compiler-owned Name exported by the successful
  -- root query. Decode its actual components; do not scan all environment declarations.
  let root ← checked (decodeName (← checked (binding.getObjVal? "rootActualNameExpr")))
  unless root.toString == display do throwError "Actual root binding display mismatch"
  let env ← getEnv
  unless moduleOf env root == some `B1SourceReplay do throwError "Wrong actual root owner"
  let rootCi ← getConstInfo root
  let some rootValue := rootCi.value? (allowOpaque := true) | throwError "No actual root proof value"
  unless namesJson rootCi.levelParams.toArray == (← checked (binding.getObjVal? "rootLevelParams")) do
    throwError "Actual root universe parameters differ from successful binding"
  unless (← checked (encodeExpr rootCi.type)) == (← checked (binding.getObjVal? "actualTypeExpr")) do
    throwError "Current actual root TYPE differs from successfully checked bound root"
  unless namesJson (rootCi.type.getUsedConstants.qsort Name.lt) ==
      (← checked (binding.getObjVal? "directTypeConstants")) do
    throwError "Current actual root TYPE dependencies differ from successful binding"
  unless namesJson (rootValue.getUsedConstants.qsort Name.lt) ==
      (← checked (binding.getObjVal? "directValueConstants")) do
    throwError "Current actual root proof dependencies differ from successful binding"
  let rootReference := Json.mkObj [
    ("record",toJson "priorKernelVerifiedRootReference"),("nameExpr",encodeName root),
    ("ownerNameExpr",encodeName `B1SourceReplay),("successfulRootBinding",binding),
    ("currentActualTYPEAndDirectDependenciesMatch",toJson true),
    ("rootProofKernelAuditReused",toJson true),("rootProofReexported",toJson false),
    ("completeRootFactsMustBeReadByConsumers",toJson true)]
  IO.FS.writeFile (outputDir ++ "/root-first-reference.json") (rootReference.compress ++ "\n")
  let records ← IO.FS.Handle.mk (System.FilePath.mk (outputDir ++ "/actual-facts.jsonl")) .write
  let edges ← IO.FS.Handle.mk (System.FilePath.mk (outputDir ++ "/actual-edges.jsonl")) .write
  records.putStrLn rootReference.compress
  records.flush
  let recursorsByInduct := env.constants.fold (fun acc n c => match c with
    | .recInfo r =>
      if ((moduleOf env n).map fun owner => owner == `B1SourceReplay || cachedProjectOwner owner).getD false then
        r.all.foldl (fun acc ind => acc.insert ind (((acc[ind]?).getD #[]).push n)) acc
      else acc
    | _ => acc) ({} : RecursorIndex)
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let mut queue : Array WorkItem := #[]
  for dep in rootCi.type.getUsedConstants do
    queue := queue.push { name := dep, parent := root, reason := "actual-TYPE" }
  for dep in rootValue.getUsedConstants do
    queue := queue.push { name := dep, parent := root, reason := "actual-value" }
  let mut seen : Std.HashSet Name := ({} : Std.HashSet Name).insert root
  let mut i := 0
  let mut fullCount := 1
  let mut boundaryCount := 0
  let mut supportCount := 0
  let mut sourceOwnedCount := 1
  while i < queue.size do
    let item := queue[i]!
    i := i+1
    edges.putStrLn ((Json.mkObj [
      ("from",encodeName item.parent),("to",encodeName item.name),
      ("reason",toJson item.reason)]).compress)
    unless seen.contains item.name do
      seen := seen.insert item.name
      let ci ← getConstInfo item.name
      let some owner := moduleOf env item.name |
        throwError "Reachable constant lacks actual imported owner {item.name}"
      let prop ← isProp ci.type
      let sourceOwned := owner == `B1SourceReplay
      let cachedProject := cachedProjectOwner owner
      let closedSupport := cachedProject && prop && ci.levelParams.isEmpty &&
        (ci.value? (allowOpaque := true)).isSome
      let full := sourceOwned || (cachedProject && !prop) || closedSupport
      if full then
        let mode := if sourceOwned then "B1-source-owner-full" else if closedSupport then
          "cached-project-closed-zero-universe-Prop-support" else "cached-project-carrier-data"
        let (record,deps) ← fullRecord recursorsByInduct cache ci mode true
        records.putStrLn record.compress
        fullCount := fullCount+1
        if closedSupport then supportCount := supportCount+1
        if sourceOwned then sourceOwnedCount := sourceOwnedCount+1
        for (dep,reason) in deps do
          queue := queue.push { name := dep, parent := item.name, reason := reason }
      else
        let mode := if foundationOwner owner then "shared-foundation-boundary" else if cachedProject then
          "cached-project-polymorphic-proof-boundary" else "external-library-boundary"
        records.putStrLn ((← boundaryRecord ci mode).compress)
        boundaryCount := boundaryCount+1
        -- Cached project proof TYPEs can contain required project carriers. Inspect
        -- those TYPE edges, while keeping this polymorphic proof body at the boundary.
        if cachedProject then
          for dep in ci.type.getUsedConstants do
            queue := queue.push { name := dep, parent := item.name, reason := "cached-proof-TYPE" }
    records.flush
    edges.flush
  records.flush
  edges.flush
  IO.FS.writeFile (outputDir ++ "/summary.json") ((Json.mkObj [
    ("schema",toJson "B1-source-actual-closure/v106"),("configuration",cfg),
    ("compilerVersion",toJson Lean.versionString),("sourceRoot",encodeName root),
    ("sourceOwner",encodeName `B1SourceReplay),
    ("priorVerifiedRootReferenceUsed",toJson true),("successfulRootQueryJob",toJson "ci-018542-4dae4da4"),
    ("uniqueActualConstants",toJson seen.size),
    ("fullFactCount",toJson fullCount),("explicitBoundaryCount",toJson boundaryCount),
    ("sourceOwnedFullFactCount",toJson sourceOwnedCount),("closedPropSupportCount",toJson supportCount),
    ("actualEdgeCount",toJson queue.size),
    ("traversalCompleteUnderDeclaredBoundaryPolicy",toJson true),
    ("allMathlibProofBodiesExported",toJson false),
    ("nativeTargetComparisonAccepted",toJson false)]).pretty ++ "\n")
  logInfo "Actual B1 source closure, carrier data and closed Prop support exported with explicit cache/foundation boundaries"
end B1SourceActualClosure
