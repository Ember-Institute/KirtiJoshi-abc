#!/usr/bin/env python3
"""Bind real Cor23 source TYPE and target compilation receipts; no compiler/CI/API/Git."""
from pathlib import Path
import json,hashlib,argparse,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p):p=Path(p).resolve();return {'path':str(p),'sha256':sha(p),'contents':read(p)}
def receipt(p):
 b=bind(p);r=b['contents'];assert r['status']=='succeeded'and r['result']['exit_code']==0
 assert r['request']['workspace']==str(W)and r['request']['exclusive']is True
 ss=r['result']['snapshot'];assert ss['workspace_mode']=='exclusive_worktree'and ss['snapshot_id']is None
 return b
def name(n):return ''if not n else name(n[0])+('.'if n[0]else'')+str(n[2])
ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['open','reduction'],required=True);ap.add_argument('--source-facts',type=Path,required=True);ap.add_argument('--source-type-receipt',type=Path,required=True);ap.add_argument('--source-replay-leaf',type=Path,required=True);ap.add_argument('--source-replay-artifact',type=Path,required=True);ap.add_argument('--target-leaf',type=Path,required=True);ap.add_argument('--target-artifact',type=Path,required=True);ap.add_argument('--out',type=Path);a=ap.parse_args()
c=read(D/('configs/open-type.template.json'if a.mode=='open'else'configs/reduction.template.json'));facts=bind(a.source_facts);j=facts['contents'];assert j['schema']=='pure-arithmetic-original-type-facts/v9'and j['rootTheoremProofsRead']is False
root,=j['records'];assert root['name']=='Iut.statementII_of_cor312'and root['module']=='AbcSourceReplay.Cor23StatementII';assert root['nameExpr']==c['sourceRootNameExpr'];assert root['levelParams']==c['sourceLevelParamsActual'];assert j['closedTypeProofValues']==[],'New closed Prop support requires explicit current map/kernel review; do not drop it.'
sr=receipt(a.source_type_receipt);cfg=Path(sr['contents']['request']['environment']['PURE_TYPE_SOURCE_CONFIG']);assert read(cfg)==j['configuration']and sr['contents']['request']['worktree_manifest']['input_hashes'].get(str(cfg))==sha(cfg)
replay=Path(j['configuration']['source']['path']);assert sha(replay)==root['sourceSha256']==j['configuration']['sourceSha256'];leaf=receipt(a.source_replay_leaf);art=receipt(a.source_replay_artifact)
for b in [leaf,art]:assert b['contents']['request']['worktree_manifest']['input_hashes'].get(str(replay))==sha(replay)
m=read(D/'maps/actual-type-map.json');assert sha(a.source_facts)==m['sourceFactsSha256'];known={name(x['sourceNameExpr']):x for x in m['rows']};assert len(known)==11
observed={x['name']:x for x in root['directTypeConstants']if x['name'].startswith(('Iut.','Genl.','_private.'))};assert set(observed)==set(known)
for n,row in known.items():
 assert observed[n]['nameExpr']==row['sourceNameExpr']and observed[n]['owner']==row['sourceOwnerExpr'];assert sha(row['definitionSource'])==row['definitionSourceSha256'];assert row['targetToSourceUniverseIndices']is None
c.update(sourceFactsBinding=facts,sourceTypeReceipt=sr,sourceReplayLeafReceipt=leaf,sourceReplayArtifactReceipt=art)
target=Path(c['installedSource']if a.mode=='open'else c['installedSolution']);expected=c['expectedStubText']if a.mode=='open'else c['expectedSolutionText'];assert target.read_text()==expected
for key,p in [('stubLeafReceipt'if a.mode=='open'else'solutionLeafReceipt',a.target_leaf),('stubArtifactReceipt'if a.mode=='open'else'solutionArtifactReceipt',a.target_artifact)]:
 b=receipt(p);assert b['contents']['request']['worktree_manifest']['input_hashes'].get(str(target))==sha(target);c[key]=b
if a.mode=='reduction':
 for row in c['publicProofs']:
  b=row['platformReadbackBinding'];assert sha(b['path'])==b['sha256']and read(b['path'])==b['contents'];r=b['contents'];assert r['theorem_name']==row['name']and r['theorem_id']==row['theoremId']and r['status']=='Proved';assert sha(row['localSource'])==row['localSourceSha256']
 c['platformVsLocalClassification']='c2 platform Proved, local canonical stub may carry sorryAx; epsilonE_le platform Proved. Target kernel dependency audit must report local and platform status separately.'
out=(a.out or D/('bound/open-type.final.json'if a.mode=='open'else'bound/reduction.final.json')).resolve();assert out.is_relative_to(D);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(out,sha(out))
