本包仅为 generic `Iut.statementII_of_cor312` 的静态准备，未运行编译、MCP-CI、API 或 Git，未修改主工作区。

结论：它是可先行拆分的真实来源路径，原始完整证明只有 57 行。现平台已发布完整高度理论结构、两种有界偏差关系、推论 2.2 输入、P7 结构、阈值和数值函数；但 HeightTheory 包明确省略 `StatementI/II`，故先需发布纯定义 `Genl.HeightTheory.StatementII` 的完整同名迁移包。BoundedDiscrepancy 包只保留定义和记号，缺 `trans`、`mono`、`empty`、`union`、`smul`、`DiscrepancyEquiv.ge`；另需本文件自身的 `Iut.DiscrepancyLE.of_finite`。这些七项结构性辅助均以内联私有证明保留，不要求新增七个公开节点。

原 `Corollary23.olean` 在当前 refer、abc.old 和 source-project overlay 均缺失。但是已缓存的真实 `Iut.Implication.Corollary22` 传递包含 `Genl.HeightTheory.StatementII` 和全部原有有界偏差结构引理，因此不必构建缺缓存的 `Genl.GeneralPosition.TheoremTwoOne`，即可先重放本 generic root。该 ProofPackage 模块只对文件后续 `cor312Variant_implies_abc` 的 ABC 目标使用。

入口依次为：

1. `parser-config.provisional.json`：对真实 Corollary23、Genl HeightTheory 和 BoundedDiscrepancy 三源文件做 AST 解析。当前 `source/source-provenance.json` 的行坐标及 source-body 摘要是人工确认的原始文本候选，必须先由实际 AST 精确范围重新绑定，不能冒充编译器身份。
2. `definition/Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII.lean`：唯一新增基础定义，完整保留原始 StatementII 命题。先用缓存原 Genl.HeightTheory 的真实 Expr TYPE/value 和当前目标对应核验，再私有发布。
3. `source/ReplayCor23StatementII.lean`：只导入 cached 原 Corollary22，保留原 of_finite、原 root 类型及完整证明。应在 AST 通过后按接受跨度重建并独占编译；拟定 module 为 `AbcSourceReplay.Cor23StatementII`。
4. `queries/QueryStatementIISourceType.lean` 及 provisional config：复用既有类型导出器，读取 narrow replay 中 root 的真实完整 TYPE。它不伪称原 Corollary23 已有缓存；root 声明的 Name、层级参数与归属只能以新编译事实确认。
5. `stub/` 与 `solution/`：目标完整候选。隐式 T/AG/TG/P，显式 I/ex/cheb/pnt/h312，共九项绑定；这只是由源上下文展开的候选，宇宙参数和完整 BinderInfo 须由实际源/目标 Expr 比较。source 主证明体原始文本在 solution 中未改，另七项 short helper 只改变 namespace、可见性及 protected 修饰。

两个目标公共证明依赖仅为开放的 `Corollary22Inputs.c2`（已有验收归约到 theorem110）和已证明的 `epsilonE_le`；实际平台编号见 `dependencies.json`。目标文件不导入源 Iut/Genl 模块，不导入自身父 theorem。静态检查已确认这项导入边界，但没有任何 Lean 通过声明。

`type-named-map.candidate.json` 只列出源文本所需的十一项具名常量候选，不是实际编译类型常量清单。真实 TYPE 新发现的未映射 data/private 名字必须停止并明确处理；不能靠字符串替换自动吞掉。`queries/ExistingTypeAuditAlgorithm.reference.lean.txt` 只是已验收算法参考，不是已为新 root 改好的执行查询。主智能体须绑定实际导出 Expr、当前已发布 owner 和新 StatementII Definition。

`readbacks/trilingual-draft.json` 是本子智能体对源和候选 stub 的全新静态读回，不冒称既有 A/B 读者或平台验收。中文 compactly bounded subset 暂留占位符，候选“紧有界子集／紧致有界子集”；若项目已有明确译名，应按既有约定替换。原文段落指针在 `paper/context.json`，引用 Mochizuki IUT IV Corollary2.3 proof pp.54–55；本子智能体只确认现有原文文本，不冒称新视觉页图验收。

此 generic StatementII 只陈述给定抽象高度理论中所有点的统一加法误差界。它仍依赖全称 Corollary22Inputs/P7/3.12 输入，不证明这些输入的构造，也不把抽象 T 和本项目 canonical 三足曲线高度理论认同。B1/B2 的真实点域、高度、不同理想及导子身份仍另需验收。
