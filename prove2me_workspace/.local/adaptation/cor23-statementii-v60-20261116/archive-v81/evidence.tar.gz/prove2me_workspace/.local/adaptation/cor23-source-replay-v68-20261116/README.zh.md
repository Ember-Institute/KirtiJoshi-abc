本包已经从真实接受的三源 AST 中重新绑定 Corollary23 的窄重放；仅写/tmp，未编译、CI、API、Git或主区修改。

AST 来源为 `cor23-statementii-v60-20261116/actual-parser-output/Iut-Implication-Corollary23.jsonl`，parser真实回执 `ci-017946-9604e6df`，终态 succeeded/exit0/exclusive_worktree，完整回执和输出SHA已绑定。所有声明／上下文／signature／proof范围直接取已接受 AST 字段。没有用正则或行数分割Lean命令。

入口 `AbcSourceReplay/Cor23StatementII.lean`：从原source header AST保留真实 `import Iut.Implication.Corollary22`，完整复制 namespace Iut、universe u v、open Finset Real、两项variable上下文、`DiscrepancyLE.of_finite` 和 `statementII_of_cor312` 两个完整声明，再复制原 end Iut。原模块文档也完整保留。省略后续两个ABC父声明与它们需要的TheoremTwoOne导入，没有加新数学参数、类型别名或占位证明。

`accepted-ast-replay-map.json` 保存：原source/normalizedsource SHA、parser actual receipt+SHA、每个原命令到重放字节区间映射、完整原syntax/context，以及两条声明完整signature/proof的原AST范围→新范围。每个跨度均逐字节检查相同，proof/body未改。这里仅声称AST和字节身份，不声称源码Name已有compiler验证；actual nameExpr留null。

主智能体建议安装到 W/AbcSourceReplay/Cor23StatementII.lean，再用原4.35源环境直接独占叶检查与产物生成至 W/.lake/build/lib/lean/AbcSourceReplay/Cor23StatementII.olean。该布局明确对应新module `AbcSourceReplay.Cor23StatementII`，实际owner仍由下一步读取。不要把它假报为原模块Iut.Implication.Corollary23；本重放始终保留原声明namespace Iut，但其compiled owner是独立重放模块。每个新叶首次60s/16GiB由root提交。

随后运行 `bind_source_type_config.py --installed-source <W/AbcSourceReplay/Cor23StatementII.lean>`，它只核对接受AST和安装字节，输出bound/source-type.config.json，不编译或调用外部API。

`queries/QueryCor23ReplayType.lean` 复用已验收的4.35 c2 TYPE exporter：唯一import改为新replay模块，并从实际env.constants中按actual owner和显示名唯一解析root，保留真正str/num Name组件，再读取完整ConstantInfo.type。新输出另含全部direct TYPE常量的actualName、owner、kind、levels；root theorem proof value与其proof axiom closure不读取。完整TYPE中的额外自有closed Prop支持仍按既有算法显式导出type/proof values；未知data不得替换。

query环境键仍为 `PURE_TYPE_SOURCE_CONFIG=<bound config absolute path>`。源 LEAN_PATH复用原4.35缓存路径，并加入新replay artifact所在的W/.lake/build/lib/lean；只能导入本新source模块和原缓存Iut/Genl/Mathlib，不导入目标4.33 Definitions/Theorems。actual owner、四个或其它宇宙参数计数、BinderInfo与实际项目常量清单以运行后事实为准，不用候选文字预填。完整query配置只是待执行草稿；semantic replay和TYPE的新MCP-CI回执仍由root取得。

中文compactly bounded译名继续保留占位，不影响source replay。该generic来源证明不完成本项目具体canonical高度/点域/不同理想/导子身份。
