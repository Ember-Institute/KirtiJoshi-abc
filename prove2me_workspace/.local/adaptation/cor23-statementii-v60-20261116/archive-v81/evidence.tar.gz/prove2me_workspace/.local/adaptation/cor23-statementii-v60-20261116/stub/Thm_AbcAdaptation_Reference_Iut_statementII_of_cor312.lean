/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22
import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open AbcAdaptation.Reference
open AbcAdaptation.Reference.Iut
universe u v

theorem AbcAdaptation.Reference.Iut.statementII_of_cor312
    {T : Genl.HeightTheory} {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
    {P : Corollary312VariantData.{u, v} AG TG → Prop}
    (I : ∀ (K : T.CBS) (d : ℕ), Corollary22Inputs T K d)
    (ex : ∀ K d, ThetaDataExistence P (I K d))
    (cheb : ChebyshevBound) (pnt : PrimeCountingBound)
    (h312 : ∀ X : Corollary312VariantData.{u, v} AG TG, P X → Corollary312Variant X) :
    T.StatementII := by
  sorry
