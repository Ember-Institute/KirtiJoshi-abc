#!/usr/bin/env python3
"""Bind the installed AST-exact upstream replay; no compiler, CI, API, or Git action."""
from pathlib import Path
import argparse,json,hashlib,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--installed-source',type=Path,required=True);ap.add_argument('--out',type=Path,default=D/'bound/source-type.config.json');a=ap.parse_args()
p=a.installed_source.resolve();assert p in [W/'AbcSourceReplay/Cor23StatementII.lean',D/'source-project/AbcSourceReplay/Cor23StatementII.lean'],'Source must have the exact module-relative layout; CI working_directory and actual runtime owner must also match.'
raw=D/'AbcSourceReplay/Cor23StatementII.lean';assert p.read_bytes()==raw.read_bytes()
m=read(D/'accepted-ast-replay-map.json');r=read(m['parserReceipt']['path']);assert r['job_id']==m['parserJob']and r['status']=='succeeded'and r['result']['exit_code']==0;assert sha(m['parserReceipt']['path'])==m['parserReceipt']['sha256'];assert sha(m['parserOutput']['path'])==m['parserOutput']['sha256']
source=Path(m['source']['normalizedPath']);sourcebytes=source.read_bytes();assert sha(source)==m['source']['normalizedSha256'];replay=p.read_bytes()
for row in m['selectedDeclarations']:
 for key in ['signatureRanges','proofRanges']:
  for span in row[key]:
   s=span['sourceRange'];a0,b0=s['start']['offset'],s['end']['offset'];a1,b1=span['replayByteRange'];assert sourcebytes[a0:b0]==replay[a1:b1];assert hashlib.sha256(replay[a1:b1]).hexdigest()==span['sha256']
c=read(D/'configs/source-type.template.json');c['source']['path']=str(p);c['source']['sha256']=sha(p);c['sourceSha256']=sha(p);c['sourceCommandMap']={'path':str(D/'accepted-ast-replay-map.json'),'sha256':sha(D/'accepted-ast-replay-map.json')};c['installedReplayModule']='AbcSourceReplay.Cor23StatementII';c['actualRuntimeOwnerStillRequiresCIQuery']=True
out=a.out.resolve();assert out.is_relative_to(D);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(out,sha(out))
