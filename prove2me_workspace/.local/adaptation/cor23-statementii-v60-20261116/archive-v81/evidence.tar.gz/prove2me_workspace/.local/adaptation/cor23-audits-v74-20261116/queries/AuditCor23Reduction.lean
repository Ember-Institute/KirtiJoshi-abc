import Lean
import Solutions.Sol_AbcAdaptation_Reference_Iut_statementII_of_cor312
import Theorems.Thm_AbcAdaptation_Reference_Iut_statementII_of_cor312

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

abbrev TypeNames := Array (Name × Name)

-- Proof bodies are substituted only for explicitly exported, closed Prop
-- constants in the original TYPE. Data constants require an actual named map.
partial def decodeType (names : TypeNames) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := decodeType names proofs visiting expandProofs
  let relocate : Name → Except String Name := fun n => do
    if let some p := names.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`Definitions,`Theorems,`Solutions].any (·.isPrefixOf n) then
      throw s!"Unmapped TYPE project constant: {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    let levels ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName original)) then
      unless levels.isEmpty do throw "Closed source proof unexpectedly has universe arguments"
      if !expandProofs then return .const original levels.toList
      if visiting.contains original then throw s!"Cyclic proof-only resolution: {original}"
      return ← decodeType names proofs (visiting.push original) true (← field p "actualProofExpr")
    return .const (← relocate original) levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def actualTargetProof (ci : ConstantInfo) : MetaM Expr := do
  match ci with
  | .thmInfo t => pure t.value
  | _ => throwError "Expected compiled native theorem {ci.name}"

def assertConstants (label : String) (e : Expr) (owners : Array Name) : MetaM Unit := do
  let env ← getEnv
  for n in e.getUsedConstants do
    if #[`Iut,`Genl,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf n) then
      throwError "Original project constant remains in {label}: {n}"
    let some owner := moduleOf env n | throwError "No imported owner in {label}: {n}"
    unless owners.contains owner || #[`Init,`Lean,`Std,`Mathlib,`Batteries,`Aesop,`Qq,`Plausible,`ProofWidgets,`ImportGraph,`Cli,`LeanSearchClient].any (·.isPrefixOf owner) do
      throwError "Unexpected owner in {label}: {n}, {owner}"

def proofValue (ci : ConstantInfo) : MetaM Expr := do
  match ci with
  | .thmInfo t => pure t.value
  | .defnInfo d => pure d.value
  | .opaqueInfo o => pure o.value
  | _ => throwError "No actual proof value {ci.name}"

def nativeDataNames : TypeNames := #[
  (`Genl.HeightTheory, `AbcAdaptation.Reference.Genl.HeightTheory),
  (`AbcAdaptation.Reference.Genl.HeightTheory, `AbcAdaptation.Reference.Genl.HeightTheory),
  (`Iut.AnabelianGeometry, `AbcAdaptation.Reference.Iut.AnabelianGeometry),
  (`AbcAdaptation.Reference.Iut.AnabelianGeometry, `AbcAdaptation.Reference.Iut.AnabelianGeometry),
  (`Iut.ChebyshevBound, `AbcAdaptation.Reference.Iut.ChebyshevBound),
  (`AbcAdaptation.Reference.Iut.ChebyshevBound, `AbcAdaptation.Reference.Iut.ChebyshevBound),
  (`Iut.Corollary22Inputs, `AbcAdaptation.Reference.Iut.Corollary22Inputs),
  (`AbcAdaptation.Reference.Iut.Corollary22Inputs, `AbcAdaptation.Reference.Iut.Corollary22Inputs),
  (`Iut.Corollary312Variant, `AbcAdaptation.Reference.Iut.Corollary312Variant),
  (`AbcAdaptation.Reference.Iut.Corollary312Variant, `AbcAdaptation.Reference.Iut.Corollary312Variant),
  (`Iut.Corollary312VariantData, `AbcAdaptation.Reference.Iut.Corollary312VariantData),
  (`AbcAdaptation.Reference.Iut.Corollary312VariantData, `AbcAdaptation.Reference.Iut.Corollary312VariantData),
  (`Iut.PrimeCountingBound, `AbcAdaptation.Reference.Iut.PrimeCountingBound),
  (`AbcAdaptation.Reference.Iut.PrimeCountingBound, `AbcAdaptation.Reference.Iut.PrimeCountingBound),
  (`Iut.TemperedGeometry, `AbcAdaptation.Reference.Iut.TemperedGeometry),
  (`AbcAdaptation.Reference.Iut.TemperedGeometry, `AbcAdaptation.Reference.Iut.TemperedGeometry),
  (`Iut.ThetaDataExistence, `AbcAdaptation.Reference.Iut.ThetaDataExistence),
  (`AbcAdaptation.Reference.Iut.ThetaDataExistence, `AbcAdaptation.Reference.Iut.ThetaDataExistence),
  (`Genl.HeightTheory.CBS, `AbcAdaptation.Reference.Genl.HeightTheory.CBS),
  (`AbcAdaptation.Reference.Genl.HeightTheory.CBS, `AbcAdaptation.Reference.Genl.HeightTheory.CBS),
  (`Genl.HeightTheory.StatementII, `AbcAdaptation.Reference.Genl.HeightTheory.StatementII),
  (`AbcAdaptation.Reference.Genl.HeightTheory.StatementII, `AbcAdaptation.Reference.Genl.HeightTheory.StatementII)]

def typeProofRows (types : Array Expr) : MetaM (Array Json) := do
  let env ← getEnv
  let mut queue : Array Name := #[]
  for e in types do
    for n in e.getUsedConstants do
      if #[`AbcAdaptation,`_private].any (·.isPrefixOf n) &&
          !nativeDataNames.any (·.2 == n) && !queue.contains n then queue := queue.push n
  let mut out := #[]
  let mut i := 0
  while i < queue.size do
    let n := queue[i]!
    i := i + 1
    let ci ← getConstInfo n
    unless ci.levelParams.isEmpty && (← isProp ci.type) do
      throwError "TYPE constant requires a genuine data map, not a proof expansion: {n}"
    let v ← proofValue ci
    requireClosed s!"actual TYPE proof {n}" v
    let axs ← collectAxioms n
    let taxs ← expressionAxioms ci.type
    let vaxs ← expressionAxioms v
    for xs in #[axs,taxs,vaxs] do ensureStandard s!"actual TYPE proof {n}" xs
    for e in #[ci.type,v] do
      for dep in e.getUsedConstants do
        if #[`AbcAdaptation,`_private].any (·.isPrefixOf dep) &&
            !nativeDataNames.any (·.2 == dep) && !queue.contains dep then queue := queue.push dep
    out := out.push (Json.mkObj [("nameExpr", encodeName n), ("name", toJson n.toString),
      ("actualTypeExpr", ← checked (encodeExpr ci.type)), ("actualProofExpr", ← checked (encodeExpr v)),
      ("levelParams", Json.arr #[]), ("isProposition", toJson true), ("isClosed", toJson true),
      ("axioms", toJson (axs.map Name.toString)), ("typeAxioms", toJson (taxs.map Name.toString)),
      ("proofAxioms", toJson (vaxs.map Name.toString))])
  return out

def validateProofRows (rows : Array Json) : MetaM Unit := do
  for p in rows do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) &&
        (← checked (p.getObjValAs? Bool "isClosed")) &&
        (← checked (arrayField p "levelParams")).isEmpty do throwError "Non-closed/non-Prop resolution {n}"
    let t ← checked (decodeType nativeDataNames rows #[] true (← checked (field p "actualTypeExpr")))
    let v ← checked (decodeType nativeDataNames rows #[n] true (← checked (field p "actualProofExpr")))
    let vt ← kernelCheck s!"actual closed proof {n}" v
    unless ← isProp vt do throwError "Data substitution forbidden {n}"
    kernelTypeEq s!"actual proof body/proposition {n}" vt t
    for key in #["axioms","typeAxioms","proofAxioms"] do
      for ax in ← checked (arrayField p key) do
        unless (standardAxioms.map fun a => Json.str a.toString).contains ax do throwError "Nonstandard proof axiom {n}"
    ensureStandard s!"expanded proof {n}" (← expressionAxioms v)

def expectedDataOwners : Array (Name × Name) := #[
  (`AbcAdaptation.Reference.Genl.HeightTheory, `Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_HeightTheory),
  (`AbcAdaptation.Reference.Iut.AnabelianGeometry, `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve),
  (`AbcAdaptation.Reference.Iut.ChebyshevBound, `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection),
  (`AbcAdaptation.Reference.Iut.Corollary22Inputs, `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22),
  (`AbcAdaptation.Reference.Iut.Corollary312Variant, `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement),
  (`AbcAdaptation.Reference.Iut.Corollary312VariantData, `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement),
  (`AbcAdaptation.Reference.Iut.PrimeCountingBound, `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants),
  (`AbcAdaptation.Reference.Iut.TemperedGeometry, `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions),
  (`AbcAdaptation.Reference.Iut.ThetaDataExistence, `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22),
  (`AbcAdaptation.Reference.Genl.HeightTheory.CBS, `Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_HeightTheory),
  (`AbcAdaptation.Reference.Genl.HeightTheory.StatementII, `Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII)]


def boundJson (binding : Json) : MetaM Json := do
  if binding == Json.null then throwError "Actual input binding pending"
  let p ← checked (stringField binding "path")
  let actual ← jsonFile p
  unless actual == (← checked (field binding "contents")) do throwError "Bound JSON changed: {p}"
  unless (← checked (stringField binding "sha256")).length == 64 do throwError "Missing root SHA binding: {p}"
  return actual

def passedReceipt (binding : Json) : MetaM Json := do
  let r ← boundJson binding
  unless (← checked (stringField r "status")) == "succeeded" do throwError "Required CI receipt did not succeed"
  let result ← checked (field r "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Required CI exit status is nonzero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Required exclusive input receipt differs"
  return r

def readCor23SourceRecord (cfg : Json) : MetaM (Json × Json) := do
  let _ ← passedReceipt (← checked (field cfg "sourceTypeReceipt"))
  let facts ← boundJson (← checked (field cfg "sourceFactsBinding"))
  unless (← checked (stringField facts "schema")) == "pure-arithmetic-original-type-facts/v9" &&
      !(← checked (facts.getObjValAs? Bool "rootTheoremProofsRead")) do throwError "Expected TYPE-only source export"
  let records ← checked (arrayField facts "records")
  unless records.size == 1 do throwError "Expected one actual source theorem TYPE"
  let r := records[0]!
  unless (← checked (field r "nameExpr")) == (← checked (field cfg "sourceRootNameExpr")) &&
      (← checked (stringField r "name")) == "Iut.statementII_of_cor312" &&
      (← checked (stringField r "module")) == "AbcSourceReplay.Cor23StatementII" do
    throwError "Actual replay source root Name/owner differs"
  let sourceProofs ← checked (arrayField facts "closedTypeProofValues")
  validateProofRows sourceProofs
  for (n,o) in expectedDataOwners do
    unless moduleOf (← getEnv) n == some o do throwError "Mapped target data owner differs: {n}"
  return (facts,r)

def canonicalType (type : Expr) (params : List Name) (count : Nat) : MetaM Expr := do
  unless params.length == count do throwError "Universe arity differs"
  return type.instantiateLevelParams params ((canonicalLevels count).map Level.param)
def valueOf (ci : ConstantInfo) : Option Expr :=
  match ci with
  | .thmInfo i => some i.value
  | .defnInfo i => some i.value
  | .opaqueInfo i => some i.value
  | _ => none


run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected target4.33 compiler"
  let cfg ← jsonFile (← absoluteEnv "COR23_REDUCTION_AUDIT_CONFIG")
  unless (← checked (stringField cfg "schema")) == "cor23-parent-reduction-audit-config/v69" do throwError "Wrong Cor23 reduction config"
  let _ ← passedReceipt (← checked (field cfg "solutionLeafReceipt"))
  let _ ← passedReceipt (← checked (field cfg "solutionArtifactReceipt"))
  let (facts,r) ← readCor23SourceRecord cfg
  let sourceProofs ← checked (arrayField facts "closedTypeProofValues")
  let root ← checked (decodeName (← checked (field cfg "rootNameExpr")))
  let ownModule ← checked (decodeName (← checked (field cfg "rootModuleExpr")))
  let parentName := `AbcAdaptation.Reference.Iut.statementII_of_cor312
  let parentModule := `Theorems.Thm_AbcAdaptation_Reference_Iut_statementII_of_cor312
  let env ← getEnv
  let ci ← getConstInfo root
  let parent ← getConstInfo parentName
  unless moduleOf env root == some ownModule && moduleOf env parentName == some parentModule do throwError "Wrong solution/parent TYPE owners"
  let sourceExpr ← checked (decodeType nativeDataNames sourceProofs #[] true (← checked (field r "elaboratedExpr")))
  let sourceSig ← checked (decodeType nativeDataNames sourceProofs #[] false (← checked (field r "elaboratedExpr")))
  let ownTypeProofs ← typeProofRows #[ci.type,parent.type]
  validateProofRows ownTypeProofs
  let solutionExpr ← checked (decodeType nativeDataNames ownTypeProofs #[] true (← checked (encodeExpr ci.type)))
  let parentExpr ← checked (decodeType nativeDataNames ownTypeProofs #[] true (← checked (encodeExpr parent.type)))
  let solutionSig ← checked (decodeType nativeDataNames ownTypeProofs #[] false (← checked (encodeExpr ci.type)))
  let parentSig ← checked (decodeType nativeDataNames ownTypeProofs #[] false (← checked (encodeExpr parent.type)))
  let ps ← namesFromJson (← checked (field r "levelParams"))
  let st ← canonicalType sourceExpr ps ci.levelParams.length
  let tt ← canonicalType solutionExpr ci.levelParams ci.levelParams.length
  let pt ← canonicalType parentExpr parent.levelParams ci.levelParams.length
  kernelTypeEq "Cor23 source/parent TYPE" st pt
  kernelTypeEq "Cor23 source/solution TYPE" st tt
  kernelTypeEq "Cor23 parent/solution TYPE" pt tt
  for sig in #[parentSig,solutionSig] do
    unless binderInventory sourceSig == binderInventory sig && binderPlacement sourceSig == binderPlacement sig do
      throwError "Complete source/parent/solution BinderInfo differs"
  let telescope ← forallTelescope ci.type fun xs result => do
    unless xs.size == (← checked (cfg.getObjValAs? Nat "expectedTopLevelBinders")) do throwError "Input arity changed"
    let bs ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name",toJson d.userName.toString),("binderInfo",toJson (encodeBinder d.binderInfo)),
        ("type",toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders",Json.arr bs),("result",toJson (← ppExpr result).pretty),("topLevelBinderCount",toJson xs.size)]
  let installedText ← IO.FS.readFile (← checked (stringField cfg "installedSolution"))
  unless installedText == (← checked (stringField cfg "expectedSolutionText")) do throwError "Pinned solution source changed"
  let allowed ← checked (arrayField cfg "publicProofs")
  for row in allowed do
    let readback ← boundJson (← checked (field row "platformReadbackBinding"))
    unless (← checked (stringField readback "theorem_name")) == (← checked (stringField row "name")) &&
        (← checked (stringField readback "theorem_id")) == (← checked (stringField row "theoremId")) &&
        (← checked (stringField readback "status")) == "Proved" do
      throwError "Public dependency has no actual Proved platform readback"
  let mut queue := #[root]
  let mut doneNames : Array Name := #[]
  let mut importedRows : Array Json := #[]
  let mut ownRows : Array Json := #[]
  let mut referenced : Array Name := #[]
  let mut index := 0
  while index < queue.size do
    let n := queue[index]!
    index := index + 1
    unless doneNames.contains n do
      doneNames := doneNames.push n
      let info ← getConstInfo n
      let some proof := valueOf info | throwError "Missing own-module proof/value {n}"
      if proof.getUsedConstants.contains `sorryAx || info.type.getUsedConstants.contains `sorryAx then
        throwError "Direct sorryAx in own-module root/helper {n}"
      let proofUsed := proof.getUsedConstants
      let typeUsed := info.type.getUsedConstants
      ownRows := ownRows.push (Json.mkObj [("name",toJson n.toString),("nameExpr",encodeName n),
        ("proofDirectConstants",toJson (proofUsed.map Name.toString)),("typeDirectConstants",toJson (typeUsed.map Name.toString))])
      for dep in proofUsed ++ typeUsed do
        if dep == parentName then throwError "Parent occurs in its own proof reduction"
        unless referenced.contains dep do referenced := referenced.push dep
        if moduleOf env dep == some ownModule then
          unless queue.contains dep do queue := queue.push dep
        else if let some owner := moduleOf env dep then
          if owner.toString.startsWith "Theorems." then
            let some row := allowed.find? (fun x => (stringField x "name").toOption == some dep.toString)
              | throwError "Unclassified imported public proof {dep}"
            unless (← checked (stringField row "module")) == owner.toString do throwError "Imported theorem owner differs"
            let depAxioms ← collectAxioms dep
            for ax in depAxioms do
              unless standardAxioms.contains ax || ax == `sorryAx do throwError "Unexpected imported local axiom {dep}: {ax}"
            let localSorry := depAxioms.contains `sorryAx
            unless localSorry == (← checked (row.getObjValAs? Bool "expectedLocalCanonicalSorryAx")) do
              throwError "Pinned local canonical sorry classification changed: {dep}"
            let actualRow := Json.mkObj [("name",toJson dep.toString),("owner",toJson owner.toString),
              ("platformTheoremId",← checked (field row "theoremId")),("platformStatus",toJson "Proved"),
              ("platformReadbackBinding",← checked (field row "platformReadbackBinding")),
              ("actualLocalAxioms",toJson (depAxioms.map Name.toString)),("actualLocalHasSorryAx",toJson localSorry)]
            unless importedRows.contains actualRow do importedRows := importedRows.push actualRow
  for row in allowed do
    let publicName ← checked (decodeName (← checked (field row "nameExpr")))
    unless referenced.contains publicName do throwError "Classified public theorem is not actually consumed: {publicName}"
  let axs ← collectAxioms root
  for ax in axs do
    unless standardAxioms.contains ax || ax == `sorryAx do throwError "Unexpected local root axiom: {ax}"
  let taxs ← expressionAxioms ci.type
  ensureStandard "Cor23 solution TYPE only" taxs
  for m in env.header.moduleNames do
    if #[`Iut,`Genl,`AbcSourceReplay,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf m) then
      throwError "Source/production project import leaked into target audit: {m}"
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema",toJson "cor23-parent-type-dependency-audit/v69"),("configuration",cfg),
    ("sourceNameExpr",← checked (field r "nameExpr")),("sourceOwner",← checked (field r "module")),
    ("targetParent",toJson parentName.toString),("targetSolution",toJson root.toString),("telescope",telescope),
    ("sourceTypeExpr",← checked (field r "elaboratedExpr")),("parentTypeExpr",← checked (encodeExpr parent.type)),
    ("solutionTypeExpr",← checked (encodeExpr ci.type)),
    ("sourceClosedTYPEProofValues",Json.arr sourceProofs),("targetClosedTYPEProofValues",Json.arr ownTypeProofs),
    ("completeSourceParentTypeEqual",toJson true),("completeSourceSolutionTypeEqual",toJson true),
    ("completeParentSolutionTypeEqual",toJson true),("allFullBinderInventoryEqual",toJson true),
    ("allFullBinderPlacementEqual",toJson true),("sourceTheoremProofValueRead",toJson false),("parentValueRead",toJson false),
    ("ownModuleProofs",Json.arr ownRows),("importedPublicTheorems",Json.arr importedRows),
    ("allOwnModuleProofBodiesDirectSorryFree",toJson true),("parentProofReferenceAbsent",toJson true),
    ("allClassifiedPublicProofsActuallyConsumed",toJson true),("platformPublicProofsAllProved",toJson true),
    ("localAxiomClosure",toJson (axs.map Name.toString)),("typeAxioms",toJson (taxs.map Name.toString)),
    ("localSorryAxDoesNotNegateProvedPlatformStatus",toJson true),
    ("unconditionalABCClaimed",toJson false)]).pretty ++ "\n")
  logInfo "Cor23 source/parent/solution TYPE and BinderInfo equal; actual proof dependencies classified"
end FoundationAudit
