**English**

For the supplied height theory and input families, for every natural number $d$, every real $\varepsilon>0$ and every supplied subset parameter $K$, there exists a real $C$ such that

$$h_{\mathrm{can}}(x)\leq(1+\varepsilon)(\log\text{-}\mathrm{diff}(x)+\log\text{-}\mathrm{cond}(x))+C$$

for all $x$ in the supplied subset and degree restriction. The constant is uniform in $x$. If $d=0$, the domain is empty. Otherwise choose a height threshold large enough both for Corollary 2.2 and for its error term to be at most $\varepsilon$. The input Northcott law and the exceptional-set law make the union of points below that threshold and the original exceptional set finite. Outside this finite set, the proved Corollary 2.2 and the error estimate give the desired upper bound for the auxiliary height. The input bounded-discrepancy comparison transfers it to canonical height. Every real-valued difference is bounded above on the finite exceptional set, so its contribution is absorbed into one additive constant. Combine the two bounds. The arithmetic and geometric input families remain the original explicit assumptions.

**简体中文**

对于给定的高度理论和输入族，对每个自然数 $d$、每个正实数 $\varepsilon$ 及给定子集参数 $K$，存在实常数 $C$，使得所有满足子集及次数限制的 $x$ 都有

$$h_{\mathrm{can}}(x)\leq(1+\varepsilon)(\log\text{-}\mathrm{diff}(x)+\log\text{-}\mathrm{cond}(x))+C.$$

常数对 $x$ 一致。若 $d=0$，定义域为空。否则选取足够大的高度阈值，同时满足推论 2.2 的要求并使误差项至多为 $\varepsilon$。输入中的 Northcott 法律和例外集法律保证低于阈值的点与原例外集之并为有限集。在其补集上，已证明的推论 2.2 和误差估计给出辅助高度的所需上界，再由输入中的有界偏差比较转到典范高度。有限例外集上的实值差具有统一上界，可吸收到同一个加法常数中。合并两部分即得结论；原有算术和几何输入族仍保留为显式假设。

**日本語**

与えられた高さの理論と入力族に対し、任意の自然数 $d$、正の実数 $\varepsilon$ および部分集合のパラメータ $K$ について、実定数 $C$ が存在して、部分集合と次数の制限を満たすすべての $x$ に対して

$$h_{\mathrm{can}}(x)\leq(1+\varepsilon)(\log\text{-}\mathrm{diff}(x)+\log\text{-}\mathrm{cond}(x))+C$$

が成り立つ。定数は $x$ に依存しない。$d=0$ ならば定義域は空である。それ以外の場合、系2.2に必要な条件を満たし、誤差項が $\varepsilon$ 以下になるように高さの閾値を取る。入力の Northcott 法則と例外集合の法則によって、閾値以下の点と元の例外集合の和集合は有限となる。その外側では、既証明の系2.2と誤差の評価から補助的な高さの上界を得て、入力された有界差の比較によって標準的な高さへ移す。有限例外集合上の実数値の差には一様な上界があるため、一つの加法定数に吸収できる。二つの評価を合わせれば結論を得る。元の算術的・幾何学的入力族はすべて明示的な仮定として残る。
