#!/usr/bin/env python3
"""Archive and remove exactly the integrated v81 dependency proof drafts. No CI/API/Git."""
from pathlib import Path
import argparse,hashlib,io,json,math,tarfile,sys,re
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation/main-chain-open-20261116';CHAIN=W/'.local/adaptation/proved-source-chain-integration-v81-20261116';C=W/'.local/adaptation/cor23-canonical-v81-20261116'
VISIBILITY_MANIFEST_SHA256='7f52e790af9f4a58d4aaaf4a6ba0755acce7a055814e9624c161770bb4dba3d9'
VISIBILITY_FIXED_SHA256='9911f4b6c13556cb79d0ca079c1477cfd1abaedc16ea220d4d0ac65938686728'
PRIVATE_NAME_MANIFEST_SHA256='b85229ccebcccf12821761dc248ac90b2fa9ebd107ef4ebb392bc0682d2e1b73'
PRIVATE_NAME_FIXED_SHA256='4066ebd0114d425852b9ebc8e4135104e41697cb518b29295973e7b981b0dee4'
NAME='AbcAdaptation.Reference.Iut.statementII_of_cor312';STANDARD={'propext','Classical.choice','Quot.sound'}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def receipt(p):
 j=read(p);assert j['status']=='succeeded' and j['result']['exit_code']==0,p
 assert j['request']['workspace']==str(W) and j['request']['exclusive'] is True,p
 s=j['result']['snapshot'];assert s['workspace_mode']=='exclusive_worktree' and s['snapshot_id'] is None,p
 q=j['request']['parameters'];args=[q['source']] if 'source' in q else q['args'];assert j['result']['actual_arguments']==['lean',*args],p
 rr=j.get('resources',j['result'].get('resources',{}));assert rr.get('peak_rss_bytes') is not None and rr['peak_rss_bytes']<=16*1024**3,p
 if all(rr.get(k)is not None for k in ['cpu_time_seconds','cpu_user_seconds','cpu_system_seconds']):assert math.isclose(rr['cpu_time_seconds'],rr['cpu_user_seconds']+rr['cpu_system_seconds'],abs_tol=1e-6),p
 return j

def final_gate(require=False):
 paths=[A/'cor23-canonical-leaf-v81-result.json',A/'cor23-canonical-artifact-v81-result.json',A/'cor23-canonical-audit-v81-result.json',C/'actual/canonical-audit.json'];pending=[str(p)for p in paths if not p.exists()]
 if pending:
  if require:raise AssertionError(('Final standard-axiom gate is pending',pending))
  return {'passed':False,'pending':pending}
 rows=[receipt(p)for p in paths[:3]];j=read(paths[3]);canon=W/('Theorems/Thm_'+NAME.replace('.','_')+'.lean')
 assert j['completeSourceCanonicalTypeEqual'] and j['allFullBinderInventoryEqual'] and j['allFullBinderPlacementEqual'] and j['allOwnModuleProofBodiesDirectSorryFree'] and j['canonicalSelfReferenceAbsent']
 assert j['canonicalName']==NAME and len(j['ownModuleProofs'])==8
 assert set(j['localAxiomClosure'])<=STANDARD and 'sorryAx'not in j['localAxiomClosure']
 assert j['configuration']['expectedCanonicalText']==canon.read_text()
 assert all(x['expectedLocalCanonicalSorryAx'] is False for x in j['configuration']['publicProofs'])
 for r in rows[:2]:assert r['request']['worktree_manifest']['input_hashes'].get(str(canon))==sha(canon)
 audit=rows[2];out=audit['result']['stdout'];assert audit['result'].get('review',{}).get('passed') is True and 'sorryAx'not in out
 roots=[NAME,*read(CHAIN/'manifest.json')['topologicalOrder']]
 for root in roots:
  # Each queried theorem must have an actual named axiom print line, not only a configured name.
  printed=re.findall("'"+re.escape(root)+r"' depends on axioms:\s*\[([^\]]*)\]",out,re.S)
  assert len(printed)==1,(root,printed)
  actual=set(x.strip()for x in printed[0].split(',')if x.strip());assert actual<=STANDARD,(root,printed)
 return {'passed':True,'pending':[],'jobs':[r['job_id']for r in rows],'report':str(paths[3]),'reportSha256':sha(paths[3]),'rootCount':11,'receipts':[str(p)for p in paths[:3]]}

def private_name_replay(stage,visibility,files):
 assert stage['schema']=='prime-selection-private-name-ast-repair/v83'
 assert stage['inputCanonical']['sha256']==VISIBILITY_FIXED_SHA256 and stage['outputCanonical']['sha256']==PRIVATE_NAME_FIXED_SHA256
 assert stage['nameTokenCountChanged']==6 and all(stage[k]is True for k in ['onlyIdentifierTokenBytesChanged','helperDeclarationVisibilityRemainsPrivate','proofBytesOutsideListedNameTokensIdentical','helperOwnProofBodyByteIdentical','rootTYPEUnchanged','noProofDeletedOrReplaced','noHypothesisAdded'])
 assert sha(CHAIN/'manifest.json')==stage['originalSolutionToV79Manifest']['sha256']
 assert stage['v79ToV80VisibilityManifest']['sha256']==VISIBILITY_MANIFEST_SHA256
 astpath=Path(stage['sourceAST']['path']);coords=Path(stage['sourceCoordinates']['path']);assert sha(astpath)==stage['sourceAST']['sha256'];assert sha(coords)==stage['sourceCoordinates']['sha256'];files.update([astpath,coords])
 rows=[json.loads(x)for x in astpath.read_text().splitlines()];coordinate_bytes=coords.read_bytes()
 expected=[(1828,1846,2584,2602,'declaration-name'),(3218,3236,7966,7984,'reference-name'),(7467,7485,13009,13027,'reference-name'),(10278,10296,15792,15810,'reference-name'),(10424,10442,15910,15928,'reference-name'),(10936,10954,16394,16412,'reference-name')]
 edits=stage['changesFromVisibilityOnly'];assert len(edits)==len(expected)
 for e,(lo,hi,slo,shi,kind)in zip(edits,expected):
  assert(e['targetStart'],e['targetEnd'],e['sourceASTRange']['start']['offset'],e['sourceASTRange']['end']['offset'],e['kind'])==(lo,hi,slo,shi,kind)
  assert e['before']=='log_natCast_nonneg'and e['after']=='prime_selection_log_natCast_nonneg'
  assert visibility[lo:hi]==e['before'].encode()and coordinate_bytes[slo:shi]==e['before'].encode()
  refs=[r for r in rows if r.get('kind')=='ref'and r.get('start',{}).get('offset')==slo and r.get('end',{}).get('offset')==shi]
  assert len(refs)==1 and refs[0]['const']=='Iut.log_natCast_nonneg'
  if kind=='reference-name':assert e['sourceResolvedConstant']=='Iut.log_natCast_nonneg'
  # Exact name-token edits lie in the helper binding, term_nonneg body or root body only.
  assert (kind=='declaration-name'and 1814<=lo<hi<=1985)or(kind=='reference-name'and(3185<=lo<hi<=3239 or 4278<=lo<hi<=12779))
 out=visibility
 for e in reversed(edits):out=out[:e['targetStart']]+e['after'].encode()+out[e['targetEnd']:]
 assert hashlib.sha256(out).hexdigest()==PRIVATE_NAME_FIXED_SHA256
 return out

def chain_inventory(require=False):
 manifest=read(CHAIN/'manifest.json');assert len(manifest['nodes'])==10
 files=set();deletes=[];nodefacts=[];pending=[]
 for i,node in enumerate(manifest['nodes'],1):
  name=node['name'];assert name==manifest['topologicalOrder'][i-1]
  canon=Path(node['originalCanonicalStub']['path']);assert canon.parent==W/'Theorems'
  sol=Path(node['sourceSolution']['path']);assert sol.parent==W/'Solutions'
  transform=None;stage=None;label='v84'if i==8 else'v81';expected=node['draftCanonical']['sha256']
  if i==8:
   mp=CHAIN/'visibility-v82/transformation-manifest.json';assert sha(mp)==VISIBILITY_MANIFEST_SHA256;transform=read(mp);files.add(mp)
   sp=CHAIN/'private-name-v84/transformation-manifest.json';assert sha(sp)==PRIVATE_NAME_MANIFEST_SHA256;stage=read(sp);files.add(sp)
   assert transform['sourceSolution']['sha256']==node['sourceSolution']['sha256']and transform['previousCanonicalDraft']['sha256']==expected
   assert transform['fixedCanonicalDraft']['sha256']==VISIBILITY_FIXED_SHA256
   assert transform['onlyChangeFromV79']=={'utf8ByteStart':1814,'utf8ByteEnd':1814,'insert':'private ','line':50}
   assert transform['rootProofAndTypeByteIdenticalToV79']and transform['helperProofBodyByteIdentical']and transform['allOtherBytesUnchanged']and transform['noHelperDeleted']and transform['noHypothesisAdded']
   expected=PRIVATE_NAME_FIXED_SHA256
  assert sha(canon)==expected,('Current canonical is not integrated candidate',canon)
  assert node['platform']['status']=='Proved';assert node['privateProofPrefixByteIdentical']and node['rootProofBodyByteIdentical']and node['rootTypeTextIdenticalToExistingStub']
  if sol.exists():
   assert sha(sol)==node['sourceSolution']['sha256'];b=sol.read_bytes();needle=b'theorem solution';assert b.count(needle)==1
   rootonly=b.replace(needle,('theorem '+name).encode(),1)
   if transform:
    assert hashlib.sha256(rootonly).hexdigest()==node['draftCanonical']['sha256']
    assert b[1814:].startswith(b'lemma log_natCast_nonneg ')
    visibility=rootonly[:1814]+b'private '+rootonly[1814:];assert hashlib.sha256(visibility).hexdigest()==VISIBILITY_FIXED_SHA256
    replay=b
    assert transform['changesFromSourceSolution']==[{'kind':'private-visibility','utf8ByteStart':1814,'utf8ByteEnd':1814,'insert':'private ','originalLine':50,'declaration':'AbcAdaptation.Reference.Iut.log_natCast_nonneg'},{'kind':'root-binding','utf8ByteStart':3794,'utf8ByteEnd':3810,'before':'theorem solution','after':'theorem '+name}]
    for edit in sorted(transform['changesFromSourceSolution'],key=lambda x:x['utf8ByteStart'],reverse=True):
     lo,hi=edit['utf8ByteStart'],edit['utf8ByteEnd'];assert b[lo:hi]==edit.get('before','').encode();replay=replay[:lo]+edit.get('insert',edit.get('after','')).encode()+replay[hi:]
    assert replay==visibility and private_name_replay(stage,visibility,files)==canon.read_bytes()
   else:assert rootonly==canon.read_bytes(),name
   files.add(sol);deletes.append({'path':str(sol),'sha256':sha(sol),'role':'integrated accepted top-level proof draft','comparedCanonical':str(canon),'compiledCanonicalSHA256':sha(canon)})
  else:
   old=CHAIN/'archive-v81/manifest.json';assert old.exists()and any(x['path']==str(sol)and x['sha256']==node['sourceSolution']['sha256']for x in read(old)['deletedIntegratedProofDrafts']),sol
  files.add(canon)
  duplicate_pins=[('canonical',{'sha256':expected},'redundant integrated canonical draft'),('history',node['originalCanonicalStub'],'superseded canonical stub draft')]
  if transform:
   duplicate_pins.extend([('history/root-only-candidate',node['draftCanonical'],'superseded root-only canonical candidate'),('history/visibility-only-candidate',{'sha256':VISIBILITY_FIXED_SHA256},'superseded private-visibility-only canonical candidate'),('visibility-v82/Theorems',{'sha256':VISIBILITY_FIXED_SHA256},'redundant historical visibility-only proof draft'),('private-name-v84/Theorems',{'sha256':PRIVATE_NAME_FIXED_SHA256},'redundant integrated unique-private-name proof draft')])
   assert len(stage['failedAttempts'])==2
   for fail,(job,label0,pin)in zip(stage['failedAttempts'],[('ci-018101-23e491ac','v81',node['draftCanonical']['sha256']),('ci-018128-e69c8405','v82',VISIBILITY_FIXED_SHA256)]):
    failed=A/f'source-chain-08-leaf-{label0}-result.json';failure=read(failed);assert failure['job_id']==job==fail['jobId']and failure['status']=='failed'and failure['result']['exit_code']!=0
    assert failure['request']['worktree_manifest']['input_hashes'].get(str(canon))==pin
    assert sha(failed)==fail['originalReceipt']['sha256']==fail['preservedReceipt']['sha256'];assert 'log_natCast_nonneg'in json.dumps(failure['result'],ensure_ascii=False);files.add(failed)
    preserved=CHAIN/'private-name-v84/preserved'/failed.name;assert sha(preserved)==sha(failed);files.add(preserved)
  for rel,pin,role in duplicate_pins:
   p=CHAIN/rel/canon.name
   if transform and rel not in ['canonical','history']and not p.exists():
    archived=CHAIN/'archive-v81/manifest.json';assert archived.exists()and any(x['path']==str(p)and x['sha256']==pin['sha256']for x in read(archived)['deletedIntegratedProofDrafts']),('Historical/final duplicate candidate must be archived before cleanup',p)
   if p.exists():
    assert sha(p)==pin['sha256'];files.add(p);deletes.append({'path':str(p),'sha256':sha(p),'role':role,'comparedCanonical':str(canon),'compiledCanonicalSHA256':sha(canon)})
  for pin in node['platformReceiptPins']+node['priorAuditPins']:
   p=Path(pin['path']);assert sha(p)==pin['sha256'];files.add(p)
  rs=[]
  for kind in ['leaf','artifact']:
   p=A/f'source-chain-{i:02d}-{kind}-{label}-result.json'
   if not p.exists():pending.append(str(p));continue
   r=receipt(p);assert r['request']['worktree_manifest']['input_hashes'].get(str(canon))==sha(canon),p;files.add(p);rs.append({'kind':kind,'jobId':r['job_id'],'path':str(p),'sha256':sha(p),'resources':r.get('resources')})
  nodefacts.append({'name':name,'platform':node['platform'],'canonical':str(canon),'canonicalSha256':sha(canon),'sourceSolutionSha256':node['sourceSolution']['sha256'],'historicalRootOnlyEdit':node['onlyEdit'],'finalEdit':'root name, exact private visibility token, six AST-bound helper Name tokens'if stage else node['onlyEdit'],'visibilityRepair':{'visibilityManifest':str(CHAIN/'visibility-v82/transformation-manifest.json'),'visibilityManifestSHA256':VISIBILITY_MANIFEST_SHA256,'privateNameManifest':str(CHAIN/'private-name-v84/transformation-manifest.json'),'privateNameManifestSHA256':PRIVATE_NAME_MANIFEST_SHA256,'historicalRootOnlyCanonicalSHA256':node['draftCanonical']['sha256'],'historicalVisibilityOnlyCanonicalSHA256':VISIBILITY_FIXED_SHA256,'failedLeafJobs':['ci-018101-23e491ac','ci-018128-e69c8405'],'exactSourceASTNameTokenEdits':6,'rootTYPEAndAllProofBytesOutsideListedNameTokensPreserved':True,'helperOwnProofBodyByteIdentical':True,'finalCanonicalSHA256':expected}if stage else None,'finalReceiptLabel':label,'individualCanonicalReceipts':rs})
 for row in read(CHAIN/'numeric-helper-source-binding.json'):
  p=Path(row['receiptPath']);assert sha(p)==row['receiptSHA256'];r=receipt(p);assert r['job_id']==row['jobId'];node=next(n for n in manifest['nodes']if n['name']==row['name']);assert row['sourceSHA256']==node['sourceSolution']['sha256'];assert r['request']['worktree_manifest']['input_hashes'].get(node['sourceSolution']['path'])==row['sourceSHA256'];files.add(p)
 if require:assert not pending,('Missing individual canonical receipts',pending)
 return files,deletes,nodefacts,pending


def archive_write(out,files,report,deletes):
 out=out.resolve();assert out.is_relative_to(W/'.local/adaptation');out.mkdir(parents=True,exist_ok=True);archive=out/'evidence.tar.gz'
 if (out/'manifest.json').exists():
  prior=read(out/'manifest.json');assert sha(archive)==prior['sha256']
  with tarfile.open(archive,'r:gz')as tar:
   index=json.load(tar.extractfile('ARCHIVE_INDEX.json'))
   for row in index['files']:assert hashlib.sha256(tar.extractfile(row['archivePath']).read()).hexdigest()==row['sha256']
  return prior
 entries=[]
 for p in sorted(set(files)):
  p=p.resolve();assert p.is_relative_to(R);entries.append({'path':str(p),'archivePath':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size})
 report['files']=entries
 with tarfile.open(archive,'w:gz')as tar:
  for row in entries:tar.add(row['path'],arcname=row['archivePath'],recursive=False)
  b=json.dumps(report,ensure_ascii=False,indent=2).encode();info=tarfile.TarInfo('ARCHIVE_INDEX.json');info.size=len(b);tar.addfile(info,io.BytesIO(b))
 with tarfile.open(archive,'r:gz')as tar:
  for row in entries:assert hashlib.sha256(tar.extractfile(row['archivePath']).read()).hexdigest()==row['sha256']
  for row in deletes:
   p=Path(row['path']);assert sha(p)==row['sha256'];assert sha(row['comparedCanonical'])==row['compiledCanonicalSHA256'];assert hashlib.sha256(tar.extractfile(str(p.relative_to(R))).read()).hexdigest()==row['sha256']
 # All members and all removal checks finish before the first deletion.
 for row in deletes:Path(row['path']).unlink()
 m={'schema':'proved-source-chain-completed-archive/v81','archive':str(archive.relative_to(R)),'sha256':sha(archive),'bytes':archive.stat().st_size,'fileCount':len(entries),'allMemberSha256Verified':True,'deletedIntegratedProofDrafts':deletes,'nodes':report['nodes'],'finalStandardAxiomGate':report['finalStandardAxiomGate'],'historicalNumericGenericAuditDidNotPinActualSol':True,'numericActualPriorLeafArtifactBindingPreserved':True}
 save(out/'manifest.json',m);return m

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');ap.add_argument('--out',type=Path,default=CHAIN/'archive-v81');a=ap.parse_args()
 gate=final_gate(a.apply);files,deletes,nodes,pending=chain_inventory(a.apply)
 for root in [CHAIN]:
  for p in root.rglob('*'):
   if p.is_file() and not p.is_symlink() and p.suffix not in ['.olean','.ilean','.o','.c','.bc','.a','.so','.gz'] and not any(x.startswith('archive-')for x in p.relative_to(root).parts):files.add(p)
 for pattern in ['source-chain-*-v81-*.json','source-chain-08-*-v82-*.json','source-chain-08-*-v84-*.json']:
  for p in A.glob(pattern):files.add(p)
 for p in gate.get('receipts',[]):files.add(Path(p))
 if gate.get('report'):files.add(Path(gate['report']))
 report={'schema':'proved-source-chain-archive-plan/v81','nodes':nodes,'fileCount':len(files),'inputBytes':sum(p.stat().st_size for p in files),'deleteAfterVerifiedArchive':deletes,'pendingIndividualCanonicalReceipts':pending,'finalStandardAxiomGate':gate,'noOriginalReferenceOrSourceReplayDeleted':True,'queriesAndConfigsRetained':True,'canonicalC22Connected':False,'S2-04Completed':False}
 save(D/'chain-dry-run.json',report)
 if a.apply:print(json.dumps(archive_write(a.out,files,report,deletes),ensure_ascii=False,indent=2))
 else:print(json.dumps({k:report[k]for k in ['fileCount','inputBytes','pendingIndividualCanonicalReceipts','finalStandardAxiomGate']},ensure_ascii=False))
if __name__=='__main__':main()
