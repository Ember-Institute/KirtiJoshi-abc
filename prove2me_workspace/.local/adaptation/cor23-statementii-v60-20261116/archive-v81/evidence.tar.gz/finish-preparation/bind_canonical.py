#!/usr/bin/env python3
"""Bind root's final canonical CI receipts. Never runs Lean/API/Git."""
from pathlib import Path
import argparse,json,hashlib,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def receipt(p):
 p=Path(p).resolve();j=read(p);assert j['status']=='succeeded'and j['result']['exit_code']==0
 assert j['request']['workspace']==str(W)and j['request']['exclusive']is True
 ss=j['result']['snapshot'];assert ss['workspace_mode']=='exclusive_worktree'and ss['snapshot_id']is None
 return {'path':str(p),'sha256':sha(p),'contents':j}
ap=argparse.ArgumentParser();ap.add_argument('--leaf-receipt',type=Path,required=True);ap.add_argument('--artifact-receipt',type=Path,required=True);ap.add_argument('--out',type=Path,default=D/'bound/canonical.final.json');a=ap.parse_args()
c=read(D/'configs/canonical.template.json');src=Path(c['installedCanonical']);assert src.read_text()==c['expectedCanonicalText']
for key,p in [('canonicalLeafReceipt',a.leaf_receipt),('canonicalArtifactReceipt',a.artifact_receipt)]:
 b=receipt(p);assert b['contents']['request']['worktree_manifest']['input_hashes'].get(str(src))==sha(src);c[key]=b
old=c['previousSourceParentSolutionAudit'];assert sha(old['path'])==old['sha256'];j=read(old['path']);assert j['completeSourceSolutionTypeEqual']and j['allFullBinderPlacementEqual']and j['allOwnModuleProofBodiesDirectSorryFree']
out=a.out.resolve();assert out.is_relative_to(D);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');print(out,sha(out))
