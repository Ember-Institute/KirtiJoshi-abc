#!/usr/bin/env python3
"""Prepare or apply final Cor23 registration only after real v81 acceptance. No CI/API/Git."""
from pathlib import Path
import argparse,copy,difflib,hashlib,json,sys,tarfile
sys.dont_write_bytecode=True
from archive_chain import D,R,W,A,CHAIN,C,NAME,sha,read,save,receipt,final_gate,chain_inventory
S=W/'.local/adaptation/cor23-statementii-v60-20261116';P=W/'.local/adaptation/cor23-source-replay-v68-20261116';T=W/'.local/adaptation/cor23-audits-v74-20261116'
REG=W/'.local/adaptation/platform-node-registry.json';PLAN=R/'docs/开发计划.Prove2Me适配.md';STATUS=R/'docs/Prove2Me适配状态.md';LEDGER=S/'SOURCE_LEDGER.json'
CANON=W/('Theorems/Thm_'+NAME.replace('.','_')+'.lean');THEOREM_ID='d0dc484c-0de7-4e50-b751-e39e46fb5bd2';SUBMISSION='edc57f66-28c1-4f08-8aa3-448430b9ea85'
def rel(p):return str(Path(p).relative_to(R))
def compact_json(j):return json.dumps(j,ensure_ascii=False,indent=2)+'\n'
def verify_archive(path):
 m=read(path);arc=R/m['archive'];assert sha(arc)==m['sha256'] and m['allMemberSha256Verified'] is True
 with tarfile.open(arc,'r:gz')as tar:
  index=json.load(tar.extractfile('ARCHIVE_INDEX.json'))
  for x in index['files']:assert hashlib.sha256(tar.extractfile(x['archivePath']).read()).hexdigest()==x['sha256']
 return m

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');ap.add_argument('--compactly-bounded-zh',help='Use only a Chinese term explicitly confirmed by the user');args=ap.parse_args()
 gate=final_gate(args.apply);archives=[S/'archive-v81/manifest.json',CHAIN/'archive-v81/manifest.json'];pending=[str(p)for p in archives if not p.exists()]
 if not gate['passed']or pending:
  if args.apply:raise AssertionError(('Complete final standard gate and verified archives before registration',gate,pending))
  j={'schema':'cor23-registration-pending/v81','finalGate':gate,'pendingVerifiedArchives':pending,'mainWorkspaceModified':False};save(D/'registration-pending.json',j);print(compact_json(j));return
 _,_,nodes,missing=chain_inventory(True);assert not missing
 cm,dm=[verify_archive(p)for p in archives]
 assert cm['canonicalSha256']==sha(CANON) and cm['finalCanonicalStandardClosureAccepted'] is True
 assert dm['finalStandardAxiomGate']['passed'] is True
 accepted=read(S/'platform/verify-result.json');item=read(S/'platform/theorem-proved.json');assert accepted['status']=='ACCEPTED'and accepted['id']==SUBMISSION and item['theorem_id']==THEOREM_ID and item['theorem_name']==NAME and item['status']=='Proved'and item['visibility']=='private'
 report=read(C/'actual/canonical-audit.json');proof=read(S/'final-proof-byte-identity-v74.json');assert proof['allSourceProofBodiesPresentExactlyOnce'];assert sorted(x['bytes']for x in proof['proofBodies'])==[142,2556]
 receipts=[]
 for stem in ['cor23-source-replay-leaf-v68','cor23-source-replay-artifact-v68','cor23-source-type-v70','cor23-stub-leaf-v70','cor23-stub-artifact-v70','cor23-solution-leaf-v71','cor23-solution-artifact-v71','cor23-open-type-audit-v74','cor23-proof-audit-v74','cor23-canonical-leaf-v81','cor23-canonical-artifact-v81','cor23-canonical-audit-v81']:
  path=A/(stem+'-result.json');j=receipt(path);rr=j.get('resources',j['result'].get('resources',{}));receipts.append({'jobId':j['job_id'],'receipt':rel(path),'receiptSha256':sha(path),'phase':stem,'resources':{k:rr.get(k)for k in ['wall_time_seconds','cpu_time_seconds','cpu_user_seconds','cpu_system_seconds','peak_rss_bytes','peak_pss_bytes','source','degraded']}})
 hist=D/'history-v78/cor23-canonical-audit-v78-result.json'
 negative={'jobId':'ci-018039-b996e6e5','status':'failed','meaning':'Source TYPE equality passed; explicit final axiom review exposed transitive sorryAx in the historical local c2 stub. This was not final canonical acceptance.','finalAccepted':False,'preservedInVerifiedCor23Archive':True}
 if hist.exists():negative.update({'receiptSha256':sha(hist)})
 unit={'schema':'cor23-statementii-source-proof-delivery/v81','sourceName':'Iut.statementII_of_cor312','targetName':NAME,'theoremId':THEOREM_ID,'status':'Proved','visibility':'private','verificationStatus':'ACCEPTED','acceptedSubmissionId':SUBMISSION,'root_graph_membership':False,'sourceUnit':rel(S),'canonical':rel(CANON),'canonicalSha256':sha(CANON),'sourceProjectTYPEMapCount':11,'sourceUniverses':4,'topLevelBinders':9,'fullSourceTYPEAndBinderInfoEqual':True,'actualOwnModuleProofs':8,'privateSourceHelpers':7,'sourceProofRangesBytes':[142,2556],'sourceProofBodiesByteIdentical':True,'sourceTheoremProofValueReadByTYPEExporter':False,'publicDependencies':[{'name':x['name'],'theoremId':x['platformTheoremId'],'platformStatus':x['platformStatus'],'finalLocalHasSorryAx':x['actualLocalHasSorryAx']}for x in report['importedPublicTheorems']],'historicalLocalC2StubHadSorryAx':True,'historicalV78AxiomReview':negative,'finalLocalC2HasSorryAx':False,'finalCanonicalStandardClosureAccepted':True,'actualFinalAxioms':report['localAxiomClosure'],'finalElevenRootStandardAxiomGate':gate,'archive':cm['archive'],'archiveSha256':cm['sha256'],'integratedDependencyArchive':dm['archive'],'integratedDependencyArchiveSha256':dm['sha256'],'jobs':[x['jobId']for x in receipts],'receipts':receipts,'readbackModel':'gpt-6.1-sol','chineseTermPending':None if args.compactly_bounded_zh else 'compactly bounded subset','canonicalC22Connected':False,'S2-04Completed':False,'concreteArithmeticIdentityOrInitialDataExistenceProved':False,'unconditionalABCClaimed':False}
 reg=read(REG);old=copy.deepcopy(reg);prep=reg['reference_source_preparation'];prep['cor23_statementII_full_source_proof_unit']=unit
 node={'name':NAME,'theorem_id':THEOREM_ID,'status':'Proved','submission_id':SUBMISSION,'verification_status':'ACCEPTED','visibility':'private','source':'refer/iut/Iut/Implication/Corollary23.lean','source_commit':'07cb1da58f6d428a670dbb5dd6093d428bcbcdd8','root_graph_membership':False}
 prior=[x for x in prep['proved_nodes']if x['name']==NAME]
 if prior:assert all(x['theorem_id']==THEOREM_ID for x in prior)
 else:prep['proved_nodes'].append(node)
 for edge in prep['dependency_pairs']:
  if edge.get('consumer')=='Iut.statementII_of_cor312':
   edge.update({'consumer':NAME,'originalSourceConsumer':'Iut.statementII_of_cor312','consumerTheoremId':THEOREM_ID,'consumerIsOriginalSourceName':False,'consumerTargetNotYetPublished':False,'targetParentReductionPending':False,'verifiedConsumerSubmissionId':SUBMISSION})
 if not any(x.get('producer')=='AbcAdaptation.Reference.Iut.epsilonE_le'and x.get('consumer')==NAME for x in prep['dependency_pairs']):prep['dependency_pairs'].append({'producer':'AbcAdaptation.Reference.Iut.epsilonE_le','consumer':NAME,'actualSourceValueEdge':True,'consumerTheoremId':THEOREM_ID,'verifiedConsumerSubmissionId':SUBMISSION,'targetParentReductionPending':False})
 prep['statementii_definition_unit'].update({'actualSourceConsumer':NAME,'originalSourceConsumer':'Iut.statementII_of_cor312','targetConsumerPending':False,'consumerTheoremId':THEOREM_ID})
 prep['proved_source_chain_canonical_integration_v81']={'schema':'proved-chain-canonical-delivery/v81','nodes':nodes,'finalStandardAxiomGate':gate,'archive':dm['archive'],'archiveSha256':dm['sha256'],'historicalLocalC2StubHadSorryAx':True,'finalLocalC2HasSorryAx':False,'canonicalC22Connected':False,'S2-04Completed':False,'root_graph_membership':False,'numericActualHistoricalLeafArtifactSHABindingPreserved':True,'visibilityRepair':{'node':'AbcAdaptation.Reference.Iut.LocalHeightData.exists_prime_selection','failedLeafJobs':['ci-018101-23e491ac','ci-018128-e69c8405'],'failedLeafReason':'public helper name collision; private visibility alone could not shadow the imported public name','finalReceiptLabel':'v84','exactPrivateTokenInsertionAndSixSourceASTNameTokenEdits':True,'sourceTYPEAndProofBytesOutsideListedNameTokensPreserved':True,'helperOwnProofBodyByteIdentical':True,'historicalRootOnlyAndVisibilityOnlyCandidatesAndBothFailuresArchived':True},'historicalGenericAuditMissingSolHashPreservedAsNegativeEvidence':True}
 # Integration changes local code, not already accepted platform proof state or root graph counts.
 assert reg['graph_counts']==old['graph_counts']and reg['edges']==old['edges']and reg['open_frontier']==old['open_frontier']and reg['mathematical_root_proved']==old['mathematical_root_proved']
 assert prep['canonicalC22Connected']is False
 ledger={'schema':'cor23-source-ledger/v81','sourceCommit':'07cb1da58f6d428a670dbb5dd6093d428bcbcdd8','sourceModule':'refer/iut/Iut/Implication/Corollary23.lean','sourceTheorem':'Iut.statementII_of_cor312','canonicalTheorem':NAME,'platformTheoremId':THEOREM_ID,'acceptedSubmissionId':SUBMISSION,'proofBodyFaithfulness':proof,'privateSourceHelperMap':read(S/'private-source-map.json'),'canonicalIntegration':unit,'dependencyCanonicalIntegration':prep['proved_source_chain_canonical_integration_v81'],'sourceConsumers':[{'producer':'AbcAdaptation.Reference.Iut.Corollary22Inputs.c2','consumer':NAME,'kind':'actual proof-value dependency'},{'producer':'AbcAdaptation.Reference.Iut.epsilonE_le','consumer':NAME,'kind':'actual proof-value dependency'},{'producer':'AbcAdaptation.Reference.Genl.HeightTheory.StatementII','consumer':NAME,'kind':'conclusion TYPE'}],'mathematicalScope':'Generic conditional arithmetic inequality only. Actual point fields, heights, different ideals, conductors and common-source initial-data existence remain open.','historicalFailedReview':negative}
 proposed={LEDGER:compact_json(ledger)}
 # Keep only real pending readback terminology in the status document.
 status=STATUS.read_text();line=f'- `{NAME}`：`compactly bounded subset`（待定：紧有界子集／紧致有界子集）。'
 if args.compactly_bounded_zh:
  status='\n'.join(x for x in status.splitlines()if not(x.startswith('- `'+NAME+'`')and 'compactly bounded subset'in x))+'\n'
 elif line not in status:
  assert '## 4. 未完成自然语言读回的证明义务'in status;status=status.rstrip()+'\n'+line+'\n'
 proposed[STATUS]=status
 plan=PLAN.read_text();anchor='- [x] 单独迁移一般高度理论的 `StatementII` 纯定义，完整类型、定义值、十项实际数据映射和绑定信息均由内核核对；私有定义已发布并逐字段回读，独立三语读回保留中文待定术语，定义本身不作为陈述二的证明。'
 extra='- [x] 完成 `statementII_of_cor312` 的完整条件性来源证明迁移和私有完整验收；十一项实际类型映射、四个宇宙、九个参数及完整绑定信息由内核核对，两段来源证明正文保持字节一致，实际消费已证明的参考推论 2.2 和误差项界，具体算术身份及初始数据存在性仍开放。\n- [x] 将上述消费者所需十项已验收辅助及组合证明整合到具名规范模块；分别完成叶检查和产物回执，最终十一根显式公理输出仅含标准公理，修复历史本地推论 2.2 桩的传递 `sorryAx`，保留旧失败证据；已集成证明草稿经归档逐项校验后清除。'
 if extra not in plan:assert anchor in plan;plan=plan.replace(anchor,anchor+'\n'+extra,1)
 assert '- [ ] 以实际点域、高度、不同理想、导子及完整初始数据存在性身份，将参考 `c2` 接回规范高度估计节点。'in plan
 proposed[PLAN]=plan
 for p in [CANON,*[Path(n['canonical'])for n in nodes],LEDGER,*archives,R/cm['archive'],R/dm['archive']]:
  reg['files'][rel(p)]=hashlib.sha256(proposed[p].encode()).hexdigest()if p in proposed else sha(p)
 proposed[REG]=compact_json(reg)
 out=D/'registration-proposed';out.mkdir(exist_ok=True);diff=[];inputs=[]
 for p,text in proposed.items():
  oldtext=p.read_text()if p.exists()else'';dest=out/p.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text);diff.extend(difflib.unified_diff(oldtext.splitlines(True),text.splitlines(True),fromfile=str(p),tofile=str(p)));inputs.append({'path':str(p),'beforeSha256':sha(p)if p.exists()else None,'afterSha256':hashlib.sha256(text.encode()).hexdigest(),'proposed':str(dest)})
 (D/'registration.patch').write_text(''.join(diff));save(D/'registration-plan.json',{'schema':'cor23-final-registration-plan/v81','finalGate':gate,'writes':inputs,'rootGraphCountsUnchanged':True,'canonicalC22Connected':False,'S2-04Completed':False,'mainWorkspaceModified':args.apply})
 if args.apply:
  for row in inputs:
   p=Path(row['path']);assert(sha(p)if p.exists()else None)==row['beforeSha256']
  for p,text in proposed.items():p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 print(compact_json({'apply':args.apply,'writeCount':len(inputs),'patch':str(D/'registration.patch'),'finalGateJobs':gate['jobs'],'canonicalC22Connected':False,'S2-04Completed':False}))
if __name__=='__main__':main()
