# Cor23 与十项来源链：最终登记／归档入口（v81）

仅供主智能体使用。默认执行只读检查，在本 /tmp 目录写 dry-run 或候选补丁；不编译、不调用 API、不操作 Git。`--apply` 才会写工程。

## 前置验收

主智能体完成十项已证明依赖逐一独占叶检查和产物生成（节点08最终使用v84，其余使用v81），再完成 Cor23 规范模块叶检查、产物生成、十一根显式 `#print axioms` 的实际 review。归档和登记脚本必须等到全部实际成功回执落盘。

脚本核验：精确 workspace、exclusive_worktree、snapshot_id=null、实际 Lean 参数、退出码、物理 RSS≤16 GiB、CPU 分项与总量；每个 canonical 的成功回执输入哈希匹配当前文件；实际最终完整类型与绑定信息、八项自有证明、公共依赖 local sorryAx=false、真实审查 passed=true，十一根公理输出只有标准公理。v78 的传递 sorryAx 失败完整保留，不能按成功计数。

## 推荐执行顺序

```sh
python3 /tmp/p2m-cor23-finish-v77-20261116/archive_chain.py
python3 /tmp/p2m-cor23-finish-v77-20261116/archive_chain.py --apply
python3 /tmp/p2m-cor23-finish-v77-20261116/archive_cor23.py
python3 /tmp/p2m-cor23-finish-v77-20261116/archive_cor23.py --apply
python3 /tmp/p2m-cor23-finish-v77-20261116/finish_registration.py
```

最后一个 dry-run 在真实门禁和两个已校验归档具备后生成本目录 `registration.patch`、`registration-proposed/`、`registration-plan.json`。主智能体审阅后：

```sh
python3 /tmp/p2m-cor23-finish-v77-20261116/finish_registration.py --apply
```

Cor23 推荐使用默认 v81 的四个路径，不传 `--extra-dir`：链证据独立归档，Cor23 归档自动包含全部 source-chain v81 以及节点08 v82、v84 请求／回执和链 manifest、数值历史精确哈希证据、负面证据及链归档 manifest。这样不会再次打包整个链 tar。

## 精确清理白名单

链归档的基础白名单为 30 份：manifest 十个已证明节点对应的顶层 `Solutions/Sol_*.lean`，加链 A81 内 `canonical/Thm_*.lean` 十份、`history/Thm_*.lean` 十份。每个 Sol 必须匹配 manifest 所记已接受来源 SHA。除节点08外，只把 `theorem solution` 改为实际名字后逐字节等于当前已编译 canonical。节点08因上游规范证明现已公开同名辅助引理，原v81叶检查（ci-018101-23e491ac）报重名；最终只按固定SHA的变换清单，在源字节1814插入 `private ` 并执行原根名更换。脚本逐字节重放这两段修改，原根类型和全部证明正文不允许变化。private 可见性单独修补也被 Lean 拒绝（ci-018128-e69c8405），因此最终再按固定 SHA 的 Stage2 来源语法树清单，将六个精确 Name token（helper 声明名、term_nonneg 一处引用、root 四处引用）统一改为唯一私有名。脚本同时核验原始语法树、坐标源码 SHA、每个来源常量解析及目标 UTF-8 范围；helper 自身证明正文、根类型和六个 Name token 之外的全部证明字节保持一致。08 最终成功回执使用 v84，两次失败与候选均归档。每个重复 canonical 和旧桩分别核验 manifest 的精确 SHA。删除前重新核验当前 compiled canonical SHA。另将节点08的 `history/root-only-candidate/` 原根名候选、`history/visibility-only-candidate/` 可见性修补候选、`visibility-v82/Theorems/` 可见性重复稿以及 `private-name-v84/Theorems/` 最终唯一私有名重复稿纳入精确白名单。本次链白名单34份，Cor23另3份，共37份。两份变换清单、两次失败回执、来源语法树、坐标源码、查询和配置继续保留。

Cor23 归档只删 3 份：顶层 `Solutions/Sol_AbcAdaptation_Reference_Iut_statementII_of_cor312.lean`、S60 的 `solution/` 同名稿和 `stub/Thm_AbcAdaptation_Reference_Iut_statementII_of_cor312.lean`。三份分别由实际历史成功 solution/stub 叶回执绑定精确 SHA；当前 canonical 必须与接受候选（仅根定理名更换）逐字节一致。旧桩的完整类型／绑定信息关系已由原始 source/parent/solution 内核审查证明，历史依赖 sorryAx 标记不修改。

两套归档均先关闭 tar，再逐一重读全部 tar 成员并核验 SHA；所有白名单的当前 SHA、canonical SHA、tar 内 SHA 全部验证完成后才开始删除。再次 apply 已存在的归档会校验并返回既有归档，不重写归档丢失已清理源稿。

不删规范 Theorems、原始参考文本、source replay、原始 source、actual-parser-output、查询、配置、回执和其他单元草稿。S60 的 `definition/` 是纯定义稿，不在本轮“已集成证明草稿”白名单；如另有定义清理任务，由主智能体另行明确处理。

## 登记范围

登记脚本写四个文件：本单元 S60/SOURCE_LEDGER.json、platform-node-registry.json、docs/开发计划.Prove2Me适配.md、docs/Prove2Me适配状态.md。状态文档仅新增 Cor23 未定的 `compactly bounded subset` 中文术语；若用户已核定译名，先更新实际读回，再用 `--compactly-bounded-zh <用户核定译名>` 避免新增此条。

根图计数、根边与开放前沿保持一致；canonicalC22Connected=false、S2-04Completed=false。参考条件性陈述二的证明不代表实际点域、高度、不同理想、导子和完整初始数据存在性已经构造，也不代表 Joshi 的 3.12 适配完成。
