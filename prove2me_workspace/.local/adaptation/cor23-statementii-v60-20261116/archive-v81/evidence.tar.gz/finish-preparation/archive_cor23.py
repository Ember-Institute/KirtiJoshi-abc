#!/usr/bin/env python3
"""Root-only archival entry. Default is read-only dry-run. No compiler/API/Git calls."""
from pathlib import Path
import argparse,json,hashlib,tarfile,io,math,sys,shutil
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation/main-chain-open-20261116'
S=W/'.local/adaptation/cor23-statementii-v60-20261116';P=W/'.local/adaptation/cor23-source-replay-v68-20261116';T=W/'.local/adaptation/cor23-audits-v74-20261116'
C=W/'.local/adaptation/cor23-canonical-v78-20261116'
C79=W/'.local/adaptation/cor23-canonical-v79-20261116'
C81=W/'.local/adaptation/cor23-canonical-v81-20261116'
from archive_chain import final_gate,CHAIN
NAME='AbcAdaptation.Reference.Iut.statementII_of_cor312';STEM=NAME.replace('.','_');CANON=W/('Theorems/Thm_'+STEM+'.lean');SOLUTION=W/('Solutions/Sol_'+STEM+'.lean');CANDIDATE=D/'canonical'/CANON.name
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
def save(p,j):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def check_receipt(p):
 p=Path(p).resolve();j=read(p);assert j['status']=='succeeded'and j['result']['exit_code']==0,p
 assert j['request']['workspace']==str(W)and j['request']['exclusive']is True,p
 snap=j['result']['snapshot'];assert snap['workspace_mode']=='exclusive_worktree'and snap['snapshot_id']is None,p
 src=j['request']['parameters'].get('source')or j['request']['parameters']['args'][0]
 assert j['result']['actual_arguments']==['lean',*([src]if'source'in j['request']['parameters']else j['request']['parameters']['args'])],p
 res=j.get('resources',j['result'].get('resources',{}));rss=res.get('peak_rss_bytes');assert rss is not None and rss<=16*1024**3,p
 if all(res.get(k)is not None for k in ['cpu_time_seconds','cpu_user_seconds','cpu_system_seconds']):assert math.isclose(res['cpu_time_seconds'],res['cpu_user_seconds']+res['cpu_system_seconds'],abs_tol=1e-6),p
 return j

def inspect_core():
 platform=read(S/'platform/verify-result.json');assert platform['status']=='ACCEPTED'and platform['id']=='edc57f66-28c1-4f08-8aa3-448430b9ea85';assert platform['theorem_id']=='d0dc484c-0de7-4e50-b751-e39e46fb5bd2'
 item=read(S/'platform/theorem-proved.json');assert item['theorem_name']==NAME and item['theorem_id']==platform['theorem_id']and item['status']=='Proved'and item['visibility']=='private'
 assert isinstance(read(S/'platform/decompositions.json')['decompositions'],list)
 oldAudit=read(T/'actual/reduction-type-dependency-audit.json');assert oldAudit['completeSourceSolutionTypeEqual']and oldAudit['completeSourceParentTypeEqual']and oldAudit['completeParentSolutionTypeEqual'];assert oldAudit['allFullBinderInventoryEqual']and oldAudit['allFullBinderPlacementEqual'];assert oldAudit['allOwnModuleProofBodiesDirectSorryFree']and oldAudit['parentProofReferenceAbsent'];assert not oldAudit['sourceTheoremProofValueRead']and not oldAudit['parentValueRead'];assert len(oldAudit['ownModuleProofs'])==8
 public={r['platformTheoremId']:r for r in oldAudit['importedPublicTheorems']};assert set(public)=={'8d766b69-9c89-44f7-9aaf-26f075f5bdf4','86697611-90eb-4197-bf85-9586928917f8'}
 for key,row in public.items():
  assert row['platformStatus']=='Proved';assert row['actualLocalHasSorryAx']==(key=='8d766b69-9c89-44f7-9aaf-26f075f5bdf4')
 assert 'sorryAx'in oldAudit['localAxiomClosure'];assert set(oldAudit['typeAxioms'])<={'propext','Classical.choice','Quot.sound'}
 f=read(P/'actual/source-type.json');r,=f['records'];assert r['name']=='Iut.statementII_of_cor312'and r['module']=='AbcSourceReplay.Cor23StatementII';assert len(r['levelParams'])==4 and f['closedTypeProofValues']==[] and f['rootTheoremProofsRead']is False
 proof=read(S/'final-proof-byte-identity-v74.json');assert proof['allSourceProofBodiesPresentExactlyOnce'];m=read(P/'accepted-ast-replay-map.json');coord=Path(m['source']['normalizedPath']).read_bytes();target=(SOLUTION if SOLUTION.exists()else CANDIDATE).read_bytes()
 for row in proof['proofBodies']:
  rg=row['sourceRange'];b=coord[rg['start']['offset']:rg['end']['offset']];assert hashlib.sha256(b).hexdigest()==row['sha256'];assert target.count(b)==1
 assert sorted(x['bytes']for x in proof['proofBodies'])==[142,2556]
 payload=read(S/'publication/payload.json');before=read(S/'publication/published-item.json')
 for key in ['theorem_name','theorem_title','preamble','formal_statement','natural_language_statement','source']:assert before[key]==payload[key]
 rb=read(S/'readbacks/independent-v70/manifest.json');assert rb['reader_model']=='gpt-6.1-sol';paper=read(S/'paper/context-verified-v73.json');assert sha(paper['visualEvidence']['path'])==paper['visualEvidence']['sha256'];assert paper['verifiedQuote']in payload['natural_language_statement']
 receipts=[]
 for prefix in ['cor23-source-replay-leaf-v68','cor23-source-replay-artifact-v68','cor23-source-type-v70','cor23-stub-leaf-v70','cor23-stub-artifact-v70','cor23-solution-leaf-v71','cor23-solution-artifact-v71','cor23-open-type-audit-v74','cor23-proof-audit-v74']:
  p=A/(prefix+'-result.json');j=check_receipt(p);receipts.append({'path':str(p),'jobId':j['job_id'],'resources':j['resources']})
 return platform,item,oldAudit,receipts

ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');ap.add_argument('--out',type=Path,default=S/'archive-v81');ap.add_argument('--canonical-leaf',type=Path,default=A/'cor23-canonical-leaf-v81-result.json');ap.add_argument('--canonical-artifact',type=Path,default=A/'cor23-canonical-artifact-v81-result.json');ap.add_argument('--canonical-audit-receipt',type=Path,default=A/'cor23-canonical-audit-v81-result.json');ap.add_argument('--canonical-audit-report',type=Path,default=C81/'actual/canonical-audit.json');ap.add_argument('--canonical-axioms-receipt',type=Path,help='Optional separate explicit axiom receipt; by default use canonical audit receipt with appended #print axioms');ap.add_argument('--keep-top-level-solution',action='store_true');ap.add_argument('--extra-dir',type=Path,action='append',default=[],help='Additional explicit dependency-integration evidence directory under W/.local/adaptation');ap.add_argument('--final-local-closure',choices=['standard'],default='standard',help='Final canonical gate requires actual standard-only closure after dependency integration');a=ap.parse_args()
platform,item,oldAudit,receipts=inspect_core();final=[];pending=[];chainGate=final_gate(a.apply)
if a.canonical_axioms_receipt is None:a.canonical_axioms_receipt=a.canonical_audit_receipt
for key in ['canonical_leaf','canonical_artifact','canonical_audit_receipt','canonical_audit_report','canonical_axioms_receipt']:
 p=getattr(a,key)
 if p is None or not p.exists():pending.append(key)
 else:
  if key.endswith('report'):j=read(p);assert j['completeSourceCanonicalTypeEqual']and j['allFullBinderInventoryEqual']and j['allFullBinderPlacementEqual']and j['allOwnModuleProofBodiesDirectSorryFree']and j['canonicalSelfReferenceAbsent'];assert j['canonicalName']==NAME;assert 'sorryAx'not in j['localAxiomClosure']and set(j['localAxiomClosure'])<={'propext','Classical.choice','Quot.sound'};assert len(j['ownModuleProofs'])==8;assert j['configuration']['expectedCanonicalText']==CANDIDATE.read_text();assert all(row['expectedLocalCanonicalSorryAx']is False for row in j['configuration']['publicProofs'])
  else:
   j=check_receipt(p)
   if key=='canonical_axioms_receipt':
    out=j['result']['stdout'];assert NAME in out and 'sorryAx'not in out;assert all(x in out for x in ['propext','Classical.choice','Quot.sound']);assert j['result'].get('review',{}).get('passed')is True, 'Final explicit axioms review must really pass after dependency integration';
    # The scheduler's generic no_sorry flag is not used as evidence; explicit actual output
    # and the dependency-specific canonical report preserve the historical tracked sorryAx distinction.
   if key in ['canonical_leaf','canonical_artifact']:assert j['request']['worktree_manifest']['input_hashes'].get(str(CANON))==sha(CANON)
  final.append(Path(p).resolve())
if a.apply:assert not pending,('Final canonical receipts are required before archiving and cleaning',pending);assert CANON.read_bytes()==CANDIDATE.read_bytes(),'Canonical integration differs from accepted candidate'
files=[]
for root in [S,P,T,C,C79,C81,*a.extra_dir]:
 if not root.exists():continue
 assert root.resolve().is_relative_to(W/'.local/adaptation'),'Additional evidence must stay in explicit adaptation dirs'
 for p in root.rglob('*'):
  if p.is_file()and not p.is_symlink()and p.suffix not in ['.olean','.ilean','.o','.c','.bc','.a','.so']and '__pycache__'not in p.parts and a.out not in p.parents and not any(x.startswith('archive-')for x in p.relative_to(root).parts):files.append(p)
for p in A.glob('cor23-*.json'):files.append(p)
for pattern in ['source-chain-*-v81-*.json','source-chain-08-*-v82-*.json','source-chain-08-*-v84-*.json']:
 for p in A.glob(pattern):files.append(p)
for p in [CHAIN/'manifest.json',CHAIN/'historical-receipt-source-binding.json',CHAIN/'numeric-helper-source-binding.json',CHAIN/'recursive-source-closure.json',CHAIN/'visibility-v82/transformation-manifest.json',CHAIN/'private-name-v84/transformation-manifest.json',CHAIN/'archive-v81/manifest.json']:
 if p.exists():files.append(p)
for p in [CANON,SOLUTION,CANDIDATE,D/'queries/AuditCor23Canonical.lean',D/'queries/PrintCor23CanonicalAxioms.lean',D/'configs/canonical.template.json',D/'bind_canonical.py',D/'archive_cor23.py',D/'archive_chain.py',D/'finish_registration.py',D/'README.v81.zh.md']+final:
 if p.exists():files.append(p)
# Source-only byte evidence in referenced support files is pinned separately; do not copy a whole cache.
external=[]
for p in P.rglob('*.olean'):
 external.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'role':'Source replay prebuilt artifact retained as pin only, not copied into evidence archive'})
for row in read(S/'private-source-map.json'):
 p=Path(row['source']);external.append({'path':str(p),'sha256':sha(p),'role':'Original structural-helper source'})
for p in [R/'refer/iut/Iut/Implication/Corollary23.lean',W/'Definitions/Def_AbcAdaptation_Reference_Genl_GeneralPosition_StatementII.lean',W/'Theorems/Thm_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2.lean',W/'Theorems/Thm_AbcAdaptation_Reference_Iut_epsilonE_le.lean']:
 external.append({'path':str(p),'sha256':sha(p),'role':'Pinned original/canonical dependency; not a new verification claim'})
files += [p for p in (D/'history-v78').rglob('*')if p.is_file()]
files=sorted(set(files));entries=[]
for p in files:
 arc=str(p.relative_to(R))if p.is_relative_to(R)else'finish-preparation/'+str(p.relative_to(D));entries.append({'path':str(p),'archivePath':arc,'sha256':sha(p),'bytes':p.stat().st_size})
deletes=[]
solpin=read(A/'cor23-solution-leaf-v71-result.json')['request']['worktree_manifest']['input_hashes'][str(SOLUTION)]
stubpin=read(A/'cor23-stub-leaf-v70-result.json')['request']['worktree_manifest']['input_hashes'][str(CANON)]
for p,pin,role in [(SOLUTION,solpin,'integrated accepted top-level proof draft'),(S/'solution'/SOLUTION.name,solpin,'redundant accepted solution draft'),(S/'stub'/CANON.name,stubpin,'superseded theorem stub draft')]:
 if p.exists()and not(a.keep_top_level_solution and p==SOLUTION):
  assert sha(p)==pin,(p,'historical successful receipt SHA mismatch');assert CANON.read_bytes()==CANDIDATE.read_bytes();deletes.append({'path':str(p),'sha256':pin,'role':role,'comparedCanonical':str(CANON),'compiledCanonicalSHA256':sha(CANON)})
report={'schema':'cor23-finish-archive-dry-run/v81','platformVerification':platform['status'],'platformStatus':item['status'],'theoremId':item['theorem_id'],'sourceProjectTYPEMapCount':11,'sourceUniverses':4,'sourceProofRangesBytes':[142,2556],'typeAndBinderAudit':True,'privateSourceHelpers':7,'actualOwnModuleProofs':8,'publicDependenciesPlatformProved':2,'historicalLocalC2StubHadSorryAx':True,'finalLocalC2HasSorryAx':None if pending else False,'historicalV78TransitiveSorryAxExpected':True,'finalCanonicalStandardClosureRequired':True,'v78CanonicalReviewAccepted':False,'finalCanonicalStandardClosureAccepted':None if pending else True,'fileCount':len(entries),'inputBytes':sum(x['bytes']for x in entries),'pendingFinalCanonicalEvidence':pending,'archiveOutput':str(a.out.resolve()),'files':entries,'externalPins':external,'priorReceipts':receipts,'deleteAfterVerifiedArchive':deletes,'finalElevenRootStandardAxiomGate':chainGate,'canonicalExcludedFromDeletion':str(CANON)}
save(D/'dry-run.json',report)
if not a.apply:
 print(json.dumps({k:report[k]for k in ['fileCount','inputBytes','pendingFinalCanonicalEvidence','archiveOutput','sourceProofRangesBytes','historicalLocalC2StubHadSorryAx','finalLocalC2HasSorryAx','finalCanonicalStandardClosureAccepted']},ensure_ascii=False));raise SystemExit(0)
out=a.out.resolve();assert out.is_relative_to(W/'.local/adaptation');out.mkdir(parents=True,exist_ok=True);arc=out/'evidence.tar.gz'
if (out/'manifest.json').exists():
 old=read(out/'manifest.json');assert sha(arc)==old['sha256']
 with tarfile.open(arc,'r:gz')as tar:
  index=json.load(tar.extractfile('ARCHIVE_INDEX.json'))
  for row in index['files']:assert hashlib.sha256(tar.extractfile(row['archivePath']).read()).hexdigest()==row['sha256']
 print(json.dumps(old,ensure_ascii=False,indent=2));raise SystemExit(0)
with tarfile.open(arc,'w:gz')as tar:
 for row in entries:tar.add(row['path'],arcname=row['archivePath'],recursive=False)
 data=json.dumps(report,ensure_ascii=False,indent=2).encode();info=tarfile.TarInfo('ARCHIVE_INDEX.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
with tarfile.open(arc,'r:gz')as tar:
 for row in entries:assert hashlib.sha256(tar.extractfile(row['archivePath']).read()).hexdigest()==row['sha256']
allowed={SOLUTION,S/'solution'/SOLUTION.name,S/'stub'/CANON.name}
for row in report['deleteAfterVerifiedArchive']:
 p=Path(row['path']);assert p in allowed and p!=CANON;assert sha(p)==row['sha256'];assert sha(row['comparedCanonical'])==row['compiledCanonicalSHA256']
for row in report['deleteAfterVerifiedArchive']:Path(row['path']).unlink()
manifest={'schema':'cor23-completed-archive/v81','archive':str(arc.relative_to(R)),'sha256':sha(arc),'bytes':arc.stat().st_size,'fileCount':len(entries),'allMemberSha256Verified':True,'deletedIntegratedTopLevelDrafts':report['deleteAfterVerifiedArchive'],'deletedIntegratedProofDrafts':report['deleteAfterVerifiedArchive'],'finalElevenRootStandardAxiomGate':chainGate,'historicalLocalC2StubHadSorryAx':True,'finalLocalC2HasSorryAx':False,'finalCanonicalStandardClosureAccepted':True,'historicalV78CanonicalReviewFailed':True,'platformStatus':'Proved','platformVerificationStatus':'ACCEPTED','canonical':str(CANON.relative_to(R)),'canonicalSha256':sha(CANON)};save(out/'manifest.json',manifest);print(json.dumps(manifest,ensure_ascii=False,indent=2))
