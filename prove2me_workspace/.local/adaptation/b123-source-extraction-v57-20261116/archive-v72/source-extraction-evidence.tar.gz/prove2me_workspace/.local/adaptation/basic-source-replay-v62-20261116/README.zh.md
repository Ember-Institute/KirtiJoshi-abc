完整 Basic 原语法重放包已准备，所有文件只写在本 `/tmp` 目录。

入口为 `source-project/Iut/Tripod/Basic.lean`：它与 `refer/iut/Iut/Tripod/Basic.lean` 的全部 23619 字节逐字一致，保留原许可证、两个 import、命名空间、两个无名实例、全部结构及全部原证明。没有按正则切声明，没有删减或改写证明。现有 `ci-017929-e66fedf6` AST 给出 71 个 command、60 个 declaration command，`command-map.json` 逐条保存原/回放字节范围和摘要，连同签名/证明范围均未改变；实际生成声明数尚不由此推定。

即刻重放不需要导入整个 Corollary22，也不需要补 Mathlib 源依赖：Basic 的原始直接导入仅 `Iut.Cor312.ThetaData.Places` 与 `Genl.GeneralPosition.HeightTheory`，现 4.35 搜索路径均有 `.olean`。`Places` 自身原来导入 Mathlib，已有其缓存。`cached-imports.json` 记录实际查得的缓存路径/摘要和完整既有 LEAN_PATH/PATH。保留两条原始 import 比改成更大的消费者环境更精确；这不是新的冷构建需求。

父智能体应把 task source 安装到稳定 source project 中，以正确的编译目录和源相对路径生成真实模块 `Iut.Tripod.Basic`，再生成相同模块路径的产物。不要将 `.local...Basic` 的产物误报为 `Iut.Tripod.Basic`，也不要仅改 sourceModule 字符串掩盖 owner 差异。`handoff.json` 只给相对 source/artifact 布局和必须绑定字段，没有代调用 CI 或假定调度器的工作目录语义。

`queries/QueryBasicSourceFacts.lean` 是后续未编译草稿：它导入真实 Basic 模块，按真实 compiler module owner 枚举所有声明，序列化完整 Name 组件、TYPE、宇宙参数、绑定信息、直接 TYPE 常量及 definition/opaque 值；默认不读取 theorem 证明值。共享 Expr codec 来自已有 source TYPE 查询，新增枚举部分尚待根智能体 CI。读取定义值包含源类型类实例的值；这不等于新数学证明或来源/目标相等已经验收。目标结构比较还需后续读取并核对构造器、字段、递归器元数据，不能只看名称和打印文本。

`target-correspondence-candidates.json` 区分三类：现 Def_AbcTripod 已有的实际参数点、点域、生成元、degree、归一化高度/不同理想/导子与紧致有界结构；同陈述而 proof 不同的辅助定理；尚未适配的 `tripodTheory`、源 Northcott 推论和源 StatementII 展开。独立 `CompactlyBounded` 结构只能在完整具名映射、字段和构造元数据核对后用于共同 carrier，不先当作定义性相等。`tripodTheory` 必须用现实际字段构造，不能把任意高度理论或运输法律作为新假设。

Basic 的 `statementII_iff'` 展开的目标形状与现规范 `AbcAdaptation.Tripod.StatementII` 相同，这是源 Main→规范 StatementII 的直接候选桥梁；它不是 source theorem 与 target predicate 的简单别名。`NorthcottHyp` 也是一个定义的命题，不是载入 Basic 后得到的证明。`Iut.finHeight`、`Iut.legendreJ` 和 `h_eq_finHeight_div` 不在 Basic 内，后续应从 Height 的真实 AST 狭义恢复，不能根据本包将它们标作已适配。

静态准备已完成。没有运行 Lean/Lake/MCP-CI、API 或 Git，没有改主工作区。
