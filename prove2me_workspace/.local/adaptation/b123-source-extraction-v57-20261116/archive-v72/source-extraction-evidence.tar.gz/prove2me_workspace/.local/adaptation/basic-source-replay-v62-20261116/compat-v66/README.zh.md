最窄建议是仅替换 `finite_of_fieldOf_eq` 中原来那条无进展的 `simp only`：

```lean
    change ∃ y : F,
      Height.logHeight₁ y ≤ max H 0 * Module.finrank ℚ F ∧ (y : Qbar) = l
```

后续原代码 `subst hFl; refine ⟨gen l, ?_, rfl⟩` 及其高度比较全部保留。

原因是当前分支的目标正是参数点的底层值 `l` 属于 `Subtype.val` 对给定高度有界子集的像。`Set.preimage`、`Set.image` 和集合构造器的成员关系展开后，这就是所列存在量词；`change` 要求内核确认定义性相等，并不增加数学假设。父回执所述情形中这些透明定义已经消去，故仅依赖 `simp only` 必须做出一次变换会触发无进展错误；明确给出目标形状不依赖该简化器状态。

该补丁保留实际点域 F、高度、`max H 0` 阈值、次数因子和原见证 `gen l`，没有删 Northcott 证明或改其陈述。完整原文件存 `OriginalBasic.lean.txt`，单行替换后的完整文件存 `EffectiveBasic.lean.txt`；`patch.diff` 和 `source-map.json` 绑定实际 AST command64及原/有效证明摘要。原签名字节不变，有效证明体与原证明体不同，不能继续称整份原源码逐字编译通过。

静态提议已完成，未改主工作区，未运行 CI、Lean、API 或 Git。最终验收仍由主智能体按实际编译回执确定。
