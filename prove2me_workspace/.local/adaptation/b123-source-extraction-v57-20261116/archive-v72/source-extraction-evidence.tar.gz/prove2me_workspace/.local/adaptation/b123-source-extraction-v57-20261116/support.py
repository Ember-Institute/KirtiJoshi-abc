from pathlib import Path
import json,re,hashlib
D=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/b123-source-extraction-v57-20261116');R=Path('/home/admin-wsl/Coq/abc/refer/iut')
sets={
'carrier':{'Iut.Tripod.Basic':['Qbar','Pt','fieldOf','gen','deg','ptLE','logDiff','logCond','CompactlyBounded','CompactlyBounded.set','tripodTheory'],'Iut.Tripod.CurveFacts':['CurveProviders','CurveProviders.curve','CurveProviders.tate','CurveProviders.localData','CurveProviders.h','curveInputs'],'Iut.Tripod.Providers':['tripodProviders'],'Iut.Concrete.Existence':['EllipticCurveData.localHeightData','CurveInputs','CurveInputs.toCorollary22Inputs'],'Iut.Concrete.Main':['IsConcrete','ConcreteThetaDataExistence'],'Iut.Anabelian.Geometry':['modelAG','modelTG']},
'B1-proof-chain':{'Iut.Tripod.Height':['finHeight','legendreJ','finHeight_mapEquiv','finHeight_algebraMap','finrank_mul_h_eq_finHeight','jT','tpdEquiv_jT'],'Iut.Tripod.TwoAdic':['tpd','genT','tpdEquiv','finrank_tpd']},
'B2-proof-and-transport':{'Iut.Tripod.GeneralPosition':['ptEquiv','cbsOf','discr_congr','finsum_div_eq_logCond','ptEquiv_mem_set']}}
# Name display recovery from source contexts; compiled identities remain pending.
qualified={('Iut.Tripod.Height',x):'Iut.'+x for x in ['finHeight','legendreJ','finHeight_mapEquiv','finHeight_algebraMap']}
qualified.update({('Iut.Anabelian.Geometry',x):'Iut.Anabelian.'+x for x in ['modelAG','modelTG']})
qualified.update({('Iut.Concrete.Existence',x):'Iut.'+x for x in ['EllipticCurveData.localHeightData','CurveInputs','CurveInputs.toCorollary22Inputs']})
qualified.update({('Iut.Concrete.Main',x):'Iut.'+x for x in ['IsConcrete','ConcreteThetaDataExistence']})
rows=[]
for role,mods in sets.items():
 for m,names in mods.items():
  p=R/(m.replace('.','/')+'.lean');t=p.read_text()
  for n in names:
   # Nested namespaces produce short original declIds; use literal final component only as source locator.
   spellings=[n,n.rsplit('.',1)[-1]];matches=[]
   for spelling in spellings:
    pat=r'^(?:@\[[^\n]*\]\s*)?(?:noncomputable\s+)?(?:def|abbrev|theorem|lemma|structure)\s+'+re.escape(spelling)+r'(?=\s|\{|\()'
    matches=list(re.finditer(pat,t,re.M))
    if matches:break
   assert matches,(m,n)
   q=matches[0];name=qualified.get((m,n),'Iut.Tripod.'+n)
   rows.append({'role':role,'sourceDisplayName':name,'module':m,'source':str(p),'sourceLine':t[:q.start()].count('\n')+1,'sourceDeclarationLine':t[q.start():].splitlines()[0],'compilerNameExpr':None,'targetName':None,'policy':'Exact source command and inherited contexts must be selected from next accepted AST; no wrapper/type reconstructed here.'})
(D/'carrier-and-proof-support-roots.json').write_text(json.dumps({'schema':'b123-original-carrier-proof-support-roots/v53','roots':rows,'platformNodesToCreate':[],'mechanicalHelpersPolicy':'Inline/private complete source bodies inside parent reduction; no new helper platform nodes','bridgeDraftCorrection':{'incorrectDraftSpelling':'Iut.Tripod.legendreJ','actualSourceNamespace':'Iut.legendreJ','source':'Iut/Tripod/Height.lean:246 (namespace Iut, closes at529)'}},ensure_ascii=False,indent=2)+'\n')
# Direct minimal whole-module imports for a future successful typed environment, NOT runnable now.
(D/'type-root-batches.json').write_text(json.dumps({'schema':'b123-type-root-batches/v53','allBlockedByMissingOleans':True,'batches':[{'batch':'B1','minimalWholeSourceImports':['Iut.Tripod.Height'],'roots':['Iut.Tripod.h_eq_finHeight_div'],'closureSupport':['Iut.Tripod.CurveFacts','Iut.Tripod.TwoAdic'],'note':'Full Height import is an upper bound; replay exact carriers/proof ancestors after parser to avoid pulling unrelated later height bounds.'},{'batch':'B2','minimalWholeSourceImports':['Iut.Tripod.GeneralPosition'],'roots':['Iut.Tripod.curves_fieldOf_eq','Iut.Tripod.curves_deg_eq','Iut.Tripod.curves_logDiff_eq','Iut.Tripod.curves_logCond_eq','Iut.Tripod.mem_set_of_bounds'],'note':'GeneralPosition imports Genl.Curves.ProofPackage for later theorems; the requested early transport roots may need only its actual data dependencies. Determine from AST/replay rather than whole proof-package build.'},{'batch':'B3-conversion-first','minimalWholeSourceImports':['Iut.Concrete.Main'],'roots':['Iut.IsConcrete','Iut.ConcreteThetaDataExistence','Iut.ConcreteThetaDataExistence.toThetaDataExistence'],'note':'Recover exact generic concrete P7→ThetaDataExistence adapter before fixed tripod producer; preserve cert, LocalEstimate, qOther and all conductor identities.'},{'batch':'B3-fixed-producer-and-root','minimalWholeSourceImports':['Iut.Tripod.Main'],'roots':["Iut.Tripod.concreteThetaDataExistence'",'Iut.Tripod.abc_of_variant'],'note':'Main entails real providers, Pi1/Tp model geometry and tower arithmetic. Source input CF/CI is actual term, not extra arbitrary hypothesis. No direct import possible from current caches.'}]},ensure_ascii=False,indent=2)+'\n')
