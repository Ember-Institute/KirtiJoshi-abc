B1/B2/B3 下一单元只读准备，未修改共享工作区，未编译或调用 CI/API/Git。

下一步入口为 `next-query-pointers.json`。先由主智能体独占执行现有 `QueryNextCarrierParserRanges.lean`，配本包 `parser-only.config.json`，使用已缓存的原始4.35 `Iut.Implication.Corollary22` 环境解析10份真实源文件。`compilerDeclarations` 故意为空：这些 producer 不在已导入的环境内；该阶段只提取完整 AST/上下文/签名/证明范围，不声称已获得真实 compiler Name 或 TYPE。已有 driver 的路径、摘要、结构化环境与下一步 oracle/TYPE模板指针均已固定。

`extraction-roots.json` 列出9个主要根：abc_of_variant、h_eq_finHeight_div、四项 curves_*_eq、mem_set_of_bounds、concreteThetaDataExistence'、ConcreteThetaDataExistence.toThetaDataExistence。它们的源文件、行号、原始签名与摘要均已记录；继承参数、完整 elaborated TYPE、数值组件 NameExpr 明确待真实提取，没有造目标名称或类型包装。

`carrier-and-proof-support-roots.json` 列出原始 point/field/degree/height theory、CurveProviders/curveInputs、concrete P7 和 height/field 传输支持根。`type-root-batches.json` 给出 B1、B2、B3 conversion、B3固定producer 的最小整模块导入上界；实际应由 AST 缩成真实命令闭包，完整保留原始数据命令与证明，机械辅助留在 parent 内 private/inline。

现96模块图是 generic Corollary22/Cor312 的依赖闭包，不包含下游具体 tripod producer、curve input 和 transport。所有本次主要 source module 的 `.olean` 在当前refer、abc.old原cache及extraction overlay中均缺失，不能直接 import Tripod.Main 读取 TYPE。`cache-and-import-gaps.json` 记录整源码导入闭包上界：202个 source-present 缺缓存模块，101个已有缓存边界，无未解析源；这不是要求全构建202模块。应先解析后切出精确来源命令，逐依赖用 MCP-CI 处理，不重下载依赖或冷建Mathlib。

B1应保留真实 F_λ→F_tpd≃ℚ(λ) 的有限高度归一化；B2的 curves_* 源根是 Genl.Curves.tripod→Iut.Tripod.ptEquiv 的传输，并不自动证明 native目标环境中的canonical传输。B3 conversion完整保留certificate、LocalEstimate、heightOther 2 ℓ、different及双conductor关系。固定producer仍使用真实Pi1/Tp、CurveProviders、tower arithmetic及Main里的CF/CI源项，不能用任意新输入记录代替。

已发现旧 BRIDGE_SIGNATURE_DRAFT 中 `Iut.Tripod.legendreJ` 是显示命名错误：源 `Height.lean:246` 在 namespace Iut 内，真实源码根为 `Iut.legendreJ`。此修正已记录；未生成适配目标名。

交付完成，等待主智能体下一轮独占执行，不开展额外验证。
