from pathlib import Path
import json,re,hashlib
D=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/b123-source-extraction-v57-20261116');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation';R=Path('/home/admin-wsl/Coq/abc/refer/iut');E=A/'reference-extraction-20261115';old=Path('/home/admin-wsl/Coq/abc.old/refer/iut');manifest=json.loads((E/'artifact-manifest.json').read_text());graphpath=E/'c22-decl-graph.jsonl';graph=[json.loads(x) for x in graphpath.open()];decls={x['name']:x for x in graph if x.get('record')=='decl'};modules={x['module'] for x in json.loads((E/'c22-participating-modules.json').read_text())}
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,d):
 p=D/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(d if isinstance(d,str) else json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def pin(p):return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
cacheRoots=[E/'source-project/.lake/build/lib/lean']+[Path(x) for x in manifest['candidate_original_lean_path'].split(':')]
sourceRoots=[R,old]+[Path(x['path']) for x in manifest['dependencies']]+[Path('/home/admin-wsl/Coq/mathlib4')]+list(Path('/home/admin-wsl/Coq/mathlib4/.lake/packages').iterdir())
def source(m):return next((p for x in sourceRoots if (p:=x/(m.replace('.','/')+'.lean')).exists()),None)
def artifacts(m):return [str(p) for x in cacheRoots if (p:=x/(m.replace('.','/')+'.olean')).exists()]
def imports(p):return re.findall(r'^import\s+([^\s]+)',p.read_text(),re.M)
core=[('B0/fixed producer','Iut.Tripod.abc_of_variant','Iut.Tripod.Main','abc_of_variant'),('B1','Iut.Tripod.h_eq_finHeight_div','Iut.Tripod.Height','h_eq_finHeight_div'),('B2','Iut.Tripod.curves_fieldOf_eq','Iut.Tripod.GeneralPosition','curves_fieldOf_eq'),('B2','Iut.Tripod.curves_deg_eq','Iut.Tripod.GeneralPosition','curves_deg_eq'),('B2','Iut.Tripod.curves_logDiff_eq','Iut.Tripod.GeneralPosition','curves_logDiff_eq'),('B2','Iut.Tripod.curves_logCond_eq','Iut.Tripod.GeneralPosition','curves_logCond_eq'),('B2','Iut.Tripod.mem_set_of_bounds','Iut.Tripod.GeneralPosition','mem_set_of_bounds'),('B3','Iut.Tripod.concreteThetaDataExistence\'','Iut.Tripod.Main',"concreteThetaDataExistence'"),('B3/conversion','Iut.ConcreteThetaDataExistence.toThetaDataExistence','Iut.Concrete.Main','ConcreteThetaDataExistence.toThetaDataExistence')]
# These are original source spelling + namespace context. No compiler Name Expr or target Name is constructed.
rows=[]
for role,name,m,short in core:
 p=source(m);txt=p.read_text();pat=re.compile(r'^(?:theorem|lemma) '+re.escape(short)+r'(?=\s|\{)',re.M);mat=pat.search(txt);assert mat,(m,short);j=mat.start()
 # Only raw signature capture: locate top-level proof token, never treat named arguments := as a proof.
 depth=0;end=None
 for k in range(j,len(txt)):
  ch=txt[k]
  if depth==0 and (txt.startswith(':=',k) or txt.startswith(' where',k)):
   end=k;break
  if ch in '([{':depth+=1
  elif ch in ')]}':depth-=1
 assert end is not None
 sig=txt[j:end].rstrip();line=txt[:j].count('\n')+1
 rows.append({'role':role,'sourceDisplayName':name,'originalModule':m,'source':pin(p),'sourceLine':line,'literalSourceSignatureWithoutAmbientBinders':sig,'signatureScope':'raw source text only, compiler TYPE and inherited binders pending','in96ModuleGraph':m in modules,'in96DeclarationGraph':name in decls,'existingCompilerNameExpr':None,'existingElaboratedType':None,'cacheArtifacts':artifacts(m),'typeExtractionReady':False,'targetName':None})
write('extraction-roots.json',{'schema':'b123-actual-source-root-plan/v53','roots':rows,'rootCount':len(rows),'wrapperDeclarationsEmitted':False,'fullCompilerNameIdentityPending':True})
# Source modules to parse contain all main roots and exact actual data/producer carriers.
astmods=['Iut.Tripod.Main','Iut.Tripod.Height','Iut.Tripod.GeneralPosition','Iut.Tripod.Basic','Iut.Tripod.CurveFacts','Iut.Tripod.Providers','Iut.Concrete.Main','Iut.Concrete.Existence','Iut.Tripod.TwoAdic','Iut.Anabelian.Geometry']
# Cached boundary traversal: no need to expand/rebuild a present olean.
allrows={};todo=list(astmods)
while todo:
 m=todo.pop()
 if m in allrows:continue
 cached=artifacts(m);p=source(m)
 r={'module':m,'source':pin(p) if p else None,'cacheArtifacts':cached,'status':'cached-boundary' if cached else 'missing-cache-source-present' if p else 'missing-cache-and-source'};allrows[m]=r
 if cached:continue
 if m.startswith(('Mathlib.','Lean.','Init.','Std.')) or m in ['Mathlib','Lean','Init','Std']:
  r['status']='external-cache-resolution-required';continue
 if p:r['imports']=imports(p);todo.extend(r['imports'])
missing=[m for m,r in allrows.items()if r['status']=='missing-cache-source-present'];cached=[m for m,r in allrows.items()if r['status']=='cached-boundary'];unresolved=[m for m,r in allrows.items()if r['status'] not in ['cached-boundary','missing-cache-source-present']]
write('cache-and-import-gaps.json',{'schema':'b123-source-cache-gap-audit/v53','compiled':False,'cacheSearchRoots':[str(x)for x in cacheRoots],'sourceResolutionRoots':[str(x)for x in sourceRoots],'roots':astmods,'missingSourceModuleCacheCount':len(missing),'cachedBoundaryModuleCount':len(cached),'unresolvedCount':len(unresolved),'missingSourceModuleCaches':sorted(missing),'cachedBoundaryModules':sorted(cached),'unresolvedModules':sorted(unresolved),'moduleRecords':allrows,'important':'This is an import-level upper bound for whole-source modules, not a declaration-level requirement. Narrow AST source replay must derive smaller actual dependencies before any broad build.'})
entries=[]
for m in astmods:
 p=source(m);b=p.read_bytes();entries.append({'module':m,'source':str(p),'sourceSha256':sha(b),'normalizedSha256':sha(b.replace(b'\r\n',b'\n')),'compilerDeclarations':[]})
parserDriver=A/'reference-main-chain-parser-20261115/QueryNextCarrierParserRanges.lean';cfg={'outputDir':str(D/'parser-output'),'sources':entries,'acceptedGraphSha256':sha(graphpath.read_bytes())};write('parser-only.config.json',cfg)
baseenv=json.loads((A/'reference-main-chain-parser-20261115/ci-input-paths.json').read_text())['environment'];env={'LEAN_PATH':baseenv['LEAN_PATH'],'PATH':baseenv['PATH'],'FOUNDATION_PARSER_CONFIG':str(D/'parser-only.config.json')}
write('next-query-pointers.json',{'schema':'b123-next-source-query-pointers/v53','firstExecutablePreparation':{'phase':'AST only; no producer import or re-elaboration','driver':pin(parserDriver),'configuration':str(D/'parser-only.config.json'),'parameters':{'source':str(parserDriver)},'environment':env,'minimalImportedSourceModule':'Iut.Implication.Corollary22 (already cached original4.35)','compilerDeclarationsPolicy':'Empty by design: external producer constants are absent from imported environment. Complete command AST, scopes, signatures and body ranges still emitted. Do not claim compiler Name identity or TYPE from this phase.','globalScopeCompatibility':'Driver already opens common number-field scopes. If Parser.testParseModule rejects source log⁺/scope syntax, add exact original open scoped WithZero Real/IntermediateField/Classical to a query copy after checking scope availability; do not import missing Main or replace source text.'},'afterParser':{'action':'Select exact original source commands and every original namespace/section/variable/open/local-instance context from AST; retain complete original data commands. Use real closure roots below; private closed arithmetic helpers remain inside parent source replay. Do not synthesize target wrappers.','semanticOracleDriver':pin(A/'reference-volume-tate-carriers-20261115/ExtractSmallRuntimeOracle.lean'),'semanticOraclePolicy':'Build a config from newly accepted AST command/body spans and exact source context. Existing96 graph cannot provide actual value deps for these absent producer roots. Compile/replay only true declaration dependencies through MCP-CI; preserve complete original types/proofs.','typeQueryTemplate':pin(A/'c2-open-v48-20261116/source/QueryOriginalType.lean'),'typeQueryPolicy':'Only after actual producer environment exists: replace imports with the narrow successful source contexts; recover unique actual compiler Names and nameExpr (including private numeric components), then read actual full Expr TYPE/telescope, owner, direct TYPE/value constants, and axioms. Never reconstruct nameExpr from dotted text or infer a type from raw signatures.','rootManifest':str(D/'extraction-roots.json'),'supportRootManifest':str(D/'carrier-and-proof-support-roots.json')},'ciRequestEmitted':False,'mainMustSupplyBeforeCI':['installed frozen query/config/output paths','current truthful exclusive worktree manifest','session_id/agent_id/idempotency_key','resource estimates based on task history','source/cache stability until terminal result']})
# Pin evidence/config without copying caches.
write('evidence-bindings.json',{'graph':pin(graphpath),'participatingModules':pin(E/'c22-participating-modules.json'),'moduleCount':len(modules),'referenceActions':pin(Path('/tmp/p2m-refer-iut-frontier-audit-v44-20261116/root-next-actions.json')),'bridgeDraft':pin(A/'reference-main-chain-parser-20261115/c2-source-input-plan/BRIDGE_SIGNATURE_DRAFT.md'),'priorParserAcceptance':pin(A/'reference-main-chain-parser-20261115/parser-acceptance.json'),'currentToolchain':pin(R/'lean-toolchain'),'cacheProvenanceManifest':pin(E/'artifact-manifest.json'),'graphExclusionReason':'96 participating modules are a dependency closure rooted in generic Corollary22/Cor312 and their carriers; downstream concrete instantiations and Tripod transport/curve producers are consumers outside that import closure. External producer cannot be recovered by renaming generic input fields.'})
print(json.dumps({'rootCount':len(rows),'astModules':astmods,'missingWholeSourceModuleCaches':len(missing),'cachedBoundary':len(cached),'unresolved':unresolved},ensure_ascii=False,indent=2))
