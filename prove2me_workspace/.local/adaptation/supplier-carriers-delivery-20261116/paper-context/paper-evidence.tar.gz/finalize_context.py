import json,pathlib,hashlib
D=pathlib.Path('/tmp/p2m-supplier-paper-context-v1-20261116')
p=D/'paper-context.json';j=json.loads(p.read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
q={'id':'IV-theorem110-bound','paper':'IV','locator':'§1, Theorem 1.10, first final displayed inequality','printed_pages':[23],'pdf_file_pages':[23], 'quote_markdown':r'$\frac16\cdot\log(\mathfrak q)\leq\left(1+\frac{20\cdot d_{\mathrm{mod}}}{l}\right)\cdot\left(\log(\mathfrak d^{F_{\mathrm{tpd}}})+\log(\mathfrak f^{F_{\mathrm{tpd}}})\right)+20\cdot(e_{\mathrm{mod}}^*\cdot l+\eta_{\mathrm{prm}})$', 'scope_note':'First inequality in the theorem’s final displayed chain. Its next inequality replaces the tripodal-field invariants by the F-invariants. The theorem derives the chain under its full hypotheses on pp. 22–23.', 'transcription':'Manually transcribed from the original PDF and checked against its rendered p. 23 in this task.', 'evidence':[{'paper':'IV','printed_page':23,'pdf_file_page':23,**{k:{'path':str(D/'evidence'/f'IV-023.{ext}'),'sha256':sha(D/'evidence'/f'IV-023.{ext}')} for k,ext in [('image','png'),('raw_text','raw.txt')]}}]}
j['quotations'].append(q)
cites={
 'Genl.HeightTheory':'Source context: [GenEll], Definition 1.2(i)–(ii), p. 5; Example 1.3(i)–(ii), pp. 5–6; Proposition 1.4(iii), p. 6; Definition 1.5(iii)–(iv), p. 8; Theorem 2.1(i)–(ii), p. 11.',
 'Iut.LocalHeightData.heightEq / heightOther':'Source context: IUT IV, Corollary 2.2(i), p. 41; proof of Corollary 2.2(ii), total-height paragraph on p. 44, (P5) on p. 46, and the first comparison on p. 47; Theorem 1.10, p. 23.',
 'Iut.epsilonE / deltaBound':'Source formulas: IUT IV, Corollary 2.2(ii), opening and (C2), p. 42. The field-degree bound occurs in its proof, p. 44. The ε_E argument occurs on p. 47.',
 'DiscrepancyLE / DiscrepancyEquiv':'Source notation: [GenEll], Definition 1.2(ii), p. 5, with the correction in IUT IV, Remark 2.3.1(ii), p. 55.',
 'Iut.Corollary22Inputs':'Source context: IUT IV, Corollary 2.2(i), p. 41; its proof, pp. 43–46. The cited background includes [GenEll], Proposition 1.4(iv), p. 6, Lemma 3.1(iii), p. 14, and Lemma 3.5, p. 17.',
 'Iut.ThetaDataExistence':'Source context: IUT IV, proof of Corollary 2.2(ii), (P7) and its adjacent paragraphs, p. 46; Theorem 1.10, pp. 22–23; final invariant comparisons, p. 48.',
 'Iut.Corollary22Inputs.threshold':'Source motivation: IUT IV, proof of Corollary 2.2(ii), total-height and finite-exception paragraph, p. 44; (P4), p. 45; (P5), p. 46; ε_E≤1 argument, p. 47.'}
for c in j['definition_contexts']:
 c['source_citation']=cites[c['definition']]
 c['english_readback_with_citations']=c['english_readback']+' '+c['source_citation']
 if c['definition']=='Iut.ThetaDataExistence':c['quotation_ids'].append(q['id'])
for paper in j['paper_sources'].values():
 path=pathlib.Path(paper['local_pdf'])
 assert sha(path)==paper['sha256'],str(path)
ids={q['id'] for q in j['quotations']}
for c in j['definition_contexts']:
 for ref in c.get('quotation_ids',[]):assert ref in ids,ref
 for f in c.get('fields',[]):
  for ref in f['quotation_ids']:assert ref in ids,ref
j['validation']={'paper_sha256_checked':True,'quotation_reference_ids_checked':True,'field_counts':{'Genl.HeightTheory':15,'Iut.Corollary22Inputs':16},'all_new_quotations_visually_checked':True,'reuse_note':'Four quotations retain their previously verified transcriptions and original evidence from the 2026-11-15 context file.','no_compilation_or_external_acceptance_claimed':True}
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
# Rewrite the readable note to include paragraph citations in every readback.
lines=['# Original-paper context for definition suppliers','',j['purpose'],'', 'All cited page numbers match the printed and PDF file pages in the local originals. [GenEll] displays February 2009. IUT IV displays April 2020.','']
for c in j['definition_contexts']:
 lines+=['## '+c['definition'],'',c['classification'],'',c['english_readback_with_citations'],'']
 if 'fields' in c:
  lines+=['| Field | Intended source context |','| --- | --- |']
  for f in c['fields']:lines+=['| `'+f['name']+'` | '+f['readback']+' See '+', '.join(f['quotation_ids'])+'. |']
  lines+=['']
 for s in c.get('limits',[]):lines+=['- '+s]
 lines+=['']
lines+=['## Original quotations','']
for x in j['quotations']:
 lines+=['### '+x['id'],'',x['paper']+', '+x['locator']+', p. '+', '.join(map(str,x['printed_pages']))+'.','',x['quote_markdown'],'',x['scope_note'],'']
lines+=['## Genl license provenance','',j['original_code_provenance']['Genl']['license_statement'],'','```text',j['original_code_provenance']['Genl']['source_header'],'```','',
'The JSON record includes source hashes, original PDF paths, rendered-page hashes, and the prior verified quotation record. No compiler, CI job, platform API, or Git operation was used for this note.','']
(D/'paper-context.md').write_text('\n'.join(lines))
(D/'artifact-manifest.json').write_text(json.dumps({'schema':'paper-context-artifacts-v1','files':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in [D/'paper-context.json',D/'paper-context.md',D/'build_context.py',D/'finalize_context.py']]},indent=2)+'\n')
print('Validated',len(j['quotations']),'quotations and',len(j['definition_contexts']),'definition contexts.')
