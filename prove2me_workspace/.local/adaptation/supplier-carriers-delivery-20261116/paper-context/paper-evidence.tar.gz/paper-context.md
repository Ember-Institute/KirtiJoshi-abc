# Original-paper context for definition suppliers

Original-paper context for definition suppliers. This is a source explanation, not a formal proof, a blind type readback, or a claim that the interfaces instantiate the geometry.

All cited page numbers match the printed and PDF file pages in the local originals. [GenEll] displays February 2009. IUT IV displays April 2020.

## Genl.HeightTheory

Generic Lean interface motivated by the original paper; not a verbatim paper definition.

This structure supplies an abstract height formalism. Its 15 fields name curves, point types, degree subsets, three real functions, the tripod, and compactly bounded subsets. It also supplies two degree-filter laws and a proof that the tripod is hyperbolic. These fields describe the intended geometric interpretation. The structure itself does not construct number fields, curves, divisors, heights, or local bounding domains. Source context: [GenEll], Definition 1.2(i)–(ii), p. 5; Example 1.3(i)–(ii), pp. 5–6; Proposition 1.4(iii), p. 6; Definition 1.5(iii)–(iv), p. 8; Theorem 2.1(i)–(ii), p. 11.

| Field | Intended source context |
| --- | --- |
| `Curve` | A type intended to represent curve–divisor pairs (X,D). See GE-geometry. |
| `Pt` | An algebraic-point type for each curve. See GE-geometry. |
| `Hyperbolic` | A predicate intended to express positive log-canonical degree. See GE-geometry. |
| `DivisorFree` | A predicate intended to express D=∅. See GE-geometry. |
| `ptLE` | The degree-at-most subsets. See GE-degree-filter. |
| `ptEQ` | The degree-exactly subsets. See GE-degree-filter. |
| `ptLE_zero` | An interface law: the degree-at-most-zero set is empty. See GE-degree-filter. |
| `ptLE_succ` | An interface law decomposing degree-at-most-(d+1). See GE-degree-filter. |
| `htCan` | A real function intended as a representative of the log-canonical height class. See GE-height-class, GE-geometry. |
| `logDiff` | A real function intended as the normalized log-different. See GE-log-diff. |
| `logCond` | A real function intended as the normalized log-conductor. See GE-log-cond. |
| `tripod` | A distinguished curve intended as (P¹_Q,{0,1,∞}). See GE-geometry. |
| `hyperbolic_tripod` | A witness that the distinguished curve satisfies Hyperbolic. See GE-geometry. |
| `CBS` | A type intended to index the relevant compactly bounded subsets. See GE-cbs. |
| `cbsSet` | The underlying point set for each CBS index. See GE-cbs. |

- Curve and Pt are abstract types. Their geometric meanings come from the interpretation, not the bare types.
- Hyperbolic and DivisorFree are predicates supplied by the interface.
- The two degree-filter equations are explicit Lean interface laws. The paper defines degree subsets by fields and set difference.
- CBS and cbsSet do not carry local domains or a named finite set Σ. The intended support condition is implicit in the choice of CBS.
- No StatementI or StatementII theorem is part of the selected structure command.

## Iut.LocalHeightData.heightEq / heightOther

Local auxiliary definitions that partition the total normalized height; not named definitions from the paper.

For local height data L, heightEq(q) sums the terms at bad places with residue characteristic q, then divides by L.deg. The function heightOther(a,b) sums the terms whose residue characteristics differ from both a and b, with the same denominator. Each term is hv(v)·f(v)·log(p(v)). These formulas partition the globally normalized height from IUT IV, p. 44. Source context: IUT IV, Corollary 2.2(i), p. 41; proof of Corollary 2.2(ii), total-height paragraph on p. 44, (P5) on p. 46, and the first comparison on p. 47; Theorem 1.10, p. 23.

- heightOther(2,l) is identified with the theorem input log(q) only by the supplied thetaData equality. The generic sum definition alone proves no such geometric identification.
- heightEq(q) keeps the global denominator deg. It is not Definition 1.9(ii)’s normalized E-degree, whose denominator sums local degrees over E.
- The support sets can be empty. If a=b, the two exclusions coincide; a three-part decomposition requires a≠b.
- The pilot quantity |log(q-underlined-underlined)| is log(q)/(2l), as stated in Theorem 1.10, p. 23. It must not be equated directly with heightOther(2,l).

## Iut.epsilonE / deltaBound

Lean numeric functions implementing formulas used in the paper.

The function epsilonE(δ,h) returns (60δ)²·log(2δh)/sqrt(h). For the positive height h=log(q^∀), this is the ε_E in Corollary 2.2(ii), p. 42. The function deltaBound(d) returns 552960d, which equals 2¹²·3³·5·d. Corollary 2.2(ii) uses this δ, and its proof bounds [F:Q] by δ on p. 44. Source formulas: IUT IV, Corollary 2.2(ii), opening and (C2), p. 42. The field-degree bound occurs in its proof, p. 44. The ε_E argument occurs on p. 47.

- The Lean definitions are total on their formal domains. The paper uses positive d and positive height h under its geometric hypotheses.
- The equality 2¹²·3³·5=552960 is arithmetic. It does not establish the geometric degree bound; localData_deg_le supplies that bound.
- The numeric definitions alone establish neither ε_E≤1 nor the C2 inequality.

## DiscrepancyLE / DiscrepancyEquiv

Generic Lean relations expressing the paper’s bounded-discrepancy notation.

DiscrepancyLE(f,g,s) means that some real C satisfies f(x)≤g(x)+C for every x in s. DiscrepancyEquiv(f,g,s) requires this bound in both directions. Thus the two functions differ by a bounded amount on s. The notation follows Mochizuki’s correction in IUT IV, Remark 2.3.1(ii), p. 55. Source notation: [GenEll], Definition 1.2(ii), p. 5, with the correction in IUT IV, Remark 2.3.1(ii), p. 55.

- The uncorrected direction printed in [GenEll], Definition 1.2(ii), p. 5 is reversed. Cite the correction when describing ≲.
- The two directions may use different constants. A common absolute-value bound follows by taking their maximum.
- These definitions introduce relations, not quotient types of BD-classes.
- They apply to arbitrary real-valued functions on a type α. No geometric height theory is required to form the relations.

## Iut.Corollary22Inputs

Local 16-field input bundle. Its fields are supplied data and assumptions, not 16 theorems proved by its declaration.

For an abstract height theory T, a compactly bounded index K, and a degree bound d, this structure supplies the height inputs for Corollary 2.2. Its 16 fields include local data, comparison bounds, finiteness properties, subgroup predicates, and an exceptional set. The conditions apply to points in T.cbsSet(K) of degree at most d, except htCan_equiv, which applies on all of T.cbsSet(K). Source context: IUT IV, Corollary 2.2(i), p. 41; its proof, pp. 43–46. The cited background includes [GenEll], Proposition 1.4(iv), p. 6, Lemma 3.1(iii), p. 14, and Lemma 3.5, p. 17.

| Field | Intended source context |
| --- | --- |
| `h` | The total q-height function. See IV-height-definition. |
| `localData` | Local height data for each point in K of degree at most d. See IV-height-definition, GE-local-height. |
| `localData_height` | A supplied equality between localData.height and h. See IV-height-definition. |
| `localData_deg_le` | A supplied bound deg≤552960*d. See IV-degree-bound, IV-invariants. |
| `htCan_equiv` | A supplied bounded-discrepancy comparison of h/6 and the tripod height. See IV-height-equivalence. |
| `northcott` | A supplied finiteness property for bounded height and degree. See GE-northcott. |
| `B` | A real bound for the unscaled contribution over 2. See IV-height-equivalence. |
| `B_nonneg` | A supplied nonnegativity proof for B. See IV-height-equivalence. |
| `heightEq_two_le` | A supplied upper bound heightEq(2)≤B. See IV-height-equivalence. |
| `HasCyclicSubgroup` | A predicate intended to express existence of an l-cyclic subgroup scheme. See GE-cyclic, IV-p4. |
| `TK` | A real constant used by the cyclic-subgroup estimate. See IV-p4. |
| `cyclic_bound` | A supplied estimate with h−heightEq(2), under primality and local divisibility hypotheses. See GE-cyclic, IV-p4. |
| `SL2Image` | A predicate intended to express that the l-torsion Galois image contains SL₂. See IV-p5-p6. |
| `sl2_of` | A supplied implication from (P2), absence of a cyclic subgroup, and a bad place away from 2l. See IV-p5-p6. |
| `excCore` | A set intended to contain points whose elliptic curve lacks an F-core. See IV-core-exception. |
| `excCore_finite` | A supplied finiteness proof for the exceptional set at bounded degree. See IV-core-exception. |

- The declaration does not prove that the 16 fields hold for a concrete elliptic-curve construction.
- The source field cyclic_bound subtracts heightEq(2); the paper’s p. 45 display writes total log(q^∀) after bounded discrepancies. This is a local formulation of the needed bound, not the same printed formula.
- The Lean B bounds the full contribution heightEq(2). The paper’s B_K on p. 47 bounds one sixth of the difference of the two heights. These constants have different normalizations.
- TK has type ℝ without a positivity field. The local threshold uses max TK 0. The paper calls T_K positive on p. 45.
- HasCyclicSubgroup, SL2Image, and excCore are supplied symbols. Their intended geometric meanings are not definitions proved by this structure.

## Iut.ThetaDataExistence

Local proposition packaging the construction associated with (P7), plus formal interfaces and invariant comparisons. It is not a verbatim transcription of (P7).

Assume x lies in K, has degree at most d, and avoids the exceptional set. Let l be prime, with l≥7. Assume (P2), (P3), a bad place away from 2l, and the supplied SL2Image predicate. Then thetaData supplies a variant-data bundle X and its Theorem 1.10 invariants. The output satisfies P, its certificate, nonempty local estimates, X.l=l, and X.dmod≤d. It also identifies X.qPilot.logQ with heightOther(2,l) and gives the stated different and conductor comparisons. Source context: IUT IV, proof of Corollary 2.2(ii), (P7) and its adjacent paragraphs, p. 46; Theorem 1.10, pp. 22–23; final invariant comparisons, p. 48.

- P, Corollary312VariantData, Theorem110Certificate, and LocalEstimate are repository interfaces. The paper does not use these Lean names or this conjunction.
- The paper’s (P7), p. 46 says the constructed initial Θ-data satisfies Theorem 1.10. The local proposition packages that construction as an assumption to consume later.
- The paper invokes (P1), (P2), (P5), and (P6) before (P7). The local input uses l≥7, (P2), (P3), the bad-place witness, and SL2Image. Do not claim these formulations are definitionally identical.
- The final equality and two conductor inequalities correspond to p. 48. They are output fields of this assumption, not new proofs in this definition.
- X.qPilot.logQ is the repository’s Theorem 1.10 log(q) carrier. The separately normalized Corollary 3.12 pilot log-volume includes the factor 1/(2l).

## Iut.Corollary22Inputs.threshold

Local explicit sufficient threshold. The formula is not printed in Mochizuki’s paper.

This local function takes the maximum of four bounds. They support the prime-selection threshold, the cyclic-subgroup exclusion, the bad-place existence argument, and ε_E≤1. The paper instead enlarges a finite exceptional set at these steps. The fourth powers and the displayed constants are choices in the Lean implementation. Source motivation: IUT IV, proof of Corollary 2.2(ii), total-height and finite-exception paragraph, p. 44; (P4), p. 45; (P5), p. 46; ε_E≤1 argument, p. 47.

- This numeric definition alone proves none of the four consequences. Later arguments must use the input hypotheses.
- This formula is not the paper’s full quantitative exceptional-set bound H_unif·ε_d^(-3)·d^(4+ε_d)+H_K. It must not be described as an equivalent statement of Corollary 2.2(ii) or (iii).

## Original quotations

### GE-bd-class

GenEll, §1, Definition 1.2(ii), sentences after the defining inequality, p. 5.

The relation “$\approx$” clearly defines an equivalence relation on the set of functions $\mathcal F\to\mathbb R$; we shall refer to an equivalence class relative to this equivalence relation as a(n) [$\mathcal F$-]BD-class [i.e., “bounded discrepancy class”].

Complete sentence or display at the stated location; line breaks and line-end hyphenation are joined.

### IV-discrepancy-correction

IV, §2, Remark 2.3.1(ii), correction of [GenEll], Definition 1.2(ii), p. 55.

In [GenEll], Definition 1.2, (ii), the non-resp’d and first resp’d items in the display should be reversed! That is to say, the notation “$\alpha\lesssim_{\mathcal F}\beta$” corresponds to “$\alpha(x)-\beta(x)\leq C$”; the notation “$\alpha\gtrsim_{\mathcal F}\beta$” corresponds to “$\beta(x)-\alpha(x)\leq C$”.

Complete sentence or display at the stated location; line breaks and line-end hyphenation are joined.

### GE-degree-filter

GenEll, §1, Example 1.3(i), degree-at-most and degree-exactly subsets, p. 5.

$X(\overline{\mathbb Q})^{\leq d}\subseteq X(\overline{\mathbb Q})$

the union of the subsets $X(F)\subseteq X(\overline{\mathbb Q})$ as $F$ ranges over the number fields such that $[F:\mathbb Q]\leq d$ [so $X(\overline{\mathbb Q})^{\leq\infty}=X(\overline{\mathbb Q})$];

$X(\overline{\mathbb Q})^{=d}\overset{\mathrm{def}}{=}X(\overline{\mathbb Q})^{\leq d}\backslash X(\overline{\mathbb Q})^{\leq d-1}\subseteq X(\overline{\mathbb Q})$.

Display and its following explanatory clause; the preceding phrase “If d∈N∪{∞}, then we shall denote by” is omitted.

### GE-cbs

GenEll, §1, Example 1.3(ii), first full paragraph on p. 6, p. 6.

We shall refer to a subset $X(\overline{\mathbb Q})$ obtained [i.e., as a “$\mathcal K_V$”] in this fashion as a compactly bounded subset, to $V$ as the support of the compactly bounded subset, and to the “$K_v$” as the bounding domains of the compactly bounded subset.

One sentence; its phrase “in this fashion” refers to the local domains on pp. 5–6. This is not a free-standing definition without those conditions.

### GE-height-class

GenEll, §1, Proposition 1.4(iii), first sentence, p. 6.

The BD-class of $\operatorname{ht}_{\overline{\mathcal L}}$ depends only on the isomorphism class of the line bundle $\mathcal L_{\mathbb Q}$ on $X_{\mathbb Q}$.

Complete sentence or display at the stated location; line breaks and line-end hyphenation are joined.

### GE-northcott

GenEll, §1, Proposition 1.4(iv), p. 6.

Let $d$ be a positive integer, $C\in\mathbb R$. Suppose further that the line bundle $\mathcal L_{\mathbb Q}$ is ample on $X_{\mathbb Q}$. Then the set of points $x\in X(\overline{\mathbb Q})^{\leq d}$ [cf. Example 1.3, (i)] such that $\operatorname{ht}_{\overline{\mathcal L}}(x)\leq C$ is finite.

Complete sentence or display at the stated location; line breaks and line-end hyphenation are joined.

### GE-log-diff

GenEll, §1, Definition 1.5(iii), assignment defining the log-different, p. 8.

$X(\overline{\mathbb Q})\ni x\mapsto\operatorname{log\text{-}diff}_X(x)\overset{\mathrm{def}}{=}\underline{\deg}_F(\delta_x)\in\mathbb R$

determines a well-defined log-different function $\operatorname{log\text{-}diff}_X$ on $X(\overline{\mathbb Q})$.

Display and final clause. The preceding sentences require F to be the minimal field of definition of x and δ_x to be its different divisor.

### GE-log-cond

GenEll, §1, Definition 1.5(iv), definition of the conductor divisor, p. 8.

$\mathfrak f_x^D\overset{\mathrm{def}}{=}(D_x)_{\mathrm{red}}\in\operatorname{ADiv}(F)$

as the conductor of $x$.

Display and its following clause. Here D_x is the pullback of D along Spec(O_F)→X, and F is minimal for x. The paragraph defines log-cond_D(x)=underlined deg_F(f_x^D).

### GE-geometry

GenEll, §2, Theorem 2.1(i), opening hypotheses, p. 11.

Let $X$ be a smooth, proper, geometrically connected curve over a number field; $D\subseteq X$ a reduced divisor; $U_X\overset{\mathrm{def}}{=}X\backslash D$; $d$ a positive integer; $\epsilon\in\mathbb R_{>0}$ a positive real number. Write $\omega_X$ for the canonical sheaf on $X$. Suppose that $U_X$ is a hyperbolic curve — i.e., that the degree of the line bundle $\omega_X(D)$ is positive.

Complete sentence or display at the stated location; line breaks and line-end hyphenation are joined.

### GE-local-height

GenEll, §3, Definition 3.3, p. 15.

We shall refer to the positive integer $v_K(q_E)\in\mathbb Z_{>0}$ as the local height of $E$ [or $E_K$].

Complete sentence or display at the stated location; line breaks and line-end hyphenation are joined.

### GE-cyclic

GenEll, §3, Lemma 3.5, hypothesis concerning local heights and conclusion, p. 17.

Suppose further that $l$ is prime to the local heights of $E$ at all of its primes of [bad] multiplicative reduction [a condition that is satisfied, for instance, if $l$ is $>$ these local heights]. Then we have

$\frac{1}{12(1+\epsilon)}l\cdot\underline{\deg}_{\infty}(E)\leq\operatorname{ht}^{\mathrm{Falt}}(E)+2\log(l)+C$

for some constant $C\in\mathbb R$ which [may depend on $\epsilon$ but] is independent of $E$, $F$, $H_F$, and $l$.

Final part of the lemma. Its preceding hypotheses include ε>0 and an l-cyclic subgroup scheme H_F⊆E_F. This excerpt is not the separate cyclic_bound field verbatim.

### IV-height-definition

IV, §2, proof of Corollary 2.2(ii), paragraph beginning “Next, let us write”, p. 44.

$h\overset{\mathrm{def}}{=}\log(\mathfrak q^{\forall})=\frac{1}{[F:\mathbb Q]}\cdot\sum_{v\in\mathbb V(F)^{\mathrm{non}}}h_v\cdot f_v\cdot\log(p_v)$

— that is to say, $h_v=0$ for those $v$ at which $E_F$ has good reduction; $h_v\in\mathbb N_{\geq1}$ is the local height of $E_F$ [cf. [GenEll], Definition 3.3] for those $v$ at which $E_F$ has bad multiplicative reduction.

Complete sentence or display at the stated location; line breaks and line-end hyphenation are joined.

### IV-degree-bound

IV, §2, Corollary 2.2(ii), opening on p. 42; and proof on p. 44, p. 42, 44.

Set $\delta\overset{\mathrm{def}}{=}2^{12}\cdot3^3\cdot5\cdot d$.

Thus, since $[F:\mathbb Q]\leq\delta$ [cf. the properties (E3), (E4), (E5) in the proof of Theorem 1.10] […].

Two separate excerpts: first a complete sentence on p. 42, then a clause on p. 44 with its continuation omitted. The separate source passages are not one continuous paragraph.

### IV-height-equivalence

IV, §2, Corollary 2.2(i), displayed equality of BD-classes, p. 41.

$\frac16\cdot\log(\mathfrak q_{(-)}^{\nmid2})\approx\frac16\cdot\log(\mathfrak q_{(-)}^{\forall})\approx\frac16\cdot\operatorname{ht}_{\infty}\approx\operatorname{ht}_{\omega_X(D)}$

of functions on $\mathcal K_V\subseteq U_X(\overline{\mathbb Q})$.

Display and following clause. The corollary assumes the tripod, a compactly bounded K_V with 2 in its support, and condition (*j-inv).

### IV-core-exception

IV, §2, proof of Corollary 2.2(ii), first paragraph on p. 43, p. 43.

First, let us recall that if the once-punctured elliptic curve associated to $E_F$ fails to admit an $F$-core, then there are only four possibilities for the $j$-invariant of $E_F$ [cf. [CanLift], Proposition 2.7].

Complete sentence or display at the stated location; line breaks and line-end hyphenation are joined.

### IV-p4

IV, §2, proof of Corollary 2.2(ii), (P4) and next display, p. 45.

(P4) $E_F$ does not admit an $l$-cyclic subgroup scheme.

Indeed, the existence of an $l$-cyclic subgroup scheme of $E_F$ would imply that

$\frac{l-2}{24}\cdot\log(\mathfrak q^{\forall})\leq2\cdot\log(l)+T_{\mathcal K}$.

Condition and beginning of its justification. The following paragraph obtains T_K from bounded discrepancies. The Lean cyclic_bound instead subtracts the contribution over 2 explicitly.

### IV-p5-p6

IV, §2, proof of Corollary 2.2(ii), (P5), (P6) and sentence after (P6), p. 46.

(P5) if we write $\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}$ for the set of nonarchimedean valuations $\in\mathbb V_{\mathrm{mod}}\overset{\mathrm{def}}{=}\mathbb V(F_{\mathrm{mod}})$ that do not divide $2l$ and at which $E_F$ has bad multiplicative reduction, then $\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}\neq\emptyset$.

[…] (P6) the image of the outer homomorphism $\operatorname{Gal}(\overline{\mathbb Q}/F)\to GL_2(\mathbb F_l)$ determined by the $l$-torsion points of $E_F$ contains the subgroup $SL_2(\mathbb F_l)\subseteq GL_2(\mathbb F_l)$.

Indeed, since, by (P5), $E_F$ has bad multiplicative reduction at some valuation $\in\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}\neq\emptyset$, (P6) follows formally from (P2), (P4), and [GenEll], Lemma 3.1, (iii) [cf. the proof of the final portion of [GenEll], Theorem 3.8].

Separate labeled conditions and final justification. The paragraph proving (P5) between the conditions is explicitly omitted.

### IV-p7

IV, §2, proof of Corollary 2.2(ii), (P7) and following paragraph, p. 46.

(P7) the resulting initial $\Theta$-data

$(\overline F/F,X_F,l,\underline C_K,\underline{\mathbb V},\mathbb V_{\mathrm{mod}}^{\mathrm{bad}},\underline\epsilon)$

satisfies the various conditions in the statement of Theorem 1.10.

Here, we note in passing that the crucial existence of data “$\underline{\mathbb V}$” and “$\underline\epsilon$” satisfying the requisite conditions follows, in essence, as a consequence of the fact [i.e., (P6)] that the Galois action on $l$-torsion points contains the full special linear group $SL_2(\mathbb F_l)$.

Complete (P7) and next paragraph. The preceding paragraph invokes (P1), (P2), (P5), (P6) and [IUTchI], Definition 3.1(a)–(f). Underlines follow the PDF.

### IV-C2

IV, §2, Corollary 2.2(ii), condition (C2) and definition of ε_E, p. 42.

$\frac16\cdot\log(\mathfrak q)\leq\frac16\cdot\log(\mathfrak q^{\nmid2})\leq\frac16\cdot\log(\mathfrak q^{\forall})\leq(1+\epsilon_E)\cdot(\operatorname{log\text{-}diff}_X(x_E)+\operatorname{log\text{-}cond}_D(x_E))+C_{\mathcal K}$

— where we write

$\epsilon_E\overset{\mathrm{def}}{=}(60\delta)^2\cdot\frac{\log(2\delta\cdot(\log(\mathfrak q^{\forall})))}{(\log(\mathfrak q^{\forall}))^{1/2}}$.

Displayed inequality and definition. The hypotheses, exceptional set, field construction, and (C1) earlier on pp. 41–42 remain part of the paper statement.

### IV-invariant-comparison

IV, §2, proof of Corollary 2.2(ii), final paragraph before Remark 2.2.1, p. 48.

[…] we have an equality $\operatorname{log\text{-}diff}_X(x_E)=\log(\mathfrak d^{F_{\mathrm{tpd}}})$, as well as inequalities $\log(\mathfrak f^{F_{\mathrm{tpd}}})\leq\operatorname{log\text{-}cond}_D(x_E)\leq\log(\mathfrak f^{F_{\mathrm{tpd}}})+\log(2l)$ […].

Exact mathematical clause, with its beginning and continuation explicitly omitted. The paper also states the same comparison at the top of p. 43.

### IV-epsilon-proof

IV, §2, proof of Corollary 2.2(ii), paragraph “Now let us set” and last clause on the page, p. 47.

$\epsilon_E\overset{\mathrm{def}}{=}(60\delta)^2\cdot h^{-1/2}\cdot\log(2\delta\cdot h)$

[…] we may assume without loss of generality that $\epsilon_E\leq1$.

First definition display, excluding its following parenthetical lower bound; then the final clause on the page. The intervening estimates and exceptional-set enlargement are omitted.

### IV-global-degree

IV, §1, Definition 1.9(i), sentence defining normalized degree and pullback equality, p. 21, 22.

If $\mathfrak a\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall refer to

$$\underline{\deg}(\mathfrak a)\overset{\mathrm{def}}{=}\frac{1}{[F:\mathbb Q]}\cdot\deg_F(\mathfrak a)$$

as the normalized degree of $\mathfrak a$. Thus, for any finite extension $K$ of $F$, we have

$$\underline{\deg}(\mathfrak a|_K)=\underline{\deg}(\mathfrak a)$$

— where we write $\underline{\deg}(\mathfrak a|_K)$ for the normalized degree of the pull-back $\mathfrak a|_K\in\operatorname{ADiv}_{\mathbb R}(K)$ [defined in the evident fashion] of $\mathfrak a$ to $K$.

Complete sentence(s) at the cited location.

### IV-fiber-degree

IV, §1, Definition 1.9(ii), opening through the definition of normalized E-degree, p. 22.

Let $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}\overset{\mathrm{def}}{=}\mathbb V(\mathbb Q)$, $E\subseteq\mathbb V(F)$ a nonempty set of elements lying over $v_{\mathbb Q}$. If $\mathfrak a=\sum_{v\in\mathbb V(F)}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F)$, then we shall write

$$\mathfrak a_E\overset{\mathrm{def}}{=}\sum_{v\in E}c_v\cdot v\in\operatorname{ADiv}_{\mathbb R}(F);\qquad\underline{\deg}_E(\mathfrak a)\overset{\mathrm{def}}{=}\frac{\deg(\mathfrak a_E)}{\sum_{v\in E}[F_v:\mathbb Q_{v_{\mathbb Q}}]}$$

for the portion of $\mathfrak a$ supported in $E$ and the “normalized $E$-degree” of $\mathfrak a$, respectively.

Complete sentence(s) at the cited location.

### IV-invariants

IV, §1, Theorem 1.10, opening through the definition of the tripodal field, p. 22.

Fix a collection of initial $\Theta$-data as in [IUTchI], Definition 3.1. Suppose that we are in the situation of [IUTchIII], Corollary 3.12, and that the elliptic curve $E_F$ has good reduction at every valuation $\in\mathbb V(F)^{\mathrm{good}}\cap\mathbb V(F)^{\mathrm{non}}$ that does not divide $2l$. In the notation of [IUTchI], Definition 3.1, let us write $d_{\mathrm{mod}}\overset{\mathrm{def}}{=}[F_{\mathrm{mod}}:\mathbb Q]$, $(1\leq)\ e_{\mathrm{mod}}\ (\leq d_{\mathrm{mod}})$ for the maximal ramification index of $F_{\mathrm{mod}}$ [i.e., of valuations $\in\mathbb V_{\mathrm{mod}}^{\mathrm{non}}$] over $\mathbb Q$, $d_{\mathrm{mod}}^*\overset{\mathrm{def}}{=}2^{12}\cdot3^3\cdot5\cdot d_{\mathrm{mod}}$, $e_{\mathrm{mod}}^*\overset{\mathrm{def}}{=}2^{12}\cdot3^3\cdot5\cdot e_{\mathrm{mod}}\ (\leq d_{\mathrm{mod}}^*)$, and

$$F_{\mathrm{mod}}\subseteq F_{\mathrm{tpd}}\overset{\mathrm{def}}{=}F_{\mathrm{mod}}(E_{F_{\mathrm{mod}}}[2])\subseteq F$$

for the “tripodal” intermediate field obtained from $F_{\mathrm{mod}}$ by adjoining the fields of definition of the $2$-torsion points of any model of $E_F\times_F\overline F$ over $F_{\mathrm{mod}}$ [cf. Proposition 1.8, (ii), (iii)].

The opening of the theorem. The further (3·5)-torsion and field-generation hypotheses follow on the same page and are outside this excerpt. They remain part of the paper theorem.

### IV-q-normalization

IV, §1, Theorem 1.10 statement, sentence beginning “Here, we observe”, p. 23.

Here, we observe that the various “$\log(q_{(-)})$”’s are independent of the choice of $F_{\square}$, and that the quantity “$\lvert\log(\underline{\underline q})\rvert\in\mathbb R_{>0}$” defined in [IUTchIII], Corollary 3.12, is equal to $\frac{1}{2l}\cdot\log(q)\in\mathbb R$ [cf. the definition of “$\underline q_{\underline v}$” in [IUTchI], Example 3.2, (iv)].

Complete sentence(s) at the cited location.

### IV-theorem110-bound

IV, §1, Theorem 1.10, first final displayed inequality, p. 23.

$\frac16\cdot\log(\mathfrak q)\leq\left(1+\frac{20\cdot d_{\mathrm{mod}}}{l}\right)\cdot\left(\log(\mathfrak d^{F_{\mathrm{tpd}}})+\log(\mathfrak f^{F_{\mathrm{tpd}}})\right)+20\cdot(e_{\mathrm{mod}}^*\cdot l+\eta_{\mathrm{prm}})$

First inequality in the theorem’s final displayed chain. Its next inequality replaces the tripodal-field invariants by the F-invariants. The theorem derives the chain under its full hypotheses on pp. 22–23.

## Genl license provenance

The exact source headers declare Apache 2.0. The locked Genl root tree has no LICENSE, LICENSE.md, or LICENSE.txt. Do not cite a Genl repository LICENSE as an existing file. The supplied standard Apache 2.0 text comes from refer/iut/LICENSE, with that external origin recorded.

```text
Copyright (c) 2026 Christian Merten. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Christian Merten
```

The JSON record includes source hashes, original PDF paths, rendered-page hashes, and the prior verified quotation record. No compiler, CI job, platform API, or Git operation was used for this note.
