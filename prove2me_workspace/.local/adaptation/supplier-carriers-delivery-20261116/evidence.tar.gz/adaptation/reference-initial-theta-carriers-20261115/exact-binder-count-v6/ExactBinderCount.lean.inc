-- Exact size of the original binderInventory, without constructing its strings.
-- Memoize one value per exact Expr; add it once for every incoming tree edge.
private partial def binderCountDag (e : Expr) : StateM (Lean.ExprStructMap Nat) Nat := do
  let cache ← get
  if let some count := cache[(⟨e⟩ : ExprStructEq)]? then
    return count
  let count ← match e with
    | .forallE _ type body _ => do
      let domain ← binderCountDag type
      let body ← binderCountDag body
      pure (1 + domain + body)
    | .lam _ type body _ => do
      let domain ← binderCountDag type
      let body ← binderCountDag body
      pure (1 + domain + body)
    | .app fn arg => do
      let fn ← binderCountDag fn
      let arg ← binderCountDag arg
      pure (fn + arg)
    | .letE _ type value body _ => do
      let type ← binderCountDag type
      let value ← binderCountDag value
      let body ← binderCountDag body
      pure (type + value + body)
    | .mdata _ body => binderCountDag body
    | .proj _ _ body => binderCountDag body
    | _ => pure 0
  modify fun cache => cache.insert (⟨e⟩ : ExprStructEq) count
  return count

private def exactBinderCount (e : Expr) : Nat :=
  ((binderCountDag e).run {}).1

