-- Exact canonical representation of the original binderPlacement traversal.
-- ID zero is the empty traversal. Both inputs share the same intern table.
private inductive BinderPathKey where
  | forallE (binder : String) (domain body : Nat)
  | lam (binder : String) (domain body : Nat)
  | app (fn arg : Nat)
  | letE (type value body : Nat)
  | proj (body : Nat)
  deriving BEq, Hashable

private structure BinderPathCache where
  expressions : Lean.ExprStructMap Nat := {}
  shapes : Std.HashMap BinderPathKey Nat := {}
  nextId : Nat := 1

private def internBinderPathKey (key : BinderPathKey) : StateM BinderPathCache Nat := do
  let cache ← get
  if let some ref := cache.shapes[key]? then
    return ref
  let ref := cache.nextId
  set { cache with shapes := cache.shapes.insert key ref, nextId := ref + 1 }
  return ref

private partial def internBinderPath (e : Expr) : StateM BinderPathCache Nat := do
  let cache ← get
  -- ExprStructEq uses Expr.equal, which retains BinderInfo and binder names.
  -- Plain Expr keys use Expr.eqv and must not be substituted here.
  if let some ref := cache.expressions[(⟨e⟩ : ExprStructEq)]? then
    return ref
  let ref ← match e with
    | .forallE _ type body binder => do
      let domain ← internBinderPath type
      let body ← internBinderPath body
      internBinderPathKey (.forallE (encodeBinder binder) domain body)
    | .lam _ type body binder => do
      let domain ← internBinderPath type
      let body ← internBinderPath body
      internBinderPathKey (.lam (encodeBinder binder) domain body)
    | .app fn arg => do
      let fn ← internBinderPath fn
      let arg ← internBinderPath arg
      if fn == 0 && arg == 0 then pure 0
      else internBinderPathKey (.app fn arg)
    | .letE _ type value body _ => do
      let type ← internBinderPath type
      let value ← internBinderPath value
      let body ← internBinderPath body
      if type == 0 && value == 0 && body == 0 then pure 0
      else internBinderPathKey (.letE type value body)
    | .proj _ _ body => do
      let body ← internBinderPath body
      if body == 0 then pure 0 else internBinderPathKey (.proj body)
    | .mdata _ body => internBinderPath body
    | _ => pure 0
  modify fun cache => { cache with expressions := cache.expressions.insert (⟨e⟩ : ExprStructEq) ref }
  return ref

private def strictBinderShape (source target : Expr) : Bool :=
  let action : StateM BinderPathCache Bool := do
    let source ← internBinderPath source
    let target ← internBinderPath target
    pure (source == target)
  (action.run {}).1
