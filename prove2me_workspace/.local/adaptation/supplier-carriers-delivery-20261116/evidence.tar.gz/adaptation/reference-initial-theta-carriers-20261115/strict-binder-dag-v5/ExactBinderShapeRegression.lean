import Lean
open Lean
namespace FoundationAudit

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

-- Exact canonical representation of the original binderPlacement traversal.
-- ID zero is the empty traversal. Both inputs share the same intern table.
private inductive BinderPathKey where
  | forallE (binder : String) (domain body : Nat)
  | lam (binder : String) (domain body : Nat)
  | app (fn arg : Nat)
  | letE (type value body : Nat)
  | proj (body : Nat)
  deriving BEq, Hashable

private structure BinderPathCache where
  expressions : Lean.ExprStructMap Nat := {}
  shapes : Std.HashMap BinderPathKey Nat := {}
  nextId : Nat := 1

private def internBinderPathKey (key : BinderPathKey) : StateM BinderPathCache Nat := do
  let cache ← get
  if let some ref := cache.shapes[key]? then
    return ref
  let ref := cache.nextId
  set { cache with shapes := cache.shapes.insert key ref, nextId := ref + 1 }
  return ref

private partial def internBinderPath (e : Expr) : StateM BinderPathCache Nat := do
  let cache ← get
  -- ExprStructEq uses Expr.equal, which retains BinderInfo and binder names.
  -- Plain Expr keys use Expr.eqv and must not be substituted here.
  if let some ref := cache.expressions[(⟨e⟩ : ExprStructEq)]? then
    return ref
  let ref ← match e with
    | .forallE _ type body binder => do
      let domain ← internBinderPath type
      let body ← internBinderPath body
      internBinderPathKey (.forallE (encodeBinder binder) domain body)
    | .lam _ type body binder => do
      let domain ← internBinderPath type
      let body ← internBinderPath body
      internBinderPathKey (.lam (encodeBinder binder) domain body)
    | .app fn arg => do
      let fn ← internBinderPath fn
      let arg ← internBinderPath arg
      if fn == 0 && arg == 0 then pure 0
      else internBinderPathKey (.app fn arg)
    | .letE _ type value body _ => do
      let type ← internBinderPath type
      let value ← internBinderPath value
      let body ← internBinderPath body
      if type == 0 && value == 0 && body == 0 then pure 0
      else internBinderPathKey (.letE type value body)
    | .proj _ _ body => do
      let body ← internBinderPath body
      if body == 0 then pure 0 else internBinderPathKey (.proj body)
    | .mdata _ body => internBinderPath body
    | _ => pure 0
  modify fun cache => { cache with expressions := cache.expressions.insert (⟨e⟩ : ExprStructEq) ref }
  return ref

private def strictBinderShape (source target : Expr) : Bool :=
  let action : StateM BinderPathCache Bool := do
    let source ← internBinderPath source
    let target ← internBinderPath target
    pure (source == target)
  (action.run {}).1

private def oldStrictBinderShape (s t : Expr) : Bool :=
  binderInventory s == binderInventory t && binderPlacement s == binderPlacement t

private def regression : IO Unit := do
  let atom := Expr.const `a []
  let other := Expr.const `b []
  let b := Expr.lam `x atom (.bvar 0) .default
  let inst := Expr.lam `x atom (.bvar 0) .instImplicit
  unless !(ExprStructEq.beq ⟨b⟩ ⟨inst⟩) do
    throw (IO.userError "ExprStructEq unexpectedly ignores BinderInfo")
  let cases : Array Expr := #[atom, other, .sort .zero,
    b, inst, .lam `x atom (.bvar 0) .implicit,
    .lam `x atom (.bvar 0) .strictImplicit,
    .lam `otherName other (.bvar 0) .default,
    .forallE `x atom (.bvar 0) .default,
    .app b atom, .app atom b, .app b b,
    .app b inst, .app (.lam `y other (.bvar 0) .default) b,
    .letE `x b atom atom false, .letE `x atom b atom false,
    .letE `x atom atom b false, .letE `x atom atom b true,
    .proj `P 0 b, .proj `Q 7 b, .mdata {} b,
    .app (.mdata {} b) (.mdata {} b)]
  for i in [:cases.size] do
    for j in [:cases.size] do
      let expected := oldStrictBinderShape cases[i]! cases[j]!
      unless strictBinderShape cases[i]! cases[j]! == expected do
        throw (IO.userError s!"Exact BinderInfo comparer differs at pair {i},{j}")
  -- Equal inventories can have different path placements.
  unless binderInventory (.app b atom) == binderInventory (.app atom b) &&
      !strictBinderShape (.app b atom) (.app atom b) do
    throw (IO.userError "fn/arg placement distinction lost")
  -- Repeated incoming edges count twice; memoization cannot erase multiplicity.
  unless !strictBinderShape (.app b b) (.app b atom) do
    throw (IO.userError "Repeated shared-subtree occurrence lost")
  -- This pair specifically catches an Expr.eqv-based memo key.
  unless !strictBinderShape (.app b inst) (.app b b) do
    throw (IO.userError "Memo merged distinct BinderInfo annotations")
  IO.println s!"Exact BinderInfo comparer matched the original predicate on {cases.size * cases.size} pairs"

#eval regression
end FoundationAudit
