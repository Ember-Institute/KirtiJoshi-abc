import Mathlib.Data.Real.Basic
import Mathlib.Data.Set.Defs
set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference


universe u

namespace Genl


structure HeightTheory where
  
  Curve : Type u
  
  Pt : Curve → Type u
  
  Hyperbolic : Curve → Prop
  
  DivisorFree : Curve → Prop
  
  ptLE : (X : Curve) → ℕ → Set (Pt X)
  
  ptEQ : (X : Curve) → ℕ → Set (Pt X)
  
  ptLE_zero : ∀ X, ptLE X 0 = ∅
  
  ptLE_succ : ∀ X d, ptLE X (d + 1) = ptLE X d ∪ ptEQ X (d + 1)
  
  htCan : (X : Curve) → Pt X → ℝ
  
  logDiff : (X : Curve) → Pt X → ℝ
  
  logCond : (X : Curve) → Pt X → ℝ
  
  tripod : Curve
  
  hyperbolic_tripod : Hyperbolic tripod
  
  CBS : Type u
  
  cbsSet : CBS → Set (Pt tripod)

end Genl

end AbcAdaptation.Reference
