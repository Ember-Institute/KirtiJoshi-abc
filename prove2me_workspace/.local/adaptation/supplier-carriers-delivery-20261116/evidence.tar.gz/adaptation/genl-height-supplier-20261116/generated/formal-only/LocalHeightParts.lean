import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection
set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference


universe w

namespace Iut

open Finset Real

namespace LocalHeightData

variable (L : LocalHeightData)


noncomputable def heightEq (q : ℕ) : ℝ :=
  (∑ v ∈ L.bad.filter (fun v => L.p v = q), (L.hv v : ℝ) * L.f v * Real.log (L.p v)) / L.deg


noncomputable def heightOther (a b : ℕ) : ℝ :=
  (∑ v ∈ L.bad.filter (fun v => L.p v ≠ a ∧ L.p v ≠ b),
    (L.hv v : ℝ) * L.f v * Real.log (L.p v)) / L.deg

end LocalHeightData

end Iut

end AbcAdaptation.Reference
