import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection_HeightParts
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true
#check @AbcAdaptation.Reference.Iut.LocalHeightData.heightEq
#print axioms AbcAdaptation.Reference.Iut.LocalHeightData.heightEq
#check @AbcAdaptation.Reference.Iut.LocalHeightData.heightOther
#print axioms AbcAdaptation.Reference.Iut.LocalHeightData.heightOther
