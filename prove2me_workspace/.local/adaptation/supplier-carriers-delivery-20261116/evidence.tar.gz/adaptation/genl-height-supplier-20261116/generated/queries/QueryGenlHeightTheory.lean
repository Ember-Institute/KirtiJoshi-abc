import Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_HeightTheory
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true
#check @AbcAdaptation.Reference.Genl.HeightTheory
#check @AbcAdaptation.Reference.Genl.HeightTheory.mk
#check @AbcAdaptation.Reference.Genl.HeightTheory.cbsSet
#print AbcAdaptation.Reference.Genl.HeightTheory
#print axioms AbcAdaptation.Reference.Genl.HeightTheory
