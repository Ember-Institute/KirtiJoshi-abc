import Mathlib.Data.Real.Basic
import Mathlib.Data.Set.Defs
set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference


variable {α β : Type*}


def DiscrepancyLE (f g : α → ℝ) (s : Set α) : Prop :=
  ∃ C : ℝ, ∀ x ∈ s, f x ≤ g x + C


def DiscrepancyEquiv (f g : α → ℝ) (s : Set α) : Prop :=
  DiscrepancyLE f g s ∧ DiscrepancyLE g f s

@[inherit_doc]
notation:50 f:51 " ≲[" s "] " g:51 => DiscrepancyLE f g s

@[inherit_doc]
notation:50 f:51 " ≈[" s "] " g:51 => DiscrepancyEquiv f g s

end AbcAdaptation.Reference
