import Definitions.Def_AbcAdaptation_Reference_Genl_Mathlib_Order_BoundedDiscrepancy
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true
#check @AbcAdaptation.Reference.DiscrepancyLE
#print AbcAdaptation.Reference.DiscrepancyLE
#print axioms AbcAdaptation.Reference.DiscrepancyLE
#check @AbcAdaptation.Reference.DiscrepancyEquiv
#print AbcAdaptation.Reference.DiscrepancyEquiv
#print axioms AbcAdaptation.Reference.DiscrepancyEquiv
