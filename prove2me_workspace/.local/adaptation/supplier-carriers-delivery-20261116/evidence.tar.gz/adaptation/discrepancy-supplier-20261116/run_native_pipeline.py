from pathlib import Path
import hashlib,json,subprocess,shutil,sys
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace');A=W/'.local/adaptation'
D=A/'discrepancy-supplier-20261116';C=A/'c2-complete-inputs-20261116'
def job(b,tag,source,*args):
 subprocess.run([sys.executable,str(b/'ci.py'),'submit',tag,source,*args],check=True)
 while True:
  r=subprocess.run([sys.executable,str(b/'ci.py'),'collect',tag],check=True,text=True,capture_output=True)
  print(r.stdout,flush=True)
  if (b/(tag+'-result.json')).exists(): break
job(D,'native-discrepancy-artifact-v1','Definitions/Def_AbcAdaptation_Reference_Genl_Mathlib_Order_BoundedDiscrepancy.lean','--artifact','--basis','Leaf ci-015864 passed17.66s with1.84GiB RSS; same source emitted as import artifact')
job(D,'native-discrepancy-types-axioms-v1',str((D/'QueryDiscrepancyDefinitions.lean').relative_to(W)),'--review','--purpose','Actual two discrepancy relation bodies/types and axiom review')
s=C/'candidate-handoff/draft/Definitions/Def_AbcAdaptation_Reference_Iut_Implication_Corollary22.lean'
assert hashlib.sha256(s.read_bytes()).hexdigest()=='14f7125eac5ed29745e509394f34bec7dc7d68886f51b2907388d5dbbb36a5db'
t=W/'Definitions'/s.name;assert not t.exists();shutil.copy2(s,t)
job(C,'native-c2-inputs-leaf-v1',str(t.relative_to(W)),'--purpose','Complete original C2 inputs16fields, P7 existence1field and threshold; preserve all hypotheses')
job(C,'native-c2-inputs-artifact-v1',str(t.relative_to(W)),'--artifact','--basis','Same unchanged source after successful native leaf;60s16GiB retained')
job(C,'native-c2-inputs-types-axioms-v1',str((C/'QueryCorollary22InputsP7.lean').relative_to(W)),'--review','--purpose','Actual C2 input/P7 structure full field types, threshold body and axioms')
print('NATIVE_PIPELINE_PASSED',flush=True)
