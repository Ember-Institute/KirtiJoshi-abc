# 五个 iut / Genl 定义来源对应的小单元

本目录只有离线草稿；没有 CI、Lean、API、Git 调用或主区写入。所有配置 `publish=false`。

五个数学 root 为 `Genl.HeightTheory`、`Iut.LocalHeightData.heightEq`、`Iut.LocalHeightData.heightOther`、`Iut.epsilonE`、`Iut.deltaBound`。已有source-export inventories及旧 PrimeSelection/Numeric Expr工件均未覆盖这些root的完整data值，检查见 `existing-artifact-coverage.json`；没有用元数据或仅theorem type代替来源对应。

`QuerySmallSupplierOriginalExprs.lean` 复用既有Source Expr exporter。`source-export-config.json` 只选择38个声明：HeightTheory完整原结构命令的30个compiler API/constructor/recursor/generated companions；heightEq/Other两个data定义；epsilonE/deltaBound及其generated companions共六项。`StatementI/II`是独立源码定义，明确排除。所有15字段、原完整type/value Expr、BinderInfo、计算metadata、recursor RHS和autoParam Expr都导出。原全模块总量检查改为38选中声明+七个prior LocalHeightData依赖的闭包检查；没有重新导出整库。

来源4.35.0-rc3的三个import为 `Genl.GeneralPosition.HeightTheory`、`Iut.Implication.PrimeSelection`、`Iut.Implication.Corollary22`，复用热缓存。Genl缓存中的原source与刚通过native叶所用frozen source SHA完全相同。已有结构化环境候选见 `source-environment-candidate.json`；root实际提交前仍需绑定当前路径和inputs，不沿用历史worktree manifest。

source导出入口环境变量为 `NEXT_CARRIER_EXPORT_CONFIG=/tmp/p2m-iut-small-supplier-identity-20261116/source-export-config.json`；首次资源预估60s/16GiB。它输出单个 `source-original-exprs.json`。实际accepted原Name来自原Env精确同owner lookup，配置nameExpr=null不是伪造acceptedName。

`AuditSmallSupplierIdentity.lean` 导入三个新native Definitions和既有PrimeSelection Definitions，复用原generic encode/decode、kernelTypeEq/kernelTermEq、compareRecord、computationShape/structureShape。原Expr按完整Name/.proj/universe/binder递归替换到目标，再与真实target ConstantInfo比较完整type、非Prop计算值、recursor RHS及全部结构字段/autoParam。Prop证明检查type和标准axioms。七个现有LocalHeightData依赖只作为已有carrier map使用，不宣称在本单元重新证明其data身份。没有initial-theta galK例外、adic replay、标准名字兼容替换或universe排列猜测。

目标审查配置 `audit-config.json` 的 `sourceReceiptBinding` 当前为null，故明确pending。root在source exporter实际通过后须填真实 `receiptPath`、完整 `receiptContents` 和 `sourceExprSha256`，同时把原Expr SHA和回执/config/query列入新的审查CI manifest。入口核对receipt终态、原配置、source schema/compiler及38条完整记录后才比较；不能凭native叶/类型公理通过就宣称身份。

若生成辅助名称或跨版本标准常量不匹配，入口列出实际missing/nonunique target Names并停止；没有fallback map、删除字段或证明替换。只有38条全部比较且五root均覆盖后才输出通过数据。所有input SHA、原native通过job、配置和入口SHA见 `handoff.json`。草稿没有编译验收，也不关闭数学父义务。
