#!/usr/bin/env python3
"""Generate one small source export and one existing-kernel based audit draft.
Offline only: all writes are confined to the assigned /tmp directory.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,json
R=Path('/home/admin-wsl/Coq/abc');A=R/'prove2me_workspace/.local/adaptation'
D=Path(__file__).resolve().parent
ROOTS=['Genl.HeightTheory','Iut.LocalHeightData.heightEq','Iut.LocalHeightData.heightOther','Iut.epsilonE','Iut.deltaBound']
DEPENDENCIES=['Iut.LocalHeightData','Iut.LocalHeightData.bad','Iut.LocalHeightData.deg','Iut.LocalHeightData.f','Iut.LocalHeightData.hv','Iut.LocalHeightData.p','Iut.LocalHeightData.ι']

def digest(b):return hashlib.sha256(b).hexdigest()
def ev(p):return {'path':str(p.resolve()),'sha256':digest(p.read_bytes())}
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def encode(n):
 x=[]
 for s in n.split('.'):x=[x,'str',s]
 return x

def main():
 assert D==Path('/tmp/p2m-iut-small-supplier-identity-20261116')
 graphpath=A/'reference-extraction-20261115/c22-decl-graph.jsonl'
 graph={r['name']:r for r in map(json.loads,graphpath.read_text().splitlines()) if r.get('record')=='decl'}
 selected={n:r for n,r in graph.items() if any(n==p or n.startswith(p+'.') for p in ROOTS) and n not in ['Genl.HeightTheory.StatementI','Genl.HeightTheory.StatementII']}
 assert len(selected)==38
 sourcepaths={
 'Genl.GeneralPosition.HeightTheory':Path('/home/admin-wsl/Coq/abc.old/refer/iut/.lake/packages/genl/Genl/GeneralPosition/HeightTheory.lean'),
 'Iut.Implication.PrimeSelection':R/'refer/iut/Iut/Implication/PrimeSelection.lean',
 'Iut.Implication.Corollary22':R/'refer/iut/Iut/Implication/Corollary22.lean'}
 targets={
 'Genl.GeneralPosition.HeightTheory':'Definitions.Def_AbcAdaptation_Reference_Genl_GeneralPosition_HeightTheory',
 'Iut.Implication.PrimeSelection':'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection_HeightParts',
 'Iut.Implication.Corollary22':'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs'}
 source_rows=[]
 for module,p in sourcepaths.items():
  source_rows.append({'module':module,'source':str(p),'sourceSha256':digest(p.read_bytes()),'normalizedSha256':digest(p.read_bytes().replace(b'\r\n',b'\n'))})
 genlfrozen=A/'genl-height-supplier-20261116/frozen/Genl/GeneralPosition/HeightTheory.lean'
 assert digest(genlfrozen.read_bytes())==next(r['sourceSha256'] for r in source_rows if r['module'].startswith('Genl.'))
 record_cfg=[]
 for n,r in selected.items():
  s=next(s for s in source_rows if s['module']==r['module'])
  record_cfg.append({'name':n,'nameExpr':None,'module':r['module'],'sourceSha256':s['sourceSha256'],
    'normalizedSha256':s['normalizedSha256'],'selected':True,'mathematicalRoot':n in ROOTS,
    'role':'root' if n in ROOTS else 'complete-source-structure-or-generated-command-companion'})
 config={'schema':'foundation-original-export-config-v2','compilerVersion':'4.35.0-rc3','publish':False,
 'expectedRecordCount':38,'expectedSelectedCount':38,'inventorySha256':digest(json.dumps(record_cfg,sort_keys=True).encode()),
 'graphSha256':digest(graphpath.read_bytes()),'outputFile':str(D/'source-original-exprs.json'),
 'sources':source_rows,'records':record_cfg,'mathematicalRoots':ROOTS,
 'approvedDependencyDisplays':DEPENDENCIES,
 'scope':'Five roots and full whole HeightTheory command API/constructors/recursors/autoParams/generated helpers only. StatementI/II excluded as separate source commands. Seven prior LocalHeightData dependencies are Name-bound, not re-proved.',
 'unmappedPolicy':'Any additional project dependency is pending; do not expand to a full library export.'}
 cfg=D/'source-export-config.json';write(cfg,config)
 originaltool=A/'reference-main-bound-carriers-20261115/QueryNextCarrierOriginalExprs.lean'
 text=originaltool.read_text();start=text.index('/-! Stable JSON')
 text='import Lean\nimport Genl.GeneralPosition.HeightTheory\nimport Iut.Implication.PrimeSelection\nimport Iut.Implication.Corollary22\n\n'+text[start:]
 text=text.replace('  let mut selectedCount := 0\n','  let mut selectedCount := 0\n  let mut observedProjectDeps : Array Name := #[]\n')
 text=text.replace('    let selected ← checked (entry.getObjValAs? Bool "selected")', '''    let exprs := #[ci.type] ++ value?.toArray ++ (match ci with
      | .recInfo r => r.rules.toArray.map (·.rhs)
      | _ => #[]) ++ (match getStructureInfo? (← getEnv) name with
      | some info => info.fieldInfo.filterMap (·.autoParam?)
      | none => #[])
    for e in exprs do
      for dep in e.getUsedConstants do
        if (#[`Genl, `Iut].any (·.isPrefixOf dep) || (moduleOf sourceEnv dep).any sourceModules.contains) && !observedProjectDeps.contains dep then
          observedProjectDeps := observedProjectDeps.push dep
    let selected ← checked (entry.getObjValAs? Bool "selected")''')
 old='''  unless actualOwned.size == seen.size && actualOwned.all seen.contains do
    throwError "Source-owned constant set differs from complete export inventory"
'''
 new='''  let approvedDisplays ← checked (config.getObjValAs? (Array String) "approvedDependencyDisplays")
  let mut approvedNames : Array Name := #[]
  let mut dependencyFacts : Array Json := #[]
  for display in approvedDisplays do
    let matches := actualNames[display]?.getD #[]
    unless matches.size == 1 do throwError "Pending approved dependency Name: {display}"
    let n := matches[0]!
    unless (`Iut.LocalHeightData).isPrefixOf n &&
        moduleOf sourceEnv n == some `Iut.Implication.PrimeSelection do
      throwError "Unexpected LocalHeightData dependency owner {n}"
    approvedNames := approvedNames.push n
    dependencyFacts := dependencyFacts.push (Json.mkObj [
      ("original", toJson n.toString), ("originalName", encodeName n),
      ("sourceOwner", toJson "Iut.Implication.PrimeSelection"),
      ("role", toJson "session-authorized existing LocalHeightData dependency map")])
  for n in observedProjectDeps do
    unless seen.contains n || approvedNames.contains n do
      throwError "Pending project dependency outside selected38/prior7: {n}"
'''
 assert old in text;text=text.replace(old,new)
 text=text.replace('("sources", Json.arr sourceRows), ("records", Json.arr records)',
                   '("sources", Json.arr sourceRows), ("approvedDependencyFacts", Json.arr dependencyFacts), ("records", Json.arr records)')
 sourcequery=D/'QuerySmallSupplierOriginalExprs.lean';sourcequery.write_text(text)
 # Existing 4.33 generic Expr/kernel primitives and compareRecord, with no legacy
 # compatibility fields. The body is separate and small for review.
 initialtool=A/'reference-initial-theta-carriers-20261115/AuditNextCarriers.template.lean'
 foundationtool=A/'foundation-reference-carriers-20261115/AuditFoundationCarriers.lean'
 initial=initialtool.read_text();foundation=foundationtool.read_text()
 copied=[]
 def take(path,text,start,end):
  i=text.index(start);j=text.index(end,i);chunk=text[i:j]
  copied.append({'source':ev(path),'startMarker':start,'endMarkerExclusive':end,'copiedBytesSha256':digest(chunk.encode())})
  return chunk
 b=take(initialtool,initial,'/-! Stable JSON','end FoundationAudit\nnamespace FoundationAudit')
 b+='end FoundationAudit\nnamespace FoundationAudit\nopen Lean Elab Term Meta\n\n'
 b+='structure Relocation where\n  original : Name\n  target : Name\n  permutation : Option (Array Nat)\n  expectedInstance : Option Bool\n  expectedAxioms : Option (Array Name)\n\nabbrev Relocations := Array Relocation\n\n'
 b+='def projectName (n : Name) : Bool :=\n  #[`Iut, `Genl, `AbcAdaptation, `Definitions, `Theorems, `Solutions].any (·.isPrefixOf n)\n\n'
 b+=take(foundationtool,foundation,'def relocated (rs : Relocations)','def readRelocations (config : Json)')
 b+=take(initialtool,initial,'def requireClosed (label : String)','def allowedOwner (rs : Relocations)')
 b+='def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do\n  pure ()\n\n'
 b+=take(initialtool,initial,'def auditDeclaration (rs : Relocations)','-- Paths distinguish binders')
 b+=take(initialtool,initial,'-- Paths distinguish binders','def boundPlatformHelperEvidence')
 compare=take(initialtool,initial,'def compareRecord (rs : Relocations)','def audit : TermElabM Unit')
 compare=compare.replace('  let signatureRs := { rs with sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[] }\n','').replace('decodeExpr signatureRs','decodeExpr rs')
 compare=compare.replace('unexpanded-original-exported-signature-after-named-relocation-vs-actual-target-type','actual-exported-4.35-source-type-after-exact-name-relocation-vs-actual-4.33-target-type')
 b+=compare
 write(D/'reused-function-blocks.json',{'schema':'small-supplier-generic-functions-source-blocks/v1','blocks':copied,'modifications':'compareRecord removes the empty legacy compatibility-array copy and uses exact ordinary relocation for both signature reads; no compatibility Expr decoder is copied.'})
 a=b.index('def allowedOwner (rs : Relocations)');z=b.index('def auditDeclaration (rs : Relocations)',a)
 b=b[:a]+'''def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No owner {name}"
  unless modules.contains owner do throwError "Forbidden dependency {name}, owner {owner}"
  if #[`Iut, `Genl].any (·.isPrefixOf name) then
    throwError "Pending unrelocated source dependency {name}"
  if (`AbcAdaptation).isPrefixOf name && !(rs.any (·.target == name)) then
    throwError "Pending unmapped target dependency {name}"

'''+b[z:]
 auditimports='import Lean\n'+''.join('import '+m+'\n' for m in targets.values())
 auditimports+='import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection\n\n'
 auditquery=D/'AuditSmallSupplierIdentity.lean';auditquery.write_text(auditimports+b+(D/'audit-entry-body.lean.txt').read_text())
 maps=[]
 for n,r in selected.items():
  maps.append({'original':n,'target':'AbcAdaptation.Reference.'+n,'targetOwner':targets[r['module']],
  'expectedIsInstance':r['isInstance'],'expectedSourceAxioms':[encode(a) for a in r['axioms']],
  'targetToSourceUniverseIndices':None,'role':'root' if n in ROOTS else 'source-command-generated-or-structure-api-candidate',
  'targetNameStatus':'runtime exact Name resolution at expected module; missing generated names stay pending'})
 deps=[{'original':n,'target':'AbcAdaptation.Reference.'+n,'targetOwner':'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_PrimeSelection',
   'role':'existing-carrier-map dependency; not a new data-value identity claim'} for n in DEPENDENCIES]
 auditcfg={'schema':'small-supplier-identity-config/v1','publish':False,'sourceReceiptBinding':None,'sourceExprFile':str(D/'source-original-exprs.json'),
 'sourceExportConfig':ev(cfg),'expectedRecordCount':38,'mathematicalRoots':ROOTS,'projectMap':maps,'priorDependencies':deps,
 'standardRenames':[],'proofValueSubstitutions':[],'outputFile':str(D/'small-supplier-kernel-result.json'),
 'dependencyMapEvidence':[ev(A/'prime-selection-reference-split-20261115/original-wrapped-type-name-map.json'),
  ev(A/'prime-selection-reference-split-20261115/type-audits/Iut-LocalHeightData-exists_prime_selection.json'),
  ev(A/'prime-selection-reference-split-20261115/definition-compiler-field-review.json')],
 'status':'source Expr export pending; runtime source receipt binding and target generated Name resolution required before acceptance'}
 auditcfgpath=D/'audit-config.json';write(auditcfgpath,auditcfg)
 # Explicitly record inspected source inventories instead of claiming absence in
 # arbitrary unsearched caches. None covers the five required full value roots.
 coverage=[]
 for folder,filename in [('foundation-reference-carriers-20261115','export-config.json'),('reference-initial-theta-carriers-20261115','export-config.json'),
  ('reference-main-bound-carriers-20261115','source-export-config.json'),('reference-packet-field-carriers-20261115','export-config.json'),
  ('reference-tate-theta-carriers-20261115','export-config.json'),('reference-volume-tate-carriers-20261115','export-config.json')]:
  p=A/folder/filename;x=load(p);found=[r['name'] for r in x['records'] if r.get('name') in ROOTS]
  coverage.append({'inventory':ev(p),'rootRecordsPresent':found})
 assert not any(r['rootRecordsPresent'] for r in coverage)
 write(D/'existing-artifact-coverage.json',{'schema':'small-supplier-existing-export-coverage/v1','inspectedInventories':coverage,
 'oldPrimeSelectionOriginalExprs':ev(A/'prime-selection-reference-split-20261115/original-exprs.json'),
 'oldNumericOriginalExprs':ev(A/'main-c22-numeric-helpers-20261115/source-facts/original-exprs.json'),
 'result':'Inspected source-export inventories do not contain the five roots; old PrimeSelection/Numeric artifacts contain only other theorem types. New minimal selected38 Expr export required.'})
 write(D/'selected-graph-rows.json',{'roots':ROOTS,'excludedSeparateDefinitions':['Genl.HeightTheory.StatementI','Genl.HeightTheory.StatementII'],'declarations':list(selected.values())})
 receipts=[]
 for folder,ns in [('genl-height-supplier-20261116',['genl-height-theory-leaf-v1','genl-height-theory-types-axioms-v1','local-height-parts-leaf-v1','local-height-parts-types-axioms-v1']),('main-chain-native-minimal-20261116',['numeric-inputs-leaf-v1'])]:
  for n in ns:
   p=A/folder/(n+'-result.json');x=load(p);assert x['status']=='succeeded' and x['result']['exit_code']==0
   receipts.append({'job_id':x['job_id'],'receipt':ev(p)})
 targetfiles=[R/'prove2me_workspace'/Path(m.replace('.','/')).with_suffix('.lean') for m in targets.values()]
 inputs=[graphpath,originaltool,initialtool,foundationtool,genlfrozen,Path(__file__),D/'audit-entry-body.lean.txt',*sourcepaths.values(),*targetfiles]
 handoff={'schema':'iut-small-supplier-identity-handoff/v1','publish':False,'mathematicalRoots':ROOTS,
 'sourceExport':{'query':ev(sourcequery),'config':ev(cfg),'environment':{'NEXT_CARRIER_EXPORT_CONFIG':str(cfg)},'compiler':'4.35.0-rc3','expected_duration':'60s','expected_memory':'16GiB'},
 'targetAudit':{'query':ev(auditquery),'config':ev(auditcfgpath),'environment':{'SMALL_SUPPLIER_AUDIT_CONFIG':str(auditcfgpath)},'compiler':'4.33.1','expected_duration':'60s','expected_memory':'16GiB'},
 'nativeReceipts':receipts,'inputEvidence':[ev(p) for p in inputs],
 'counts':{'mathematicalRoots':5,'selectedSourceRecords':38,'GenlWholeStructureAndCompanions':30,'GenlFields':15,'priorDependencyNames':7},
 'toolReuse':'Original exporter encodeExpr/structure metadata/value writer retained. Only imports and full-module-total guard become a selected38/project-closure check. Target uses existing encode/decode, kernelTypeEq, kernelTermEq and compareRecord without compatibility values.',
 'next':'Root first submits minimal4.35 source export. Bind actual terminal receipt and actual output SHA before target audit/acceptance. Draft auditor has no source receipt yet and cannot be accepted from native leaf/type/metadata alone.',
 'pending':['Actual selected38 source Expr export and receipt binding.','Actual target generated Name resolution, complete type/data/recursor/structure kernel comparisons.',
 'No standard rename or proof substitution is configured; any cross-version constant/binder/value difference stays pending.'],
 'validation':'Offline preparation only; no CI/Lean/API/Git or main workspace writes.'}
 write(D/'handoff.json',handoff)
 print(json.dumps({'sourceQuery':ev(sourcequery),'sourceConfig':ev(cfg),'auditQuery':ev(auditquery),'counts':handoff['counts']},ensure_ascii=False))

if __name__=='__main__':main()
