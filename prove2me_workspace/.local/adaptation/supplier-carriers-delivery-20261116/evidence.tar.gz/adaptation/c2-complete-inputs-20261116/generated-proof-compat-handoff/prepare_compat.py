#!/usr/bin/env python3
"""Extend the current root C2 auditor at three exact proof-only boundaries."""
import sys
sys.dont_write_bytecode = True
import json, hashlib
from pathlib import Path

D = Path(__file__).resolve().parent
W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A = W / '.local/adaptation'
C = A / 'c2-complete-inputs-20261116'
S = A / 'small-supplier-identity-20261116'
def load(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p): return {'path': str(p), 'sha256': sha(p)}
def save(p, x): p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')
def replace_once(s, old, new):
    assert s.count(old) == 1, old
    return s.replace(old, new)

def main():
    assert D == Path('/tmp/p2m-main-bound-candidates-v8-20261115/c2-generated-proof-compat-20261116')
    base = C / 'AuditPackageIdentity.lean'
    text = base.read_text()
    original = text
    assert 'Pending computational value BinderInfo inventory/placement difference' in text
    assert 'Pending recursor RHS BinderInfo inventory/placement difference' in text
    compare_start = text.index('def compareRecord (rs : Relocations)')
    compare_end = text.index('-- The source file is produced', compare_start)
    original_compare = text[compare_start:compare_end]
    cfg = load(C / 'audit-config.json')
    assert len(cfg['projectMap']) == 44 and len(cfg['priorDependencies']) == 37
    source44 = load(C / 'source-original-exprs.json')
    source38 = load(S / 'source-original-exprs.json')
    source44_records = {r['name']: r for r in source44['records']}
    source38_records = {r['name']: r for r in source38['records']}
    proof4 = 'Iut.Corollary22Inputs.threshold._proof_4'
    native = 'AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_'
    row, = [r for r in cfg['projectMap'] if r['original'] == proof4]
    row['target'] = native + '6'
    row['targetNameStatus'] = 'one exact source-backed generated-proof name exception; kernel type/axiom checks required'
    small_receipt = load(S / 'source-exprs-v2-result.json')
    assert small_receipt['status'] == 'succeeded' and small_receipt['job_id'] == 'ci-015877-23714e2c'
    small_config = Path(small_receipt['request']['environment']['NEXT_CARRIER_EXPORT_CONFIG'])
    native_receipt_path = C / 'native-threshold-generated-proofs-v1-result.json'
    native_receipt = load(native_receipt_path)
    assert native_receipt['status'] == 'succeeded' and native_receipt['job_id'] == 'ci-015938-ebf02a01'
    assert native_receipt['result']['exit_code'] == 0
    native_query = C / 'QueryThresholdGeneratedProofs.lean'
    assert native_receipt['result']['snapshot']['manifest']['source_sha256'] == sha(native_query)
    compat = {
        'schema': 'c2-three-source-backed-generated-proofs/v1',
        'literalSourceBinding': {'receiptPath': str(S / 'source-exprs-v2-result.json'), 'receiptContents': small_receipt,
                                 'sourceExprFile': str(S / 'source-original-exprs.json'), 'sourceExprSha256': sha(S / 'source-original-exprs.json'),
                                 'sourceExportConfigPath': str(small_config), 'sourceExportConfigSha256': sha(small_config)},
        'nativeProofQueryBinding': {'receiptPath': str(native_receipt_path), 'receiptContents': native_receipt,
                                    'querySha256': sha(native_query), 'query': pin(native_query)},
        'exactRenamedOriginalProof': {'original': proof4, 'target': native + '6'},
        'targetOnlyGeneratedProofs': [
            {'target': native + '4', 'sourceEvidence': 'Iut.epsilonE._proof_2', 'namedIdentityClaimed': False},
            {'target': native + '5', 'sourceEvidence': 'Iut.epsilonE._proof_1', 'namedIdentityClaimed': False}],
        'dataValueSubstitutions': [], 'newAliases': [], 'rawNamespacePrefixIdentity': False,
        'publishAllowed': False, 'finalAcceptance': False}
    cfg['generatedProofCompatibility'] = compat
    cfg['outputFile'] = str(D / 'kernel-identity-result.json')
    cfg['status'] = 'three exact proof-only compatibility checks pending actual native helper receipt and kernel acceptance'
    # Permit additional dependency Names only after the caller obtains the two
    # exact source-backed proof certificates. No Relocations alias is added.
    text = replace_once(text,
        'def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do',
        'def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name)\n    (certifiedGeneratedProofs : Array Name := #[]) : MetaM Unit := do')
    text = replace_once(text,
        'if (`AbcAdaptation).isPrefixOf name && !(rs.any (·.target == name)) then',
        'if (`AbcAdaptation).isPrefixOf name &&\n      !(rs.any (·.target == name)) && !certifiedGeneratedProofs.contains name then')
    text = replace_once(text,
        'def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Json := do',
        'def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name)\n    (certifiedGeneratedProofs : Array Name := #[]) : MetaM Json := do')
    # Both calls inside auditDeclaration keep the same owner and axiom checks.
    assert text.count('allowedOwner rs modules dep') == 2
    text = text.replace('allowedOwner rs modules dep', 'allowedOwner rs modules dep certifiedGeneratedProofs')
    helpers = (D / 'compat-helpers.lean.txt').read_text()
    marker = '-- The source file is produced by the small existing Expr exporter'
    text = replace_once(text, marker, helpers + '\n' + marker)
    text = replace_once(text,
        '  let env ← getEnv\n  let configured ← checked (arrayField cfg "projectMap")',
        '''  let compat ← checked (field cfg "generatedProofCompatibility")
  unless (← checked (stringField compat "schema")) == "c2-three-source-backed-generated-proofs/v1" do
    throwError "Unexpected generated-proof compatibility scope"
  unless (← checked (arrayField compat "dataValueSubstitutions")).isEmpty &&
      (← checked (arrayField compat "newAliases")).isEmpty do
    throwError "No data substitution or new alias is allowed"
  requireNativeGeneratedProofReceipt compat
  let literalRecords ← boundSmallLiteralSource compat
  let env ← getEnv
  let configured ← checked (arrayField cfg "projectMap")''')
    text = replace_once(text,
        '''    unless target == `AbcAdaptation.Reference ++ original do
      throwError "Pending generated relocation differs from exact namespace-prefix candidate {display}"''',
        '''    unless target == `AbcAdaptation.Reference ++ original do
      unless original == `Iut.Corollary22Inputs.threshold._proof_4 &&
          target == `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_6 do
        throwError "Pending generated relocation differs from exact namespace-prefix candidate {display}"
      let exception ← checked (field compat "exactRenamedOriginalProof")
      unless (← checked (stringField exception "original")) == original.toString &&
          (← checked (stringField exception "target")) == target.toString do
        throwError "Exact source-backed generated-proof rename configuration differs"''')
    text = replace_once(text,
        '  let mut comparisons := #[]\n  let mut targetAudits := #[]',
        '''  let originalProof4 ← checkedProofRecord records `Iut.Corollary22Inputs.threshold._proof_4
  let renamedProofCertificate ← certifyGeneratedProof rs allowed originalProof4
    `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_6 "one exact original generated-proof rename"
  let sourceLiteral2 ← checkedProofRecord literalRecords `Iut.epsilonE._proof_2
  let sourceLiteral60 ← checkedProofRecord literalRecords `Iut.epsilonE._proof_1
  let targetProof4 ← resolveNativeGeneratedProof `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_4
  let targetProof5 ← resolveNativeGeneratedProof `AbcAdaptation.Reference.Iut.Corollary22Inputs.threshold._proof_5
  let extra2Certificate ← certifyGeneratedProof rs allowed sourceLiteral2 targetProof4
    "target-only generated proof backed by actual original epsilonE literal2 proof; no named identity"
  let extra60Certificate ← certifyGeneratedProof rs allowed sourceLiteral60 targetProof5
    "target-only generated proof backed by actual original epsilonE literal60 proof; no named identity"
  let certifiedGeneratedProofs := #[targetProof4, targetProof5]
  let extraRows ← checked (arrayField compat "targetOnlyGeneratedProofs")
  unless extraRows.size == 2 do throwError "Expected exactly two source-backed target-only generated proofs"
  for row in extraRows do
    let sourceDisplay ← checked (stringField row "sourceEvidence")
    let targetDisplay ← checked (stringField row "target")
    unless !(← checked (row.getObjValAs? Bool "namedIdentityClaimed")) &&
        ((sourceDisplay == "Iut.epsilonE._proof_2" && targetDisplay == targetProof4.toString) ||
         (sourceDisplay == "Iut.epsilonE._proof_1" && targetDisplay == targetProof5.toString)) do
      throwError "Unexpected source-backed target-only proof configuration"
  let actualTargetClosure := env.constants.fold (fun acc n _ =>
    if moduleOf env n == some `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22 &&
        ((`AbcAdaptation.Reference.Iut.Corollary22Inputs).isPrefixOf n ||
         (`AbcAdaptation.Reference.Iut.ThetaDataExistence).isPrefixOf n) &&
        !(`AbcAdaptation.Reference.Iut.Corollary22Inputs.c2).isPrefixOf n then acc.push n else acc) (#[] : Array Name)
  let configuredTargets ← configured.mapM fun row => do
    let originalDisplay ← checked (stringField row "original")
    let sourceRecord := records.find? fun r => (stringField r "name").toOption == some originalDisplay
    let some sourceRecord := sourceRecord | throwError "Missing actual configured source Name {originalDisplay}"
    let original ← checked (decodeName (← checked (field sourceRecord "nameExpr")))
    let some rel := rs.find? (·.original == original) | throwError "Missing configured target Name {original}"
    pure rel.target
  unless actualTargetClosure.size == 46 && configuredTargets.size == 44 &&
      actualTargetClosure.all (fun n => configuredTargets.contains n || certifiedGeneratedProofs.contains n) do
    throwError "Actual target C2/P7 closure differs from original44 plus the two certified generated proofs"
  let mut comparisons := #[]
  let mut targetAudits := #[]''')
    text = replace_once(text,
        '    comparisons := comparisons.push (← compareRecord rs allowed record target)\n    targetAudits := targetAudits.push (← auditDeclaration rs allowed target.name)',
        '''    let comparison ← compareRecord rs allowed record target
    comparisons := comparisons.push (Json.mkObj [
      ("completeComparison", comparison),
      ("rawNamespacePrefixNameEqual", toJson (target.name == `AbcAdaptation.Reference ++ original)),
      ("exactGeneratedProofRenameUsed", toJson (original == `Iut.Corollary22Inputs.threshold._proof_4))])
    targetAudits := targetAudits.push (← auditDeclaration rs allowed target.name certifiedGeneratedProofs)''')
    text = replace_once(text,
        '    ("compatibilitySubstitutions", Json.arr #[]), ("hasSorryAx", toJson false),',
        '''    ("compatibilitySubstitutions", Json.arr #[]), ("hasSorryAx", toJson false),
    ("rawNamespacePrefixIdentity", toJson false),
    ("sourceBackedGeneratedProofRename", renamedProofCertificate),
    ("sourceBackedTargetOnlyGeneratedProofs", Json.arr #[extra2Certificate, extra60Certificate]),
    ("targetGeneratedClosureCount", toJson actualTargetClosure.size),
    ("sourceGeneratedClosureCount", toJson configuredTargets.size),
    ("newMathematicalAliases", Json.arr #[]), ("dataValueSubstitutions", Json.arr #[]),
    ("generatedProofCompatibility", compat),''')
    # The root-enhanced full comparison implementation is copied without any
    # edit, including both new BinderInfo checks for values and recursor RHS.
    a = text.index('def compareRecord (rs : Relocations)')
    b = text.index('-- Three source-backed generated-proof checks.', a)
    assert text[a:b] == original_compare
    audit_path = D / 'AuditC2GeneratedProofCompatibility.lean'
    audit_path.write_text(text)
    save(D / 'audit-config.json', cfg)
    save(D / 'actual-source-proof-facts.json', {
        'source44': pin(C / 'source-original-exprs.json'), 'source38': pin(S / 'source-original-exprs.json'),
        'source44Receipt': pin(C / 'source-identity-exprs-v3-result.json'), 'source38Receipt': pin(S / 'source-exprs-v2-result.json'),
        'records': [source44_records[proof4], source38_records['Iut.epsilonE._proof_2'], source38_records['Iut.epsilonE._proof_1']],
        'nativeProofQueryReceipt': pin(native_receipt_path), 'nativeProofFactsPending': False,
        'nativeProofTypesConfirmedByActualReceipt': {'proof4': '(1+1).AtLeastTwo', 'proof5': '(59+1).AtLeastTwo', 'proof6': '(3+1).AtLeastTwo'},
        'publishAllowed': False, 'finalAcceptance': False})
    save(D / 'handoff.json', {'schema': 'exact-c2-generated-proof-compatibility-draft/v1',
        'auditQuery': pin(audit_path), 'auditConfig': pin(D / 'audit-config.json'),
        'baseRootAuditor': pin(base), 'baseRootConfig': pin(C / 'audit-config.json'),
        'preservedFullCompareRecordSha256': hashlib.sha256(original_compare.encode()).hexdigest(),
        'rootDataAndRecursorBinderInfoChecksPreservedByteForByte': True,
        'baseSource44Receipt': pin(C / 'source-identity-exprs-v3-result.json'),
        'original44ObligationsRetained': True, 'source44RecordCount': len(source44['records']),
        'prior37MappingRetainedExceptOriginalThresholdProof4TargetName': True,
        'extraTargetOnlyProofsAreNotNameMappings': True,
        'rawNamespacePrefixIdentity': False, 'dataValueSubstitutions': [], 'newAliases': [],
        'nativeProofQueryReceipt': pin(native_receipt_path),
        'pending': ['Source44 receipt binding by root.',
                    'Actual kernel type/axiom certificates and all44 full comparisons.'],
        'compilerRun': False, 'CIInvoked': False, 'platformAPIInvoked': False, 'gitInvoked': False,
        'mainWorkspaceWritten': False, 'publishAllowed': False, 'finalAcceptance': False})
    print(json.dumps({'query': pin(audit_path), 'config': pin(D / 'audit-config.json'),
                      'preservedCompareRecordSha256': hashlib.sha256(original_compare.encode()).hexdigest()}, indent=2))

if __name__ == '__main__': main()
