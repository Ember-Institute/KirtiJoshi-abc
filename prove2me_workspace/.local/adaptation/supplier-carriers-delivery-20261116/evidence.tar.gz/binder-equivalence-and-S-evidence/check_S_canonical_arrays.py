#!/usr/bin/env python3
"""Check v5 canonical path trees against S's20 actual original array hashes.

Offline serialization/comparer regression only. No compiler or CI call.
"""
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ANALYSIS = HERE.parent / 'serialization-analysis'
spec = importlib.util.spec_from_file_location('existing_S_array_reference', ANALYSIS / 'reconstruct_S_binder_arrays.py')
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)


def main():
    report = json.loads((ANALYSIS / 'S-report-with-binder-arrays-omitted-for-analysis.json').read_text())
    originals = json.loads((ANALYSIS / 'S-binder-array-sizes.json').read_text())
    dag = report['sharedLosslessExpressionEvidence']['exprDag']['nodes']
    # Canonical zero represents an empty traversal. The same table serves every
    # source and target node, and keys contain exact tags and child IDs.
    canonical = [{'kind': 'sort'}]
    key_ids, refs = {}, []
    def intern(key, node):
        if key not in key_ids:
            key_ids[key] = len(canonical)
            canonical.append(node)
        return key_ids[key]
    for node in dag:
        kind = node['kind']
        if kind in ['forall', 'lam']:
            d, b = refs[node['type']], refs[node['body']]
            result = intern((kind, node['binder'], d, b),
                {'kind': kind, 'binder': node['binder'], 'type': d, 'body': b})
        elif kind == 'app':
            f, a = refs[node['fn']], refs[node['arg']]
            result = 0 if f == a == 0 else intern((kind, f, a), {'kind': kind, 'fn': f, 'arg': a})
        elif kind == 'let':
            t, v, b = refs[node['type']], refs[node['value']], refs[node['body']]
            result = 0 if t == v == b == 0 else intern((kind, t, v, b),
                {'kind': kind, 'type': t, 'value': v, 'body': b})
        elif kind == 'proj':
            b = refs[node['body']]
            result = 0 if b == 0 else intern((kind, b), {'kind': kind, 'body': b})
        else:
            assert kind in {'sort', 'const', 'bvar', 'nat', 'string'}
            result = 0
        refs.append(result)
    signature = report['report']
    rows = []
    for i, slot in enumerate(signature['changedDataSlots']):
        for side, field in [('source', 'completeFaithfulReplaySignature'), ('target', 'completeTargetSignature')]:
            raw_ref = reference.locate(dag, signature[field]['root'], slot['path'])
            for traversal in ['Inventory', 'Placement']:
                key = side + 'RawBinder' + traversal
                order = ['sourceRawBinderInventory', 'sourceRawBinderPlacement', 'targetRawBinderInventory', 'targetRawBinderPlacement']
                expected = originals['rows'][4 * i + order.index(key)]
                digest, size, count = reference.array_hash(reference.strings(canonical, refs[raw_ref], traversal == 'Placement'))
                assert (digest, size, count) == (expected['sha256'], expected['bytes'], expected['items']), (i, key)
                rows.append({'slot': i, 'key': key, 'exactHashBytesAndItemsMatch': True,
                    'sha256': digest, 'bytes': size, 'items': count})
                print(json.dumps({'slot': i, 'key': key, 'match': True}), flush=True)
    view_source = refs[signature['sourceBinderView']['root']]
    view_target = refs[signature['targetBinderView']['root']]
    assert view_source == view_target
    result = {'status': 'offline original-S regression; not a compiler receipt',
        'originalDagNodes': len(dag), 'canonicalPathTreeNodesIncludingEmpty': len(canonical),
        'all20OriginalArraysMatchFromCanonicalPathTrees': True,
        'accountedSourceAndTargetBinderViewsCanonicalIdsEqual': True, 'arrays': rows}
    out = HERE / 'S-canonical-array-regression.json'
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'result': str(out), 'canonicalPathTreeNodesIncludingEmpty': len(canonical)}))


if __name__ == '__main__':
    main()
