"""Offline p5-only theorem/proof packet from the accepted actual source oracle."""
from pathlib import Path
import hashlib
import json
import shutil

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
UNIT = W / '.local/adaptation/main-chain-open-20261116'
GEN = UNIT / 'tools/generated'
OUT = Path('/tmp/p2m-main-p5-publisher-v9-20261116')
NAME = 'AbcAdaptation.Reference.Iut.p5_height_bound'
RB = Path('/tmp/p2m-main-proof-trilingual-b-v9-20261116/trilingual-readbacks.json')
PAPER = W / '.local/adaptation/supplier-carriers-delivery-20261116/paper-context/paper-context.json'
ENV = '0df444a360eaa60ab8c11dca51a86af692955474'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def nodes(node):
    yield node
    for child in node.get('children', []):
        yield from nodes(child)


def prepare():
    index_path = GEN / 'oracle-output/Iut_p5_height_bound/index.json'
    index = json.loads(index_path.read_text())
    receipt_path = UNIT / 'source-oracle-p5-height-v1-result.json'
    receipt = json.loads(receipt_path.read_text())
    assert receipt['job_id'] == 'ci-016006-2107ae17' and receipt['status'] == 'succeeded'
    assert receipt['result']['exit_code'] == 0 and index['complete'] is True
    result, = index['results']
    assert result['status'] == 'success'
    facts_path, coordinate_path = map(Path, [result['output'], result['coordinateSource']])
    raw = coordinate_path.read_bytes()
    assert sha(coordinate_path) == index['config']['files'][0]['normalizedSha256']
    facts = [json.loads(line) for line in facts_path.read_text().splitlines()]
    decl, = [r for r in facts if r['kind'] == 'decl' and r.get('nameText') == 'p5_height_bound']
    assert decl['generationIssue'] is None and decl['privateTok'] is None
    a, b = decl['declStart']['offset'], decl['declEnd']['offset']
    na, nb = [decl['nameRange'][k]['offset'] for k in ['start', 'end']]
    va, vb = decl['valStart']['offset'], decl['valueRange']['end']['offset']
    assert raw[na:nb] == b'p5_height_bound' and raw[va:va+5] == b':= by'
    assert vb == b
    # Actual AST binder groups, not a regex analysis of the signature.
    signature, = decl['signatureSyntax']
    binders = [n for n in nodes(signature) if n['syntaxKind'] in [
        'Lean.Parser.Term.implicitBinder', 'Lean.Parser.Term.explicitBinder']]
    assert sum(n['syntaxKind'].endswith('.implicitBinder') for n in binders) == 1
    assert sum(n['syntaxKind'].endswith('.explicitBinder') for n in binders) == 9
    signature_bytes = raw[nb:va]
    assert b'_hr0' in signature_bytes
    body = raw[va:vb]
    source_meta_path = GEN / 'metadata/Iut_p5_height_bound.json'
    source_meta = json.loads(source_meta_path.read_text())
    assert hashlib.sha256(body).hexdigest() == source_meta['originalBodyHashes'][0]
    assert raw[a:b] + b'\n' == Path(source_meta['originalWholeCommand']['path']).read_bytes()
    repository_path = W.parent / 'refer/iut/Iut/Implication/Corollary22.lean'
    repository_raw = repository_path.read_bytes()
    assert repository_raw.count(raw[a:b]) == 1
    repository_start = repository_raw.index(raw[a:b])
    repository_first_line = repository_raw[:repository_start].count(b'\n') + 1
    repository_last_line = repository_raw[:repository_start + b-a].count(b'\n') + 1
    source_url = ('https://github.com/lana-agents/iut/blob/07cb1da58f6d428a670dbb5dd6093d428bcbcdd8/'
        + 'Iut/Implication/Corollary22.lean#L' + str(repository_first_line) + '-L' + str(repository_last_line))
    proof_refs = [r for r in facts if r['kind'] == 'ref' and va <= r['start']['offset'] < r['end']['offset'] <= vb]
    assert not any(r['const'].startswith(('Iut.', 'Genl.')) for r in proof_refs)

    candidate = Path('/tmp/p2m-main-pure-helpers-v9-20261116/Theorems/Thm_AbcAdaptation_Reference_Iut_p5_height_bound.lean').read_text()
    imports = [line for line in candidate.splitlines() if line.startswith('import ')]
    assert imports and all(line.startswith('import Mathlib.') for line in imports)
    notice = '''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
'''
    preamble = notice + '\n'.join(imports) + '''

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open Finset Real

'''
    formal = 'theorem ' + NAME + signature_bytes.decode() + ':= by sorry'
    solution_prefix = preamble + 'theorem solution' + signature_bytes.decode()
    solution = solution_prefix.encode() + body + b'\n'
    stub = (preamble + formal + '\n').encode()
    theorem_rel = 'Theorems/Thm_' + NAME.replace('.', '_') + '.lean'
    solution_rel = 'Solutions/Sol_' + NAME.replace('.', '_') + '.lean'
    for rel, content in [(theorem_rel, stub), (solution_rel, solution)]:
        path = OUT / 'staging' / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    original = OUT / 'source-evidence/Original_p5_height_bound.lean'
    original.parent.mkdir(parents=True, exist_ok=True)
    original.write_bytes(raw[a:b] + b'\n')
    shutil.copyfile(W / '.local/adaptation/reference-extraction-20261115/LICENSE.iut.Apache-2.0', OUT / 'LICENSE.iut.Apache-2.0')

    rb_all = json.loads(RB.read_text())
    rb, = [r for r in rb_all['nodes'] if r['sourceName'] == 'Iut.p5_height_bound']
    frozen = rb_all['frozen_english_source']
    assert sha(frozen['path']) == frozen['sha256'] == sha(frozen['byte_exact_copy'])
    assert rb['readbacks']['en'] == rb['originalEnglish'] == rb['readback']
    assert hashlib.sha256(rb['readbacks']['en'].encode()).hexdigest() == rb['english_readback_utf8_sha256']
    assert len(rb['binder_analysis']['implicit']) == 6 and len(rb['binder_analysis']['explicit']) == 9
    assert rb['binder_analysis']['explicit'][2] == '_hr0 : 0 ≤ r'
    trilingual = '\n\n'.join('**' + title + '**\n\n' + rb['readbacks'][lang]
        for lang, title in [('en', 'English'), ('zh_Hans', '简体中文'), ('ja', '日本語')])
    papers = json.loads(PAPER.read_text())
    quote, = [q for q in papers['quotations'] if q['id'] == 'IV-p5-p6']
    assert quote['paper'] == 'IV' and quote['printed_pages'] == [46]
    metadata_hashes = {str(p): sha(p) for p in [index_path, receipt_path, facts_path,
        coordinate_path, source_meta_path, Path(source_meta['originalWholeCommand']['path']), RB,
        Path(frozen['path']), Path(frozen['byte_exact_copy']), PAPER, repository_path, OUT / 'LICENSE.iut.Apache-2.0']}
    for item in quote['evidence']:
        for value in item.values():
            if isinstance(value, dict) and 'path' in value and 'sha256' in value:
                assert sha(value['path']) == value['sha256']
                metadata_hashes[value['path']] = value['sha256']
    note = ('This is a local real inequality in the reference Lean proof of the (P5) argument. '
        'Its scalar lg is an arbitrary real parameter constrained by the displayed hypotheses; '
        'it is not defined as a logarithm in this theorem. In the source consumer '
        'Iut.Corollary22Inputs.c2 it is instantiated after bounding log(ℓ), with r and s '
        'representing successive square roots. The inequality helps bound the height in the '
        'exceptional case. It does not construct a bad-reduction place, initial theta data, '
        'or a full geometric proof of (P5). The paper paragraph below provides the (P5) '
        'context; it does not state this scalar lemma or its fourth-power constant verbatim.')
    status_note = ('The independent readback above was frozen from a statement stub and its '
        'original proof-status sentences are preserved. The separate solution file copies '
        'the complete reference proof body. Source/target compiled-type identity, native '
        'typechecking and axiom acceptance are separate root-supplied gates; the frozen '
        'readback itself is not evidence that those gates have passed.')
    quotation = '> ' + quote['quote_markdown'] + '\n\n— Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV*, ' + quote['locator'] + ', printed p. 46.'
    description = ('**Independent formal-code readback (frozen statement-stub input)**\n\n' + trilingual +
        '\n\n**Implementation and proof-status context (separate from frozen readback)**\n\n' + status_note +
        '\n\n**Paper source context (English)**\n\n' + note +
        '\n\n**Original paper paragraph**\n\n' + quotation +
        '\n\nOriginal paper: ' + papers['paper_sources']['IV']['official_url'])
    payload = {'theorem_name': NAME, 'theorem_title': 'A local real height bound for the (P5) argument — （P5）论证中的局部实数高度界 — (P5) の議論の局所的な実数高さ評価',
        'preamble': preamble, 'formal_statement': formal, 'natural_language_statement': description,
        'source': source_url,
        'env': ENV, 'private': True}
    save(OUT / 'payload.json', payload)
    save(OUT / 'frozen-p5-readback.json', rb)
    save(OUT / 'source-proof-evidence.json', {'oracleJob': receipt['job_id'], 'actualDeclaration': decl,
        'sourceProofSha256': hashlib.sha256(body).hexdigest(), 'sourceSignatureSha256': hashlib.sha256(signature_bytes).hexdigest(),
        'solutionProofByteRange': [len(solution_prefix.encode()), len(solution_prefix.encode()) + len(body)],
        'originalCommandSha256': hashlib.sha256(raw[a:b]).hexdigest(), 'proofRefs': proof_refs,
        'repositoryOriginalCommand': {'path': str(repository_path), 'sha256': sha(repository_path), 'matchedByteRange': [repository_start, repository_start + b-a], 'matchedLines': [repository_first_line, repository_last_line], 'url': source_url},
        'actualSourceProjectProofDependencies': [], 'implicitParameters': 6, 'explicitConditions': 9,
        'unneeded_hr0Preserved': True, 'sourceCompiledTypeExpr': None,
        'sourceTargetCompiledTypeIdentityAccepted': False,
        'scope': 'Actual source proof-command oracle and AST-derived exact signature/body; compiled-type equality is pending root, not inferred from AST.'})
    tag = NAME.replace('.', '_')
    packet = {'schema': 'p5-private-theorem-proof-packet/v1', 'workspace': str(W),
        'mission_id': 'eeb5193f-68c0-41d0-9263-4a5ff7c801ee', 'root_id': 'e33ff731-60a7-43ef-87ae-c12aeba23cb5',
        'environment': ENV, 'scope': 'detached-source-consumer-preparation-for-existing-private-mission',
        'root_graph_membership': False, 'canonicalC22Connected': False,
        'publications': [{'tag': tag, 'endpoint': '/submit-problem', 'payload': payload}],
        'verification': [{'tag': tag, 'theorem_name': NAME, 'source': solution_rel}],
        'source_sha256': {theorem_rel: hashlib.sha256(stub).hexdigest(), solution_rel: hashlib.sha256(solution).hexdigest()},
        'staged_sources': {theorem_rel: str(OUT / 'staging' / theorem_rel), solution_rel: str(OUT / 'staging' / solution_rel)},
        'metadata_sha256': metadata_hashes, 'sourceOracleJob': receipt['job_id'],
        'mathematical_scope': 'Pure real inequality assisting the source (P5) argument; no geometric object or canonical C2 root connection.',
        'frozenReadback': rb, 'explanation': trilingual + '\n\n' + status_note + '\n\n' + note,
        'allGatesAccepted': False}
    assert solution.startswith(preamble.encode() + b'theorem solution') and b'sorry' not in solution.split()
    assert solution[len(solution_prefix.encode()):-1] == body
    assert json.loads(json.dumps(packet, ensure_ascii=False)) == packet
    save(OUT / 'packet.json', packet)
    return packet


if __name__ == '__main__':
    print(json.dumps({'prepared': prepare()['publications'][0]['payload']['theorem_name'], 'APIInvoked': False}))
