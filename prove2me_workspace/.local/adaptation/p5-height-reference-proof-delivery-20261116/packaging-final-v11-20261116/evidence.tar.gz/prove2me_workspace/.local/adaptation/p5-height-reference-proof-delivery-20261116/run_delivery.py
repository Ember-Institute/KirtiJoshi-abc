from pathlib import Path
import importlib.util,json
O=Path('/tmp/p2m-main-p5-publisher-v9-20261116')
s=importlib.util.spec_from_file_location('p5pub',O/'publisher.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
print(json.dumps(m.deliver(O/'packet.json',O/'ready.final.json',O/'platform')),flush=True)
