"""Offline p5-only shim around the existing numeric theorem delivery protocol.
Import/prepare/preflight do not load credentials or call an API. Only explicit
`deliver` invokes the existing publisher. No compiler, CI, Git, or source writes.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import importlib.util
import json

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
OUT = Path('/tmp/p2m-main-p5-publisher-v9-20261116')
NAME = 'AbcAdaptation.Reference.Iut.p5_height_bound'
PROTOCOL = W / '.local/adaptation/main-c22-numeric-reference-split-20261115/delivery.py'
_spec = importlib.util.spec_from_file_location('p5_existing_numeric_delivery', PROTOCOL)
old = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(old)  # Existing module defines functions/constants only.
BASE_PREFLIGHT = old.preflight
old.NAMES = [NAME]
old.ORIGINALS = ['Iut.p5_height_bound']
old.GATES |= {'source_proof_oracle', 'original_proof_identity'}
read, sha, save = old.read, old.sha, old.save
AUDIT_FLAGS = ['signatureBinderInfoPreserved', 'allExpressionBinderInfoEqual',
    'kernelTargetSolutionTypeEqual', 'kernelOriginalTargetTypeEqual',
    'kernelOriginalSolutionTypeEqual', 'solutionClosureStandardAxiomsOnly']


def prepare():
    """Regenerate only task-local staged code and packet; every unaccepted gate stays false."""
    spec = importlib.util.spec_from_file_location('p5_offline_prepare', OUT / 'prepare.py')
    generation = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generation)
    packet = generation.prepare()
    # Retain hashes of the actual generator and known delivery implementation.
    packet['metadata_sha256'].update({str(p): sha(p) for p in [
        PROTOCOL, OUT / 'prepare.py', Path(__file__).resolve(),
        OUT / 'source-proof-evidence.json', OUT / 'frozen-p5-readback.json']})
    save(OUT / 'packet.json', packet)
    gates = {g: False for g in sorted(old.GATES)}
    gates['source_proof_oracle'] = True  # Actual ci-016006 receipt is already bound.
    ready = {'passed': False, 'packet_sha256': sha(OUT / 'packet.json'),
        'source_sha256': packet['source_sha256'], 'gates': gates,
        'ci_receipts': [], 'kernel_audit': None,
        'evidence_sha256': packet['metadata_sha256'].copy(),
        'explanations': {NAME: packet['explanation']},
        'required_inputs': {'native_theorem_stub_leaf': None, 'native_solution_leaf': None,
            'source_target_solution_kernel_audit': None, 'axiom_audit': None,
            'production_checks': None, 'git_diff_check': None, 'existing_private_mission': None},
        'note': 'Root must supply actual compiled-type/binder/proof-source/standard-axiom audit and accepted receipts. Source AST/InfoTree success does not set wrapped_kernel_type_identity.'}
    save(OUT / 'ready.template.json', ready)
    return packet


def preflight(packet_path, ready_path):
    """Reuse the established gates and require the actual source/target/solution audit."""
    packet, ready = read(packet_path), read(ready_path)
    assert ready['passed'] is True, 'Root final acceptance remains pending'
    assert len(packet['publications']) == len(packet['verification']) == 1
    row, = packet['publications']
    assert row['endpoint'] == '/submit-problem' and row['payload']['theorem_name'] == NAME
    assert row['payload']['private'] is True and row['payload']['env'] == old.ENV
    assert packet['sourceOracleJob'] == 'ci-016006-2107ae17'
    audit_path = ready['kernel_audit']
    assert audit_path and audit_path in ready['evidence_sha256'], 'Compiled-type/axiom audit is not bound'
    audit = read(audit_path)
    for key in AUDIT_FLAGS:
        assert audit[key] is True, ('Required actual kernel audit flag missing', key)
    assert audit['solutionHasTransitiveSorryAx'] is False and audit['solutionBodyDirectSorryAx'] is False
    assert set(audit['solutionAxioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}
    assert set(ready['required_inputs']) == {'native_theorem_stub_leaf', 'native_solution_leaf',
        'source_target_solution_kernel_audit', 'axiom_audit', 'production_checks',
        'git_diff_check', 'existing_private_mission'}
    assert all(p and p in ready['evidence_sha256'] for p in ready['required_inputs'].values())
    # Source signature and complete solution proof remain exactly the frozen generated files.
    for relative, staged in packet['staged_sources'].items():
        assert (W / relative).read_bytes() == Path(staged).read_bytes(), ('Installed code differs', relative)
    proof = read(OUT / 'source-proof-evidence.json')
    solution = (W / packet['verification'][0]['source']).read_bytes()
    a, b = proof['solutionProofByteRange']
    assert __import__('hashlib').sha256(solution[a:b]).hexdigest() == proof['sourceProofSha256']
    return BASE_PREFLIGHT(packet_path, ready_path)


old.preflight = preflight


def deliver(packet_path, ready_path, directory):
    """Explicit root-only network entry, after all supplied gates pass."""
    result = old.deliver(packet_path, ready_path, directory)
    packet = read(packet_path)
    row, = packet['publications']
    item = read(Path(directory) / (row['tag'] + '-published-item.json'))
    # Existing numeric receipts preserve these API fields byte-exactly. Check all
    # formal/readback metadata, beyond merely seeing PUBLISHED/ACCEPTED statuses.
    for key in ['theorem_name', 'theorem_title', 'preamble', 'formal_statement',
                'natural_language_statement', 'source']:
        assert item[key] == row['payload'][key], ('Exact platform readback differs', key)
    save(Path(directory) / 'p5-exact-readback.json', {'passed': True,
        'theorem_id': item['theorem_id'], 'payload_sha256': sha(OUT / 'payload.json'),
        'frozen_languages_preserved': True, 'verification': 'ACCEPTED',
        'canonicalC22Connected': False})
    result.pop('both_direct_proofs', None)
    result['p5_direct_proof'] = 'ACCEPTED'
    result['published_theorem_count'] = 1
    save(Path(directory) / 'delivery-summary.json', result)
    return result
