#!/usr/bin/env python3
import sys
sys.dont_write_bytecode=True
import json,hashlib
from pathlib import Path
R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation';D=Path(__file__).resolve().parent
ROOTS=['Iut.p5_height_bound','Iut.log_ell_bound','Iut.epsilonE_le']
def ev(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def enc(n):
 x=[]
 for s in n.split('.'):x=[x,'str',s]
 return x

def main():
 assert D==Path('/tmp/p2m-main-pure-type-identity-v9-20261116')
 original=A/'small-supplier-identity-20261116/QuerySmallSupplierOriginalExprs.lean';text=original.read_text();i=text.index('/-! Stable JSON');j=text.index('end FoundationAudit\nnamespace NextCarrierOriginalExport')
 primitive=text[i:j]+'end FoundationAudit\n'
 query='import Lean\nimport Iut.Implication.Corollary22\n\n'+primitive+(D/'source-body.lean.txt').read_text()
 (D/'QueryPureArithmeticTypeFacts.lean').write_text(query)
 src=R/'refer/iut/Iut/Implication/Corollary22.lean'
 cfg={'schema':'pure-arithmetic-type-source-config/v9','publish':False,'roots':[{'name':n,'nameExpr':enc(n)} for n in ROOTS],
 'expectedRootCount':3,'sourceModule':'Iut.Implication.Corollary22','sourceSha256':ev(src)['sha256'],
 'allowedDataNames':['Iut.epsilonE'],'outputFile':str(D/'original-type-facts.json'),
 'mode':'TYPE FACTS ONLY; cached original root theorem proof values are never accessed or exported. Separate independent proof oracle receipts remain separate.',
 'source':ev(src)}
 write(D/'source-config.json',cfg)
 # Use the actual4.33 generic kernel functions, never the old proof-oracle import.
 audittool=A/'small-supplier-identity-20261116/AuditSmallSupplierIdentity.lean';s=audittool.read_text();i=s.index('/-! Stable JSON');j=s.index('end FoundationAudit\nnamespace FoundationAudit');base=s[i:j]
 # This source primitive section ends without its namespace close.
 base+='end FoundationAudit\nnamespace FoundationAudit\nopen Lean Elab Term Meta\n\n'
 a=s.index('def requireClosed (label : String)');b=s.index('def allowedOwner (rs : Relocations)',a)
 base+=s[a:b]
 a=s.index('-- Paths distinguish binders');b=s.index('def compareRecord (rs : Relocations)',a);base+=s[a:b]
 for root in ROOTS:
  short=root.split('.')[-1];module='Theorems.Thm_AbcAdaptation_Reference_Iut_'+short
  target='AbcAdaptation.Reference.'+root
  q='import Lean\nimport '+module+'\nimport Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs\n\n'+base+(D/'native-body.lean.txt').read_text()
  (D/f'Audit_{short}.lean').write_text(q)
  nativefile=W/Path(module.replace('.','/')).with_suffix('.lean')
  c={'schema':'pure-arithmetic-native-type-config/v9','publish':False,'sourceFacts':str(D/'original-type-facts.json'),
    'sourceConfig':ev(D/'source-config.json'),'sourceReceiptBinding':None,
    'originalName':enc(root),'original':root,'targetName':enc(target),'target':target,'targetModule':enc(module),
    'dataMap':[{'sourceName':enc('Iut.epsilonE'),'source':'Iut.epsilonE','targetName':enc('AbcAdaptation.Reference.Iut.epsilonE'),'target':'AbcAdaptation.Reference.Iut.epsilonE','targetOwner':'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs'}],
    'dataIdentityEvidence':ev(A/'small-supplier-identity-20261116/native-kernel-identity-v2-result.json'),
    'nativeSource':ev(nativefile) if nativefile.exists() else {'path':str(nativefile),'status':'not integrated yet; bind actual source before CI'},
    'outputFile':str(D/f'{short}-type-identity.json'),'standardRenames':[],
    'proofResolutionPolicy':'Only actual exported closed Prop generated helpers in original TYPE may be expanded; each is kernel checked against its actual source type. Never replace data values or source theorem proofs.'}
  write(D/f'{short}-config.json',c)
 write(D/'handoff.json',{'schema':'pure-arithmetic-type-identity-handoff/v9','publish':False,
   'sourceQuery':ev(D/'QueryPureArithmeticTypeFacts.lean'),'sourceConfig':ev(D/'source-config.json'),
   'sourceEnvironment':{'PURE_TYPE_SOURCE_CONFIG':str(D/'source-config.json')},
   'nativeQueries':[ev(D/f'Audit_{n.split(".")[-1]}.lean') for n in ROOTS],
   'nativeConfigs':[ev(D/f'{n.split(".")[-1]}-config.json') for n in ROOTS],
   'nativeEnvironmentVariable':'PURE_TYPE_NATIVE_CONFIG','expected_duration':'60s','expected_memory':'16GiB',
   'toolsReused':[ev(original),ev(audittool),ev(A/'main-c22-numeric-helpers-20261115/QueryNumericSourceFacts.lean')],
   'mode':'Source cached module only for actual complete TYPE facts. Root theorem values/proof closures are not read. Separate independent original proof probes and native proof leaves are separately bound and cannot be inferred from these type facts.',
   'pending':'Source actual type/proofhelper export and receipt/SHA binding; target artifact availability and full kernel type/BinderInfo plus target standard-axiom acceptance.',
   'validation':'Offline source composition only; no Lean/CI/API/Git/main workspace write.'})
 print(json.dumps({'sourceQuery':ev(D/'QueryPureArithmeticTypeFacts.lean'),'sourceConfig':ev(D/'source-config.json'),'nativeQueries':3},ensure_ascii=False))

if __name__=='__main__':main()
