p5 单节点离线定理／证明发布准备完成。产物只在本目录，无 API、编译、CI、Git 或主区修改。

- `payload.json` 是 `/submit-problem` 的 private、固定环境 payload，完整形式声明以 `theorem AbcAdaptation.Reference.Iut.p5_height_bound ... := by sorry` 表示。
- `staging/Theorems/Thm_AbcAdaptation_Reference_Iut_p5_height_bound.lean` 是精确 statement stub。
- `staging/Solutions/Sol_AbcAdaptation_Reference_Iut_p5_height_bound.lean` 是全局 `theorem solution`，保留原 source proof/value 字节 `dc36cb385b3dd4d8a00b9e55736f8b0cb430dd90823b17d65fdefa0aeb4a3683`。它仅导入已列 Mathlib 模块，不导入自身、任何其他 Theorems、Iut/Genl 或原 Corollary22 模块。
- `packet.json`、`ready.template.json`、`source-proof-evidence.json` 和 `frozen-p5-readback.json` 绑定确切代码和元数据。`publisher.py` 是既有 numeric delivery 的单节点 shim，不另写网络协议。

形式签名直接从已通过的实际 source oracle `ci-016006-2107ae17` 的 decl/name/signature/value AST 范围取得。该 oracle 有真实 InfoTree refs，不仅是 parser-only 输出；本声明 proof refs 没有项目定理依赖。完整原命令与之前固定源 AST 命令字节一致。替换只发生于 AST 声明绑定：一份写全限定 target 名加 `:= by sorry`，另一份写顶层 `solution` 并保留整个实际 proof body。六个隐式实数参数与九个显式条件原顺序保留，特别保留未使用的 `_hr0 : 0≤r`。没有删参数、加假设或凭漂亮打印文本重造类型。

注意 actual InfoTree JSONL 没有导出 compiled type Expr／完整 pretty type。它不能代替来源／目标编译类型同一性验收。`source-proof-evidence.json` 的 compiled-type acceptance 明确为 false，ready 的 `wrapped_kernel_type_identity` 也保持 false。Root 必须提供实际 type/BinderInfo/kernel/axiom 审查 JSON；预期字段沿用既有 numeric helpers 的 audit schema，列于 `publisher.py` 的 `AUDIT_FLAGS`。

已知回执见 `known-ci-evidence.json`：来源 oracle `ci-016006-2107ae17` 成功；准备过程中只读到 root 的原生 exact-proof leaf `ci-016017-be29acb2` 也已成功。这不代表本次新暂存的 top-level solution 和 by-sorry statement stub 已编译，也不代表标准公理、来源／目标类型身份或全项目 gate 已完成。后者均未替 root 勾选。

冻结三语只选择 Reader B 的 p5 条目，英文与 frozen original、其 byte-exact copy 及字符串 SHA 完全一致；三种语言都逐字符串写入 payload。原文里关于原显示 stub 的 `by sorry` 状态句原样保留。发布说明以独立段落解释该冻结输入状态，与另附完整 source proof 及 root 编译／公理回执分开。没有把读回答案改成“已证”，也未重新署名独立盲读。

论文段落来自 root 提供的已核对 paper-context 中 `IV-p5-p6`：IUT IV 第 46 页 (P5)、(P6) 及紧随段落。payload 中保留原 quote 和证据哈希。英文说明明确这是供源 C2 的 P5 论证使用的条件性实数不等式，lg 本身未被定义为 log(ℓ)，不构造坏约化处或 theta 数据，也不把四次方界说成原文直接定理。几何消费者入口仍是 `Iut.Corollary22Inputs.c2`，本次不接 canonical C2 root 边。

仓库原文与有效 AST 的行号不同：原 reference `refer/iut/Iut/Implication/Corollary22.lean` 的整个命令唯一字节匹配在 178–205 行；修复后 effective AST 为 181–208 行。payload 的 GitHub source URL 指向仓库原文 178–205，两个坐标各自记录，未静默混用。

Root 的最小后续步骤：把两个暂存文件按 packet 中同名相对路径整合到 W（若现有 W/Theorems 文件是完整 native proof，先保留它的成功证据；本 payload 对应的上传 stub 有单独 SHA）。根任务统一通过 MCP-CI 验收 statement stub、top-level solution、对应实际编译类型／BinderInfo／标准公理审查和项目 gates。把真实成功回执／审查及哈希填入 `ready.json`，然后 `publisher.preflight(packet,ready)`；只有通过后才显式调用 `publisher.deliver(packet,ready,专用稳定journal)`。

`publisher.py` 使用与 numeric helpers 相同的既有 `main-c22-numeric-reference-split-20261115/delivery.py`。导入前禁用 Python bytecode cache，避免在主区写 `__pycache__`；导入、prepare、preflight 均不加载凭证或访问 API。显式 deliver 才执行既有私有任务检查、持久化 request intent/job ID、单节点发布、原 proof_type=prove multipart、ACCEPTED 等待及 root 图前后相等检查。之后再逐字段核对完整 theorem name/title/preamble/formal_statement/三语说明/source 回读。沿用原 mutation 的传输不明停止重发纪律；始终续用这一个 p5 专用 journal，不运行旧脚本的批量任务。

ready 模板只有已经绑定真实成功 CI 的 `source_proof_oracle=true`，其余 gate（包括 actual compiled-type identity、new files、公理、聚合、git diff、mission 验收）均为 false，`passed=false`。离线检查确认该模板在任何 API 调用前被拒绝。没有发布或声称父数学义务完成。
