/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Defs
import Mathlib.Algebra.Order.GroupWithZero.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open Finset Real

theorem AbcAdaptation.Reference.Iut.p5_height_bound {B δ h r s lg : ℝ} (hB : 0 ≤ B) (hδ : 1 ≤ δ) (_hr0 : 0 ≤ r)
    (hrr : r * r = h) (hs0 : 0 ≤ s) (hss : s * s = r) (hh1 : 1 ≤ h)
    (hlg : lg ≤ 3 + 2 * δ + 8 * s) (hmain : h ≤ B + r * lg) :
    h ≤ (B + 11 + 2 * δ) ^ 4 := by sorry
