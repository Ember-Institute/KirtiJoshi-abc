/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Namespace adaptation of the complete original source command. The proof body
and signature bytes are retained. This native candidate has not been compiled. -/
import Mathlib.Data.Real.Basic
import Mathlib.Data.Finset.Defs
import Mathlib.Algebra.Order.GroupWithZero.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference
namespace Iut
universe u v w
open Finset Real

/-- The (P5) argument: if `h ≤ B + √h·log ℓ` with `log ℓ ≤ 3 + 2δ + 8·√√h`, then
`h ≤ (B + 11 + 2δ)⁴`. -/
lemma p5_height_bound {B δ h r s lg : ℝ} (hB : 0 ≤ B) (hδ : 1 ≤ δ) (_hr0 : 0 ≤ r)
    (hrr : r * r = h) (hs0 : 0 ≤ s) (hss : s * s = r) (hh1 : 1 ≤ h)
    (hlg : lg ≤ 3 + 2 * δ + 8 * s) (hmain : h ≤ B + r * lg) :
    h ≤ (B + 11 + 2 * δ) ^ 4 := by sorry

end Iut
end AbcAdaptation.Reference
