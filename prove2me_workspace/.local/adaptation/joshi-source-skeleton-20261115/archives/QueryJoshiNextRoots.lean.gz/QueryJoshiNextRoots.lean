/-
Draft query for root MCP-CI only. Not compiled by this subagent.
Adapted from prove2me_workspace/scripts/extract_decl_graph.lean.
Read built modules; traverse declaration dependencies, not whole source files.
-/
import ArithmeticTeichmullerSpaces.Act1Scene1.IutInitialThetaActualRawVolumeBound
import ArithmeticTeichmullerSpaces.Act1Scene1.IutInitialThetaCanonicalActualHullData
import Lean

open Lean

set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.proofs true
set_option pp.maxDepth 1000000
set_option pp.maxSteps 1000000

run_meta do
  let env ← getEnv
  let roots : Array Name := #[
    `JoshiTeich.Act1Scene1.InitialThetaRawQ.logSum_eq_degree_mul_reference,
    `JoshiTeich.Act1Scene1.CanonicalActualHull.raw_volume_bound,
    `JoshiTeich.Act1Scene1.CanonicalActualHull.corollary312]
  let getMod : Name → Option Name := fun n => do
    let idx ← env.getModuleIdxFor? n
    env.header.moduleNames[idx.toNat]?
  let isLocal : Name → Bool := fun n =>
    match getMod n with
    | some m => `ArithmeticTeichmullerSpaces.isPrefixOf m || `TateCurvesTheta.isPrefixOf m
    | none => false
  let valueDeps : ConstantInfo → Array Name := fun ci =>
    match ci with
    | .thmInfo t => t.value.getUsedConstants
    | .defnInfo d => d.value.getUsedConstants
    | .opaqueInfo o => o.value.getUsedConstants
    | _ => #[]
  let arr : Array Name → Json := fun ns => Json.arr (ns.map fun n => toJson n.toString)
  let mut queue := roots.toList
  let mut seen : Std.HashSet Name := {}
  let mut localModules : Std.HashSet Name := {}
  let mut instanceRoots : Std.HashSet Name := {}
  let mut rows : Array Json := #[]
  let mut continueInstances := true
  while continueInstances do
    while h : queue ≠ [] do
      let n := queue.head h
      queue := queue.tail
      if seen.contains n then continue
      seen := seen.insert n
      let some ci := env.find? n | throwError "Missing declaration: {n}"
      let mod := getMod n
      let kind := match ci with
        | .thmInfo _ => "theorem" | .defnInfo _ => "def" | .axiomInfo _ => "axiom"
        | .opaqueInfo _ => "opaque" | .inductInfo _ => "inductive" | .ctorInfo _ => "ctor"
        | .recInfo _ => "rec" | .quotInfo _ => "quot"
      let tdeps := ci.type.getUsedConstants
      let vdeps := valueDeps ci
      let mut apiDeps : Array Name := #[]
      if isLocal n then
        if let some m := mod then localModules := localModules.insert m
        if let .inductInfo i := ci then apiDeps := apiDeps ++ i.ctors.toArray
        if let some s := getStructureInfo? env n then
          apiDeps := apiDeps ++ s.fieldInfo.map (·.projFn)
        let traversedValueDeps := if kind == "theorem" then #[] else vdeps
        queue := (tdeps ++ traversedValueDeps ++ apiDeps).toList.filter isLocal ++ queue
      let range ← findDeclarationRanges? n
      let isInst ← Lean.Meta.isInstance n
      let typeText := (← Lean.Meta.ppExpr ci.type).pretty
      let defText ← match ci with
        | .defnInfo d => pure (Json.str (← Lean.Meta.ppExpr d.value).pretty)
        | .opaqueInfo o => pure (Json.str (← Lean.Meta.ppExpr o.value).pretty)
        | _ => pure Json.null
      rows := rows.push (Json.mkObj [
        ("name", toJson n.toString),
        ("userName", toJson ((privateToUserName? n).getD n).toString),
        ("module", toJson (mod.map Name.toString)),
        ("kind", toJson kind),
        ("isPrivate", toJson (privateToUserName? n).isSome),
        ("isInstance", toJson isInst),
        ("isRoot", toJson (roots.contains n)),
        ("elaboratedType", toJson typeText),
        ("definitionValue", defText),
        ("typeDeps", arr tdeps),
        ("theoremProofDeps", if kind == "theorem" then arr vdeps else Json.arr #[]),
        ("definitionValueDeps", if kind != "theorem" then arr vdeps else Json.arr #[]),
        ("apiDeps", arr apiDeps),
        ("startLine", toJson (range.map (·.range.pos.line) |>.getD 0)),
        ("endLine", toJson (range.map (·.range.endPos.line) |>.getD 0))])
    -- As in the existing playbook, erased instances are additional roots.
    -- Restrict this addition to modules reached by declarations, then fixpoint.
    for (n, _) in env.constants.toList do
      let some m := getMod n | continue
      unless localModules.contains m do continue
      if seen.contains n then continue
      if ← Lean.Meta.isInstance n then
        instanceRoots := instanceRoots.insert n
        queue := n :: queue
    continueInstances := !queue.isEmpty
  let some outputDir ← IO.getEnv "JOSHI_SOURCE_GRAPH_OUTPUT" |
    throwError "Missing JOSHI_SOURCE_GRAPH_OUTPUT"
  IO.FS.createDirAll outputDir
  IO.FS.writeFile (outputDir ++ "/declgraph.jsonl")
    (String.intercalate "\n" (rows.toList.map Json.compress))
  IO.FS.writeFile (outputDir ++ "/query-summary.json")
    (Json.mkObj [("roots", arr roots), ("instanceRoots", arr instanceRoots.toArray),
      ("reachedModules", arr localModules.toArray), ("declarationCount", toJson rows.size)]).pretty
  logInfo m!"Joshi next-root query emitted {rows.size} reachable declarations"
