/-
Draft for root MCP-CI; this subagent did not compile it.
Increment from accepted actual graph 6fdc7fa212e3eb937237183245d37aa33918883808f380b44738f0c3a5314fab.
Only dependency names, actual module/kind/ranges and axiom names are exported.
No ppExpr, proof/body pretty-print, Expr serialization or new proof construction.
-/
import ArithmeticTeichmullerSpaces.Act1Scene1.IutInitialThetaActualRawVolumeBound
import ArithmeticTeichmullerSpaces.Act1Scene1.IutInitialThetaCanonicalActualHullData
import Lean
import Lean.Util.CollectAxioms

open Lean

run_meta do
  unless Lean.versionString == "4.33.1" do throwError "Expected built Lean 4.33.1 environment"
  let some configPath ← IO.getEnv "RAW_DEGREE_FRONTIER_CONFIG" |
    throwError "Missing RAW_DEGREE_FRONTIER_CONFIG"
  let config ← match Json.parse (← IO.FS.readFile configPath) with
    | .ok value => pure value
    | .error message => throwError "Invalid frontier config JSON: {message}"
  let requiredString := fun key => do
    match config.getObjValAs? String key with
    | .ok value => pure value
    | .error message => throwError "Invalid config string {key}: {message}"
  let requiredNames := fun key => do
    match config.getObjValAs? (Array String) key with
    | .ok names => pure (names.map String.toName)
    | .error message => throwError "Invalid config names {key}: {message}"
  let graphSha ← requiredString "acceptedGraphSha256"
  unless graphSha == "6fdc7fa212e3eb937237183245d37aa33918883808f380b44738f0c3a5314fab" do
    throwError "Frontier config refers to another accepted graph"
  let outputDir ← requiredString "outputDir"
  let seeds ← requiredNames "proofFrontierNames"
  let externalNames ← requiredNames "externalOwnerNames"
  unless seeds.size == 14 && externalNames.size == 442 do
    throwError "Expected exact 14 proof-frontier seeds and 442 external-owner requests"

  let env ← getEnv
  let getMod : Name → Option Name := fun n => do
    let idx ← env.getModuleIdxFor? n
    env.header.moduleNames[idx.toNat]?
  let localModule := fun (m : Name) =>
    (`ArithmeticTeichmullerSpaces).isPrefixOf m || (`TateCurvesTheta).isPrefixOf m
  let localDecl := fun (n : Name) => (getMod n).any localModule
  let valueDeps : ConstantInfo → Array Name := fun ci => match ci with
    | .thmInfo t => t.value.getUsedConstants
    | .defnInfo d => d.value.getUsedConstants
    | .opaqueInfo o => o.value.getUsedConstants
    | _ => #[]
  let kindOf : ConstantInfo → String := fun ci => match ci with
    | .thmInfo _ => "theorem" | .defnInfo _ => "def" | .axiomInfo _ => "axiom"
    | .opaqueInfo _ => "opaque" | .inductInfo _ => "inductive" | .ctorInfo _ => "ctor"
    | .recInfo _ => "rec" | .quotInfo _ => "quot"
  let arr := fun (ns : Array Name) => Json.arr (ns.map fun n => toJson n.toString)

  -- Resolve owner by env.getModuleIdxFor?; never classify from the constant name.
  let ownerRow := fun (n : Name) => do
    let some ci := env.find? n | throwError "Requested declaration not present in built Env: {n}"
    let range ← findDeclarationRanges? n
    pure (Json.mkObj [("name", toJson n.toString),
      ("module", toJson ((getMod n).map Name.toString)),
      ("ownerResolution", toJson "actual Env.getModuleIdxFor?; no name-prefix ownership inference"),
      ("kind", toJson (kindOf ci)),
      ("startLine", toJson (range.map (·.range.pos.line) |>.getD 0)),
      ("endLine", toJson (range.map (·.range.endPos.line) |>.getD 0))])
  let mut requestedOwners : Array Json := #[]
  for n in externalNames do
    requestedOwners := requestedOwners.push (← withCurrHeartbeats (ownerRow n))
  IO.println s!"raw-degree-frontier: resolved {requestedOwners.size} requested external owners"

  -- One instance index, reused as each genuinely reached local module enters.
  let mut instancesByModule : Std.HashMap Name (Array Name) := {}
  let mut instanceNames : Std.HashSet Name := {}
  let mut indexed := 0
  for (n, _) in env.constants.toList do
    let some m := getMod n | continue
    unless localModule m do continue
    if ← withCurrHeartbeats (Lean.Meta.isInstance n) then
      instanceNames := instanceNames.insert n
      instancesByModule := instancesByModule.insert m ((instancesByModule.getD m #[]).push n)
    indexed := indexed + 1
    if indexed % 2000 == 0 then IO.println s!"raw-degree-frontier: indexed={indexed}"

  let mut queue := seeds.toList
  let mut seen : Std.HashSet Name := {}
  let mut reachedModules : Std.HashSet Name := {}
  let mut instanceRoots : Std.HashSet Name := {}
  let mut dependencyOwners : Std.HashSet Name := {}
  let mut graphRows : Array Json := #[]
  while h : queue ≠ [] do
    let n := queue.head h
    queue := queue.tail
    if seen.contains n then continue
    seen := seen.insert n
    let some ci := env.find? n | throwError "Missing recursive frontier declaration: {n}"
    let some m := getMod n | throwError "No imported module for local frontier declaration: {n}"
    unless localModule m do throwError "Frontier seed/worklist escaped participating modules: {n} in {m}"
    if !reachedModules.contains m then
      reachedModules := reachedModules.insert m
      let insts := instancesByModule.getD m #[]
      for inst in insts do
        instanceRoots := instanceRoots.insert inst
        if !seen.contains inst then queue := inst :: queue
      IO.println s!"raw-degree-frontier: module={m}, instances={insts.size}, visited={graphRows.size}"
    let (row, deps) ← withCurrHeartbeats do
      let tdeps := ci.type.getUsedConstants
      let vdeps := valueDeps ci
      let mut apiDeps : Array Name := #[]
      let mut fields : Array Name := #[]
      if let .inductInfo i := ci then apiDeps := apiDeps ++ i.ctors.toArray
      if let some s := getStructureInfo? env n then
        fields := s.fieldInfo.map (·.projFn)
        apiDeps := apiDeps ++ fields
      let range ← findDeclarationRanges? n
      let axioms ← Lean.collectAxioms n
      let kind := kindOf ci
      let row := Json.mkObj [("name", toJson n.toString),
        ("module", toJson m.toString), ("kind", toJson kind),
        ("userName", toJson ((privateToUserName? n).getD n).toString),
        ("isPrivate", toJson (privateToUserName? n).isSome),
        ("isSeed", toJson (seeds.contains n)),
        ("isInstance", toJson (instanceNames.contains n)),
        ("startLine", toJson (range.map (·.range.pos.line) |>.getD 0)),
        ("endLine", toJson (range.map (·.range.endPos.line) |>.getD 0)),
        ("typeDeps", arr tdeps), ("valueDeps", arr vdeps), ("apiDeps", arr apiDeps),
        ("structureFieldProjections", arr fields), ("axioms", arr axioms),
        ("theoremProofDeps", if kind == "theorem" then arr vdeps else Json.arr #[]),
        ("definitionValueDeps", if kind != "theorem" then arr vdeps else Json.arr #[])]
      pure (row, tdeps ++ vdeps ++ apiDeps)
    graphRows := graphRows.push row
    for d in deps do
      if localDecl d then
        if !seen.contains d then queue := d :: queue
      else dependencyOwners := dependencyOwners.insert d
    if graphRows.size % 200 == 0 then
      IO.println s!"raw-degree-frontier: visited={graphRows.size}, last={n}"

  let mut terminalOwners : Array Json := #[]
  for n in dependencyOwners.toArray do
    terminalOwners := terminalOwners.push (← withCurrHeartbeats (ownerRow n))
  IO.FS.createDirAll outputDir
  IO.FS.writeFile (outputDir ++ "/proof-frontier-graph.jsonl")
    (String.intercalate "\n" (graphRows.toList.map Json.compress))
  IO.FS.writeFile (outputDir ++ "/requested-external-owners.json") (Json.arr requestedOwners).pretty
  IO.FS.writeFile (outputDir ++ "/recursive-external-owners.json") (Json.arr terminalOwners).pretty
  IO.FS.writeFile (outputDir ++ "/proof-frontier-summary.json")
    (Json.mkObj [("acceptedGraphSha256", toJson graphSha), ("seeds", arr seeds),
      ("reachedModules", arr reachedModules.toArray), ("instanceRoots", arr instanceRoots.toArray),
      ("declarationCount", toJson graphRows.size), ("requestedExternalOwnerCount", toJson requestedOwners.size),
      ("recursiveExternalOwnerCount", toJson terminalOwners.size),
      ("scope", toJson "Recursively closes local type/value/theorem-proof/API and reached-module instances. External env modules remain pinned dependencies; no external body recursion."),
      ("baseline355ExactExport", toJson "Not performed; original accepted 355-name raw-degree selection remains a separate later exact type/body/parser export.")]).pretty
  IO.println s!"raw-degree-frontier: complete rows={graphRows.size}, modules={reachedModules.size}"
