/-
Root MCP-CI draft, not compiled by this subagent.
Source: current root QueryJoshiNextRoots.v2.lean (401c3a3fc520cf465ff54655880ffc04ed869df0b87ecc74011e3d41dbdf8379).
Stage: exact type/definition/API closure; direct theorem-proof edges deferred.
Pretty-print ONLY the three root types. Other exact type/value text is deferred
to the selected-declaration exporter after this dependency graph is available.
-/
import ArithmeticTeichmullerSpaces.Act1Scene1.IutInitialThetaActualRawVolumeBound
import ArithmeticTeichmullerSpaces.Act1Scene1.IutInitialThetaCanonicalActualHullData
import Lean

open Lean

set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.proofs true

run_meta do
  let some outputDir ← IO.getEnv "JOSHI_SOURCE_GRAPH_OUTPUT" |
    throwError "Missing JOSHI_SOURCE_GRAPH_OUTPUT"
  let env ← getEnv
  let roots : Array Name := #[
    `JoshiTeich.Act1Scene1.InitialThetaRawQ.logSum_eq_degree_mul_reference,
    `JoshiTeich.Act1Scene1.CanonicalActualHull.raw_volume_bound,
    `JoshiTeich.Act1Scene1.CanonicalActualHull.corollary312]
  let getMod : Name → Option Name := fun n => do
    let idx ← env.getModuleIdxFor? n
    env.header.moduleNames[idx.toNat]?
  let isLocalModule : Name → Bool := fun m =>
    (`ArithmeticTeichmullerSpaces).isPrefixOf m || (`TateCurvesTheta).isPrefixOf m
  let isLocal : Name → Bool := fun n =>
    match getMod n with
    | some m => isLocalModule m
    | none => false
  let valueDeps : ConstantInfo → Array Name := fun ci =>
    match ci with
    | .thmInfo t => t.value.getUsedConstants
    | .defnInfo d => d.value.getUsedConstants
    | .opaqueInfo o => o.value.getUsedConstants
    | _ => #[]
  let arr : Array Name → Json := fun ns => Json.arr (ns.map fun n => toJson n.toString)

  -- Index local-module instances ONCE. No repeated constants.toList scans.
  IO.println "joshi-query-v3: indexing instances in local imported modules"
  let mut instancesByModule : Std.HashMap Name (Array Name) := {}
  let mut instanceNames : Std.HashSet Name := {}
  let mut indexedLocalDecls := 0
  for (n, _) in env.constants.toList do
    let some m := getMod n | continue
    unless isLocalModule m do continue
    indexedLocalDecls := indexedLocalDecls + 1
    if ← withCurrHeartbeats (Lean.Meta.isInstance n) then
      instanceNames := instanceNames.insert n
      instancesByModule := instancesByModule.insert m
        ((instancesByModule.getD m #[]).push n)
    if indexedLocalDecls % 2000 == 0 then
      IO.println s!"joshi-query-v3: indexed {indexedLocalDecls} local declarations"
  IO.println s!"joshi-query-v3: instance index ready; localDecls={indexedLocalDecls}, instances={instanceNames.size}"

  let mut queue := roots.toList
  let mut seen : Std.HashSet Name := {}
  let mut localModules : Std.HashSet Name := {}
  let mut instanceRoots : Std.HashSet Name := {}
  let mut rows : Array Json := #[]
  let mut deferredExactNames : Array Name := #[]
  while h : queue ≠ [] do
    let n := queue.head h
    queue := queue.tail
    if seen.contains n then continue
    seen := seen.insert n
    let some ci := env.find? n | throwError "Missing declaration: {n}"
    let mod := getMod n
    -- Entering a module queues all of its registered instances exactly once.
    -- The same worklist reaches newly introduced modules, so this is the
    -- original module-instance fixpoint without rescanning the environment.
    if let some m := mod then
      if isLocalModule m && !localModules.contains m then
        localModules := localModules.insert m
        let moduleInstances := instancesByModule.getD m #[]
        for inst in moduleInstances do
          instanceRoots := instanceRoots.insert inst
          if !seen.contains inst then queue := inst :: queue
        IO.println s!"joshi-query-v3: module={m}, queuedInstances={moduleInstances.size}, visited={rows.size}"

    -- Each declaration gets the DEFAULT heartbeat budget independently.
    -- No maxHeartbeats override is set, and errors are not suppressed.
    let (row, traversedDeps) ← withCurrHeartbeats do
      let kind := match ci with
        | .thmInfo _ => "theorem" | .defnInfo _ => "def" | .axiomInfo _ => "axiom"
        | .opaqueInfo _ => "opaque" | .inductInfo _ => "inductive" | .ctorInfo _ => "ctor"
        | .recInfo _ => "rec" | .quotInfo _ => "quot"
      let tdeps := ci.type.getUsedConstants
      let vdeps := valueDeps ci
      let mut apiDeps : Array Name := #[]
      let mut fieldProjections : Array Name := #[]
      if let .inductInfo i := ci then apiDeps := apiDeps ++ i.ctors.toArray
      if let some s := getStructureInfo? env n then
        fieldProjections := s.fieldInfo.map (·.projFn)
        apiDeps := apiDeps ++ fieldProjections
      let range ← findDeclarationRanges? n
      let rootType ← if roots.contains n then
          pure (Json.str (← Lean.Meta.ppExpr ci.type).pretty)
        else pure Json.null
      let traversedValueDeps := if kind == "theorem" then #[] else vdeps
      let next := (tdeps ++ traversedValueDeps ++ apiDeps).filter isLocal
      let row := Json.mkObj [
        ("name", toJson n.toString),
        ("userName", toJson ((privateToUserName? n).getD n).toString),
        ("module", toJson (mod.map Name.toString)),
        ("kind", toJson kind),
        ("isPrivate", toJson (privateToUserName? n).isSome),
        ("isInstance", toJson (instanceNames.contains n)),
        ("isRoot", toJson (roots.contains n)),
        ("elaboratedType", rootType),
        ("exactTypeDeferred", toJson (!roots.contains n)),
        ("definitionValueDeferred", toJson (kind == "def" || kind == "opaque")),
        ("typeDeps", arr tdeps),
        ("theoremProofDeps", if kind == "theorem" then arr vdeps else Json.arr #[]),
        ("definitionValueDeps", if kind != "theorem" then arr vdeps else Json.arr #[]),
        ("apiDeps", arr apiDeps),
        ("structureFieldProjections", arr fieldProjections),
        ("startLine", toJson (range.map (·.range.pos.line) |>.getD 0)),
        ("endLine", toJson (range.map (·.range.endPos.line) |>.getD 0))]
      pure (row, next)
    rows := rows.push row
    if !roots.contains n then deferredExactNames := deferredExactNames.push n
    queue := traversedDeps.toList ++ queue
    if rows.size % 250 == 0 then
      IO.println s!"joshi-query-v3: visited={rows.size}, last={n}, modules={localModules.size}"

  IO.println s!"joshi-query-v3: writing {rows.size} declaration dependency rows"
  IO.FS.createDirAll outputDir
  IO.FS.writeFile (outputDir ++ "/declgraph.jsonl")
    (String.intercalate "\n" (rows.toList.map Json.compress))
  IO.FS.writeFile (outputDir ++ "/query-summary.json")
    (Json.mkObj [("schema", toJson "joshi-source-signature-closure/v3"),
      ("roots", arr roots), ("instanceRoots", arr instanceRoots.toArray),
      ("reachedModules", arr localModules.toArray),
      ("declarationCount", toJson rows.size),
      ("indexedLocalDeclarationCount", toJson indexedLocalDecls),
      ("indexedInstanceCount", toJson instanceNames.size),
      ("exactTypeValueExport", toJson "Only three root types printed; all other exact type/value text deferred to selected-declaration exporter."),
      ("theoremProofTraversal", toJson "Direct dependencies exported without recursive traversal; definition-body theorem proof closure must be completed in the next stage.")]).pretty
  IO.FS.writeFile (outputDir ++ "/deferred-exact-export.json")
    (Json.mkObj [("schema", toJson "joshi-selected-exact-export-plan/v1"),
      ("candidateNames", arr deferredExactNames),
      ("selection", toJson "Select actual needed declarations from declgraph before printing exact types/definition values; retain all field types and instances."),
      ("proofClosure", toJson "Theorem reached by a definition body needs its full closed proof closure; an Open stub is not valid Def-material.")]).pretty
  IO.println s!"joshi-query-v3: complete; rows={rows.size}, modules={localModules.size}"
