/-- `log π ≤ 2` (via `π ≤ 4` and `log 2 < 0.7`). -/
lemma log_pi_le_two : Real.log Real.pi ≤ 2 := by
  have h4 : Real.log Real.pi ≤ Real.log 4 :=
    Real.log_le_log Real.pi_pos Real.pi_le_four
  have : Real.log 4 = 2 * Real.log 2 := by
    rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.log_pow]; push_cast; ring
  have := Real.log_two_lt_d9
  linarith