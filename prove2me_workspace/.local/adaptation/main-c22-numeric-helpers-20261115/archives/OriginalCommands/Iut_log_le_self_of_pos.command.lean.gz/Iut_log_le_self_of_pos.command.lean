/-- `log y ≤ y` for `y > 0`. -/
lemma log_le_self_of_pos {y : ℝ} (hy : 0 < y) : Real.log y ≤ y := by
  linarith [Real.log_le_sub_one_of_pos hy]