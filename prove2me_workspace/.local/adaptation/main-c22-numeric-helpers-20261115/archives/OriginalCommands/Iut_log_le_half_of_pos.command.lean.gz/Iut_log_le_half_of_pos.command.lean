/-- `log y ≤ y/2` for `y > 0`. -/
lemma log_le_half_of_pos {y : ℝ} (hy : 0 < y) : Real.log y ≤ y / 2 := by
  set s := Real.sqrt y with hs
  have hs0 : 0 < s := Real.sqrt_pos.mpr hy
  have hss : s * s = y := Real.mul_self_sqrt hy.le
  have h1 : Real.log y = 2 * Real.log s := by
    rw [← hss, Real.log_mul hs0.ne' hs0.ne']; ring
  have h2 := Real.log_le_sub_one_of_pos hs0
  have h3 : s ≤ y / 4 + 1 := by nlinarith [sq_nonneg (s - 2)]
  linarith