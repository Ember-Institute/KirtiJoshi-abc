/-- `log(20·δ²·h²) ≤ 6·log(2·δ·h)` for `δ, h ≥ 1`. -/
lemma log_bound_ell {δ h : ℝ} (hδ : 1 ≤ δ) (hh : 1 ≤ h) :
    Real.log (20 * δ ^ 2 * h ^ 2) ≤ 6 * Real.log (2 * δ * h) := by
  have h1 : Real.log (20 * δ ^ 2 * h ^ 2) = Real.log 20 + 2 * Real.log δ + 2 * Real.log h := by
    rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity) (by positivity),
      Real.log_pow, Real.log_pow]; push_cast; ring
  have h2 : Real.log (2 * δ * h) = Real.log 2 + Real.log δ + Real.log h := by
    rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity) (by positivity)]
  have h20 : Real.log 20 ≤ 6 * Real.log 2 := by
    have : Real.log 20 ≤ Real.log 64 := Real.log_le_log (by norm_num) (by norm_num)
    have h64 : Real.log 64 = 6 * Real.log 2 := by
      rw [show (64 : ℝ) = 2 ^ 6 by norm_num, Real.log_pow]; push_cast; ring
    linarith
  have hδ0 : 0 ≤ Real.log δ := Real.log_nonneg hδ
  have hh0 : 0 ≤ Real.log h := Real.log_nonneg hh
  linarith