import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace AbcAdaptation.Reference

set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3

namespace Iut

universe u v w

open Finset Real



end Iut

end AbcAdaptation.Reference

theorem AbcAdaptation.Reference.Iut.log_bound_ell {δ h : ℝ} (hδ : 1 ≤ δ) (hh : 1 ≤ h) :
    Real.log (20 * δ ^ 2 * h ^ 2) ≤ 6 * Real.log (2 * δ * h) := by
  sorry
