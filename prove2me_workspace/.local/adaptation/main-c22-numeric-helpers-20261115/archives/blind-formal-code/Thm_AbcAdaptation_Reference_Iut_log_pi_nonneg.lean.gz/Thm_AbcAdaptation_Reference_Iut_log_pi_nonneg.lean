import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.Real.Pi.Bounds
import Mathlib.Tactic.Linarith

namespace AbcAdaptation.Reference

set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3

namespace Iut

universe u v



end Iut

end AbcAdaptation.Reference
theorem AbcAdaptation.Reference.Iut.log_pi_nonneg : 0 ≤ Real.log Real.pi := by
  sorry
