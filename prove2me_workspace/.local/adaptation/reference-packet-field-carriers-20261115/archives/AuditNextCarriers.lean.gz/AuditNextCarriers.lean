import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PointMap
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RationalPlace
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_PacketPresentation
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Container
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_HolomorphicHull
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PlacesOver
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  -- moduleNames maps every imported header; this lookup needs only one entry.
  return (← env.header.modules[index.toNat]?).module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

structure Relocation where
  original : Name
  target : Name
  permutation : Option (Array Nat)
  expectedInstance : Option Bool
  expectedAxioms : Option (Array Name)

structure ProofElision where
  original : Name
  record : Json
  evidence : Json

def approvedProofElisions : Array Name :=
  #[`Iut.solvableClosure._proof_2, `Iut.solvableClosure._proof_4]

def approvedRenamedOriginal : Name := `Iut.solvableClosure._proof_3
def approvedRenamedTarget : Name := `AbcAdaptation.Reference.Iut.solvableClosure._proof_2
def proofParent : Name := `Iut.solvableClosure
def proofSourceOwner : Name := `Iut.Cor312.ThetaData.GlobalField
def proofTargetOwner : Name := `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField

structure Relocations where
  rows : Array Relocation
  projectPrefixes : Array Name
  sourcePrefixes : Array Name
  targetPrefix : Name
  elisions : Array ProofElision

def Relocations.find? (rs : Relocations) (p : Relocation → Bool) : Option Relocation := rs.rows.find? p
def Relocations.any (rs : Relocations) (p : Relocation → Bool) : Bool := rs.rows.any p

def projectName (rs : Relocations) (n : Name) : Bool :=
  rs.projectPrefixes.any (·.isPrefixOf n)

def relocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.original == n) then return r.target
  if projectName rs n then throw s!"Unmapped project name {n}"
  return n

def inverseRelocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.target == n) then return r.original
  if projectName rs n then throw s!"Unmapped wrapped name {n}"
  return n

def reorder (indices : Array Nat) (us : Array α) : Except String (Array α) := do
  unless indices.size == us.size && indices.toList.eraseDups.length == us.size do
    throw "Universe permutation has incorrect size or repeated indices"
  indices.mapM fun i => match us[i]? with
    | some u => pure u
    | none => throw "Universe permutation index out of range"

-- Only applications whose original syntactic head is an approved elision are
-- beta-reduced. Other original lambdas and applications are preserved verbatim.
partial def elidedApplicationHead (rs : Relocations) (j : Json) : Except String Bool := do
  match ← stringField j "kind" with
  | "app" => elidedApplicationHead rs (← field j "fn")
  | "const" =>
    let original ← decodeName (← field j "name")
    return rs.elisions.any (·.original == original)
  | _ => return false

partial def decodeExprCore (rs : Relocations) (active : Array Name) (j : Json) : Except String Expr := do
  let recur := decodeExprCore rs active
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    let mut levels ← (← arrayField j "levels").mapM decodeLevel
    if let some elision := rs.elisions.find? (·.original == original) then
      if active.contains original then throw s!"Cyclic approved proof expansion {original}"
      let params ← (← arrayField elision.record "levelParams").mapM decodeName
      unless params.size == levels.size do throw s!"Proof expansion universe arity differs {original}"
      let value ← field elision.record "valueExpr"
      if value == Json.null then throw s!"Approved original proof value missing {original}"
      let decoded ← decodeExprCore rs (active.push original) value
      return decoded.instantiateLevelParams params.toList levels.toList
    let target ← relocated rs original
    if let some r := rs.find? (·.original == original) then
      if let some indices := r.permutation then levels ← reorder indices levels
    return .const target levels.toList
  | "app" =>
    let fnJson ← field j "fn"
    let fn ← recur fnJson
    let arg ← recur (← field j "arg")
    if ← elidedApplicationHead rs fnJson then
      if let .lam _ _ body _ := fn then return body.instantiate1 arg
    return .app fn arg
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocated rs (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unknown Expr kind {k}"

def decodeExpr (rs : Relocations) (j : Json) : Except String Expr :=
  decodeExprCore rs #[] j

def recordName (record : Json) : Except String Name := do
  let name ← decodeName (← field record "nameExpr")
  unless name.toString == (← stringField record "name") do throw "Record structural name differs"
  return name

def uniqueSourceRecord (records : Array Json) (name : Name) : MetaM Json := do
  let matchingRecords := records.filter fun record => (recordName record).toOption == some name
  unless matchingRecords.size == 1 do throwError "Expected one original record {name}"
  return matchingRecords[0]!

def requireInternalProofRecord (record : Json) : MetaM Unit := do
  let name ← checked (recordName record)
  unless (← checked (stringField record "module")) == proofSourceOwner.toString &&
      (← checked (stringField record "constantKind")) == "theorem" &&
      (← checked (record.getObjValAs? Bool "isProposition")) &&
      (← checked (record.getObjValAs? Bool "selected")) &&
      !(← checked (record.getObjValAs? Bool "isInstance")) do
    throwError "Resolution requires selected proposition-valued original theorem {name}"
  if (← checked (field record "valueExpr")) == Json.null then
    throwError "Original proof has no genuine exported value {name}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    let axs := (← checked (record.getObjValAs? (Array String) key)).map String.toName
    ensureStandard s!"original internal proof {name}: {key}" axs

def requireProofGraphFacts (row record : Json) : MetaM Unit := do
  let expectedAxioms := (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray
  let actualAxioms := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless expectedAxioms.qsort Name.lt == actualAxioms.qsort Name.lt &&
      !(← checked (row.getObjValAs? Bool "expectedIsInstance")) do
    throwError "Approved internal proof differs from accepted graph axiom/instance facts"

def readProofElisions (config : Json) (records : Array Json) : MetaM (Array ProofElision) := do
  let evidence ← checked (field config "internalProofEvidence")
  let originalAcceptance ← jsonFile (← checked (stringField evidence "originalAcceptanceFile"))
  unless (← checked (stringField originalAcceptance "status")) == "accepted" &&
      (← checked (stringField originalAcceptance "job_id")) == "ci-013498-336a3a9a" &&
      (← checked (field originalAcceptance "originalExprsSha256")) ==
        (← checked (field evidence "originalExprsSha256")) do
    throwError "Original proof export acceptance differs"
  let platformReceipt ← jsonFile (← checked (stringField evidence "platformQueryReceipt"))
  unless (← checked (stringField platformReceipt "job_id")) == "ci-013599-61a18ec4" &&
      (← checked (stringField platformReceipt "status")) == "succeeded" &&
      (← checked ((← checked (field platformReceipt "result")).getObjValAs? Nat "exit_code")) == 0 do
    throwError "Actual platform helper query receipt differs"
  let platformFacts ← jsonFile (← checked (stringField evidence "platformFactsFile"))
  unless (← checked (stringField platformFacts "schema")) == "next-carrier-platform-actual-v1" &&
      (← checked (stringField platformFacts "compilerVersion")) == "4.33.1" &&
      (← checked (platformFacts.getObjValAs? Nat "recordCount")) == 29 do
    throwError "Actual platform helper facts differ"
  let targetRecords ← checked (arrayField platformFacts "records")
  let actualTargetRecord ← uniqueSourceRecord targetRecords approvedRenamedTarget
  let target ← getConstInfo approvedRenamedTarget
  unless moduleOf (← getEnv) target.name == some proofTargetOwner && kind target == "theorem" &&
      (← isProp target.type) && !(Lean.Meta.isInstanceCore (← getEnv) target.name) do
    throwError "Renamed helper is not the actual expected target proposition"
  unless (← checked (field actualTargetRecord "elaboratedExpr")) == (← checked (encodeExpr target.type)) do
    throwError "Actual target helper type differs from accepted query"
  let some targetValue := target.value? (allowOpaque := true) |
    throwError "Actual renamed helper value unavailable"
  unless (← checked (field actualTargetRecord "valueExpr")) == (← checked (encodeExpr targetValue)) do
    throwError "Actual target helper value differs from accepted query"
  let renameRows ← checked (arrayField config "internalProofRenames")
  unless renameRows.size == 1 do throwError "Exactly one approved internal helper rename is required"
  let rename := renameRows[0]!
  unless (← checked (decodeName (← checked (field rename "originalName")))) == approvedRenamedOriginal &&
      (← checked (decodeName (← checked (field rename "targetName")))) == approvedRenamedTarget do
    throwError "Unexpected internal helper rename"
  let renamedSource ← uniqueSourceRecord records approvedRenamedOriginal
  requireInternalProofRecord renamedSource
  requireProofGraphFacts rename renamedSource
  unless (← checked (field rename "expectedOriginalRecord")) == renamedSource do
    throwError "Renamed helper original record differs"
  let parserText ← IO.FS.readFile (← checked (stringField evidence "parserFactsFile"))
  let mut parserFacts : Array Json := #[]
  for line in parserText.splitOn "\n" do
    if !line.isEmpty then parserFacts := parserFacts.push (← checked (Json.parse line))
  let parentFacts := parserFacts.filter fun fact =>
    (stringField fact "kind").toOption == some "compilerDecl" &&
    (stringField fact "name").toOption == some proofParent.toString
  unless parentFacts.size == 1 &&
      (← checked (field parentFacts[0]! "containingCommandIndices")) == toJson (#[18] : Array Nat) do
    throwError "Expected retained owner command18 for solvableClosure"
  let originalBytes ← IO.FS.readBinFile (← checked (stringField evidence "originalCoordinateSource"))
  let retainedBytes ← IO.FS.readBinFile (← checked (stringField evidence "retainedSmallSource"))
  let originalStart ← checked (evidence.getObjValAs? Nat "originalCommandStart")
  let originalEnd ← checked (evidence.getObjValAs? Nat "originalCommandEnd")
  let retainedStart ← checked (evidence.getObjValAs? Nat "retainedCommandStart")
  let retainedEnd ← checked (evidence.getObjValAs? Nat "retainedCommandEnd")
  let parentRange ← checked (field parentFacts[0]! "compilerRange")
  unless originalStart == (← checked ((← checked (field parentRange "start")).getObjValAs? Nat "offset")) &&
      originalEnd == (← checked ((← checked (field parentRange "end")).getObjValAs? Nat "offset")) do
    throwError "Proof parent command offsets differ from original compiler range"
  unless originalStart < originalEnd && originalEnd ≤ originalBytes.size &&
      retainedStart < retainedEnd && retainedEnd ≤ retainedBytes.size &&
      originalBytes.extract originalStart originalEnd == retainedBytes.extract retainedStart retainedEnd do
    throwError "Retained original owner command bytes differ"
  let renamedParserRows := parserFacts.filter fun fact =>
    (stringField fact "kind").toOption == some "compilerDecl" &&
    (stringField fact "name").toOption == some approvedRenamedOriginal.toString
  unless renamedParserRows.size == 1 do throwError "Renamed proof compiler range fact is missing"
  let renamedParserFact := renamedParserRows[0]!
  unless (← checked (field renamedParserFact "compilerRange")) == Json.null &&
      !(← checked (renamedParserFact.getObjValAs? Bool "sourceRootCandidate")) &&
      (← checked (field rename "parserFact")) == renamedParserFact do
    throwError "Only the reviewed compiler-internal no-range helper may be renamed"
  let elisionRows ← checked (arrayField config "internalProofElisions")
  unless elisionRows.size == approvedProofElisions.size do throwError "Exactly two approved proof resolutions required"
  let mut result : Array ProofElision := #[]
  for row in elisionRows do
    let original ← checked (decodeName (← checked (field row "originalName")))
    unless approvedProofElisions.contains original && !(result.any (·.original == original)) do
      throwError "Unapproved or duplicate original proof resolution {original}"
    let record ← uniqueSourceRecord records original
    requireInternalProofRecord record
    requireProofGraphFacts row record
    unless (← checked (field row "expectedOriginalRecord")) == record do
      throwError "Approved proof record differs {original}"
    let parserRows := parserFacts.filter fun fact =>
      (stringField fact "kind").toOption == some "compilerDecl" &&
      (stringField fact "name").toOption == some original.toString
    unless parserRows.size == 1 do throwError "Missing original compiler no-range fact {original}"
    let parserFact := parserRows[0]!
    unless (← checked (field parserFact "compilerRange")) == Json.null &&
        (← checked (arrayField parserFact "containingCommandIndices")).isEmpty &&
        !(← checked (parserFact.getObjValAs? Bool "sourceRootCandidate")) &&
        (← checked (parserFact.getObjValAs? Bool "selected")) &&
        (← checked (stringField parserFact "declarationKind")) == "theorem" &&
        (← checked (field row "parserFact")) == parserFact do
      throwError "Resolution requires genuine compiler-internal no-range proof {original}"
    unless (← checked (field row "standaloneTargetIdentity")) == Json.null do
      throwError "Elided source proof must not assert a target identity {original}"
    result := result.push ⟨original, record, row⟩
  return result

def readRelocations (config : Json) (records : Array Json) : MetaM Relocations := do
  let elisions ← readProofElisions config records
  let projectPrefixes := (← namesFromJson (← checked (field config "projectPrefixes"))).toArray
  let sourcePrefixes := (← namesFromJson (← checked (field config "originalProjectPrefixes"))).toArray
  let targetPrefix ← checked (decodeName (← checked (field config "targetProjectPrefix")))
  unless !projectPrefixes.isEmpty && !sourcePrefixes.isEmpty && targetPrefix != .anonymous do
    throwError "Empty project-prefix policy"
  let mut result : Array Relocation := #[]
  for key in #["projectMap", "standardRenames"] do
    for row in ← checked (arrayField config key) do
      let original ← checked (decodeName (← checked (field row "originalName")))
      let target ← checked (decodeName (← checked (field row "targetName")))
      unless original.toString == (← checked (stringField row "original")) &&
        target.toString == (← checked (stringField row "target")) do
        throwError "Structural relocation name mismatch"
      if key == "standardRenames" then
        if projectPrefixes.any (·.isPrefixOf original) || projectPrefixes.any (·.isPrefixOf target) then
          throwError "Standard relocation contains project name"
        unless (← checked (stringField row "evidence")).length > 0 do
          throwError "Standard rename requires reviewed compiler/source evidence"
      else
        let exactApprovedRename := original == approvedRenamedOriginal && target == approvedRenamedTarget
        unless sourcePrefixes.any (·.isPrefixOf original) &&
            (target == targetPrefix ++ original || exactApprovedRename) do
          throwError "Unexpected project relocation {original} -> {target}"
        if elisions.any (·.original == original) then
          throwError "Elided original proof must not claim a named target {original}"
      if result.any (fun r => r.original == original || r.target == target) then
        throwError "Duplicate or non-injective relocation {original} -> {target}"
      let indicesJson ← checked (field row "targetToSourceUniverseIndices")
      let permutation ← if indicesJson == Json.null then pure none else
        pure (some (← checked ((← checked indicesJson.getArr?).mapM Json.getNat?)))
      let expectedInstance ← if key == "projectMap" then
        pure (some (← checked (row.getObjValAs? Bool "expectedIsInstance"))) else pure none
      let expectedAxioms ← if key == "projectMap" then
        pure (some (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray) else pure none
      result := result.push ⟨original, target, permutation, expectedInstance, expectedAxioms⟩
  unless result.size == (← checked (config.getObjValAs? Nat "expectedNamedMappingCount")) do
    throwError "Named relocation count differs"
  unless result.any (fun row => row.original == approvedRenamedOriginal && row.target == approvedRenamedTarget) do
    throwError "Approved generated helper rename is missing"
  return ⟨result, projectPrefixes, sourcePrefixes, targetPrefix, elisions⟩

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No imported owner for {name}"
  unless modules.contains owner do
    throwError "Forbidden dependency {name}, owner {owner}"
  if rs.sourcePrefixes.any (·.isPrefixOf name) then
    throwError "Unrelocated original project dependency {name}"

def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  if let .axiomInfo _ := ci then throwError "Carrier declares an axiom {name}"
  let axs ← collectAxioms name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"carrier {name}" axs
  ensureStandard s!"carrier type {name}" taxs
  let value? := ci.value? (allowOpaque := true)
  let vaxs ← match value? with
    | some v => expressionAxioms v
    | none => pure #[]
  ensureStandard s!"carrier value {name}" vaxs
  for expr in #[ci.type] ++ value?.toArray do
    for dep in expr.getUsedConstants do allowedOwner rs modules dep
  if let .recInfo r := ci then
    for rule in r.rules do
      for dep in rule.rhs.getUsedConstants do allowedOwner rs modules dep
      ensureStandard s!"recursor rule {name}" (← expressionAxioms rule.rhs)
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("hasValue", toJson value?.isSome),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name))]

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

def validateProofElision (rs : Relocations) (allowedOwners : Array Name)
    (elision : ProofElision) : MetaM Json := do
  let original := elision.original
  let record := elision.record
  let params ← namesFromJson (← checked (field record "levelParams"))
  unless params.eraseDups == params do throwError "Duplicate original proof universe parameter {original}"
  let canonical := (canonicalLevels params.length).map Level.param
  let originalType := (← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))).instantiateLevelParams params canonical
  let originalValue := (← checked (decodeExprCore rs #[original] (← checked (field record "valueExpr")))).instantiateLevelParams params canonical
  unless (← isProp originalType) do throwError "Expanded original helper type is not a proposition {original}"
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory originalType do
    throwError "Expanded original proof type changed BinderInfo inventory {original}"
  let inferred ← kernelCheck s!"genuine original proof value {original}" originalValue
  kernelTypeEq s!"genuine original proof inhabits exact original type {original}" inferred originalType
  let taxs ← expressionAxioms originalType
  let vaxs ← expressionAxioms originalValue
  ensureStandard s!"expanded original proof type {original}" taxs
  ensureStandard s!"expanded original proof value {original}" vaxs
  for expr in #[originalType, originalValue] do
    for dep in expr.getUsedConstants do allowedOwner rs allowedOwners dep
  return Json.mkObj [
    ("original", toJson original.toString), ("originalName", encodeName original),
    ("resolution", toJson "genuine-exported-original-proof-value"),
    ("standaloneTargetIdentity", Json.null), ("sourceRecord", record),
    ("evidence", elision.evidence), ("ownerOriginal", encodeName proofParent),
    ("exactOriginalTypeKernelChecked", toJson true),
    ("genuineOriginalValueInhabitsExactOriginalType", toJson true),
    ("sourceTypeBinderInventoryPreserved", toJson true),
    ("expandedTypeAxioms", toJson (taxs.map Name.toString)),
    ("expandedValueAxioms", toJson (vaxs.map Name.toString)),
    ("expandedDependenciesHaveAllowedOwners", toJson true),
    ("hasSorryAx", toJson false)]

def approvedExtensionalEliminators : Array Name :=
  #[`Iut.IsInitialThetaGlobalData.casesOn, `Iut.IsInitialThetaGlobalData.recOn]

-- The only fallback proves equality of the complete values. It does not change
-- their types, erase computation checks, or assert definitional equality.
def proveGeneratedEliminatorEquality (rs : Relocations) (allowedOwners : Array Name)
    (original : Name) (sourceType sourceValue targetValue : Expr) : MetaM Json := do
  unless approvedExtensionalEliminators.contains original do
    throwError "Computational values are not definitionally equal: {original}"
  let structureName := `AbcAdaptation.Reference.Iut.IsInitialThetaGlobalData
  let constructorName := `AbcAdaptation.Reference.Iut.IsInitialThetaGlobalData.mk
  let recursorName := `AbcAdaptation.Reference.Iut.IsInitialThetaGlobalData.rec
  let .inductInfo inductiveInfo ← getConstInfo structureName |
    throwError "Expected exact initial-theta global-data inductive"
  unless inductiveInfo.numParams == 9 && inductiveInfo.numIndices == 0 &&
      inductiveInfo.ctors == [constructorName] && inductiveInfo.numNested == 0 do
    throwError "Unexpected initial-theta structure computation shape"
  let .recInfo recursor ← getConstInfo recursorName |
    throwError "Expected exact initial-theta primitive recursor"
  unless recursor.numParams == 9 && recursor.numIndices == 0 &&
      recursor.numMotives == 1 && recursor.numMinors == 1 &&
      recursor.rules.length == 1 && recursor.rules[0]!.ctor == constructorName &&
      recursor.rules[0]!.nfields == 6 && !recursor.k && !recursor.isUnsafe &&
      recursor.levelParams.tail == inductiveInfo.levelParams do
    throwError "Unexpected initial-theta primitive recursor metadata"
  let proof ← forallTelescope sourceType fun args _ => do
    unless args.size == 12 do throwError "Expected9 parameters, motive, major and minor"
    let majorType ← inferType args[10]!
    unless majorType.getAppFn.isConstOf structureName && majorType.getAppArgs.size == 9 &&
        majorType.getAppArgs == args.extract 0 9 && (← isProp majorType) do
      throwError "Unexpected generated eliminator major premise"
    let levels := majorType.getAppFn.constLevels!
    unless levels.length == inductiveInfo.levelParams.length do
      throwError "Unexpected generated eliminator structure universes"
    let left := mkAppN sourceValue args
    let right := mkAppN targetValue args
    let pointwiseGoal ← mkEq left right
    -- Generalize the branch argument inside the recursor motive, so the motive
    -- depends only on the major premise and the first ten function arguments.
    let branchGoal ← mkForallFVars #[args[11]!] pointwiseGoal
    let equalityMotive ← mkLambdaFVars #[args[10]!] branchGoal
    let constructorPrefix := mkAppN (mkConst constructorName levels) (args.extract 0 9)
    let constructorCase ← forallTelescope (← inferType constructorPrefix) fun fields _ => do
      unless fields.size == 6 do throwError "Expected exactly six structure fields"
      for component in fields do
        unless (← isProp (← inferType component)) do
          throwError "Generated eliminator fallback requires every field to be a proposition"
      let constructed := mkAppN constructorPrefix fields
      let caseGoal ← whnf (mkApp equalityMotive constructed)
      let caseProof ← forallTelescope caseGoal fun branchArgs _ => do
        unless branchArgs.size == 1 do throwError "Expected one generalized branch argument"
        let caseArgs := (args.extract 0 10) ++ #[constructed, branchArgs[0]!]
        -- The final kernel check verifies that this reflexivity term also has
        -- the required right-hand side, using the primitive constructor rule.
        mkLambdaFVars branchArgs (← mkEqRefl (mkAppN sourceValue caseArgs))
      mkLambdaFVars fields caseProof
    let recursion := mkAppN (mkConst recursorName (.zero :: levels))
      ((args.extract 0 9) ++ #[equalityMotive, constructorCase, args[10]!])
    let mut pointwiseProof := mkApp recursion args[11]!
    -- Each step turns a proof for all values of one argument into equality of
    -- the corresponding functions. All inferred metavariables must disappear.
    for index in (List.range args.size).reverse do
      pointwiseProof ← mkFunExt (← mkLambdaFVars #[args[index]!] pointwiseProof)
    pure pointwiseProof
  let proof ← instantiateMVars proof
  requireClosed s!"generated eliminator equality proof {original}" proof
  let expectedEquality ← mkEq sourceValue targetValue
  let inferredEquality ← kernelCheck s!"generated eliminator equality proof {original}" proof
  kernelTypeEq s!"generated eliminator equality proof has exact full-value equation {original}"
    inferredEquality expectedEquality
  let axs ← expressionAxioms proof
  ensureStandard s!"generated eliminator equality proof {original}" axs
  for dep in proof.getUsedConstants do allowedOwner rs allowedOwners dep
  return Json.mkObj [
    ("original", encodeName original),
    ("method", toJson "primitive-recursion reflexivity on all six symbolic constructor fields, followed by function extensionality on all twelve arguments"),
    ("definitionalValueEqual", toJson false),
    ("kernelCheckedPropositionalValueEquality", toJson true),
    ("exactFullValueEquality", ← checked (encodeExpr expectedEquality)),
    ("kernelCheckedEqualityProof", ← checked (encodeExpr proof)),
    ("primitiveRecursor", encodeName recursorName),
    ("constructor", encodeName constructorName),
    ("constructorFieldCount", toJson (6 : Nat)),
    ("extensionalArgumentCount", toJson (12 : Nat)),
    ("axioms", toJson (axs.map Name.toString)),
    ("hasSorryAx", toJson false)]

-- Exact internal helper only: these are data-instance implementation lambdas,
-- not proof terms. The complete types must already be kernel-convertible.
def compareInternalInstanceBinders (original targetName : Name)
    (sourceType targetType : Expr) : MetaM Json := do
  unless original == approvedRenamedOriginal && targetName == approvedRenamedTarget do
    throwError "Full type BinderInfo inventory/placement differs for {original}"
  unless (binderInventory sourceType).size == 29 && (binderInventory targetType).size == 61 do
    throwError "Unexpected exact internal helper BinderInfo inventory sizes"
  let expectedFlags : Array String := #["default", "instImplicit", "instImplicit", "default",
    "instImplicit", "default", "instImplicit", "instImplicit"]
  let instanceReports ← forallTelescope sourceType fun args sourceBody => do
    unless args.size == 8 do throwError "Expected exactly eight internal helper parameters"
    let mut targetBody := targetType
    for index in [:args.size] do
      let sourceDecl ← args[index]!.fvarId!.getDecl
      let .forallE _ targetDomain targetRest targetBinder := targetBody |
        throwError "Target internal helper lost an exposed Pi binder"
      unless encodeBinder sourceDecl.binderInfo == expectedFlags[index]! &&
          sourceDecl.binderInfo == targetBinder &&
          binderInventory sourceDecl.type == binderInventory targetDomain &&
          binderPlacement sourceDecl.type == binderPlacement targetDomain do
        throwError "Internal helper exposed binder/domain BinderInfo differs at {index}"
      let prefixArgs := args.extract 0 index
      kernelTypeEq s!"internal helper parameter domain {index}"
        (← mkForallFVars prefixArgs sourceDecl.type) (← mkForallFVars prefixArgs targetDomain)
      targetBody := targetRest.instantiate1 args[index]!
    unless sourceBody.getAppFn.isConstOf ``IsScalarTower &&
        targetBody.getAppFn.isConstOf ``IsScalarTower &&
        sourceBody.getAppArgs.size == 6 && targetBody.getAppArgs.size == 6 do
      throwError "Expected exact IsScalarTower type with three types and three SMul instances"
    let sourceArgs := sourceBody.getAppArgs
    let targetArgs := targetBody.getAppArgs
    -- Preserve full nested BinderInfo and placement in the mathematical type
    -- arguments as well as in every exposed parameter domain above.
    for index in [:3] do
      unless binderInventory sourceArgs[index]! == binderInventory targetArgs[index]! &&
          binderPlacement sourceArgs[index]! == binderPlacement targetArgs[index]! do
        throwError "Internal helper mathematical type argument BinderInfo differs at {index}"
      kernelTypeEq s!"internal helper mathematical type argument {index}"
        (← mkForallFVars args sourceArgs[index]!) (← mkForallFVars args targetArgs[index]!)
    let expectedSourceLambdaCounts : Array Nat := #[4, 7, 7]
    let expectedTargetLambdaCounts : Array Nat := #[8, 21, 21]
    let mut reports : Array Json := #[]
    for instanceIndex in [:3] do
      let argumentIndex := instanceIndex + 3
      let sourceInstance := sourceArgs[argumentIndex]!
      let targetInstance := targetArgs[argumentIndex]!
      let sourceBinders := binderInventory sourceInstance
      let targetBinders := binderInventory targetInstance
      unless sourceBinders.size == expectedSourceLambdaCounts[instanceIndex]! &&
          targetBinders.size == expectedTargetLambdaCounts[instanceIndex]! &&
          sourceBinders.all (· == "lambda:default") && targetBinders.all (· == "lambda:default") do
        throwError "Unexpected binder inside exact internal SMul implementation {argumentIndex}"
      let sourceInstanceType ← whnf (← inferType sourceInstance)
      let targetInstanceType ← whnf (← inferType targetInstance)
      unless sourceInstanceType.getAppFn.isConstOf ``SMul &&
          targetInstanceType.getAppFn.isConstOf ``SMul &&
          !(← isProp sourceInstanceType) && !(← isProp targetInstanceType) do
        throwError "Expected data-valued SMul instances, not proof subterms"
      let closedSource ← mkLambdaFVars args sourceInstance
      let closedTarget ← mkLambdaFVars args targetInstance
      kernelTermEq s!"exact internal helper closed SMul data instance {argumentIndex}"
        closedSource closedTarget
      reports := reports.push (Json.mkObj [
        ("IsScalarTowerArgumentIndex", toJson argumentIndex),
        ("sourceImplementationBinderInfo", toJson sourceBinders),
        ("targetImplementationBinderInfo", toJson targetBinders),
        ("allImplementationBindersDefaultLambdas", toJson true),
        ("dataInstanceType", toJson "SMul"), ("isProofSubterm", toJson false),
        ("closedOverAllEightParameters", toJson true),
        ("closedDataInstanceTypesAndValuesKernelEqual", toJson true)])
    return reports
  return Json.mkObj [
    ("original", encodeName original), ("target", encodeName targetName),
    ("scope", toJson "three data-valued SMul instance implementations in the exact renamed internal theorem"),
    ("rawSourceBinderInventory", toJson (binderInventory sourceType)),
    ("rawTargetBinderInventory", toJson (binderInventory targetType)),
    ("rawSourceBinderPlacement", toJson (binderPlacement sourceType)),
    ("rawTargetBinderPlacement", toJson (binderPlacement targetType)),
    ("rawBinderInventoryEqual", toJson false), ("rawBinderPlacementEqual", toJson false),
    ("allEightExposedPiBindersAndDomainsStrictlyEqual", toJson true),
    ("allThreeMathematicalTypeArgumentBindersStrictlyEqual", toJson true),
    ("implementationDataInstanceKernelEqual", toJson true),
    ("instanceComparisons", Json.arr instanceReports),
    ("proofIrrelevanceClassification", toJson "not used to classify implementation lambdas; these are data instances"),
    ("binderImplementationDifferenceAccountedFor", toJson true)]

def compareRecord (rs : Relocations) (allowedOwners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.eraseDups == sourceParams do throwError "Duplicate universe parameter {original}"
  unless sourceParams.length == target.levelParams.length do
    throwError "Universe parameter count differs for {original}"
  unless (← checked (stringField record "constantKind")) == kind target do
    throwError "ConstantInfo kind differs for {original}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original axiom for {original}"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "Missing map entry {original}"
  let some expectedAxioms := rel.expectedAxioms |
    throwError "Missing accepted-graph source axiom inventory {original}"
  let sourceAxiomNames := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxiomNames.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Original axiom closure differs from accepted compiler graph {original}"
  let some expectedInstance := rel.expectedInstance |
    throwError "Missing accepted-graph instance flag {original}"
  unless (← checked (record.getObjValAs? Bool "isInstance")) == expectedInstance do
    throwError "Exported original instance flag differs from accepted graph {original}"
  unless Lean.Meta.isInstanceCore (← getEnv) target.name == expectedInstance do
    throwError "Instance registry membership differs for {original}"
  let targetLevels ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let reordered ← checked (reorder indices canonical.toArray)
      pure reordered.toList
  let sourceTypeRaw ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams targetLevels
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory sourceType do
    throwError "Source serialization BinderInfo inventory differs for {original}"
  -- The exact full kernel type check precedes any internal-implementation
  -- accounting. A binder exception cannot make a different type pass.
  kernelTypeEq s!"original versus target type {original}" sourceType targetType
  let rawBinderInventoryEqual := binderInventory sourceType == binderInventory targetType
  let rawBinderPlacementEqual := binderPlacement sourceType == binderPlacement targetType
  let mut internalBinderEvidence := Json.null
  if !rawBinderInventoryEqual || !rawBinderPlacementEqual then
    internalBinderEvidence ← compareInternalInstanceBinders original target.name sourceType targetType
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do
    throwError "Inductive/constructor/recursor computation shape differs for {original}"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  unless sourceProp == (← isProp target.type) do throwError "Proposition status differs {original}"
  let mut comparedValue := false
  let mut definitionallyEqualValue := false
  let mut propositionalValueEquality := Json.null
  let originalValueJson ← checked (field record "valueExpr")
  -- Proof declarations are audited by exact type and axiom closure. For a data
  -- value containing proof fields, Kernel.isDefEq itself uses proof irrelevance.
  if !sourceProp && originalValueJson != Json.null then
    let sourceValue := (← checked (decodeExpr rs originalValueJson)).instantiateLevelParams sourceParams canonical
    let some targetValue := target.value? (allowOpaque := true) |
      throwError "Target value missing for {original}"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq s!"original value inhabits original type {original}"
      (← kernelCheck s!"original value {original}" sourceValue) sourceType
    kernelTypeEq s!"target value inhabits target type {original}"
      (← kernelCheck s!"target value {original}" targetValue) targetType
    -- Both values and their exact common type were kernel-checked above.
    let definitionallyEqual ← match Kernel.isDefEq (← getEnv) {} sourceValue targetValue with
      | .ok equal => pure equal
      | .error exception => throwKernelException exception
    if definitionallyEqual then
      definitionallyEqualValue := true
    else
      propositionalValueEquality ← proveGeneratedEliminatorEquality rs allowedOwners
        original sourceType sourceValue targetValue
    comparedValue := true
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut comparedRules := 0
  if let .recInfo r := target then
    unless rules.size == r.rules.length do throwError "Recursor rule count differs {original}"
    for i in [:rules.size] do
      let sourceRhs := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let targetRhs := r.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      kernelTermEq s!"recursor rule {original} #{i}" sourceRhs targetRhs
      comparedRules := comparedRules + 1
  else
    unless rules.isEmpty do throwError "Unexpected original recursor rules {original}"
  let sourceStruct ← checked (field record "structure")
  if sourceStruct != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name |
      throwError "Target structure metadata missing {target.name}"
    unless (← checked (field sourceStruct "fieldsInConstructorOrder")) ==
        toJson (info.fieldNames.map Name.toString) do
      throwError "Structure field order differs {original}"
    let projections ← namesFromJson (← checked (field sourceStruct "projections"))
    let targetProjections ← projections.toArray.mapM fun n => checked (relocated rs n)
    unless targetProjections == info.fieldInfo.map (·.projFn) do
      throwError "Structure accessor identities/order differ {original}"
    for p in targetProjections do
      unless rs.any (·.target == p) do throwError "Unaudited structure accessor {p}"
  return Json.mkObj [("original", toJson original.toString), ("originalName", encodeName original),
    ("target", toJson target.name.toString), ("targetName", encodeName target.name),
    ("sourceRecord", record), ("kernelTypeEqual", toJson true),
    ("allExpressionBinderInfoEqual", toJson rawBinderInventoryEqual),
    ("binderInfoPlacementEqual", toJson rawBinderPlacementEqual),
    ("exposedBinderInfoEqual", toJson true),
    ("implementationDataInstanceKernelEqual", if internalBinderEvidence == Json.null then Json.null else toJson true),
    ("binderImplementationDifferenceAccountedFor", toJson (internalBinderEvidence != Json.null)),
    ("internalBinderImplementationEvidence", internalBinderEvidence),
    ("computationShapeEqual", toJson true), ("kernelValueEqual", toJson definitionallyEqualValue),
    ("computationalValueEqualityChecked", toJson comparedValue),
    ("kernelPropositionalValueEquality", toJson (propositionalValueEquality != Json.null)),
    ("propositionalValueEqualityEvidence", propositionalValueEquality),
    ("proofDeclaration", toJson sourceProp), ("recursorRulesCompared", toJson comparedRules),
    ("instanceRegistryMatchesAcceptedGraph", toJson true),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("expectedIsInstance", toJson expectedInstance),
    ("universeOriginalOrder", Json.arr (sourceParams.toArray.map encodeName)),
    ("universeTargetOrder", Json.arr (target.levelParams.toArray.map encodeName)),
    ("targetToSourceUniverseIndices", match rel.permutation with | none => Json.null | some a => toJson a)]

def audit : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected platform4.33.1, got {Lean.versionString}"
  let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
  unless (← checked (stringField config "schema")) == "next-carrier-kernel-audit-config-v3" do
    throwError "Wrong config schema"
  let source ← jsonFile (← checked (stringField config "originalExprFile"))
  unless (← checked (stringField source "schema")) == "foundation-original-exprs-v2" &&
      (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" do
    throwError "Wrong original compiler/schema"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field source key)) == (← checked (field config key)) do
      throwError "Input provenance hash differs: {key}"
  let records ← checked (arrayField source "records")
  let expectedRecordCount ← checked (config.getObjValAs? Nat "expectedRecordCount")
  let expectedSelectedCount ← checked (config.getObjValAs? Nat "expectedSelectedCount")
  unless records.size == expectedRecordCount do throwError "Original record count differs from config"
  unless (← checked (source.getObjValAs? Nat "recordCount")) == expectedRecordCount do
    throwError "Exporter record count differs from config"
  unless (← checked (source.getObjValAs? Nat "selectedCount")) == expectedSelectedCount do
    throwError "Exporter selected count differs from config"
  let moduleRows ← checked (arrayField config "modules")
  unless moduleRows.size == (← checked (config.getObjValAs? Nat "expectedModuleCount")) do
    throwError "Module count differs from config"
  let modules ← moduleRows.mapM fun row => return (← checked (stringField row "target")).toName
  let rs ← readRelocations config records
  let env ← getEnv
  let dependencyModules := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
  let standardPrefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
  let allowedProjectModules := modules ++ dependencyModules
  unless allowedProjectModules.size == allowedProjectModules.toList.eraseDups.length do
    throwError "Duplicate allowed project modules"
  let mut allowedOwners := #[]
  for imported in env.header.moduleNames do
    unless standardPrefixes.any (·.isPrefixOf imported) || allowedProjectModules.contains imported do
      throwError "Forbidden imported module {imported}"
    allowedOwners := allowedOwners.push imported
  let directImports := ((env.header.imports.map (·.module)).toList.eraseDups).toArray.filter (· != `Init)
  unless directImports.size == allowedProjectModules.size + 1 && directImports.contains `Lean &&
      allowedProjectModules.all directImports.contains do
    throwError "Auditor direct imports differ from exact configured Def-module set plus Lean"
  let mut directImportReports : Array Json := #[]
  for row in moduleRows do
    let owner := (← checked (stringField row "target")).toName
    let expected := (← checked (row.getObjValAs? (Array String) "allowedDirectImports")).map String.toName
    unless expected.size == expected.toList.eraseDups.length do throwError "Duplicate direct imports {owner}"
    let mut actual : Array Name := #[]
    let mut ownerFound := false
    for i in [:env.header.moduleNames.size] do
      if env.header.moduleNames[i]! == owner then
        let some data := env.header.moduleData[i]? | throwError "Module data missing {owner}"
        actual := ((data.imports.map (·.module)).toList.eraseDups).toArray.filter (· != `Init)
        ownerFound := true
    unless ownerFound && actual.size == expected.size && actual.all expected.contains do
      throwError "Target direct imports differ from precise configured imports {owner}"
    if actual.contains `Mathlib then throwError "Broad Mathlib import forbidden {owner}"
    directImportReports := directImportReports.push (Json.mkObj [
      ("module", toJson owner.toString), ("actual", toJson (actual.map Name.toString)),
      ("exactConfiguredImportSet", toJson true)])
  let declarations := env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)
  unless declarations.size > 0 do throwError "No carrier declarations"
  let mut ownedReports := #[]
  let mut comparisons := #[]
  let mut seenOriginal : Array Name := #[]
  let mut requiredCount := 0
  let mut namedRequiredCount := 0
  let mut proofResolutionReports : Array Json := #[]
  let mut resolvedProofNames : Array Name := #[]
  let expectedNamedSelectedCount ← checked (config.getObjValAs? Nat "expectedNamedSelectedCount")
  let expectedElidedProofCount ← checked (config.getObjValAs? Nat "expectedElidedProofCount")
  unless expectedNamedSelectedCount == 131 && expectedElidedProofCount == 2 &&
      expectedSelectedCount == expectedNamedSelectedCount + expectedElidedProofCount &&
      rs.elisions.size == expectedElidedProofCount do
    throwError "This reviewed resolution requires131 named +2 proof obligations =133 selected originals"
  let mut missingOptional := #[]
  for record in records do
    let original ← checked (decodeName (← checked (field record "nameExpr")))
    if seenOriginal.contains original then throwError "Duplicate original record {original}"
    seenOriginal := seenOriginal.push original
    unless original.toString == (← checked (stringField record "name")) do
      throwError "Original name identity differs"
    let sourceOwner ← checked (stringField record "module")
    let ownerRows := moduleRows.filter fun row => (stringField row "original").toOption == some sourceOwner
    unless ownerRows.size == 1 do throwError "Original module not configured: {sourceOwner}"
    for key in #["sourceSha256", "normalizedSha256"] do
      unless (← checked (field record key)) == (← checked (field ownerRows[0]! key)) do
        throwError "Original source provenance differs: {key}"
    let selected ← checked (record.getObjValAs? Bool "selected")
    if selected then requiredCount := requiredCount + 1
    if let some elision := rs.elisions.find? (·.original == original) then
      unless selected && elision.record == record do
        throwError "Approved proof resolution lost its exact selected original record {original}"
      proofResolutionReports := proofResolutionReports.push (← validateProofElision rs allowedOwners elision)
      resolvedProofNames := resolvedProofNames.push original
      continue
    let targetName ← checked (relocated rs original)
    if selected then namedRequiredCount := namedRequiredCount + 1
    unless env.contains targetName do
      if selected then throwError "Required generated/source declaration missing: {original} -> {targetName}"
      missingOptional := missingOptional.push (toJson original.toString)
      continue
    unless moduleOf env targetName == some (← checked (stringField ownerRows[0]! "target")).toName do
      throwError "Wrong target artifact owner {targetName}"
    comparisons := comparisons.push (← compareRecord rs allowedOwners record (← getConstInfo targetName))
  unless requiredCount == expectedSelectedCount do throwError "Mandatory selected count differs from config"
  unless namedRequiredCount == expectedNamedSelectedCount &&
      proofResolutionReports.size == expectedElidedProofCount &&
      approvedProofElisions.all resolvedProofNames.contains do
    throwError "Named versus genuine-proof resolution accounting differs"
  let ownerComparisons := comparisons.filter fun row =>
    (stringField row "original").toOption == some proofParent.toString
  unless ownerComparisons.size == 1 &&
      (← checked (ownerComparisons[0]!.getObjValAs? Bool "kernelTypeEqual")) &&
      (← checked (ownerComparisons[0]!.getObjValAs? Bool "kernelValueEqual")) &&
      !(← checked (ownerComparisons[0]!.getObjValAs? Bool "proofDeclaration")) do
    throwError "Internal proof resolutions require full owning solvableClosure type/value equivalence"
  proofResolutionReports := proofResolutionReports.map fun row => Json.mkObj [
    ("proofResolution", row), ("ownerTypeKernelEqual", toJson true),
    ("ownerComputationalValueKernelEqual", toJson true),
    ("coveredByOriginalOwner", encodeName proofParent)]
  let mut targetOnly := #[]
  for name in declarations.qsort Name.lt do
    ownedReports := ownedReports.push (← auditDeclaration rs allowedOwners name)
    if !(rs.any fun r => r.target == name && seenOriginal.contains r.original) then
      targetOnly := targetOnly.push (toJson name.toString)
  let output ← checked (stringField config "outputDir")
  IO.FS.createDirAll output
  IO.FS.writeFile (output ++ "/next-carrier-kernel-audit.json") ((Json.mkObj [
    ("schema", toJson "next-carrier-kernel-audit-v3"), ("compilerVersion", toJson Lean.versionString),
    ("originalCompilerVersion", toJson "4.35.0-rc3"),
    ("configuration", config), ("requiredComparedCount", toJson namedRequiredCount),
    ("requiredSourceDeclarationCount", toJson requiredCount),
    ("requiredEliminatedInternalProofCount", toJson proofResolutionReports.size),
    ("requiredResolvedCount", toJson (namedRequiredCount + proofResolutionReports.size)),
    ("eliminatedInternalProofResolutions", Json.arr proofResolutionReports),
    ("internalProofRenames", ← checked (field config "internalProofRenames")),
    ("comparisons", Json.arr comparisons), ("ownedDeclarations", Json.arr ownedReports),
    ("directImportReports", Json.arr directImportReports),
    ("previouslyAcceptedDependencyModules", Json.arr (dependencyModules.map encodeName)),
    ("missingUnselectedOriginalDeclarations", Json.arr missingOptional),
    ("targetOnlyCompilerDeclarations", Json.arr targetOnly),
    ("allOwnedTypeValueClosuresStandardAxiomsOnly", toJson true),
    ("hasSorryAx", toJson false),
    ("targetOnlyPolicy", toJson "all reported and axiom audited; review source-command generation provenance before acceptance")]).pretty ++ "\n")
  logInfo s!"Next carrier audit: {namedRequiredCount} mandatory named exact types +{proofResolutionReports.size} genuine original proof resolutions ={requiredCount} selected originals; {comparisons.size} total named pairs; {ownedReports.size} artifact-owned axiom closures"

end FoundationAudit

syntax (name := auditNextCarrier) "audit_next_carriers" : command
@[command_elab auditNextCarrier] def elabAuditNextCarrier : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.audit

audit_next_carriers
