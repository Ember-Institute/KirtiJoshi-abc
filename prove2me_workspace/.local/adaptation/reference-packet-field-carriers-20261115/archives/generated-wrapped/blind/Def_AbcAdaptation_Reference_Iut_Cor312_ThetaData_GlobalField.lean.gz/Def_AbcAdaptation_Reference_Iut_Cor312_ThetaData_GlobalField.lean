import Mathlib.Algebra.Algebra.Defs
import Mathlib.Algebra.Algebra.Equiv
import Mathlib.Algebra.Algebra.Rat
import Mathlib.Algebra.CharP.IntermediateField
import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Field.Rat
import Mathlib.Algebra.Field.Subfield.Defs
import Mathlib.Algebra.Group.Action.Defs
import Mathlib.Algebra.Group.Basic
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Even
import Mathlib.Algebra.Group.Subgroup.Defs
import Mathlib.Algebra.Group.Subgroup.Ker
import Mathlib.Algebra.Group.Submonoid.Defs
import Mathlib.Algebra.GroupWithZero.Action.Defs
import Mathlib.Algebra.GroupWithZero.Defs
import Mathlib.Algebra.Module.Defs
import Mathlib.Algebra.Module.Rat
import Mathlib.Algebra.Module.Torsion.Basic
import Mathlib.Algebra.NoZeroSMulDivisors.Basic
import Mathlib.Algebra.NoZeroSMulDivisors.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Algebra.Ring.Nat
import Mathlib.Algebra.Ring.Parity
import Mathlib.Algebra.Ring.Rat
import Mathlib.Algebra.Ring.Subring.Defs
import Mathlib.Algebra.Ring.Subsemiring.Defs
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Basic
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Point
import Mathlib.AlgebraicGeometry.EllipticCurve.Reduction
import Mathlib.AlgebraicGeometry.EllipticCurve.VariableChange
import Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass
import Mathlib.Data.SetLike.Basic
import Mathlib.Data.Int.Cast.Defs
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Data.Set.Defs
import Mathlib.FieldTheory.Galois.Basic
import Mathlib.FieldTheory.IntermediateField.Adjoin.Defs
import Mathlib.FieldTheory.IntermediateField.Basic
import Mathlib.FieldTheory.Tower
import Mathlib.GroupTheory.Solvable
import Mathlib.LinearAlgebra.Dimension.Finrank
import Mathlib.LinearAlgebra.FiniteDimensional.Defs
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace
import Mathlib.Order.CompletePartialOrder
import Mathlib.Order.SetNotation
import Mathlib.RingTheory.DedekindDomain.AdicValuation
import Mathlib.RingTheory.DedekindDomain.Basic
import Mathlib.RingTheory.DiscreteValuationRing.Basic
import Mathlib.RingTheory.Flat.TorsionFree
import Mathlib.RingTheory.Henselian
import Mathlib.RingTheory.LocalRing.Defs
import Mathlib.RingTheory.Localization.FractionRing
import Mathlib.RingTheory.Noetherian.Basic
import Mathlib.RingTheory.RegularLocalRing.Defs
import Mathlib.RingTheory.SimpleRing.Basic
import Mathlib.RingTheory.SimpleRing.Principal
import Mathlib.RingTheory.Valuation.ValuationSubring
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

open NumberField IsDedekindDomain WeierstrassCurve IntermediateField



section Reduction

variable {F : Type*} [Field F] [NumberField F] (E : WeierstrassCurve F)


def HasGoodReductionAt (w : FinitePlace F) : Prop :=
  ∃ C : VariableChange F,
    ((C • E).baseChange (w.maximalIdeal.adicCompletion F)).HasGoodReduction
      (w.maximalIdeal.adicCompletionIntegers F)


def HasMultiplicativeReductionAt (w : FinitePlace F) : Prop :=
  ∃ C : VariableChange F,
    ((C • E).baseChange (w.maximalIdeal.adicCompletion F)).HasMultiplicativeReduction
      (w.maximalIdeal.adicCompletionIntegers F)


def HasStableReductionAt (w : FinitePlace F) : Prop :=
  HasGoodReductionAt E w ∨ HasMultiplicativeReductionAt E w

end Reduction



section FieldOfModuli

variable (F : Type*) [Field F] [NumberField F] (E : WeierstrassCurve F) [E.IsElliptic]


noncomputable def fieldOfModuli : IntermediateField ℚ F := ℚ⟮E.j⟯

instance : FiniteDimensional ℚ ↥(fieldOfModuli F E) :=
  Module.Finite.left ℚ ↥(fieldOfModuli F E) F

instance : NumberField ↥(fieldOfModuli F E) where


noncomputable def solvableClosure (Fbar : Type*) [Field Fbar]
    [Algebra ↥(fieldOfModuli F E) Fbar] :
    IntermediateField ↥(fieldOfModuli F E) Fbar :=
  ⨆ L ∈ {L : IntermediateField ↥(fieldOfModuli F E) Fbar |
      FiniteDimensional ↥(fieldOfModuli F E) ↥L ∧
      IsGalois ↥(fieldOfModuli F E) ↥L ∧
      IsSolvable (↥L ≃ₐ[↥(fieldOfModuli F E)] ↥L)}, L


def IsGaloisOfDegreePrimeTo (ℓ : ℕ) : Prop :=
  IsGalois ↥(fieldOfModuli F E) F ∧ Nat.Coprime (Module.finrank ↥(fieldOfModuli F E) F) ℓ

end FieldOfModuli



section Conditions

variable (F : Type*) [Field F] [NumberField F] (E : WeierstrassCurve F) [E.IsElliptic]

variable (Fbar : Type*) [Field Fbar] [Algebra F Fbar]

open scoped Classical in

def SixTorsionRational : Prop :=
  ∀ P ∈ AddSubgroup.torsionBy (Affine.Point (Affine.baseChange E Fbar)) 6,
    P ∈ (Affine.Point.baseChange (W' := E) F Fbar).range

variable (VBad : Set (FinitePlace ↥(fieldOfModuli F E)))


def badPlacesOver : Set (FinitePlace F) :=
  {w | ∃ v ∈ VBad, FinitePlace.LiesOver w v}


structure IsInitialThetaGlobalData : Prop where
  
  sqrt_neg_one : IsSquare (-1 : F)
  
  stable_reduction : ∀ w : FinitePlace F, HasStableReductionAt E w
  
  six_torsion_rational : SixTorsionRational F E Fbar
  
  bad_nonempty : VBad.Nonempty
  
  bad_odd : ∀ v ∈ VBad, Odd (residueChar v)
  
  bad_multiplicative : ∀ v ∈ VBad, ∀ w : FinitePlace F,
    FinitePlace.LiesOver w v → HasMultiplicativeReductionAt E w

end Conditions

end Iut

end AbcAdaptation.Reference
