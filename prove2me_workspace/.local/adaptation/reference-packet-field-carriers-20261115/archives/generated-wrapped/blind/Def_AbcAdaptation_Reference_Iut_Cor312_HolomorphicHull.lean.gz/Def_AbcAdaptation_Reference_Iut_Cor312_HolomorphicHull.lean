import Mathlib.Data.Set.Basic
import Mathlib.Data.Set.BooleanAlgebra
import Mathlib.Data.Set.Defs
import Mathlib.Order.CompleteBooleanAlgebra
import Mathlib.Order.CompletePartialOrder
import Mathlib.Order.Defs.PartialOrder
import Mathlib.Order.RelClasses
import Mathlib.Topology.Defs.Basic
import Mathlib.Topology.Defs.Filter
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_PacketPresentation

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

universe u v

namespace DirectSumPresentation

variable {C : Type u} {P : DirectSumPresentation.{u, v} C}


def IsLeastHullRegionIn (P : DirectSumPresentation C) (𝓗 : Set (Set P.Total))
    (U R : Set P.Total) : Prop :=
  R ∈ 𝓗 ∧ U ⊆ R ∧ ∀ R' ∈ 𝓗, U ⊆ R' → R ⊆ R'

end DirectSumPresentation

open DirectSumPresentation


structure HullSystem {C : Type u} (P : DirectSumPresentation.{u, v} C) :
    Type (max u v) where
  
  Admissible : Set (Set P.Total)
  
  relCompact_of_admissible : ∀ U ∈ Admissible, IsCompact (closure U)
  
  HullRegions : Set (Set P.Total)
  
  isHullRegion_of_mem : ∀ R ∈ HullRegions, P.IsHullRegion R
  
  integralRegion_mem : P.integralRegion ∈ HullRegions
  
  hull : Set P.Total → Set P.Total
  
  isLeastHullRegion_hull : ∀ U ∈ Admissible, P.IsLeastHullRegionIn HullRegions U (hull U)
  
  hull_admissible : ∀ U ∈ Admissible, hull U ∈ Admissible

namespace HullSystem

variable {C : Type u} {P : DirectSumPresentation.{u, v} C} (H : HullSystem P)

variable {U V : Set P.Total}


lemma subset_hull (hU : U ∈ H.Admissible) : U ⊆ H.hull U :=
  (H.isLeastHullRegion_hull U hU).2.1


lemma hull_le (hU : U ∈ H.Admissible) {R : Set P.Total}
    (hR : R ∈ H.HullRegions) (hUR : U ⊆ R) : H.hull U ⊆ R :=
  (H.isLeastHullRegion_hull U hU).2.2 R hR hUR


theorem hull_eq_self (hU : U ∈ H.Admissible) (h : U ∈ H.HullRegions) : H.hull U = U :=
  Set.Subset.antisymm (H.hull_le hU h subset_rfl) (H.subset_hull hU)

end HullSystem

end Iut

end AbcAdaptation.Reference
