# Original-paper context for the next five carrier bundles

Source context only. Exact selection: 32 source commands. Independent blind readbacks remain separate.

## Iut.Cor312.Container

**Paper source context.** Mochizuki III describes the local tensor packet as a tensor product, over labels, of direct sums of log-shells at chosen places above a rational place (Introduction, p. 11; Propositions 3.1–3.2, pp. 92–99). Proposition 3.9(iii) (p. 117) permits families with zero local log-volume at all but finitely many rational places and then sums those local volumes. These passages supply the setting for the local packet-index and region-family interface. “Large volume container” is the reference project’s name for its combined interface, not the title of one definition in Mochizuki.

**Implementation scope.** The selected commands provide LargeVolumeContainerData; its rational-place fibers and finite enumerations; the tuple index Components; AdmissibleRegion; pointwise inclusion of such region families; and logShellAdmissible. The data take a supplied chain of finite label sets, an arbitrary type $V$ with a map to rational-place labels and finite fibers, packet presentations indexed by tuples, and supplied log-shell regions. The fields assert that those regions are product regions with compact closure, equal the designated integral regions outside a finite set, and contain the integral region at finite rational places. The family type likewise requires equality with the designated integral region almost everywhere. With the paper’s zero normalization for integral-region volumes, requiring equality to those regions is stronger than merely requiring zero local volume. No equivalence of these conditions is proved here. The component rings remain arbitrary commutative rings with topologies and designated subsets. This interface does not construct completions, tensor decompositions, p-adic logarithms, or a multiradial algorithm. Although the source file also defines a restricted-product Container abbreviation, that abbreviation is not among this unit’s selected commands.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), Introduction, construction paragraph and both bullets, ending with the name tensor packet; printed/PDF page(s) 11.

> Then, in order to obtain objects that are immune to the various label indeterminacies discussed above, we consider, for each element $*\in\mathbb S_{j+1}^{\pm}$, and for each [say, for simplicity, nonarchimedean] $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}$,
>
> - the direct sum of the log-shells associated to the prime-strip labeled by the given element $*\in\mathbb S_{j+1}^{\pm}$ at the $\underline v\in\underline{\mathbb V}$ that lie over $v_{\mathbb Q}$;
>
> we then form
>
> - the tensor product, over the elements $*\in\mathbb S_{j+1}^{\pm}$, of these direct sums.
>
> This collection of tensor products associated to $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}$ will be referred to as the tensor packet associated to the collection of prime-strips indexed by elements of $\mathbb S_{j+1}^{\pm}$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), Proposition 3.9(iii), finite local-volume support condition and summation passage; printed/PDF page(s) 117.

> for the subset of elements whose components, indexed by $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}$, have zero log-volume [cf. (i)] for all but finitely many $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}$. Then, by adding the log-volumes of (i) [all but finitely many of which are zero!] at the various $v_{\mathbb Q}\in\mathbb V_{\mathbb Q}$, one obtains a global log-volume […]

**Actual consumer.** The extracted graph has LargeVolumeContainerData→proc→theorem110, Fiber/Components and their finite enumerations→LogVolumeData→globalVol→LocalEstimate.rhs_le→theorem110, and logShellAdmissible plus the region-family order→RHSData→rhsData→theorem110. The structural fields and their premises organize the numerical theorem’s inputs; they do not establish its local estimates or the Corollary 3.12 variant.

## Iut.Cor312.HolomorphicHull

**Paper source context.** Mochizuki III, Remark 3.9.5(i)–(ii) (p. 127), defines the holomorphic hull in the setting of Proposition 3.9(i) and records its fixed-point, inclusion, and monotonicity properties. Item (i) requires a relatively compact subset of finite log-volume. For relatively compact input it uses the smallest containing scaled integral region, with a nonzero multiplier in every field component. For non-relatively-compact input the paper uses the full ambient space. These qualifications remain part of the paper context.

**Implementation scope.** The five selected commands are IsLeastHullRegionIn, HullSystem, subset_hull, hull_le, and hull_eq_self. The leastness predicate is relative to any supplied class $\mathcal H$: membership in that class, containment of the input, and inclusion in every other containing member. HullSystem supplies an admissible class with compact closures, a chosen class of unit-scaled integral regions containing the integral region, a total operation, a proof of leastness on admissible inputs, and preservation of admissibility. The selected three lemmas follow from those supplied fields. There is no theorem here that such a HullSystem exists for arithmetic packets. Its admissible class may be empty, and values outside that class are unconstrained. The chosen hull class need not comprise all unit-scaled regions. In arbitrary commutative component rings, being a unit is stronger than being nonzero; no nontriviality assumption excludes zero rings. The interface’s unconstrained values outside admissibility also differ from the paper’s specified full-space branch. The file’s unselected existence-certificate constructor and closure-operator definitions are not outputs of this unit.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), Remark 3.9.5(i), complete item; printed/PDF page(s) 127.

> Suppose that we are in the situation of Proposition 3.9, (i). Let
>
> $$ {}^{\alpha}U\subseteq\mathcal I^{\mathbb Q}({}^{\alpha}\mathcal F_{v_{\mathbb Q}})\quad\text{(respectively, }{}^{A}U\subseteq\mathcal I^{\mathbb Q}({}^{A}\mathcal F_{v_{\mathbb Q}});\quad{}^{A,\alpha}U\subseteq\mathcal I^{\mathbb Q}({}^{A,\alpha}\mathcal F_{\underline v})\text{)} $$
>
> be a subset that contains a relatively compact subset whose log-volume [cf. the discussion of Remark 3.1.1, (iii), (iv), as well as Remark 3.9.7, (ii), below] is finite [i.e., $>-\infty$]. If ${}^{\alpha}U$ (respectively, ${}^{A}U$; ${}^{A,\alpha}U$) is relatively compact, then we define the holomorphic hull of ${}^{\alpha}U$ (respectively, ${}^{A}U$; ${}^{A,\alpha}U$) to be the smallest subset of the form
>
> $$ {}^{\alpha}H\overset{\mathrm{def}}{=}\lambda\cdot\mathcal O_{{}^{\alpha}\mathcal F_{v_{\mathbb Q}}}\quad\text{(respectively, }{}^{A}H\overset{\mathrm{def}}{=}\lambda\cdot\mathcal O_{{}^{A}\mathcal F_{v_{\mathbb Q}}};\quad{}^{A,\alpha}H\overset{\mathrm{def}}{=}\lambda\cdot\mathcal O_{{}^{A,\alpha}\mathcal F_{\underline v}}\text{)} $$
>
> — where, relative to the direct sum decomposition of $\mathcal I^{\mathbb Q}((-))$ as a direct sum of fields [cf. the discussion of Proposition 3.9, (i)], $\lambda\in\mathcal I^{\mathbb Q}((-))$ is an element such that each component of $\lambda$ [i.e., relative to this direct sum decomposition] is nonzero — that contains ${}^{\alpha}U$ (respectively, ${}^{A}U$; ${}^{A,\alpha}U$). If ${}^{\alpha}U$ (respectively, ${}^{A}U$; ${}^{A,\alpha}U$) is not relatively compact, then we define the holomorphic hull of ${}^{\alpha}U$ (respectively, ${}^{A}U$; ${}^{A,\alpha}U$) to be $\mathcal I^{\mathbb Q}({}^{\alpha}\mathcal F_{v_{\mathbb Q}})$ (respectively, $\mathcal I^{\mathbb Q}({}^{A}\mathcal F_{v_{\mathbb Q}})$; $\mathcal I^{\mathbb Q}({}^{A,\alpha}\mathcal F_{\underline v})$). One verifies immediately that the holomorphic hull is well-defined [under the conditions stated].

Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020), Remark 3.9.5(ii), displayed properties P1–P3; printed/PDF page(s) 127.

> (P1) $\phi(H)=H$, for any $H\in\mathbb H$;
>
> (P2) $P\subseteq\phi(P)$, for any $P\in\mathbb P$;
>
> (P3) $\phi(P_1)\subseteq\phi(P_2)$, for any $P_1,P_2\in\mathbb P$ such that $P_1\subseteq P_2$.

**Actual consumer.** The graph has HullSystem→ContainerHullSystem.system→LocalEstimate→theorem110. The hull_le lemma feeds hull_subset_cont and then the local-to-global volume inequality. The fixed-point lemma feeds hull_integralRegion, hullAdmissible, hullFamily, and RHSData.thetaHull. These are conditional uses of an already supplied system, not a construction of the paper’s hulls.

## Iut.Cor312.ThetaData.GlobalField

**Paper source context.** Mochizuki I, Definition 3.1(a)–(b) (pp. 61–62), requires a number field containing a square root of $-1$, a chosen algebraic closure, a once-punctured elliptic curve with stable reduction, a field of moduli, a maximal solvable extension, a nonempty designated bad-place set of odd residue characteristics, and the stated rationality and degree conditions. The excerpts locate the paper’s global initial-data setting. They do not identify the local predicate with the entire initial-$\Theta$-data tuple.

**Implementation scope.** The eleven selected commands provide good, multiplicative, and stable reduction predicates; the subfield $\mathbb Q(j(E))$ and its finite-dimensional/number-field instances; a supremum of finite solvable Galois intermediate fields; the Galois/degree-coprimality predicate; rationality of six-torsion; bad places above a specified finite-place set; and the predicate IsInitialThetaGlobalData. The reduction predicates use a global Weierstrass variable change at each finite place followed by Mathlib reduction over that place’s completed valuation ring; a single simultaneous change for all places is not required. Stable means good or multiplicative in this implementation. The chosen formula $F_{\mathrm{mod}}:=\mathbb Q(j(E))$ does not itself prove an equivalence with the paper’s field of moduli of $X_F$. Likewise the supremum definition does not establish every maximal-solvable-extension property. Its ambient field need not be algebraically closed. In IsInitialThetaGlobalData, the ambient $\overline F$-named parameter is only a field with an $F$-algebra structure; algebraic closedness is not a field of that predicate. The predicate supplies six listed conditions on supplied data and neither constructs that data nor the punctured/orbicurve objects. The prime-dependent coprimality predicate is separate and allows an arbitrary natural-number input.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), Definition 3.1(a), complete item; printed/PDF page(s) 61.

> $F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), Definition 3.1(b), opening sentences through the clause defining E_F; printed/PDF page(s) 61.

> $X_F$ is a once-punctured elliptic curve [i.e., a hyperbolic curve of type $(1,1)$] over $F$ that admits stable reduction over all $v\in\mathbb V(F)^{\mathrm{non}}$. Write $E_F$ for the elliptic curve over $F$ determined by $X_F$ [so $X_F\subseteq E_F$];

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), Definition 3.1(b), consecutive clauses defining F_mod, F_sol, and V_mod; printed/PDF page(s) 61.

> $F_{\mathrm{mod}}\subseteq F$ for the field of moduli [cf., e.g., [AbsTopIII], Definition 5.1, (ii)] of $X_F$; $F_{\mathrm{sol}}\subseteq\overline F$ for the maximal solvable extension of $F_{\mathrm{mod}}$ in $\overline F$; $\mathbb V_{\mathrm{mod}}\overset{\mathrm{def}}{=}\mathbb V(F_{\mathrm{mod}})$.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), Definition 3.1(b), final complete sentence crossing the page break; printed/PDF page(s) 61, 62.

> Here, we suppose further that the field extension $F/F_{\mathrm{mod}}$ is Galois of degree prime to $l$, and that the $2\cdot3$-torsion points of $E_F$ are rational over $F$.

**Actual consumer.** Most selected declarations feed InitialThetaData and then Corollary312VariantData.data→theorem110. The moduli-field instances also feed dmod bounds; badPlacesOver feeds qOrder and logQAt. The selected solvableClosure command has no recorded consumer path to theorem110: it is retained as the full source-command owner of a shared helper declaration. Its presence is not evidence that a maximal-solvable-extension construction or a separate mathematical obligation is complete.

**Selection scope.** Exactly eleven source commands are selected. ModPlace, goodModPlaces, badModPlaces, and HasSplitMultiplicativeReductionAt are not selected outputs. solvableClosure is retained because it owns a shared helper at the source-command boundary, not because it has a demonstrated direct mathematical consumer.

## Iut.Cor312.ThetaData.PlacesOver

**Paper source context.** Mochizuki I, Definition 3.1(c)–(e) (p. 62), uses a torsion-defined finite Galois extension $K/F$ and chosen places of $K$ above the moduli-field places. This extension-and-places setting is served by the selected local algebraic helpers. The excerpts identify the setting; they are not a quotation of the generic ring-of-integers automorphism construction used by the implementation.

**Implementation scope.** The six selected commands supply algebraicity of one number field over another given an algebra structure, restriction of a base-fixing automorphism to rings of integers, its compatibility with the field embedding, the induced action on finite places, its prime-ideal formula, and preservation of the place below. The place attached to $\sigma$ and $w$ is represented by the inverse-image ideal under $\sigma^{-1}$, equivalently the image of the prime under $\sigma$. The generic API assumes number fields and the stated algebra structures, not that their extension is Galois. For preservation over a further subfield, compatibility of the two algebra maps is an explicit hypothesis. This is ordinary local implementation infrastructure. It does not choose the paper’s section of places or construct initial data. The source file’s existence-of-places and decomposition-group declarations are outside this unit’s selected commands.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), Definition 3.1(c), first sentence through the definition of K; printed/PDF page(s) 62.

> $l$ is a prime number $\geq5$ such that the image of the outer homomorphism
>
> $$G_F\to GL_2(\mathbb F_l)$$
>
> determined by the $l$-torsion points of $E_F$ contains the subgroup $SL_2(\mathbb F_l)\subseteq GL_2(\mathbb F_l)$; write $K\subseteq\overline F$ for the finite Galois extension of $F$ determined by the kernel of this homomorphism.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), Definition 3.1(e), opening sentence and its explanatory clause; printed/PDF page(s) 62.

> $\underline{\mathbb V}\subseteq\mathbb V(K)$ is a subset that induces a natural bijection
>
> $$\underline{\mathbb V}\xrightarrow{\sim}\mathbb V_{\mathrm{mod}}$$
>
> — i.e., a section of the natural surjection $\mathbb V(K)\twoheadrightarrow\mathbb V_{\mathrm{mod}}$.

**Actual consumer.** The graph records galRestrictInt→galPlace→TateFamily→InitialThetaData→data→theorem110. The prime-ideal formula and preservation lemma also feed isBadPlace_galPlace before TateFamily. Those helpers maintain the compatibility of supplied bad-place and Tate-family data; they do not prove the paper’s full local geometry.

## TateCurvesTheta.QParameter.Basic

**Paper source context.** Mochizuki I, Definition 3.1(c) (p. 62), imposes a coprimality condition on the orders of the elliptic curve’s $q$-parameters and explicitly calls them local heights by reference to *Arithmetic Elliptic Curves in General Position*, Definition 3.3. In that original paper, §3 first fixes a finite extension of $\mathbb Q_p$ with a surjective discrete valuation and a split multiplicative-reduction elliptic-curve model (pp. 14–15); Definition 3.3 calls the positive integer $v_K(q_E)$ its local height. This is the curve-associated arithmetic setting served by the much smaller selected metric carrier.

**Implementation scope.** The selected commands are only TateParameter and norm_q_pos. For any normed field $K$, TateParameter consists of a unit $q\in K^{\times}$ and the strict inequality $\lVert q\rVert<1$. norm_q_pos proves $0<\lVert q\rVert$ from invertibility in the field. Neither completeness nor an ultrametric norm is assumed. The carrier does not include an elliptic curve, a discrete valuation, a normalized local height, or a Tate uniformization. Thus a member of this generic type is not by definition the paper’s curve-associated parameter. The source file’s real-valued order, convergence, and non-torsion lemmas are not selected outputs. No equality between a metric expression and the paper’s integer local height is asserted by this unit.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), Definition 3.1(c), second complete sentence; printed/PDF page(s) 62.

> Also, we suppose that $l$ is prime to the [residue characteristics of the] elements of $\mathbb V_{\mathrm{mod}}^{\mathrm{bad}}$, as well as to the orders of the $q$-parameters of $E_F$ [i.e., in the terminology of [GenEll], Definition 3.3, the “local heights” of $E_F$] at the primes of $\mathbb V(F)^{\mathrm{bad}}$.

Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position* (February 2009), §3, paragraph introducing local theory at nonarchimedean primes, immediately before the torsion discussion; printed/PDF page(s) 14, 15.

> Next, we consider the local theory at nonarchimedean primes. Let $K$ be a finite extension of $\mathbb Q_p$ [where $p$ is a prime number] with residue field $k$, maximal ideal $\mathfrak m_K\subseteq\mathcal O_K$, and valuation map $v_K:K^{\times}\to\mathbb Z$ [which we normalize so that $v_K$ is surjective]; $\overline K$ an algebraic closure of $K$; $G_K\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline K/K)$; $E\to\operatorname{Spec}(\mathcal O_K)$ a one-dimensional semi-abelian scheme over $\mathcal O_K$ such that the generic fiber $E_K$ of $E$ is proper, while the special fiber $E_k$ of $E$ is isomorphic to $(\mathbb G_m)_k$, the multiplicative group over $k$.

Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position* (February 2009), Definition 3.3, complete definition; printed/PDF page(s) 15.

> We shall refer to the positive integer $v_K(q_E)\in\mathbb Z_{>0}$ as the local height of $E$ [or $E_K$].

**Actual consumer.** The graph records TateParameter→AdmissiblePrimeData→theorem110. Its positivity lemma feeds orderZ_pos and toOrdered, then qOrder and logQAt before theorem110. The later normalized-order infrastructure supplies the additional valuation data; the two selected commands do not construct that bridge.

## Paper versions

I: Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020).
https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf
Local PDF: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`; SHA-256 `7360e3ed27c235b5497a0743d3ed1646fbb97688547d16b7c784fc7f127f1f03`.

III: Shinichi Mochizuki, *Inter-universal Teichmüller Theory III: Canonical Splittings of the Log-theta-lattice* (May 2020).
https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20III.pdf
Local PDF: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory III.pdf`; SHA-256 `9a7ee3c77b1c7717210c0613eb39b6844649d0040dc3d9e1be7d544f8f91a0b9`.

IV: Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020).
https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf
Local PDF: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`; SHA-256 `5bf4b1e0a8c2686562a6859e5009d301335044cfb5efec5d3a9edf764e4af87f`.

GenEll: Shinichi Mochizuki, *Arithmetic Elliptic Curves in General Position* (February 2009).
https://www.kurims.kyoto-u.ac.jp/~motizuki/Arithmetic%20Elliptic%20Curves%20in%20General%20Position.pdf
Local PDF: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Arithmetic Elliptic Curves in General Position.pdf`; SHA-256 `b9dc115af61dca7fe434332ebafddf6a376a9e2926dad4e1ea2dcc0d2441f768`.

