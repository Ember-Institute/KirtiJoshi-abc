import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  -- moduleNames maps every imported header; this lookup needs only one entry.
  return (← env.header.modules[index.toNat]?).module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace NextCarrierPlatformActual
open Lean FoundationAudit

def usedConstantsJson (env : Environment) (e : Expr) : Json :=
  Json.arr (e.getUsedConstants.qsort Name.lt |>.map fun name => Json.mkObj [
    ("name", toJson name.toString), ("nameExpr", encodeName name),
    ("owner", match moduleOf env name with | none => Json.null | some owner => toJson owner.toString)])

run_meta do
  unless Lean.versionString == "4.33.1" do
    throwError "Expected platform compiler 4.33.1, got {Lean.versionString}"
  let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_PLATFORM_QUERY_CONFIG")
  unless (← checked (stringField config "schema")) == "next-carrier-platform-actual-config-v1" do
    throwError "Wrong platform actual query config"
  let owner ← checked (decodeName (← checked (field config "moduleName")))
  unless owner == `Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField do
    throwError "This query exports the actual GlobalField artifact only"
  let env ← getEnv
  let declarations := env.constants.fold (fun acc name _ =>
    if moduleOf env name == some owner then acc.push name else acc) (#[] : Array Name)
  unless !declarations.isEmpty do throwError "No GlobalField-owned declarations"
  let cache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let mut records : Array Json := #[]
  for name in declarations.qsort Name.lt do
    let ci ← getConstInfo name
    unless ci.name == name do throwError "Constant identity differs {name}"
    let axs ← cachedAxioms cache name
    let taxs ← expressionAxioms cache ci.type
    let value? := ci.value? (allowOpaque := true)
    let vaxs ← match value? with
      | none => pure #[]
      | some value => expressionAxioms cache value
    ensureStandard s!"actual declaration {name}" axs
    ensureStandard s!"actual type {name}" taxs
    ensureStandard s!"actual value {name}" vaxs
    let valueJson ← match value? with
      | none => pure Json.null
      | some value => checked (encodeExpr value)
    let recursorRules ← match ci with
      | .recInfo info => info.rules.toArray.mapM fun rule => do
          let ruleAxioms ← expressionAxioms cache rule.rhs
          ensureStandard s!"actual recursor rule {name}" ruleAxioms
          return Json.mkObj [
            ("constructorName", encodeName rule.ctor), ("numFields", toJson rule.nfields),
            ("rhs", ← checked (encodeExpr rule.rhs)),
            ("usedConstants", usedConstantsJson env rule.rhs),
            ("axioms", toJson (ruleAxioms.map Name.toString))]
      | _ => pure #[]
    records := records.push (Json.mkObj [
      ("name", toJson ci.name.toString), ("nameExpr", encodeName ci.name),
      ("module", toJson owner.toString), ("moduleName", encodeName owner),
      ("constantKind", toJson (kind ci)),
      ("isProposition", toJson (← Lean.Meta.isProp ci.type)),
      ("isInstance", toJson (Lean.Meta.isInstanceCore env ci.name)),
      ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
      ("elaboratedExpr", ← checked (encodeExpr ci.type)),
      ("binderInventory", toJson (binderInventory ci.type)),
      ("valueExpr", valueJson), ("hasValue", toJson value?.isSome),
      ("typeUsedConstants", usedConstantsJson env ci.type),
      ("valueUsedConstants", match value? with | none => Json.arr #[] | some v => usedConstantsJson env v),
      ("computationShape", ← checked (computationShape ci pure)),
      ("recursorRules", Json.arr recursorRules),
      ("axioms", toJson (axs.map Name.toString)),
      ("typeAxioms", toJson (taxs.map Name.toString)),
      ("valueAxioms", toJson (vaxs.map Name.toString)),
      ("hasSorryAx", toJson false)])
  let focusNames ← namesFromJson (← checked (field config "focusNames"))
  let focusPresence := focusNames.toArray.map fun name => Json.mkObj [
    ("name", toJson name.toString), ("nameExpr", encodeName name),
    ("exists", toJson (env.contains name)),
    ("owner", match moduleOf env name with | none => Json.null | some m => toJson m.toString)]
  let output ← checked (stringField config "outputFile")
  unless output.startsWith "/" do throwError "Expected absolute output path"
  IO.FS.writeFile output ((Json.mkObj [
    ("schema", toJson "next-carrier-platform-actual-v1"),
    ("compilerVersion", toJson Lean.versionString), ("configuration", config),
    ("recordCount", toJson records.size), ("module", toJson owner.toString),
    ("serialization", toJson "actual ConstantInfo type/value/rules; structural Names; metadata erasure; no pretty-printer decoding"),
    ("focusPresence", Json.arr focusPresence), ("records", Json.arr records),
    ("cachedAxiomQueryCount", toJson (← cache.get).size), ("hasSorryAx", toJson false)]).pretty ++ "\n")
  logInfo s!"Exported {records.size} actual GlobalField declarations to {output}"

end NextCarrierPlatformActual
