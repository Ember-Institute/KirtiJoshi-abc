import Lean
import B1SourceReplay

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  let m ← env.header.modules[index.toNat]?
  return m.module

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit

namespace BasicNativeCompare
open Lean Elab Term Meta FoundationAudit
abbrev NameMap := Array (Name × Name)

partial def relocateExpr (maps : NameMap) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := relocateExpr maps proofs visiting expandProofs
  let relocate (n : Name) : Except String Name := do
    if let some p := maps.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`_private].any (·.isPrefixOf n) then
      throw s!"Unmapped actual project Name {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let n ← decodeName (← field j "name")
    let us ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName n)) then
      unless us.isEmpty do throw s!"Closed proof has universe args {n}"
      if !expandProofs then return .const n []
      if visiting.contains n then throw s!"Cyclic proof support {n}"
      return ← relocateExpr maps proofs (visiting.push n) true (← field p "actualProofExpr")
    return .const (← relocate n) us.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok t => return t
  | .error ex => throwKernelException ex

def kernelEq (label : String) (e f : Expr) : MetaM Unit := do
  let et ← kernelCheck label e
  let ft ← kernelCheck label f
  for (a,b) in #[(et,ft),(e,f)] do
    match Kernel.isDefEq (← getEnv) {} a b with
    | .ok true => pure ()
    | .ok false => throwError "Kernel inequality {label}"
    | .error ex => throwKernelException ex

partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++ binderPlacement t (path ++ ".type") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".function") ++ binderPlacement a (path ++ ".argument")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++ binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

partial def outerForallBinderInfo : Expr → Array String
  | .forallE _ _ body bi => #[encodeBinder bi] ++ outerForallBinderInfo body
  | .mdata _ e => outerForallBinderInfo e
  | _ => #[]


end BasicNativeCompare
namespace CurveOfTorsionFreeSourceNormalization
open Lean Elab Term Meta FoundationAudit BasicNativeCompare
def forbiddenFlatNames : Array Name := #[
  ``Module.Flat.isTorsionFree, ``Module.Flat.instOfIsDedekindDomainOfIsTorsionFree,
  ``IsDomain.of_isSimpleRing, ``IsPrincipalIdealRing.of_isSimpleRing,
  ``Module.FaithfullyFlat.toFlat, ``Module.FaithfullyFlat.instOfNontrivialOfFree,
  ``IsRegularLocalRing.toIsLocalRing,
  ``IsRegularLocalRing.instOfIsLocalRingOfIsDomainOfIsPrincipalIdealRing,
  ``HenselianLocalRing.toIsLocalRing, ``Field.henselian]

def forbidFlatProof (label : String) (e : Expr) : MetaM Unit := do
  for n in forbiddenFlatNames do
    if e.getUsedConstants.contains n then throwError "Obsolete flat proof dependency remains in {label}: {n}"

def freeProofFor (expectedType : Expr) : MetaM Expr := do
  unless ← isProp expectedType do throwError "Expected TYPE is not a proposition"
  unless expectedType.getAppFn.isConstOf ``Module.IsTorsionFree do
    throwError "Expected exact Module.IsTorsionFree proposition"
  let f ← mkConstWithFreshMVarLevels ``Module.Free.instIsTorsionFree
  let (xs,bis,result) ← forallMetaTelescopeReducing (← inferType f)
  unless ← isDefEq result expectedType do throwError "Free theorem result does not match original proof TYPE"
  let mut synthesizedFree := 0
  for i in [:xs.size] do
    let x ← instantiateMVars xs[i]!
    if x.isMVar then
      unless bis[i]! == .instImplicit do throwError "Unconstrained data argument in Free proof"
      let xt ← instantiateMVars (← inferType x)
      unless xt.getAppFn.isConstOf ``Module.Free do
        throwError "Only Module.Free may be synthesized after fixing the complete original TYPE"
      let instanceProof ← synthInstance xt
      forbidFlatProof "synthesized actual Free instance term" instanceProof
      x.mvarId!.assign instanceProof
      synthesizedFree := synthesizedFree + 1
  unless synthesizedFree == 1 do throwError "Expected exactly one existing Free instance argument"
  let candidate ← instantiateMVars (mkAppN f xs)
  if candidate.hasMVar then throwError "Unresolved metavariable in actual Free proof"
  unless ← isDefEq (← inferType candidate) expectedType do throwError "Replacement proof TYPE differs"
  forbidFlatProof "replacement Free proof term" candidate
  return candidate

partial def constantUses : Expr → Array (Name × Nat)
  | .const n us => #[(n,us.length)]
  | .app f a => constantUses f ++ constantUses a
  | .lam _ t b _ => constantUses t ++ constantUses b
  | .forallE _ t b _ => constantUses t ++ constantUses b
  | .letE _ t v b _ => constantUses t ++ constantUses v ++ constantUses b
  | .mdata _ e => constantUses e
  | .proj _ _ e => constantUses e
  | _ => #[]


run_meta do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected source4.35.0-rc3"
  let cfg ← jsonFile (← absoluteEnv "B1_CURVEOF_SOURCE_TORSIONFREE_NORMALIZATION_CONFIG")
  unless (← checked (stringField cfg "schema")) == "B1-curveOf-torsionFree-source-normalization-config/v182" do
    throwError "Wrong torsion-free source normalization config"
  let sr ← checked (field cfg "sourceRecord")
  let nr ← checked (field cfg "nativeRecord")
  let sourceName ← checked (decodeName (← checked (field sr "nameExpr")))
  unless sourceName == `Iut.Tripod.instIsTorsionFreeSubtypeQbarMemIntermediateFieldRat_b1SourceReplay do
    throwError "Unexpected complete source proof"
  let ci ← getConstInfo sourceName
  unless moduleOf (← getEnv) sourceName == some `B1SourceReplay && kind ci == "theorem" &&
      ci.levelParams.isEmpty && Lean.Meta.isInstanceCore (← getEnv) sourceName do
    throwError "Original source proof owner/kind/universes/instance differs"
  let some raw := ci.value? (allowOpaque := true) | throwError "Missing complete original proof"
  unless (← checked (field sr "actualTypeExpr")) == (← checked (encodeExpr ci.type)) &&
      (← checked (field sr "actualValueExpr")) == (← checked (encodeExpr raw)) do
    throwError "Original full source TYPE/value differs from bound actual fact"
  unless outerForallBinderInfo ci.type == #["default"] && (← isProp ci.type) do
    throwError "Original proof must retain exact explicit F parameter and whole Prop TYPE"
  let rawTYPE ← kernelCheck "original whole source proof" raw
  kernelEq "original whole source proof TYPE" rawTYPE ci.type
  let _ ← kernelCheck "original complete TYPE" ci.type
  let rawAxioms ← expressionAxioms raw
  ensureStandard "original complete source proof" rawAxioms
  ensureStandard "original source declaration" (← collectAxioms sourceName)
  let nq ← checked (decodeName (← checked (field cfg "nativeQbarNameExpr")))
  let sq ← checked (decodeName (← checked (field cfg "sourceQbarNameExpr")))
  unless nq == `AbcAdaptation.Tripod.Qbar && sq == `Iut.Tripod.Qbar do throwError "Only Qbar Name may be reversed"
  let maps : NameMap := #[(nq,sq),(sq,sq)]
  let candidateNativeTYPE ← checked (relocateExpr maps #[] #[] false (← checked (field nr "elaboratedExpr")))
  let candidateNativeValue ← checked (relocateExpr maps #[] #[] false (← checked (field nr "valueExpr")))
  unless (← checked (arrayField nr "levelParams")).isEmpty &&
      (← checked (nr.getObjValAs? Bool "isProposition")) &&
      (← checked (nr.getObjValAs? Bool "valueRead")) &&
      (← checked (nr.getObjValAs? Bool "kernelValueTypeMatchesActualTYPE")) do
    throwError "Bound actual native candidate is not a complete zero-universe proof"
  let mut missing : Array Json := #[]
  let mut arity : Array Json := #[]
  let mut seen : Array (Name × Nat) := #[]
  for (label,e) in #[("actualNativeTYPEAfterOnlyQbarReverse",candidateNativeTYPE),
      ("actualNativeValueAfterOnlyQbarReverse",candidateNativeValue)] do
    for (n,k) in constantUses e do
      unless seen.contains (n,k) do
        seen := seen.push (n,k)
        match (← getEnv).find? n with
        | none => missing := missing.push (Json.mkObj [
            ("name",toJson n.toString),("nameExpr",encodeName n),
            ("candidateExpression",toJson label),("universeArgumentCount",toJson k)])
        | some info => unless info.levelParams.length == k do
            arity := arity.push (Json.mkObj [
              ("name",toJson n.toString),("nameExpr",encodeName n),
              ("candidateExpression",toJson label),("actualNativeUniverseArguments",toJson k),
              ("actualSourceUniverseParameters",toJson info.levelParams.length)])
  let usedPublicFallback := !missing.isEmpty || !arity.isEmpty
  let out ← checked (stringField cfg "outputFile")
  unless out.startsWith "/" do throwError "Expected absolute output path"
  if let some parent := (System.FilePath.mk out).parent then IO.FS.createDirAll parent
  IO.FS.writeFile out ((Json.mkObj [
    ("schema",toJson "B1-curveOf-torsionFree-source-normalization/v182"),
    ("status",toJson "candidate-preflight-completed-normalization-not-yet-accepted"),
    ("actualNativeCandidateSourcePreflightMissingNames",Json.arr missing),
    ("actualNativeCandidateSourcePreflightUniverseArityDifferences",Json.arr arity),
    ("sourceKernelNormalizationChecked",toJson false),
    ("nativeCorrespondenceAccepted",toJson false)]).pretty ++ "\n")
  let candidate ← if usedPublicFallback then
      forallTelescope ci.type fun xs expected => do
        unless xs.size == 1 do throwError "Expected exactly the original F parameter"
        let proof ← freeProofFor expected
        let whole ← mkLambdaFVars xs proof
        forbidFlatProof "complete public fallback" whole
        pure whole
    else do
      kernelEq "actual reverse-Qbar native complete TYPE" candidateNativeTYPE ci.type
      pure candidateNativeValue
  let normalizedTYPE ← kernelCheck "complete normalization candidate" candidate
  kernelEq "complete original/candidate proof TYPE" normalizedTYPE ci.type
  unless ← isProp normalizedTYPE do throwError "Normalization would replace non-Propositional data"
  kernelEq "complete original/candidate whole proof" raw candidate
  forbidFlatProof "complete normalized proof" candidate
  let normalizedAxioms ← expressionAxioms candidate
  ensureStandard "complete normalized proof" normalizedAxioms
  let equality ← mkEq raw candidate
  let equalityProof ← mkEqRefl raw
  let equalityProofTYPE ← kernelCheck "complete whole-proof equality certificate" equalityProof
  kernelEq "complete whole-proof equality certificate TYPE" equalityProofTYPE equality
  let equalityAxioms ← expressionAxioms equalityProof
  ensureStandard "whole-proof equality certificate" equalityAxioms
  let normalizedRow := sr
    |>.setObjVal! "actualValueExpr" (← checked (encodeExpr candidate))
    |>.setObjVal! "kernelInferredValueTypeExpr" (← checked (encodeExpr normalizedTYPE))
    |>.setObjVal! "directValueConstants" (Json.arr (candidate.getUsedConstants.qsort Name.lt |>.map encodeName))
    |>.setObjVal! "valueAxioms" (toJson (normalizedAxioms.map Name.toString))
    |>.setObjVal! "normalizationSource" (toJson "source4.35 whole Prop proof certificate; original source fact retained")
  IO.FS.writeFile out ((Json.mkObj [
    ("schema",toJson "B1-curveOf-torsionFree-source-normalization/v182"),
    ("status",toJson "accepted-source-whole-Prop-proof-certificate"),
    ("compilerVersion",toJson Lean.versionString),("configuration",cfg),
    ("sourceNameExpr",encodeName sourceName),("sourceOwnerNameExpr",encodeName `B1SourceReplay),
    ("sourceRecord",sr),("normalizedSourceRecord",normalizedRow),
    ("actualNativeCandidateSourcePreflightMissingNames",Json.arr missing),
    ("actualNativeCandidateSourcePreflightUniverseArityDifferences",Json.arr arity),
    ("usedAcceptedPublicFreeProofFallbackAfterExactPreflight",toJson usedPublicFallback),
    ("actualNativeCandidateAfterOnlyQbarReverseTYPE",← checked (encodeExpr candidateNativeTYPE)),
    ("actualNativeCandidateAfterOnlyQbarReverseValue",← checked (encodeExpr candidateNativeValue)),
    ("originalWholeProofTYPE",← checked (encodeExpr ci.type)),
    ("originalWholeProofValue",← checked (encodeExpr raw)),
    ("normalizedWholeProofTYPE",← checked (encodeExpr normalizedTYPE)),
    ("normalizedWholeProofValue",← checked (encodeExpr candidate)),
    ("wholeProofEqualityExpr",← checked (encodeExpr equality)),
    ("wholeProofEqualityProofExpr",← checked (encodeExpr equalityProof)),
    ("originalWholeProofKernelChecked",toJson true),
    ("sameWholePropTYPEKernelChecked",toJson true),
    ("wholeProofKernelDefEq",toJson true),
    ("wholeProofEqualityCertificateKernelChecked",toJson true),
    ("rawSourceProofByteIdentityClaimed",toJson false),
    ("rawAxioms",toJson (rawAxioms.map Name.toString)),
    ("normalizedAxioms",toJson (normalizedAxioms.map Name.toString)),
    ("certificateAxioms",toJson (equalityAxioms.map Name.toString)),
    ("nonPropositionalDataReplacementUsed",toJson false),
    ("sourceASTOrBodyEdited",toJson false),("newAxiomsIntroduced",toJson false),
    ("sourceKernelNormalizationChecked",toJson true),
    ("nativeCorrespondenceAccepted",toJson false)]).pretty ++ "\n")
  logInfo "Complete torsion-free whole Prop proof normalization certificate exported; source TYPE/data unchanged"
end CurveOfTorsionFreeSourceNormalization
