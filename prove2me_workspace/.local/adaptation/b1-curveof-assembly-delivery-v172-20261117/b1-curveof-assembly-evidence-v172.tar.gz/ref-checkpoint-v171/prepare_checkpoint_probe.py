from pathlib import Path
import json,hashlib
D=Path('/tmp/p2m-b1-curveof-refspan-v171-20261117')
V=Path('/tmp/p2m-b1-curveof-assembly-v166-20261117/pending-ref')
cfg=json.loads((V/'ref-probe.config.json').read_text())
oldq=V/'QueryCurveOfResolvedReferenceV166.lean';qbytes=oldq.read_bytes()
prefix=qbytes[:cfg['probeCommandStart']].decode()
probe=qbytes[cfg['probeCommandStart']:cfg['probeCommandEnd']]
suffix=qbytes[cfg['probeCommandEnd']:]
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def inject(old,new):
 global prefix
 assert prefix.count(old)==1
 prefix=prefix.replace(old,new,1)
def phase(label):return '  IO.println "CURVEOF_REFSPAN_V171: '+label+'"\n  (← IO.getStdout).flush\n'
inject('import B1SourceReplay\n','import B1SourceReplay\n\nrun_meta do\n'+phase('imports complete')+'\n')
inject('  elabCommand c\n',phase('command elaboration start')+'  elabCommand c\n'+phase('command elaboration end'))
inject('  let state := ((← get).infoState.substituteLazy).get\n',phase('InfoTree extraction start')+'  let state := ((← get).infoState.substituteLazy).get\n')
inject('  unless !refs.isEmpty do',phase('InfoTree extraction end')+'  unless !refs.isEmpty do')
inject('  IO.FS.writeFile output (result.pretty ++ "\\n")\n','  IO.FS.writeFile output (result.pretty ++ "\\n")\n'+phase('resolved-reference JSON written'))
out=D/'QueryCurveOfResolvedReferenceV166.lean'
out.write_bytes(prefix.encode()+probe+suffix)
sourceRelativeStart,sourceRelativeEnd=cfg['sourceCommandRelativeReferenceRange']
delta=len(cfg['probeDeclIdRewrite']['replacement'].encode())-7
lo=len(prefix.encode())+sourceRelativeStart+delta
hi=len(prefix.encode())+sourceRelativeEnd+delta
assert out.read_bytes()[lo:hi]==b"finiteDimensional_fieldOf'"
assert probe==qbytes[cfg['probeCommandStart']:cfg['probeCommandEnd']]
cfg['probeReferenceByteStart']=lo;cfg['probeReferenceByteEnd']=hi
cfg['probeCommandStart']=len(prefix.encode());cfg['probeCommandEnd']=len(prefix.encode())+len(probe)
cfg['outputFile']=str(D/'actual-resolved-ref.json');cfg['queryBinding']=pin(out)
cfg['checkpointRevision']={'schema':'B1-source-ref-checkpoint-revision/v171',
 'previousFailedJobId':'ci-018841-8fcfd783','previousStatus':'timeout',
 'previousObservedWallSeconds':180.07,'previousCompleteDurationKnown':False,
 'previousCPUAndPhysicalMemoryKnown':False,'originalQuery':pin(oldq),'originalConfig':pin(V/'ref-probe.config.json'),
 'probeSourceCommandBytesUnchanged':True,'innerElabAndSubstituteLazyOrderUnchanged':True,
 'checkpoints':['imports complete','command elaboration start','command elaboration end','InfoTree extraction start','InfoTree extraction end','resolved-reference JSON written'],
 'eachCheckpoint':'IO.println followed immediately by IO.getStdout.flush'}
cp=D/'ref-probe.config.json';cp.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
template=json.loads((V/'recommended-mcp-request.template.json').read_text())
template['parameters']['source']=str(out)
template['parameters']['environment']['B1_CURVEOF_REFSPAN_V166_CONFIG']=str(cp)
template['expected_duration']='300s';template['expected_memory']='12GiB'
template['idempotency_key']='b1-curveof-refspan-v171-attempt2-<new-query-config-binding>'
template['worktree_manifest']['external_inputs']=[pin(out),pin(cp)]
template['notes'] += [
 'Same logical source probe module, second attempt after ci-018841-8fcfd783 timeout; new query/config and idempotency key.',
 '300s is a resource estimate based on prior accepted Stage2 236.74s with system CPU215.1s and physical RSS11.18GiB, plus original probe timeout giving only >=180s. It is not a scheduler timeout override.',
 '12GiB is the parent-selected expected physical memory estimate; original timeout receipt has no CPU/RSS/exitcode data.',
 'No source build or import graph change: only immediate stdout checkpoint calls inserted before/after existing stages.']
(D/'recommended-mcp-request.template.json').write_text(json.dumps(template,ensure_ascii=False,indent=2)+'\n')
manifest={'schema':'B1-refspan-checkpoint-handoff/v171','compiled':False,'mainWorkspaceWritten':False,
 'previousFailedInputsPreserved':True,'originalProbeCommandUnchanged':True,
 'probeReferenceRange':[lo,hi],'sourceReferenceRange':[10014,10040],
 'files':[pin(p) for p in [out,cp,D/'recommended-mcp-request.template.json',Path(__file__)]]}
(D/'handoff-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(out);print(cp);print('new probe byte range',lo,hi)
