# CurveOf reference probe timeout diagnosis v171

结论：目前没有证据表明 v166 的 `substituteLazy.get` 与当前外层 command 构成等待环。`ci-018841-8fcfd783` 的 `180.07s` timeout 只给本次耗时下界；空日志不能定位阶段，也不能补出缺失的 CPU、RSS、exit code。

直接源证据来自已安装的 source toolchain `leanprover/lean4:v4.35.0-rc3`：

- `Lean/Elab/InfoTrees.lean:17` 的内置 `#info_trees in cmd` 正是 `elabCommand cmd` 后读取 `(← getInfoState).substituteLazy.get.trees`。v166 顺序与内置实现一致。
- `Lean/Elab/InfoTree/Basic.lean:88` 的 `InfoState.substituteLazy` 等待的是现有 `lazyAssignment` task 列表，再将树中对应 hole 替换。它本身不新建“等待当前外层 command 结束”的 promise。
- `Lean/Elab/MutualDef.lean:1237` 仅在单 theorem 且 `Elab.async` 开启时调用 `elabAsync`；后者在 `1306` 附近创建 proof InfoTree hole/promise。probe 重放的是 `noncomputable def curveOf`，走 `elabSync`。
- `Lean/Elab/Command.lean:891` 在每条顶层命令开始时清空此前的 InfoState。因此下一条 `run_meta` 不能直接取得上一 command 的树；必须先保存，或在独立 frontend 返回 State 后读取。
- 同文件 `elabCommandTopLevel` 的 finally 先 resolve snapshot，之后才调用 `runLintersAsync`；其 linter InfoTree 等待 hole 在 `574–586` 创建。v166 在 nested `elabCommand` 返回后、当前外层结束前提取，不会已经含有该外层“结束后才加入”的 linter hole。

已验收 Stage2 实现 `prove2me_workspace/.local/adaptation/reference-extraction-20261115/ExtractReferenceStage2Batch.lean:140–161` 使用启用 InfoTree 的 `IO.processCommands`，在整个 frontend 返回后遍历 `s.commandState.infoState.trees`。这是可供参考的另一种已验证读取时点，但本轮按 root 决定保留原生 `#info_trees` 顺序，避免引入额外 frontend API 变化。

历史 Stage2 `ci-012821-e57c05a4` 成功回执显示 wall `236.7428303s`、CPU user `11.98s`、system `215.1s`、peak physical RSS `12002975744 bytes`（约 `11.18GiB`）。它证明来源查询的读入/系统开销可能显著，但不能证明本次 timeout 的具体原因。root 所述此前约 `129s` 的 B1 查询也是估计背景，不能替代此次实测。

本稿只在原 query 插入六个立即刷新的 stdout checkpoint：imports complete、command elaboration start、command elaboration end、InfoTree extraction start、InfoTree extraction end、resolved-reference JSON written。每项用 `IO.println` 后立即 `(← IO.getStdout).flush`。导入后第一 checkpoint 位于所有 probe helper 声明之前，因此若始终没有它，阻塞位于导入/到达该点之前；若有开始而无结束，则可定位到相应阶段。每个区间仍包含其内部所有工作，不能仅凭标签推断更细原因。

新文件保留原逻辑模块名 `QueryCurveOfResolvedReferenceV166.lean`，仅目录版本为 v171。原源 command bytes、declId-only probe rename、body、binders 与 `.get` 顺序全部不变；probe ref range 已更新为 `[5371,5397)`，原源仍为 `[10014,10040)`。配置 schema 与输出结构继续兼容 v166 的 `apply_verified_ref.py`。

资源按 root 指定的同一逻辑模块第二次尝试填写 `expected_duration: "300s"`、`expected_memory: "12GiB"`。这是以历史 Stage2 成功数据和当前超时下界为依据的预估，不覆盖 scheduler timeout。旧失败 query/config 未覆盖；新 query/config 已交 root 并冻结。本代理没有运行 Lean 或 MCP-CI。
