## 論文原文の背景

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示す。系の後続部分は引用しない。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61。正確な英文は英語部分に示す。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

これらの段落は、ルジャンドル曲線族と選ばれた代数閉包の背景を与える。五つの基礎的な補助宣言や完全なレコード構成関数を、逐語的なインターフェースとして述べるものではない。パラメータ、三つの選ばれた平方根、3 等分点と 5 等分点の座標集合から生成される完全な体は、参照プロジェクトの明示的な構成である。ソースの補助的帰結と条件付きのレコード構成は、その構成の基礎的な数学を与える。

