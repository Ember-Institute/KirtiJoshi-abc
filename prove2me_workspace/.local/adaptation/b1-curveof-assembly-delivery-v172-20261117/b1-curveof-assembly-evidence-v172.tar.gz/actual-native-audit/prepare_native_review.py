from pathlib import Path
import argparse, hashlib, json

D=Path('/tmp/p2m-b1-curveof-native-audit-v182-20261117')
S=Path('/tmp/p2m-b1-curveof-assembly-v166-20261117')
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
A=W/'.local/adaptation'

def load(p):return json.loads(p.read_text())
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def nm(n):return '' if not n else '.'.join(filter(None,[nm(n[0]),str(n[2])]))
def ne(n):
 r=[]
 for s in n.split('.'):r=[r,'str',s]
 return r
def result_head(e):
 while e.get('kind') in ['forall','mdata']:e=e['body']
 while e.get('kind')=='app':e=e['fn']
 return nm(e.get('name',[])) if e.get('kind')=='const' else e.get('kind')
def outer_count(e):
 n=0
 while e.get('kind')=='forall':n+=1;e=e['body']
 return n

def main():
 ap=argparse.ArgumentParser();ap.add_argument('inventory',type=Path);ap.add_argument('--output-directory',type=Path,default=D);ap.add_argument('--resolved-reference',type=Path,required=True);ap.add_argument('--source-normalization',type=Path,required=True);ap.add_argument('--source-normalization-receipt',type=Path,required=True);ap.add_argument('--source-query',type=Path,required=True);ap.add_argument('--source-query-sha256',required=True);ap.add_argument('--source-metadata-acceptance',type=Path,required=True);args=ap.parse_args()
 out=args.output_directory.resolve();out.mkdir(parents=True,exist_ok=True)
 inv=load(args.inventory);assert inv['schema']=='B1-curveOf-native-actual-inventory/v168'
 records=inv['records'];bydisplay={r['name']:r for r in records};assert len(bydisplay)==len(records)
 allSources=[load(p) for p in sorted((S/'source').glob('fact-*.json'))];assert len(allSources)==23
 sources=[f for f in allSources if not f['name'].startswith('Iut.EllipticCurveData') and 'instNumberField' not in f['name']];assert len(sources)==10
 priorSources=[f for f in allSources if f not in sources];assert len(priorSources)==13
 sourceOnly=[f for f in sources if f['name']=='Iut.Tripod.curveOf._proof_2'];assert len(sourceOnly)==1
 sources=[f for f in sources if f not in sourceOnly];assert len(sources)==9
 proof=sourceOnly[0];assert proof['kind']=='theorem' and not proof['isInstance'] and proof['isProposition'] and not proof['levelParams'] and outer_count(proof['actualTypeExpr'])==0
 proofs=[{**proof,'actualProofExpr':proof['actualValueExpr']}]
 ownerC='Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfCarrier';ownerA='Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOf'
 owned=[r for r in records if r['module'] in [ownerC,ownerA]]
 assert len(owned)==inv['ownedCount']
 selected=[]
 def pair(src,tgt,reason):
  selected.append({'sourceNameExpr':src['nameExpr'],'source':src['name'],'targetNameExpr':tgt['nameExpr'],'target':tgt['name'],'targetOwnerNameExpr':ne(tgt['module']),'targetOwner':tgt['module'],'resolution':reason})
 for sf in sources:
  sn=sf['name']
  if sn.startswith('Iut.EllipticCurveData'):
   tn='AbcAdaptation.Reference.'+sn
   candidates=[r for r in records if r['name']==tn and r['module']=='Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_EllipticCurveData']
   why='Existing accepted full ECD boundary, actual NameExpr re-read from native inventory'
  elif '_b1SourceReplay' in sn:
   h=result_head(sf['actualTypeExpr'])
   candidates=[r for r in owned if r['module']==ownerC and r['isInstance'] and result_head(r['elaboratedExpr'])==h and outer_count(r['elaboratedExpr'])==outer_count(sf['actualTypeExpr'])]
   why='Actual owner + instance registration + result head + explicit telescope count; no source replay suffix/name guess'
  elif sn.startswith('Iut.Tripod.curveOf.'):
   h=result_head(sf['actualTypeExpr']);h=h.replace('Iut.Tripod.','AbcAdaptation.Tripod.')
   candidates=[r for r in owned if r['module']==ownerA and r['constantKind']=='theorem' and not r['isInstance'] and result_head(r['elaboratedExpr'])==h and outer_count(r['elaboratedExpr'])==outer_count(sf['actualTypeExpr'])]
   why='Actual assembly owner + theorem kind + result head + telescope count; generated helper numbering/name not guessed'
  else:
   tn=sn.replace('Iut.Tripod.','AbcAdaptation.Tripod.',1)
   expected='Definitions.Def_AbcTripod' if 'instNumberField' in sn else ownerA if sn=='Iut.Tripod.curveOf' else ownerC
   candidates=[r for r in records if r['name']==tn and r['module']==expected]
   why='Exact public display uniquely resolved at actual owner, actual NameExpr read from inventory'
  assert len(candidates)==1,(sn,[(r['name'],r['module']) for r in candidates])
  pair(sf,candidates[0],why)
 assert len({nm(p['targetNameExpr']) for p in selected})==9
 assert {r['name'] for r in owned}=={p['target'] for p in selected if p['targetOwner'] in [ownerC,ownerA]},'All newly owned declarations require audit rows'
 boundarySources=load(S/'source/boundary-full-facts.json')+priorSources
 boundary=[]
 for sf in boundarySources:
  sn=sf['name'];tn=('AbcAdaptation.Reference.'+sn) if sn.startswith('Iut.EllipticCurveData') else sn.replace('Iut.Tripod.','AbcAdaptation.Tripod.',1)
  if sn=="Iut.Tripod.finiteDimensional_fieldOf'":tn='AbcAdaptation.Tripod.finiteDimensional_fieldOfExtended'
  tgt=bydisplay[tn]
  boundary.append({'source':sn,'sourceNameExpr':sf['nameExpr'],'target':tn,'targetNameExpr':tgt['nameExpr'],'targetOwner':tgt['module'],'targetOwnerNameExpr':ne(tgt['module']),'actualTargetNameTakenFromInventory':True,'boundaryPolicy':'Existing accepted correspondence; this audit retains the constant rather than expanding its body'})
 norm=load(args.source_normalization);receipt=load(args.source_normalization_receipt)
 assert norm['schema']=='B1-curveOf-torsionFree-source-normalization/v182'
 assert receipt['status']=='succeeded' and receipt['job_id']
 sourceQueryPin=pin(args.source_query.resolve());assert sourceQueryPin['sha256']==args.source_query_sha256,'Actual fixed source query SHA differs'
 nativeInput=norm['configuration']['nativeRecord'];actualInput=bydisplay['AbcAdaptation.Tripod.instIsTorsionFreeSubtypeQbarMemIntermediateFieldRat']
 assert nativeInput==actualInput,'Source certificate native candidate differs from entire actual inventory row'
 assert actualInput['module']=='Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfCarrier' and actualInput['constantKind']=='theorem' and actualInput['isInstance']
 assert actualInput['nameExpr']==ne('AbcAdaptation.Tripod.instIsTorsionFreeSubtypeQbarMemIntermediateFieldRat')
 rootMetadata=load(args.source_metadata_acceptance)
 assert rootMetadata['sourceQuerySHA256']==args.source_query_sha256 and rootMetadata['fullNativeRecordExactlyMatchesAcceptedInventory']
 assert not rootMetadata['sourceQueryContainsLaterTmpMetadataGuards'] and rootMetadata['mathematicalTYPEAndProofEqualityGuardsAreInCompiledQuery']
 assert rootMetadata['actualNativeNameExpr']==actualInput['nameExpr'] and rootMetadata['actualNativeOwner']==actualInput['module']
 assert rootMetadata['actualNativeKind']==actualInput['constantKind'] and rootMetadata['actualNativeIsInstance']==actualInput['isInstance']
 metadataAcceptance={'rootExternalVerificationBinding':{'pin':pin(args.source_metadata_acceptance.resolve()),'contents':rootMetadata},'actualNativeRecordNameOwnerKindInstanceVerified':True,'completeNativeRecordJSONEqualsActualInventory':True,'actualNativeRecord':actualInput,'actualNativeInventoryBinding':pin(args.inventory.resolve()),'sourceQueryBinding':sourceQueryPin,'fixedSourceQuerySHA256':args.source_query_sha256,'addedSourceMetadataGuardsClaimedCompiled':False,'verificationContext':'External preparation checks, separate from the frozen first-version source mathematical kernel checks'}
 for k in ['sourceKernelNormalizationChecked','originalWholeProofKernelChecked','sameWholePropTYPEKernelChecked','wholeProofKernelDefEq','wholeProofEqualityCertificateKernelChecked']:assert norm[k],k
 for k in ['nonPropositionalDataReplacementUsed','sourceASTOrBodyEdited','newAxiomsIntroduced','rawSourceProofByteIdentityClaimed']:assert not norm[k],k
 normSource=[r for r in sources if r['nameExpr']==norm['sourceNameExpr']];assert len(normSource)==1 and normSource[0]==norm['sourceRecord']
 assert norm['normalizedSourceRecord']['actualTypeExpr']==normSource[0]['actualTypeExpr']
 normalizationBinding={'file':str(args.source_normalization.resolve()),'contents':norm,'pin':pin(args.source_normalization.resolve()),'receiptFile':str(args.source_normalization_receipt.resolve()),'receiptContents':receipt,'receiptPin':pin(args.source_normalization_receipt.resolve()),'sourceNormalizationJob':receipt['job_id'],'sourceQueryBinding':sourceQueryPin,'externalMetadataAcceptance':metadataAcceptance}
 # Reuse the accepted ECD and NumberField boundaries, retaining all original Exprs.
 ecdFile=A/'b1-bare-normalized-review-v121-20261117/actual/bare-normalized-correspondence-audit.json'
 nfFile=A/'b1-existing-four-v115-20261117/actual/existing-four-correspondence-audit.json'
 ledgerFile=A/'b1-existing-and-elliptic-delivery-v123-20261117/SOURCE_LEDGER.json'
 ecd=load(ecdFile);nf=load(nfFile);ledger=load(ledgerFile)
 nfRows=[r for r in nf['reports'] if r['source']=='Iut.Tripod.instNumberFieldSubtypeQbarMemIntermediateFieldRatOfFiniteDimensional'];assert len(nfRows)==1
 reused={'fullECD12Acceptance':ecd,'fullECD12AcceptanceJob':'ci-018597-7df8415e','fullECD12AcceptanceBinding':pin(ecdFile),'numberFieldAcceptance':nfRows[0],'numberFieldAcceptanceJob':'ci-018574-8f1900b3','numberFieldAcceptanceBinding':pin(nfFile),'deliveryLedgerBinding':pin(ledgerFile),'deliveryLedger':ledger,'newBoundaryNormalizationsApplied':False}
 for p in boundary:
  if p['source'].startswith('Iut.EllipticCurveData'):p['acceptedReviewJob']='ci-018597-7df8415e'
  elif 'instNumberField' in p['source']:p['acceptedReviewJob']='ci-018574-8f1900b3'
 # Every source-only const occurrence receives its own precise JSON expression path.
 expansions=[]
 def uses(x,path,label):
  if isinstance(x,dict):
   if x.get('kind')=='const' and x.get('name')==proof['nameExpr']:
    assert x['levels']==[]
    expansions.append({'sourceExpression':label,'path':path,'sourceNameExpr':proof['nameExpr'],'universeArgumentCount':0,'expansion':'complete original actualValueExpr; no replacement target constant'})
   for k,v in x.items():
    if isinstance(v,(dict,list)):uses(v,path+'.'+k,label)
  elif isinstance(x,list):
   for i,v in enumerate(x):uses(v,path+'.'+str(i),label)
 for sf in sources+sourceOnly:
  for key,suffix in [('actualTypeExpr','TYPE'),('actualValueExpr','value')]:uses(sf[key],'root',sf['name']+':'+suffix)
 assert expansions,'Expected at least one real source-only proof reference'
 # Bind the complete source records and source closure evidence without editing Expr data.
 bound={'schema':'B1-curveOf-native-bound-inputs/v182','sourceRecords':sources,'sourceProofNormalizationBinding':normalizationBinding,'sourceOnlyProofRecords':proofs,'sourceOnlyProofExpansionOccurrences':expansions,'actualPairs':selected,'acceptedBoundaryPairs':boundary,'sourceBoundaryFullFacts':boundarySources,'acceptedCarrierBoundaryEvidence':reused,
  'sourceProjectClosure':load(S/'audit/source-project-closure-plan.json'),
  'sourceNineConstructorArguments':load(S/'audit/curveOf-nine-constructor-consumers.json'),
  'sourceGeneratedProofTelescopes':load(S/'audit/generated-proof-parameter-closure.json'),
  'sourceCompleteActualEdges':load(S/'source/assembly-complete-actual-edges.json'),
  'sourceProvenance':load(S/'source-provenance.json'),
  'nativeInventoryBinding':pin(args.inventory.resolve()),
  'sourceInputPins':[pin(p) for p in sorted((S/'source').glob('fact-*.json'))]+[pin(S/'source/boundary-full-facts.json')],
  'sourceFactsModified':False,'sourceOnlyFullProofExpansionApplied':True,'targetConstantFabricatedForSourceOnlyProof':False,'silentMathlibNameOrDataRewriteApplied':False,'sourceClosureMode':'Minimal project closure, full TYPE/value/proof/metadata for each row; external Lean/Mathlib names remain exact',
  'sourceRootClosureCIJob':'ci-018560-1db29f6e','resolvedReferenceBinding':None if args.resolved_reference is None else {'pin':pin(args.resolved_reference.resolve()),'contents':load(args.resolved_reference)}}
 bp=out/'curveof-native.bound-inputs.json';dump(bp,bound)
 cfg={'schema':'B1-curveOf-native-review-config/v182','boundInputsFile':str(bp),'boundInputsBinding':{'contents':bound,**pin(bp)},'outputFile':str(out/'curveof-native-review.json'),'nativeInventoryBinding':pin(args.inventory.resolve()),'compiledBySubagent':False,'newMathematicalAssumptions':False}
 dump(out/'curveof-native-review.config.json',cfg)
 dump(out/'actual-map-resolution.json',{'actualPairs':selected,'acceptedBoundaryPairs':boundary,'allNewOwnedConstantsAccountedFor':True,'rootAwaitingCI':True})
 print('Prepared',len(sources),'full mapped source rows and',len(proofs),'source-only full proof rows,',len(boundary),'existing boundaries;',len(owned),'new native owned declarations')
 print(out/'curveof-native-review.config.json')
if __name__=='__main__':main()
