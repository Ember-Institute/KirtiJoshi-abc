import Lean
import ArithmeticTeichmullerSpaces.Prologue.Audit.Checks
import ArithmeticTeichmullerSpaces.Prologue.Audit.ImportAudit
import ArithmeticTeichmullerSpaces.Act1Scene1
import ArithmeticTeichmullerSpaces.Prologue.Audit.AxiomAudit
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfCarrier
import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOf

#print axioms AbcAdaptation.Tripod.gen'_ne_zero
#print axioms AbcAdaptation.Tripod.gen'_ne_one
#print axioms AbcAdaptation.Tripod.legendre_gen'_isElliptic
#print axioms AbcAdaptation.Tripod.curveOf

open Lean Elab Command Meta in
run_meta do
  let env ← getEnv
  let owners : Array Name := #[
    `Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfCarrier,
    `Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOf]
  let names := env.constants.fold (fun result name _ =>
    match env.getModuleIdxFor? name with
    | none => result
    | some index => if (env.header.moduleNames[index.toNat]?).any owners.contains then result.push name else result) (#[] : Array Name)
  unless names.size == 9 do throwError "Expected all nine native owned declarations"
  for name in names.qsort Name.lt do
    let axioms ← collectAxioms name
    for axiomName in axioms do
      unless #[`propext, `Classical.choice, `Quot.sound].contains axiomName do
        throwError "Unexpected axiom {axiomName} in {name}"
    logInfo "{name}: standard axioms {axioms}"
  logInfo "Checks, ImportAudit, Act1Scene1 and AxiomAudit imported; all nine new declarations have standard axioms only"
