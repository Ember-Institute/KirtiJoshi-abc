from pathlib import Path
import json,hashlib,shutil,re
from datetime import datetime,timezone
O=Path('/tmp/p2m-b1-curveof-assembly-publication-v177-20261117');P=Path('/tmp/p2m-b1-curveof-assembly-publication-v170-20261117');F=Path('/tmp/p2m-b1-curveof-assembly-fresh-blind-v174-20261117');W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
oldhashes={str(p):sha(p) for p in P.rglob('*') if p.is_file()};frozen={str(p):sha(p) for p in F.rglob('*') if p.is_file()};fm=json.loads((F/'manifest.json').read_text());ef=json.loads((F/'english-freeze.json').read_text())
for n,h in fm['artifact_sha256'].items():assert sha(F/n)==h
for n,h in ef['sha256'].items():assert sha(F/n)==h
assert sha(F/'english-freeze.json')==fm['english_freeze_sha256']
intuition={
'carrier':{'en':'These helpers let the same algebraic parameter be used inside its generated field. They also make the fixed algebraic closure available over any intermediate field and carry the two parameter inequalities into the Legendre ellipticity condition.','zh-CN':'这些辅助声明让同一个代数参数可以在其生成域中使用，也使固定代数闭包可作为任意中间域的代数闭包，并将参数的两个不等式用于 Legendre 曲线的椭圆性条件。','ja':'これらの補助宣言により、同じ代数的パラメータをその生成体の中で扱える。また、固定した代数閉包を任意の中間体上の代数閉包として用い、パラメータの二つの不等式からルジャンドル曲線の楕円性を得る。'},
'assembly':{'en':'Once the point and the two finiteness proofs are supplied, the construction keeps the generated number field, the fixed algebraic closure, and the Legendre equation together in one elliptic-curve record.','zh-CN':'给定参数点和两个有限性证明后，这个构造把生成的数域、固定代数闭包及 Legendre 方程保存在同一个椭圆曲线记录中。','ja':'パラメータ点と二つの有限性の証明を与えると、この構成は、生成された数体、固定した代数閉包、およびルジャンドル方程式を一つの楕円曲線レコードにまとめる。'}}
units=[]
for label,rbprefix,suffix in [('carrier','carrier','CurveOfCarrier'),('assembly','curveof','CurveOf')]:
 source=W/f'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_{suffix}.lean';assert sha(source)==fm['source_sha256'][str(source)]
 prelim=json.loads((P/label/'publication-fields.preliminary.json').read_text());parts=[];mathblocks={}
 for lang,edlang,langlabel,iheading in [('en','en','English','Intuitive explanation (non-rigorous)'),('zh-CN','zh-Hans','简体中文','直观解释（非严格）'),('ja','ja','日本語','直観的説明（非厳密）')]:
  raw=(F/f'{rbprefix}.readback.{lang}.md').read_text();math=raw[raw.index('## '):];mathblocks[lang]=math
  editorial=(P/f'source-editorial.{edlang}.md').read_text()
  parts.append('# '+langlabel+'\n\n'+math.rstrip()+'\n\n'+editorial.rstrip()+'\n\n## '+iheading+'\n\n'+intuition[label][lang])
 statement='\n\n'.join(parts)+'\n'
 payload={k:prelim[k] for k in ['definition_name','definition_title']};payload.update(definition=source.read_text(),natural_language_statement=statement,source=prelim['source'],env=prelim['env'],private=prelim['private'])
 assert list(payload)==['definition_name','definition_title','definition','natural_language_statement','source','env','private']
 assert len(payload['definition_title'])<=200
 assert payload['definition']==source.read_text() and sha(source)==fm['source_sha256'][str(source)]
 assert payload['env']=='0df444a360eaa60ab8c11dca51a86af692955474' and payload['private'] is True
 assert re.fullmatch('[a-zA-Z_][a-zA-Z0-9_]*',payload['definition_name'])
 assert all(math.rstrip() in statement for math in mathblocks.values())
 assert not re.search(r'ci-\d|gpt-|SHA.?256|\bhash\b|\bCI\b|编译|コンパイル',statement,re.I)
 dest=O/label;dest.mkdir(exist_ok=True);(dest/'payload.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');(dest/'natural-language-statement.md').write_text(statement);shutil.copyfile(source,dest/source.name)
 units.append({'bundle':label,'definition_name':payload['definition_name'],'source':rec(source),'payload':rec(dest/'payload.json'),'payload_code_utf8_sha256':hashlib.sha256(payload['definition'].encode()).hexdigest(),'math_readback_sources':[rec(F/f'{rbprefix}.readback.{lang}.md') for lang in ['en','zh-CN','ja']],'exactness':{'code_byte_identical_canonical':True,'all_math_readback_blocks_verbatim':True,'only_process_preface_before_first_math_heading_omitted':True,'five_noncontent_preliminary_fields_reused_exactly':all(payload[k]==prelim[k] for k in prelim)},'static_payload_checks':{'seven_keys_exact':True,'name_regex':True,'title_max200':True,'env_exact':True,'private_true':True,'no_process_metadata_in_product_statement':True}})
(O/'independent-readback').mkdir(exist_ok=True)
for p in F.iterdir():
 if p.is_file():shutil.copyfile(p,O/'independent-readback'/p.name)
for n in ['paper-context.json','code-provenance.json','source-LICENSE-Apache-2.0.txt']:
 shutil.copyfile(P/n,O/n)
receipts=[]
R=W/'.local/adaptation/main-chain-open-20261116'
for n in ['b1-curveof-carrier-definition-leaf-v167-result.json','b1-curveof-carrier-definition-artifact-v167-result.json','b1-curveof-assembly-definition-leaf-v173-result.json','b1-curveof-assembly-definition-artifact-v173-result.json','b1-curveof-resolved-ref-source-probe-v171-result.json']:
 p=R/n;d=json.loads(p.read_text());assert d['status']=='succeeded' and d['result']['exit_code']==0
 resources=d.get('resources',{});cpu=resources.get('cpu_time_seconds');cu=resources.get('cpu_user_seconds');cs=resources.get('cpu_system_seconds')
 if cpu is not None and cu is not None and cs is not None:assert abs(cpu-cu-cs)<1e-6
 receipts.append({'receipt':rec(p),'job_id':d['job_id'],'status':d['status'],'exit_code':d['result']['exit_code'],'workspace':d['request']['workspace'],'source':d['request']['parameters'].get('source'),'actual_arguments':d['result'].get('actual_arguments'),'resources':resources})
meta={'schema':'B1-CurveOfAssembly-two-private-definition-payloads/v177','created_utc':datetime.now(timezone.utc).isoformat(),'status':'STATICALLY_VALIDATED_NOT_POSTED','editorial_model':'gpt-6.1-sol','editorial_not_new_independent_readback':True,'submission_order':['carrier','assembly'],'units':units,'environment':'0df444a360eaa60ab8c11dca51a86af692955474','private':True,'frozen_independent_readback':{'directory':str(F),'model':fm['model'],'audit_count':fm['audit_count'],'all_file_hashes':frozen,'all_originals_unchanged':all(sha(Path(p))==h for p,h in frozen.items()),'all_three_language_mathematical_blocks_verbatim':True,'process_prefaces_preserved_in_originals_and_copies':True,'translations_not_extra_independent_audits':True,'READ_SCOPE':rec(F/'READ_SCOPE.md'),'manifest':rec(F/'manifest.json'),'english_freeze':rec(F/'english-freeze.json')},'prior_preparatory_draft':{'directory':str(P),'all_original_file_hashes':oldhashes,'v170_unchanged':all(sha(Path(p))==h for p,h in oldhashes.items())},'paper_and_license':{'paper_context':rec(O/'paper-context.json'),'code_provenance':rec(O/'code-provenance.json'),'license':rec(O/'source-LICENSE-Apache-2.0.txt'),'source_background_reused_from_v170':True,'observed_source_hashes_in_old_provenance_are_historical_not_final':'The final canonical hashes are the unit.source entries above. v170 provenance preserves its historical observations and pending-ref status.'},'accepted_existing_receipts':receipts,'resolved_ref':{'accepted_job_id_reported_by_parent':'ci-018880','only_finiteDimensional_reference_renamed_to_Extended':True,'obsolete_draft_wrapper_comment_absent':"/- DRAFT:" not in (W/'Definitions/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOf.lean').read_text(),'final_reference':'finiteDimensional_fieldOfExtended h3 h5'},'scope':{'carrier_instances_for_arbitrary_intermediate_field_no_finite_degree_premise':True,'curveOf_three_explicit_inputs_x_h3_h5':True,'nine_record_fields_covered_by_frozen_readback':True,'no_Galois_or_CurveArithmetic_output_added':True,'no_unconditional_supplier_existence_added':True,'no_separate_small_problem_nodes':True},'operations':{'CI_compiler_API_Git_executed':False,'main_workspace_written':False,'v170_or_blind_originals_changed':False,'publication_performed':False},'acceptance_boundary':'This is static payload validation plus read-only inspection of saved receipts. It does not create a new compiler, kernel, or platform-acceptance receipt.'}
(O/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
checks={'schema':'B1-CurveOfAssembly-static-payload-validation/v177','submission_order':['carrier','assembly'],'checks_by_bundle':{u['bundle']:{**u['exactness'],**u['static_payload_checks']} for u in units},'canonical_hashes_match_fresh_reader_manifest':True,'frozen_English_and_translations_hashes_match':True,'original_freshblind_directory_unchanged':True,'v170_draft_unchanged':True,'not_posted':True}
(O/'validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
assert all(sha(Path(p))==h for p,h in frozen.items());assert all(sha(Path(p))==h for p,h in oldhashes.items())
print(json.dumps({'submission_order':['carrier','assembly'],'payloads':[{'bundle':u['bundle'],'name':u['definition_name'],'source_sha256':u['source']['sha256'],'payload_sha256':u['payload']['sha256'],'path':u['payload']['path']} for u in units],'static_checks_passed':True},ensure_ascii=False,indent=2))
