# Reading scope, independence disclosure, and binder inventory

This delivery contains one independent English read-back, split into two bundles, and its Simplified Chinese and Japanese translations. It does not contain three independent audits. The English files were written and hashed in `english-freeze.json` before any translation file was created. Their frozen hashes were checked after translation. The model designation is gpt-6.1-sol.

The two output bundles cover exactly the declarations introduced in the two requested final Lean files: five declarations in CurveOfCarrier and one in CurveOf. Neither target introduces a separate type declaration. Definitions and structures from actual imports were read only to resolve the meaning and inferred structures of these six declarations; they are expanded within the read-back where needed rather than treated as additional output declarations.

## Independence and visibility disclosure

The auditor read `references/mission_auditor.md` and `docs/三语自然语言读回原则.md` first. It then read the two target files and the local imports recorded in `manifest.json`. Raw source display made natural-language comments visible, including adaptation provenance, copyright, mathematical docstrings, and comments about proof status or intended uses. These comments were disregarded when determining the meaning of each declaration. In particular, the description of the output field uses the actual adjoin expression, not mathematical claims in its docstring.

One necessary import, `Definitions/Def_AbcTripod.lean`, was displayed in full while resolving `Qbar`, `Pt`, and the number-field instance. This also exposed its unused later formal declarations and comments, including height, discriminant, conductor, bounded-set, StatementI/StatementII, and projection declarations. Those declarations were not used to infer the meaning or intended role of either target. This extra visible scope is explicitly disclosed; the read-back is based on the six target declarations and the definitions and structures that their actual types require.

No other `/tmp` draft, source ledger, paper, old read-back, or separately supplied description of the parent objective was read. No external source or terminology lookup was performed. Only ordinary mathematical vocabulary was needed; no new specialized translation was proposed as settled terminology.

To determine imported type meanings, the auditor inspected the actual Mathlib declarations for `WeierstrassCurve.IsElliptic`, `NumberField`, `IsAlgClosure`, and the nonsingular affine `Point` type. Searches also returned the location of `Module.isTorsionFree_iff_algebraMap_injective`. Two initial Mathlib path probes failed because the workspace did not have a `mathlib` package symlink; a directory listing resolved the existing external Mathlib tree. This did not run Lean or change dependencies. All ripgrep calls used the required `.local/bin/rg-two-cores` wrapper.

## Exact binder and typeclass inventory

| Bundle / source line | Declaration | Quantified or explicit inputs | Result and inferred-structure scope |
| --- | --- | --- | --- |
| Carrier:20 | `gen'_ne_zero` | Implicit `{l : Qbar}`; explicit proof `(hl : l ≠ 0)` | `gen' l ≠ 0` in `fieldOf' l`; existing field, zero, algebraic-closure, and intermediate-field structures. No caller-supplied typeclass binder and no torsion-finiteness premise. |
| Carrier:24 | `gen'_ne_one` | Implicit `{l : Qbar}`; explicit proof `(hl : l ≠ 1)` | `gen' l ≠ 1` in `fieldOf' l`; existing field, identity, algebraic-closure, and intermediate-field structures. No caller-supplied typeclass binder and no torsion-finiteness premise. |
| Carrier:30 | Anonymous torsion-free instance | Explicit `(F : IntermediateField ℚ Qbar)` | `Module.IsTorsionFree F Qbar`, for the inclusion-induced scalar action. `F` is arbitrary, without a finite-dimensionality binder. The field and scalar structures are synthesized from the concrete intermediate field. |
| Carrier:34 | Anonymous algebraic-closure instance | Explicit `(F : IntermediateField ℚ Qbar)` | `IsAlgClosure F Qbar`, for the inclusion-induced algebra structure. The required torsion-free instance is synthesized from the preceding declaration. No finite-dimensionality binder or external algebraic-closure assumption is supplied by the caller. |
| Carrier:39 | `legendre_gen'_isElliptic` | Explicit `(x : Pt)`; `Pt` internally contains `x.1 ≠ 0 ∧ x.1 ≠ 1` | `(legendre (gen' x.1)).IsElliptic`; coefficient type `fieldOf' x.1`. The field, commutative-ring, and nonzero-2 structures are inferred; no torsion-finiteness binder. |
| CurveOf:25 | `curveOf` | Explicit `(x : Pt)`, `(h3 : TorsionFinite x.1 3)`, `(h5 : TorsionFinite x.1 5)` | A value of `EllipticCurveData` with its structure universe instantiated at 0, hence a record type in universe 1. No implicit element binder or caller-supplied typeclass binder. A local inferred `FiniteDimensional ℚ (fieldOf' x.1)` is installed using `h3` and `h5`. |

The `curveOf` record sets `F`, `Fbar`, `E`, and `isElliptic` explicitly. It also fills inferred fields `fieldF`, `numberFieldF`, `fieldFbar`, `algebraFbar`, and `isAlgClosure`. The imported `numberFieldF` structure records characteristic zero and finite-dimensionality over the rationals. The imported `isAlgClosure` structure records algebraic closedness and algebraicity, with an inferred torsion-free module parameter. All of these structures are described in the read-back. The square-root choices are fixed by the imported definitions, not arguments or uniqueness claims.

## Verification boundary

This was a source-only read-back. No CLI compiler, MCP-CI job, external API, Git command, snapshot, or write outside this task's temporary directory was used. Hash and heading-count checks verified the frozen English files and the six-declaration alignment of the translations. This delivery does not certify a compilation or an axiom audit.
