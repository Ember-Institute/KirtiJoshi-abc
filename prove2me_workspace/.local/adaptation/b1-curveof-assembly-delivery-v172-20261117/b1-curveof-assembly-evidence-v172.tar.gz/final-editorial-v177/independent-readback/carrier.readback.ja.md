# 独立した英語読み戻しの日本語訳 — 第1束：CurveOfCarrier

本ファイルは凍結済みの `carrier.readback.en.md` の翻訳である。要約値は `english-freeze.json` に記録されている。原文の独立読解モデルは gpt-6.1-sol である。本訳文は別の独立監査ではない。

## `gen'_ne_zero`

$\overline{\mathbb Q}$ を固定された $\mathbb Q$ の代数閉包とする。暗黙に量化された任意の $\lambda\in\overline{\mathbb Q}$ と、明示的に与えられる任意の $\lambda\ne0$ の証明に対し、$\lambda$ を以下の中間体 $F_\lambda$ の元とみなすと、それはこの体において零でない。ここで $F_\lambda$ は、有理数、$\lambda$、選ばれた $-1$ の平方根、選ばれた $\lambda$ の平方根、選ばれた $1-\lambda$ の平方根、および $\overline{\mathbb Q}$ 上の方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ の非特異点群において $3$ 倍または $5$ 倍すると零になる点のすべてのアフィン座標を含む、$\overline{\mathbb Q}$ の最小の部分体である。この点群は、指定された零点と、この方程式の非特異なアフィン解からなる。零点は座標を与えず、アフィン点 $(a,b)$ は集合 $\{a,b\}$ を与える。`gen'` と記される元は、まさに $\lambda$ と、その $F_\lambda$ への所属の証明を組にしたものである。このパラメータは $1$ に等しくてもよい。いずれの捩れ点集合の有限性も前提ではない。

## `gen'_ne_one`

$\overline{\mathbb Q}$ を固定された $\mathbb Q$ の代数閉包とする。暗黙に量化された任意の $\lambda\in\overline{\mathbb Q}$ と、明示的に与えられる任意の $\lambda\ne1$ の証明に対し、$\lambda$ を以下の中間体 $F_\lambda$ の元とみなすと、それはこの体の乗法単位元と異なる。ここで $F_\lambda$ は、有理数、$\lambda$、選ばれた $-1$ の平方根、選ばれた $\lambda$ の平方根、選ばれた $1-\lambda$ の平方根、および $\overline{\mathbb Q}$ 上の方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ の非特異点群において $3$ 倍または $5$ 倍すると零になる点のすべてのアフィン座標を含む、$\overline{\mathbb Q}$ の最小の部分体である。この点群は、指定された零点と、この方程式の非特異なアフィン解からなる。零点は座標を与えず、アフィン点 $(a,b)$ は集合 $\{a,b\}$ を与える。`gen'` と記される元は、まさに $\lambda$ と、その $F_\lambda$ への所属の証明を組にしたものである。このパラメータは $0$ に等しくてもよい。いずれの捩れ点集合の有限性も前提ではない。

## 結果の型が `Module.IsTorsionFree F Qbar` である無名インスタンス

$\mathbb Q$ とその固定された代数閉包 $\overline{\mathbb Q}$ の間の任意の中間体 $F$ を明示的に与えると、この宣言は、包含写像 $F\hookrightarrow\overline{\mathbb Q}$ を通じたスカラー倍に関して $\overline{\mathbb Q}$ が捩れのない $F$-加群であるという主張を与える。具体的には、任意の $a\in F$ と $z\in\overline{\mathbb Q}$ に対し、$a\ne0$ かつ $a\cdot z=0$ ならば $z=0$ である。体構造と加群構造は、中間体と代数閉包の既存の構造であり、呼出し側が追加の仮定として与えるものではなく推論される。$F$ の次数が有限であるという制限はない。中間体全体 $F=\overline{\mathbb Q}$ も含まれる。

## 結果の型が `IsAlgClosure F Qbar` である無名インスタンス

$\mathbb Q$ とその固定された代数閉包 $\overline{\mathbb Q}$ の間の任意の中間体 $F$ を明示的に与えると、この宣言は、包含写像で定まる拡大 $\overline{\mathbb Q}/F$ に代数閉包の構造を与える。したがって、$\overline{\mathbb Q}$ は代数閉体であり、その各元は $F$ 上代数的である。すなわち、$F$ に係数を持つある零でない多項式を満たす。体構造、$\overline{\mathbb Q}$ 上の $F$-代数構造、および捩れのない $F$-加群の構造は、既存の構造と直前のインスタンスから推論され、呼出し側が追加で与える仮定ではない。この主張は、有限次数の制限なしに、このようなすべての中間体に適用され、$F=\overline{\mathbb Q}$ も含まれる。

## `legendre_gen'_isElliptic`

$\overline{\mathbb Q}$ を固定された $\mathbb Q$ の代数閉包とする。部分型 $\{\lambda\in\overline{\mathbb Q}:\lambda\ne0\ \text{かつ}\ \lambda\ne1\}$ の点 $p$ を明示的に任意に与えると、$F_\lambda$ 上で係数が $(a_1,a_2,a_3,a_4,a_6)=(0,-(1+t),0,t,0)$ である Weierstrass 曲線の判別式は可逆である。ここで $\lambda$ は $p$ の基になる元であり、$t$ は $\lambda$ を $F_\lambda$ の元とみなしたものである。この体において判別式が零でないというのも同値な表現である。ここで $F_\lambda$ は、有理数、$\lambda$、選ばれた $-1$ の平方根、選ばれた $\lambda$ の平方根、選ばれた $1-\lambda$ の平方根、および $\overline{\mathbb Q}$ 上の方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ の非特異点群において $3$ 倍または $5$ 倍すると零になる点のすべてのアフィン座標を含む、$\overline{\mathbb Q}$ の最小の部分体である。この群は零点と非特異なアフィン解からなる。零点は座標を与えず、$(a,b)$ は $\{a,b\}$ を与える。部分型の引数は既に二つの不等式を含む。この定理の引数には、いずれの捩れ点集合についても有限性の証明は含まれない。曲線に用いる体、環、および $2$ の非零性のインスタンスは $F_\lambda$ から推論される。
