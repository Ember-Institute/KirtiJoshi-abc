# 独立英文读回的简体中文译文——第一组：CurveOfCarrier

本文件译自已冻结的 `carrier.readback.en.md`，其摘要见 `english-freeze.json`。原始独立审读模型为 gpt-6.1-sol。本译文不是另一次独立审计。

## `gen'_ne_zero`

设 $\overline{\mathbb Q}$ 为固定的 $\mathbb Q$ 的代数闭包。对每个隐式量化的 $\lambda\in\overline{\mathbb Q}$ 和每个显式给出的 $\lambda\ne0$ 的证明，将 $\lambda$ 视为下述中间域 $F_\lambda$ 的元素后，它在该域中非零。这里，$F_\lambda$ 是 $\overline{\mathbb Q}$ 中包含有理数、$\lambda$、选定的 $-1$ 的平方根、选定的 $\lambda$ 的平方根、选定的 $1-\lambda$ 的平方根，以及方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 在 $\overline{\mathbb Q}$ 上的非奇异点群中所有被乘以 $3$ 或乘以 $5$ 消去的点的仿射坐标的最小子域。该点群由一个指定的零点和此方程的非奇异仿射解组成；零点不贡献坐标，仿射点 $(a,b)$ 贡献集合 $\{a,b\}$。记为 `gen'` 的元素恰好是 $\lambda$ 连同它属于 $F_\lambda$ 的证明。此参数允许等于 $1$；两个挠点集合的有限性都不是前提。

## `gen'_ne_one`

设 $\overline{\mathbb Q}$ 为固定的 $\mathbb Q$ 的代数闭包。对每个隐式量化的 $\lambda\in\overline{\mathbb Q}$ 和每个显式给出的 $\lambda\ne1$ 的证明，将 $\lambda$ 视为下述中间域 $F_\lambda$ 的元素后，它不同于该域的乘法单位元。这里，$F_\lambda$ 是 $\overline{\mathbb Q}$ 中包含有理数、$\lambda$、选定的 $-1$ 的平方根、选定的 $\lambda$ 的平方根、选定的 $1-\lambda$ 的平方根，以及方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 在 $\overline{\mathbb Q}$ 上的非奇异点群中所有被乘以 $3$ 或乘以 $5$ 消去的点的仿射坐标的最小子域。该点群由一个指定的零点和此方程的非奇异仿射解组成；零点不贡献坐标，仿射点 $(a,b)$ 贡献集合 $\{a,b\}$。记为 `gen'` 的元素恰好是 $\lambda$ 连同它属于 $F_\lambda$ 的证明。此参数允许等于 $0$；两个挠点集合的有限性都不是前提。

## 结果类型为 `Module.IsTorsionFree F Qbar` 的匿名实例

对每个显式给出的、介于 $\mathbb Q$ 与其固定代数闭包 $\overline{\mathbb Q}$ 之间的中间域 $F$，此声明提供如下断言：通过包含映射 $F\hookrightarrow\overline{\mathbb Q}$ 定义标量乘法后，$\overline{\mathbb Q}$ 是无挠 $F$-模。具体地，对每个 $a\in F$ 和 $z\in\overline{\mathbb Q}$，若 $a\ne0$ 且 $a\cdot z=0$，则 $z=0$。域结构和模结构采用中间域及代数闭包已有的结构；这些结构由系统推断，不是调用者额外提供的假设。对 $F$ 没有有限次数限制；也包含整个中间域 $F=\overline{\mathbb Q}$ 的情形。

## 结果类型为 `IsAlgClosure F Qbar` 的匿名实例

对每个显式给出的、介于 $\mathbb Q$ 与其固定代数闭包 $\overline{\mathbb Q}$ 之间的中间域 $F$，此声明为包含映射定义的扩张 $\overline{\mathbb Q}/F$ 提供代数闭包结构。因此，$\overline{\mathbb Q}$ 是代数闭域，其每个元素都在 $F$ 上代数，即满足某个系数属于 $F$ 的非零多项式。两个域结构、$\overline{\mathbb Q}$ 上的 $F$-代数结构，以及它的无挠 $F$-模结构，均由已有结构和前一个实例推断；它们不是调用者额外提供的假设。此断言适用于每个这样的中间域，没有有限次数限制，也包含 $F=\overline{\mathbb Q}$。

## `legendre_gen'_isElliptic`

对每个显式给出的子类型 $\{\lambda\in\overline{\mathbb Q}:\lambda\ne0\ \text{且}\ \lambda\ne1\}$ 的点 $p$，其中 $\overline{\mathbb Q}$ 是固定的 $\mathbb Q$ 的代数闭包，$F_\lambda$ 上系数为 $(a_1,a_2,a_3,a_4,a_6)=(0,-(1+t),0,t,0)$ 的 Weierstrass 曲线具有可逆的判别式；这里 $\lambda$ 是 $p$ 的底层元素，$t$ 是将 $\lambda$ 视为 $F_\lambda$ 的元素所得的元素。等价地，在这个域上，判别式非零。这里，$F_\lambda$ 是 $\overline{\mathbb Q}$ 中包含有理数、$\lambda$、选定的 $-1$ 的平方根、选定的 $\lambda$ 的平方根、选定的 $1-\lambda$ 的平方根，以及方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 在 $\overline{\mathbb Q}$ 上的非奇异点群中所有被乘以 $3$ 或乘以 $5$ 消去的点的仿射坐标的最小子域。该群由零点和非奇异仿射解组成；零点不贡献坐标，$(a,b)$ 贡献 $\{a,b\}$。子类型参数已经包含两个不等式。此定理不以任一挠点集合的有限性证明为参数；曲线使用的域实例、环实例和 $2$ 非零的实例均由 $F_\lambda$ 推断。
