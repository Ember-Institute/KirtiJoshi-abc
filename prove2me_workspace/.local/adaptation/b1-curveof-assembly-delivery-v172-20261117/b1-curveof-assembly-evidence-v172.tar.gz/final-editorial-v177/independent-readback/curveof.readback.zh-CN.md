# 独立英文读回的简体中文译文——第二组：CurveOf

本文件译自已冻结的 `curveof.readback.en.md`，其摘要见 `english-freeze.json`。原始独立审读模型为 gpt-6.1-sol。本译文不是另一次独立审计。

## `curveOf`

这个非可计算定义接收三个显式参数：子类型 $\{\lambda\in\overline{\mathbb Q}:\lambda\ne0\ \text{且}\ \lambda\ne1\}$ 的一个点 $p$；方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 在 $\overline{\mathbb Q}$ 上所有被乘以 $3$ 消去的非奇异点所成集合有限的证明；以及所有被乘以 $5$ 消去的非奇异点所成的对应集合有限的证明。这里，$\overline{\mathbb Q}$ 是固定的 $\mathbb Q$ 的代数闭包，$\lambda$ 是 $p$ 的底层元素。每个点集使用的群由一个指定的零点和所示方程的非奇异仿射解组成。输出是一个 `EllipticCurveData` 记录，其中域类型位于宇宙 $0$，记录类型位于宇宙 $1$。其基域是 $\overline{\mathbb Q}$ 的中间域 $F_\lambda$：它在 $\mathbb Q$ 上由 $\lambda$、选定的 $-1$ 的平方根、选定的 $\lambda$ 的平方根、选定的 $1-\lambda$ 的平方根，以及上述 $3$-挠点和 $5$-挠点的全部仿射坐标生成；零点不贡献坐标，仿射点 $(a,b)$ 贡献 $\{a,b\}$。记录中的扩张域恰好是 $\overline{\mathbb Q}$，代数结构由 $F_\lambda$ 的包含映射给出。记录中的 $F_\lambda$ 上的曲线具有 Weierstrass 系数 $(a_1,a_2,a_3,a_4,a_6)=(0,-(1+t),0,t,0)$，其中 $t$ 是将 $\lambda$ 视为 $F_\lambda$ 的元素所得的元素。该记录还保存两个域的域结构、$F_\lambda$ 是数域的断言（特征为零且在 $\mathbb Q$ 上有限维）、$\overline{\mathbb Q}$ 的 $F_\lambda$-代数结构、此扩张的代数闭包结构（扩张域是代数闭域且在 $F_\lambda$ 上代数），以及曲线的判别式是可逆元的断言。$F_\lambda$ 的有限维结构在局部使用两个有限性证明获得；其余省略的记录字段由已有实例推断填入，其中椭圆性断言由 `legendre_gen'_isElliptic` 在 $p$ 处给出。代数闭包断言需要的无挠模结构也由包含映射所对应的实例推断。所有平方根都是导入的定义所作的固定选择；没有把唯一性或额外平方根选择作为参数传入。此定义没有隐式元素参数，也没有调用者提供的类型类参数。
