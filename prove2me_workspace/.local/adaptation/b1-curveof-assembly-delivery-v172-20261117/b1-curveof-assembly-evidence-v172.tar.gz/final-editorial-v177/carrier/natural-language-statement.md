# English

## `gen'_ne_zero`

Let $\overline{\mathbb Q}$ be the fixed algebraic closure of $\mathbb Q$. For every implicitly quantified $\lambda\in\overline{\mathbb Q}$ and every explicit proof that $\lambda\ne0$, the element $\lambda$ regarded as an element of the following intermediate field $F_\lambda$ is nonzero in that field. Here $F_\lambda$ is the smallest subfield of $\overline{\mathbb Q}$ containing the rational numbers, $\lambda$, a chosen square root of $-1$, a chosen square root of $\lambda$, a chosen square root of $1-\lambda$, and all affine coordinates of the points killed by multiplication by $3$ or by $5$ in the group of nonsingular points of $y^2=x^3-(1+\lambda)x^2+\lambda x$ over $\overline{\mathbb Q}$. This point group consists of a distinguished zero point and the nonsingular affine solutions of that equation; the zero point contributes no coordinates, and an affine point $(a,b)$ contributes the set $\{a,b\}$. The element denoted by `gen'` is precisely $\lambda$ together with its membership in $F_\lambda$. The parameter may equal $1$; no finiteness assumption on either torsion set is a premise.

## `gen'_ne_one`

Let $\overline{\mathbb Q}$ be the fixed algebraic closure of $\mathbb Q$. For every implicitly quantified $\lambda\in\overline{\mathbb Q}$ and every explicit proof that $\lambda\ne1$, the element $\lambda$ regarded as an element of the following intermediate field $F_\lambda$ differs from its multiplicative identity. Here $F_\lambda$ is the smallest subfield of $\overline{\mathbb Q}$ containing the rational numbers, $\lambda$, a chosen square root of $-1$, a chosen square root of $\lambda$, a chosen square root of $1-\lambda$, and all affine coordinates of the points killed by multiplication by $3$ or by $5$ in the group of nonsingular points of $y^2=x^3-(1+\lambda)x^2+\lambda x$ over $\overline{\mathbb Q}$. This point group consists of a distinguished zero point and the nonsingular affine solutions of that equation; the zero point contributes no coordinates, and an affine point $(a,b)$ contributes the set $\{a,b\}$. The element denoted by `gen'` is precisely $\lambda$ together with its membership in $F_\lambda$. The parameter may equal $0$; no finiteness assumption on either torsion set is a premise.

## Anonymous instance with result `Module.IsTorsionFree F Qbar`

For every explicitly supplied intermediate field $F$ between $\mathbb Q$ and its fixed algebraic closure $\overline{\mathbb Q}$, this declaration supplies the assertion that $\overline{\mathbb Q}$ is a torsion-free $F$-module for scalar multiplication through the inclusion $F\hookrightarrow\overline{\mathbb Q}$. Concretely, for every $a\in F$ and $z\in\overline{\mathbb Q}$, if $a\ne0$ and $a\cdot z=0$, then $z=0$. The field and module structures are the existing structures of the intermediate field and the algebraic closure; they are inferred rather than additional hypotheses supplied by a caller. There is no finite-degree restriction on $F$; the full intermediate field $F=\overline{\mathbb Q}$ is included.

## Anonymous instance with result `IsAlgClosure F Qbar`

For every explicitly supplied intermediate field $F$ between $\mathbb Q$ and its fixed algebraic closure $\overline{\mathbb Q}$, this declaration supplies an algebraic-closure structure on the extension $\overline{\mathbb Q}/F$ defined by the inclusion. Thus $\overline{\mathbb Q}$ is algebraically closed, and each of its elements is algebraic over $F$, meaning that it satisfies a nonzero polynomial with coefficients in $F$. The field structures, the $F$-algebra structure on $\overline{\mathbb Q}$, and its torsion-free $F$-module structure are inferred from the existing structures and the preceding instance; they are not extra caller-supplied assumptions. The assertion applies to every such intermediate field, with no finite-degree restriction, including $F=\overline{\mathbb Q}$.

## `legendre_gen'_isElliptic`

For every explicit point $p$ of the subtype $\{\lambda\in\overline{\mathbb Q}:\lambda\ne0\ \text{and}\ \lambda\ne1\}$, where $\overline{\mathbb Q}$ is the fixed algebraic closure of $\mathbb Q$, the Weierstrass curve over $F_\lambda$ with coefficients $(a_1,a_2,a_3,a_4,a_6)=(0,-(1+t),0,t,0)$ has invertible discriminant, where $\lambda$ is the underlying element of $p$ and $t$ is $\lambda$ regarded as an element of $F_\lambda$. Equivalently, over this field the discriminant is nonzero. Here $F_\lambda$ is the smallest subfield of $\overline{\mathbb Q}$ containing the rational numbers, $\lambda$, a chosen square root of $-1$, a chosen square root of $\lambda$, a chosen square root of $1-\lambda$, and all affine coordinates of the points killed by multiplication by $3$ or by $5$ in the group of nonsingular points of $y^2=x^3-(1+\lambda)x^2+\lambda x$ over $\overline{\mathbb Q}$. That group consists of its zero point and its nonsingular affine solutions; the zero point contributes no coordinates and $(a,b)$ contributes $\{a,b\}$. The subtype argument already contains both inequalities. No proof of finiteness of either torsion set is an argument of this theorem; the field, ring, and nonvanishing-of-$2$ instances used for the curve are inferred from $F_\lambda$.

## Original paper background

Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, Corollary 2.2, opening two complete sentences before “Let”, printed/PDF page 41:

> Suppose that $X=\mathbb P^1_{\mathbb Q}$ is the projective line over $\mathbb Q$, and that $D\subseteq X$ is the divisor consisting of the three points “$0$”, “$1$”, and “$\infty$”. We shall regard $X$ as the “$\lambda$-line” — i.e., we shall regard the standard coordinate on $X=\mathbb P^1_{\mathbb Q}$ as the “$\lambda$” in the Legendre form “$y^2=x(x-1)(x-\lambda)$” of the Weierstrass equation defining an elliptic curve — and hence as being equipped with a natural classifying morphism $U_X\to(\mathcal M_{\mathrm{ell}})_{\mathbb Q}$ [cf. the discussion preceding Proposition 1.8].

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`. Later corollary material is omitted.

Shinichi Mochizuki, *Inter-universal Teichmüller Theory I: Construction of Hodge Theaters* (May 2020), §3, Definition 3.1(a), complete item, printed/PDF page 61:

> $F$ is a number field such that $\sqrt{-1}\in F$; $\overline F$ is an algebraic closure of $F$. Write $G_F\overset{\mathrm{def}}{=}\operatorname{Gal}(\overline F/F)$.

Official original: https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf. Local original: `/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`.

These passages give the Legendre-family and chosen-algebraic-closure background. They do not state the five carrier helpers or the complete record-construction function as verbatim interfaces. The full field generated by the parameter, three selected square roots, and the 3- and 5-torsion coordinate sets is the reference project's explicit construction. The source helpers and the conditional assembly are supporting mathematical infrastructure for that construction.

## Intuitive explanation (non-rigorous)

These helpers let the same algebraic parameter be used inside its generated field. They also make the fixed algebraic closure available over any intermediate field and carry the two parameter inequalities into the Legendre ellipticity condition.

# 简体中文

## `gen'_ne_zero`

设 $\overline{\mathbb Q}$ 为固定的 $\mathbb Q$ 的代数闭包。对每个隐式量化的 $\lambda\in\overline{\mathbb Q}$ 和每个显式给出的 $\lambda\ne0$ 的证明，将 $\lambda$ 视为下述中间域 $F_\lambda$ 的元素后，它在该域中非零。这里，$F_\lambda$ 是 $\overline{\mathbb Q}$ 中包含有理数、$\lambda$、选定的 $-1$ 的平方根、选定的 $\lambda$ 的平方根、选定的 $1-\lambda$ 的平方根，以及方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 在 $\overline{\mathbb Q}$ 上的非奇异点群中所有被乘以 $3$ 或乘以 $5$ 消去的点的仿射坐标的最小子域。该点群由一个指定的零点和此方程的非奇异仿射解组成；零点不贡献坐标，仿射点 $(a,b)$ 贡献集合 $\{a,b\}$。记为 `gen'` 的元素恰好是 $\lambda$ 连同它属于 $F_\lambda$ 的证明。此参数允许等于 $1$；两个挠点集合的有限性都不是前提。

## `gen'_ne_one`

设 $\overline{\mathbb Q}$ 为固定的 $\mathbb Q$ 的代数闭包。对每个隐式量化的 $\lambda\in\overline{\mathbb Q}$ 和每个显式给出的 $\lambda\ne1$ 的证明，将 $\lambda$ 视为下述中间域 $F_\lambda$ 的元素后，它不同于该域的乘法单位元。这里，$F_\lambda$ 是 $\overline{\mathbb Q}$ 中包含有理数、$\lambda$、选定的 $-1$ 的平方根、选定的 $\lambda$ 的平方根、选定的 $1-\lambda$ 的平方根，以及方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 在 $\overline{\mathbb Q}$ 上的非奇异点群中所有被乘以 $3$ 或乘以 $5$ 消去的点的仿射坐标的最小子域。该点群由一个指定的零点和此方程的非奇异仿射解组成；零点不贡献坐标，仿射点 $(a,b)$ 贡献集合 $\{a,b\}$。记为 `gen'` 的元素恰好是 $\lambda$ 连同它属于 $F_\lambda$ 的证明。此参数允许等于 $0$；两个挠点集合的有限性都不是前提。

## 结果类型为 `Module.IsTorsionFree F Qbar` 的匿名实例

对每个显式给出的、介于 $\mathbb Q$ 与其固定代数闭包 $\overline{\mathbb Q}$ 之间的中间域 $F$，此声明提供如下断言：通过包含映射 $F\hookrightarrow\overline{\mathbb Q}$ 定义标量乘法后，$\overline{\mathbb Q}$ 是无挠 $F$-模。具体地，对每个 $a\in F$ 和 $z\in\overline{\mathbb Q}$，若 $a\ne0$ 且 $a\cdot z=0$，则 $z=0$。域结构和模结构采用中间域及代数闭包已有的结构；这些结构由系统推断，不是调用者额外提供的假设。对 $F$ 没有有限次数限制；也包含整个中间域 $F=\overline{\mathbb Q}$ 的情形。

## 结果类型为 `IsAlgClosure F Qbar` 的匿名实例

对每个显式给出的、介于 $\mathbb Q$ 与其固定代数闭包 $\overline{\mathbb Q}$ 之间的中间域 $F$，此声明为包含映射定义的扩张 $\overline{\mathbb Q}/F$ 提供代数闭包结构。因此，$\overline{\mathbb Q}$ 是代数闭域，其每个元素都在 $F$ 上代数，即满足某个系数属于 $F$ 的非零多项式。两个域结构、$\overline{\mathbb Q}$ 上的 $F$-代数结构，以及它的无挠 $F$-模结构，均由已有结构和前一个实例推断；它们不是调用者额外提供的假设。此断言适用于每个这样的中间域，没有有限次数限制，也包含 $F=\overline{\mathbb Q}$。

## `legendre_gen'_isElliptic`

对每个显式给出的子类型 $\{\lambda\in\overline{\mathbb Q}:\lambda\ne0\ \text{且}\ \lambda\ne1\}$ 的点 $p$，其中 $\overline{\mathbb Q}$ 是固定的 $\mathbb Q$ 的代数闭包，$F_\lambda$ 上系数为 $(a_1,a_2,a_3,a_4,a_6)=(0,-(1+t),0,t,0)$ 的 Weierstrass 曲线具有可逆的判别式；这里 $\lambda$ 是 $p$ 的底层元素，$t$ 是将 $\lambda$ 视为 $F_\lambda$ 的元素所得的元素。等价地，在这个域上，判别式非零。这里，$F_\lambda$ 是 $\overline{\mathbb Q}$ 中包含有理数、$\lambda$、选定的 $-1$ 的平方根、选定的 $\lambda$ 的平方根、选定的 $1-\lambda$ 的平方根，以及方程 $y^2=x^3-(1+\lambda)x^2+\lambda x$ 在 $\overline{\mathbb Q}$ 上的非奇异点群中所有被乘以 $3$ 或乘以 $5$ 消去的点的仿射坐标的最小子域。该群由零点和非奇异仿射解组成；零点不贡献坐标，$(a,b)$ 贡献 $\{a,b\}$。子类型参数已经包含两个不等式。此定理不以任一挠点集合的有限性证明为参数；曲线使用的域实例、环实例和 $2$ 非零的实例均由 $F_\lambda$ 推断。

## 论文原文背景

望月新一，*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*，2020 年 4 月版，第 2 节，推论 2.2 开头、“Let”之前的完整两句，印刷页与文件页均为第 41 页。精确英文引文见英文部分；推论后续内容未引用。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一，*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*，2020 年 5 月版，第 3 节，定义 3.1(a) 全文，印刷页与文件页均为第 61 页。精确英文引文见英文部分。官方原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。本地原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

这些段落提供 Legendre 曲线族与选定代数闭包的背景，不是五个基础辅助声明或完整记录构造函数的逐字接口。由参数、三个选定平方根及分别被 3、5 杀死的点的坐标集合生成的完整域，是参考工程的显式构造。源码辅助结论与有条件的记录组装，为该构造提供基础数学支持。

## 直观解释（非严格）

这些辅助声明让同一个代数参数可以在其生成域中使用，也使固定代数闭包可作为任意中间域的代数闭包，并将参数的两个不等式用于 Legendre 曲线的椭圆性条件。

# 日本語

## `gen'_ne_zero`

$\overline{\mathbb Q}$ を固定された $\mathbb Q$ の代数閉包とする。暗黙に量化された任意の $\lambda\in\overline{\mathbb Q}$ と、明示的に与えられる任意の $\lambda\ne0$ の証明に対し、$\lambda$ を以下の中間体 $F_\lambda$ の元とみなすと、それはこの体において零でない。ここで $F_\lambda$ は、有理数、$\lambda$、選ばれた $-1$ の平方根、選ばれた $\lambda$ の平方根、選ばれた $1-\lambda$ の平方根、および $\overline{\mathbb Q}$ 上の方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ の非特異点群において $3$ 倍または $5$ 倍すると零になる点のすべてのアフィン座標を含む、$\overline{\mathbb Q}$ の最小の部分体である。この点群は、指定された零点と、この方程式の非特異なアフィン解からなる。零点は座標を与えず、アフィン点 $(a,b)$ は集合 $\{a,b\}$ を与える。`gen'` と記される元は、まさに $\lambda$ と、その $F_\lambda$ への所属の証明を組にしたものである。このパラメータは $1$ に等しくてもよい。いずれの捩れ点集合の有限性も前提ではない。

## `gen'_ne_one`

$\overline{\mathbb Q}$ を固定された $\mathbb Q$ の代数閉包とする。暗黙に量化された任意の $\lambda\in\overline{\mathbb Q}$ と、明示的に与えられる任意の $\lambda\ne1$ の証明に対し、$\lambda$ を以下の中間体 $F_\lambda$ の元とみなすと、それはこの体の乗法単位元と異なる。ここで $F_\lambda$ は、有理数、$\lambda$、選ばれた $-1$ の平方根、選ばれた $\lambda$ の平方根、選ばれた $1-\lambda$ の平方根、および $\overline{\mathbb Q}$ 上の方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ の非特異点群において $3$ 倍または $5$ 倍すると零になる点のすべてのアフィン座標を含む、$\overline{\mathbb Q}$ の最小の部分体である。この点群は、指定された零点と、この方程式の非特異なアフィン解からなる。零点は座標を与えず、アフィン点 $(a,b)$ は集合 $\{a,b\}$ を与える。`gen'` と記される元は、まさに $\lambda$ と、その $F_\lambda$ への所属の証明を組にしたものである。このパラメータは $0$ に等しくてもよい。いずれの捩れ点集合の有限性も前提ではない。

## 結果の型が `Module.IsTorsionFree F Qbar` である無名インスタンス

$\mathbb Q$ とその固定された代数閉包 $\overline{\mathbb Q}$ の間の任意の中間体 $F$ を明示的に与えると、この宣言は、包含写像 $F\hookrightarrow\overline{\mathbb Q}$ を通じたスカラー倍に関して $\overline{\mathbb Q}$ が捩れのない $F$-加群であるという主張を与える。具体的には、任意の $a\in F$ と $z\in\overline{\mathbb Q}$ に対し、$a\ne0$ かつ $a\cdot z=0$ ならば $z=0$ である。体構造と加群構造は、中間体と代数閉包の既存の構造であり、呼出し側が追加の仮定として与えるものではなく推論される。$F$ の次数が有限であるという制限はない。中間体全体 $F=\overline{\mathbb Q}$ も含まれる。

## 結果の型が `IsAlgClosure F Qbar` である無名インスタンス

$\mathbb Q$ とその固定された代数閉包 $\overline{\mathbb Q}$ の間の任意の中間体 $F$ を明示的に与えると、この宣言は、包含写像で定まる拡大 $\overline{\mathbb Q}/F$ に代数閉包の構造を与える。したがって、$\overline{\mathbb Q}$ は代数閉体であり、その各元は $F$ 上代数的である。すなわち、$F$ に係数を持つある零でない多項式を満たす。体構造、$\overline{\mathbb Q}$ 上の $F$-代数構造、および捩れのない $F$-加群の構造は、既存の構造と直前のインスタンスから推論され、呼出し側が追加で与える仮定ではない。この主張は、有限次数の制限なしに、このようなすべての中間体に適用され、$F=\overline{\mathbb Q}$ も含まれる。

## `legendre_gen'_isElliptic`

$\overline{\mathbb Q}$ を固定された $\mathbb Q$ の代数閉包とする。部分型 $\{\lambda\in\overline{\mathbb Q}:\lambda\ne0\ \text{かつ}\ \lambda\ne1\}$ の点 $p$ を明示的に任意に与えると、$F_\lambda$ 上で係数が $(a_1,a_2,a_3,a_4,a_6)=(0,-(1+t),0,t,0)$ である Weierstrass 曲線の判別式は可逆である。ここで $\lambda$ は $p$ の基になる元であり、$t$ は $\lambda$ を $F_\lambda$ の元とみなしたものである。この体において判別式が零でないというのも同値な表現である。ここで $F_\lambda$ は、有理数、$\lambda$、選ばれた $-1$ の平方根、選ばれた $\lambda$ の平方根、選ばれた $1-\lambda$ の平方根、および $\overline{\mathbb Q}$ 上の方程式 $y^2=x^3-(1+\lambda)x^2+\lambda x$ の非特異点群において $3$ 倍または $5$ 倍すると零になる点のすべてのアフィン座標を含む、$\overline{\mathbb Q}$ の最小の部分体である。この群は零点と非特異なアフィン解からなる。零点は座標を与えず、$(a,b)$ は $\{a,b\}$ を与える。部分型の引数は既に二つの不等式を含む。この定理の引数には、いずれの捩れ点集合についても有限性の証明は含まれない。曲線に用いる体、環、および $2$ の非零性のインスタンスは $F_\lambda$ から推論される。

## 論文原文の背景

望月新一、*Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations*、2020 年 4 月版、第 2 節、系 2.2 の冒頭から「Let」の前までの完全な二文、印刷・PDF ファイルページ 41。正確な英文は英語部分に示す。系の後続部分は引用しない。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf`。

望月新一、*Inter-universal Teichmüller Theory I: Construction of Hodge Theaters*、2020 年 5 月版、第 3 節、定義 3.1(a) 全文、印刷・PDF ファイルページ 61。正確な英文は英語部分に示す。公式原文：https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20I.pdf。ローカル原文：`/home/admin-wsl/Coq/abc/refer/Mochizuki/Inter-universal Teichmuller Theory I.pdf`。

これらの段落は、ルジャンドル曲線族と選ばれた代数閉包の背景を与える。五つの基礎的な補助宣言や完全なレコード構成関数を、逐語的なインターフェースとして述べるものではない。パラメータ、三つの選ばれた平方根、3 等分点と 5 等分点の座標集合から生成される完全な体は、参照プロジェクトの明示的な構成である。ソースの補助的帰結と条件付きのレコード構成は、その構成の基礎的な数学を与える。

## 直観的説明（非厳密）

これらの補助宣言により、同じ代数的パラメータをその生成体の中で扱える。また、固定した代数閉包を任意の中間体上の代数閉包として用い、パラメータの二つの不等式からルジャンドル曲線の楕円性を得る。
