from pathlib import Path
import json,hashlib
D=Path('/tmp/p2m-b1-curveof-assembly-v166-20261117')
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
P=W/'.local/adaptation/b1-source-parser-v93-20261117/parser-output/Iut-Tripod-CurveOf.jsonl'
B=P.with_suffix('.normalized.lean').read_bytes()
rows={r['commandIndex']:r for r in map(json.loads,P.read_text().splitlines()) if r.get('commandSyntax')}
def nodes(x):
 yield x
 for c in x.get('children',[]):yield from nodes(c)
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
c=rows[45];a,z=c['range']['start']['offset'],c['range']['end']['offset'];raw=B[a:z]
decl=next(n for n in nodes(c['commandSyntax']) if n['syntaxKind']=='Lean.Parser.Command.declId')
dr=decl['range'];i,j=dr['start']['offset']-a,dr['end']['offset']-a
assert raw[i:j]==b'curveOf'
new=b'curveOf_refSpanProbeV166';probe=raw[:i]+new+raw[j:]
ident=next(n for n in nodes(c['commandSyntax']) if n.get('identifier')=="finiteDimensional_fieldOf'")
rr=ident['range'];u,v=rr['start']['offset']-a,rr['end']['offset']-a
assert i<j<u<v
delta=len(new)-(j-i)
prefix=r'''import Lean
import B1SourceReplay

namespace CurveOfRefSpanProbeV166
open Lean Elab Command

partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

def checked {α : Type} (x : Except String α) : CommandElabM α :=
  match x with
  | .ok x => pure x
  | .error e => throwError "{e}"

partial def collect (t : InfoTree) (lo hi : Nat) (parent : Name := .anonymous) : Array Json :=
  match t with
  | .context (.parentDeclCtx n) child => collect child lo hi n
  | .context _ child => collect child lo hi parent
  | .hole _ => #[]
  | .node info children => Id.run do
    let mut out := #[]
    if let .ofTermInfo ti := info then
      if ti.stx.isIdent then
        if let some start := ti.stx.getPos? then
          if let some stop := ti.stx.getTailPos? then
            if start.byteIdx == lo && stop.byteIdx == hi then
              if let .const n us := ti.expr.getAppFn then
                out := out.push <| Json.mkObj [
                  ("referenceNameExpr",encodeName n),
                  ("referenceDisplay",toJson n.toString),
                  ("parentDeclNameExpr",encodeName parent),
                  ("parentDeclDisplay",toJson parent.toString),
                  ("probeByteStart",toJson start.byteIdx),
                  ("probeByteEnd",toJson stop.byteIdx),
                  ("universeArgumentCount",toJson us.length),
                  ("syntaxIdentifier",toJson ti.stx.getId.toString),
                  ("isBinder",toJson ti.isBinder)]
    for child in children do out := out ++ collect child lo hi parent
    return out

elab "captureCurveOfRefV166" c:command : command => do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected source4.35.0-rc3"
  let some cfgPath ← IO.getEnv "B1_CURVEOF_REFSPAN_V166_CONFIG"
    | throwError "Missing B1_CURVEOF_REFSPAN_V166_CONFIG"
  let cfg ← checked <| Json.parse (← IO.FS.readFile cfgPath)
  let lo ← checked <| cfg.getObjValAs? Nat "probeReferenceByteStart"
  let hi ← checked <| cfg.getObjValAs? Nat "probeReferenceByteEnd"
  let output ← checked <| cfg.getObjValAs? String "outputFile"
  let sourceFile ← checked <| cfg.getObjValAs? String "originalNormalizedSource"
  let sourceStart ← checked <| cfg.getObjValAs? Nat "originalCommandStart"
  let sourceEnd ← checked <| cfg.getObjValAs? Nat "originalCommandEnd"
  let expectedBytes ← checked <| cfg.getObjValAs? String "expectedOriginalCommand"
  let source ← IO.FS.readBinFile sourceFile
  unless source.extract sourceStart sourceEnd == expectedBytes.toUTF8 do
    throwError "Original source command differs from pinned exact bytes"
  modify fun s => {s with infoState := {s.infoState with enabled := true}}
  elabCommand c
  unless !(← get).messages.hasErrors do throwError "Probe command elaboration failed"
  let state := ((← get).infoState.substituteLazy).get
  let mut refs := #[]
  for tree in state.trees do
    refs := refs ++ collect (tree.substitute state.assignment) lo hi
  unless !refs.isEmpty do throwError "No actual term reference at the requested identifier span"
  for ref in refs do
    unless (← checked <| ref.getObjValAs? String "referenceDisplay") ==
        "Iut.Tripod.finiteDimensional_fieldOf'" do
      throwError "Resolved a different source declaration"
    unless (← checked <| ref.getObjValAs? String "parentDeclDisplay") ==
        "Iut.Tripod.curveOf_refSpanProbeV166" do
      throwError "Wrong actual containing probe declaration"
    unless !(← checked <| ref.getObjValAs? Bool "isBinder") do
      throwError "Expected a source use-site rather than a binder"
  let result := Json.mkObj [
    ("schema",toJson "B1-curveOf-source-resolved-reference-probe/v166"),
    ("actualResolvedReferences",Json.arr refs),
    ("sourceCommandBytesMatched",toJson true),
    ("referenceExtractedFromActualTermInfo",toJson true),
    ("originalUseSiteRewritten",toJson false),
    ("probeOnlyDeclIdRewrite",toJson true),
    ("configuration",cfg)]
  if let some parent := (System.FilePath.mk output).parent then IO.FS.createDirAll parent
  IO.FS.writeFile output (result.pretty ++ "\n")
  logInfo "Original curveOf finiteDimensional reference resolved from exact command probe"

end CurveOfRefSpanProbeV166

namespace Iut.Tripod
open WeierstrassCurve NumberField
open scoped IntermediateField

captureCurveOfRefV166
'''
q=D/'pending-ref/QueryCurveOfResolvedReferenceV166.lean';q.write_bytes(prefix.encode()+probe+b'\n\nend Iut.Tripod\n')
start=len(prefix.encode())+u+delta;end=len(prefix.encode())+v+delta
assert q.read_bytes()[start:end]==b"finiteDimensional_fieldOf'"
cfg={'schema':'B1-curveOf-source-reference-probe-config/v166','originalNormalizedSource':str(P.with_suffix('.normalized.lean')),
 'originalCommandStart':a,'originalCommandEnd':z,'expectedOriginalCommand':raw.decode(),
 'originalUseSiteRange':rr,'sourceCommandIndex':45,'probeDeclIdRewrite':{'original':decl,'replacement':new.decode()},
 'probeReferenceByteStart':start,'probeReferenceByteEnd':end,'probeCommandStart':len(prefix.encode()),
 'probeCommandEnd':len(prefix.encode())+len(probe),'sourceCommandRelativeReferenceRange':[u,v],
 'expectedResolvedSourceNameExpr':[[[[],'str','Iut'],'str','Tripod'],'str',"finiteDimensional_fieldOf'"],
 'outputFile':str(D/'pending-ref/actual-resolved-ref.json'),
 'probePolicy':'Import accepted B1SourceReplay; replay only original AST command45 under the original namespace/open context, with exactly one AST declId rename to avoid redeclaration. Preserve every body and binder byte. Map actual TermInfo reference range back through the recorded declId-length delta.',
 'queryBinding':pin(q),'sourceBindings':[pin(P),pin(P.with_suffix('.normalized.lean')),
 pin(W/'.local/adaptation/b1-source-replay-v104-20261117/source-project/B1SourceReplay.lean')],
 'acceptedSourceArtifactJob':'ci-018538-2c5490b3','originalSourceOwner':'B1SourceReplay'}
cp=D/'pending-ref/ref-probe.config.json';dump(cp,cfg)
dump(D/'pending-ref/recommended-mcp-request.template.json',{
 'language':'lean','task_type':'leaf','project_id':'source4.35.0-rc3','workspace':'/home/admin-wsl/Coq/abc',
 'target':'file','parameters':{'source':str(q),'environment':{'B1_CURVEOF_REFSPAN_V166_CONFIG':str(cp),
 'LEAN_PATH':'<reuse exact source4.35.0-rc3 search path from successful B1SourceReplay query jobs; include accepted source-project B1SourceReplay.olean>'}},
 'expected_duration':'60s','expected_memory':'16GiB','exclusive':True,
 'session_id':'<root current session>','agent_id':'<root>','idempotency_key':'b1-curveof-refspan-v166-attempt1-<query/config-sha>',
 'worktree_manifest':{'worktree_id':'<actual root worktree ID>','head':'68f2b2be','dirty_files':'<read actual current Git status>',
 'untracked_files':'<include installed query/config and other actual untracked inputs>',
 'external_inputs':[pin(q),pin(cp)],'prebuilt_artifacts':'<pin existing source4.35.0-rc3 B1SourceReplay.olean and exact cached dependencies; do not rebuild>'},
 'notes':['Template: use actual registered scheduler project ID for source4.35.0-rc3 if named differently.',
 'Root may copy query/config into main workspace; update query source/config paths and manifest pins accordingly.',
 'Do not import or rebuild all fourteen replay modules; this query imports the existing accepted B1SourceReplay.olean and elaborates one definition.']})
print(q);print(cp);print('reference probe bytes',start,end,'original bytes',rr['start']['offset'],rr['end']['offset'])
