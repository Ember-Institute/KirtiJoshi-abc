from pathlib import Path
import json,hashlib

D=Path('/tmp/p2m-b1-curveof-assembly-v166-20261117')
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
C=W/'.local/adaptation/b1-source-replay-v104-20261117'
P=W/'.local/adaptation/b1-source-parser-v93-20261117/parser-output/Iut-Tripod-CurveOf.jsonl'
B=P.with_suffix('.normalized.lean').read_bytes()
AST={r['commandIndex']:r for r in map(json.loads,P.read_text().splitlines()) if r.get('commandSyntax')}
M=C/'compat-v105/source-replay-spans-map.json';SP=C/'source-project/B1SourceReplay.lean'
maps={r['originalCommandIndex']:r for r in json.loads(M.read_text())['commands'] if r['sourceModule']=='Iut.Tripod.CurveOf'}
FP=C/'actual/closure-v111/actual-facts.jsonl';EP=C/'actual/closure-v111/actual-edges.jsonl'
def nm(n):return '' if not n else '.'.join(filter(None,[nm(n[0]),str(n[2])]))
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def nodes(x):
 yield x
 for c in x.get('children',[]):yield from nodes(c)
def enodes(x):
 if isinstance(x,dict):
  yield x
  for v in x.values():yield from enodes(v)
 elif isinstance(x,list):
  for v in x:yield from enodes(v)
def consts(x):return sorted(set(nm(n['name']) for n in enodes(x) if n.get('kind')=='const'))
def raw(i):r=AST[i]['range'];return B[r['start']['offset']:r['end']['offset']]
for s in ['definitions','source','audit','pending-ref']:(D/s).mkdir(exist_ok=True)
notice='''/-
Adaptation provenance: exact accepted Iut AST command spans.
Original repository: https://github.com/lana-agents/iut
Original commit: 07cb1da58f6d428a670dbb5dd6093d428bcbcdd8
Original source: Iut/Tripod/CurveOf.lean
-/
/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
'''
ctx='\nnamespace AbcAdaptation.Tripod\nopen WeierstrassCurve NumberField\nopen scoped IntermediateField\n\n'
carrier=D/'definitions/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfCarrier.lean'
carrier.write_text(notice+'import Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfGenerator\nimport Theorems.Thm_AbcAdaptation_Tripod_legendre_isElliptic\nimport Mathlib.FieldTheory.IsAlgClosed.AlgebraicClosure\n'+ctx+'\n\n'.join(raw(i).decode() for i in [39,40,41,42,43])+'\n\nend AbcAdaptation.Tripod\n')
assembly=D/'pending-ref/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOf.lean'
assembly.write_text(notice+'/- DRAFT: the body retains the original finiteDimensional_fieldOf\' use-site.\nA resolved source reference span is required before its public-name rewrite. -/\nimport Definitions.Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfCarrier\nimport Definitions.Def_AbcAdaptation_Reference_Iut_Concrete_EllipticCurveData\nimport Theorems.Thm_AbcAdaptation_Tripod_finiteDimensional_fieldOfExtended\n'+ctx+'open AbcAdaptation.Reference.Iut\n\n'+raw(45).decode()+'\n\nend AbcAdaptation.Tripod\n')
records=[];rb=SP.read_bytes()
for i in [39,40,41,42,43,45]:
 b=raw(i);s=maps[i];er=s['effectiveReplayRange'];assert rb[er['start']['offset']:er['end']['offset']]==b
 assert hashlib.sha256(b).hexdigest()==s['originalSHA256']
 p=D/'source'/f'command-{i}.lean.txt';p.write_bytes(b)
 records.append({'commandIndex':i,'originalRange':AST[i]['range'],'sourceBytes':pin(p),'replayRange':er,'byteIdenticalToAcceptedReplay':True})

# One explicit public-name use-site remains unmodified. Lexical AST evidence is not a resolved refSpan.
refs=[x for x in nodes(AST[45]['commandSyntax']) if x.get('identifier')=="finiteDimensional_fieldOf'"]
assert len(refs)==1
ref=refs[0];r=ref['range'];a,z=r['start']['offset'],r['end']['offset'];cr=AST[45]['range'];er=maps[45]['effectiveReplayRange']
ar=er['start']['offset']+a-cr['start']['offset'];zr=er['start']['offset']+z-cr['start']['offset']
assert B[a:z]==rb[ar:zr]==b"finiteDimensional_fieldOf'"
request={'schema':'B1-assembly-required-resolved-reference/v166','status':'root-CI extraction required; no replacement applied',
 'sourceModule':'Iut.Tripod.CurveOf','commandIndex':45,'sourceContext':'curveOf letI body',
 'lexicalASTIdentifier':ref,'sourceCommandRelativeByteRange':[a-cr['start']['offset'],z-cr['start']['offset']],
 'acceptedReplayByteRange':[ar,zr],'acceptedReplayLine':1133,'acceptedReplayUTF8ColumnRange':[10,36],
 'expectedResolvedSourceNameExpr':[[[[],'str','Iut'],'str','Tripod'],'str',"finiteDimensional_fieldOf'"],
 'requestedTargetPublicName':'finiteDimensional_fieldOfExtended',
 'requiredReceipt':['MCP-CI source elaboration job ID','source replay file and immutable effective input SHA256',
  'exact resolved use-site reference NameExpr and UTF-8 span','containing declaration source NameExpr',
  'reference record binding/hash; distinguish from lexical syntax identifier'],
 'allowedRewriteAfterReceipt':'replace only the verified identifier UTF-8 span; preserve all remaining command bytes',
 'noAliasOrNewHypothesisFallback':True,'sourceInputs':[pin(P),pin(P.with_suffix('.normalized.lean')),pin(SP),pin(M)]}
dump(D/'pending-ref/root-ci-reference-extraction-request.json',request)

rootnames=["Iut.Tripod.gen'_ne_zero","Iut.Tripod.gen'_ne_one",
 'Iut.Tripod.instIsTorsionFreeSubtypeQbarMemIntermediateFieldRat_b1SourceReplay',
 'Iut.Tripod.instIsAlgClosureSubtypeQbarMemIntermediateFieldRat_b1SourceReplay',
 "Iut.Tripod.legendre_gen'_isElliptic",'Iut.Tripod.curveOf']
supportnames=['Iut.Tripod.curveOf._proof_'+str(i) for i in range(1,5)]+[
 'Iut.Tripod.instNumberFieldSubtypeQbarMemIntermediateFieldRatOfFiniteDimensional',
 'Iut.EllipticCurveData','Iut.EllipticCurveData.mk']
supportnames += ['Iut.EllipticCurveData.'+s for s in ['F','fieldF','numberFieldF','Fbar','fieldFbar','algebraFbar','isAlgClosure','E','isElliptic','rec']]
boundarynames=['Iut.Tripod.Qbar','Iut.Tripod.Pt','Iut.Tripod.TorsionFinite',"Iut.Tripod.fieldOf'",
 "Iut.Tripod.gen'",'Iut.Tripod.legendre',"Iut.Tripod.finiteDimensional_fieldOf'",'Iut.Tripod.legendre_isElliptic']
facts={}
for line in FP.open():
 f=json.loads(line)
 if f.get('name') in rootnames+supportnames+boundarynames:facts[f['name']]=f
assert set(rootnames+supportnames+boundarynames)==set(facts)
for name in rootnames+supportnames:
 f=facts[name];p=D/'source'/('fact-'+name.replace('.','_').replace("'",'Prime')+'.json');dump(p,f)
 if f['kind'] not in ['constructor','inductive','recursor']:
  assert f['valueRead'] and f['kernelValueTypeMatchesActualTYPE'] and not f['hasSorryAx']
dump(D/'source/boundary-full-facts.json',[facts[n] for n in boundarynames])
edges=[json.loads(l) for l in EP.open()]
selected=set(rootnames+supportnames)
selectededges=[e for e in edges if nm(e['from']) in selected]
dump(D/'source/assembly-complete-actual-edges.json',selectededges)
dump(D/'source/actual-consumer-edges.json',[e for e in edges if nm(e['to']) in selected])
generated=[]
for n in supportnames[:4]:
 f=facts[n];generated.append({'sourceNameExpr':f['nameExpr'],'sourceName':n,'levelParams':f['levelParams'],
 'telescope':f['telescope'],'directTypeConstants':f['directTypeConstants'],'directValueConstants':f['directValueConstants'],
 'isInstance':f['isInstance'],'metadata':f['metadata'],'valueAxioms':f['valueAxioms'],
 'fullTypeAndValuePreservedInSourceFact':True})
dump(D/'audit/generated-proof-parameter-closure.json',generated)

# Flatten the maximal actual source mk application; retain each full actual argument Expr.
def peel(e):
 args=[]
 while e.get('kind')=='app':args.append(e['arg']);e=e['fn']
 return e,list(reversed(args))
applications=[]
for e in enodes(facts['Iut.Tripod.curveOf']['actualValueExpr']):
 h,args=peel(e)
 if h.get('kind')=='const' and nm(h['name'])=='Iut.EllipticCurveData.mk':applications.append((h,args))
h,args=max(applications,key=lambda x:len(x[1]));assert len(args)==9
labels=['F','fieldF','numberFieldF','Fbar','fieldFbar','algebraFbar','isAlgClosure','E','isElliptic']
dump(D/'audit/curveOf-nine-constructor-consumers.json',{'sourceDefinition':facts['Iut.Tripod.curveOf']['nameExpr'],
 'actualConstructor':h,'constructorMetadata':facts['Iut.EllipticCurveData.mk']['metadata'],
 'constructorTelescope':facts['Iut.EllipticCurveData.mk']['telescope'],
 'arguments':[{'index':i,'field':label,'actualArgumentExpr':arg,'directConstants':consts(arg)} for i,(label,arg) in enumerate(zip(labels,args))],
 'outerTelescope':facts['Iut.Tripod.curveOf']['telescope'],'allNineSourceArgumentsPresent':True})

# Stop only at declared existing project boundaries; keep every newly introduced helper and generated proof in the closure.
known=set(rootnames+supportnames+boundarynames)
projectrefs={nm(e['to']) for e in selectededges if nm(e['to']).startswith(('Iut.','Genl.','_private.'))}
missing=sorted(projectrefs-known)
assert not missing,missing
dump(D/'audit/source-project-closure-plan.json',{'schema':'B1-assembly-source-project-closure/v166',
 'newSourceRoots':rootnames,'generatedAndExistingSupport':supportnames,'existingSourceBoundaryNames':boundarynames,
 'projectConstantReferencesOutsideRecordedClosure':missing,'completeUnderDeclaredExistingBoundaries':True,
 'externalMathlibLeanBoundaryPolicy':'Actual direct names retained; their proof bodies are not recursively exported.',
 'sourceFullClosureJob':'ci-018560-1db29f6e','targetAcceptedByThisDraft':False,
 'targetAnonymousAndGeneratedNames':'Unknown until native inventory. Do not assume source _b1SourceReplay suffix or _proof_N numbering.',
 'newMathematicalAssumptions':False,'CurveArithmeticSupplied':False,'unconditionalCurveOfExistenceClaimed':False})
dump(D/'audit/native-review-required.json',{'schema':'B1-assembly-native-review-required/v166',
 'firstBundleSourceCommands':[39,40,41,42,43],'secondBundleSourceCommands':[45],
 'firstLeafEstimate':{'expected_duration':'60s','expected_memory':'16GiB'},
 'requiredNativeChecks':['inventory all new actual constants under their real owner','resolve both anonymous instance Names; preserve isInstance',
 'map all source generated curveOf._proof_N to uniquely matched native actual TYPE/value support',
 'compare complete TYPE and proof/data values by kernel equality after complete NameExpr relocation',
 'preserve strict TYPE BinderInfo, universe parameter arity, kind, metadata, and Prop/data',
 'validate the nine constructor arguments against source actual Expr and same EllipticCurveData.mk',
 'check x/h3/h5 remain explicit in curveOf and in NumberField auxiliary proof; inspect all generated proof parameter telescopes',
 'check only permitted standard axioms and no sorryAx','do not infer CurveArithmetic from EllipticCurveData construction'],
 'alreadyExistingNativePrerequisitesNeedActualMap':['Qbar','Pt','TorsionFinite',"fieldOf'","gen'",'legendre',
 'finiteDimensional_fieldOfExtended','legendre_isElliptic','EllipticCurveData/mk and all required projections',
 'Def_AbcTripod intermediate-field NumberField instance'],
 'pendingSourceResolvedRef':str(D/'pending-ref/root-ci-reference-extraction-request.json')})
dump(D/'source-provenance.json',{'schema':'B1-assembly-source-provenance/v166','sourceRecords':records,
 'inputPins':[pin(p) for p in [P,P.with_suffix('.normalized.lean'),M,SP,FP,EP]],
 'bundlePins':[pin(carrier),pin(assembly)],'allSourceDeclarationBytesUnchanged':True,'publicNameRewritesApplied':[],
 'pendingResolvedRefCount':1,'compiled':False,'mainWorkspaceWritten':False,'apiCalled':False,'gitWritten':False})
print('Prepared exact-source two-bundle draft; one resolved public-name reference remains pending.')
