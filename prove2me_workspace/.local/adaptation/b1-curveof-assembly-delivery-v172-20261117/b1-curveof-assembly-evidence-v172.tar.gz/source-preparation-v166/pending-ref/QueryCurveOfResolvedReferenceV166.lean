import Lean
import B1SourceReplay

namespace CurveOfRefSpanProbeV166
open Lean Elab Command

partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

def checked {α : Type} (x : Except String α) : CommandElabM α :=
  match x with
  | .ok x => pure x
  | .error e => throwError "{e}"

partial def collect (t : InfoTree) (lo hi : Nat) (parent : Name := .anonymous) : Array Json :=
  match t with
  | .context (.parentDeclCtx n) child => collect child lo hi n
  | .context _ child => collect child lo hi parent
  | .hole _ => #[]
  | .node info children => Id.run do
    let mut out := #[]
    if let .ofTermInfo ti := info then
      if ti.stx.isIdent then
        if let some start := ti.stx.getPos? then
          if let some stop := ti.stx.getTailPos? then
            if start.byteIdx == lo && stop.byteIdx == hi then
              if let .const n us := ti.expr.getAppFn then
                out := out.push <| Json.mkObj [
                  ("referenceNameExpr",encodeName n),
                  ("referenceDisplay",toJson n.toString),
                  ("parentDeclNameExpr",encodeName parent),
                  ("parentDeclDisplay",toJson parent.toString),
                  ("probeByteStart",toJson start.byteIdx),
                  ("probeByteEnd",toJson stop.byteIdx),
                  ("universeArgumentCount",toJson us.length),
                  ("syntaxIdentifier",toJson ti.stx.getId.toString),
                  ("isBinder",toJson ti.isBinder)]
    for child in children do out := out ++ collect child lo hi parent
    return out

elab "captureCurveOfRefV166" c:command : command => do
  unless Lean.versionString == "4.35.0-rc3" do throwError "Expected source4.35.0-rc3"
  let some cfgPath ← IO.getEnv "B1_CURVEOF_REFSPAN_V166_CONFIG"
    | throwError "Missing B1_CURVEOF_REFSPAN_V166_CONFIG"
  let cfg ← checked <| Json.parse (← IO.FS.readFile cfgPath)
  let lo ← checked <| cfg.getObjValAs? Nat "probeReferenceByteStart"
  let hi ← checked <| cfg.getObjValAs? Nat "probeReferenceByteEnd"
  let output ← checked <| cfg.getObjValAs? String "outputFile"
  let sourceFile ← checked <| cfg.getObjValAs? String "originalNormalizedSource"
  let sourceStart ← checked <| cfg.getObjValAs? Nat "originalCommandStart"
  let sourceEnd ← checked <| cfg.getObjValAs? Nat "originalCommandEnd"
  let expectedBytes ← checked <| cfg.getObjValAs? String "expectedOriginalCommand"
  let source ← IO.FS.readBinFile sourceFile
  unless source.extract sourceStart sourceEnd == expectedBytes.toUTF8 do
    throwError "Original source command differs from pinned exact bytes"
  modify fun s => {s with infoState := {s.infoState with enabled := true}}
  elabCommand c
  unless !(← get).messages.hasErrors do throwError "Probe command elaboration failed"
  let state := ((← get).infoState.substituteLazy).get
  let mut refs := #[]
  for tree in state.trees do
    refs := refs ++ collect (tree.substitute state.assignment) lo hi
  unless !refs.isEmpty do throwError "No actual term reference at the requested identifier span"
  for ref in refs do
    unless (← checked <| ref.getObjValAs? String "referenceDisplay") ==
        "Iut.Tripod.finiteDimensional_fieldOf'" do
      throwError "Resolved a different source declaration"
    unless (← checked <| ref.getObjValAs? String "parentDeclDisplay") ==
        "Iut.Tripod.curveOf_refSpanProbeV166" do
      throwError "Wrong actual containing probe declaration"
    unless !(← checked <| ref.getObjValAs? Bool "isBinder") do
      throwError "Expected a source use-site rather than a binder"
  let result := Json.mkObj [
    ("schema",toJson "B1-curveOf-source-resolved-reference-probe/v166"),
    ("actualResolvedReferences",Json.arr refs),
    ("sourceCommandBytesMatched",toJson true),
    ("referenceExtractedFromActualTermInfo",toJson true),
    ("originalUseSiteRewritten",toJson false),
    ("probeOnlyDeclIdRewrite",toJson true),
    ("configuration",cfg)]
  if let some parent := (System.FilePath.mk output).parent then IO.FS.createDirAll parent
  IO.FS.writeFile output (result.pretty ++ "\n")
  logInfo "Original curveOf finiteDimensional reference resolved from exact command probe"

end CurveOfRefSpanProbeV166

namespace Iut.Tripod
open WeierstrassCurve NumberField
open scoped IntermediateField

captureCurveOfRefV166
/-- **The elliptic curve of a point `λ` of the tripod**: the Legendre curve `E_λ` over its
field of definition `F_λ = ℚ(λ, √−1, √λ, √(1 − λ), E_λ[3], E_λ[5])`, with the algebraic
closure `ℚ̄`. -/
noncomputable def curveOf_refSpanProbeV166 (x : Pt) (h3 : TorsionFinite x.1 3) (h5 : TorsionFinite x.1 5) :
    EllipticCurveData :=
  letI := finiteDimensional_fieldOf' h3 h5
  { F := fieldOf' x.1
    Fbar := Qbar
    E := legendre (gen' x.1)
    isElliptic := legendre_gen'_isElliptic x }

end Iut.Tripod
