# CurveOf complete carrier assembly draft v166

本轮交付使用两个顺序导入 bundle，不把小 helpers 扩成单独平台节点。尚未编译、未调用平台 API、未写 Git 或主工作区。

1. `definitions/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOfCarrier.lean`：内嵌原 AST commands 39–43，依次为 `gen'_ne_zero`、`gen'_ne_one`、两个匿名 carrier 标准实例、`legendre_gen'_isElliptic`。全部原声明字节不变，包括原 prime helper 名与证明体。它直接导入已验收的 Generator 和 `legendre_isElliptic`。
2. `pending-ref/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOf.lean`：原 AST command45 的完整纯构造，导入第一 bundle、已验收的完整 EllipticCurveData 和有限维定理。通过 `open AbcAdaptation.Reference.Iut` 解析原短名 `EllipticCurveData`；源构造命令逐字保留。

第二文件目前保留尚未公开重命名的 `finiteDimensional_fieldOf'` use-site，因此暂不可作为可编译上传文件。唯一待处理的位置是 command45 line220 col10–36、原 normalized UTF-8 `[10014,10040)`；本稿没有添加 alias，也没有用 regex 猜测改名。

## 先提取唯一 resolved ref

`pending-ref/QueryCurveOfResolvedReferenceV166.lean` 和 `ref-probe.config.json` 可供 root 独占 MCP-CI 提交，推荐结构化请求在 `recommended-mcp-request.template.json`。使用 source4.35.0-rc3 的现有搜索路径，首次新叶估计 `60s` / `16GiB`；环境变量为 `B1_CURVEOF_REFSPAN_V166_CONFIG`。

该 query 只导入 `Lean` 与已缓存验收的 `B1SourceReplay`，不重建十四模块。它把完整原 command45 放回 `Iut.Tripod` 及原 open 上下文；仅依已提取 AST declId range 把声明名 `curveOf` 改成 `curveOf_refSpanProbeV166`，避免与被导入的来源声明冲突。所有 binder 和 body 字节不变。自定义 command elaborator 捕获实际 InfoTree，在 probe 的唯一目标 ident 范围 `[4824,4850)` 读取 TermInfo 的常量 NameExpr，同时检查实际 parent probe 名和非 binder 属性；config 保存从 probe 回原源 `[10014,10040)` 的精确映射。

它是“原命令在已验收来源环境中的轻量 reference probe”，不是原始源文件整体 elaboration 的 InfoTree，也不声称原源码 proof bytes 与 native 内核值逐字相同。query 会在运行时核对原源 command bytes，实际结果再由 root 与成功 CI 回执共同验收。Query/config 已优先交 root 使用，本代理不再修改它们。

`apply_verified_ref.py` 已准备但未执行。只有 root 验收 resolved reference 之后，才以结果 JSON 和接受的 job ID 调用。脚本检查实际 NameExpr、parent、probe byte range、原命令字节和原映射，只在已验证原 ident span 把 `finiteDimensional_fieldOf'` 换成 `finiteDimensional_fieldOfExtended`，输出最终 `definitions/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOf.lean`。它保留 pending 原文件和独立 rewrite 记录。后续仍需 native CI/平台验收。

## 完整源闭包和九字段真实构造

`source/` 保留 23 个逐项完整 source facts，另有八项 existing-boundary facts：原 TYPE、完整 value/proof、BinderInfo、universes、metadata、instance/Prop 属性和公理均保留。constructor/inductive/recursor 没有 ordinary value 是其常量种类本身的事实，不是遗漏。源事实复用既有 `ci-018560-1db29f6e` 闭包，原文件与 actual edges 的哈希固定于 `source-provenance.json`。

`audit/source-project-closure-plan.json` 逐项列出新 roots、生成支持与已有边界。对选定 root/support 的所有 actual TYPE/value/metadata 边做闭包检查，没有未列出的 Iut/Genl/private 项目常量。Mathlib/Lean 是明确外部边界，没有宣称递归导出了其全部证明体。

`audit/curveOf-nine-constructor-consumers.json` 保存 `curveOf` 实际完整 `EllipticCurveData.mk` 应用的九个原 argument Expr，及其直接常量：

| 槽位 | 实际来源 |
| --- | --- |
| `F` | `fieldOf' x.1` 的 subtype carrier |
| `fieldF` | 中间域 field 实例 |
| `numberFieldF` | `curveOf._proof_1` |
| `Fbar` | `Qbar` |
| `fieldFbar` | AlgebraicClosure 的 field 实例 |
| `algebraFbar` | 中间域 inclusion 的 Algebra 实例 |
| `isAlgClosure` | `curveOf._proof_4` |
| `E` | `legendre (gen' x.1)` |
| `isElliptic` | `legendre_gen'_isElliptic x` |

这些是源内核 Expr 中的原构造器参数，不是根据 record surface syntax 猜出的缺省字段。

`audit/generated-proof-parameter-closure.json` 保留所有四个生成辅助证明的完整参数闭包：

| 源生成声明 | 参数 | 结果与消费 |
| --- | --- | --- |
| `curveOf._proof_1` | 显式 `x`, `h3`, `h5` | `NumberField (fieldOf' x.1)`；消费 conditional finite-dimensional theorem 和 Basic 的通用数域实例 |
| `curveOf._proof_2` | 无 | source `SubsemiringClass` 支持，被 `_proof_3` 的 TYPE 消费 |
| `curveOf._proof_3` | 显式 `x` | torsion-free；消费 source carrier instance，被 `_proof_4` 的 TYPE 消费 |
| `curveOf._proof_4` | 显式 `x` | algebraic closure；消费 source closure instance，被 `curveOf` 的第七构造槽消费 |

最终源 `curveOf` 仍是三个显式参数 `(x : Pt) (h3 : TorsionFinite x.1 3) (h5 : TorsionFinite x.1 5)`。body 仍以 `letI` 从 h3/h5 得有限维实例；已有 `Def_AbcTripod` 中的通用中间域 NumberField 实例据此提供数域性。完整数域实例 source fact 也已保存，需要在 native 审查中记录其真实 target NameExpr 对应，不能仅因目标源码存在就跳过 kernel 检查。

## 名称冲突与可移植范围

按当前主区静态文件检查，只有 FieldsData 和 Generator 两项 CurveOf 模块已存在；第一 bundle 的原 `gen'_ne_zero`、`gen'_ne_one`、`legendre_gen'_isElliptic` 不与当前公开 ASCII 节点冲突。两个匿名实例虽与源 replay 作用相同，但目标位于 `AbcAdaptation.Tripod`，源位于 `Iut.Tripod`。轻量 probe 位于来源 namespace，因此只改 probe 的 declId 以避开已导入的原 `curveOf`。

不得同时导入历史 v160 的 `CurveOfCarrierInstances` 模块和本轮第一 bundle；它们会重复登记同一目标 namespace 下的匿名实例。若历史包将来整合，须选择一个 owner，而不是同时装入两个重复包。

目标匿名实例和 `curveOf._proof_N` 的真实 Name、编号与捕获参数仍须 native 编译库存确定。本稿没有把来源 `_b1SourceReplay` 后缀或 `_proof_N` 编号直接认作目标真名。`audit/native-review-required.json` 给出验收清单：按真实 owner/type/value 唯一定位，核对完整内核 TYPE/value、严格 TYPE BinderInfo、universes、metadata、实例登记、公理、九个构造 argument 与所有生成辅助参数。

目前不缺本 bundle 所需的 source full facts。还缺一项 source resolved-reference 证据（已交可运行轻量 query），以及全部 native 编译/库存/完整对应与平台回读验收；这些属于 root 后续 CI。新模块首次叶检查固定 `60s` / `16GiB`。

本构造提供显式 torsion-finiteness 输入下的 EllipticCurveData。它不提供 CurveArithmetic，不把 h3/h5 消去，也不证明无条件曲线供应存在性。Galois、stable reduction、torsion rationality 等后续 arithmetic obligations仍分别由其实际来源定理供应。
