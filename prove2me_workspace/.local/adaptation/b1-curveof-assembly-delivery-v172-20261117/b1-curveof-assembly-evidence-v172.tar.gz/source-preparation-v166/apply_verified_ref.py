"""Run only after root has accepted the resolved-reference MCP-CI receipt.

Usage: python3 apply_verified_ref.py ACTUAL_RESOLVED_REF_JSON ACCEPTED_JOB_ID
This script never runs Lean or submits a job. It refuses an unresolved lexical-only record.
"""
from pathlib import Path
import json,hashlib,sys
D=Path('/tmp/p2m-b1-curveof-assembly-v166-20261117')
assert len(sys.argv)==3 and sys.argv[2].startswith('ci-'), 'Supply accepted resolved-ref JSON and MCP-CI job ID'
rp=Path(sys.argv[1]);r=json.loads(rp.read_text());cfg=r['configuration']
assert r['schema']=='B1-curveOf-source-resolved-reference-probe/v166'
assert r['sourceCommandBytesMatched'] and r['referenceExtractedFromActualTermInfo']
assert r['probeOnlyDeclIdRewrite'] and not r['originalUseSiteRewritten']
expected=[[[[],'str','Iut'],'str','Tripod'],'str',"finiteDimensional_fieldOf'"]
assert r['actualResolvedReferences']
for ref in r['actualResolvedReferences']:
 assert ref['referenceNameExpr']==expected
 assert ref['parentDeclDisplay']=='Iut.Tripod.curveOf_refSpanProbeV166'
 assert ref['probeByteStart']==cfg['probeReferenceByteStart']
 assert ref['probeByteEnd']==cfg['probeReferenceByteEnd']
 assert not ref['isBinder']
raw=(D/'source/command-45.lean.txt').read_bytes()
assert raw.decode()==cfg['expectedOriginalCommand']
u,v=cfg['sourceCommandRelativeReferenceRange']
assert raw[u:v]==b"finiteDimensional_fieldOf'"
replacement=b'finiteDimensional_fieldOfExtended'
changed=raw[:u]+replacement+raw[v:]
p=D/'pending-ref/Def_AbcAdaptation_Reference_Iut_Tripod_CurveOf.lean';template=p.read_bytes()
assert template.count(raw)==1
# Exact byte splice, with the source unchanged everywhere outside the verified source use-site.
start=template.index(raw);result=template[:start]+changed+template[start+len(raw):]
out=D/'definitions'/p.name;out.write_bytes(result)
def pin(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
record={'schema':'B1-assembly-resolved-use-site-rewrite/v166','acceptedReferenceJobId':sys.argv[2],
 'referenceRecord':pin(rp),'verifiedOriginalResolvedNameExpr':expected,'originalCommandRelativeRange':[u,v],
 'originalIdentifier':"finiteDimensional_fieldOf'",'replacementIdentifier':replacement.decode(),
 'originalCommandSHA256':hashlib.sha256(raw).hexdigest(),'changedCommandSHA256':hashlib.sha256(changed).hexdigest(),
 'unchangedOutsideVerifiedSpan':True,'sourceBinderOrHypothesisChanged':False,'output':pin(out)}
(D/'verified-reference-rewrite.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(out)
