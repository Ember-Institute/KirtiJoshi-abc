长期归档与精确清理复核，2026-11-16。这里只写本 /tmp 目录；没有运行 package_pure_two.py，也没有 API、编译、MCP-CI、Git 或主工作区修改。

两节点交付已闭合在请求的局部范围：

| 目标 | 平台 theorem | ACCEPTED submission | 恢复具名源码 artifact |
| --- | --- | --- | --- |
| log_ell_bound | 5a873b12-aa78-4112-833f-1f12e280f14f | 88916340-d70d-4d63-9167-a26a9d2cd3ac | ci-016693-a791e1a3，succeeded/exit 0 |
| epsilonE_le | 86697611-90eb-4197-bf85-9586928917f8 | 53e697c6-39c8-4d59-8594-0402f3497c95 | ci-016695-e95cb880，succeeded/exit 0 |

当前两个 W/Theorems 真正具名 proof 与四角色历史 native-facts.json 的 nativeSourceText 完全相同，无文本 sorry；SHA256 分别为 `8160276c9a650e0e57af9aef976dff43e7509435444abfa6fcce27e24c6e2f7f`、`5de9f3b0370d89404a388789c4b29f0641693d10e33fad9dc9f82f900bc9f414`。脚本在归档前再次检查该身份和最终 artifact 输入 SHA、独占模式及退出码。

实际四角色审查 ci-016505-5acfce62、ci-016506-554bba3c 均 succeeded/exit 0。两份实际审计的 12 个验收字段为 true、5 个 sorry 相关字段为 false；native、solution、registeredDependency 公理均仅含 propext、Classical.choice、Quot.sound。另有历史 publish=false 元数据，不能把它混入 12/5 计数。

当前 registry 的两节点 theorem/submission/Proved/ACCEPTED 已对应；计划 `docs/开发计划.Prove2Me适配.md:71` 的勾选范围也对应。脚本只读取并收存运行当时的 registry 与计划快照，不维护它们。

最终发布 item 的 name/title/preamble/formal_statement/natural_language_statement/source 六个字段逐项与实际 packet 相同。paper-context-v18 的 Mochizuki 原段落、图像/原始文字、append patch 和校验均在最终包中；原冻结英语与三语没有改写。root 图前后保持相同，detached/root_graph_membership=false、canonicalC22Connected=false。这里不声称 canonical C2、几何输入或 S2-04 完成。

新脚本：`package_pure_two.py`。默认仅报告；root 最终执行时使用：

```
python3 /tmp/p2m-pure-two-delivery-final-v20-20261116/package_pure_two.py
python3 /tmp/p2m-pure-two-delivery-final-v20-20261116/package_pure_two.py --apply
```

长期输出为 `W/.local/adaptation/pure-two-platform-packets-v13-20261116/packaging-final-v20-20261116/` 的 evidence.tar.gz、duplicates.tar.gz、packaging-manifest.json。输出目录已存在时停止，避免覆盖。脚本本身及本 review、删除清单也收入长期 evidence tar。

tar 名称已统一：所有仓库内文件的 archive_path 都由 `path.relative_to(ROOT)` 生成；外部 /tmp 历史输入映射到同一仓库相对前缀下 `packaging-final-v20-20261116/external-evidence/tmp/...`。添加 tar 和读回验证都使用同一 archive_path 字段，不使用绝对路径，不依赖 tar 自动去前导斜线。manifest 同时保存真实源路径与 archive_path，因此能还原 /tmp 原出处。

删除前流程是：检查 16 项精确 SHA → 核对最终交付身份 → 收集小型证据并写 manifest → 写两份 tar → 重开两份 tar，检查成员集合及每成员 SHA → 再检查原输入没有变化 → 最后删除白名单。这一流程没有编译或网络调用。

`delete-whitelist.json` 精确列出 16 个已集成草稿，合计 52,621 bytes：

- W/Solutions 的 log_ell_bound、epsilonE_le 全局上传解答两个文件。
- 最终 packet/staging 中两个目标 stub 和两个 global solution，共四文件。
- main-chain-open/tools/generated/OpenSourceDrafts/Iut_log_ell_bound.lean、Iut_epsilonE_le.lean，以及 generated/formal-only 对应两个文件，共四文件。
- main-chain-open/pure-helper-candidates 的 Theorems、formal-only/Theorems、StatementStubs 中两个目标各三份，共六文件。

真实 W/Theorems 的两个具名 proof、已经注册的两个父模块、NumericInputs、其他节点的源码、metadata/config/audit/oracle 源与输出都不删除。原始 proof 命令额外保存于 tar，当前原始证据文件也保留；没有把来源证据当草稿删除。已删除 staging/formal-only 的历史 JSON 路径通过 duplicates.tar.gz 内精确仓库相对成员查找；历史 JSON/readback/sourceOpen 不静默改写。原父 helper formal-only stub 也不处理，它们属于独立已注册单位的历史材料。

归档证据覆盖：

1. main-chain-open 下两目标及恢复父闭包的全部 29 组 request/submit/result；包括最初 native-facts v13 语法失败 ci-016428-7cb3617c、ci-016429-7ebc449f，后续 v14 修复、最终四角色、平台 stub/solution、原生 leaf/artifact、最终 integrated artifact；也包括共享原型事实 v1 失败 ci-016056-1261bc54 和 v2 成功 ci-016079-cdad59f7。脚本要求每组三件套完整，并记录每次状态、退出码和原始资源字段。
2. 两条真实 source InfoTree：source-oracle-log-ell-bound ci-016250-93e12640、source-oracle-epsilonE-le ci-016251-82b0ff2b 的 result、index、JSONL、normalized source、diagnostics 以及 source probe/config/metadata/OriginalCommands。两条 JSONL 分别为 305,808、317,776 bytes。
3. 原始 original-type-facts.json、查询源、原始与当前四角色 audit/config/bound/native-facts、最终约 8.5 MB 的实际审计 JSON；源证明与 nativeSourceText 都可复核。
4. 最终 packet/payload/ready、完整 platform journal、真实 accepted solution 上传字节、root 图前后与逐字段 readback、私有任务范围和 production gate 复用记录。
5. 原始英文 readback-a/readback-b、原三语 A/B 和 terminology/coverage（共 26 条独立读回覆盖），冻结双条选择、Mochizuki 原文证据、许可证（最终 LICENSE.iut.Apache-2.0 与 refer/iut/LICENSE）。
6. 修复后的 delivery_with_proved_parents.py、原 base delivery.py、live-proved-parent-readbacks.json，两个父实际 Proved 回读；并保留每个节点已有 request intent/submission/result。脚本不调用发布器，也不重复任何 POST。目录中没有单独命名的最初 base-protocol assert 失败日志；该事件由原/修正协议、实际 journal 和本会话说明定位，不虚构 API 失败回执。
7. ready 最终引用的 /tmp 原版本生成器/证明候选/字节证据按来源单独存档，避免长期交付依赖临时目录存活。selected 编译 request 的实际 .lean/.json 入口也收集；不递归追踪任意 input_hashes 或配置内部的巨大导出路径。

规模：独立只读统计的更宽文件超集（包含脚本实际不选的其他 handoff 文件）共 284 文件、28,560,940 bytes = 27.2378 MiB；加本 review 和末次脚本改动后保守不超过 28 MiB。连 tar 头和 gzip 余量，两份 archive 合计保守不超过 30 MiB。脚本在任何归档写入前强制每个文件 ≤16 MiB、全部选中输入 ≤64 MiB。当前最大文件是约 4.25 MB 的实际四角色审计，未打开或重哈希 2.3 GB/560 MB 全环境或其他 source unit dump。

最终恢复 artifact 的资源回执：

| 目标 | 墙钟秒 | CPU 总秒（user+system） | 进程树峰值物理 RSS bytes |
| --- | --- | --- | --- |
| log_ell_bound | 41.81558860000223 | 39.78（2.25+37.53） | 3,149,651,968 |
| epsilonE_le | 42.22735319999629 | 41.150000000000006（4.95+36.2） | 3,208,171,520 |

RSS 均在 16 GiB 以下；PSS 均未知。数值来自相应 MCP-CI resources 字段，CPU 合计与明细一致。没有把 host/worker 总内存当本叶峰值。

脚本仅经 Python AST 语法解析及只读路径/来源/规模核对，没有实际执行（包括默认报告模式）。root 运行前后可按其既有授权维护 docs/registry/Git；本脚本不会替 root 做这些操作。
