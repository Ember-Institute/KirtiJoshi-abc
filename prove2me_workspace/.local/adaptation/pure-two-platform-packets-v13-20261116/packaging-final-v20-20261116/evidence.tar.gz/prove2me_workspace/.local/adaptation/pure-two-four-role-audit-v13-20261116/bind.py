#!/usr/bin/env python3
"""Root-run offline binding utility; receipts and bytes are checked, no CI/API calls.
This utility writes only the assigned /tmp directory, including when --out is used.
"""
import argparse,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation'
P=Path('/tmp/p2m-pure-two-platform-packets-v13-20261116')
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def binding(p):
 p=Path(p).resolve();return {'path':str(p),'sha256':sha(p.read_bytes()),'contents':load(p)}
def receipt(p,source=None,digest=None):
 b=binding(p);r=b['contents'];assert r['status']=='succeeded' and r['result']['exit_code']==0,(p,'not terminal success')
 snap=r['result']['snapshot'];assert snap['workspace_mode']=='exclusive_worktree' and snap['snapshot_id'] is None
 if source:
  hashes=r['request']['worktree_manifest']['input_hashes'];assert hashes[str(source)]==digest,(p,'source input SHA does not match requested role',source)
 return b
def unique(data,piece,label):
 assert piece and data.count(piece)==1,(label,'expected bytes are not a unique exact slice')
 a=data.index(piece);return [a,a+len(piece)]
def source_binding(short):
 O=A/'main-chain-open-20261116';key='log-ell-bound' if short=='log_ell_bound' else 'epsilonE-le'
 candidates=[O/('source-oracle-'+key+'-v1-result.json')]
 # The current root uses source-oracle-epsilonE-le-v1 or epsilonE-v1 naming.
 if short=='epsilonE_le':candidates += [O/'source-oracle-epsilonE-v1-result.json',O/'source-oracle-epsilon-e-le-v1-result.json']
 p=next((p for p in candidates if p.exists()),None)
 if p is None:
  for p0 in O.glob('source-oracle-*-v1-result.json'):
   r=load(p0)
   if r.get('job_id','').startswith('ci-016251-') and short=='epsilonE_le':p=p0;break
 assert p is not None,'Exact source oracle receipt file not found'
 rb=receipt(p);r=rb['contents'];expected='ci-016250-' if short=='log_ell_bound' else 'ci-016251-';assert r['job_id'].startswith(expected)
 idxp=O/'tools/generated/oracle-output'/('Iut_'+short)/'index.json';idx=load(idxp)
 assert idx['complete'] is True and idx['requestedFiles']==idx['finishedFiles']==1
 row=idx['results'][0];assert row['status']=='success'
 diag=load(row['diagnostics']);assert diag['hasErrors'] is False
 config=load(idx['configPath']);assert config==idx['config']
 assert r['request']['parameters']['args'][-1]==idx['configPath']
 assert r['result']['actual_arguments']==['lean',*r['request']['parameters']['args']]
 coord=Path(row['coordinateSource']);facts=Path(row['output']);bs=coord.read_bytes()
 configured=idx['config']['files'][0];assert sha(bs)==configured['normalizedSha256'];assert sha(Path(row['source']).read_bytes())==configured['sourceSha256']
 rs=[json.loads(l) for l in facts.read_text().splitlines() if l]
 assert rs[-1]['kind']=='summary' and rs[-1]['status']=='success'
 assert sum(x['kind']=='decl' for x in rs)==row['declarationCount']
 assert sum(x['kind']=='ref' for x in rs)==row['referenceCount']
 decls=[x for x in rs if x['kind']=='decl' and x.get('nameText')==short];assert len(decls)==1
 d=decls[0];assert d['generationIssue'] is None
 a,b=d['valueRange']['start']['offset'],d['valueRange']['end']['offset'];assert a==d['valStart']['offset'] and b==d['declEnd']['offset']
 nameEnd=d['nameRange']['end']['offset'];proof=bs[a:b];sig=bs[nameEnd:a]
 packet=next(x for x in load(P/'source-proof-evidence.json')['nodes'] if x['sourceName']=='Iut.'+short)
 assert sha(proof)==packet['sourceProofSha256'] and sha(sig)==packet['signatureSha256']
 command=bs[d['declStart']['offset']:d['declEnd']['offset']]
 original=Path(packet['originalCommand']['path']).read_bytes();assert original==command or original==command+b'\n'
 repo=Path(packet['repositoryCommand']['path']).read_bytes();x,y=packet['repositoryCommand']['matchedByteRange'];assert repo[x:y]==command
 forbidden={'Iut.'+short,'AbcAdaptation.Reference.Iut.'+short,'Iut.Corollary22Inputs.c2','Iut.c2_final','Iut.assembly'}
 refs=[x for x in rs if x['kind']=='ref' and a<=x['start']['offset'] and x['end']['offset']<=b]
 assert not any(x['const'] in forbidden for x in refs)
 return {'oracleReceipt':rb,'oracleIndex':binding(idxp),'oracleDiagnostics':binding(row['diagnostics']),
  'oracleFactsPath':str(facts),'oracleFactsSha256':sha(facts.read_bytes()),'oracleFactsText':facts.read_text(),
  'oracleCoordinateSource':str(coord),'oracleCoordinateSha256':sha(bs),'oracleCoordinateText':bs.decode(),
  'actualDecl':d,'sourceProofText':proof.decode(),'sourceSignatureText':sig.decode(),
  'repositorySource':{'path':packet['repositoryCommand']['path'],'sha256':sha(repo)},
  'sourceCommandSha256':sha(command),'actualProofReferenceCount':len(refs)}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--helper',choices=['log_ell_bound','epsilonE_le'],required=True);ap.add_argument('--phase',choices=['native','final'],required=True)
 for arg in ['native-leaf','native-artifact','stub-leaf','stub-artifact','solution-leaf','solution-artifact','native-facts-receipt']:
  ap.add_argument('--'+arg,type=Path)
 ap.add_argument('--dependency-receipt',type=Path,action='append',required=True)
 ap.add_argument('--out',type=Path)
 ap.add_argument('--native-facts',type=Path)
 args=ap.parse_args();cfg=load(D/(args.helper+'-config.template.json'))
 # Bind actual existing source TYPE facts without reopening any huge old export.
 p5=load(A/'main-pure-type-identity-20261116/p5-global-solution-config.json');src=p5['sourceReceiptBinding']['receiptPath']
 cfg['sourceTypeReceipt']=receipt(src);cfg['sourceTypeFactsBinding']=binding(cfg['sourceFacts']['path'])
 assert cfg['sourceTypeReceipt']['contents']['job_id']=='ci-016079-cdad59f7'
 assert cfg['sourceTypeFactsBinding']['sha256']==p5['sourceReceiptBinding']['sourceFactsSha256']
 cfg['sourceBinding']=source_binding(args.helper)
 cfg['dependencyReceiptBindings']=[receipt(p) for p in args.dependency_receipt]
 cfg['expectedStubText']=Path(cfg['expectedStubSource']['path']).read_text();cfg['expectedSolutionText']=Path(cfg['expectedSolutionSource']['path']).read_text()
 if args.phase=='native':
  assert args.native_leaf and args.native_artifact
  native=Path(cfg['nativeInstalledSource']);data=native.read_bytes();cfg['expectedNativeText']=data.decode()
  # Exact existing source proof/signature slices, independent of header/comments.
  sig=cfg['sourceBinding']['sourceSignatureText'].encode();proof=cfg['sourceBinding']['sourceProofText'].encode()
  sr=unique(data,sig,'native signature');pr=unique(data,proof,'native original proof');assert sr[1]==pr[0]
  cfg['proofByteEvidence']['nativeSignatureByteRange']=sr;cfg['proofByteEvidence']['nativeProofByteRange']=pr
  cfg['expectedNativeSource']={'path':str(native),'sha256':sha(data)}
  cfg['nativeReceiptBindings']=[receipt(p,native,sha(data)) for p in [args.native_leaf,args.native_artifact]]
  integration=A/'pure-two-native-integration-v13-20261116/integration-bindings.json'
  assert integration.exists();cfg['nativeIntegrationBindings']=binding(integration)
 else:
  assert all([args.stub_leaf,args.stub_artifact,args.solution_leaf,args.solution_artifact,args.native_facts_receipt])
  history=(args.native_facts or Path(cfg['nativeFactsOutput'])).resolve();cfg['nativeFactsOutput']=str(history);hb=binding(history);hc=hb['contents'];assert hc['schema']=='pure-historical-native-type-facts/v13' and hc['targetName']==cfg['targetName']
  hb['receipt']=receipt(args.native_facts_receipt)
  nr=hb['receipt']['contents'];np=Path(nr['request']['environment']['PURE_FOUR_ROLE_CONFIG'])
  assert load(np)==hc['configuration'],'Native facts do not match actual collector configuration'
  assert nr['request']['worktree_manifest']['input_hashes'][str(np)]==sha(np.read_bytes())
  cfg['nativeFactsBinding']=hb
  # Carry the exact native snapshot and byte ranges already checked in its epoch.
  cfg['proofByteEvidence']=hc['configuration']['proofByteEvidence'];cfg['expectedNativeText']=hc['nativeSourceText']
  for role,paths in [('stub',[args.stub_leaf,args.stub_artifact]),('solution',[args.solution_leaf,args.solution_artifact])]:
   installed=Path(cfg[role+'InstalledSource']);expected=cfg['expected'+role.title()+'Text'].encode();assert installed.read_bytes()==expected
   cfg[role+'ReceiptBindings']=[receipt(p,installed,sha(expected)) for p in paths]
 out=(args.out or D/(args.helper+'-'+args.phase+'-bound.json')).resolve();assert D==out.parent or D in out.parents
 out.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
 print(str(out),sha(out.read_bytes()))

if __name__=='__main__':main()
