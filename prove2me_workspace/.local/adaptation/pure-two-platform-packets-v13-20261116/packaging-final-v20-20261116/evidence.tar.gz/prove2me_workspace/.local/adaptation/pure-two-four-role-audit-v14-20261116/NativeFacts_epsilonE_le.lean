import Lean
import Theorems.Thm_AbcAdaptation_Reference_Iut_epsilonE_le
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

abbrev TypeNames := Array (Name × Name)

-- Proof bodies are substituted only for explicitly exported, closed Prop
-- constants in the original TYPE. Data constants require an actual named map.
partial def decodeType (names : TypeNames) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := decodeType names proofs visiting expandProofs
  let relocate : Name → Except String Name := fun n => do
    if let some p := names.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`Definitions,`Theorems,`Solutions].any (·.isPrefixOf n) then
      throw s!"Unmapped TYPE project constant: {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    let levels ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName original)) then
      unless levels.isEmpty do throw "Closed source proof unexpectedly has universe arguments"
      if !expandProofs then return .const original levels.toList
      if visiting.contains original then throw s!"Cyclic proof-only resolution: {original}"
      return ← decodeType names proofs (visiting.push original) true (← field p "actualProofExpr")
    return .const (← relocate original) levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def actualTargetProof (ci : ConstantInfo) : MetaM Expr := do
  match ci with
  | .thmInfo t => pure t.value
  | _ => throwError "Expected compiled native theorem {ci.name}"

def assertConstants (label : String) (e : Expr) (owners : Array Name) : MetaM Unit := do
  let env ← getEnv
  for n in e.getUsedConstants do
    if #[`Iut,`Genl,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf n) then
      throwError "Original project constant remains in {label}: {n}"
    let some owner := moduleOf env n | throwError "No imported owner in {label}: {n}"
    unless owners.contains owner || #[`Init,`Lean,`Std,`Mathlib,`Batteries,`Aesop,`Qq,`Plausible,`ProofWidgets,`ImportGraph,`Cli,`LeanSearchClient].any (·.isPrefixOf owner) do
      throwError "Unexpected owner in {label}: {n}, {owner}"

def proofValue (ci : ConstantInfo) : MetaM Expr := do
  match ci with
  | .thmInfo t => pure t.value
  | .defnInfo d => pure d.value
  | .opaqueInfo o => pure o.value
  | _ => throwError "No actual proof value {ci.name}"

def nativeDataNames : TypeNames := #[( `Iut.epsilonE, `AbcAdaptation.Reference.Iut.epsilonE),
  (`AbcAdaptation.Reference.Iut.epsilonE, `AbcAdaptation.Reference.Iut.epsilonE)]

def typeProofRows (types : Array Expr) : MetaM (Array Json) := do
  let env ← getEnv
  let mut queue : Array Name := #[]
  for e in types do
    for n in e.getUsedConstants do
      if #[`AbcAdaptation,`_private].any (·.isPrefixOf n) &&
          n != `AbcAdaptation.Reference.Iut.epsilonE && !queue.contains n then queue := queue.push n
  let mut out := #[]
  let mut i := 0
  while i < queue.size do
    let n := queue[i]!
    i := i + 1
    let ci ← getConstInfo n
    unless ci.levelParams.isEmpty && (← isProp ci.type) do
      throwError "TYPE constant requires a genuine data map, not a proof expansion: {n}"
    let v ← proofValue ci
    requireClosed s!"actual TYPE proof {n}" v
    let axs ← collectAxioms n
    let taxs ← expressionAxioms ci.type
    let vaxs ← expressionAxioms v
    for xs in #[axs,taxs,vaxs] do ensureStandard s!"actual TYPE proof {n}" xs
    for e in #[ci.type,v] do
      for dep in e.getUsedConstants do
        if #[`AbcAdaptation,`_private].any (·.isPrefixOf dep) &&
            dep != `AbcAdaptation.Reference.Iut.epsilonE && !queue.contains dep then queue := queue.push dep
    out := out.push (Json.mkObj [("nameExpr", encodeName n), ("name", toJson n.toString),
      ("actualTypeExpr", ← checked (encodeExpr ci.type)), ("actualProofExpr", ← checked (encodeExpr v)),
      ("levelParams", Json.arr #[]), ("isProposition", toJson true), ("isClosed", toJson true),
      ("axioms", toJson (axs.map Name.toString)), ("typeAxioms", toJson (taxs.map Name.toString)),
      ("proofAxioms", toJson (vaxs.map Name.toString))])
  return out

def validateProofRows (rows : Array Json) : MetaM Unit := do
  for p in rows do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) &&
        (← checked (p.getObjValAs? Bool "isClosed")) &&
        (← checked (arrayField p "levelParams")).isEmpty do throwError "Non-closed/non-Prop resolution {n}"
    let t ← checked (decodeType nativeDataNames rows #[] true (← checked (field p "actualTypeExpr")))
    let v ← checked (decodeType nativeDataNames rows #[n] true (← checked (field p "actualProofExpr")))
    let vt ← kernelCheck s!"actual closed proof {n}" v
    unless ← isProp vt do throwError "Data substitution forbidden {n}"
    kernelTypeEq s!"actual proof body/proposition {n}" vt t
    for key in #["axioms","typeAxioms","proofAxioms"] do
      for ax in ← checked (arrayField p key) do
        unless (standardAxioms.map fun a => Json.str a.toString).contains ax do throwError "Nonstandard proof axiom {n}"
    ensureStandard s!"expanded proof {n}" (← expressionAxioms v)

def boundJson (binding : Json) : MetaM Json := do
  if binding == Json.null then throwError "Pending root receipt/facts binding"
  let p ← checked (stringField binding "path")
  let actual ← jsonFile p
  unless actual == (← checked (field binding "contents")) do throwError "Bound JSON changed {p}"
  unless (← checked (stringField binding "sha256")).length == 64 do throwError "Missing root SHA binding {p}"
  return actual

def passedReceipt (binding : Json) : MetaM Json := do
  let r ← boundJson binding
  unless (← checked (stringField r "status")) == "succeeded" do throwError "Receipt not succeeded"
  let result ← checked (field r "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Receipt failed"
  let snap ← checked (field result "snapshot")
  unless (← checked (stringField snap "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snap "snapshot_id")) == Json.null do throwError "Non-exclusive receipt"
  return r

def requireReceipts (rows : Json) : MetaM Unit := do
  let a ← checked rows.getArr?
  unless !a.isEmpty do throwError "Required receipt list is empty"
  for r in a do discard <| passedReceipt r

def bytesEqual (text : String) (range : Json) (expected : String) : MetaM Bool := do
  let a ← checked range.getArr?
  unless a.size == 2 do throwError "Malformed UTF8 byte range"
  let x ← checked a[0]!.getNat?
  let y ← checked a[1]!.getNat?
  let bs := text.toUTF8
  unless x ≤ y && y ≤ bs.size do throwError "Out-of-bound UTF8 byte range"
  return bs.extract x y == expected.toUTF8

def sourceByteIdentity (cfg native : Json) : MetaM (Bool × String × String) := do
  let binding ← checked (field cfg "sourceBinding")
  let receipt ← passedReceipt (← checked (field binding "oracleReceipt"))
  let idx ← boundJson (← checked (field binding "oracleIndex"))
  unless (← checked (idx.getObjValAs? Bool "complete")) do throwError "Source InfoTree index incomplete"
  let results ← checked (arrayField idx "results")
  unless results.size == 1 && (← checked (stringField results[0]! "status")) == "success" do throwError "Source InfoTree failed"
  let diagnostics ← boundJson (← checked (field binding "oracleDiagnostics"))
  unless !(← checked (diagnostics.getObjValAs? Bool "hasErrors")) do throwError "Actual source oracle has errors"
  let jsonl ← IO.FS.readFile (← checked (stringField binding "oracleFactsPath"))
  unless jsonl == (← checked (stringField binding "oracleFactsText")) do throwError "Oracle facts bytes changed"
  let source ← IO.FS.readFile (← checked (stringField binding "oracleCoordinateSource"))
  unless source == (← checked (stringField binding "oracleCoordinateText")) do throwError "Oracle normalized source changed"
  let decl ← checked (field binding "actualDecl")
  let short ← checked (stringField cfg "short")
  unless (← checked (stringField decl "nameText")) == short do throwError "Wrong actual source declaration"
  let mut actualDeclFound := false
  let mut ownGoalUsed := false
  let p0 ← checked ((← checked (field decl "valStart")).getObjValAs? Nat "offset")
  let p1 ← checked ((← checked (field decl "declEnd")).getObjValAs? Nat "offset")
  for line in jsonl.splitOn "\n" do
    if line.isEmpty then continue
    let row ← checked (Json.parse line)
    if (stringField row "kind").toOption == some "decl" && row == decl then actualDeclFound := true
    if (stringField row "kind").toOption == some "ref" then
      let s ← checked ((← checked (field row "start")).getObjValAs? Nat "offset")
      let e ← checked ((← checked (field row "end")).getObjValAs? Nat "offset")
      if p0 ≤ s && e ≤ p1 then
        let n ← checked (stringField row "const")
        if #["Iut." ++ short,"AbcAdaptation.Reference.Iut." ++ short,"Iut.Corollary22Inputs.c2","Iut.c2_final","Iut.assembly"].contains n then ownGoalUsed := true
  unless actualDeclFound && !ownGoalUsed do throwError "Actual source proof InfoTree missing/self-or-future-goal reference"
  let proof ← checked (stringField binding "sourceProofText")
  let signature ← checked (stringField binding "sourceSignatureText")
  let proofRange := toJson #[p0,p1]
  let nameEnd ← checked ((← checked (field (← checked (field decl "nameRange")) "end")).getObjValAs? Nat "offset")
  unless (← bytesEqual source proofRange proof) && (← bytesEqual source (toJson #[nameEnd,p0]) signature) do
    throwError "Source proof/signature differs from actual InfoTree ranges"
  let nativeText ← checked (stringField native "nativeSourceText")
  let b ← checked (field cfg "proofByteEvidence")
  let sol ← IO.FS.readFile (← checked (stringField cfg "solutionInstalledSource"))
  let signatureOk := (← bytesEqual nativeText (← checked (field b "nativeSignatureByteRange")) signature) &&
    (← bytesEqual sol (← checked (field b "solutionSignatureByteRange")) signature)
  let proofOk := (← bytesEqual nativeText (← checked (field b "nativeProofByteRange")) proof) &&
    (← bytesEqual sol (← checked (field b "solutionProofByteRange")) proof)
  unless signatureOk && proofOk do throwError "Native/global solution original proof/signature bytes differ"
  return (true, ← checked (stringField receipt "job_id"), ← checked (stringField b "sourceProofSha256"))

def dependencyAudit (cfg : Json) : MetaM (Array Name × Array Json) := do
  let names ← checked (cfg.getObjValAs? (Array String) "registeredDependencyNames")
  let mut union : Array Name := #[]
  let mut rows := #[]
  for display in names do
    let n := display.toName
    let ci ← getConstInfo n
    let expectedOwner := if n == `AbcAdaptation.Reference.Iut.epsilonE then
      `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs
      else ("Theorems.Thm_" ++ display.replace "." "_").toName
    unless moduleOf (← getEnv) n == some expectedOwner do throwError "Wrong registered dependency owner {n}"
    let v ← proofValue ci
    let axs ← collectAxioms n
    let taxs ← expressionAxioms ci.type
    let vaxs ← expressionAxioms v
    for xs in #[axs,taxs,vaxs] do ensureStandard s!"registered dependency {n}" xs
    if v.getUsedConstants.contains `sorryAx then throwError "Registered dependency direct sorry {n}"
    for ax in axs do unless union.contains ax do union := union.push ax
    rows := rows.push (Json.mkObj [("name", toJson display), ("owner", toJson ((moduleOf (← getEnv) n).map Name.toString)),
      ("axioms", toJson (axs.map Name.toString)), ("typeAxioms", toJson (taxs.map Name.toString)),
      ("valueAxioms", toJson (vaxs.map Name.toString)), ("hasSorryAx", toJson (axs.contains `sorryAx))])
  return (union.qsort Name.lt,rows)
def collectNativeRole : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected4.33 native facts"
  let cfg ← jsonFile (← absoluteEnv "PURE_FOUR_ROLE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "pure-four-role-config/v13" do throwError "Wrong four-role config"
  unless !(← checked (cfg.getObjValAs? Bool "publish")) do throwError "Native facts are unpublished only"
  requireReceipts (← checked (field cfg "nativeReceiptBindings"))
  requireReceipts (← checked (field cfg "dependencyReceiptBindings"))
  discard <| passedReceipt (← checked (field cfg "sourceTypeReceipt"))
  let facts ← boundJson (← checked (field cfg "sourceTypeFactsBinding"))
  let n ← checked (decodeName (← checked (field cfg "targetNameExpr")))
  let owner ← checked (decodeName (← checked (field cfg "theoremModule")))
  let ci ← getConstInfo n
  unless moduleOf (← getEnv) n == some owner do throwError "Wrong historical native owner"
  let value ← actualTargetProof ci
  let axs ← collectAxioms n
  let taxs ← expressionAxioms ci.type
  let vaxs ← expressionAxioms value
  for xs in #[axs,taxs,vaxs] do ensureStandard "historical native proof/type" xs
  let directSorry := value.getUsedConstants.contains `sorryAx
  unless !directSorry && !axs.contains `sorryAx do throwError "Native proof has sorry"
  let typeProofs ← typeProofRows #[ci.type]
  validateProofRows typeProofs
  let sourceRecords ← checked (arrayField facts "records")
  let sourceName ← checked (stringField cfg "sourceName")
  let selected := sourceRecords.filter fun r => (stringField r "name").toOption == some sourceName
  unless selected.size == 1 do throwError "Missing source type record"
  let record := selected[0]!
  let sourceProofs ← checked (arrayField facts "closedTypeProofValues")
  validateProofRows sourceProofs
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.length == ci.levelParams.length do throwError "Native/source universe count mismatch"
  let levels := (canonicalLevels sourceParams.length).map Level.param
  let sourceExpr ← checked (decodeType nativeDataNames sourceProofs #[] true (← checked (field record "elaboratedExpr")))
  let sourceSignature ← checked (decodeType nativeDataNames sourceProofs #[] false (← checked (field record "elaboratedExpr")))
  let nativeType := ci.type.instantiateLevelParams ci.levelParams levels
  let sourceType := sourceExpr.instantiateLevelParams sourceParams levels
  kernelTypeEq "historical source/native full type" sourceType nativeType
  unless binderInventory sourceSignature == binderInventory ci.type &&
      binderPlacement sourceSignature == binderPlacement ci.type do throwError "Source/native BinderInfo mismatch"
  let text ← IO.FS.readFile (← checked (stringField cfg "nativeInstalledSource"))
  unless text == (← checked (stringField cfg "expectedNativeText")) do throwError "Installed native proof source differs from candidate"
  let (daxs,drows) ← dependencyAudit cfg
  for m in (← getEnv).header.moduleNames do
    if #[`Iut,`Genl,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf m) then throwError "Source proof import in native facts {m}"
  IO.FS.writeFile (← checked (stringField cfg "nativeFactsOutput")) ((Json.mkObj [
    ("schema", toJson "pure-historical-native-type-facts/v13"), ("compilerVersion", toJson Lean.versionString),
    ("targetName", toJson n.toString), ("owner", encodeName owner),
    ("actualRawTypeExpr", ← checked (encodeExpr ci.type)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("typeProofValues", Json.arr typeProofs), ("nativeSourceText", toJson text),
    ("nativeAxioms", toJson (axs.map Name.toString)), ("nativeTypeAxioms", toJson (taxs.map Name.toString)),
    ("nativeProofAxioms", toJson (vaxs.map Name.toString)),
    ("nativeBodyDirectSorryAx", toJson directSorry), ("nativeHasTransitiveSorryAx", toJson (axs.contains `sorryAx)),
    ("kernelOriginalNativeTypeEqual", toJson true), ("fullBinderInfoEqual", toJson true),
    ("registeredDependencyAxioms", toJson (daxs.map Name.toString)), ("registeredDependencyFacts", Json.arr drows),
    ("configuration", cfg), ("publish", toJson false)]).pretty ++ "\n")

end FoundationAudit
syntax (name := collectPureNative) "collect_pure_native" : command
@[command_elab collectPureNative] def elabCollectPureNative : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.collectNativeRole
collect_pure_native
