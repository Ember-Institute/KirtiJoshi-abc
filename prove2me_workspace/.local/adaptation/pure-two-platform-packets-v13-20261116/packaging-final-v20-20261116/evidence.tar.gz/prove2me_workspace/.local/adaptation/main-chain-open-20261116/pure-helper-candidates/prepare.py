"""Offline port of three actual source commands. No compilation/API/Git/main writes."""
from pathlib import Path
import hashlib
import json
import shutil

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
SOURCE = W / '.local/adaptation/main-chain-open-20261116/tools/generated'
OUT = Path('/tmp/p2m-main-pure-helpers-v9-20261116')
NAMES = ['p5_height_bound', 'log_ell_bound', 'epsilonE_le']
MATHLIB = Path('/home/admin-wsl/Coq/mathlib4-0df444a')
CONFIG = {
 'p5_height_bound': {
  'imports': ['Mathlib.Data.Real.Basic', 'Mathlib.Data.Finset.Defs',
    'Mathlib.Algebra.Order.GroupWithZero.Basic', 'Mathlib.Tactic.Linarith',
    'Mathlib.Tactic.NormNum', 'Mathlib.Tactic.Positivity', 'Mathlib.Tactic.Push', 'Mathlib.Tactic.Ring'],
  'children': []},
 'log_ell_bound': {
  'imports': ['Mathlib.Analysis.SpecialFunctions.Log.Basic', 'Mathlib.Analysis.Complex.ExponentialBounds',
    'Mathlib.Data.Finset.Defs', 'Mathlib.Algebra.Order.GroupWithZero.Basic',
    'Mathlib.Tactic.Linarith', 'Mathlib.Tactic.NormNum', 'Mathlib.Tactic.Positivity', 'Mathlib.Tactic.Ring',
    'Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_self_of_pos'],
  'children': ['Iut.log_le_self_of_pos']},
 'epsilonE_le': {
  'imports': ['Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs',
    'Mathlib.Analysis.SpecialFunctions.Log.Basic', 'Mathlib.Analysis.Real.Sqrt',
    'Mathlib.Algebra.Order.GroupWithZero.Basic', 'Mathlib.Data.Finset.Defs',
    'Mathlib.Tactic.FieldSimp', 'Mathlib.Tactic.Linarith', 'Mathlib.Tactic.NormNum',
    'Mathlib.Tactic.Positivity', 'Mathlib.Tactic.Push', 'Mathlib.Tactic.Ring',
    'Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_self_of_pos',
    'Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_four_mul_sqrt_sqrt'],
  'children': ['Iut.log_le_four_mul_sqrt_sqrt', 'Iut.log_le_self_of_pos']}}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def code_only(s):
    """Remove comments lexically; never infer signatures, declarations or proof boundaries."""
    out, i, depth, line, string = [], 0, 0, False, False
    while i < len(s):
        c, pair = s[i], s[i:i+2]
        if line:
            if c == '\n':
                line = False
                out.append(c)
            else:
                out.append(' ')
            i += 1
        elif depth:
            if pair == '/-':
                depth += 1
                out.extend('  ')
                i += 2
            elif pair == '-/':
                depth -= 1
                out.extend('  ')
                i += 2
            else:
                out.append('\n' if c == '\n' else ' ')
                i += 1
        elif string:
            out.append(c)
            if c == '\\' and i + 1 < len(s):
                out.append(s[i+1])
                i += 2
            else:
                if c == '"':
                    string = False
                i += 1
        elif pair in ['/-', '--']:
            depth, line = (1, False) if pair == '/-' else (0, True)
            out.extend('  ')
            i += 2
        else:
            if c == '"':
                string = True
            out.append(c)
            i += 1
    assert depth == 0 and not string
    return '\n'.join(x.rstrip() for x in ''.join(out).splitlines()).strip() + '\n'


def prepare():
    source_ledger = json.loads((SOURCE / 'SOURCE_LEDGER.json').read_text())
    registry = json.loads((W / '.local/adaptation/platform-node-registry.json').read_text())
    registered = {r['name']: r for r in registry['reference_source_preparation']['proved_nodes']}
    frontier = json.loads((SOURCE / 'frontier.json').read_text())
    frontier_nodes = {r['sourceName']: r for r in frontier['nodes']}
    records, ledger, statements, import_rows = [], [], [], []
    for n in NAMES:
        name = 'Iut.' + n
        target = 'AbcAdaptation.Reference.' + name
        metadata_path = SOURCE / 'metadata' / ('Iut_' + n + '.json')
        metadata = json.loads(metadata_path.read_text())
        raw_path = Path(metadata['originalWholeCommand']['path'])
        raw = raw_path.read_bytes()
        assert digest(raw) == metadata['originalWholeCommand']['sha256']
        coordinate = Path(metadata['originalCoordinateSource'])
        coordinate_raw = coordinate.read_bytes()
        assert digest(coordinate_raw) == metadata['originalCoordinateSha256']
        a, b = [metadata['originalRange'][k]['offset'] for k in ['start', 'end']]
        assert raw == coordinate_raw[a:b] + b'\n'
        assert len(metadata['proofAndDefinitionBodyRanges']) == len(metadata['signatureSyntax']) == 1
        proof = metadata['proofAndDefinitionBodyRanges'][0]
        pa, pb = [proof[k]['offset'] for k in ['start', 'end']]
        body = coordinate_raw[pa:pb]
        assert digest(body) == metadata['originalBodyHashes'][0]
        assert body.startswith(b':= by')
        sig = metadata['signatureSyntax'][0]['range']
        sa, sb = [sig[k]['offset'] for k in ['start', 'end']]
        assert a <= sa < sb < pa < pb == b
        imports = CONFIG[n]['imports']
        assert CONFIG[n]['children'] == frontier_nodes[name]['directRegisteredReuse']
        assert frontier_nodes[name]['directPendingChildren'] == []
        notice = '''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Namespace adaptation of the complete original source command. The proof body
and signature bytes are retained. This native candidate has not been compiled. -/
'''
        preamble = notice + '\n'.join('import ' + x for x in imports) + '''

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference
namespace Iut
universe u v w
open Finset Real

'''
        closing = '\nend Iut\nend AbcAdaptation.Reference\n'
        native = preamble.encode() + raw + closing.encode()
        fn = 'Thm_' + target.replace('.', '_') + '.lean'
        native_path = OUT / 'Theorems' / fn
        native_path.parent.mkdir(parents=True, exist_ok=True)
        native_path.write_bytes(native)
        original_copy = OUT / 'OriginalCommands' / raw_path.name
        original_copy.parent.mkdir(exist_ok=True)
        shutil.copyfile(raw_path, original_copy)
        meta_copy = OUT / 'source-metadata' / metadata_path.name
        meta_copy.parent.mkdir(exist_ok=True)
        shutil.copyfile(metadata_path, meta_copy)
        statement = raw[:pa-a] + b':= by sorry\n'
        statement_path = OUT / 'StatementStubs' / fn
        statement_path.parent.mkdir(exist_ok=True)
        statement_path.write_bytes(preamble.encode() + statement + closing.encode())
        formal_path = OUT / 'formal-only' / 'Theorems' / fn
        formal_path.parent.mkdir(parents=True, exist_ok=True)
        formal_path.write_text(code_only(native.decode()))
        native_body_start = len(preamble.encode()) + pa - a
        native_body_end = len(preamble.encode()) + pb - a
        assert native[native_body_start:native_body_end] == body
        record = {'sourceName': name, 'targetName': target, 'candidate': str(native_path),
            'candidateSha256': digest(native), 'statementCandidate': str(statement_path),
            'formalOnly': str(formal_path), 'sourceMetadata': {'path': str(metadata_path), 'sha256': sha(metadata_path)},
            'originalCommand': {'path': str(raw_path), 'sha256': digest(raw)},
            'originalCoordinate': {'path': str(coordinate), 'sha256': digest(coordinate_raw)},
            'originalCommandRange': metadata['originalRange'], 'originalSignatureRange': sig,
            'originalProofRange': proof, 'nativeCommandRange': [len(preamble.encode()), len(preamble.encode()) + b-a],
            'nativeSignatureRange': [len(preamble.encode()) + sa-a, len(preamble.encode()) + sb-a],
            'nativeProofRange': [native_body_start, native_body_end], 'proofSha256': digest(body),
            'sourceStatementAndProofBytesUnchanged': True, 'sourceTrailingNewlineOutsideAst': True,
            'proofEdits': [], 'newHypotheses': [], 'nativeLeafTypecheck': 'pending root MCP-CI',
            'semanticSourceOracle': metadata['semanticSourceOracleStatus'],
            'sourceOracleProbe': metadata['oracleProbe'], 'sourceOracleConfig': metadata['oracleConfig']}
        records.append(record)
        child_rows = []
        for child in CONFIG[n]['children']:
            row = registered['AbcAdaptation.Reference.' + child]
            assert row['status'] == 'Proved' and row['verification_status'] == 'ACCEPTED'
            child_rows.append(row)
        original_entry = next(x for x in source_ledger['entries'] if x['producerSourceName'] == name)
        ledger.append({'producerSourceName': name, 'targetName': target,
            'actualConsumers': metadata['actualConsumerEdges'], 'graphTypeDependencies': metadata['graphTypeDependencies'],
            'graphValueDependencies': metadata['graphValueDependencies'], 'directRegisteredChildren': child_rows,
            'source': original_entry['source'], 'sourceMetadata': record['sourceMetadata'],
            'proofSha256': record['proofSha256'], 'fidelity': 'Original source command, signature, binders and whole proof body copied without any edit; only imports and outer namespace are adapted.',
            'nativeImportClosureNote': 'Existing registered-child Theorems files are local statement stubs with sorry. Platform child proofs are separately ACCEPTED; local transitive axiom closure remains an explicit root audit item.',
            'proofCompletionClaimed': False})
        statements.append({'sourceName': name, 'targetName': target, 'preamble': preamble,
            'statementInNamespace': statement.decode(), 'closingContext': closing,
            'scope': 'AST-derived exact statement candidate, not a platform payload or compiler-derived printed type'})
        for imported in imports:
            source = (MATHLIB if imported.startswith('Mathlib.') else W) / (imported.replace('.', '/') + '.lean')
            assert source.exists()
            assert not imported.startswith(('Iut.', 'Genl.', 'ArithmeticTeichmullerSpaces.'))
            assert imported != 'Theorems.Thm_' + target.replace('.', '_')
            import_rows.append({'consumer': target, 'import': imported, 'sourcePath': str(source), 'sha256': sha(source)})
    for mod in ['Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_self_of_pos',
                'Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_four_mul_sqrt_sqrt',
                'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs']:
        p = W / (mod.replace('.', '/') + '.lean')
        dst = OUT / 'formal-only' / (mod.replace('.', '/') + '.lean')
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(code_only(p.read_text()))
    save(OUT / 'source-proof-byte-evidence.json', records)
    save(OUT / 'statement-candidates.json', statements)
    save(OUT / 'consumer-ledger.json', {'sourceCommit': '07cb1da58f6d428a670dbb5dd6093d428bcbcdd8', 'entries': ledger,
        'sourceLedgerInput': {'path': str(SOURCE / 'SOURCE_LEDGER.json'), 'sha256': sha(SOURCE / 'SOURCE_LEDGER.json')}})
    save(OUT / 'imports.json', import_rows)
    save(OUT / 'module-plan.json', {'leafModules': [r['targetName'] for r in records],
        'nativeFileModules': ['Theorems.Thm_' + r['targetName'].replace('.', '_') for r in records],
        'independentLeaves': ['Iut.p5_height_bound'], 'registeredChildReuse': {
            'Iut.log_ell_bound': CONFIG['log_ell_bound']['children'], 'Iut.epsilonE_le': CONFIG['epsilonE_le']['children']},
        'numericDefinition': 'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs',
        'newCrossEdgesAmongTheseThree': [], 'targetParentConsumer': 'Iut.Corollary22Inputs.c2',
        'compiler': 'Lean v4.33.1; Mathlib 0df444a360eaa60ab8c11dca51a86af692955474',
        'firstNewLeafEstimates': {'expected_duration': '60s', 'expected_memory': '16GiB'},
        'CIExecutor': 'root only through MCP-CI; no compilation performed by this preparation',
        'sourceOraclePolicy': 'Use the already prepared separate OracleSourceProbes/Configs to obtain original semantic facts; do not import a full source/own-goal module as a proof oracle.'})
    return records


if __name__ == '__main__':
    print(json.dumps({'prepared': [r['targetName'] for r in prepare()], 'compilerRun': False, 'CIInvoked': False}, ensure_ascii=False))
