# 三个纯算术 helper 的实际完整类型同一性草稿

全部写入仅限本临时目录；未调用Lean、CI、API、Git，未写主区。所有配置publish=false。

code-first source入口为 `QueryPureArithmeticTypeFacts.lean`，4.35配置为 `source-config.json`，环境变量 `PURE_TYPE_SOURCE_CONFIG`。它只import缓存原 `Iut.Implication.Corollary22` 并读取三root的ConstantInfo.type；不读取或导出三root的原proof value，也不collect三root的证明公理闭包。它导出实际结构化Name/Expr、完整BinderInfo、universe参数及type axioms，不做pretty-printer round-trip。

如果TYPE引用源生成的封闭Prop证明（例如epsilonE._proof_2），source入口另行取得其actual type/proof Expr与三套axioms。它拒绝任何非Prop数据替换、开放表达式、非零universe proof参数及对三root证明的引用；递归记录proof体所需的同source-module封闭Prop helper。唯一允许的项目data引用为epsilonE，后续必须映射到已接受NumericInputs Definition。

每个helper各有 `Audit_p5_height_bound.lean` / `Audit_log_ell_bound.lean` / `Audit_epsilonE_le.lean` 和同名 `*-config.json`，native环境变量为 `PURE_TYPE_NATIVE_CONFIG`。每份只import其native theorem artifact和NumericInputs Definition；不会导入生产Iut/Genl。未准备完成的helper artifact须root先按实际授权验收。

native decoder复用现有Expr codec，只增加明确的proof-only分支：按实际source Name找到已导出的封闭Prop值，递归展开；每个proof均由native kernel检查其actual source proposition及standard axioms。没有给源proof常量虚构native alias，没有data值替换。原source和actual target的raw Expr都写入结果，因此rawName差异不会被隐藏。

签名BinderInfo检查使用未展开proof常量的source signature；kernelTypeEq使用已检查的proof-body展开与epsilonE实际Name映射。这样既检查原完整签名的inventory/placement，也允许原source numeral proof与native编译器新proofName通过真实typed proof body和内核proof irrelevance对接。native theorem、type、proof的transitive axioms必须只含标准公理；sorryAx会失败。

三个native config的sourceReceiptBinding当前为null，须root在实际source TYPE导出成功后填真实receiptPath、receiptContents、sourceFactsSha256，并在MCP-CI manifest绑定source facts、receipt、配置和入口。预估首次60s/16GiB。若root移动文件/配置，须更新路径和SHA。

p5原独立证明oracle ci-016006及native proof leaf ci-016017另见 `separate-proof-evidence.json`；它们与本TYPE事实导出严格分开。本查询不宣称验证独立source proof，也不从cached全模块的旧proof推断它。其余两个独立proof oracle状态没有被假定通过。
