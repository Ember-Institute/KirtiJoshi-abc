#!/usr/bin/env python3
"""Prepare two phased four-role audits. No compiler, CI, API, Git, or workspace writes."""
import sys
sys.dont_write_bytecode=True
import ast,hashlib,json,copy,importlib.util
from pathlib import Path
R=Path('/home/admin-wsl/Coq/abc');W=R/'prove2me_workspace';A=W/'.local/adaptation';D=Path(__file__).resolve().parent
P=Path('/tmp/p2m-pure-two-platform-packets-v13-20261116');N=Path('/tmp/p2m-pure-next-two-native-v12-20261116')
SHORT=['log_ell_bound','epsilonE_le']
def ev(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def load(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def enc(s):
 n=[]
 for part in s.split('.'):n=[n,'str',part]
 return n

def main():
 assert D==Path('/tmp/p2m-pure-two-four-role-audit-v13-20261116')
 p5=A/'main-pure-type-identity-20261116/AuditP5GlobalSolution.lean';s=p5.read_text();common=s[s.index('/-! Stable JSON'):s.index('def pureArithmeticTypeAudit :')]
 common+=(D/'common-extra.lean.txt').read_text()
 publisher=P/'publisher.py';tree=ast.parse(publisher.read_text());flags={}
 for n in tree.body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['AUDIT_FLAGS','NO_SORRY_FLAGS'] for t in n.targets):
   flags[n.targets[0].id]=ast.literal_eval(n.value)
 assert len(flags['AUDIT_FLAGS'])==12
 rows={r['sourceName'].split('.')[-1]:r for r in load(P/'source-proof-evidence.json')['nodes']}
 spec=importlib.util.spec_from_file_location('four_role_offline_binder',D/'bind.py');binder=importlib.util.module_from_spec(spec);spec.loader.exec_module(binder)
 for short in SHORT:
  tm='Theorems.Thm_AbcAdaptation_Reference_Iut_'+short;sm='Solutions.Sol_AbcAdaptation_Reference_Iut_'+short
  for phase,imports,body in [('NativeFacts',[tm,'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs'],'native-body.lean.txt'),('FourRoles',[tm,sm,'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs'],'final-body.lean.txt')]:
   q='import Lean\n'+''.join('import '+m+'\n' for m in imports)+'\n'+common+(D/body).read_text()
   (D/f'{phase}_{short}.lean').write_text(q)
  byteEvidence=copy.deepcopy(rows[short]);actualNative=W/'Theorems'/('Thm_AbcAdaptation_Reference_Iut_'+short+'.lean');nativeBytes=actualNative.read_bytes();sb=binder.source_binding(short)
  sr=binder.unique(nativeBytes,sb['sourceSignatureText'].encode(),'actual native signature');pr=binder.unique(nativeBytes,sb['sourceProofText'].encode(),'actual native proof');assert sr[1]==pr[0]
  byteEvidence['preIntegrationCandidate']={'path':byteEvidence['nativeCandidate'],'sha256':byteEvidence['nativeCandidateSha256']}
  byteEvidence.update(nativeCandidate=str(actualNative),nativeCandidateSha256=hashlib.sha256(nativeBytes).hexdigest(),nativeSignatureByteRange=sr,nativeProofByteRange=pr)
  cfg={'schema':'pure-four-role-config/v13','publish':False,'short':short,'sourceName':'Iut.'+short,'targetName':'AbcAdaptation.Reference.Iut.'+short,
   'targetNameExpr':enc('AbcAdaptation.Reference.Iut.'+short),'theoremModule':enc(tm),'solutionModule':enc(sm),
   'sourceFacts':ev(A/'main-pure-type-identity-20261116/original-type-facts.json'),
   'nativeInstalledSource':str(W/Path(tm.replace('.','/')).with_suffix('.lean')),
   'stubInstalledSource':str(W/Path(tm.replace('.','/')).with_suffix('.lean')),
   'solutionInstalledSource':str(W/Path(sm.replace('.','/')).with_suffix('.lean')),
   'expectedNativeSource':ev(W/'Theorems'/('Thm_AbcAdaptation_Reference_Iut_'+short+'.lean')),
   'expectedStubSource':ev(P/'staging/Theorems'/('Thm_AbcAdaptation_Reference_Iut_'+short+'.lean')),
   'expectedSolutionSource':ev(P/'staging/Solutions'/('Sol_AbcAdaptation_Reference_Iut_'+short+'.lean')),
   'proofByteEvidence':byteEvidence,
   'registeredDependencyNames':['AbcAdaptation.Reference.Iut.log_le_self_of_pos']+(['AbcAdaptation.Reference.Iut.log_le_four_mul_sqrt_sqrt'] if short=='epsilonE_le' else [])+['AbcAdaptation.Reference.Iut.epsilonE'],
   'sourceBinding':None,'nativeReceiptBindings':None,'nativeFactsBinding':None,'stubReceiptBindings':None,'solutionReceiptBindings':None,'dependencyReceiptBindings':None,
   'nativeFactsOutput':str(D/f'{short}-native-facts.json'),'finalOutput':str(D/f'{short}-four-role-audit.json'),
   'publisherAuditFlags':flags['AUDIT_FLAGS'],'publisherNoSorryFlags':flags['NO_SORRY_FLAGS'],
   'pending':'Root must run native facts while genuine native and restored children are installed, bind facts+receipts, then replace own goal with stub and compile global solution before final audit. No native/stub co-import.',
   'inputEvidence':[ev(p5),ev(A/'main-pure-type-identity-20261116/p5-global-solution-kernel-identity.json'),ev(publisher)]}
  save(D/f'{short}-config.template.json',cfg)
  ready={'targetName':cfg['targetName'],'sourceName':cfg['sourceName'],'sourceOracleJob':None,'sourceProofSha256':rows[short]['sourceProofSha256'],'publish':False,'passed':False}
  ready.update({f:False for f in flags['AUDIT_FLAGS']+flags['NO_SORRY_FLAGS']});ready.update({k:[] for k in ['nativeAxioms','solutionAxioms','registeredDependencyAxioms']})
  save(D/f'{short}-audit-flags.not-run.json',ready)
 save(D/'handoff.json',{'schema':'two-pure-helper-four-role-handoff/v13','publish':False,'source':ev(A/'main-pure-type-identity-20261116/original-type-facts.json'),
  'configs':[ev(D/f'{s}-config.template.json') for s in SHORT],
  'queries':[ev(D/f'{phase}_{s}.lean') for s in SHORT for phase in ['NativeFacts','FourRoles']],
  'environmentVariable':'PURE_FOUR_ROLE_CONFIG','expected_duration':'60s','expected_memory':'16GiB',
  'publisherFlags':flags,'publisher':ev(publisher),'nativeStatus':'Draft candidates only; restored children are not declared closed before actual CI/axiom facts.',
  'executionOrder':'Bind source oracle + native receipts; run NativeFacts. Bind native facts receipt. Install/compile stub+global solution in the separate later phase; bind receipts; run FourRoles. Never import historical native and same-name stub together.',
  'validation':'Offline preparation only; no compilation/CI/API/Git/main workspace writes.'})
 print('Prepared configs and four-role queries in',D)

if __name__=='__main__':main()
