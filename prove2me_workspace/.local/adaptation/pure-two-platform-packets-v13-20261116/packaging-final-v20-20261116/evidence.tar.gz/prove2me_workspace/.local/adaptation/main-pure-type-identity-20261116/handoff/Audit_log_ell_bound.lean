import Lean
import Theorems.Thm_AbcAdaptation_Reference_Iut_log_ell_bound
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

abbrev TypeNames := Array (Name × Name)

-- Proof bodies are substituted only for explicitly exported, closed Prop
-- constants in the original TYPE. Data constants require an actual named map.
partial def decodeType (names : TypeNames) (proofs : Array Json) (visiting : Array Name)
    (expandProofs : Bool) (j : Json) : Except String Expr := do
  let recur := decodeType names proofs visiting expandProofs
  let relocate : Name → Except String Name := fun n => do
    if let some p := names.find? (·.1 == n) then return p.2
    if #[`Iut,`Genl,`AbcAdaptation,`Definitions,`Theorems,`Solutions].any (·.isPrefixOf n) then
      throw s!"Unmapped TYPE project constant: {n}"
    return n
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    let levels ← (← arrayField j "levels").mapM decodeLevel
    if let some p := proofs.find? (fun p => (field p "nameExpr").toOption == some (encodeName original)) then
      unless levels.isEmpty do throw "Closed source proof unexpectedly has universe arguments"
      if !expandProofs then return .const original levels.toList
      if visiting.contains original then throw s!"Cyclic proof-only resolution: {original}"
      return ← decodeType names proofs (visiting.push original) true (← field p "actualProofExpr")
    return .const (← relocate original) levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocate (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unsupported actual Expr kind {k}"

def actualTargetProof (ci : ConstantInfo) : MetaM Expr := do
  match ci with
  | .thmInfo t => pure t.value
  | _ => throwError "Expected compiled native theorem {ci.name}"

def assertConstants (label : String) (e : Expr) (owners : Array Name) : MetaM Unit := do
  let env ← getEnv
  for n in e.getUsedConstants do
    if #[`Iut,`Genl,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf n) then
      throwError "Original project constant remains in {label}: {n}"
    let some owner := moduleOf env n | throwError "No imported owner in {label}: {n}"
    unless owners.contains owner || #[`Init,`Lean,`Std,`Mathlib,`Batteries,`Aesop,`Qq,`Plausible,`ProofWidgets,`ImportGraph,`Cli,`LeanSearchClient].any (·.isPrefixOf owner) do
      throwError "Unexpected owner in {label}: {n}, {owner}"

def pureArithmeticTypeAudit : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected native4.33 type audit"
  let cfg ← jsonFile (← absoluteEnv "PURE_TYPE_NATIVE_CONFIG")
  unless (← checked (stringField cfg "schema")) == "pure-arithmetic-native-type-config/v9" do throwError "Wrong native type config"
  unless !(← checked (cfg.getObjValAs? Bool "publish")) do throwError "Native query is unpublished only"
  let binding ← checked (field cfg "sourceReceiptBinding")
  if binding == Json.null then throwError "Pending actual source TYPE export receipt/SHA binding"
  let receipt ← jsonFile (← checked (stringField binding "receiptPath"))
  unless receipt == (← checked (field binding "receiptContents")) &&
      (← checked (stringField receipt "status")) == "succeeded" do throwError "Source TYPE receipt mismatch"
  let sourceResult ← checked (field receipt "result")
  unless (← checked (sourceResult.getObjValAs? Nat "exit_code")) == 0 do throwError "Source TYPE export failed"
  let snap ← checked (field sourceResult "snapshot")
  unless (← checked (stringField snap "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snap "snapshot_id")) == Json.null do throwError "Unexpected source TYPE workspace receipt"
  unless (← checked (stringField binding "sourceFactsSha256")).length == 64 do throwError "Source TYPE SHA not bound in config/CI manifest"
  let facts ← jsonFile (← checked (stringField cfg "sourceFacts"))
  unless (← checked (stringField facts "schema")) == "pure-arithmetic-original-type-facts/v9" &&
      (← checked (stringField facts "compilerVersion")) == "4.35.0-rc3" &&
      !(← checked (facts.getObjValAs? Bool "rootTheoremProofsRead")) do throwError "Wrong TYPE-fact scope/compiler"
  let sourceCfg ← jsonFile (← checked (stringField (← checked (field cfg "sourceConfig")) "path"))
  unless (← checked (field facts "configuration")) == sourceCfg do throwError "TYPE export config changed"
  let records ← checked (arrayField facts "records")
  unless records.size == 3 do throwError "Expected exactly three actual TYPE records"
  let original ← checked (decodeName (← checked (field cfg "originalName")))
  let targetName ← checked (decodeName (← checked (field cfg "targetName")))
  let targetOwner ← checked (decodeName (← checked (field cfg "targetModule")))
  let originalRows := records.filter fun r => (field r "nameExpr").toOption == some (encodeName original)
  unless originalRows.size == 1 do throwError "Missing/duplicate original TYPE {original}"
  let record := originalRows[0]!
  let target ← getConstInfo targetName
  unless moduleOf (← getEnv) targetName == some targetOwner do throwError "Wrong actual native theorem owner {targetName}"
  let numericOwner := `Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs
  let mut names : TypeNames := #[]
  for row in ← checked (arrayField cfg "dataMap") do
    let n ← checked (decodeName (← checked (field row "sourceName")))
    let t ← checked (decodeName (← checked (field row "targetName")))
    unless n == `Iut.epsilonE && t == `AbcAdaptation.Reference.Iut.epsilonE &&
        moduleOf (← getEnv) t == some numericOwner do throwError "Only the existing accepted epsilonE data Name map is admitted"
    names := names.push (n,t)
  let proofs ← checked (arrayField facts "closedTypeProofValues")
  let mut proofReports := #[]
  for p in proofs do
    let n ← checked (decodeName (← checked (field p "nameExpr")))
    unless (← checked (p.getObjValAs? Bool "isProposition")) &&
        (← checked (p.getObjValAs? Bool "isClosed")) &&
        (← checked (arrayField p "levelParams")).isEmpty do throwError "Invalid proof-only source resolution {n}"
    for key in #["axioms","typeAxioms","proofAxioms"] do
      for ax in ← checked (arrayField p key) do
        unless (standardAxioms.map fun a => Json.str a.toString).contains ax do throwError "Nonstandard source proof axiom {n}"
    let sourceProofType ← checked (decodeType names proofs #[] true (← checked (field p "actualTypeExpr")))
    let proof ← checked (decodeType names proofs #[n] true (← checked (field p "actualProofExpr")))
    let proofType ← kernelCheck s!"actual source Prop proof body {n}" proof
    unless ← isProp proofType do throwError "Source resolution is data, not a Prop proof {n}"
    kernelTypeEq s!"actual source proof typed against its exported proposition {n}" sourceProofType proofType
    let axs ← expressionAxioms proof
    ensureStandard s!"source closed Prop proof realized natively {n}" axs
    assertConstants s!"proof-only body {n}" proof #[numericOwner]
    proofReports := proofReports.push (Json.mkObj [
      ("sourceName", encodeName n), ("sourceRecord", p),
      ("expandedActualProofExpr", ← checked (encodeExpr proof)),
      ("kernelCheckedActualProposition", toJson true), ("axioms", toJson (axs.map Name.toString)),
      ("nativeNameAliasInvented", toJson false), ("dataSubstitution", toJson false)])
  let typeJson ← checked (field record "elaboratedExpr")
  -- Keep the raw proof Names for signature BinderInfo checks. Expansion is only
  -- used for the kernel check; raw source/target Exprs are retained in output.
  let rawSignature ← checked (decodeType names proofs #[] false typeJson)
  let sourceTypeRaw ← checked (decodeType names proofs #[] true typeJson)
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.length == target.levelParams.length do throwError "Universe arity mismatch"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let sourceSignature := rawSignature.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams canonical
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory sourceSignature &&
      binderInventory sourceSignature == binderInventory targetType &&
      binderPlacement sourceSignature == binderPlacement targetType do throwError "Complete original/native signature BinderInfo differs"
  for ax in ← checked (arrayField record "typeAxioms") do
    unless (standardAxioms.map fun a => Json.str a.toString).contains ax do throwError "Nonstandard original TYPE axiom"
  assertConstants "resolved original TYPE" sourceType #[numericOwner,targetOwner]
  assertConstants "actual native TYPE" targetType #[numericOwner,targetOwner]
  kernelTypeEq s!"actual complete TYPE {original} -> {targetName}" sourceType targetType
  let proof ← actualTargetProof target
  requireClosed "actual native compiled theorem proof" proof
  let axs ← collectAxioms targetName
  let taxs ← expressionAxioms target.type
  let paxs ← expressionAxioms proof
  for xs in #[axs,taxs,paxs] do ensureStandard "actual native theorem/type/proof" xs
  -- Native proof dependencies may include already accepted arithmetic children.
  -- Standard axiom closure above rejects any imported Open theorem dependency.
  for m in (← getEnv).header.moduleNames do
    if #[`Iut,`Genl,`ArithmeticTeichmullerSpaces].any (·.isPrefixOf m) then throwError "Production source import in native audit {m}"
  IO.FS.writeFile (← checked (stringField cfg "outputFile")) ((Json.mkObj [
    ("schema", toJson "pure-arithmetic-native-type-identity/v9"), ("compilerVersion", toJson Lean.versionString),
    ("original", encodeName original), ("target", encodeName targetName),
    ("configuration", cfg), ("sourceReceiptBinding", binding),
    ("dataIdentityEvidence", ← checked (field cfg "dataIdentityEvidence")),
    ("rawOriginalTypeRecord", record), ("actualRawTargetTypeExpr", ← checked (encodeExpr target.type)),
    ("resolvedOriginalTypeExpr", ← checked (encodeExpr sourceType)),
    ("proofOnlyResolutions", Json.arr proofReports), ("kernelCompleteTypeEqual", toJson true),
    ("fullSignatureBinderInventoryAndPlacementEqual", toJson true),
    ("nativeTheoremAxioms", toJson (axs.map Name.toString)),
    ("nativeTypeAxioms", toJson (taxs.map Name.toString)), ("nativeProofAxioms", toJson (paxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("sourceTheoremProofsReadForTypeFacts", toJson false),
    ("independentOriginalProofOracleAcceptedByThisQuery", toJson false), ("publish", toJson false)]).pretty ++ "\n")

end FoundationAudit
syntax (name := auditPureArithmeticType) "audit_pure_arithmetic_type" : command
@[command_elab auditPureArithmeticType] def elabAuditPureArithmeticType : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.pureArithmeticTypeAudit

audit_pure_arithmetic_type
