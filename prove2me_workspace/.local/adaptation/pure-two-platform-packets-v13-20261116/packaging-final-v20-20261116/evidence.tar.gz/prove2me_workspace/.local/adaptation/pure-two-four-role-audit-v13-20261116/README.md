# 两个纯 helper 的四角色严格审查草稿

唯一写目录为本目录。没有Lean、MCP-CI、API、Git调用或主区写入。所有配置publish=false，所有 `*-audit-flags.not-run.json` 字段均为false。

使用已实际通过的P5 codec/闭合Prop展开/kernelTypeEq/BinderInfo primitives，分别准备log_ell_bound和epsilonE_le。来源Type Expr只读取146KB的original-type-facts.json，不加载旧560MB/2.3GB导出。source独立proof oracle来自actual ci-016250/251与complete=true、hasErrors=false的InfoTree工件，不能以原文注释代替。

分两个互斥时间阶段：

1. genuine native与恢复后的两个Proved helper安装并实际通过leaf/artifact后，用bind.py --phase native绑定回执，再运行 `NativeFacts_<helper>.lean`。入口只import实际W的native具名module和NumericInputs；检查原source/native完整Type Expr+BinderInfo、实际native证明和注册依赖的标准公理闭包，记录raw type、闭合TYPE proof值及完整native源码快照。这里不产生项目proofalias。
2. root保存历史nativefacts及其collector回执后，安装并编译平台stub和global solution。用bind.py --phase final绑定历史nativefacts与stub/solution回执，再运行 `FourRoles_<helper>.lean`。此入口只import当前stub/global solution与NumericInputs，不同时import同名native。它对source/native/stub/global solution四种实际Type Expr逐一检查全部6pair的kernelTypeEq、完整BinderInfo inventory和placement。

两阶段统一环境变量 `PURE_FOUR_ROLE_CONFIG`。首次每个新叶预估60s/16GiB。bind.py只做离线回执与字节绑定，不启动编译。默认写本目录bound配置；--out也限制本目录。root若把nativefacts写到别处，可在final绑定时用--native-facts指定只读路径。

native绑定需要 --native-leaf、--native-artifact及一个或多个--dependency-receipt。final绑定需要 --stub-leaf、--stub-artifact、--solution-leaf、--solution-artifact、--native-facts-receipt及--dependency-receipt；可指定--native-facts。所有必需回执必须succeeded、exit0、exclusive_worktree；native/stub/solution各自的实际输入SHA须与其真实源码对应。

root已更改native过时注释，故binder不使用v12旧offset。它从actual InfoTree selected decl的nameRange/valStart/declEnd读取完整signature/proof bytes，在实际W native源码唯一匹配并要求两段相邻。实际离线预览：logell signature[977,1165]、proof[1165,2047]，SHA8160276c...；epsilon signature[1175,1324]、proof[1324,3399]，SHA5de9f3b...。source-evidence单命令文件仅比实际AST command多一个外部结尾newline；数学签名与证明bytes完全一致。最终入口再次读取实际JSONL、normalized source、诊断和source oracle receipt，检查本轮selected decl事实、proof范围ref没有self/future-goal依赖，并将历史native及当前global solution的signature/proof与actual source字节直接比较。

闭合Prop数字实例证明使用显式actual typed proof值展开，raw source/native/stub/solution Name差异全部保留；不创建alias，不替换数据。epsilonE仅复用现有NumericInputs Definition，不增加定义。注册依赖按真实ConstantInfo owner与当前transitive axioms检查；未验收的恢复候选不被称作闭合。

最终精确输出publisher.py所需12个AUDIT_FLAGS与5个NO_SORRY_FLAGS，全部在实际6pair、字节、回执、公理门成功后由事实计算。native/global solution及注册依赖不得有sorryAx；stub本身是Open，只比较其完整type并单独报告stub公理。未运行的模板始终passed=false，不是验收结果。此交付没有执行发布器、上传或消息发送。
