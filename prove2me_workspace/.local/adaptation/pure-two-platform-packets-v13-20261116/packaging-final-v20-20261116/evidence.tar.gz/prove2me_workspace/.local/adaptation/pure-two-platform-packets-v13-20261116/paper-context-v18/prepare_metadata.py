from pathlib import Path
import json, hashlib, copy
root=Path('/home/admin-wsl/Coq/abc')
out=Path('/tmp/p2m-pure-helpers-mochizuki-context-v18-20261116')
packet_path=root/'prove2me_workspace/.local/adaptation/pure-two-platform-packets-v13-20261116/packet.json'
p5_path=root/'prove2me_workspace/.local/adaptation/p5-height-reference-proof-delivery-20261116/payload.json'
supplier=root/'prove2me_workspace/.local/adaptation/supplier-carriers-delivery-20261116/paper-context/paper-context.json'
supplier_tar=supplier.with_name('paper-evidence.tar.gz')
main_context=root/'prove2me_workspace/.local/adaptation/main-c22-numeric-reference-split-20261115/paper-source-context.en.json'
code=root/'refer/iut/Iut/Implication/Corollary22.lean'
pdf=root/'refer/Mochizuki/Inter-universal Teichmuller Theory IV.pdf'
url='https://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf'
def sha(b): return hashlib.sha256(b).hexdigest()
def record(p): return {'path':str(p),'sha256':sha(p.read_bytes())}
def write(name,obj): (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
packet=json.loads(packet_path.read_text())
supplier_data=json.loads(supplier.read_text())
assert sha(pdf.read_bytes())==supplier_data['paper_sources']['IV']['sha256']
qlog=r'''Next, let us note that it follows immediately from (P1), together with Proposition 2.1, (i), that

$h^{1/2}\cdot\log(l)\leq h^{1/2}\cdot\log(20\cdot\delta^2\cdot h^2)$ […]'''
qeps=r'''Now let us set

$\epsilon_E\overset{\mathrm{def}}{=}(60\delta)^2\cdot h^{-1/2}\cdot\log(2\delta\cdot h)$ […]

[…] we may assume without loss of generality that $\epsilon_E\leq1$.'''
quotes=[
 {'id':'IV-C22-log-context','paper':'IV','printed_page':45,'pdf_file_page':45,'locator':'§2, proof of Corollary 2.2(ii), (P1), and the final paragraph after (P4) preceding (P5)','quote_markdown':qlog,'normalization':'English prose is transcribed from the rendered original; line breaks and the line-end hyphen in Proposition are joined. Mathematical notation is rendered as LaTeX. Only the first comparison of the following display is quoted; its remaining comparisons are explicitly omitted.','context_note':'(P1) on the same page includes l ≤ 10δ·h^(1/2)·log(2δ·h) ≤ 20δ²h². The original paper uses a prime l; the scalar lemma uses an arbitrary real ell under its explicit hypotheses.','checked_existing_rendering':True},
 {'id':'IV-C22-epsilon-context','paper':'IV','printed_page':47,'pdf_file_page':47,'locator':'§2, proof of Corollary 2.2(ii), paragraph “Now let us set”, first definition display, and final clause of the page','quote_markdown':qeps,'normalization':'Prose and mathematical formula checked against the rendered original. LaTeX replaces the printed notation. The parenthetical lower bound, the next definition, intermediate estimates, and the exceptional-set enlargement are explicitly omitted.','context_note':'This gives the paper context for arranging epsilonE ≤ 1. It does not identify the reference helper’s general epsilon or fourth-power threshold as a verbatim paper statement.','checked_existing_rendering':True}
]
for q in quotes:
 q['author']='Shinichi Mochizuki'
 q['title']='Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations'
 q['version']='April 2020'
 q['official_url']=url
 q['quote_sha256_utf8']=sha(q['quote_markdown'].encode())
 p=q['printed_page']
 q['evidence']=[record(out/f'evidence/IV-{p:03d}.png'),record(out/f'evidence/IV-{p:03d}.raw.txt')]
 q['evidence_source_archive']=record(supplier_tar)
log_append='\n\n**Mochizuki paper context for the Corollary 2.2 consumer (English)**\n\n'+r'''The reference consumer `Iut.Corollary22Inputs.c2` uses `log_ell_bound` while ruling out the failure of (P5): after obtaining $\ell\leq20\delta^2h^2$, it bounds $\log\ell$ and passes that bound to `p5_height_bound`. Mochizuki’s corresponding discussion is in IUT IV, §2, proof of Corollary 2.2(ii), printed/PDF p. 45: (P1) gives the prime bound, and the final paragraph before (P5) begins:

> '''+qlog.replace('\n\n','\n>\n> ')+r'''

— Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, proof of Corollary 2.2(ii), paragraph beginning “Next, let us note” after (P4), printed/PDF p. 45.

This quotation locates the Corollary 2.2 consumption context. The paper continues with its own estimates leading to (P5); it does not state this scalar lemma with the conclusion $\log\ell\leq3+2\delta+8s$. The reference helper’s real parameters and constants $3,2,8$, and the hypothesis $\log h\leq4s$, belong to that Lean extraction. The quotation adds no hypothesis to the formal statement.

Original paper: '''+url

eps_append='\n\n**Mochizuki paper context for the Corollary 2.2 consumer (English)**\n\n'+r'''The reference consumer `Iut.Corollary22Inputs.c2` applies `epsilonE_le` with $\varepsilon=1$ to its explicit height threshold and then carries $\epsilon_E\leq1$ into the final (C2) estimate. Mochizuki defines this error term and arranges the same bound in IUT IV, §2, proof of Corollary 2.2(ii), printed/PDF p. 47:

> '''+qeps.replace('\n\n','\n>\n> ')+r'''

— Shinichi Mochizuki, *Inter-universal Teichmüller Theory IV: Log-volume Computations and Set-theoretic Foundations* (April 2020), §2, proof of Corollary 2.2(ii), paragraph “Now let us set” and final clause of the page, printed/PDF p. 47.

This quotation locates the Corollary 2.2 consumption context. The omitted paper argument enlarges the exceptional set and uses its surrounding geometric and height hypotheses. The reference helper gives a sufficient scalar fourth-power threshold for any positive real $\varepsilon$ under its displayed assumptions. That threshold, including $2\delta+4$ and the fourth power, is a reference Lean implementation estimate; it is not quoted as an independently stated paper theorem. The quotation adds no hypothesis to the formal statement.

Original paper: '''+url
append_values=[log_append,eps_append]
ops=[]
append_records=[]
preview=copy.deepcopy(packet)
protected={}
for i,app in enumerate(append_values):
 payload=packet['publications'][i]['payload']
 name=payload['theorem_name']
 old=payload['natural_language_statement']
 frozen=old.split('\n\n**Implementation and proof-status context',1)[0]
 pointer=f'/publications/{i}/payload/natural_language_statement'
 new=old+app
 ops.extend([{'op':'test','path':pointer,'value':old},{'op':'replace','path':pointer,'value':new}])
 append_records.append({'theorem_name':name,'json_pointer':pointer,'old_utf8_sha256':sha(old.encode()),'append_markdown':app,'append_utf8_sha256':sha(app.encode()),'new_utf8_sha256':sha(new.encode()),'frozen_prefix_utf8_sha256':sha(frozen.encode()),'quotation_id':quotes[i]['id']})
 preview['publications'][i]['payload']['natural_language_statement']=new
 assert new.encode().startswith(old.encode())
 assert new.split('\n\n**Implementation and proof-status context',1)[0].encode()==frozen.encode()
 restored=copy.deepcopy(preview['publications'][i]['payload'])
 restored['natural_language_statement']=old
 assert restored==payload
 protected[name]={'preamble_utf8_sha256':sha(payload['preamble'].encode()),'formal_statement_utf8_sha256':sha(payload['formal_statement'].encode()),'all_existing_natural_language_bytes_preserved':True,'frozen_trilingual_readback_bytes_preserved':True}
restored=copy.deepcopy(preview)
for i in range(2):restored['publications'][i]['payload']['natural_language_statement']=packet['publications'][i]['payload']['natural_language_statement']
assert restored==packet
p5=json.loads(p5_path.read_text())
p5_nls=p5['natural_language_statement']
p5_quote=next(q for q in supplier_data['quotations'] if q['id']=='IV-p5-p6')
p5_report={'file':record(p5_path),'same_missing_quote_gap':False,'checks':{'contains_original_paper_paragraph': '**Original paper paragraph**' in p5_nls,'contains_exact_previously_verified_P5_P6_quote':p5_quote['quote_markdown'] in p5_nls,'contains_Mochizuki_author': 'Shinichi Mochizuki' in p5_nls,'contains_precise_locator': 'printed p. 46' in p5_nls and 'Corollary 2.2(ii)' in p5_nls,'contains_official_url':url in p5_nls,'distinguishes_scalar_lemma_from_paper': 'it does not state this scalar lemma or its fourth-power constant verbatim' in p5_nls},'action':'Report only. No edit and no API call.','note':'The P5 payload already quotes the prior supplier IV-p5-p6 text exactly, including the explicit omission before (P6). The comparison to [GenEll] is part of Mochizuki’s own cited paragraph; this is not a Joshi quotation.'}
assert all(p5_report['checks'].values())
write('metadata-append-patch.json',{'schema':'pure-helpers-mochizuki-source-context-append/v1','status':'draft-not-applied','packet':record(packet_path),'scope':'Only append English Mochizuki paper-consumer context to two natural_language_statement strings. Existing text is an exact UTF-8 prefix; all other packet fields are unchanged.','appends':append_records,'protected_fields':protected})
write('rfc6902-patch.json',ops)
write('packet.preview.json',preview)
write('quotations-evidence.json',{'schema':'pure-helpers-mochizuki-quotations-evidence/v1','paper':{**supplier_data['paper_sources']['IV'],'sha256_rechecked_this_task':sha(pdf.read_bytes())},'source_inputs':[record(supplier),record(supplier_tar),record(main_context),record(code)],'quotations':quotes,'code_consumption':{'Iut.log_ell_bound':{'declaration_line':158,'direct_consumer':'Iut.Corollary22Inputs.c2','direct_call_line':520,'following_consumer':'Iut.p5_height_bound at line 522'},'Iut.epsilonE_le':{'declaration_line':111,'direct_consumer':'Iut.Corollary22Inputs.c2','direct_call_line':418,'instantiation':'epsilon = 1; hε1′ is passed into c2_final at line 554'}},'verification_scope':'Existing original-PDF hashes and archived rendering hashes rechecked. Rendered pp.45 and47 visually inspected. Existing supplier quotation provenance used; no new download, PDF parsing, compiler run, or platform action.'})
write('p5-gap-report.json',p5_report)
write('validation.json',{'passed':True,'validation_type':'Metadata-only JSON/string/provenance validation; no Lean compilation','only_changed_json_paths':[f'/publications/{i}/payload/natural_language_statement' for i in range(2)],'all_previous_natural_language_utf8_preserved':True,'frozen_trilingual_readbacks_unchanged':True,'all_preamble_and_formal_statement_strings_unchanged':True,'all_other_packet_fields_unchanged':True,'source_code_written':False,'main_workspace_written':False,'git_invoked':False,'ci_invoked':False,'compiler_invoked':False,'platform_api_invoked':False,'files_written_only_under':str(out)})
manifest={str(p.relative_to(out)):sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='sha256-manifest.json'}
write('sha256-manifest.json',manifest)
print(json.dumps({'out':str(out),'files':list(manifest),'p5_same_gap':False,'packet_sha256':sha(packet_path.read_bytes()),'quotation_sha256':[q['quote_sha256_utf8'] for q in quotes]},ensure_ascii=False,indent=2))
