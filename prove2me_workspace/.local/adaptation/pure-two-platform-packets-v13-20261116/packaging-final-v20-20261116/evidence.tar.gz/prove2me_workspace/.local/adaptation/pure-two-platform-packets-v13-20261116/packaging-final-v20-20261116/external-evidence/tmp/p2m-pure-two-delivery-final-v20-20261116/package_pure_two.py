#!/usr/bin/env python3
"""Root-run archival package. Default reports only; --apply archives and removes 16 reviewed drafts.
No compiler, CI, API, Git, docs edits, or registry edits. All tar member names are repo-relative.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import tarfile

ROOT = Path('/home/admin-wsl/Coq/abc')
W = ROOT / 'prove2me_workspace'
A = W / '.local/adaptation'
CHAIN = A / 'main-chain-open-20261116'
DELIVERY = A / 'pure-two-platform-packets-v13-20261116'
FOUR = A / 'pure-two-four-role-audit-v13-20261116'
TASK = Path('/tmp/p2m-pure-two-delivery-final-v20-20261116')
OUTPUT = DELIVERY / 'packaging-final-v20-20261116'
MAX_FILE_BYTES = 16 * 1024 ** 2
MAX_TOTAL_BYTES = 64 * 1024 ** 2
NAMES = ['log_ell_bound', 'epsilonE_le']
EXPECTED = {
    'log_ell_bound': {
        'theorem_id': '5a873b12-aa78-4112-833f-1f12e280f14f',
        'submission_id': '88916340-d70d-4d63-9167-a26a9d2cd3ac',
        'source_sha256': '8160276c9a650e0e57af9aef976dff43e7509435444abfa6fcce27e24c6e2f7f',
        'artifact_job': 'ci-016693-a791e1a3', 'audit_job': 'ci-016505-5acfce62'},
    'epsilonE_le': {
        'theorem_id': '86697611-90eb-4197-bf85-9586928917f8',
        'submission_id': '53e697c6-39c8-4d59-8594-0402f3497c95',
        'source_sha256': '5de9f3b0370d89404a388789c4b29f0641693d10e33fad9dc9f82f900bc9f414',
        'artifact_job': 'ci-016695-e95cb880', 'audit_job': 'ci-016506-554bba3c'},
}
TRUE_AUDIT_FLAGS = ['sourceProofCommandIdentityVerified', 'solutionClosureStandardAxiomsOnly',
    'signatureBinderInfoPreserved', 'registeredDependencyClosureStandardAxiomsOnly',
    'nativeClosureStandardAxiomsOnly', 'kernelStubSolutionTypeEqual',
    'kernelOriginalStubTypeEqual', 'kernelOriginalSolutionTypeEqual',
    'kernelOriginalNativeTypeEqual', 'kernelNativeStubTypeEqual',
    'kernelNativeSolutionTypeEqual', 'allExpressionBinderInfoEqual']
FALSE_AUDIT_FLAGS = ['solutionHasTransitiveSorryAx', 'solutionBodyDirectSorryAx',
    'registeredDependenciesHaveTransitiveSorryAx', 'nativeHasTransitiveSorryAx', 'nativeBodyDirectSorryAx']
PARENTS = ['log_le_self_of_pos', 'log_le_four_mul_sqrt_sqrt']


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked(path):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise RuntimeError('Missing or symlink input: ' + str(path))
    if path.stat().st_size > MAX_FILE_BYTES:
        raise RuntimeError('Excluded large input; do not read/hash/archive: ' + str(path))
    return path


def arcname(path):
    """One canonical archive key, used identically for add and verification."""
    path = Path(path)
    if path.is_relative_to(ROOT):
        value = path.relative_to(ROOT).as_posix()
    else:
        # Preserve /tmp evidence under a virtual repo-relative archival path.
        # No absolute path or tar's automatic slash stripping is used.
        if not path.is_relative_to(Path('/tmp')):
            raise RuntimeError('Unreviewed outside-repository input: ' + str(path))
        value = (OUTPUT.relative_to(ROOT) / 'external-evidence' / 'tmp' /
                 path.relative_to('/tmp')).as_posix()
    parsed = PurePosixPath(value)
    if parsed.is_absolute() or '..' in parsed.parts or value.startswith('/'):
        raise RuntimeError('Invalid repo-relative archive name: ' + value)
    return value


def selected_attempt(path):
    name = path.name.lower()
    return any(token in name for token in ['log_ell_bound', 'epsilone_le',
        'log-ell-bound', 'epsilone-le', 'restored-log_le_self_of_pos',
        'restored-log_le_four_mul_sqrt_sqrt', 'restored-pure-dependencies',
        'source-pure-three-type-facts', 'pure-two'])


def collect(remove):
    files = set()
    # Only bounded, theorem-specific directories. Never traverse the adaptation
    # root, caches, complete environment exports, or unrelated supplier dumps.
    for directory in [DELIVERY, FOUR, CHAIN / 'independent-readbacks-v9']:
        for path in directory.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and not path.is_relative_to(OUTPUT):
                files.add(checked(path))
    attempts = sorted(path for path in CHAIN.glob('*.json') if selected_attempt(path))
    files.update(attempts)
    for path in attempts:
        if not path.name.endswith('-request.json'):
            continue
        request = read(checked(path))
        parameters = request.get('parameters', {})
        source_args = [parameters.get('source')] + parameters.get('args', [])
        for value in source_args:
            if isinstance(value, str) and Path(value).suffix in ['.lean', '.json']:
                source = Path(value) if Path(value).is_absolute() else W / value
                # These are actual compiler/config entry points, not recursive
                # manifests. Do not follow arbitrary input_hashes into huge dumps.
                if source.is_file():
                    files.add(checked(source))
    for name in NAMES:
        oracle = CHAIN / 'tools/generated/oracle-output' / ('Iut_' + name)
        files.update(checked(path) for path in oracle.rglob('*') if path.is_file())
        for directory, suffix in [('metadata', '.json'), ('OriginalCommands', '.lean'),
                ('OracleSourceProbes', '.lean'), ('OracleConfigs', '.json')]:
            files.add(checked(CHAIN / 'tools/generated' / directory / ('Iut_' + name + suffix)))
        files.add(checked(W / 'Theorems' / ('Thm_AbcAdaptation_Reference_Iut_' + name + '.lean')))
        files.add(checked(CHAIN / 'pure-helper-candidates/OriginalCommands' / ('Iut_' + name + '.lean')))
        files.add(checked(CHAIN / 'pure-helper-candidates/source-metadata' / ('Iut_' + name + '.json')))
    for relative in ['Handoff.md', 'artifact-manifest.json', 'consumer-ledger.json',
            'formal-only-inputs.json', 'frozen-readback-reference.json', 'imports.json',
            'module-plan.json', 'native-api-review.json', 'offline-validation.json',
            'prepare.py', 'source-proof-byte-evidence.json', 'statement-candidates.json',
            'LICENSE.iut.Apache-2.0']:
        files.add(checked(CHAIN / 'pure-helper-candidates' / relative))
    identity = A / 'main-pure-type-identity-20261116'
    for relative in ['original-type-facts.json', 'source-config.json',
            'QueryPureArithmeticTypeFacts.lean', 'handoff/Audit_log_ell_bound.lean',
            'handoff/Audit_epsilonE_le.lean', 'handoff/log_ell_bound-config.json',
            'handoff/epsilonE_le-config.json', 'handoff/QueryPureArithmeticTypeFacts.lean',
            'handoff/final-manifest.json', 'handoff/handoff.json', 'handoff/README.md',
            'handoff/source-config.json', 'handoff/native-body.lean.txt',
            'handoff/source-body.lean.txt', 'handoff/separate-proof-evidence.json']:
        files.add(checked(identity / relative))
    ready = read(DELIVERY / 'ready.final.json')
    # Includes the exact /tmp generator versions used by the final packet.
    # Each has a separate virtual repo-relative tar member, preserving origin.
    files.update(checked(path) for path in ready['evidence_sha256'])
    for values in ready['required_inputs'].values():
        files.update(checked(path) for path in values.values())
    files.update(checked(path) for path in ready['shared_required_inputs'].values())
    old_unit = A / 'main-c22-numeric-helpers-20261115'
    for parent in PARENTS:
        files.add(checked(W / 'Theorems' / ('Thm_AbcAdaptation_Reference_Iut_' + parent + '.lean')))
        tag = 'verify-AbcAdaptation_Reference_Iut_' + parent
        for suffix in ['-solution.lean', '-intent.json', '-result.json']:
            files.add(checked(old_unit / 'delivery-journal' / (tag + suffix)))
    files.add(checked(W / 'Definitions/Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs.lean'))
    files.update(checked(path) for path in [ROOT / 'refer/iut/Iut/Implication/Corollary22.lean',
        ROOT / 'refer/iut/LICENSE', CHAIN / 'tools/generated/SOURCE_LEDGER.json',
        A / 'reference-main-chain-parser-20261115/parser-output/Iut-Implication-Corollary22.normalized.lean',
        A / 'platform-node-registry.json', ROOT / 'docs/开发计划.Prove2Me适配.md',
        Path(__file__).resolve(), TASK / 'delete-whitelist.json', TASK / 'REVIEW.md', TASK / 'static-review.json'])
    return sorted(files - set(remove), key=str), attempts


def require_success(path, job):
    receipt = read(checked(path))
    assert receipt['job_id'] == job and receipt['status'] == 'succeeded', str(path)
    assert receipt['result']['exit_code'] == 0, str(path)
    return receipt


def verify_final_state():
    registry = read(A / 'platform-node-registry.json')
    records = {row['name']: row for row in registry['reference_source_preparation']['proved_nodes']}
    summary = read(DELIVERY / 'platform/delivery-summary.json')
    assert summary['both_direct_proofs'] == 'ACCEPTED'
    assert summary['canonicalC22Connected'] is False and summary['root_graph_unchanged'] is True
    packet = read(DELIVERY / 'packet.json')
    payloads = {row['payload']['theorem_name']: row['payload'] for row in packet['publications']}
    statuses = {}
    for name, expected in EXPECTED.items():
        target = 'AbcAdaptation.Reference.Iut.' + name
        canonical = checked(W / 'Theorems' / ('Thm_AbcAdaptation_Reference_Iut_' + name + '.lean'))
        assert digest(canonical) == expected['source_sha256'], 'Changed final native source: ' + str(canonical)
        facts = read(FOUR / (name + '-native-facts.json'))
        assert canonical.read_text() == facts['nativeSourceText'], 'Restored native differs from archived facts'
        artifact = require_success(CHAIN / ('integrated-' + name + '-accepted-native-artifact-v18-result.json'), expected['artifact_job'])
        request = artifact['request']
        assert request['workspace'] == str(W) and request['exclusive'] is True
        assert request['worktree_manifest']['source_sha256'] == expected['source_sha256']
        assert artifact['result']['snapshot']['workspace_mode'] == 'exclusive_worktree'
        assert artifact['result']['snapshot']['snapshot_id'] is None
        require_success(CHAIN / ('pure-' + name + '-four-role-final-v15-result.json'), expected['audit_job'])
        audit = read(DELIVERY / 'actual-audits' / (name + '-four-role-audit.json'))
        assert all(audit[key] is True for key in TRUE_AUDIT_FLAGS)
        assert all(audit[key] is False for key in FALSE_AUDIT_FLAGS)
        for key in ['nativeAxioms', 'solutionAxioms', 'registeredDependencyAxioms']:
            assert set(audit[key]) <= {'propext', 'Classical.choice', 'Quot.sound'}
        verification = read(DELIVERY / 'platform' / ('verify-' + target.replace('.', '_') + '-result.json'))
        assert verification['status'] == 'ACCEPTED'
        assert verification['theorem_id'] == expected['theorem_id'] and verification['id'] == expected['submission_id']
        published = read(DELIVERY / 'platform' / (target.replace('.', '_') + '-published-item.json'))
        for key in ['theorem_name', 'theorem_title', 'preamble', 'formal_statement',
                    'natural_language_statement', 'source']:
            assert published[key] == payloads[target][key], 'Final platform payload differs: ' + key
        record = records[target]
        assert record['theorem_id'] == expected['theorem_id'] and record['submission_id'] == expected['submission_id']
        assert record['status'] == 'Proved' and record['verification_status'] == 'ACCEPTED'
        assert record['root_graph_membership'] is False
        statuses[name] = {'canonical_source_sha256': digest(canonical), 'artifact_job': artifact['job_id'],
            'platform_theorem': verification['theorem_id'], 'platform_submission': verification['id']}
    return statuses


def write_archive(path, entries):
    with tarfile.open(path, 'w:gz') as archive:
        for row in entries:
            archive.add(row['source'], arcname=row['archive_path'], recursive=False)
    with tarfile.open(path, 'r:gz') as archive:
        expected = {row['archive_path'] for row in entries}
        actual = {member.name for member in archive.getmembers()}
        assert actual == expected, 'Archive member names differ'
        for row in entries:
            member = archive.getmember(row['archive_path'])
            assert member.isfile() and not member.name.startswith('/')
            stream = archive.extractfile(member)
            assert stream is not None and hashlib.sha256(stream.read()).hexdigest() == row['sha256'], row['archive_path']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    if OUTPUT.exists():
        raise SystemExit('Output exists; inspect the prior run instead of overwriting: ' + str(OUTPUT))
    whitelist = read(TASK / 'delete-whitelist.json')
    assert len(whitelist) == 16
    remove = {ROOT / row['path']: row for row in whitelist}
    for path, row in remove.items():
        checked(path)
        assert digest(path) == row['sha256'] and path.stat().st_size == row['bytes'], 'Reviewed draft changed: ' + str(path)
        assert not path.is_relative_to(W / 'Theorems'), 'Canonical theorem deletion is forbidden'
        assert not any(parent in path.name for parent in PARENTS), 'Registered parent deletion is forbidden'
    final = verify_final_state()
    evidence, attempts = collect(remove)
    all_files = evidence + list(remove)
    total = sum(checked(path).stat().st_size for path in all_files)
    assert total <= MAX_TOTAL_BYTES, 'Selected evidence exceeds bounded 64 MiB input total'
    all_keys = [arcname(path) for path in all_files]
    assert len(all_keys) == len(set(all_keys)), 'Duplicate canonical archive name'
    entries = [{'source': str(path), 'archive_path': arcname(path), 'bytes': path.stat().st_size,
                'sha256': digest(path)} for path in evidence]
    removed_entries = [{'source': str(path), 'archive_path': arcname(path),
                        'bytes': row['bytes'], 'sha256': row['sha256']} for path, row in remove.items()]
    attempts_by_stem = {}
    for path in attempts:
        stem, suffix = path.name.rsplit('-', 1)
        attempts_by_stem.setdefault(stem, set()).add(suffix)
    assert all(parts == {'request.json', 'submit.json', 'result.json'} for parts in attempts_by_stem.values()), 'Attempt triple is incomplete'
    attempt_states = []
    for path in attempts:
        if path.name.endswith('-result.json'):
            receipt = read(path)
            attempt_states.append({'path': str(path.relative_to(ROOT)), 'job_id': receipt['job_id'],
                'status': receipt['status'], 'exit_code': receipt['result']['exit_code'],
                'resources': receipt.get('resources'), 'compile_time_seconds': receipt.get('compile_time_seconds')})
    manifest = {'schema': 'pure-two-final-archive/v20', 'completed': False,
        'final_verified_state': final, 'input_bytes': total, 'input_mib': total / 1024 ** 2,
        'archive_upper_bound_bytes': total + len(all_files) * 1024 + 1024 ** 2,
        'canonical_archive_names': 'All tar members are repo-relative; external /tmp sources use a virtual repo-relative external-evidence/tmp subtree.',
        'evidence': entries, 'remove_after_verified_archive': removed_entries,
        'attempts': attempt_states,
        'excluded_scope': 'No cache, full environment export, 2.3 GB/560 MB source dump, unrelated source unit, canonical theorem, or registered parent is removed.',
        'historical_paths': 'Removed original staging/formal-only paths resolve as exact repo-relative members of duplicates.tar.gz. Historical JSON/readback/sourceOpen text is unchanged.'}
    print(json.dumps({'mode': 'apply' if args.apply else 'report-only', 'output': str(OUTPUT),
        'evidence_files': len(entries), 'attempt_groups': len(attempts_by_stem),
        'remove_files': len(removed_entries), 'remove_bytes': sum(row['bytes'] for row in removed_entries),
        'input_bytes': total, 'input_mib': total / 1024 ** 2,
        'archive_upper_bound_bytes': manifest['archive_upper_bound_bytes'],
        'remove_whitelist': removed_entries}, ensure_ascii=False, indent=2))
    if not args.apply:
        return
    OUTPUT.mkdir()
    manifest_path = OUTPUT / 'packaging-manifest.json'
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    write_archive(OUTPUT / 'evidence.tar.gz', entries)
    write_archive(OUTPUT / 'duplicates.tar.gz', removed_entries)
    # Both tar files have been reopened and every member verified by the same
    # repo-relative key and pre-archive SHA before the first source deletion.
    for row in entries + removed_entries:
        assert digest(checked(row['source'])) == row['sha256'], 'Input changed while archiving: ' + row['source']
    for path in remove:
        path.unlink()
    manifest['completed'] = True
    manifest['archive_bytes'] = {name: (OUTPUT / name).stat().st_size for name in ['evidence.tar.gz', 'duplicates.tar.gz']}
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__':
    main()
