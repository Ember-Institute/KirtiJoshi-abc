"""Offline shim for the existing delivery protocol. Only explicit deliver calls APIs."""
from pathlib import Path
import hashlib
import importlib.util
import sys
sys.dont_write_bytecode = True

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
OUT = Path('/tmp/p2m-pure-two-platform-packets-v13-20261116')
PROTOCOL = W / '.local/adaptation/pure-two-platform-packets-v13-20261116/delivery_with_proved_parents.py'
spec = importlib.util.spec_from_file_location('pure_two_existing_numeric_delivery', PROTOCOL)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
BASE_PREFLIGHT = old.preflight
SHORT = ['log_ell_bound', 'epsilonE_le']
NAMES = ['AbcAdaptation.Reference.Iut.' + name for name in SHORT]
old.NAMES = NAMES
old.ORIGINALS = ['Iut.' + name for name in SHORT]
old.GATES |= {'source_proof_oracle', 'original_proof_identity',
    'native_stub_solution_binder_identity', 'closed_dependency_closure'}
read, sha, save = old.read, old.sha, old.save
AUDIT_FLAGS = ['signatureBinderInfoPreserved', 'allExpressionBinderInfoEqual',
    'kernelOriginalNativeTypeEqual', 'kernelOriginalStubTypeEqual',
    'kernelOriginalSolutionTypeEqual', 'kernelNativeStubTypeEqual',
    'kernelNativeSolutionTypeEqual', 'kernelStubSolutionTypeEqual',
    'sourceProofCommandIdentityVerified', 'nativeClosureStandardAxiomsOnly',
    'solutionClosureStandardAxiomsOnly', 'registeredDependencyClosureStandardAxiomsOnly']
NO_SORRY_FLAGS = ['nativeHasTransitiveSorryAx', 'nativeBodyDirectSorryAx',
    'solutionHasTransitiveSorryAx', 'solutionBodyDirectSorryAx',
    'registeredDependenciesHaveTransitiveSorryAx']
REQUIRED_PER_NODE = {'native_leaf', 'native_artifact', 'stub_leaf', 'stub_artifact',
    'solution_leaf', 'solution_artifact', 'source_proof_oracle',
    'source_native_stub_solution_kernel_audit', 'recursive_axiom_audit',
    'registered_dependency_closure_audit'}
EXPECTED_DEPENDENCY_PATHS = {
    'Theorems/Thm_AbcAdaptation_Reference_Iut_log_le_self_of_pos.lean',
    'Theorems/Thm_AbcAdaptation_Reference_Iut_log_le_four_mul_sqrt_sqrt.lean',
    'Definitions/Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs.lean'}


def prepare():
    spec = importlib.util.spec_from_file_location('pure_two_offline_prepare', OUT / 'prepare.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.prepare()


def preflight(packet_path, ready_path):
    """Validate root-supplied acceptance before the established publisher can run."""
    packet, ready = read(packet_path), read(ready_path)
    assert ready['passed'] is True, 'Root final acceptance remains pending'
    assert len(packet['publications']) == len(packet['verification']) == 2
    assert [row['payload']['theorem_name'] for row in packet['publications']] == NAMES
    assert set(ready['kernel_audits']) == set(ready['source_oracle_receipts']) == set(NAMES)
    assert set(ready['required_inputs']) == set(NAMES)
    assert set(ready['dependency_source_sha256']) == EXPECTED_DEPENDENCY_PATHS
    for relative, digest in ready['dependency_source_sha256'].items():
        assert sha(W / relative) == digest, ('Changed registered dependency source', relative)
    proof_rows = {row['targetName']: row for row in read(OUT / 'source-proof-evidence.json')['nodes']}
    for name, publication, verification in zip(NAMES, packet['publications'], packet['verification']):
        payload = publication['payload']
        assert publication['endpoint'] == '/submit-problem'
        assert payload['private'] is True and payload['env'] == old.ENV
        assert verification['theorem_name'] == name
        frozen = packet['frozenReadbacks'][name]
        assert frozen['sourceOpen'] is True
        assert frozen['readbacks']['en'] == frozen['originalEnglish'] == frozen['readback']
        assert hashlib.sha256(frozen['readbacks']['en'].encode()).hexdigest() == frozen['english_readback_utf8_sha256']
        assert all(text in payload['natural_language_statement'] for text in frozen['readbacks'].values())
        required = ready['required_inputs'][name]
        assert set(required) == REQUIRED_PER_NODE
        assert all(path and path in ready['evidence_sha256'] for path in required.values())
        oracle_path = ready['source_oracle_receipts'][name]
        assert oracle_path == required['source_proof_oracle']
        oracle = read(oracle_path)
        assert oracle['status'] == 'succeeded' and oracle['result']['exit_code'] == 0
        audit_path = ready['kernel_audits'][name]
        assert audit_path and audit_path in ready['evidence_sha256']
        audit = read(audit_path)
        assert audit['targetName'] == name and audit['sourceName'] == proof_rows[name]['sourceName']
        assert audit['sourceOracleJob'] == oracle['job_id']
        for flag in AUDIT_FLAGS:
            assert audit[flag] is True, (name, 'Missing actual audit acceptance', flag)
        for flag in NO_SORRY_FLAGS:
            assert audit[flag] is False, (name, 'Sorry closure not excluded', flag)
        for key in ['nativeAxioms', 'solutionAxioms', 'registeredDependencyAxioms']:
            assert set(audit[key]) <= {'propext', 'Classical.choice', 'Quot.sound'}
        proof = proof_rows[name]
        assert audit['sourceProofSha256'] == proof['sourceProofSha256']
        solution = (W / verification['source']).read_bytes()
        a, b = proof['solutionProofByteRange']
        assert hashlib.sha256(solution[a:b]).hexdigest() == proof['sourceProofSha256']
        a, b = proof['solutionSignatureByteRange']
        assert hashlib.sha256(solution[a:b]).hexdigest() == proof['signatureSha256']
    assert set(ready['shared_required_inputs']) == {'production_checks', 'import_audit',
        'git_diff_check', 'existing_private_mission'}
    assert all(path and path in ready['evidence_sha256'] for path in ready['shared_required_inputs'].values())
    for relative, staged in packet['staged_sources'].items():
        assert (W / relative).read_bytes() == Path(staged).read_bytes(), ('Installed upload source differs', relative)
    return BASE_PREFLIGHT(packet_path, ready_path)


old.preflight = preflight


def deliver(packet_path, ready_path, directory):
    """Explicit root-only network entry, using the existing mutation journal discipline."""
    result = old.deliver(packet_path, ready_path, directory)
    packet = read(packet_path)
    for row in packet['publications']:
        item = read(Path(directory) / (row['tag'] + '-published-item.json'))
        for key in ['theorem_name', 'theorem_title', 'preamble', 'formal_statement',
                    'natural_language_statement', 'source']:
            assert item[key] == row['payload'][key], ('Exact readback differs', row['tag'], key)
    save(Path(directory) / 'pure-two-exact-readback.json', {'passed': True,
        'published_theorems': NAMES, 'frozen_languages_preserved': True,
        'verification': 'ACCEPTED', 'canonicalC22Connected': False})
    return result
