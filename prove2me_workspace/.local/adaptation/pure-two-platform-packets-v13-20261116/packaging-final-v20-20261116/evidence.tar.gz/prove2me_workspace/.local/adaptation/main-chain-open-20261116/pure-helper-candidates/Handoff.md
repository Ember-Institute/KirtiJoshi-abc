三个 4.33 原生候选已在 `Theorems/`，精确目标名称分别为 `AbcAdaptation.Reference.Iut.p5_height_bound`、`AbcAdaptation.Reference.Iut.log_ell_bound` 和 `AbcAdaptation.Reference.Iut.epsilonE_le`。每个独立叶文件保留完整原始声明，包括所有隐式参数、未使用参数、全部界条件和原证明体；只增加外层 `AbcAdaptation.Reference` 命名空间并把原工程导入缩小为明确 Mathlib 模块、已接受 NumericInputs Definition 和实际直接子定理。

原始命令、原 metadata、声明草稿和证据分别见 `OriginalCommands/`、`source-metadata/`、`StatementStubs/`、`source-proof-byte-evidence.json`。原源头是 `Iut.Implication.Corollary22` 的 accepted source AST `ci-014817-8a1bb50d`，规范化坐标 SHA 为 `ee2936fcf7c4d85f0e776fc0ce7e96dbdad7cfc2cf6261759358bb6d24af4909`。三个原命令文件等于相应 AST command range 加末尾一个换行。原 proof/value 半开字节段及对应原生位置均已记录；`p5`、`log_ell`、`epsilonE` 证明 SHA 逐项匹配原 metadata。没有通过 regex 生成签名或切分证明。

三个实际类型保持：

- `p5_height_bound` 的六个实数参数 B,δ,h,r,s,lg 与九个条件全部保留，包含原声明虽未使用的 `_hr0 : 0≤r`。结论仍为 `h≤(B+11+2δ)^4`。
- `log_ell_bound` 保留 δ,h,ℓ,s，条件为 δ≥1、h≥1、ℓ≥1、ℓ≤20δ²h² 和 log(h)≤4s，结论为 log(ℓ)≤3+2δ+8s。没有额外假定 s 为平方根。
- `epsilonE_le` 保留 δ≥1、ε>0、原四次方阈值和 h≥1，结论仍为原 NumericInputs 中 total `epsilonE δ h≤ε`。

实际源 DAG 和消费者见 `consumer-ledger.json`：p5 无项目子依赖；log_ell 仅复用 `Iut.log_le_self_of_pos`；epsilonE 复用 NumericInputs 中的 `Iut.epsilonE` 及两项实际注册 helper `log_le_self_of_pos`、`log_le_four_mul_sqrt_sqrt`。图中两个 `epsilonE._proof_*` 是 Definition 自带辅助证明，随真实 Definition 进入，不制造额外假设或独立数学子节点。这三项都由 `Iut.Corollary22Inputs.c2` 的原 proof/value 实际消费；三项之间没有新交叉边。

两项注册 helper 的 saved 平台状态为 Proved / ACCEPTED，IDs 和 submission IDs 已录入 ledger。主区相应 `Theorems` 文件仍是本地 statement stub，故导入它们时本地传递 `sorryAx` 是明确待审边界；候选自己没有 sorry。没有将这些 stub 冒称为本地闭合证明，也没有私自替它们重新写一份新证明来隐藏 DAG。Root 的平台/本地检查须区分来源 proof body、子节点复用和最终公理闭包。

`imports.json` 逐项记录实际导入路径和 SHA。所有数学基础导入都是锁定的精确 Mathlib 模块；项目导入只有上述 Definition 和源 DAG 的直接子节点。无 `Iut.*`、`Genl.*`、生产 Act1/Act2、`AbcSourceOracle.*`、原 Corollary22 全模块或任何本节点 own-goal import。没有把原源完整模块用作目标证明 oracle。

`native-api-review.json` 是静态 Mathlib 源检查：幂次不等式、乘法消去、log/exp/sqrt API 的已见名字和签名与原 proof 用法相符，尚无实测 native API 失败。由于禁止编译，tactic elaboration、精确最小导入可用性和实际 native 证明通过均保持 pending。没有为可能兼容性问题预先改证明，更没有改变类型、提高 heartbeat 或补充假设。

`formal-only/` 只含三个去注释后的完整候选代码、两个真实直接子定理的现有 statement stub 和已有 NumericInputs Definition。它不含论文来源解释、Handoff 或旧读回答案。冻结 Reader B `/tmp/p2m-main-proof-blind-b-v9-20261116/readback-en.json` 原样未动，仅在 `frozen-readback-reference.json` 保存只读哈希引用；本次不冒称独立盲读。

`module-plan.json` 是主智能体集成和 MCP-CI 的最小模块计划。三个新叶首次检查按项目约定使用 60s/16GiB，由 root 单独提交。后续原始语义来源事实应使用已经准备好的独立 OracleSourceProbes/OracleConfigs，路径及原哈希在证据中保留；目前 metadata 的真实 proof-command semantic oracle 仍标 pending，不能把 AST 字节匹配扩大为 source/target kernel identity。Root 应先运行原生叶检查，必要时只对报告的真实 native API 失败作局部来源保持修复，再进行对应 Checks/Axioms/ImportAudit、聚合和身份核验。

产物只写入本目录；没有运行 Lean/Lake/CI/API/Git，没有修改主区或冻结读回。状态是 source-proof candidates prepared，尚无编译、数学父义务完成或平台发布声明。
