"""Create only this task's offline two-helper packet. No API, CI, Git, or W writes."""
from pathlib import Path
import hashlib
import json
import shutil

W = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
OUT = Path('/tmp/p2m-pure-two-platform-packets-v13-20261116')
NATIVE = Path('/tmp/p2m-pure-next-two-native-v12-20261116')
UNIT = W / '.local/adaptation/main-chain-open-20261116'
RB = UNIT / 'independent-readbacks-v9'
TYPE_FACTS = W / '.local/adaptation/main-pure-type-identity-20261116/original-type-facts.json'
PROTOCOL = W / '.local/adaptation/main-c22-numeric-reference-split-20261115/delivery.py'
ENV = '0df444a360eaa60ab8c11dca51a86af692955474'
SHORT = ['log_ell_bound', 'epsilonE_le']
NAMES = ['AbcAdaptation.Reference.Iut.' + name for name in SHORT]
TITLES = [
    'A scalar logarithmic bound for the Corollary 2.2 argument — 推论 2.2 论证中的标量对数界 — 系2.2の議論におけるスカラーの対数評価',
    'A scalar bound for epsilonE at large height — 大高度下 epsilonE 的标量界 — 高さが十分大きい場合の epsilonE のスカラー評価',
]
GATES = {'new_leaf_modules', 'checks_axioms', 'import_audit', 'act1scene1',
    'axiom_audit', 'wrapped_kernel_type_identity', 'independent_readbacks',
    'source_ledger_consumers', 'git_diff_check', 'existing_mission_scope',
    'source_proof_oracle', 'original_proof_identity', 'native_stub_solution_binder_identity',
    'closed_dependency_closure'}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def prepare():
    native_manifest = read(NATIVE / 'manifest.json')
    translated = read(RB / 'trilingual-b.json')
    english = read(RB / 'readback-b-en.json')
    assert sha(RB / 'readback-b-en.json') == translated['frozen_english_source']['sha256']
    by_name = {row['sourceName']: row for row in translated['nodes']}
    original_by_name = {row['sourceName']: row for row in english['nodes']}
    registry = read(W / '.local/adaptation/platform-node-registry.json')
    registered = {row['name']: row for row in registry['reference_source_preparation']['proved_nodes']}
    proof_rows, publications, verification, sources, staged, frozen, contexts = [], [], [], {}, {}, {}, {}
    metadata = [RB / 'trilingual-b.json', RB / 'readback-b-en.json', TYPE_FACTS,
        NATIVE / 'manifest.json', PROTOCOL, Path(__file__), OUT / 'publisher.py']
    dependencies = {}
    repository = W.parent / 'refer/iut/Iut/Implication/Corollary22.lean'
    repository_bytes = repository.read_bytes()
    notice = (NATIVE / 'Theorems/Thm_AbcAdaptation_Reference_Iut_log_ell_bound.lean').read_text().split('/- Namespace adaptation')[0]
    for short, name, title in zip(SHORT, NAMES, TITLES):
        native = next(row for row in native_manifest['targets'] if row['name'] == name)
        native_path = Path(native['draft'])
        raw = native_path.read_bytes()
        assert sha(native_path) == native['sha256']
        native_name = ('lemma ' + short).encode()
        name_end = raw.index(native_name) + len(native_name)
        pa, pb = native['nativeProofRange']
        signature, body = raw[name_end:pa], raw[pa:pb]
        assert signature.startswith(b' ') and signature.endswith(b' ')
        assert hashlib.sha256(body).hexdigest() == native['proofSha256']
        assert body.startswith(b':= by') and b'sorry' not in body.split()
        imports = [line for line in raw.decode().splitlines() if line.startswith('import ')]
        assert all(line.startswith(('import Mathlib.', 'import Theorems.', 'import Definitions.')) for line in imports)
        expected_project = ['import Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_self_of_pos']
        if short == 'epsilonE_le':
            expected_project += ['import Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_four_mul_sqrt_sqrt',
                'import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs']
        assert {line for line in imports if not line.startswith('import Mathlib.')} == set(expected_project)
        # Open the existing namespace for unqualified helper/epsilonE references
        # in the copied source body and in the global solution's signature.
        preamble = notice + '\n'.join(imports) + ('\n\nset_option relaxedAutoImplicit false\n'
            'set_option maxSynthPendingDepth 3\nopen Finset Real\n'
            'open AbcAdaptation.Reference.Iut\n\n')
        formal = 'theorem ' + name + signature.decode() + ':= by sorry'
        prefix = preamble.encode() + b'theorem solution' + signature
        solution = prefix + body + b'\n'
        stub = (preamble + formal + '\n').encode()
        theorem_rel = 'Theorems/Thm_' + name.replace('.', '_') + '.lean'
        solution_rel = 'Solutions/Sol_' + name.replace('.', '_') + '.lean'
        for relative, data in [(theorem_rel, stub), (solution_rel, solution)]:
            path = OUT / 'staging' / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            sources[relative] = hashlib.sha256(data).hexdigest()
            staged[relative] = str(path)
        rb = by_name['Iut.' + short]
        original_rb = original_by_name['Iut.' + short]
        assert rb['sourceOpen'] is True
        assert rb['readbacks']['en'] == rb['originalEnglish'] == rb['readback'] == original_rb['readback']
        assert hashlib.sha256(rb['readbacks']['en'].encode()).hexdigest() == rb['english_readback_utf8_sha256']
        assert sha(rb['formalOnly']['path']) == rb['formalOnly']['sha256']
        assert rb['binder_analysis']['instance'] == []
        assert len(rb['binder_analysis']['implicit']) == (4 if short == 'log_ell_bound' else 3)
        assert len(rb['binder_analysis']['explicit']) == (5 if short == 'log_ell_bound' else 4)
        frozen[name] = rb
        trilingual = '\n\n'.join('**' + title + '**\n\n' + rb['readbacks'][lang]
            for lang, title in [('en', 'English'), ('zh_Hans', '简体中文'), ('ja', '日本語')])
        status = ('The independent readback above describes the frozen formal-only statement stub, '
            'whose explicit sorry and original proof-status sentences are preserved. It does not describe '
            'the separately supplied complete reference proof. The native candidate and the global solution '
            'copy that complete proof body without edits. Actual source/native/stub/solution compiled-type '
            'and BinderInfo correspondence, native compilation, and recursive axiom closure are separate '
            'root-supplied gates. In particular, a platform-accepted child theorem does not establish that '
            'the installed local child module is free of transitive sorryAx.')
        context = ('This is a conditional real-number inequality used in the reference '
            'Iut.Corollary22Inputs.c2 proof. ' + (
            'It converts the scalar upper bound on ell into a logarithmic upper bound. Ell remains '
            'an arbitrary real parameter, and the theorem does not construct a prime or a geometric object.'
            if short == 'log_ell_bound' else
            'It bounds the explicitly defined scalar function epsilonE under the displayed fourth-power '
            'lower bound on h. It does not supply number-field, curve, local-height, or initial theta data.') +
            ' The exact Lean source command is cited below. The scalar lemma and its constants are '
            'reference Lean implementation details; no claim is made that this formula is a verbatim paper theorem. '
            'This detached source-consumer preparation does not connect canonical Corollary 2.2 or close S2-04.')
        proof_explanation = (
            'Monotonicity of the logarithm gives log(ell) ≤ log(20 delta² h²). '
            'The product and power identities expand this as log(20) + 2 log(delta) + 2 log(h). '
            'The estimate exp(3) > 20 gives log(20) ≤ 3. Since delta ≥ 1, '
            'log(delta) ≤ delta, and the hypothesis gives log(h) ≤ 4s. '
            'Combining these three bounds proves log(ell) ≤ 3 + 2 delta + 8s.'
            if short == 'log_ell_bound' else
            'Put s = sqrt(sqrt(h)) and M = (60 delta)²(2 delta + 4)/epsilon. '
            'The assumptions give s ≥ 1, M ≥ 0, and M⁴ ≤ h = s⁴, hence M ≤ s. '
            'The logarithm bounds give log(2 delta h) ≤ 2 delta + 4s ≤ (2 delta + 4)s. '
            'Therefore the numerator of epsilonE is at most '
            '(60 delta)²(2 delta + 4)s = epsilon M s ≤ epsilon s². '
            'Its denominator is sqrt(h) = s² > 0, which proves epsilonE ≤ epsilon.')
        contexts[name] = status + '\n\n' + context + '\n\n**Reference proof argument**\n\n' + proof_explanation
        original = NATIVE / 'evidence/originals' / ('Iut_' + short + '.lean')
        command = original.read_bytes().rstrip(b'\n')
        assert repository_bytes.count(command) == 1
        start = repository_bytes.index(command)
        first = repository_bytes[:start].count(b'\n') + 1
        last = repository_bytes[:start + len(command)].count(b'\n') + 1
        source_url = ('https://github.com/lana-agents/iut/blob/07cb1da58f6d428a670dbb5dd6093d428bcbcdd8/'
            'Iut/Implication/Corollary22.lean#L' + str(first) + '-L' + str(last))
        copied_original = OUT / 'source-evidence' / original.name
        copied_original.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original, copied_original)
        payload = {'theorem_name': name, 'theorem_title': title, 'preamble': preamble,
            'formal_statement': formal,
            'natural_language_statement': '**Independent formal-code readback (frozen statement-stub input)**\n\n' + trilingual +
                '\n\n**Implementation and proof-status context (separate from frozen readback)**\n\n' + status +
                '\n\n**Reference source context (English)**\n\n' + context +
                '\n\n**Reference proof argument**\n\n' + proof_explanation,
            'source': source_url, 'env': ENV, 'private': True}
        tag = name.replace('.', '_')
        save(OUT / 'payloads' / (tag + '.json'), payload)
        publications.append({'tag': tag, 'endpoint': '/submit-problem', 'payload': payload})
        verification.append({'tag': tag, 'theorem_name': name, 'source': solution_rel})
        child_names = ['AbcAdaptation.Reference.Iut.log_le_self_of_pos']
        if short == 'epsilonE_le':
            child_names.append('AbcAdaptation.Reference.Iut.log_le_four_mul_sqrt_sqrt')
        children = []
        for child in child_names:
            child_record = registered[child]
            assert child_record['status'] == 'Proved' and child_record['verification_status'] == 'ACCEPTED'
            restored = next(row for row in native_manifest['restoredDependencies'] if row['name'] == child)
            assert restored['theorem_id'] == child_record['theorem_id']
            children.append(child_record)
            dependencies[child] = {'registered': child_record, 'expectedRestoredNative': restored,
                'installedRecursiveAxiomAcceptance': False}
        row = {'sourceName': 'Iut.' + short, 'targetName': name, 'nativeCandidate': str(native_path),
            'nativeCandidateSha256': sha(native_path), 'sourceProofSha256': native['proofSha256'],
            'signatureSha256': hashlib.sha256(signature).hexdigest(),
            'nativeSignatureByteRange': [name_end, pa], 'nativeProofByteRange': [pa, pb],
            'solutionSignatureByteRange': [len(preamble.encode() + b'theorem solution'), len(prefix)],
            'solutionProofByteRange': [len(prefix), len(prefix) + len(body)],
            'originalCommand': {'path': str(copied_original), 'sha256': sha(copied_original)},
            'repositoryCommand': {'path': str(repository), 'matchedByteRange': [start, start + len(command)],
                'matchedLines': [first, last], 'url': source_url},
            'sourceProofOracleReceipt': None, 'sourceProofOracleAccepted': False,
            'sourceOriginalTypeFacts': str(TYPE_FACTS), 'actualConsumer': 'Iut.Corollary22Inputs.c2',
            'registeredChildren': children, 'sourceOpen': True,
            'sourceOpenAppliesTo': 'frozen independent formal-only stub; not the separate complete source proof',
            'sourceNativeStubSolutionCompiledIdentityAccepted': False,
            'transitiveSorryClosureAccepted': False, 'proofBytesPreserved': True}
        proof_rows.append(row)
        metadata.extend([native_path, copied_original, Path(rb['formalOnly']['path']),
            UNIT / 'tools/generated/metadata' / ('Iut_' + short + '.json')])
    shutil.copyfile(W / '.local/adaptation/reference-extraction-20261115/LICENSE.iut.Apache-2.0', OUT / 'LICENSE.iut.Apache-2.0')
    save(OUT / 'frozen-readbacks.json', frozen)
    save(OUT / 'source-proof-evidence.json', {'schema': 'pure-two-proof-byte-evidence/v1', 'nodes': proof_rows})
    save(OUT / 'registered-dependencies.json', {'nodes': dependencies,
        'numericInputs': {'module': 'Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs',
            'definitionId': '0aa4ddf2-14e3-4664-a493-269006776830', 'requiredDeclaration': 'AbcAdaptation.Reference.Iut.epsilonE'},
        'installedRecursiveClosureAccepted': False})
    metadata.extend(OUT / filename for filename in ['frozen-readbacks.json', 'source-proof-evidence.json',
        'registered-dependencies.json', 'LICENSE.iut.Apache-2.0'])
    packet = {'schema': 'pure-two-private-theorem-proof-packet/v1', 'workspace': str(W),
        'mission_id': 'eeb5193f-68c0-41d0-9263-4a5ff7c801ee', 'root_id': 'e33ff731-60a7-43ef-87ae-c12aeba23cb5',
        'environment': ENV, 'scope': 'detached-source-consumer-preparation-for-existing-private-mission',
        'root_graph_membership': False, 'canonicalC22Connected': False,
        'mathematical_scope': 'Two conditional scalar real inequalities used by source Corollary22Inputs.c2.',
        'publications': publications, 'verification': verification, 'source_sha256': sources,
        'staged_sources': staged, 'metadata_sha256': {str(path): sha(path) for path in metadata},
        'sourceOracleJobs': {name: None for name in NAMES}, 'frozenReadbacks': frozen,
        'explanations': {name: '\n\n'.join('**' + title + '**\n\n' + frozen[name]['readbacks'][lang]
            for lang, title in [('en', 'English'), ('zh_Hans', '简体中文'), ('ja', '日本語')]) +
            '\n\n' + contexts[name] for name in NAMES}, 'allGatesAccepted': False}
    save(OUT / 'packet.json', packet)
    required = ['native_leaf', 'native_artifact', 'stub_leaf', 'stub_artifact', 'solution_leaf',
        'solution_artifact', 'source_proof_oracle', 'source_native_stub_solution_kernel_audit',
        'recursive_axiom_audit', 'registered_dependency_closure_audit']
    ready = {'passed': False, 'packet_sha256': sha(OUT / 'packet.json'), 'source_sha256': sources,
        'gates': {gate: False for gate in sorted(GATES)}, 'ci_receipts': [],
        'evidence_sha256': packet['metadata_sha256'].copy(), 'explanations': packet['explanations'],
        'kernel_audits': {name: None for name in NAMES},
        'source_oracle_receipts': {name: None for name in NAMES},
        'dependency_source_sha256': {},
        'required_inputs': {name: {key: None for key in required} for name in NAMES},
        'shared_required_inputs': {'production_checks': None, 'import_audit': None,
            'git_diff_check': None, 'existing_private_mission': None},
        'note': 'All gates deliberately false. Root must supply actual four-role compiled types and BinderInfo, proof-source identity, and native/global-solution recursive standard-axiom closure. Existing original type facts and accepted child registry entries do not set these gates.'}
    save(OUT / 'ready.template.json', ready)
    return packet


if __name__ == '__main__':
    packet = prepare()
    print(json.dumps({'prepared': NAMES, 'APIInvoked': False, 'allGatesAccepted': packet['allGatesAccepted']}))
