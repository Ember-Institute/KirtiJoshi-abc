/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22_NumericInputs
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.Real.Sqrt
import Mathlib.Algebra.Order.GroupWithZero.Basic
import Mathlib.Data.Finset.Defs
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring
import Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_self_of_pos
import Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_four_mul_sqrt_sqrt

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open Finset Real
open AbcAdaptation.Reference.Iut

theorem AbcAdaptation.Reference.Iut.epsilonE_le {δ h ε : ℝ} (hδ : 1 ≤ δ) (hε : 0 < ε)
    (hh : ((60 * δ) ^ 2 * (2 * δ + 4) / ε) ^ 4 ≤ h) (hh1 : 1 ≤ h) :
    epsilonE δ h ≤ ε := by sorry
