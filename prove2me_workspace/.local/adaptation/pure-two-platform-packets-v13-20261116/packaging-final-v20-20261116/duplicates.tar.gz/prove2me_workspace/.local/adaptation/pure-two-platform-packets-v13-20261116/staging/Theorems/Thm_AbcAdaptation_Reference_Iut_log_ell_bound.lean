/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Data.Finset.Defs
import Mathlib.Algebra.Order.GroupWithZero.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Theorems.Thm_AbcAdaptation_Reference_Iut_log_le_self_of_pos

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open Finset Real
open AbcAdaptation.Reference.Iut

theorem AbcAdaptation.Reference.Iut.log_ell_bound {δ h ℓ s : ℝ} (hδ : 1 ≤ δ) (hh1 : 1 ≤ h) (hℓ : 1 ≤ ℓ)
    (hℓup : ℓ ≤ 20 * δ ^ 2 * h ^ 2) (hlogh : Real.log h ≤ 4 * s) :
    Real.log ℓ ≤ 3 + 2 * δ + 8 * s := by sorry
