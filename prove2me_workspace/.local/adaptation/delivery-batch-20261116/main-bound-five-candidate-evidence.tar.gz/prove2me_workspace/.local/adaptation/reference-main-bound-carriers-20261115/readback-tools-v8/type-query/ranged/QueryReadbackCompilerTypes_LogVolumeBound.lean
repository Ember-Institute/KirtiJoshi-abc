import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.capsuleBound
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.casesOn
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.cont
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.cont_eq_integral
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.cont_mem_hullRegions
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.dstPlaces
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.mk
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.noConfusion
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.packetVol_mono
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.rec
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.recOn
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.thetaPilot_subset
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.vol_finite
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.vol_infinite
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.mk.noConfusion
