Five target drafts are ready for main-agent MCP-CI checks and independent readback.
All artifacts use candidate status. The parent formal correspondence remains pending.
No compiler, CI, API, network, Git command, or main-workspace write ran in this task.
No independent readback answer was written.

Install only candidate_parent.py and prepare_candidate_wrappers.py into a new candidate-tools directory.
Keep the existing bind_parent.py, parent_binding.py, wrapper scripts, and publication entry unchanged.
The entry generates a private copy of the existing wrapper script.
candidate-draft/candidate-wrapper-generator.diff records its complete delta.
The delta changes candidate dependency handling, schema, status, counts, output names, and false gates.
The original make_wrapper, blind_packet, source oracle checks, command checks, and proof byte checks remain identical.

Run this offline Python entry after installation:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 "$TOOLS/prepare_candidate_wrappers.py" \
  --base "$BNEXT" --parent "$BINITIAL" --out "$TOOLS/candidate-draft"
```

Set TOOLS to the new candidate-tools directory.
Set BNEXT to reference-main-bound-carriers-20261115.
Set BINITIAL to reference-initial-theta-carriers-20261115.
Use absolute paths for all three variables.
The output must stay below TOOLS.
Use a new candidate directory when installing into BNEXT.
The script reads accepted source artifacts from BNEXT and writes only below its output directory.
It does not call the strict parent binder.

The current draft is candidate-draft/generated-wrapped/Definitions/.
The five files retain canonical Definitions module names.
The source and target artifact paths in reports currently refer to this task directory.
Regenerate after moving tools, or record exact copied source paths and SHA values for MCP-CI inputs.
Do not convert these candidate schemas into accepted correspondence evidence.

The candidate parent report contains exactly 200 named candidates and four genuine source proof metadata records.
It keeps the required parent partition as 73 named candidates plus all four genuine proof values.
The four proof values have standaloneTargetIdentity=null and receive no named aliases.
The metadata matches exact records in the accepted original Expr artifact at recorded byte spans.
The 200 pairs use the actual compiler target Names and owners from the existing target query.
The existing two generated proof-name shifts remain explicit.
These Name facts do not establish kernel equality or formal acceptance.

The existing strict dependency verifier still checks the 415 previously accepted names and 19 modules.
The candidate adapter adds 200 draft names and four draft modules.
The resulting draft map therefore contains 615 dependency names and 23 dependency modules.
The report counts only the 415 old names as actual accepted named dependencies.
All 200 parent entries use mappingRole=prior-candidate-only.
The map schema is main-bound-candidate-typed-name-module-map-v1.
The wrapper report schema is main-bound-candidate-wrapper-generation-v1.
The ordinary strict binder still refuses the pending parent.

Generation preserves all 197 original metadata records, 173 selected records, and 27 complete selected AST commands.
It reuses all five accepted source InfoTree oracles and all actual project references.
It checks 20 proof and definition body ranges against original bytes.
It retains original source notices, adaptation provenance, and the exact owner-path Mathlib import candidates.
It imports no monolithic Mathlib module.
offline-validation.json pins the unchanged paper context with 18 quotations and five bundles.
LICENSE.Apache-2.0 copies the actual original repository license.
Each generated bundle also contains the original copyright and license notice.

candidate-draft/candidate-generation-summary.json records the input and output identities.
candidate-draft/candidate-parent-report.json keeps the full candidate parent partition.
candidate-draft/generated-wrapped/candidate-wrapper-report.json records commands, proof ranges, imports, provenance, and blind packets.
candidate-draft/generated-wrapped/candidate-typed-original-source-wrapped-map.json records typed Name candidates.
candidate-draft/generated-wrapped/blind/ contains code packets for independent readback.
candidate-draft/generated-wrapped/payloads/ contains draft definition payloads.
Their presence does not authorize publication.
All finalAcceptance, publishAllowed, and parentFormalAccepted gates remain false.
Each bundle also keeps all four formalAcceptance flags false.

Main must submit the actual target leaves through MCP-CI and collect actual compiler evidence.
Main can start independent readback from the generated code and actual compiler types.
The eventual formal flow still requires the real parent accepted map and all existing mathematical checks.
This draft does not complete any mathematical parent obligation or publish a platform record.

Entry SHA256: d2eece9e6251f96985b32b093e98ea061c35c60b1f2664c9962cccfb5ab8db55
Parent adapter SHA256: 22423b48dbcb1bd68962b83adace8112844523d712e950c2190d756c3e2327e9
Generation summary SHA256: 0f6255fd88a5317bcb7916e6d85886f508303794bd6cc33d24d9ded3f74363c8
delivery-manifest.json lists the exact SHA256 for every delivered artifact except itself.

Definition SHA256 values:

- LeftHandSide: a0e53b47303140a6522725aab92acbd8f1c9679ac1da98e37b24ad31c24ae0ca
- RightHandSide: 0f760d8e8c8f68b554843f042fcaa6f26cf983d5d43b755cc7b431be15f1ba8c
- Statement: 124b1cde92438a098ba1216f32e67e5911f2bdc992acae39fb4ae9434205cc81
- Invariants: 15eee5caef269c603f28c72440970f63cea4a513752353bd483684deed3b7ced
- LogVolumeBound: 56a5ef14ddd38021ee0db99f3c22cb00612f86deb921faf9f8566c28b23683ee
