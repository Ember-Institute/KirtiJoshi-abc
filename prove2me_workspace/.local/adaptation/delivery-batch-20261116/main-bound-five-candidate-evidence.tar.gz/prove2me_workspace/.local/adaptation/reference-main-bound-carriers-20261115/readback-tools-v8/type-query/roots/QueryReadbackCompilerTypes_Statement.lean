import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.Corollary312Variant
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData
