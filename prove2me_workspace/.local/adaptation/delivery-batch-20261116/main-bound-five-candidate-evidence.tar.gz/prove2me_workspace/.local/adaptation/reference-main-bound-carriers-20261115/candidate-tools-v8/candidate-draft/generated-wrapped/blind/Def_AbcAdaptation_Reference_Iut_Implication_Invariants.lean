import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Mathlib.Algebra.Algebra.Defs
import Mathlib.Algebra.Algebra.Rat
import Mathlib.Algebra.BigOperators.Group.Finset.Defs
import Mathlib.Algebra.CharZero.Defs
import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Field.Rat
import Mathlib.Algebra.Field.Subfield.Defs
import Mathlib.Algebra.Group.Action.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Submonoid.Defs
import Mathlib.Algebra.GroupWithZero.Action.Defs
import Mathlib.Algebra.Module.Defs
import Mathlib.Algebra.Module.Rat
import Mathlib.Algebra.Order.Archimedean.Real.Basic
import Mathlib.Algebra.Order.Floor.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Algebra.Ring.Rat
import Mathlib.Algebra.Ring.Subring.Defs
import Mathlib.Algebra.Ring.Subsemiring.Defs
import Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Finset.Attach
import Mathlib.Data.Finset.Defs
import Mathlib.Data.Finset.Filter
import Mathlib.Data.Int.Cast.Defs
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Data.Nat.Init
import Mathlib.Data.Nat.Prime.Defs
import Mathlib.Data.Rat.Defs
import Mathlib.Data.Real.Basic
import Mathlib.Data.Set.Defs
import Mathlib.Data.SetLike.Basic
import Mathlib.FieldTheory.IntermediateField.Basic
import Mathlib.LinearAlgebra.Dimension.Finrank
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace
import Mathlib.NumberTheory.PrimeCounting

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference

set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3



namespace Iut

universe u v

open NumberField


structure PrimeCountingBound where
  
  η : ℝ
  
  one_lt_η : 1 < η
  
  bound : ∀ x : ℝ, η ≤ x → (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤ 3 * x / (2 * Real.log x)

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}


structure Theorem110Invariants (X : Corollary312VariantData.{u, v} AG TG) :
    Type where
  
  emod : ℕ
  
  one_le_emod : 1 ≤ emod
  
  emod_le_dmod : emod ≤ Module.finrank ℚ ↥(fieldOfModuli X.data.F X.data.E)
  
  logDtpd : ℝ
  
  logDtpd_nonneg : 0 ≤ logDtpd
  
  logFtpd : ℝ
  
  logFtpd_nonneg : 0 ≤ logFtpd
  
  dst : Finset ℕ
  
  dst_prime : ∀ p ∈ dst, p.Prime
  
  logDK : ℕ → ℝ
  
  logDK_nonneg : ∀ p, 0 ≤ logDK p
  
  logDK_eq_zero : ∀ p, p ∉ dst → logDK p = 0

namespace Corollary312VariantData

variable (X : Corollary312VariantData.{u, v} AG TG)


abbrev ℓ : ℕ := X.data.ℓ


abbrev lstar : ℕ := (X.data.ℓ - 1) / 2


noncomputable abbrev dmod : ℕ := Module.finrank ℚ ↥(fieldOfModuli X.data.F X.data.E)


noncomputable def logQAt (p : ℕ) : ℝ :=
  ∑ w ∈ X.qPilot.badFinset.attach.filter (fun w => residueChar w.1 = p),
    X.qPilot.weight w.1 * (X.data.prime.qOrder w.1 (X.qPilot.mem_bad w.2) : ℝ) *
      Real.log (residueChar w.1)

end Corollary312VariantData

namespace Theorem110Invariants

variable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)


abbrev eStar : ℕ := 552960 * inv.emod


noncomputable def lmod : ℝ := Real.log ((inv.eStar : ℝ) * X.ℓ)


noncomputable def ι (p : ℕ) : ℝ := if p ≤ inv.eStar * X.ℓ then 1 else 0


noncomputable def logSQ : ℝ := ∑ p ∈ inv.dst, Real.log p


noncomputable def logSle : ℝ := ∑ p ∈ inv.dst, inv.ι p


noncomputable def logDKtot : ℝ := ∑ p ∈ inv.dst, inv.logDK p

end Theorem110Invariants


structure Theorem110Certificate {X : Corollary312VariantData.{u, v} AG TG}
    (inv : Theorem110Invariants X) : Prop where
  
  seven_le : 7 ≤ X.ℓ
  
  bad_mem_dst : ∀ w ∈ X.qPilot.badFinset, residueChar w ∈ inv.dst
  
  step_ii : inv.logDKtot ≤ inv.logDtpd + inv.logFtpd + 2 * Real.log X.ℓ + 21
  
  step_iii : inv.logSQ ≤ 2 * X.dmod * (inv.logDtpd + inv.logFtpd) + 5 + Real.log X.ℓ

end Iut

end AbcAdaptation.Reference
