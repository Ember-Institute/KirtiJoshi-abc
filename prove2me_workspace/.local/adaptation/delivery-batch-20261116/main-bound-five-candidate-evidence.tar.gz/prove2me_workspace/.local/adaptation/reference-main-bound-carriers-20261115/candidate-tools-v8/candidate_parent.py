"""Draft-only parent Name candidates. This module never creates acceptance."""
import copy
import hashlib
import json
from pathlib import Path

def load(p):
    return json.loads(Path(p).read_text())

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def pin(p):
    return {'path': str(Path(p).resolve()), 'sha256': sha(p)}

def require(v, message):
    if not v:
        raise ValueError(message)

def build(template, parent):
    """Use the existing formal plan and actual compiler Names, without its verdict."""
    from wrap_carriers import name_text
    unit = load(template)
    slot, = [d for d in unit['dependencies'] if d.get('acceptedCorrespondence', {}).get('unitKind') == 'initial-theta']
    require(slot['status'] == 'pending-current-kernel', 'Expected unresolved formal parent slot')
    partition = slot['expectedRequiredPartitionFromPendingFormalPlan']
    plan_pin = partition['formalPlan']
    require(sha(plan_pin['path']) == plan_pin['sha256'], 'Parent formal plan changed')
    plan = load(plan_pin['path'])
    require(plan['globalAccounting'] == dict(completeSourceRecords=232, selected=204, named=200,
            genuineSourceProofValues=4, actualOwned=201, targetOnly=1), 'Parent exact partition differs')
    leaf = next(r for r in plan['leaves'] if r['slug'] == 'Orbicurve')
    require(sha(leaf['config']) == leaf['configSha256'], 'Parent draft config changed')
    config = load(leaf['config'])
    helpers_pin = config['platformHelperEvidence']['facts']
    require(sha(helpers_pin['path']) == helpers_pin['sha256'], 'Actual target Name query changed')
    helpers = load(helpers_pin['path'])
    owned = {r['name']: r for r in helpers['ownedDeclarations']}
    profile_path = parent / 'original-exprs-size-profile.json'
    profile = load(profile_path)
    selected = {r['name'] for r in profile['records'] if r['selected']}
    typed = load(slot['typedMap'])
    typed_current = {r['originalName']: r for r in typed['constants'] if r['mappingRole'] == 'current-unit'}
    exact_pin = config['exactOriginalProofRecords']
    require(sha(exact_pin['path']) == exact_pin['sha256'], 'Exact original proof record artifact changed')
    exact_export = load(exact_pin['path'])
    exact_records = {r['name']: r for r in exact_export['records']}
    raw_artifact = exact_export['originalArtifact']
    original_acceptance_path = parent / 'original-exprs-acceptance.json'
    original_acceptance = load(original_acceptance_path)
    require(original_acceptance['status'] == 'accepted'
            and original_acceptance['originalExprsSha256'] == raw_artifact['sha256'] == sha(raw_artifact['path']),
            'Genuine proof source is not the accepted raw original export')
    byte_spans = {r['name']: r for r in exact_export['exactOriginalRecordByteSpans']}
    proofs = []
    for r in config['proofValueResolutions']:
        source = r['sourceRecord']
        require(r['original'] in selected and r['standaloneTargetIdentity'] is None
                and source['valueExpr'] is not None and name_text(r['originalName']) == r['original'],
                'Genuine source proof value missing or has an invented target identity')
        exact = exact_records[r['original']]
        require(source == exact, 'Proof metadata is not the exact original exported record')
        byte_span = byte_spans[r['original']]
        with Path(raw_artifact['path']).open('rb') as raw:
            raw.seek(byte_span['start'])
            token = raw.read(byte_span['end'] - byte_span['start'])
        require(hashlib.sha256(token).hexdigest() == byte_span['sha256'] and json.loads(token) == source,
                'Proof metadata differs from actual raw original record bytes')
        proofs.append({'original': r['original'], 'originalName': r['originalName'],
            'sourceOwner': typed_current[r['original']]['originalModule'],
            'standaloneTargetIdentity': None, 'parentOriginal': r['parentOriginal'],
            'status': 'genuine-source-proof-metadata-only-parent-formal-audit-pending',
            'sourceRecordReference': {**pin(leaf['config']), 'collection': 'proofValueResolutions',
                'matchOriginal': r['original'], 'field': 'sourceRecord'},
            'sourceRecordCanonicalJsonSha256': hashlib.sha256(json.dumps(source, sort_keys=True,
                ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()})
    proof_names = {r['original'] for r in proofs}
    pairs = []
    for row in config['projectMap']:
        if row.get('mappingRole') != 'current-unit' or row['original'] not in selected:
            continue
        require(row['original'] not in proof_names, 'Genuine proof value acquired a named alias')
        target = owned[row['target']]
        source = typed_current[row['original']]
        require(name_text(row['originalName']) == row['original'] and name_text(row['targetName']) == row['target']
                and target['nameExpr'] == row['targetName'] and source['originalNameExpr'] == row['originalName']
                and target['module'] == source['wrappedModule'], 'Actual source/target Name or owner differs')
        pairs.append({'original': row['original'], 'originalName': row['originalName'],
            'target': row['target'], 'targetName': row['targetName'],
            'targetToSourceUniverseIndices': row.get('targetToSourceUniverseIndices'),
            'sourceOwner': source['originalModule'], 'targetOwner': target['module'],
            'status': 'actual-source-and-target-names-candidate-only-kernel-equality-pending'})
    named = {r['original'] for r in pairs}
    required_named = set(partition['namedCandidates']); required_proof = set(partition['genuineProofValueCandidates'])
    require(len(pairs) == len(named) == 200 and len(proofs) == len(proof_names) == 4
            and named | proof_names == selected and not named & proof_names,
            'Parent 200 named +4 genuine source proof partition differs')
    require(len(required_named) == 73 and len(required_proof) == 4 and required_named <= named
            and required_proof == proof_names and set(slot['requiredSourceDisplayNames']) == required_named | required_proof,
            'Required 73 named +4 genuine proof partition differs')
    wrappers_path = parent / 'generated-wrapped/foundation-wrapper-report.json'
    wrappers = load(wrappers_path)
    modules = []
    for b in wrappers['bundles']:
        require(sha(b['path']) == b['sha256'], 'Parent wrapper draft bytes changed')
        modules.append({'originalModule': b['module'], 'wrappedModule': b['wrappedModule'],
            'path': b['path'], 'sha256': b['sha256'], 'status': 'draft-module-parent-formal-audit-pending'})
    require(len(modules) == 4, 'Four parent draft modules required')
    return {'schema': 'main-bound-parent-name-candidates-v1', 'status': 'candidate-only-parent-formal-pending',
        'parentFormalAccepted': False, 'targetKernelAccepted': False, 'finalAcceptance': False, 'publishAllowed': False,
        'namedCandidates': pairs, 'genuineProofMetadata': proofs, 'modules': modules,
        'requiredNamedCandidates': sorted(required_named), 'requiredGenuineProofValues': sorted(required_proof),
        'explicitGeneratedNameShifts': [{k:r[k] for k in ['original','originalName','target','targetName']}
            for r in config['explicitGeneratedNameShifts']],
        'inputs': [pin(p) for p in [template, plan_pin['path'], leaf['config'], helpers_pin['path'],
            profile_path, slot['typedMap'], wrappers_path, exact_pin['path'], original_acceptance_path,
            raw_artifact['path']]]}

def dependency_evidence(unit):
    from carrier_contract import dependency_evidence as strict_dependencies
    old = copy.deepcopy(unit)
    old['dependencies'] = [d for d in old['dependencies']
        if d.get('acceptedCorrespondence', {}).get('unitKind') != 'initial-theta']
    constants, modules, descriptors = strict_dependencies(old)
    require(len(constants) == 415 and len(modules) == 19, 'Actual older dependency accounting differs')
    info = unit['candidateOnlyParent']
    require(sha(info['path']) == info['sha256'], 'Parent candidate report changed')
    parent = load(info['path'])
    require(parent['schema'] == 'main-bound-parent-name-candidates-v1'
            and parent['status'] == 'candidate-only-parent-formal-pending'
            and all(parent[k] is False for k in ['parentFormalAccepted','targetKernelAccepted','finalAcceptance','publishAllowed']),
            'Expected draft-only parent evidence')
    for evidence in parent['inputs']:
        require(sha(evidence['path']) == evidence['sha256'], 'Candidate parent input changed')
    slot, = [d for d in unit['dependencies'] if d.get('acceptedCorrespondence', {}).get('unitKind') == 'initial-theta']
    require(slot['status'] == 'pending-current-kernel', 'Candidate mode cannot promote the formal parent')
    typed = {r['originalName']: r for r in load(slot['typedMap'])['constants']}
    for pair in parent['namedCandidates']:
        row = copy.deepcopy(typed[pair['original']])
        row.update(wrappedName=pair['target'], wrappedNameExpr=pair['targetName'],
            targetToSourceUniverseIndices=pair['targetToSourceUniverseIndices'], mappingRole='prior-candidate-only',
            mappingIdentity='candidate-only-parent-formal-pending', mappingStatus='candidate-only-parent-formal-pending',
            dependencyCandidateEvidence=info)
        require(pair['original'] not in constants, 'Duplicate parent candidate')
        constants[pair['original']] = row
    for row in parent['modules']:
        require(row['originalModule'] not in modules and sha(row['path']) == row['sha256'], 'Parent module duplicate or changed')
        modules[row['originalModule']] = row
    require(len(constants) == 615 and len(modules) == 23, 'Draft dependency accounting differs')
    descriptors.append({'status':'candidate-only-parent-formal-pending', 'candidateEvidence':info,
        'requiredNamedCandidates':parent['requiredNamedCandidates'],
        'requiredGenuineProofValues':parent['requiredGenuineProofValues'],
        'genuineProofMetadata':parent['genuineProofMetadata'], 'finalAcceptance':False, 'publishAllowed':False})
    return constants, modules, descriptors
