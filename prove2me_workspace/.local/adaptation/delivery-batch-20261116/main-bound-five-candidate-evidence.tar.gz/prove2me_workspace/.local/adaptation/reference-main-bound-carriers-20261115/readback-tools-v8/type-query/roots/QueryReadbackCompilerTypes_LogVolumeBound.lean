import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.capsuleBound
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.dstPlaces
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.LocalEstimate.placeBound
