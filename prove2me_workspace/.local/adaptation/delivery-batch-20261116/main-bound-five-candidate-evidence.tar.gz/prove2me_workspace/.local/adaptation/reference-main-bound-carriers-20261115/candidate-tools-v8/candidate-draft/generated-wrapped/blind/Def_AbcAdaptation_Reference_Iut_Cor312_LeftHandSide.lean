import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Mathlib.Algebra.BigOperators.Group.Finset.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Finset.Attach
import Mathlib.Data.Finset.Defs
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Data.Nat.Init
import Mathlib.Data.Real.Basic
import Mathlib.Data.Set.Defs
import Mathlib.Data.SetLike.Basic
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

universe u

open NumberField

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}


structure QPilotData (D : InitialThetaData AG TG) : Type u where
  
  badFinset : Finset (FinitePlace D.F)
  
  badFinset_spec : ↑badFinset = badPlacesOver D.F D.E D.VBad
  
  weight : FinitePlace D.F → ℝ
  
  weight_pos : ∀ w ∈ badFinset, 0 < weight w

namespace QPilotData

variable {D : InitialThetaData AG TG} (Q : QPilotData D)


lemma mem_bad {w : FinitePlace D.F} (hw : w ∈ Q.badFinset) :
    w ∈ badPlacesOver D.F D.E D.VBad :=
  Q.badFinset_spec ▸ Finset.mem_coe.mpr hw


noncomputable def logQ : ℝ :=
  ∑ w ∈ Q.badFinset.attach,
    Q.weight w.1 * (D.prime.qOrder w.1 (Q.mem_bad w.2) : ℝ) *
      Real.log (residueChar w.1)


noncomputable def absLogQ : ℝ := Q.logQ / (2 * (D.ℓ : ℝ))


noncomputable def lhs : ℝ := -Q.absLogQ

end QPilotData

end Iut

end AbcAdaptation.Reference
