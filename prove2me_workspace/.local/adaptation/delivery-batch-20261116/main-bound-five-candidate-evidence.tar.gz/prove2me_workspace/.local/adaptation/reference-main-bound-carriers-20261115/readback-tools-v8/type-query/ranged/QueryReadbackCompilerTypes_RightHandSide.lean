import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RightHandSide
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.RHSData
#check @AbcAdaptation.Reference.Iut.RHSData.casesOn
#check @AbcAdaptation.Reference.Iut.RHSData.container
#check @AbcAdaptation.Reference.Iut.RHSData.hull
#check @AbcAdaptation.Reference.Iut.RHSData.mk
#check @AbcAdaptation.Reference.Iut.RHSData.noConfusion
#check @AbcAdaptation.Reference.Iut.RHSData.proc_standard
#check @AbcAdaptation.Reference.Iut.RHSData.rec
#check @AbcAdaptation.Reference.Iut.RHSData.recOn
#check @AbcAdaptation.Reference.Iut.RHSData.rhs
#check @AbcAdaptation.Reference.Iut.RHSData.thetaHull
#check @AbcAdaptation.Reference.Iut.RHSData.thetaPilot
#check @AbcAdaptation.Reference.Iut.RHSData.thetaPilot_hullAdmissible
#check @AbcAdaptation.Reference.Iut.RHSData.thetaPilot_le_shell
#check @AbcAdaptation.Reference.Iut.RHSData.toRational_finite
#check @AbcAdaptation.Reference.Iut.RHSData.toRational_infinite
#check @AbcAdaptation.Reference.Iut.RHSData.vol
#check @AbcAdaptation.Reference.Iut.RHSData.mk.noConfusion
