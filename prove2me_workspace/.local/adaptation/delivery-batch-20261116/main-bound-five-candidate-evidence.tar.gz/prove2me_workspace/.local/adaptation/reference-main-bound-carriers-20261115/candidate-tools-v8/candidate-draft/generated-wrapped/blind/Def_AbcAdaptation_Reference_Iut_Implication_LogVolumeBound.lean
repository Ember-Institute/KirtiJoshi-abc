import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Container
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ContainerHull
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_HolomorphicHull
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LogVolume
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_PacketPresentation
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RationalPlace
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RightHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Mathlib.Algebra.Group.Defs
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Data.Finset.Attach
import Mathlib.Data.Finset.Defs
import Mathlib.Data.Finset.Image
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Data.Nat.Init
import Mathlib.Data.Nat.Prime.Defs
import Mathlib.Data.Real.Basic
import Mathlib.Data.Set.Defs
import Mathlib.Data.SetLike.Basic
import Mathlib.FieldTheory.IntermediateField.Basic

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference

set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3



namespace Iut

universe u v

open NumberField

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}

namespace Theorem110Invariants

variable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)


noncomputable def capsuleBound (n : ℕ) (p : ℕ) : ℝ :=
  n * inv.logDK p - ((n : ℝ) - 1) ^ 2 / (2 * X.ℓ) * X.logQAt p + Real.log p +
    4 * n * inv.lmod * inv.ι p


structure LocalEstimate : Type (max u v) where
  
  cont : ∀ (i : Fin X.rhsData.container.proc.length) (vQ : RationalPlace),
    Set (X.rhsData.container.packet i vQ).Total
  
  cont_mem_hullRegions : ∀ i vQ, cont i vQ ∈ (X.rhsData.hull.system i vQ).HullRegions
  
  thetaPilot_subset : ∀ i vQ, (X.rhsData.thetaPilot i).region vQ ⊆ cont i vQ
  
  cont_eq_integral : ∀ i (p : Nat.Primes), (p : ℕ) ∉ inv.dst →
    cont i (.finite p) = (X.rhsData.container.packet i (.finite p)).integralRegion
  
  vol_finite : ∀ i (p : Nat.Primes), (p : ℕ) ∈ inv.dst →
    X.rhsData.vol.packetVol i (.finite p) (cont i (.finite p)) ≤
      inv.capsuleBound (X.rhsData.container.proc.capsule i).card p
  
  vol_infinite : ∀ i,
    X.rhsData.vol.packetVol i .infinite (cont i .infinite) ≤
      (X.rhsData.container.proc.capsule i).card * Real.log Real.pi
  
  packetVol_mono : ∀ i vQ (U V : Set (X.rhsData.container.packet i vQ).Total),
    (X.rhsData.container.packet i vQ).IsHullRegion U →
    (X.rhsData.container.packet i vQ).IsHullRegion V → U ⊆ V →
    X.rhsData.vol.packetVol i vQ U ≤ X.rhsData.vol.packetVol i vQ V

namespace LocalEstimate

variable (est : inv.LocalEstimate)


noncomputable def placeBound (n : ℕ) : RationalPlace → ℝ
  | .finite p => if (p : ℕ) ∈ inv.dst then inv.capsuleBound n p else 0
  | .infinite => n * Real.log Real.pi


noncomputable def dstPlaces : Finset RationalPlace :=
  inv.dst.attach.image fun p => RationalPlace.finite ⟨p.1, inv.dst_prime p.1 p.2⟩

variable {inv}

include est

end LocalEstimate

end Theorem110Invariants

end Iut

end AbcAdaptation.Reference
