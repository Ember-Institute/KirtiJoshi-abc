import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.Corollary312Variant
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.casesOn
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.data
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.mk
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.noConfusion
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.qPilot
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.rec
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.recOn
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.rhsData
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.mk.noConfusion
