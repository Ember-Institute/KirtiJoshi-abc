import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Group.Basic
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Equiv.Defs
import Mathlib.Algebra.Group.Hom.Defs
import Mathlib.Algebra.Group.Subgroup.Defs
import Mathlib.Algebra.Group.Subgroup.ZPowers.Basic
import Mathlib.Algebra.Group.Submonoid.Defs
import Mathlib.Algebra.Group.Subsemigroup.Defs
import Mathlib.Algebra.Group.TypeTags.Basic
import Mathlib.Algebra.Group.Units.Defs
import Mathlib.Algebra.Group.WithOne.Defs
import Mathlib.Algebra.GroupWithZero.Defs
import Mathlib.Algebra.Order.GroupWithZero.Canonical
import Mathlib.Algebra.Quotient
import Mathlib.Algebra.Ring.Defs
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Basic
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Point
import Mathlib.AlgebraicGeometry.EllipticCurve.VariableChange
import Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass
import Mathlib.Analysis.Normed.Field.Basic
import Mathlib.Data.FunLike.Basic
import Mathlib.Data.FunLike.Equiv
import Mathlib.Data.Int.Cast.Defs
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Data.Set.Defs
import Mathlib.GroupTheory.Coset.Defs
import Mathlib.GroupTheory.QuotientGroup.Defs
import Mathlib.Logic.Equiv.Defs
import Mathlib.RingTheory.Valuation.RankOne
import Mathlib.Topology.Algebra.Valued.NormedValued
import Mathlib.Topology.Algebra.Valued.ValuationTopology
import Mathlib.Topology.UniformSpace.Cauchy
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Parametrization
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Weierstrass

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut

open WeierstrassCurve TateCurvesTheta

open scoped Classical Valued

universe u

noncomputable section

variable {k : Type u} [Field k] [Valued k (WithZero (Multiplicative ℤ))]
  [Valuation.RankOne (Valued.v : Valuation k (WithZero (Multiplicative ℤ)))] [CompleteSpace k]


def xCoord (C : VariableChange k) : {E : WeierstrassCurve k} → E.toAffine.Point → k
  | _, Affine.Point.zero => 0
  | _, Affine.Point.some x _ _ => (x - C.r) / (C.u : k) ^ 2


def yCoord (C : VariableChange k) : {E : WeierstrassCurve k} → E.toAffine.Point → k
  | _, Affine.Point.zero => 0
  | _, Affine.Point.some x y _ => (y - C.t - C.s * (x - C.r)) / (C.u : k) ^ 3


structure TateStructure (E : WeierstrassCurve k) : Type u where
  
  t : TateParameter k
  
  C : VariableChange k
  
  hC : C • E = t.tateCurve
  
  iso : Additive (kˣ ⧸ Subgroup.zpowers t.q) ≃+ E.toAffine.Point
  
  iso_x : ∀ u : kˣ, (∀ n : ℤ, (t.q : k) ^ n * u ≠ 1) →
    xCoord C (iso (Additive.ofMul (QuotientGroup.mk u))) = t.X u
  
  iso_y : ∀ u : kˣ, (∀ n : ℤ, (t.q : k) ^ n * u ≠ 1) →
    yCoord C (iso (Additive.ofMul (QuotientGroup.mk u))) = t.Y u

namespace TateStructure

variable {E : WeierstrassCurve k} (S : TateStructure E)


def ofUnit (u : kˣ) : E.toAffine.Point := S.iso (Additive.ofMul (QuotientGroup.mk u))

lemma ofUnit_mul (u v : kˣ) : S.ofUnit (u * v) = S.ofUnit u + S.ofUnit v := by
  unfold ofUnit
  rw [← map_add]
  rfl

lemma ofUnit_one : S.ofUnit 1 = 0 := by
  unfold ofUnit
  rw [← map_zero S.iso]
  rfl

lemma ofUnit_inv (u : kˣ) : S.ofUnit u⁻¹ = -S.ofUnit u := by
  rw [eq_neg_iff_add_eq_zero, ← ofUnit_mul, inv_mul_cancel, ofUnit_one]


def graphLine (ℓ : ℕ) : AddSubgroup E.toAffine.Point where
  carrier := {P | ∃ u : kˣ, u ^ ℓ = 1 ∧ S.ofUnit u = P}
  zero_mem' := ⟨1, one_pow ℓ, S.ofUnit_one⟩
  add_mem' := by
    rintro _ _ ⟨u, hu, rfl⟩ ⟨v, hv, rfl⟩
    exact ⟨u * v, by rw [mul_pow, hu, hv, one_mul], S.ofUnit_mul u v⟩
  neg_mem' := by
    rintro _ ⟨u, hu, rfl⟩
    exact ⟨u⁻¹, by rw [inv_pow, hu, inv_one], S.ofUnit_inv u⟩


def IsCanonical (ℓ : ℕ) (P : E.toAffine.Point) : Prop :=
  ∃ u : kˣ, S.ofUnit u = P ∧
    ∃ m : ℤ, u ^ ℓ = S.t.q ^ (1 + ℓ * m) ∨ u ^ ℓ = S.t.q ^ (-1 + ℓ * m)



end TateStructure

end

end Iut

end AbcAdaptation.Reference
