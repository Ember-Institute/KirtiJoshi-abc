import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.PrimeCountingBound
#check @AbcAdaptation.Reference.Iut.Theorem110Certificate
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.dmod
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.logQAt
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.lstar
#check @AbcAdaptation.Reference.Iut.Corollary312VariantData.ℓ
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.eStar
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.lmod
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.logDKtot
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.logSQ
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.logSle
#check @AbcAdaptation.Reference.Iut.Theorem110Invariants.ι
