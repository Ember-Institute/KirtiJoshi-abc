import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RightHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Mathlib.Data.Real.Basic

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference

set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3



namespace Iut

universe u v


structure Corollary312VariantData (AG : AnabelianGeometry.{u})
    (TG : TemperedGeometry AG) : Type (max (u + 1) (v + 1)) where
  
  data : InitialThetaData AG TG
  
  qPilot : QPilotData data
  
  rhsData : RHSData.{u, v} data

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}


noncomputable def Corollary312Variant (X : Corollary312VariantData.{u, v} AG TG) :
    Prop :=
  X.qPilot.lhs ≤ X.rhsData.rhs

end Iut

end AbcAdaptation.Reference
