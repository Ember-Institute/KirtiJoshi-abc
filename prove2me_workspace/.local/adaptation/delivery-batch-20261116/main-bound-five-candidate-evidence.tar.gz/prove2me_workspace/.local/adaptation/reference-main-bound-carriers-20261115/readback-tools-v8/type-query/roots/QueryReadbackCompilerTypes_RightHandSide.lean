import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RightHandSide
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.RHSData
#check @AbcAdaptation.Reference.Iut.RHSData.rhs
#check @AbcAdaptation.Reference.Iut.RHSData.thetaHull
