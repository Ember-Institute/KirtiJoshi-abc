import Mathlib.Algebra.CharZero.Defs
import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Group.Basic
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Units.Defs
import Mathlib.Algebra.GroupWithZero.Defs
import Mathlib.Algebra.Order.Archimedean.Real.Basic
import Mathlib.Algebra.Order.Floor.Defs
import Mathlib.Algebra.Order.Monoid.Defs
import Mathlib.Algebra.Order.Monoid.Unbundled.Basic
import Mathlib.Algebra.Order.Monoid.Unbundled.Defs
import Mathlib.Algebra.Order.Monoid.Unbundled.ExistsOfLE
import Mathlib.Algebra.Order.Ring.Cast
import Mathlib.Algebra.Order.Ring.Defs
import Mathlib.Algebra.Order.Ring.Unbundled.Basic
import Mathlib.Algebra.Ring.Defs
import Mathlib.Algebra.Ring.Int.Defs
import Mathlib.Algebra.Ring.Nat
import Mathlib.Analysis.Normed.Field.Basic
import Mathlib.Analysis.Normed.Group.Basic
import Mathlib.Analysis.Normed.Group.Defs
import Mathlib.Analysis.Normed.Ring.Basic
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.Int.Cast.Basic
import Mathlib.Data.Int.Cast.Defs
import Mathlib.Data.Int.Order.Basic
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Logic.Function.Defs
import Mathlib.Order.Basic
import Mathlib.Order.Defs.LinearOrder
import Mathlib.Order.Defs.PartialOrder
import Mathlib.Tactic.Linarith.Lemmas
import Mathlib.Tactic.NormNum.Basic
import Mathlib.Tactic.NormNum.Result
import Mathlib.Tactic.Ring.Basic
import Mathlib.Tactic.Ring.Common
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_PrimeToOrder
import Mathlib.Tactic.Linarith
import Lean.Elab.Tactic.NormCast
import Lean.Elab.Tactic.Omega

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace TateCurvesTheta

variable {K : Type*} [NormedField K]


structure IsUniformizer (π : K) : Prop where
  
  ne_zero : π ≠ 0
  
  norm_lt_one : ‖π‖ < 1
  
  generates : ∀ x : Kˣ, ∃ n : ℤ, ‖(x : K)‖ = ‖π‖ ^ n

namespace IsUniformizer

variable {π : K}

lemma norm_pos (hπ : IsUniformizer π) : 0 < ‖π‖ := norm_pos_iff.mpr hπ.ne_zero

lemma log_norm_neg (hπ : IsUniformizer π) : Real.log ‖π‖ < 0 :=
  Real.log_neg hπ.norm_pos hπ.norm_lt_one

end IsUniformizer

namespace TateParameter

variable (t : TateParameter K) {π : K}

lemma exists_norm_q_eq_zpow (hπ : IsUniformizer π) : ∃ n : ℤ, ‖(t.q : K)‖ = ‖π‖ ^ n :=
  hπ.generates t.q


noncomputable def orderZ (hπ : IsUniformizer π) : ℤ :=
  Classical.choose (t.exists_norm_q_eq_zpow hπ)

lemma norm_q_eq_zpow (hπ : IsUniformizer π) : ‖(t.q : K)‖ = ‖π‖ ^ t.orderZ hπ :=
  Classical.choose_spec (t.exists_norm_q_eq_zpow hπ)


theorem orderZ_pos (hπ : IsUniformizer π) : 0 < t.orderZ hπ := by
  have hq : Real.log ‖(t.q : K)‖ < 0 := Real.log_neg t.norm_q_pos t.norm_lt_one
  have heq : Real.log ‖(t.q : K)‖ = (t.orderZ hπ : ℝ) * Real.log ‖π‖ := by
    rw [t.norm_q_eq_zpow hπ, Real.log_zpow]
  by_contra hcon
  rw [not_lt] at hcon
  have hcast : (t.orderZ hπ : ℝ) ≤ 0 := by exact_mod_cast hcon
  have hnonneg : (0 : ℝ) ≤ (t.orderZ hπ : ℝ) * Real.log ‖π‖ := by
    nlinarith [hπ.log_norm_neg.le]
  rw [heq] at hq
  linarith


noncomputable def toOrdered (hπ : IsUniformizer π) : OrderedTateParameter K :=
  { t with
    orderNat := (t.orderZ hπ).toNat
    orderNat_pos := by
      have := t.orderZ_pos hπ
      omega }

section BaseChange

variable (L : Type*) [NormedField L] [NormedAlgebra K L]

end BaseChange

end TateParameter

end TateCurvesTheta

end AbcAdaptation.Reference
