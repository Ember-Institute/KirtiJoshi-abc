import Mathlib.Algebra.Algebra.Defs
import Mathlib.Algebra.Algebra.Hom
import Mathlib.Algebra.Field.Defs
import Mathlib.Algebra.Group.Action.Defs
import Mathlib.Algebra.Group.Hom.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.GroupWithZero.Action.Defs
import Mathlib.Algebra.Module.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Algebra.Ring.Hom.Defs
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Basic
import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Point
import Mathlib.AlgebraicGeometry.EllipticCurve.Weierstrass

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut.Anabelian

open WeierstrassCurve

open scoped Classical



section PointMap

variable {k K L : Type*} [Field k] [Field K] [Field L]


noncomputable def pointMap (E : WeierstrassCurve k) (f : k →+* K) :
    E.toAffine.Point →+ (E.map f).toAffine.Point :=
  letI := f.toAlgebra
  Affine.Point.map (W' := E) (S := k) (F := k) (K := K) (Algebra.ofId k K)

variable (E : WeierstrassCurve k) (f : k →+* K)

end PointMap

end Iut.Anabelian

end AbcAdaptation.Reference
