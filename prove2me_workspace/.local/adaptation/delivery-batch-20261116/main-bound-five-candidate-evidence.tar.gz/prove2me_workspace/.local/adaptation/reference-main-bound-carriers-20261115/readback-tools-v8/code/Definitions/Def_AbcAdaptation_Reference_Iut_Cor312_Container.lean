import Mathlib.Data.Finite.Defs
import Mathlib.Data.Finite.Prod
import Mathlib.Data.Fintype.Defs
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Nat.Prime.Defs
import Mathlib.Data.Set.Defs
import Mathlib.Topology.Defs.Basic
import Mathlib.Topology.Defs.Filter
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_PacketPresentation
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RationalPlace
import Mathlib.Topology.Algebra.RestrictedProduct.Basic

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



open scoped RestrictedProduct

namespace Iut

universe u₁ u₂ v


structure LargeVolumeContainerData (ι : Type u₁) (V : Type u₂) :
    Type (max u₁ u₂ (v + 1)) where
  
  proc : Procession ι
  
  toRational : V → RationalPlace
  
  fiberFintype : ∀ vQ : RationalPlace, Fintype {v : V // toRational v = vQ}
  
  packet : (i : Fin proc.length) → (vQ : RationalPlace) →
    DirectSumPresentation.{max u₂ u₁, v}
      ((proc.capsule i).LabelType → {v : V // toRational v = vQ})
  
  logShell : ∀ (i : Fin proc.length) (vQ : RationalPlace), Set (packet i vQ).Total
  
  logShell_isProduct : ∀ i vQ, (packet i vQ).IsProductRegion (logShell i vQ)
  
  logShell_relCompact : ∀ i vQ, IsCompact (closure (logShell i vQ))
  
  logShell_finiteSupport :
    ∀ i, {vQ | logShell i vQ ≠ (packet i vQ).integralRegion}.Finite
  
  integral_subset_logShell_nonarch :
    ∀ i (p : Nat.Primes),
      (packet i (.finite p)).integralRegion ⊆ logShell i (.finite p)

namespace LargeVolumeContainerData

variable {ι : Type u₁} {V : Type u₂} (D : LargeVolumeContainerData.{u₁, u₂, v} ι V)


def Fiber (vQ : RationalPlace) : Type u₂ := {v : V // D.toRational v = vQ}

instance (vQ : RationalPlace) : Fintype (D.Fiber vQ) := D.fiberFintype vQ


abbrev Components (i : Fin D.proc.length) (vQ : RationalPlace) : Type max u₁ u₂ :=
  (D.proc.capsule i).LabelType → D.Fiber vQ

noncomputable instance (i : Fin D.proc.length) (vQ : RationalPlace) :
    Fintype (D.Components i vQ) :=
  Fintype.ofFinite _


structure AdmissibleRegion (i : Fin D.proc.length) : Type max u₁ u₂ v where
  
  region : (vQ : RationalPlace) → Set (D.packet i vQ).Total
  
  finiteSupport : {vQ | region vQ ≠ (D.packet i vQ).integralRegion}.Finite

namespace AdmissibleRegion

variable {D} {i : Fin D.proc.length}


instance : LE (D.AdmissibleRegion i) :=
  ⟨fun R S => ∀ vQ, R.region vQ ⊆ S.region vQ⟩

end AdmissibleRegion


def logShellAdmissible (i : Fin D.proc.length) : D.AdmissibleRegion i where
  region vQ := D.logShell i vQ
  finiteSupport := D.logShell_finiteSupport i

end LargeVolumeContainerData

end Iut

end AbcAdaptation.Reference
