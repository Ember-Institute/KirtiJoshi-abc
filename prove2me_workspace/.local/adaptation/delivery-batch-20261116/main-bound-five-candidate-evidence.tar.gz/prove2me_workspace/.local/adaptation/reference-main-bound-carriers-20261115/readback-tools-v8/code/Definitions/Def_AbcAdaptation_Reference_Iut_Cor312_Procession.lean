import Mathlib.Data.SetLike.Basic
import Mathlib.Data.Finset.Attach
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Defs
import Mathlib.Data.Fintype.Defs
import Mathlib.Data.Nat.Basic
import Mathlib.Order.Defs.PartialOrder
import Mathlib.Order.Interval.Finset.Basic
import Mathlib.Order.Interval.Finset.Defs
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Order.Nat

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut


def procLabels (j : ℕ) : Finset ℕ := Finset.Iic j

lemma procLabels_mono {i j : ℕ} (h : i ≤ j) : procLabels i ⊆ procLabels j :=
  Finset.Iic_subset_Iic.mpr h


structure Capsule (ι : Type*) where
  
  labels : Finset ι

namespace Capsule

variable {ι : Type*}


def card (S : Capsule ι) : ℕ := S.labels.card


def LabelType (S : Capsule ι) : Type _ := S.labels

instance [DecidableEq ι] (S : Capsule ι) : DecidableEq S.LabelType :=
  inferInstanceAs (DecidableEq S.labels)

instance (S : Capsule ι) : Fintype S.LabelType :=
  inferInstanceAs (Fintype S.labels)

end Capsule


structure Procession (ι : Type*) where
  
  length : ℕ
  
  capsule : Fin length → Capsule ι
  
  labels_mono : ∀ ⦃i j : Fin length⦄, i ≤ j → (capsule i).labels ⊆ (capsule j).labels

namespace Procession

variable {ι : Type*} (P : Procession ι)


def standard (n : ℕ) : Procession ℕ where
  length := n
  capsule i := ⟨procLabels (i + 1)⟩
  labels_mono i j h := procLabels_mono (by exact Nat.add_le_add_right h 1)

end Procession

end Iut

end AbcAdaptation.Reference
