Five formal code packets are ready for independent readers.
Give each reader one file from reader-packets/ and its actual target compiler type output.
The packets contain Lean code only. They contain no comments, paper prose, license text, or previous readback.
The production source retains its license notice. This separate inspection copy uses the existing blind packet bytes.
The code/ directory contains each exact blind module once.
The five text packets include each module's complete transitive project dependency closure.
The union contains 23 dependency modules and five current candidate modules.
These are the existing small source-preserving wrappers. No declarations were cut from those dependencies.
formal-readback-manifest.json records their source identities and dependency order.

Compile the five current production files in this order:

1. Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide.lean
2. Def_AbcAdaptation_Reference_Iut_Cor312_RightHandSide.lean
3. Def_AbcAdaptation_Reference_Iut_Cor312_Statement.lean
4. Def_AbcAdaptation_Reference_Iut_Implication_Invariants.lean
5. Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound.lean

The first two modules have no dependency on each other.
Statement imports LeftHandSide and RightHandSide.
Invariants imports LeftHandSide and Statement.
LogVolumeBound imports RightHandSide, Statement, and Invariants.
Retain all existing precise standard imports and project imports.
Main must submit every compilation through MCP-CI in the actual stable workspace.
Do not compile the reader packets as replacement production source.

The type-query/roots/ directory reuses the existing QueryReadbackCompilerTypes.lean pattern.
Its five leaves query all 27 source root declarations with explicit arguments and universe levels.
The type-query/ranged/ directory queries all 109 selected source declarations with compiler ranges.
This larger set includes root declarations, fields, constructors, and generated ranged declarations.
Each query imports only its own current target module.
Compile roots first when prompt preparation needs the smallest independent task.
The ranged leaves provide additional field and constructor types for readers.
No generated no-range candidate is assumed to exist by these readback queries.
No compiler type output is included yet.
Names in these query drafts remain candidates until the actual target compiler checks them.
The manifest lists every queried Name and source SHA256.

For actual target environment facts, reuse target-facts-query/QueryMainBoundPlatformHelpers.lean.
It copies the existing target helper exporter with exact changes in query-template.diff.
The changes cover five modules, 197 original records, 173 selected records, identifiers, output schema, and imports.
The actual Expr/Name serialization, owner discovery, helper discovery, and axiom collection remain identical.
Use these structured environment keys in the MCP-CI leaf request:

```json
{
  "NEXT_CARRIER_AUDIT_CONFIG": "/ABSOLUTE/TOOLS/formal-readback/target-facts-query/platform-query-config.json",
  "NEXT_CARRIER_PLATFORM_FACTS_OUTPUT": "/ABSOLUTE/BNEXT/current-platform-helper-facts.json"
}
```

Install or regenerate these files before submitting the leaf.
Record the actual source, config, installed Definitions, toolchain, and dependency artifact hashes in the request manifest.
Use the existing target Lean 4.33.1 environment and cached artifacts.
The exporter records presence, absence, owner, kind, levels, instance status, axioms, target-only Names, and helper Exprs.
The output schema is main-bound-platform-helper-facts-v1.
This output is factual compiler evidence. It does not compare original and target kernel terms.
Main must inspect sorryAx, unexpected axioms, generated Name shifts, and owner differences in the actual output.
Neither #check success nor helper export success establishes kernel acceptance.

kernel-reuse-plan.draft.json records the existing audit templates and the five leaf dimensions.
It is a design draft. It is not a runnable or accepted kernel audit config.
Reuse the existing next-carrier audit serializer and kernel comparison functions after binding current target facts.
Create five complete source module views from the accepted original Expr artifact and its byte profile.
Preserve every original record, Expr field, binder annotation, structure record, recursor rule, type, and value.
Do not replace full Expr evidence with the metadata-only wrapper map.
Retain the complete totals of 197 original records and 173 selected source obligations.
Bind each leaf to its exact original module, installed target bytes, and actual target query receipt.
Discover current generated identities from actual target facts before selecting named or genuine-proof comparisons.
Do not assume all 173 obligations have standalone target Names.

The old initial-theta preparation script cannot run unchanged for this unit.
It fixes four modules, 232 original records, 204 selected obligations, and a different dependency set.
Its base audit template also rejects all proof-value bindings and non-prefix relocation pairs.
The later parent formal template handles specific initial-theta proof shifts and galK evidence.
Do not copy those parent-specific mathematical exceptions into these five new module comparisons.
Keep the serializer, exact owner/import checks, full type/value checks, instance checks, and standard axiom checks.
Review any required unit-specific binder or generated-Name difference against actual compiler evidence.

The eventual dependency binding requires 205 previously accepted named pairs and 73 formally accepted parent named pairs.
These 278 required named dependencies are distinct from five genuine source proof-value obligations.
The five proof-value obligations comprise the four initial-theta values plus the prior qOrder proof value.
Reuse exact accepted source proof values and their full owner/value evidence when those proofs enter a source closure.
Give none of these genuine proof values a standalone target alias.
The four initial-theta proof metadata records remain candidates until all 204 parent source obligations receive formal acceptance.
The current candidate materials do not authorize publication before that parent acceptance.

Supply only reader-packets/ code, actual current type slices, and READER-INSTRUCTION.txt to independent readers.
Keep this tooling explanation, source provenance reports, paper context, and previous readback outside their input.
The manifest sets finalAcceptance=false, publishAllowed=false, and parent204FormalAccepted=false.
No compiler, CI, API, Git command, or main-workspace write ran while preparing this delivery.
