import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.QPilotData
#check @AbcAdaptation.Reference.Iut.QPilotData.absLogQ
#check @AbcAdaptation.Reference.Iut.QPilotData.badFinset
#check @AbcAdaptation.Reference.Iut.QPilotData.badFinset_spec
#check @AbcAdaptation.Reference.Iut.QPilotData.casesOn
#check @AbcAdaptation.Reference.Iut.QPilotData.lhs
#check @AbcAdaptation.Reference.Iut.QPilotData.logQ
#check @AbcAdaptation.Reference.Iut.QPilotData.mem_bad
#check @AbcAdaptation.Reference.Iut.QPilotData.mk
#check @AbcAdaptation.Reference.Iut.QPilotData.noConfusion
#check @AbcAdaptation.Reference.Iut.QPilotData.rec
#check @AbcAdaptation.Reference.Iut.QPilotData.recOn
#check @AbcAdaptation.Reference.Iut.QPilotData.weight
#check @AbcAdaptation.Reference.Iut.QPilotData.weight_pos
#check @AbcAdaptation.Reference.Iut.QPilotData.mk.noConfusion
