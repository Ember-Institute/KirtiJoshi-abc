import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide
set_option pp.universes true
set_option pp.fullNames true
set_option pp.explicit true

#check @AbcAdaptation.Reference.Iut.QPilotData
#check @AbcAdaptation.Reference.Iut.QPilotData.absLogQ
#check @AbcAdaptation.Reference.Iut.QPilotData.lhs
#check @AbcAdaptation.Reference.Iut.QPilotData.logQ
#check @AbcAdaptation.Reference.Iut.QPilotData.mem_bad
