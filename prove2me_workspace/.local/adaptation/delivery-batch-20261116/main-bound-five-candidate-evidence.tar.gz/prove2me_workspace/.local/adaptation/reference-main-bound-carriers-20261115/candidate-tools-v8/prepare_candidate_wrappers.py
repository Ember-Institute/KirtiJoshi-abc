#!/usr/bin/env python3
"""Prepare draft wrappers while the real parent formal correspondence is pending.

Offline Python only. Outputs use candidate schemas and cannot enter publication.
The existing source-preserving wrapper is copied with the explicit status-only
and dependency-adapter delta recorded beside it. No strict entry is modified.
"""
import sys
sys.dont_write_bytecode = True
import argparse
import copy
import difflib
import importlib.util
import json
from pathlib import Path
from candidate_parent import build, dependency_evidence, pin, require, sha

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--parent', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args(); base = a.base.resolve(); out = a.out.resolve()
    task = Path(__file__).resolve().parent
    require(task in out.parents, 'Output must be below this candidate tools directory')
    sys.path.insert(0, str(base))
    import carrier_contract as contract
    import adapt_source_report as adapter
    import wrap_carriers as original
    template = base / 'bound-unit-config.template.json'
    before = [pin(base/n) for n in ['bind_parent.py','parent_binding.py','wrap_carriers.py','carrier_contract.py',
        'run_wrapper_generation.py','adapt_source_report.py','bound-unit-config.template.json']]
    parent = build(template, a.parent.resolve())
    parent_path = out / 'candidate-parent-report.json'; write(parent_path, parent)
    unit = contract.unit_config(template)
    unit.update(status='candidate-only-parent-formal-pending', candidateOnlyParent=pin(parent_path),
        finalAcceptance=False, publishAllowed=False)
    unit_path = out / 'candidate-unit-config.json'; write(unit_path, unit)
    _, prior_modules, _ = dependency_evidence(unit)
    imports = contract.load(base/'imports.candidate.json')
    plans = [{k:r[k] for k in ['module','source435Imports','platform433Candidates']} for r in imports]
    contract.validate_import_graph({r['module']: r for r in plans}, prior_modules)
    imports_path = out/'candidate-imports.json'; write(imports_path, imports)
    review_path = out/'candidate-import-review.json'
    write(review_path, {'schema':'foundation-precise-import-review-v1','status':'reviewed-candidate-only',
        'importsCandidateSha256':sha(imports_path),'modules':plans,'parentFormalAccepted':False,
        'finalAcceptance':False,'publishAllowed':False,
        'reviewNote':'Existing exact owner-path candidates; no aggregate Mathlib import. Parent formal audit pending.'})
    # build(None) authenticates all accepted source oracles and exact source AST
    # bytes. It neither calls the strict parent binder nor invents acceptance.
    source = adapter.build(base, None)
    source.update(status='candidate-only-source-report-parent-formal-pending',
        parentFormalAccepted=False, finalAcceptance=False, publishAllowed=False)
    source['inputs']['unit_config'] = pin(unit_path)
    source_path = out/'candidate-small-source-report.json'; write(source_path, source)
    generator_path = base/'wrap_carriers.py'
    text = generator_path.read_text()
    candidate = text
    replacements = [
        ('UNIT = None', 'from candidate_parent import dependency_evidence\nTASK = Path(__file__).resolve().parent\nUNIT = None'),
        ("'foundation-wrapper-generation-v1'", "'main-bound-candidate-wrapper-generation-v1'"),
        ("'small-source-draft-generated-needs-main-CI'", "'candidate-only-source-report-parent-formal-pending'"),
        ("reviewed['status'] == 'reviewed'", "reviewed['status'] == 'reviewed-candidate-only'"),
        ("'foundation-typed-name-module-map-v1'", "'main-bound-candidate-typed-name-module-map-v1', 'parentFormalAccepted': False, 'finalAcceptance': False, 'publishAllowed': False"),
        ("'compiler-original-bound; source/wrapped-kernel-audit-pending'", "'candidate-only-parent-formal-pending'"),
        ('typed-original-source-wrapped-map.json', 'candidate-typed-original-source-wrapped-map.json'),
        ('foundation-wrapper-report.json', 'candidate-wrapper-report.json'),
        ('five-wrapper-drafts-generated-main-platform-CI-and-kernel-audit-pending', 'candidate-only-five-wrapper-drafts-parent-formal-pending'),
        ('availablePriorActualNamedConstantCount=len(prior_constants),',
         "availablePriorActualNamedConstantCount=sum(r['mappingRole'] == 'prior-delivered' for r in prior_constants.values()),\n                      availableParentCandidateNamedConstantCount=200, parentFormalAccepted=False, finalAcceptance=False, publishAllowed=False,"),
        ("report['status'].startswith('five-wrapper-drafts-generated')", "report['status'] == 'candidate-only-five-wrapper-drafts-parent-formal-pending'"),
    ]
    for old, new in replacements:
        require(candidate.count(old) == 1, 'Wrapper delta no longer applies exactly once: '+old)
        candidate = candidate.replace(old, new)
    generated_script = out/'candidate_wrapper_generator.py'
    generated_script.write_text(candidate)
    (out/'candidate-wrapper-generator.diff').write_text(''.join(difflib.unified_diff(
        text.splitlines(keepends=True), candidate.splitlines(keepends=True),
        fromfile=str(generator_path), tofile=str(generated_script))))
    spec = importlib.util.spec_from_file_location('candidate_wrapper_generator', generated_script)
    wrapper = importlib.util.module_from_spec(spec); spec.loader.exec_module(wrapper)
    arguments = ['candidate-wrapper', '--small-source-report',str(source_path), '--unit-config',str(unit_path),
        '--imports',str(imports_path),'--reviewed-imports',str(review_path),'--out',str(out/'generated-wrapped')]
    for argument, name in [('parser-acceptance','parser-acceptance.json'), ('original-exprs','original-exprs.json'),
        ('original-exprs-acceptance','original-exprs-acceptance.json'), ('original-exprs-ci-result','original-exprs-result.json'),
        ('original-exprs-profile','original-exprs-size-profile.json')]:
        arguments.extend(['--'+argument, str(base/name)])
    previous = base.parent/'reference-volume-tate-carriers-20261115'
    arguments.extend(['--oracle-driver-acceptance',str(previous/'runtime-driver-acceptance.json'),
        '--oracle-driver-ci-result',str(previous/'runtime-oracle-driver-leaf-result.json')])
    for slug in ['LeftHandSide','RightHandSide','Statement','Invariants','LogVolumeBound']:
        arguments.extend(['--oracle-receipt',str(base/('source-small-oracle-'+slug)/'index.json'),
            '--oracle-ci-result',str(base/('source-small-oracle-'+slug+'-result.json'))])
    old_argv = sys.argv
    try:
        sys.argv = arguments
        rc = wrapper.main()
    finally:
        sys.argv = old_argv
    require(rc == 0, 'Candidate generation refused its inputs; see candidate-wrapper-report.json')
    report = contract.load(out/'generated-wrapped/candidate-wrapper-report.json')
    mapping = contract.load(out/'generated-wrapped/candidate-typed-original-source-wrapped-map.json')
    require(len(report['bundles']) == 5 and report['selectedConstantCount'] == 173
        and sum(len(m['originalExprRecordNames']) for m in mapping['modules']) == 197
        and sum(c['role'] == 'selected-declaration' for b in report['bundles'] for c in b['commandMaps']) == 27,
        'Candidate original/selected/AST-command dimensions differ')
    require(all(sha(i['path']) == i['sha256'] for i in before), 'Strict scripts or template changed')
    write(out/'candidate-generation-summary.json', {'schema':'main-bound-candidate-generation-summary-v1',
        'status':'candidate-only-five-wrapper-drafts-parent-formal-pending','parentFormalAccepted':False,
        'targetCompilerAccepted':False,'targetKernelAccepted':False,'finalAcceptance':False,'publishAllowed':False,
        'originalRecords':197,'selectedRecords':173,'wholeSelectedCommands':27,
        'parentNamedCandidates':200,'genuineSourceProofMetadata':4,'requiredParentNamedCandidates':73,
        'requiredParentGenuineProofValues':4,'strictEntriesUnchanged':before,
        'candidateGenerator':pin(generated_script),'explicitDelta':pin(out/'candidate-wrapper-generator.diff'),
        'candidateParent':pin(parent_path),'wrapperReport':pin(out/'generated-wrapped/candidate-wrapper-report.json'),
        'candidateMap':pin(out/'generated-wrapped/candidate-typed-original-source-wrapped-map.json'),
        'scope':'Draft code generation for main-agent MCP-CI and independent readback. Formal binding, fidelity, kernel, axiom and publication gates remain required.'})

if __name__ == '__main__':
    main()
