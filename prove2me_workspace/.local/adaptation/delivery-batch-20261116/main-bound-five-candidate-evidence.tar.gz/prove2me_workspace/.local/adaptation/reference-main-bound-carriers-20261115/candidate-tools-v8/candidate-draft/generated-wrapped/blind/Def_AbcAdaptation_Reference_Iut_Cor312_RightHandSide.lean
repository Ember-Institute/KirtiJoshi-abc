import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Container
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ContainerHull
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LogVolume
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RationalPlace
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Mathlib.Data.Real.Basic
import Mathlib.Data.SetLike.Basic
import Mathlib.FieldTheory.IntermediateField.Basic
import Mathlib.NumberTheory.NumberField.Completion.FinitePlace
import Mathlib.NumberTheory.NumberField.InfinitePlace.Basic

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference

set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3



namespace Iut

universe u v

open NumberField

variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}


structure RHSData (D : InitialThetaData AG TG) : Type (max u (v + 1)) where
  
  container : LargeVolumeContainerData.{0, u, v} ℕ (Place ↥D.prime.torsionField)
  
  proc_standard : container.proc = Procession.standard ((D.ℓ - 1) / 2)
  
  toRational_finite : ∀ w : FinitePlace ↥D.prime.torsionField,
    (container.toRational (Place.finite w)).residueChar = residueChar w
  
  toRational_infinite : ∀ w : InfinitePlace ↥D.prime.torsionField,
    container.toRational (Place.infinite w) = RationalPlace.infinite
  
  vol : LogVolumeData container
  
  hull : ContainerHullSystem container
  
  thetaPilot : ∀ i, container.AdmissibleRegion i
  
  thetaPilot_hullAdmissible : ∀ i, hull.IsAdmissible (thetaPilot i)
  
  thetaPilot_le_shell : ∀ i, thetaPilot i ≤ container.logShellAdmissible i

namespace RHSData

variable {D : InitialThetaData AG TG} (R : RHSData.{u, v} D)


noncomputable def thetaHull : ∀ i, R.container.AdmissibleRegion i :=
  R.hull.hullFamily R.thetaPilot


noncomputable def rhs : ℝ := R.vol.processionVol R.thetaHull

end RHSData

end Iut

end AbcAdaptation.Reference
