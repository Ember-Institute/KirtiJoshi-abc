import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RightHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"


end FoundationAudit
namespace MainBoundPlatformHelperQuery
open Lean Elab Term Meta FoundationAudit

def generatedHelperFamily (name : Name) : Bool :=
  let text := name.toString
  (text.splitOn ".").any fun component =>
    component.startsWith "eq_" || component.startsWith "_proof_" ||
    component.startsWith "_aux_" || component.startsWith "match_" || component.startsWith "_match_"

def query : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do
    throwError "Expected platform compiler4.33.1, got {Lean.versionString}"
  let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
  unless (← checked (stringField config "schema")) == "next-carrier-kernel-audit-config-v3" do
    throwError "Wrong audit configuration schema"
  let moduleRows ← checked (arrayField config "modules")
  unless moduleRows.size == 5 do throwError "Expected exactly five target modules"
  let targetModules ← moduleRows.mapM fun row => do
    return (← checked (stringField row "target")).toName
  unless (← checked (config.getObjValAs? Nat "expectedRecordCount")) == 197 do
    throwError "Expected197 original source records"
  let excludedRows ← checked (arrayField config "excludedOriginalDeclarations")
  unless excludedRows.isEmpty do throwError "This unit has no original source-private records"
  let allRows ← checked (arrayField config "projectMap")
  let currentRows := allRows.filter fun row =>
    (stringField row "mappingRole").toOption == some "current-unit"
  unless currentRows.size == 197 do throwError "Expected197 public current source candidates"
  let env ← getEnv
  let owned := (env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any targetModules.contains then acc.push n else acc) (#[] : Array Name)).qsort Name.lt
  let axiomCache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let mut expectedTargets : Array Name := #[]
  let mut missingSelectedParents : Array Name := #[]
  let mut coverage : Array Json := #[]
  let mut selectedCount := 0
  let mut selectedMissingCount := 0
  for row in currentRows do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let target ← checked (decodeName (← checked (field row "targetName")))
    let required ← checked (row.getObjValAs? Bool "required")
    expectedTargets := expectedTargets.push target
    if required then selectedCount := selectedCount + 1
    let present := env.contains target
    if required && !present then
      selectedMissingCount := selectedMissingCount + 1
      unless missingSelectedParents.contains target.getPrefix do
        missingSelectedParents := missingSelectedParents.push target.getPrefix
    coverage := coverage.push (Json.mkObj [
      ("original", toJson original.toString), ("originalName", encodeName original),
      ("candidateTarget", toJson target.toString), ("candidateTargetName", encodeName target),
      ("selected", toJson required), ("present", toJson present),
      ("actualConstantKind", match env.find? target with
        | some ci => toJson (kind ci) | none => Json.null),
      ("actualLevelParams", match env.find? target with
        | some ci => Json.arr (ci.levelParams.toArray.map encodeName) | none => Json.null),
      ("actualOwner", match moduleOf env target with
        | some owner => toJson owner.toString | none => Json.null)])
  unless selectedCount == 173 do throwError "Expected173 selected original obligations"
  let mut declarations : Array Json := #[]
  let mut helperFacts : Array Json := #[]
  let mut targetOnly : Array Name := #[]
  for name in owned do
    let ci ← getConstInfo name
    let some owner := moduleOf env name | throwError "Missing actual target owner {name}"
    let axs ← cachedAxioms axiomCache name
    let typeAxs ← expressionAxioms axiomCache ci.type
    let value := ci.value? (allowOpaque := true)
    let valueAxs ← match value with
      | none => pure #[] | some e => expressionAxioms axiomCache e
    let actualOnly := !expectedTargets.contains name
    if actualOnly then targetOnly := targetOnly.push name
    let selectedParentFamily := missingSelectedParents.any (fun parent => parent.isPrefixOf name)
    let fullFacts := actualOnly || generatedHelperFamily name || selectedParentFamily
    declarations := declarations.push (Json.mkObj [
      ("name", toJson name.toString), ("nameExpr", encodeName name),
      ("module", toJson owner.toString), ("constantKind", toJson (kind ci)),
      ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
      ("isProposition", toJson (← isProp ci.type)),
      ("isInstance", toJson (Lean.Meta.isInstanceCore env name)),
      ("axioms", toJson (axs.map Name.toString)),
      ("typeAxioms", toJson (typeAxs.map Name.toString)),
      ("valueAxioms", toJson (valueAxs.map Name.toString)),
      ("hasSorryAx", toJson (axs.contains `sorryAx)),
      ("hasValue", toJson value.isSome), ("targetOnly", toJson actualOnly),
      ("fullFactExported", toJson fullFacts)])
    if fullFacts then
      helperFacts := helperFacts.push (Json.mkObj [
        ("name", toJson name.toString), ("nameExpr", encodeName name),
        ("module", toJson owner.toString), ("constantKind", toJson (kind ci)),
        ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
        ("elaboratedExpr", ← checked (encodeExpr ci.type)),
        ("valueExpr", ← match value with
          | none => pure Json.null | some e => checked (encodeExpr e)),
        ("binderInventory", toJson (binderInventory ci.type)),
        ("isProposition", toJson (← isProp ci.type)),
        ("isInstance", toJson (Lean.Meta.isInstanceCore env name)),
        ("axioms", toJson (axs.map Name.toString)),
        ("typeAxioms", toJson (typeAxs.map Name.toString)),
        ("valueAxioms", toJson (valueAxs.map Name.toString)),
        ("typeUsedConstants", Json.arr (ci.type.getUsedConstants.map encodeName)),
        ("valueUsedConstants", Json.arr (match value with
          | none => #[] | some e => e.getUsedConstants.map encodeName)),
        ("hasSorryAx", toJson (axs.contains `sorryAx)),
        ("selectionReason", toJson (if actualOnly then "actual target-only declaration" else
          if selectedParentFamily then "actual family of a missing selected source candidate" else
            "actual generated-helper family"))])
  let output ← absoluteEnv "NEXT_CARRIER_PLATFORM_FACTS_OUTPUT"
  IO.FS.writeFile output ((Json.mkObj [
    ("schema", toJson "main-bound-platform-helper-facts-v1"),
    ("compilerVersion", toJson Lean.versionString),
    ("inventorySha256", ← checked (field config "inventorySha256")),
    ("graphSha256", ← checked (field config "graphSha256")),
    ("sourceAuditConfiguration", config),
    ("moduleNames", Json.arr (targetModules.map encodeName)),
    ("ownedDeclarationCount", toJson declarations.size),
    ("sourceRecordCount", toJson (197 : Nat)),
    ("publicSourceCandidateCount", toJson currentRows.size),
    ("excludedOriginalDeclarations", Json.arr excludedRows),
    ("selectedSourceCount", toJson selectedCount),
    ("selectedMissingCount", toJson selectedMissingCount),
    ("expectedCurrentCandidates", Json.arr coverage),
    ("ownedDeclarations", Json.arr declarations),
    ("targetOnlyNames", Json.arr (targetOnly.map encodeName)),
    ("missingSelectedParentNames", Json.arr (missingSelectedParents.map encodeName)),
    ("helperFacts", Json.arr helperFacts),
    ("identityPolicy", toJson "Actual target facts only; candidate absence asserts no source-to-helper identity and grants no proof expansion permission.")]).compress ++ "\n")
  logInfo s!"Platform helper facts: {declarations.size} owned; {selectedMissingCount}/{selectedCount} selected source candidates absent; {helperFacts.size} complete helper/family facts"

end MainBoundPlatformHelperQuery
syntax (name := queryMainBoundPlatformHelpers) "query_main_bound_platform_helpers" : command
@[command_elab queryMainBoundPlatformHelpers]
def elabQueryInitialThetaPlatformHelpers : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM MainBoundPlatformHelperQuery.query
query_main_bound_platform_helpers
