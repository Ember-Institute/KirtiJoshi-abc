import Mathlib.Data.Nat.Prime.Defs

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference



namespace Iut


inductive RationalPlace : Type
  
  | finite (p : Nat.Primes) : RationalPlace
  
  | infinite : RationalPlace
  deriving DecidableEq

namespace RationalPlace


def IsFinite : RationalPlace → Prop
  | finite _ => True
  | infinite => False


def residueChar : RationalPlace → ℕ
  | finite p => p
  | infinite => 0

end RationalPlace

end Iut

end AbcAdaptation.Reference
