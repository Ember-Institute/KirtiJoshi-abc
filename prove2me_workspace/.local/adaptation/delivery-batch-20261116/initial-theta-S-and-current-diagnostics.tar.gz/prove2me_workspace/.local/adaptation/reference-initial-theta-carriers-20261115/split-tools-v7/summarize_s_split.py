#!/usr/bin/env python3
"""Bind three actual S split receipts into one offline correspondence candidate.

No compiler, scheduler, network, Git or source modification. Large reports stay
external: the candidate contains paths, SHA256 hashes and checked scalar facts.
"""
import argparse
from collections import Counter
import hashlib
import json
import mmap
from pathlib import Path
import re

WORKSPACE = Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
ORIGINAL = 'Iut.TateFamily.S'
SOURCE_SHA = 'a5a4118c9fec2029c4fda57a5121d9dec04d2d4846ecf53ca85744965d9e5f75'
STANDARD = {'propext', 'Classical.choice', 'Quot.sound'}
LIMIT = 16 * 1024**3
HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    path = Path(path).resolve()
    if path not in HASHES:
        h = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(block)
        HASHES[path] = h.hexdigest()
    return HASHES[path]


def pin(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}


def verify_original_view(view):
    raw_binding = view['rawRecordBinding']
    require(sha(raw_binding['path']) == raw_binding['artifactSha256'], 'Original source artifact changed')
    profile_pin = view['sourceProfile']
    require(sha(profile_pin['path']) == profile_pin['sha256'], 'Original source profile changed')
    profile = load(profile_pin['path'])
    require(profile['sourceSha256'] == raw_binding['artifactSha256'], 'Original profile artifact hash differs')
    row = next(x for x in profile['records'] if x['name'] == ORIGINAL)
    require(row['offset'] == raw_binding['start'] and row['endOffset'] == raw_binding['end']
            and row['bytes'] == raw_binding['bytes'], 'Original profile record span differs')
    with Path(raw_binding['path']).open('rb') as stream:
        stream.seek(raw_binding['start'])
        raw = stream.read(raw_binding['bytes'])
    require(hashlib.sha256(raw).hexdigest() == raw_binding['recordSpanSha256'] and
            json.loads(raw) == view['record'], 'Original record bytes or decoded record changed')
    for key, binding in raw_binding['fieldSpans'].items():
        begin = binding['start'] - raw_binding['start']
        require(row['fieldOffsets'][key] == binding['start'] and row['fieldBytes'][key] == binding['bytes']
                and binding['end'] == binding['start'] + binding['bytes']
                and hashlib.sha256(raw[begin:begin + binding['bytes']]).hexdigest() == binding['sha256'],
                'Original exact field span changed: ' + key)
    module_pin = view['exactModuleView']
    require(sha(module_pin['path']) == module_pin['sha256'], 'Original exact module view changed')
    require(next(x for x in load(module_pin['path'])['records'] if x['name'] == ORIGINAL) == view['record'],
            'Original module view record differs')


def field(mm, key, start, end, multiple=False):
    needle = b'"' + key.encode() + b'":'
    hits = []
    pos = start
    while (pos := mm.find(needle, pos, end)) >= 0:
        if mm[pos - 1:pos] in (b'{', b','):
            hits.append(pos + len(needle))
        pos += len(needle)
    require(bool(hits) and (multiple or len(hits) == 1), f'Missing or ambiguous field: {key}')
    values = []
    for value_start in hits:
        # Selected fields must be small. Never decode the whole 457MB report.
        tail = mm[value_start:min(end, value_start + 2 * 1024**2)].decode()
        value, _ = json.JSONDecoder().raw_decode(tail)
        values.append(value)
    return values if multiple else values[0]


def check_dag(mm, envelope, start, end):
    evidence = envelope['sharedLosslessExpressionEvidence']
    require(evidence['allRootsStrictExprEqualRoundTrip'] is True, 'Strict Expr.equal roundtrip missing')
    require(evidence['includesFullNamesBinderNamesBinderInfoAndUniverseLevels'] is True, 'Lossless Expr fields missing')
    dag = evidence['exprDag']
    require(dag['schema'] == 'foundation-expr-dag-v1', 'Wrong expression DAG schema')
    nodes, roots = dag['nodes'], dag['roots']
    require(evidence['rootCount'] == len(roots) and len(roots) > 0, 'Empty or incomplete DAG root list')
    reference_keys = {'app': ['fn', 'arg'], 'lam': ['type', 'body'],
                      'forall': ['type', 'body'], 'let': ['type', 'value', 'body'], 'proj': ['body'],
                      'bvar': [], 'sort': [], 'const': [], 'nat': [], 'string': []}
    for i, node in enumerate(nodes):
        require(node['kind'] in reference_keys, 'Unknown DAG node constructor')
        for key in reference_keys[node['kind']]:
            require(type(node[key]) is int and 0 <= node[key] < i, 'Invalid DAG topological reference')
    require(all(type(root) is int and 0 <= root < len(nodes) for root in roots), 'Invalid DAG root')
    refs = [int(m.group(1)) for m in re.compile(
        rb'\{"root":([0-9]+),"schema":"foundation-expr-dag-root-v1"\}').finditer(mm, start, end)]
    require(Counter(refs) == Counter(roots), 'Evidence roots do not match every strict-roundtrip DAG root')
    return {'rootCount': len(roots), 'nodeCount': len(nodes),
            'allRootsStrictExprEqualRoundTrip': True,
            'includesFullNamesBinderNamesBinderInfoAndUniverseLevels': True}


def validate_leaf(receipt_path, mode):
    receipt_path = Path(receipt_path).resolve()
    receipt = load(receipt_path)
    require(receipt['status'] == 'succeeded' and receipt['result']['exit_code'] == 0,
            f'{mode}: actual successful terminal receipt required')
    q, result = receipt['request'], receipt['result']
    require(q['language'] == 'lean' and q['task_type'] == ('review' if mode == 'axioms' else 'leaf')
            and q['target'] == 'file', 'Wrong compiler task')
    require(Path(q['workspace']).resolve() == WORKSPACE and q['exclusive'] is True, 'Wrong exclusive workspace')
    require(result['snapshot']['workspace_mode'] == 'exclusive_worktree' and
            result['snapshot']['snapshot_id'] is None, 'Wrong workspace receipt mode')
    require(result['actual_arguments'] == ['lean', q['parameters']['source']], 'Unexpected actual compiler arguments')
    source = (WORKSPACE / q['parameters']['source']).resolve()
    config_path = Path(q['environment']['NEXT_CARRIER_AUDIT_CONFIG']).resolve()
    output_path = Path(q['environment']['NEXT_CARRIER_SPLIT_DIAGNOSTIC_OUTPUT']).resolve()
    inputs = q['worktree_manifest']['input_hashes']
    require(sha(source) == SOURCE_SHA == q['worktree_manifest']['source_sha256'] == inputs[str(source)], 'Source binding changed')
    require(sha(config_path) == inputs[str(config_path)], 'Config binding changed')
    config = load(config_path)
    require(config['splitOriginal'] == ORIGINAL and config['splitMode'] == mode, 'Wrong declaration or sibling mode')
    record_pin = config['singleSourceDeclaration']
    require(sha(record_pin['path']) == record_pin['sha256'] == inputs[record_pin['path']], 'Source-record binding changed')
    view = load(record_pin['path'])
    verify_original_view(view)
    record = view['record']
    require(record['name'] == ORIGINAL and record['selected'] is True and record['isProposition'] is False,
            'Only the exact selected computational S declaration is supported')
    require(record['valueExpr'] is not None and record['recursorRuleRhs'] == [] and record['structure'] is None,
            'S source computation shape changed')
    require(view['inventorySha256'] == config['inventorySha256'] and view['graphSha256'] == config['graphSha256'],
            'Original source provenance changed')
    for path, expected in inputs.items():
        require(sha(path) == expected, f'Compiler input changed: {path}')
    resources = receipt['resources']
    rss = resources.get('peak_rss_bytes')
    require(type(rss) is int and 0 < rss <= LIMIT, f'{mode}: measured process-tree RSS must be at most16GiB')
    for key in ['wall_time_seconds', 'cpu_time_seconds', 'cpu_user_seconds', 'cpu_system_seconds']:
        require(isinstance(resources.get(key), (int, float)), f'Missing measured resource: {key}')
    require(abs(resources['cpu_time_seconds'] - resources['cpu_user_seconds'] - resources['cpu_system_seconds']) < .05,
            'CPU resource total disagrees with user plus system time')
    with output_path.open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as mm:
        # Lean Json.compress sorts keys. These sibling report boundaries are
        # fixed by the pinned v7 source; all other top-level fields are small.
        report_key = b'"report":'
        footer_key = b'"requiredSiblingModes":'
        require(mm.find(report_key) == mm.rfind(report_key) >= 0, 'Ambiguous report envelope')
        begin = mm.find(report_key)
        footer = mm.find(footer_key)
        require(footer == mm.rfind(footer_key) and footer > begin, 'Missing sibling-mode report boundary')
        envelope = json.loads(mm[:begin] + mm[footer:])
        start, end = begin + len(report_key), footer - 1
        require(envelope['schema'] == 'initial-theta-one-declaration-split-diagnostic-v1' and
                envelope['compilerVersion'] == '4.33.1' and envelope['original'] == ORIGINAL and envelope['mode'] == mode,
                'Wrong report identity')
        require(envelope['completeSingleSourceRecordBinding'] == record_pin, 'Report record pin differs from config')
        require(envelope['requiredSiblingModes'] == ['signature', 'value', 'axioms'], 'Incomplete sibling contract')
        require(envelope['defaultLogicalCheckHeartbeatBudget'] == 200000, 'Changed logical heartbeat budget')
        for key in ['rawOriginalTypeClaimedNative433KernelChecked', 'acceptedCorrespondenceGenerated',
                    'formalKernelAcceptanceGenerated', 'priorOver16GiBLeafAccepted']:
            require(envelope[key] is False, f'Unexpected acceptance or raw claim: {key}')
        compatibility = envelope['standardCompatibilityEvidence']
        require(compatibility['allRequiredKernelChecksPassed'] is True, 'Compatibility checks incomplete')
        finite, adic, bridges = (compatibility[k] for k in
                                ['finiteQuotients', 'adicCompleteSourceTypeValueReplay', 'predicateSemanticBridges'])
        for key in ['allRequiredKernelChecksPassed', 'currentAxiomsStandardOnly', 'currentOwnersStandardOnly',
                    'currentExactOriginalFullPropositionKernelChecked', 'currentFullBinderInfoPreserved',
                    'currentNativeValueKernelCheckedAtExactOriginalType']:
            require(finite[key] is True, 'Finite quotients compatibility incomplete: ' + key)
        require(adic['completeTypeValueChecksPassed'] is True and adic['requiredOriginalRecordCount'] == 35,
                'All35 original adic DAG type/value checks missing')
        for key in ['allRequiredKernelChecksPassed', 'axiomsStandardOnly', 'currentCompleteBridgeProofsKernelChecked']:
            require(bridges[key] is True, 'Standard predicate bridge incomplete: ' + key)
        require(bridges['classIdentityClaimedDefinitionallyEqual'] is False, 'Semantic bridge replaced by a class identity claim')
        facts = {}
        expected = {}
        if mode == 'signature':
            expected = {'diagnosticPassed': True, 'faithfulReplaySignatureKernelEqual': True,
                        'rawSignatureBinderInventoryEqual': False, 'rawSignatureBinderPlacementEqual': False,
                        'rawFalseRemainsLiteral': True, 'rawOriginalTypeKernelCheckSucceeded': False,
                        'rawOriginalSignatureClaimedKernelChecked': False, 'exactExprEqualRoundTrip': True,
                        'allOtherBinderInfoStrictlyEqual': True}
            replay = field(mm, 'standardApiReplayEvidence', start, end)
            require(replay['exactExprEqualInverseReconstruction'] is True and replay['allRequiredKernelChecksPassed'] is True
                    and replay['rawOriginalClaimedKernelChecked'] is False and replay['addedTelescopeBinders'] == 0,
                    'Faithful standard replay evidence incomplete')
            require(all(v is True for v in field(mm, 'viewNeverUsedAsKernelInput', start, end, multiple=True)),
                    'Binder view used as kernel input')
        elif mode == 'value':
            expected = {'completeTypePreconditionKernelChecked': True, 'kernelPropositionalValueEqualityUsed': False,
                        'completeComputationalDataValueCompared': True, 'proofValueComparisonOmittedForPropositions': False,
                        'completeRecursorRulesCompared': 0, 'completeComputationShapeEqual': True}
            require(field(mm, 'location', start, end) == 'whole-computational-value', 'Missing full computational value comparison')
        elif mode == 'axioms':
            expected = {'hasSorryAx': False, 'hasValue': True, 'isInstance': record['isInstance'],
                        'constantKind': record['constantKind'], 'name': envelope['target']}
            for key in ['axioms', 'typeAxioms', 'valueAxioms']:
                values = field(mm, key, start, end)
                require(set(values) <= STANDARD and set(values) == set(record[key]), 'Unexpected or changed source/target axioms: ' + key)
                facts[key] = values
        else:
            raise ValueError('Unsupported sibling mode')
        for key, value in expected.items():
            actual = field(mm, key, start, end, multiple=(key == 'kernelPropositionalValueEqualityUsed'))
            require(all(type(x) is type(value) and x == value for x in actual) if isinstance(actual, list) else
                    type(actual) is type(value) and actual == value, f'{mode}: missing or incorrect {key}')
            facts[key] = value
        dag = check_dag(mm, envelope, start, end)
    normalized = dict(config)
    normalized.pop('splitMode')
    return {'mode': mode, 'job_id': receipt['job_id'], 'receipt': pin(receipt_path),
            'source': pin(source), 'config': pin(config_path), 'report': pin(output_path),
            'target': envelope['target'], 'singleSourceRecord': record_pin, 'facts': facts,
            'strictExpressionEvidence': dag, 'resources': resources,
            'standardSemanticCompatibilityAndOwnerChecksPassed': True}, normalized


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for mode in ['signature', 'value', 'axioms']:
        parser.add_argument('--' + mode + '-receipt', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    # Reject missing/nonterminal siblings before reading any large report.
    for mode in ['signature', 'value', 'axioms']:
        r = load(getattr(args, mode + '_receipt'))
        require(r['status'] == 'succeeded' and r['result']['exit_code'] == 0, mode + ': successful actual receipt required')
    leaves, common = [], None
    for mode in ['signature', 'value', 'axioms']:
        leaf, config = validate_leaf(getattr(args, mode + '_receipt'), mode)
        require(common is None or config == common, 'Sibling configs differ beyond splitMode')
        common = config
        leaves.append(leaf)
    require(len({x['job_id'] for x in leaves}) == 3 and len({x['target'] for x in leaves}) == 1,
            'Sibling receipts are not three distinct jobs for one target')
    candidate = {'schema': 'initial-theta-S-three-actual-split-correspondence-candidate-v1',
                 'status': 'offline single-declaration correspondence candidate; three actual split checks passed',
                 'original': ORIGINAL, 'target': leaves[0]['target'], 'namedDeclarationCount': 1,
                 'inventorySha256': common['inventorySha256'], 'graphSha256': common['graphSha256'],
                 'singleSourceRecord': leaves[0]['singleSourceRecord'], 'leaves': leaves,
                 'largeReportsReferencedByHashWithoutEmbedding': True,
                 'standardSemanticsRawFalseFullValueOwnersAxiomsAndStrictDagPreserved': True,
                 'acceptedCorrespondenceGenerated': False, 'formalKernelAcceptanceGenerated': False,
                 'all200ClaimedComplete': False, 'wholeThreeModuleFormalClaimedComplete': False,
                 'tool': pin(Path(__file__))}
    require(not args.out.exists(), 'Refuse to overwrite an existing candidate')
    args.out.write_text(json.dumps(candidate, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'candidate': pin(args.out), 'namedDeclarationCount': 1}))


if __name__ == '__main__':
    main()
