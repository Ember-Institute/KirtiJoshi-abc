/-- A child must refer to an already decoded node, never itself or a future node. -/
def exprDagChild (earlier : Array Expr) (entry : Json) (key : String) : Except String Expr := do
  let ref ← (← field entry key).getNat?
  match earlier[ref]? with
  | some e => pure e
  | none => throw s!"Expr DAG {key} reference {ref} is not earlier than node {earlier.size}"

/-- Decode one node using only the completed topological prefix. -/
def decodeExprDagNode (earlier : Array Expr) (entry : Json) : Except String Expr := do
  match ← stringField entry "kind" with
  | "bvar" => return .bvar (← (← field entry "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field entry "level"))
  | "const" =>
      let levels ← (← arrayField entry "levels").mapM decodeLevel
      return .const (← decodeName (← field entry "name")) levels.toList
  | "app" => return .app (← exprDagChild earlier entry "fn") (← exprDagChild earlier entry "arg")
  | "lam" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let body ← exprDagChild earlier entry "body"
      let binder ← decodeBinder (← stringField entry "binder")
      return .lam binderName ty body binder
  | "forall" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let body ← exprDagChild earlier entry "body"
      let binder ← decodeBinder (← stringField entry "binder")
      return .forallE binderName ty body binder
  | "let" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let value ← exprDagChild earlier entry "value"
      let body ← exprDagChild earlier entry "body"
      let nondependent ← (← field entry "nondependent").getBool?
      return .letE binderName ty value body nondependent
  | "nat" => return .lit (.natVal (← (← field entry "value").getNat?))
  | "string" => return .lit (.strVal (← (← field entry "value").getStr?))
  | "proj" =>
      let projectionName ← decodeName (← field entry "name")
      let index ← (← field entry "index").getNat?
      let body ← exprDagChild earlier entry "body"
      return .proj projectionName index body
  | other => throw s!"Unsupported Expr DAG node kind: {other}"

/-- Build the shared Expr table once and validate every declared root reference. -/
def decodeExprDag (dag : Json) : Except String (Array Expr) := do
  unless (← stringField dag "schema") == "foundation-expr-dag-v1" do
    throw "Unexpected Expr DAG schema"
  let entries ← arrayField dag "nodes"
  let mut decoded : Array Expr := #[]
  for entry in entries do
    decoded := decoded.push (← decodeExprDagNode decoded entry)
  for root in ← arrayField dag "roots" do
    let ref ← root.getNat?
    unless ref < decoded.size do
      throw s!"Expr DAG root reference {ref} is outside {decoded.size} nodes"
  return decoded


def installInitialThetaAdicSourceDagValues (rs : Relocations) (allowedOwners : Array Name)
    (config : Json) : MetaM (Relocations × Json) := do
  let compatibility ← checked (field config "initialThetaStandardCompatibility")
  let binding ← checked (field compatibility "adicSourceCompatibility")
  let priorProvenance ← checked (field compatibility "priorProvenance")
  unless (← checked (stringField binding "schema")) == "tate-theta-adic-two-leaf-compatibility-v1" do
    throwError "Expected the exact accepted A19/B16 source DAG compatibility"
  let leaves ← checked (arrayField binding "leaves")
  unless leaves.size == 2 && rs.sourceCompatibilityValues.isEmpty do
    throwError "Expected exactly two source DAG leaves and no preinstalled data compatibility"
  let expectedNameList ← namesFromJson (← checked (field binding "requiredOriginalNames"))
  let expectedNames := expectedNameList.toArray
  unless expectedNames.size == 35 && expectedNames.toList.eraseDups.length == 35 do
    throwError "Expected exactly35 original compatibility declarations"
  let mut result := rs
  let mut seen : Array Name := #[]
  let mut reports : Array Json := #[]
  let mut dataCount := 0
  let mut genuineProofCount := 0
  let mut cardPowCount := 0
  let mut ringCount := 0
  for leafIndex in [:leaves.size] do
    let leaf := leaves[leafIndex]!
    let view ← jsonFile (← checked (stringField leaf "viewPath"))
    let receipt ← jsonFile (← checked (stringField leaf "receiptPath"))
    unless view == (← checked (field leaf "viewContents")) && receipt == (← checked (field leaf "receiptContents")) do
      throwError "Accepted source DAG view or receipt changed after hash binding"
    unless (← checked (stringField leaf "viewSha256")).length == 64 &&
        (← checked (stringField leaf "receiptSha256")).length == 64 do
      throwError "Missing external accepted source DAG SHA256 binding"
    unless (← checked (stringField view "schema")) == "tate-theta-adic-receipt-bound-dag-view-v1" &&
        (← checked (stringField receipt "status")) == "succeeded" &&
        (← checked (stringField receipt "job_id")) == (if leafIndex == 0 then "ci-014497-4264b653" else "ci-014507-f12c827f") do
      throwError "Wrong exact accepted source DAG leaf identity/status"
    let receiptResult ← checked (field receipt "result")
    let request ← checked (field receipt "request")
    unless (← checked (receiptResult.getObjValAs? Nat "exit_code")) == 0 &&
        (← checked (request.getObjValAs? Bool "exclusive")) do
      throwError "Accepted source DAG leaf did not exit zero exclusively"
    let snapshot ← checked (field receiptResult "snapshot")
    unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
        (← checked (field snapshot "snapshot_id")) == Json.null do
      throwError "Wrong accepted source DAG workspace mode"
    let resources ← checked (field receipt "resources")
    unless (← checked (resources.getObjValAs? Nat "peak_rss_bytes")) ≤ 17179869184 do
      throwError "Over16GiB source DAG leaf cannot supply accepted compatibility"
    let fields ← checked (field view "sourceFields")
    unless (← checked (stringField fields "schema")) == "tate-theta-adic-split-expr-dag-v1" &&
        (← checked (stringField fields "stage")) == (if leafIndex == 0 then "absnorm-support" else "finite-place") &&
        (← checked (fields.getObjValAs? Nat "stageOriginalRecordCount")) == (if leafIndex == 0 then 19 else 16) &&
        (← checked (fields.getObjValAs? Nat "allActiveOriginalRecordCount")) == 35 &&
        (← checked (fields.getObjValAs? Bool "allCompleteTypeValueKernelChecksPassed")) &&
        (← checked (fields.getObjValAs? Bool "allExprDagRootsStrictExprEqualRoundTrip")) do
      throwError "Accepted source DAG stage dimensions/checks differ"
    for key in #["inventorySha256", "graphSha256"] do
      unless (← checked (field fields key)) == (← checked (field priorProvenance key)) do
        throwError "Accepted source DAG original prior provenance differs: {key}"
    let decoded ← checked (decodeExprDag (← checked (field fields "exprDag")))
    let rows ← checked (arrayField fields "entries")
    unless rows.size == (if leafIndex == 0 then 20 else 17) do throwError "Wrong source DAG entry count"
    for row in rows do
      let name ← checked (decodeName (← checked (field row "nameExpr")))
      let params ← namesFromJson (← checked (field row "levelParams"))
      unless params.eraseDups == params do throwError "Repeated source DAG universe parameter: {name}"
      let typeRoot ← checked ((← checked (field row "typeRoot")).getNat?)
      let valueRoot ← checked ((← checked (field row "valueRoot")).getNat?)
      let some type := decoded[typeRoot]? | throwError "Missing complete source DAG type"
      let some value := decoded[valueRoot]? | throwError "Missing complete source DAG value"
      kernelTypeEq s!"complete accepted source DAG type/value {name}"
        (← kernelCheck s!"complete accepted source DAG value {name}" value) type
      let axs ← expressionAxioms value
      let taxs ← expressionAxioms type
      ensureStandard s!"complete accepted source DAG value {name}" axs
      ensureStandard s!"complete accepted source DAG type {name}" taxs
      for term in #[type, value] do
        for used in term.getUsedConstants do allowedOwner result allowedOwners used
      if name == `NumberField.RingOfIntegers.instHasFiniteQuotients then
        let some seed := result.standardProofValues.find? (·.1 == name) |
          throwError "The exact checked Ring proof seed is absent"
        unless params == seed.2.1 && Expr.equal value seed.2.2 do
          throwError "The complete source DAG Ring seed differs from the exact checked proof"
        ringCount := ringCount + 1
        continue
      unless expectedNames.contains name && !seen.contains name && !(result.any (·.original == name)) do
        throwError "Source DAG declaration is duplicated/unapproved/project-mapped: {name}"
      seen := seen.push name
      let isProof ← checked (row.getObjValAs? Bool "isProposition")
      let typeSort ← kernelCheck s!"complete source DAG declared type sort {name}" type
      let kernelProofStatus ← match typeSort with
        | .sort level => pure level.isAlwaysZero
        | _ => throwError "Complete source DAG declaration type does not inhabit a sort: {name}"
      unless isProof == kernelProofStatus do throwError "Source DAG proof/data status changed: {name}"
      let method ← checked (stringField row "resolution")
      if name == `cardQuot_pow_of_prime then
        unless method == "exact-original-type-native-theorem-proof" && isProof &&
            Expr.equal value (Lean.mkConst name (params.map Level.param)) do
          throwError "Only the exact native CardPow theorem proof may override its archived old proof body"
        cardPowCount := cardPowCount + 1
      else
        unless method == "genuine-original-complete-body" do throwError "Original source body was replaced: {name}"
        if isProof then genuineProofCount := genuineProofCount + 1 else dataCount := dataCount + 1
      result := { result with sourceCompatibilityValues := result.sourceCompatibilityValues.push (name, (params, value)) }
      reports := reports.push (Json.mkObj [
        ("original", toJson name.toString), ("originalName", encodeName name),
        ("levelParams", Json.arr (params.toArray.map encodeName)),
        ("resolution", toJson method), ("isProposition", toJson isProof),
        ("standaloneTargetIdentity", Json.null),
        ("leafJob", ← checked (field receipt "job_id")),
        ("viewPath", ← checked (field leaf "viewPath")),
        ("typeRoot", toJson typeRoot), ("valueRoot", toJson valueRoot),
        ("completeTypeAndValueRetainedInExactExprDag", toJson true),
        ("exactOriginalTypeKernelChecked", toJson true),
        ("completeValueKernelCheckedAtExactOriginalType", toJson true),
        ("typeAxioms", toJson (taxs.map Name.toString)), ("valueAxioms", toJson (axs.map Name.toString)),
        ("publicConsumerFullKernelEqualityRequired", toJson true)])
  unless seen.size == 35 && expectedNames.all seen.contains && ringCount == 2 &&
      dataCount == 8 && genuineProofCount == 26 && cardPowCount == 1 do
    throwError "Exact accepted source DAG35/data8/genuineproof26/nativeCardPow1 coverage differs"
  logInfo "Validated complete source types and values for35 source DAG declarations"
  return (result, Json.mkObj [
    ("schema", toJson "tate-theta-adic-source-dag-compatibility-result-v1"),
    ("requiredOriginalRecordCount", toJson seen.size), ("genuineOriginalDataCount", toJson dataCount),
    ("genuineOriginalProofBodyCount", toJson genuineProofCount), ("nativeCardPowProofCount", toJson cardPowCount),
    ("standardNativeProofCountIncludingRing", toJson (2 : Nat)),
    ("completeTypeValueChecksPassed", toJson true), ("entries", Json.arr reports),
    ("unusedOriginalProofArchiveCount", toJson (15 : Nat)),
    ("publicRawSignatureBinderGuardsAndFullDataEqualityRemainRequired", toJson true)])

