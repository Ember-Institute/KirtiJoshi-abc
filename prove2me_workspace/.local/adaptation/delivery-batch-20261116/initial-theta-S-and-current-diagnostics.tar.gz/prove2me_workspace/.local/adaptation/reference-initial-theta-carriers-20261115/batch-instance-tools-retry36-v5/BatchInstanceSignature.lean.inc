-- Diagnostic only. An emitted candidate is not an accepted relaxation.
structure BatchViews where
  sourceView : Expr
  targetView : Expr
  sourceRestored : Expr
  targetRestored : Expr
  slots : Array Json

private def strictBinderShape (s t : Expr) : Bool :=
  binderInventory s == binderInventory t && binderPlacement s == binderPlacement t

private def batchOwnedClosed (rs : Relocations) (owners : Array Name) (label : String) (e : Expr) : MetaM Unit := do
  requireClosed label e
  for dep in e.getUsedConstants do allowedOwner rs owners dep
  ensureStandard label (← expressionAxioms e)

private def batchPathCheck (label : String) (action : MetaM α) : MetaM α := do
  logInfo s!"Exact path check start: {label}"
  let (result, ticks) ← boundedMetaAuditUnit label action
  logInfo s!"Exact path check passed: {label}; internal heartbeat ticks {ticks}"
  return result

-- Read the consuming Pi from the actual head declaration and supplied arguments.
-- inferType on the entire large partial application is unnecessary.
private def batchConsumingFunctionType (label : String) (fn : Expr) : MetaM Expr :=
  batchPathCheck label do
    let head := fn.getAppFn
    let mut type ← match head with
      | .const n us => do
        let ci ← getConstInfo n
        pure (ci.type.instantiateLevelParams ci.levelParams us)
      | .fvar id => do
        let d ← id.getDecl
        pure d.type
      | _ => inferType head
    for a in fn.getAppArgs do
      let pi ← match type with
        | .forallE .. => pure type
        | _ => whnf type
      let .forallE _ _ body _ := pi | throwError "Actual function type is not a Pi at {label}"
      type := body.instantiate1 a
    match type with
    | .forallE .. => pure type
    | _ => whnf type

private def batchJoin (s t sr tr : Expr) (a b : BatchViews) : BatchViews :=
  ⟨s, t, sr, tr, a.slots ++ b.slots⟩

private partial def eraseAdicSeedLevelNames : Level → Level
  | .param _ => .param `_initialThetaAdicSeedUniverse
  | .succ u => .succ (eraseAdicSeedLevelNames u)
  | .max a b => .max (eraseAdicSeedLevelNames a) (eraseAdicSeedLevelNames b)
  | .imax a b => .imax (eraseAdicSeedLevelNames a) (eraseAdicSeedLevelNames b)
  | u => u

private def eraseAdicSeedExprLevels (e : Expr) : Expr := e.replace fun node =>
  match node with
  | .sort u => some (.sort (eraseAdicSeedLevelNames u))
  | .const n us => some (.const n (us.map eraseAdicSeedLevelNames))
  | _ => none

private def exactAdicSourceBoundary? (rs : Relocations) (owners : Array Name)
    (ctx : Array Expr) (path : String) (source target : Expr) : MetaM (Option BatchViews) := withCurrHeartbeats do
  unless source.getAppFn.isLambda && target.getAppFn.isConst do return none
  let targetName := target.getAppFn.constName!
  let some seed := rs.sourceCompatibilityValues.find? (·.1 == targetName) | return none
  let sameSeed ← batchPathCheck s!"exact accepted DAG seed identity {targetName} at {path}" do
    pure ((eraseAdicSeedExprLevels source.getAppFn).equal (eraseAdicSeedExprLevels seed.2.2))
  unless sameSeed do return none
  -- This exact old API computational boundary is supplied by the actual A19/B16
  -- complete DAG. It is separate from the non-Prop typeclass argument policy.
  let (cs, ct) ← batchPathCheck s!"close exact API occurrence over full existing context {targetName} at {path}" do
    return (← mkLambdaFVars ctx source, ← mkLambdaFVars ctx target)
  batchPathCheck s!"complete accepted original adic API occurrence {targetName} at {path}" do
    kernelTermEq s!"complete accepted original adic API occurrence {targetName} at {path}" cs ct
  let st ← batchPathCheck s!"complete original adic API inferred type {targetName} at {path}"
    (kernelCheck "complete original adic API application type" cs)
  let tt ← batchPathCheck s!"complete actual native adic API inferred type {targetName} at {path}"
    (kernelCheck "complete actual native API application type" ct)
  let closureTerms := #[cs, ct, st, tt]
  for i in [:closureTerms.size] do
    let term := closureTerms[i]!
    batchPathCheck s!"complete exact API owner and axiom closure {targetName} term{i} at {path}" do
      batchOwnedClosed rs owners path term
  let row ← batchPathCheck s!"complete exact API evidence serialization {targetName} at {path}" do
    return Json.mkObj [
    ("kind", toJson "exact-accepted-original-adic-dag-api-boundary"),
    ("path", toJson path), ("originalStandardName", toJson targetName.toString),
    ("originalStandardNameExpr", encodeName targetName),
    ("actualSourceDagJobs", toJson #["ci-014497-4264b653", "ci-014507-f12c827f"]),
    ("completeSourceDataExpression", ← checked (encodeExpr cs)),
    ("completeTargetDataExpression", ← checked (encodeExpr ct)),
    ("completeSourceDataType", ← checked (encodeExpr st)),
    ("completeTargetDataType", ← checked (encodeExpr tt)),
    ("sourceRawBinderInventory", toJson (binderInventory source)),
    ("targetRawBinderInventory", toJson (binderInventory target)),
    ("sourceRawBinderPlacement", toJson (binderPlacement source)),
    ("targetRawBinderPlacement", toJson (binderPlacement target)),
    ("completeClosedTypesAndValuesKernelEqual", toJson true),
    ("notANewNativeProofReplacement", toJson true),
    ("allDependenciesHaveAllowedOwners", toJson true),
    ("allAxiomsStandardOnly", toJson true), ("viewNeverUsedAsKernelInput", toJson true)]
  let marker := Expr.sort .zero
  return some ⟨marker, marker, source, target, #[row]⟩

-- Views are used only for BinderInfo accounting, never as kernel inputs.
partial def batchSignatureViews (rs : Relocations) (owners : Array Name)
    (ctx : Array Expr) (path : String) (source target : Expr) : MetaM BatchViews := withCurrHeartbeats do
  let (sameRawShape, _) ← boundedMetaAuditUnit s!"exact raw binder shape {path}" (pure (strictBinderShape source target))
  if sameRawShape then return ⟨source, target, source, target, #[]⟩
  if let some boundary ← exactAdicSourceBoundary? rs owners ctx path source target then
    return boundary
  let result ← match source, target with
  | .app sf sa, .app tf ta => do
    let mut argumentViews : Option BatchViews := none
    if !strictBinderShape sa ta then
      let tft ← batchConsumingFunctionType s!"target consuming function {path}" tf
      let sft ← batchConsumingFunctionType s!"source consuming function {path}" sf
      if let .forallE _ sd _ .instImplicit := sft then
        if let .forallE _ td _ .instImplicit := tft then
          let st := sd.headBeta
          let tt := td.headBeta
          if let .const sc _ := st.getAppFn then
            if let .const tc _ := tt.getAppFn then
              let isSameNonPropClass ← batchPathCheck s!"both actual consumed domains are the same non-Prop class {path}" do
                return sc == tc && isClass (← getEnv) sc && !(← isProp st) && !(← isProp tt)
              if isSameNonPropClass then
                let exactSlot ← batchPathCheck s!"complete non-Prop typeclass data slot {path}.arg" do
                  let cs ← mkLambdaFVars ctx sa
                  let ct ← mkLambdaFVars ctx ta
                  let cst ← mkForallFVars ctx st
                  let ctt ← mkForallFVars ctx tt
                  kernelTypeEq s!"complete consumed instance parameter domains {path}"
                    (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
                  kernelTypeEq s!"complete closed data instance types {path}" cst ctt
                  kernelTermEq s!"complete closed non-Prop typeclass data values {path}" cs ct
                  for e in #[cs, ct, cst, ctt] do batchOwnedClosed rs owners path e
                  let row := Json.mkObj [
                    ("path", toJson (path ++ ".arg")), ("contextSize", toJson ctx.size),
                    ("applicationHeadSource", ← checked (encodeExpr (← mkLambdaFVars ctx sf.getAppFn))),
                    ("applicationHeadTarget", ← checked (encodeExpr (← mkLambdaFVars ctx tf.getAppFn))),
                    ("applicationArgumentIndex", toJson sf.getAppArgs.size),
                    ("bothConsumedBinders", toJson "instImplicit"),
                    ("instanceClass", toJson sc.toString), ("isProp", toJson false),
                    ("sourceRawBinderInventory", toJson (binderInventory sa)),
                    ("targetRawBinderInventory", toJson (binderInventory ta)),
                    ("sourceRawBinderPlacement", toJson (binderPlacement sa)),
                    ("targetRawBinderPlacement", toJson (binderPlacement ta)),
                    ("sourceClosedExpr", ← checked (encodeExpr cs)),
                    ("targetClosedExpr", ← checked (encodeExpr ct)),
                    ("sourceClosedType", ← checked (encodeExpr cst)),
                    ("targetClosedType", ← checked (encodeExpr ctt)),
                    ("completeConsumedParameterDomainsKernelEqual", toJson true),
                    ("completeClosedTypesKernelEqual", toJson true),
                    ("completeClosedValuesKernelEqual", toJson true),
                    ("allDependenciesHaveAllowedOwners", toJson true),
                    ("allAxiomsStandardOnly", toJson true),
                    ("viewNeverUsedAsKernelInput", toJson true)]
                  let marker := Expr.sort .zero
                  return (⟨marker, marker, sa, ta, #[row]⟩ : BatchViews)
                argumentViews := some exactSlot
    let av ← match argumentViews with
      | some v => pure v
      | none => batchSignatureViews rs owners ctx (path ++ ".arg") sa ta
    let fnViews ← batchSignatureViews rs owners ctx (path ++ ".fn") sf tf
    pure (batchJoin (.app fnViews.sourceView av.sourceView) (.app fnViews.targetView av.targetView)
      (.app fnViews.sourceRestored av.sourceRestored) (.app fnViews.targetRestored av.targetRestored) fnViews av)
  | .forallE sn sd sb si, .forallE tn td tb ti => do
    unless si == ti do throwError "Exposed/nested forall BinderInfo changed outside data slot at {path}"
    batchPathCheck s!"complete local binder type/value {path}" do
      kernelTypeEq s!"complete forall domains {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    let dv ← batchSignatureViews rs owners ctx (path ++ ".domain") sd td
    logInfo s!"Exact path local instance context start: {path}"
    withCurrHeartbeats <| withLocalDecl sn si sd fun x => do
      Lean.Core.checkMaxHeartbeats s!"exact path local instance registration {path}"
      logInfo s!"Exact path local instance context passed: {path}"
      let bv ← batchSignatureViews rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure (batchJoin
        (.forallE sn dv.sourceView (bv.sourceView.abstract #[x]) si)
        (.forallE tn dv.targetView (bv.targetView.abstract #[x]) ti)
        (.forallE sn dv.sourceRestored (bv.sourceRestored.abstract #[x]) si)
        (.forallE tn dv.targetRestored (bv.targetRestored.abstract #[x]) ti) dv bv)
  | .lam sn sd sb si, .lam tn td tb ti => do
    unless si == ti do throwError "Lambda BinderInfo changed outside data slot at {path}"
    batchPathCheck s!"complete local binder type/value {path}" do
      kernelTypeEq s!"complete lambda domains {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    let dv ← batchSignatureViews rs owners ctx (path ++ ".domain") sd td
    logInfo s!"Exact path local instance context start: {path}"
    withCurrHeartbeats <| withLocalDecl sn si sd fun x => do
      Lean.Core.checkMaxHeartbeats s!"exact path local instance registration {path}"
      logInfo s!"Exact path local instance context passed: {path}"
      let bv ← batchSignatureViews rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure (batchJoin
        (.lam sn dv.sourceView (bv.sourceView.abstract #[x]) si)
        (.lam tn dv.targetView (bv.targetView.abstract #[x]) ti)
        (.lam sn dv.sourceRestored (bv.sourceRestored.abstract #[x]) si)
        (.lam tn dv.targetRestored (bv.targetRestored.abstract #[x]) ti) dv bv)
  | .letE sn sd sv sb snon, .letE tn td tv tb tnon => do
    unless snon == tnon do throwError "Let dependency metadata differs at {path}"
    batchPathCheck s!"complete local binder type/value {path}" do
      kernelTypeEq s!"complete let types {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    batchPathCheck s!"complete local binder type/value {path}" do
      kernelTermEq s!"complete let values {path}" (← mkLambdaFVars ctx sv) (← mkLambdaFVars ctx tv)
    let dv ← batchSignatureViews rs owners ctx (path ++ ".type") sd td
    let vv ← batchSignatureViews rs owners ctx (path ++ ".value") sv tv
    logInfo s!"Exact path local let context start: {path}"
    withCurrHeartbeats <| withLetDecl sn sd sv (fun x => do
      Lean.Core.checkMaxHeartbeats s!"exact path local let registration {path}"
      logInfo s!"Exact path local let context passed: {path}"
      let bv ← batchSignatureViews rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure ⟨.letE sn dv.sourceView vv.sourceView (bv.sourceView.abstract #[x]) snon,
        .letE tn dv.targetView vv.targetView (bv.targetView.abstract #[x]) tnon,
        .letE sn dv.sourceRestored vv.sourceRestored (bv.sourceRestored.abstract #[x]) snon,
        .letE tn dv.targetRestored vv.targetRestored (bv.targetRestored.abstract #[x]) tnon,
        dv.slots ++ vv.slots ++ bv.slots⟩) (nondep := snon)
  | .proj sn si se, .proj tn ti te => do
    unless sn == tn && si == ti do throwError "Projection metadata changed at {path}"
    let v ← batchSignatureViews rs owners ctx (path ++ ".projected") se te
    pure ⟨.proj sn si v.sourceView, .proj tn ti v.targetView,
      .proj sn si v.sourceRestored, .proj tn ti v.targetRestored, v.slots⟩
  | .mdata sm se, .mdata tm te => do
    let v ← batchSignatureViews rs owners ctx path se te
    pure ⟨.mdata sm v.sourceView, .mdata tm v.targetView,
      .mdata sm v.sourceRestored, .mdata tm v.targetRestored, v.slots⟩
  | _, _ => throwError "Unaccounted raw BinderInfo difference at {path}; no typeclass data slot accepted"
  let (_, _) ← boundedMetaAuditUnit s!"complete exact Expr reconstruction and remaining binder shape {path}" do
    unless result.sourceRestored.equal source && result.targetRestored.equal target do
      throwError "Data-slot view is not exactly reversible at {path}"
    unless strictBinderShape result.sourceView result.targetView do
      throwError "Unaccounted BinderInfo remains outside exact data slots at {path}"
  return result

private partial def batchExposedDomainLoop (ctx : Array Expr) (source target : Expr)
    (rows : Array Json) : MetaM Json := do
  match source, target with
  | .forallE n sd sb si, .forallE _ td tb ti =>
    unless si == ti do throwError "Exposed BinderInfo differs at parameter {ctx.size}"
    kernelTypeEq s!"complete exposed domain {ctx.size}"
      (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    let row := Json.mkObj [("index", toJson ctx.size), ("binderInfo", toJson (encodeBinder ti)),
      ("completeClosedDomainKernelEqual", toJson true),
      ("rawDomainBinderInventoryEqual", toJson (binderInventory sd == binderInventory td)),
      ("rawDomainBinderPlacementEqual", toJson (binderPlacement sd == binderPlacement td))]
    withLocalDecl n si sd fun x =>
      batchExposedDomainLoop (ctx.push x) (sb.instantiate1 x) (tb.instantiate1 x) (rows.push row)
  | .forallE .., _ => throwError "Target exposed forall count differs"
  | _, .forallE .. => throwError "Source exposed forall count differs"
  | _, _ =>
    kernelTypeEq "complete syntactic result closed over exposed parameters"
      (← mkForallFVars ctx source) (← mkForallFVars ctx target)
    return Json.mkObj [("allExposedBinderFlagsStrict", toJson true), ("domains", Json.arr rows),
      ("completeClosedResultKernelEqual", toJson true), ("syntacticTelescopeNoWhnf", toJson true)]

private def batchExposedDomains (source target : Expr) : MetaM Json :=
  batchExposedDomainLoop #[] source target #[]

def batchOneSignature (rs : Relocations) (owners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sp ← namesFromJson (← checked (field record "levelParams"))
  unless sp.length == target.levelParams.length do throwError "Universe arity changed"
  let canonical : List Level := (canonicalLevels sp.length).map Level.param
  let some r := rs.find? (·.original == original) | throwError "No exact named map"
  let tl : List Level ← match r.permutation with
    | none => pure canonical
    | some p => do
      let reordered : Array Level ← checked (reorder p canonical.toArray)
      pure reordered.toList
  let rawRs := {rs with sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[]}
  let raw := (← checked (decodeExpr rawRs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical
  let s := (← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical
  let t := target.type.instantiateLevelParams target.levelParams tl
  unless binderInventory raw == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
    throwError "Original exported raw inventory serialization differs"
  unless strictBinderShape raw s do throwError "Proof expansion changed raw signature BinderInfo; batch refuses to conflate views"
  let rawInventoryEqual := binderInventory raw == binderInventory t
  let rawPlacementEqual := binderPlacement raw == binderPlacement t
  let baseline := [("original", toJson original.toString), ("target", toJson target.name.toString),
    ("rawSignatureBinderInventoryEqual", toJson rawInventoryEqual),
    ("rawSignatureBinderPlacementEqual", toJson rawPlacementEqual),
    ("sourceRawBinderCount", toJson (binderInventory raw).size), ("targetRawBinderCount", toJson (binderInventory t).size),
    ("sourceSignatureSerializationValidated", toJson true)]
  try
    kernelTypeEq s!"complete unmodified signature {original}" s t
    for e in #[s, t] do batchOwnedClosed rs owners original.toString e
    let domains ← batchExposedDomains s t
    let views ← batchSignatureViews rs owners #[] "root" s t
    unless (!rawInventoryEqual || !rawPlacementEqual) == !views.slots.isEmpty do
      throwError "Raw failure and changed-slot presence disagree"
    let sourceSignatureJson ← if views.slots.isEmpty then pure Json.null else checked (encodeExpr raw)
    let targetSignatureJson ← if views.slots.isEmpty then pure Json.null else checked (encodeExpr t)
    let sourceViewJson ← if views.slots.isEmpty then pure Json.null else checked (encodeExpr views.sourceView)
    let targetViewJson ← if views.slots.isEmpty then pure Json.null else checked (encodeExpr views.targetView)
    return Json.mkObj (baseline ++ [
      ("diagnosticPassed", toJson true), ("error", Json.null),
      ("completeUnmodifiedTypesKernelEqual", toJson true),
      ("exposedDomains", domains), ("changedDataSlots", Json.arr views.slots),
      ("exactExprEqualRoundTrip", toJson true), ("allOtherBinderInfoStrictlyEqual", toJson true),
      ("rawFalseRemainsLiteral", toJson (!rawInventoryEqual || !rawPlacementEqual)),
      ("completeSourceSignature", sourceSignatureJson),
      ("completeTargetSignature", targetSignatureJson),
      ("sourceBinderView", sourceViewJson),
      ("targetBinderView", targetViewJson),
      ("viewNeverUsedAsKernelInput", toJson true)])
  catch e =>
    return Json.mkObj (baseline ++ [("diagnosticPassed", toJson false),
      ("error", toJson (← e.toMessageData.toString)), ("acceptedCorrespondenceGenerated", toJson false)])

def batchInstanceDiagnostic : TermElabM Unit := do
  let (config, rs, owners) ← withCurrHeartbeats do
    unless Lean.versionString == "4.33.1" do throwError "Expected exact target compiler"
    let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
    let rs ← readRelocations config
    let modules ← (← checked (arrayField config "modules")).mapM fun row => return (← checked (stringField row "target")).toName
    let deps := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
    let prefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
    let env ← getEnv
    let mut owners := #[]
    for m in env.header.moduleNames do
      unless prefixes.any (·.isPrefixOf m) || (modules ++ deps).contains m do throwError "Forbidden module {m}"
      owners := owners.push m
    let (facts, _) ← boundedMetaAuditUnit "actual platform evidence" (verifyPlatformHelperFacts config)
    let ((rs, _), _) ← boundedMetaAuditUnit "four genuine proof values" (installExactInitialThetaProofValues rs owners config facts)
    return (config, rs, owners)
  let mut reports := #[]
  let mut namedCount := 0
  for module in ← checked (arrayField config "batchModuleViews") do
    let source ← jsonFile (← checked (stringField module "path"))
    unless (← checked (source.getObjValAs? Nat "completeOriginalRecordCount")) == 232 &&
      (← checked (source.getObjValAs? Nat "completeOriginalSelectedCount")) == 204 do throwError "Wrong source view"
    for key in #["inventorySha256", "graphSha256"] do
      unless (← checked (field config key)) == (← checked (field source key)) do throwError "Source provenance changed"
    for record in ← checked (arrayField source "records") do
      unless (← checked (record.getObjValAs? Bool "selected")) do continue
      let original ← checked (decodeName (← checked (field record "nameExpr")))
      if rs.sourceProofValues.any (·.1 == original) then continue
      let target ← checked (relocated rs original)
      let ci ← getConstInfo target
      logInfo s!"Batch exact signature diagnostic {original}"
      let (report, ticks) ← boundedMetaAuditUnit s!"batch signature {original}" (batchOneSignature rs owners record ci)
      reports := reports.push (Json.mkObj ((← checked report.getObj?).toList ++ [
        ("independentDefaultHeartbeatBudget", toJson (200000 : Nat)), ("heartbeatsInternalTicks", toJson ticks)]))
      namedCount := namedCount + 1
  unless namedCount == 200 do throwError "Expected all200 exact named declarations"
  withCurrHeartbeats do
    let output ← absoluteEnv "NEXT_CARRIER_BATCH_INSTANCE_DIAGNOSTIC_OUTPUT"
    IO.FS.writeFile output ((Json.mkObj [
      ("schema", toJson "initial-theta-all-named-instance-signature-diagnostic-v1"),
      ("compilerVersion", toJson Lean.versionString), ("namedDeclarationCount", toJson namedCount),
      ("reports", Json.arr reports), ("acceptedCorrespondenceGenerated", toJson false),
      ("mathematicalSourcesChanged", toJson false),
      ("scope", toJson "Diagnostic candidates only: exact paths and complete closed non-Prop typeclass arguments; raw mismatches remain false. Full formal data/recursor/instance/axiom gates remain separate and mandatory.")]).compress ++ "\n")
    Lean.Core.checkMaxHeartbeats "batch diagnostic emission"
