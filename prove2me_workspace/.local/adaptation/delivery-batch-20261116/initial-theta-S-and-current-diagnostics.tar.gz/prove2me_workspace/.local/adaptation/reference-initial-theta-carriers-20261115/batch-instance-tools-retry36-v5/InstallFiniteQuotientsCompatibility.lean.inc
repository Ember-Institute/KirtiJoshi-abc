-- Recheck the exact actual prior source proposition and native proof in this job.
-- There is no named target identity and no source-body-success claim.
def installInitialThetaStandardCompatibility (rs : Relocations) (owners : Array Name)
    (config : Json) : MetaM (Relocations × Json) := do
  let binding ← checked (field config "initialThetaStandardCompatibility")
  let finite ← checked (field binding "finiteQuotients")
  let evidence ← checked (field finite "evidence")
  let readBound := fun (key : String) => do
    let b ← checked (field evidence key)
    let fresh ← jsonFile (← checked (stringField b "path"))
    unless fresh == (← checked (field b "contents")) && (← checked (stringField b "sha256")).length == 64 do
      throwError "Exact prior finite-quotients evidence changed: {key}"
    pure fresh
  let source ← readBound "sourceFacts"
  let platform ← readBound "platformFacts"
  let sr ← readBound "sourceReceipt"
  let pr ← readBound "platformReceipt"
  unless (← checked (stringField sr "job_id")) == "ci-014215-2414b895" &&
      (← checked (stringField pr "job_id")) == "ci-014243-25ac457f" do throwError "Wrong actual standard query identities"
  for r in #[sr, pr] do
    unless (← checked (stringField r "status")) == "succeeded" &&
        (← checked ((← checked (field r "result")).getObjValAs? Nat "exit_code")) == 0 do
      throwError "No successful actual standard query"
    let snapshot ← checked (field (← checked (field r "result")) "snapshot")
    unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
        (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Wrong standard evidence workspace mode"
  unless (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" &&
      (← checked (stringField platform "compilerVersion")) == Lean.versionString &&
      (← checked (source.getObjValAs? Nat "selectedOriginalScopeCount")) == 78 &&
      (← checked (source.getObjValAs? Nat "relevantStandardNameCount")) == 270 &&
      (← checked (platform.getObjValAs? Nat "relevantStandardNameCount")) == 270 do
    throwError "Actual prior provenance/compiler dimensions differ"
  let priorProvenance ← checked (field binding "priorProvenance")
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field source key)) == (← checked (field platform key)) &&
        (← checked (field source key)) == (← checked (field priorProvenance key)) do
      throwError "Prior standard provenance was silently changed to current scope"
  let original := `NumberField.RingOfIntegers.instHasFiniteQuotients
  let env ← getEnv
  unless !(env.contains original) && rs.standardProofValues.isEmpty &&
      !(rs.any (·.original == original)) && Lean.isClass env `Ring.HasFiniteQuotients do
    throwError "Absent source theorem/class/identity conditions changed"
  let shapeChecks ← checked (arrayField platform "originalCurrentStandardShapeChecks")
  unless shapeChecks.size == 7 do throwError "Expected all7 actual prior standard class API checks"
  for row in shapeChecks do
    unless (← checked (row.getObjValAs? Bool "succeeded")) do throwError "Prior source/current standard API check failed"
  let actualFacts ← checked (arrayField platform "facts")
  unless actualFacts.size == 7 do throwError "Expected7 current standard API records"
  for row in actualFacts do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    let ci ← getConstInfo name
    unless (← checked (encodeExpr ci.type)) == (← checked (field row "elaboratedExpr")) do
      throwError "Current standard API type changed after actual prior query: {name}"
    let value ← match ci.value? (allowOpaque := true) with
      | none => pure Json.null
      | some e => checked (encodeExpr e)
    unless value == (← checked (field row "valueExpr")) do
      throwError "Current standard API value changed after actual prior query: {name}"
  let records ← checked (arrayField source "facts")
  unless records.size == 8 do throwError "Expected8 original standard records"
  let exact := records.filter fun r => (stringField r "name").toOption == some original.toString
  unless exact.size == 1 do throwError "No exact actual original standard theorem record"
  let record := exact[0]!
  unless (← checked (stringField record "constantKind")) == "theorem" &&
      (← checked (record.getObjValAs? Bool "isProposition")) &&
      (← checked (record.getObjValAs? Bool "isInstance")) &&
      !(← checked (record.getObjValAs? Bool "hasSorryAx")) do throwError "Original standard wrapper is not an actual Prop theorem instance"
  let bodyFailure ← checked (field platform "genuineSourceBodyAttempt")
  unless !(← checked (bodyFailure.getObjValAs? Bool "succeeded")) do throwError "Original standard-body API failure must remain false"
  let native ← checked (field platform "nativeProofAttempt")
  for key in #["succeeded", "kernelCheckedExactSourceType", "dependencyOwnersStandardOnly"] do
    unless (← checked (native.getObjValAs? Bool key)) do throwError "No actual native standard proof evidence"
  unless !(← checked (native.getObjValAs? Bool "hasSorryAx")) do throwError "Native proof has sorryAx"
  let params ← namesFromJson (← checked (field record "levelParams"))
  let nparams ← namesFromJson (← checked (field finite "nativeLevelParams"))
  unless params.length == 1 && nparams == [Name.num (Name.str .anonymous "_finiteQuotientsQueryUniverse") 0] do
    throwError "Exact original/native standard proof universe map changed"
  let type ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let nativeType := (← checked (decodeExpr rs (← checked (field native "type")))).instantiateLevelParams nparams (params.map Level.param)
  let value := (← checked (decodeExpr rs (← checked (field native "value")))).instantiateLevelParams nparams (params.map Level.param)
  kernelTypeEq "exact original standard proposition versus restored native proof type" type nativeType
  unless binderInventory type == (← checked (record.getObjValAs? (Array String) "binderInventory")) &&
      strictBinderShape type nativeType do throwError "Exact standard proposition BinderInfo changed"
  let canonical : List Level := (canonicalLevels params.length).map Level.param
  let ct := type.instantiateLevelParams params canonical
  let cv := value.instantiateLevelParams params canonical
  unless (← isProp ct) do throwError "Standard compatibility may only install a proof"
  let inferred ← kernelCheck "actual native standard proof rechecked in current job" cv
  kernelTypeEq "native standard proof inhabits exact original full proposition" inferred ct
  unless strictBinderShape inferred ct do throwError "Current native proof inferred type BinderInfo changed"
  let standardPrefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
  for e in #[ct, cv] do
    ensureStandard "finite-quotients exact proposition/native proof" (← expressionAxioms e)
    for dep in e.getUsedConstants do
      allowedOwner rs owners dep
      let some m := moduleOf (← getEnv) dep | throwError "Native standard proof dependency has no imported owner"
      unless standardPrefixes.any (·.isPrefixOf m) do throwError "Native standard proof uses project input"
  let result := {rs with standardProofValues := #[(original, (params, value))]}
  return (result, Json.mkObj [
    ("schema", toJson "initial-theta-exact-finite-quotients-native-proof-replay-v1"),
    ("original", toJson original.toString), ("standaloneTargetIdentity", Json.null),
    ("resolution", toJson "kernel-checked-native-proof-at-exact-original-type"),
    ("originalSourceBodyAttempt", bodyFailure), ("priorProvenanceRetained", toJson true),
    ("sourceRecord", record), ("nativeProofAttempt", native),
    ("currentExactOriginalFullPropositionKernelChecked", toJson true),
    ("currentNativeValueKernelCheckedAtExactOriginalType", toJson true),
    ("currentFullBinderInfoPreserved", toJson true), ("currentOwnersStandardOnly", toJson true),
    ("currentAxiomsStandardOnly", toJson true), ("allRequiredKernelChecksPassed", toJson true),
    ("wholeConsumerDataKernelEqualityStillRequired", toJson true)])
