import Lean
import Mathlib.RingTheory.Ideal.Quotient.HasFiniteQuotients
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PointMap
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PlacesOver
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_PrimeToOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Weierstrass
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_NormalizedOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_JInvariant
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Parametrization
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateStructure
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateFamily
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic


/-
Copyright (c) 2024 Salvatore Mercuri. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Salvatore Mercuri
-/
/-
READ-ONLY REVIEW DRAFT. Not compiled by this subagent.
Root must submit through MCP-CI before treating any declaration below as checked.
The namespace is deliberate: this is a source-shape semantic model, not an alias
which claims that the two distinct standard classes are kernel definitionally equal.
-/

/-
Copyright (c) 2024 Salvatore Mercuri. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Salvatore Mercuri
-/
/-
READ-ONLY REVIEW DRAFT. Not compiled by this subagent.
Root must submit through MCP-CI before treating any declaration below as checked.
The namespace is deliberate: this is a source-shape semantic model, not an alias
which claims that the two distinct standard classes are kernel definitionally equal.
-/

namespace InitialThetaStandardCompatibilityDraft

-- Source435 WithAbs.lean:310-328, with only the namespace changed.
namespace Source435
variable {L K S : Type*} [CommSemiring K] [Semiring L] [Algebra K L]
  [FaithfulSMul K L] [PartialOrder S] [Semiring S]

variable (K)
def under (w : AbsoluteValue L S) : AbsoluteValue K S :=
  w.comp (FaithfulSMul.algebraMap_injective K L)

variable {K}
class LiesOver (w : AbsoluteValue L S) (v : AbsoluteValue K S) : Prop where
  under_eq (w) (v) : under K w = v
end Source435

section ExistingFieldContext
variable {L K S : Type*} [Field K] [Field L] [Algebra K L]
  [PartialOrder S] [Semiring S]
variable (w : AbsoluteValue L S) (v : AbsoluteValue K S)

-- Native433 still receives every structural parameter. Field K / Field L are
-- ALREADY PRESENT at the ValuationSection application site, not new hypotheses
-- to insert into a source declaration.
def targetLiesOverAtExistingFields : Prop :=
  @AbsoluteValue.LiesOver K L S
    (inferInstance : CommRing K) (inferInstance : IsSimpleRing K)
    (inferInstance : CommRing L) (inferInstance : Algebra K L)
    (inferInstance : PartialOrder S) (inferInstance : Nontrivial L)
    (inferInstance : Semiring S) w v

-- The injectivity proof arguments have the same proposition; kernel proof
-- irrelevance is sufficient for this equation-body comparison. Root must check.
theorem restrictionBodyEq :
    Source435.under K w = w.comp (algebraMap K L).injective := rfl

-- This is Iff evidence, not definitional equality between the two classes.
theorem source435IffNative433 :
    Source435.LiesOver w v ↔ AbsoluteValue.LiesOver w v := by
  constructor
  · intro h
    letI := h
    exact ⟨Source435.LiesOver.under_eq w v⟩
  · intro h
    letI := h
    exact ⟨AbsoluteValue.LiesOver.comp_eq w v⟩

-- The common semantic normal form, useful for receipts from both environments.
theorem native433IffRestrictionEquality :
    AbsoluteValue.LiesOver w v ↔ w.comp (algebraMap K L).injective = v := by
  constructor
  · intro h
    letI := h
    exact AbsoluteValue.LiesOver.comp_eq w v
  · intro h
    exact ⟨h⟩
end ExistingFieldContext

-- The target general instance already supplies precisely this proposition.
-- Do not register a constant with the absent source constant's name.
theorem finiteQuotientsNativeAtSourceType (K : Type*) [Field K] [NumberField K] :
    Ring.HasFiniteQuotients (NumberField.RingOfIntegers K) := by
  infer_instance

end InitialThetaStandardCompatibilityDraft

#print axioms InitialThetaStandardCompatibilityDraft.restrictionBodyEq
#print axioms InitialThetaStandardCompatibilityDraft.source435IffNative433
#print axioms InitialThetaStandardCompatibilityDraft.native433IffRestrictionEquality
#print axioms InitialThetaStandardCompatibilityDraft.finiteQuotientsNativeAtSourceType

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

structure Relocation where
  original : Name
  target : Name
  permutation : Option (Array Nat)
  expectedInstance : Option Bool
  expectedAxioms : Option (Array Name)

structure Relocations where
  rows : Array Relocation
  projectPrefixes : Array Name
  sourcePrefixes : Array Name
  targetPrefix : Name
  excludedSourceNames : Array Name
  sourceProofValues : Array (Name × (List Name × Expr))
  standardProofValues : Array (Name × (List Name × Expr))
  sourceCompatibilityValues : Array (Name × (List Name × Expr))

def Relocations.find? (rs : Relocations) (p : Relocation → Bool) : Option Relocation := rs.rows.find? p
def Relocations.any (rs : Relocations) (p : Relocation → Bool) : Bool := rs.rows.any p

def projectName (rs : Relocations) (n : Name) : Bool :=
  rs.projectPrefixes.any (·.isPrefixOf n) || rs.excludedSourceNames.contains n

def relocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.original == n) then return r.target
  if projectName rs n then throw s!"Unmapped project name {n}"
  return n

def inverseRelocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.target == n) then return r.original
  if projectName rs n then throw s!"Unmapped wrapped name {n}"
  return n

def reorder (indices : Array Nat) (us : Array α) : Except String (Array α) := do
  unless indices.size == us.size && indices.toList.eraseDups.length == us.size do
    throw "Universe permutation has incorrect size or repeated indices"
  indices.mapM fun i => match us[i]? with
    | some u => pure u
    | none => throw "Universe permutation index out of range"

partial def decodeExpr (rs : Relocations) (j : Json) : Except String Expr := do
  let recur := decodeExpr rs
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    if let some source := rs.sourceCompatibilityValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == source.2.1.length do throw "Exact source compatibility universe arity differs"
      return source.2.2.instantiateLevelParams source.2.1 levels.toList
    if let some proof := rs.standardProofValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == proof.2.1.length do
        throw "Universe arity differs for the exact standard proposition-valued instance proof"
      return proof.2.2.instantiateLevelParams proof.2.1 levels.toList
    if let some proof := rs.sourceProofValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == proof.2.1.length do
        throw "Universe arity differs for exact genuine equation source proof value"
      return proof.2.2.instantiateLevelParams proof.2.1 levels.toList
    let target ← relocated rs original
    let mut levels ← (← arrayField j "levels").mapM decodeLevel
    if let some r := rs.find? (·.original == original) then
      if let some indices := r.permutation then levels ← reorder indices levels
    return .const target levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocated rs (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unknown Expr kind {k}"

def readRelocations (config : Json) : MetaM Relocations := do
  let projectPrefixes := (← namesFromJson (← checked (field config "projectPrefixes"))).toArray
  let sourcePrefixes := (← namesFromJson (← checked (field config "originalProjectPrefixes"))).toArray
  let targetPrefix ← checked (decodeName (← checked (field config "targetProjectPrefix")))
  unless !projectPrefixes.isEmpty && !sourcePrefixes.isEmpty && targetPrefix != .anonymous do
    throwError "Empty project-prefix policy"
  let mut result : Array Relocation := #[]
  for key in #["projectMap", "standardRenames"] do
    for row in ← checked (arrayField config key) do
      let original ← checked (decodeName (← checked (field row "originalName")))
      let targetJson ← checked (field row "targetName")
      let target ← if targetJson == Json.null then do
        unless key == "projectMap" && (← checked (stringField row "mappingRole")) == "prior-accepted-required" do
          throwError "Only accepted legacy prior identities may need platform Name resolution"
        let display ← checked (stringField row "target")
        let owner := (← checked (stringField row "targetOwner")).toName
        let env ← getEnv
        let matchingTargets := env.constants.fold (fun acc n _ =>
          if n.toString == display && moduleOf env n == some owner then acc.push n else acc) (#[] : Array Name)
        unless matchingTargets.size == 1 do
          throwError "Accepted prior target Name is not unique at expected owner: {display}"
        pure matchingTargets[0]!
      else checked (decodeName targetJson)
      unless original.toString == (← checked (stringField row "original")) &&
        target.toString == (← checked (stringField row "target")) do
        throwError "Structural relocation name mismatch"
      if key == "standardRenames" then
        if projectPrefixes.any (·.isPrefixOf original) || projectPrefixes.any (·.isPrefixOf target) then
          throwError "Standard relocation contains project name"
        unless (← checked (stringField row "evidence")).length > 0 do
          throwError "Standard rename requires reviewed compiler/source evidence"
      else
        let exactShifts := #[(`Iut.OrbicurveDataSection.XK._proof_2, `AbcAdaptation.Reference.Iut.OrbicurveDataSection.XK._proof_1),
          (`Iut.curveK._proof_2, `AbcAdaptation.Reference.Iut.curveK._proof_1)]
        let exactShift := exactShifts.contains (original, target)
        unless sourcePrefixes.any (·.isPrefixOf original) && (target == targetPrefix ++ original || exactShift) do
          throwError "Unexpected project relocation {original} -> {target}"
      if result.any (fun r => r.original == original || r.target == target) then
        throwError "Duplicate or non-injective relocation {original} -> {target}"
      let indicesJson ← checked (field row "targetToSourceUniverseIndices")
      let permutation ← if indicesJson == Json.null then pure none else
        pure (some (← checked ((← checked indicesJson.getArr?).mapM Json.getNat?)))
      let expectedInstance ← if key == "projectMap" then
        pure (some (← checked (row.getObjValAs? Bool "expectedIsInstance"))) else pure none
      let expectedAxioms ← if key == "projectMap" then
        pure (some (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray) else pure none
      result := result.push ⟨original, target, permutation, expectedInstance, expectedAxioms⟩
  let excludedRows ← checked (arrayField config "excludedOriginalDeclarations")
  let excludedSourceNames ← excludedRows.mapM fun row => do
    checked (decodeName (← checked (field row "originalName")))
  unless excludedSourceNames.size == excludedSourceNames.toList.eraseDups.length &&
      excludedSourceNames.all (fun n => (`_private).isPrefixOf n && !(result.any (·.original == n))) do
    throwError "Excluded original-private identities overlap relocation map or are not private"
  return ⟨result, projectPrefixes, sourcePrefixes, targetPrefix, excludedSourceNames, #[], #[], #[]⟩

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No imported owner for {name}"
  unless modules.contains owner do
    throwError "Forbidden dependency {name}, owner {owner}"
  if rs.sourcePrefixes.any (·.isPrefixOf name) || rs.excludedSourceNames.contains name then
    throwError "Unrelocated original project dependency {name}"

def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  if let .axiomInfo _ := ci then throwError "Carrier declares an axiom {name}"
  let axs ← collectAxioms name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"carrier {name}" axs
  ensureStandard s!"carrier type {name}" taxs
  let value? := ci.value? (allowOpaque := true)
  let vaxs ← match value? with
    | some v => expressionAxioms v
    | none => pure #[]
  ensureStandard s!"carrier value {name}" vaxs
  for expr in #[ci.type] ++ value?.toArray do
    for dep in expr.getUsedConstants do allowedOwner rs modules dep
  if let .recInfo r := ci then
    for rule in r.rules do
      for dep in rule.rhs.getUsedConstants do allowedOwner rs modules dep
      ensureStandard s!"recursor rule {name}" (← expressionAxioms rule.rhs)
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("hasValue", toJson value?.isSome),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name))]

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

def boundPlatformHelperEvidence (config : Json) (key : String) : MetaM Json := do
  let evidence ← checked (field config "platformHelperEvidence")
  let binding ← checked (field evidence key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do
    throwError "Platform helper evidence changed after hash binding: {key}"
  unless (← checked (stringField binding "sha256")).length == 64 do
    throwError "Missing external SHA256 binding for platform helper evidence: {key}"
  return actual

def verifyPlatformHelperFacts (config : Json) : MetaM Json := do
  let facts ← boundPlatformHelperEvidence config "facts"
  let receipt ← boundPlatformHelperEvidence config "receipt"
  unless (← checked (stringField receipt "job_id")) == (← checked (stringField (← checked (field config "platformHelperEvidence")) "job_id")) &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Expected successful actual platform helper query receipt"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
    throwError "Actual platform helper query exit code is not zero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do
    throwError "Wrong actual platform helper query workspace mode"
  unless (← checked (stringField facts "schema")) == "initial-theta-platform-helper-facts-v1" &&
      (← checked (stringField facts "compilerVersion")) == Lean.versionString &&
      (← checked (facts.getObjValAs? Nat "sourceRecordCount")) == 232 &&
      (← checked (facts.getObjValAs? Nat "selectedSourceCount")) == 204 &&
      (← checked (facts.getObjValAs? Nat "selectedMissingCount")) == 3 &&
      (← checked (facts.getObjValAs? Nat "ownedDeclarationCount")) == (← checked (config.getObjValAs? Nat "expectedOwnedDeclarationCount")) do
    throwError "Unexpected actual platform helper query dimensions/compiler"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field facts key)) == (← checked (field config key)) do
      throwError "Actual platform helper query provenance changed: {key}"
  unless (← checked (arrayField facts "targetOnlyNames")).isEmpty do
    throwError "Unresolved target-only compiler declaration requires source provenance review"
  let env ← getEnv
  let moduleRows ← checked (arrayField config "modules")
  let modules ← moduleRows.mapM fun row => do
    return (← checked (stringField row "target")).toName
  let actualOwned := env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)
  let ownedRows ← checked (arrayField facts "ownedDeclarations")
  let ownedNames ← ownedRows.mapM fun row => do
    checked (decodeName (← checked (field row "nameExpr")))
  unless ownedNames.size == (← checked (config.getObjValAs? Nat "expectedOwnedDeclarationCount")) && ownedNames.toList.eraseDups.length == ownedNames.size &&
      actualOwned.size == ownedNames.size && actualOwned.all ownedNames.contains do
    throwError "Actual current owned declaration set changed after platform query"
  for row in ownedRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    let ci ← getConstInfo name
    unless name.toString == (← checked (stringField row "name")) &&
        moduleOf env name == some (← checked (stringField row "module")).toName &&
        kind ci == (← checked (stringField row "constantKind")) &&
        Json.arr (ci.levelParams.toArray.map encodeName) == (← checked (field row "levelParams")) &&
        Lean.Meta.isInstanceCore env name == (← checked (row.getObjValAs? Bool "isInstance")) do
      throwError "Actual owned declaration identity/owner/kind/universes/instance changed: {name}"
    unless !(← checked (row.getObjValAs? Bool "hasSorryAx")) do
      throwError "Actual platform query contains sorryAx: {name}"
    for key in #["axioms", "typeAxioms", "valueAxioms"] do
      for ax in ← checked (arrayField row key) do
        unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
          throwError "Unexpected actual platform query axiom: {name}"
  let helperRows ← checked (arrayField facts "helperFacts")
  for row in helperRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    unless ownedNames.contains name do throwError "Unowned actual helper fact {name}"
    let ci ← getConstInfo name
    unless (← checked (encodeExpr ci.type)) == (← checked (field row "elaboratedExpr")) do
      throwError "Actual platform helper type changed: {name}"
    let value ← match ci.value? (allowOpaque := true) with
      | none => pure Json.null | some expr => checked (encodeExpr expr)
    unless value == (← checked (field row "valueExpr")) do
      throwError "Actual platform helper value changed: {name}"
  let candidates ← checked (arrayField facts "expectedCurrentCandidates")
  unless candidates.size == 232 do throwError "Wrong actual public source candidate count"
  let mut selectedCount := 0
  let mut missingCount := 0
  for row in candidates do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let target ← checked (decodeName (← checked (field row "candidateTargetName")))
    let selected ← checked (row.getObjValAs? Bool "selected")
    let present ← checked (row.getObjValAs? Bool "present")
    unless env.contains target == present do
      throwError "Actual source candidate presence changed: {original}"
    if selected then
      selectedCount := selectedCount + 1
      if !present then
        missingCount := missingCount + 1
        unless #[`Iut.OrbicurveDataSection.XK._proof_2, `Iut.curveK._proof_2, `Iut.galK._proof_2].contains original do
          throwError "Unresolved missing selected declaration {original}"
  unless selectedCount == 204 && missingCount == 3 do
    throwError "Unresolved generated names require actual evidence and a reviewed new attempt"
  return facts

-- Exact parent only. This diagnostic never changes the original raw guard.
def galKInternalSemiringData (sourceType targetType : Expr) : MetaM Json := do
  unless (binderInventory sourceType).size == 28 && (binderInventory targetType).size == 32 do
    throwError "Unexpected exact galK full raw BinderInfo dimensions"
  let expectedFlags : Array String := #["implicit", "instImplicit", "default", "implicit", "instImplicit", "instImplicit", "default", "default"]
  let accounting ← forallTelescope sourceType fun args sourceBody => do
    unless args.size == 8 do throwError "Expected all eight original galK parameters"
    let mut targetBody := targetType
    let mut domainReports : Array Json := #[]
    let mut instanceReports : Array Json := #[]
    for index in [:args.size] do
      let sourceDecl ← args[index]!.fvarId!.getDecl
      let .forallE _ targetDomain targetRest targetBinder := targetBody |
        throwError "Actual galK lost an exposed Pi binder"
      unless encodeBinder sourceDecl.binderInfo == expectedFlags[index]! && sourceDecl.binderInfo == targetBinder do
        throwError "Exact galK exposed binder attribute changed at {index}"
      let prefixArgs := args.extract 0 index
      kernelTypeEq s!"exact galK complete exposed parameter domain {index}"
        (← mkForallFVars prefixArgs sourceDecl.type) (← mkForallFVars prefixArgs targetDomain)
      let rawInventoryEqual := binderInventory sourceDecl.type == binderInventory targetDomain
      let rawPlacementEqual := binderPlacement sourceDecl.type == binderPlacement targetDomain
      if index != 7 then
        unless rawInventoryEqual && rawPlacementEqual do
          throwError "A galK parameter domain outside sigma contains different BinderInfo at {index}"
      else
        let sourceSigma := sourceDecl.type
        let targetSigma := targetDomain
        unless sourceSigma.getAppFn.isConstOf ``AlgEquiv && targetSigma.getAppFn.isConstOf ``AlgEquiv &&
            sourceSigma.getAppArgs.size == 8 && targetSigma.getAppArgs.size == 8 do
          throwError "Expected exact sigma AlgEquiv with three types and five data instances"
        let sourceSigmaArgs := sourceSigma.getAppArgs
        let targetSigmaArgs := targetSigma.getAppArgs
        for argumentIndex in [:8] do
          let sourceArgument := sourceSigmaArgs[argumentIndex]!
          let targetArgument := targetSigmaArgs[argumentIndex]!
          let sourceBinders := binderInventory sourceArgument
          let targetBinders := binderInventory targetArgument
          let argumentRawEqual := sourceBinders == targetBinders && binderPlacement sourceArgument == binderPlacement targetArgument
          if argumentIndex < 3 then
            unless argumentRawEqual do throwError "Exact sigma mathematical type argument BinderInfo changed"
            kernelTypeEq s!"sigma full mathematical type argument {argumentIndex}"
              (← mkForallFVars prefixArgs sourceArgument) (← mkForallFVars prefixArgs targetArgument)
            instanceReports := instanceReports.push (Json.mkObj [
              ("AlgEquivArgumentIndex", toJson argumentIndex), ("kind", toJson "mathematical-type"),
              ("rawBinderInfoInventoryAndPlacementEqual", toJson true), ("completeClosedTypeKernelEqual", toJson true)])
          else
            let sourceInstanceType ← whnf (← inferType sourceArgument)
            let targetInstanceType ← whnf (← inferType targetArgument)
            unless !(← isProp sourceInstanceType) && !(← isProp targetInstanceType) do
              throwError "An alleged galK data instance is a proposition"
            let expectedHead := if argumentIndex == 3 then ``CommSemiring else if argumentIndex < 6 then ``Semiring else ``Algebra
            unless sourceInstanceType.getAppFn.isConstOf expectedHead && targetInstanceType.getAppFn.isConstOf expectedHead do
              throwError "Exact sigma data instance class changed at {argumentIndex}"
            if argumentIndex == 4 || argumentIndex == 5 then
              unless sourceBinders.size == 1 && targetBinders.size == 3 &&
                  sourceBinders.all (· == "lambda:default") && targetBinders.all (· == "lambda:default") do
                throwError "Exact Semiring subtype-predicate lambda inventory changed"
            else
              unless argumentRawEqual do throwError "A sigma data slot outside the two Semiring instances changed BinderInfo"
            let closedSource ← mkLambdaFVars prefixArgs sourceArgument
            let closedTarget ← mkLambdaFVars prefixArgs targetArgument
            kernelTermEq s!"sigma complete closed computational data instance {argumentIndex}" closedSource closedTarget
            instanceReports := instanceReports.push (Json.mkObj [
              ("AlgEquivArgumentIndex", toJson argumentIndex), ("kind", toJson "computational-data-instance"),
              ("instanceClass", toJson expectedHead.toString), ("isProofSubterm", toJson false),
              ("sourceRawBinderInfo", toJson sourceBinders), ("targetRawBinderInfo", toJson targetBinders),
              ("rawBinderInfoInventoryAndPlacementEqual", toJson argumentRawEqual),
              ("closedOverAllSevenPreviousParameters", toJson true),
              ("completeClosedDataInstanceTypesAndValuesKernelEqual", toJson true),
              ("completeSourceDataExpression", ← checked (encodeExpr closedSource)),
              ("completeTargetDataExpression", ← checked (encodeExpr closedTarget))])
        -- This view records the two complete data slots separately. The original
        -- expressions are retained; exact reconstruction proves reversibility.
        -- The view itself is not used as a kernel typing or conversion input.
        let marker := Expr.sort .zero
        let sourceSlots := #[sourceSigmaArgs[4]!, sourceSigmaArgs[5]!]
        let targetSlots := #[targetSigmaArgs[4]!, targetSigmaArgs[5]!]
        let sourceViewArgs := (sourceSigmaArgs.set! 4 marker).set! 5 marker
        let targetViewArgs := (targetSigmaArgs.set! 4 marker).set! 5 marker
        let sourceView := mkAppN sourceSigma.getAppFn sourceViewArgs
        let targetView := mkAppN targetSigma.getAppFn targetViewArgs
        let sourceRestored := mkAppN sourceSigma.getAppFn ((sourceViewArgs.set! 4 sourceSlots[0]!).set! 5 sourceSlots[1]!)
        let targetRestored := mkAppN targetSigma.getAppFn ((targetViewArgs.set! 4 targetSlots[0]!).set! 5 targetSlots[1]!)
        unless sourceRestored.equal sourceSigma && targetRestored.equal targetSigma do
          throwError "Exact sigma data-slot view did not restore the complete original expressions"
        unless binderInventory sourceView == binderInventory targetView && binderPlacement sourceView == binderPlacement targetView do
          throwError "A sigma binder difference remains outside the two exact kernel-equal Semiring data slots"
      domainReports := domainReports.push (Json.mkObj [
        ("parameterIndex", toJson index), ("binderInfo", toJson (encodeBinder sourceDecl.binderInfo)),
        ("exposedBinderInfoStrictlyEqual", toJson true), ("completeClosedParameterDomainKernelEqual", toJson true),
        ("rawDomainBinderInventoryEqual", toJson rawInventoryEqual),
        ("rawDomainBinderPlacementEqual", toJson rawPlacementEqual),
        ("onlyTwoExactSemiringDataSlotsAccounted", toJson (index == 7))])
      targetBody := targetRest.instantiate1 args[index]!
    unless binderInventory sourceBody == binderInventory targetBody && binderPlacement sourceBody == binderPlacement targetBody do
      throwError "galK result type contains an unaccounted BinderInfo difference"
    kernelTypeEq "galK complete result type over all original parameters"
      (← mkForallFVars args sourceBody) (← mkForallFVars args targetBody)
    return (domainReports, instanceReports)
  return Json.mkObj [
    ("scope", toJson "Only AlgEquiv args4/5 in galK parameter7 sigma; complete Semiring data instances"),
    ("sourceRawSignatureBinderCount", toJson (28 : Nat)), ("targetRawSignatureBinderCount", toJson (32 : Nat)),
    ("originalRawSignatureInventoryEqual", toJson false), ("originalRawSignaturePlacementEqual", toJson false),
    ("allEightExposedBinderAttributesStrictlyEqual", toJson true),
    ("allEightCompleteParameterDomainsKernelEqual", toJson true),
    ("allOtherDomainAndResultBinderInfoStrictlyEqual", toJson true),
    ("allFiveCompleteAlgEquivDataInstanceTypesAndValuesKernelEqual", toJson true),
    ("threeMathematicalTypeArgumentsBinderInfoAndKernelTypesEqual", toJson true),
    ("twoSemiringSlotViewExactExprEqualRoundTrip", toJson true),
    ("twoSemiringSlotViewRemainingBinderInfoStrictlyEqual", toJson true),
    ("viewNeverUsedAsKernelTypeOrValue", toJson true),
    ("domainComparisons", Json.arr accounting.1), ("AlgEquivArgumentComparisons", Json.arr accounting.2)]


def boundExactProofEvidence (config : Json) (key : String) : MetaM Json := do
  let binding ← checked (field config key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) &&
      (← checked (stringField binding "sha256")).length == 64 do
    throwError "Exact source-backed evidence changed after binding: {key}"
  return actual

def installExactInitialThetaProofValues (rs : Relocations) (allowedOwners : Array Name)
    (config facts : Json) : MetaM (Relocations × Array Json) := do
  let source ← boundExactProofEvidence config "exactOriginalProofRecords"
  let priorShiftReceipt ← boundExactProofEvidence config "successfulShiftReceipt"
  let priorGalReceipt ← boundExactProofEvidence config "successfulGalReceipt"
  unless (← checked (stringField priorShiftReceipt "job_id")) == "ci-014978-ca2f4850" &&
      (← checked (stringField priorShiftReceipt "status")) == "succeeded" &&
      (← checked (stringField priorGalReceipt "job_id")) == "ci-015034-278554cf" &&
      (← checked (stringField priorGalReceipt "status")) == "succeeded" do
    throwError "Exact actual successful source-backed diagnostics are not bound"
  for receipt in #[priorShiftReceipt, priorGalReceipt] do
    unless (← checked ((← checked (field receipt "result")).getObjValAs? Nat "exit_code")) == 0 do
      throwError "Exact diagnostic receipt did not exit zero"
  let exact := #[`Iut.OrbicurveDataSection.XK._proof_1, `Iut.curveK._proof_1,
    `Iut.galK._proof_1, `Iut.galK._proof_2]
  let bindings ← checked (arrayField config "proofValueResolutions")
  unless bindings.size == 4 && rs.sourceProofValues.isEmpty && rs.standardProofValues.isEmpty && rs.sourceCompatibilityValues.isEmpty do
    throwError "Expected exactly four actual source proof values and no data/standard substitutions"
  let sourceRecords ← checked (arrayField source "records")
  let mut result := rs
  let mut reports : Array Json := #[]
  for original in exact do
    let rows := bindings.filter fun row => (field row "originalName").toOption == some (encodeName original)
    let matchingRecords := sourceRecords.filter fun row => (field row "nameExpr").toOption == some (encodeName original)
    unless rows.size == 1 && matchingRecords.size == 1 && !(result.any (·.original == original)) do
      throwError "Genuine source proof identity missing or improperly mapped: {original}"
    let binding := rows[0]!
    let record := matchingRecords[0]!
    unless record == (← checked (field binding "sourceRecord")) &&
        (← checked (field binding "standaloneTargetIdentity")) == Json.null &&
        (← checked (stringField record "constantKind")) == "theorem" &&
        (← checked (record.getObjValAs? Bool "selected")) &&
        (← checked (record.getObjValAs? Bool "isProposition")) &&
        !(← checked (record.getObjValAs? Bool "isInstance")) do
      throwError "Only exact genuine selected original proposition proofs may be replayed"
    let parent ← checked (decodeName (← checked (field binding "parentOriginalName")))
    let parentTarget ← checked (relocated result parent)
    let parentFacts := (← checked (arrayField facts "helperFacts")).filter fun row =>
      (field row "nameExpr").toOption == some (encodeName parentTarget)
    unless parentFacts.size == 1 && parentFacts[0]! == (← checked (field binding "actualParentFact")) do
      throwError "Whole original proof-parent data is not bound to actual current compiler facts"
    let params ← namesFromJson (← checked (field record "levelParams"))
    unless params.eraseDups == params do throwError "Repeated source proof universe parameter"
    let levels := (canonicalLevels params.length).map Level.param
    let type ← checked (decodeExpr result (← checked (field record "elaboratedExpr")))
    let value ← checked (decodeExpr result (← checked (field record "valueExpr")))
    let rawRs := { result with rows := #[], projectPrefixes := #[], excludedSourceNames := #[], sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[] }
    let rawType ← checked (decodeExpr rawRs (← checked (field record "elaboratedExpr")))
    unless binderInventory rawType == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
      throwError "Original source proof signature BinderInfo serialization differs"
    let canonicalType := type.instantiateLevelParams params levels
    let canonicalValue := value.instantiateLevelParams params levels
    match ← kernelCheck "genuine original source proof proposition type" canonicalType with
    | .sort level => unless level.isAlwaysZero do throwError "Genuine source proof type is not Prop"
    | _ => throwError "Genuine source proof type is not a type"
    let inferred ← kernelCheck "genuine original source proof body" canonicalValue
    kernelTypeEq "genuine original source proof inhabits its exact full original type" inferred canonicalType
    let inferredInventoryEqual := binderInventory inferred == binderInventory canonicalType
    let inferredPlacementEqual := binderPlacement inferred == binderPlacement canonicalType
    if original != `Iut.galK._proof_2 then
      unless inferredInventoryEqual && inferredPlacementEqual do throwError "Source class proof inferred full BinderInfo differs"
    else
      unless !inferredInventoryEqual && !inferredPlacementEqual do
        throwError "The exact actual galK source proof inferred BinderInfo diagnostic changed"
    let sourceAxioms := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
    let expectedAxioms := (← namesFromJson (← checked (field binding "expectedSourceAxioms"))).toArray
    unless sourceAxioms.qsort Name.lt == expectedAxioms.qsort Name.lt do
      throwError "Genuine source proof axiom closure differs from accepted graph"
    let taxs ← expressionAxioms canonicalType
    let vaxs ← expressionAxioms canonicalValue
    ensureStandard "genuine original source proof type" taxs
    ensureStandard "genuine original source proof body" vaxs
    for term in #[canonicalType, canonicalValue] do
      for dep in term.getUsedConstants do allowedOwner result allowedOwners dep
    result := { result with sourceProofValues := result.sourceProofValues.push (original, (params, value)) }
    reports := reports.push (Json.mkObj [
      ("original", toJson original.toString), ("originalName", encodeName original), ("sourceRecord", record),
      ("resolution", toJson "genuine-exported-original-proof-value"), ("standaloneTargetIdentity", Json.null),
      ("sourceSignatureBinderInfoSerializationValidated", toJson true),
      ("exactOriginalTypeKernelChecked", toJson true), ("genuineOriginalValueInhabitsExactOriginalType", toJson true),
      ("inferredTypeFullBinderInfoInventoryEqual", toJson inferredInventoryEqual),
      ("inferredTypeFullBinderInfoPlacementEqual", toJson inferredPlacementEqual),
      ("inferredBinderInfoPolicy", toJson (if original == `Iut.galK._proof_2 then
        "Actual full inferred implementation BinderInfo differs; no named target identity. Exact original proposition/body kernel checked; parent whole computational data equality remains mandatory." else "Full inferred BinderInfo inventory and placement strictly equal.")),
      ("expandedTypeAxioms", toJson (taxs.map Name.toString)), ("expandedValueAxioms", toJson (vaxs.map Name.toString)),
      ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true), ("expandedDependenciesHaveAllowedOwners", toJson true),
      ("parentOriginal", toJson parent.toString), ("parentTarget", encodeName parentTarget),
      ("parentWholeValueEqualityRequired", toJson true), ("parentKernelDefinitionalValueEqualityRequired", toJson true),
      ("actualSourceDiagnosticJob", toJson "ci-014978-ca2f4850"), ("actualWholeDataDiagnosticJob", toJson "ci-015034-278554cf"),
      ("hasSorryAx", toJson false)])
  return (result, reports)

def compareRecord (rs : Relocations) (allowedOwners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.eraseDups == sourceParams do throwError "Duplicate universe parameter {original}"
  unless sourceParams.length == target.levelParams.length do
    throwError "Universe parameter count differs for {original}"
  unless (← checked (stringField record "constantKind")) == kind target do
    throwError "ConstantInfo kind differs for {original}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original axiom for {original}"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "Missing map entry {original}"
  let some expectedAxioms := rel.expectedAxioms |
    throwError "Missing accepted-graph source axiom inventory {original}"
  let sourceAxiomNames := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxiomNames.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Original axiom closure differs from accepted compiler graph {original}"
  let some expectedInstance := rel.expectedInstance |
    throwError "Missing accepted-graph instance flag {original}"
  unless (← checked (record.getObjValAs? Bool "isInstance")) == expectedInstance do
    throwError "Exported original instance flag differs from accepted graph {original}"
  unless Lean.Meta.isInstanceCore (← getEnv) target.name == expectedInstance do
    throwError "Instance registry membership differs for {original}"
  let targetLevels ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let reordered ← checked (reorder indices canonical.toArray)
      pure reordered.toList
  let signatureRs := { rs with sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[] }
  let originalSignature ← checked (decodeExpr signatureRs (← checked (field record "elaboratedExpr")))
  let originalSignature := originalSignature.instantiateLevelParams sourceParams canonical
  let sourceTypeRaw ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams targetLevels
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory originalSignature do
    throwError "Unexpanded original signature BinderInfo serialization differs for {original}"
  let rawInventoryEqual := binderInventory originalSignature == binderInventory targetType
  let rawPlacementEqual := binderPlacement originalSignature == binderPlacement targetType
  let internalInstanceEvidence ← if original == `Iut.galK then do
    unless target.name == `AbcAdaptation.Reference.Iut.galK && !rawInventoryEqual && !rawPlacementEqual do
      throwError "Exact galK raw implementation BinderInfo diagnostic changed"
    galKInternalSemiringData sourceType targetType
  else do
    unless rawInventoryEqual do
      throwError "Full unexpanded original/actual target signature BinderInfo inventory differs for {original}"
    unless rawPlacementEqual do
      throwError "Full unexpanded original/actual target signature BinderInfo placement differs for {original}"
    pure Json.null
  kernelTypeEq s!"original versus target type {original}" sourceType targetType
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do
    throwError "Inductive/constructor/recursor computation shape differs for {original}"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  unless sourceProp == (← isProp target.type) do throwError "Proposition status differs {original}"
  let mut comparedValue := false
  let mut definitionallyEqualValue := false
  let originalValueJson ← checked (field record "valueExpr")
  -- Proof declarations are audited by exact type and axiom closure. For a data
  -- value containing proof fields, Kernel.isDefEq itself uses proof irrelevance.
  if !sourceProp && originalValueJson != Json.null then
    let sourceValue := (← checked (decodeExpr rs originalValueJson)).instantiateLevelParams sourceParams canonical
    let some targetValue := target.value? (allowOpaque := true) |
      throwError "Target value missing for {original}"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq s!"original value inhabits original type {original}"
      (← kernelCheck s!"original value {original}" sourceValue) sourceType
    kernelTypeEq s!"target value inhabits target type {original}"
      (← kernelCheck s!"target value {original}" targetValue) targetType
    kernelTermEq s!"original versus target computational value {original}" sourceValue targetValue
    definitionallyEqualValue := true
    comparedValue := true
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut comparedRules := 0
  if let .recInfo r := target then
    unless rules.size == r.rules.length do throwError "Recursor rule count differs {original}"
    for i in [:rules.size] do
      let sourceRhs := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let targetRhs := r.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      kernelTermEq s!"recursor rule {original} #{i}" sourceRhs targetRhs
      comparedRules := comparedRules + 1
  else
    unless rules.isEmpty do throwError "Unexpected original recursor rules {original}"
  let sourceStruct ← checked (field record "structure")
  unless (sourceStruct != Json.null) == (getStructureInfo? (← getEnv) target.name).isSome do
    throwError "Structure metadata presence differs {original}"
  if sourceStruct != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name |
      throwError "Target structure metadata missing {target.name}"
    unless (← checked (field sourceStruct "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do
      throwError "Complete structure field/parent metadata differs {original}"
    let autoParams ← checked (arrayField sourceStruct "fieldAutoParamExprs")
    unless autoParams.size == info.fieldInfo.size do
      throwError "Structure field autoParam count differs {original}"
    for i in [:autoParams.size] do
      match autoParams[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some targetExpr =>
        if sourceJson == Json.null then throwError "Missing source autoParam {original} #{i}"
        let sourceExpr := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let targetExpr := targetExpr.instantiateLevelParams target.levelParams targetLevels
        unless binderPlacement sourceExpr == binderPlacement targetExpr do
          throwError "Structure autoParam BinderInfo placement differs {original} #{i}"
        kernelTermEq s!"structure field autoParam {original} #{i}" sourceExpr targetExpr
      | sourceJson, none =>
        unless sourceJson == Json.null do throwError "Missing target autoParam {original} #{i}"
    unless (← checked (field sourceStruct "fieldsInConstructorOrder")) ==
        toJson (info.fieldNames.map Name.toString) do
      throwError "Structure field order differs {original}"
    let projections ← namesFromJson (← checked (field sourceStruct "projections"))
    let targetProjections ← projections.toArray.mapM fun n => checked (relocated rs n)
    unless targetProjections == info.fieldInfo.map (·.projFn) do
      throwError "Structure accessor identities/order differ {original}"
    for p in targetProjections do
      unless rs.any (·.target == p) do throwError "Unaudited structure accessor {p}"
  return Json.mkObj [("original", toJson original.toString), ("originalName", encodeName original),
    ("target", toJson target.name.toString), ("targetName", encodeName target.name),
    ("sourceRecord", record), ("kernelTypeEqual", toJson true),
    ("allExpressionBinderInfoEqual", toJson (rawInventoryEqual && rawPlacementEqual)),
    ("binderInfoPlacementEqual", toJson rawPlacementEqual),
    ("sourceSignatureBinderInfoSerializationValidated", toJson true),
    ("sourceTargetSignatureBinderInfoInventoryEqual", toJson rawInventoryEqual),
    ("sourceTargetSignatureBinderInfoPlacementEqual", toJson rawPlacementEqual),
    ("binderInfoComparisonScope", toJson "unexpanded-original-exported-signature-after-named-relocation-vs-actual-target-type"),
    ("exactInternalDataInstanceBinderAccounting", internalInstanceEvidence),
    ("strictRawBinderInfoOrExactGalKTwoSemiringDataAccountingPassed", toJson true),
    ("expandedOriginalTypeKernelEqual", toJson true),
    ("computationShapeEqual", toJson true), ("completeStructureMetadataEqual", toJson true),
    ("kernelValueEqual", toJson definitionallyEqualValue),
    ("computationalValueEqualityChecked", toJson comparedValue),
    ("kernelPropositionalValueEquality", toJson false),
    ("propositionalValueEqualityEvidence", Json.null),
    ("proofDeclaration", toJson sourceProp), ("recursorRulesCompared", toJson comparedRules),
    ("instanceRegistryMatchesAcceptedGraph", toJson true),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("expectedIsInstance", toJson expectedInstance),
    ("universeOriginalOrder", Json.arr (sourceParams.toArray.map encodeName)),
    ("universeTargetOrder", Json.arr (target.levelParams.toArray.map encodeName)),
    ("targetToSourceUniverseIndices", match rel.permutation with | none => Json.null | some a => toJson a)]

-- Each declaration receives the existing default budget. Neither the option nor
-- the maximum is increased. The final check also bounds work without internal
-- heartbeat checkpoints. IO counters use 1000 internal ticks per user heartbeat.
-- Optional append-only progress output. This file is never read by the audit.
def phaseTrace (phase event : String) : IO Unit := do
  let some path ← IO.getEnv "NEXT_CARRIER_PHASE_TRACE" | pure ()
  unless path.startsWith "/" do
    throw (IO.userError "NEXT_CARRIER_PHASE_TRACE must be an absolute path")
  let now ← IO.monoMsNow
  IO.FS.withFile path .append fun handle => do
    handle.putStr ((Json.mkObj [("phase", toJson phase), ("event", toJson event),
      ("monoMsNow", toJson now)]).compress ++ "\n")
    handle.flush

def boundedMetaAuditUnit (label : String) (action : MetaM α) : MetaM (α × Nat) := do
  phaseTrace ("bounded:" ++ label) "before"
  let result : α × Nat ← withCurrHeartbeats do
    unless maxHeartbeats.get (← getOptions) == 200000 do
      throwError "Expected default maxHeartbeats200000 for each independent audit unit"
    let start ← IO.getNumHeartbeats
    let value ← action
    Lean.Core.checkMaxHeartbeats label
    let finish ← IO.getNumHeartbeats
    pure (value, finish - start)
  phaseTrace ("bounded:" ++ label) "after"
  pure result

/-- A child must refer to an already decoded node, never itself or a future node. -/
def exprDagChild (earlier : Array Expr) (entry : Json) (key : String) : Except String Expr := do
  let ref ← (← field entry key).getNat?
  match earlier[ref]? with
  | some e => pure e
  | none => throw s!"Expr DAG {key} reference {ref} is not earlier than node {earlier.size}"

/-- Decode one node using only the completed topological prefix. -/
def decodeExprDagNode (earlier : Array Expr) (entry : Json) : Except String Expr := do
  match ← stringField entry "kind" with
  | "bvar" => return .bvar (← (← field entry "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field entry "level"))
  | "const" =>
      let levels ← (← arrayField entry "levels").mapM decodeLevel
      return .const (← decodeName (← field entry "name")) levels.toList
  | "app" => return .app (← exprDagChild earlier entry "fn") (← exprDagChild earlier entry "arg")
  | "lam" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let body ← exprDagChild earlier entry "body"
      let binder ← decodeBinder (← stringField entry "binder")
      return .lam binderName ty body binder
  | "forall" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let body ← exprDagChild earlier entry "body"
      let binder ← decodeBinder (← stringField entry "binder")
      return .forallE binderName ty body binder
  | "let" =>
      let binderName ← decodeName (← field entry "name")
      let ty ← exprDagChild earlier entry "type"
      let value ← exprDagChild earlier entry "value"
      let body ← exprDagChild earlier entry "body"
      let nondependent ← (← field entry "nondependent").getBool?
      return .letE binderName ty value body nondependent
  | "nat" => return .lit (.natVal (← (← field entry "value").getNat?))
  | "string" => return .lit (.strVal (← (← field entry "value").getStr?))
  | "proj" =>
      let projectionName ← decodeName (← field entry "name")
      let index ← (← field entry "index").getNat?
      let body ← exprDagChild earlier entry "body"
      return .proj projectionName index body
  | other => throw s!"Unsupported Expr DAG node kind: {other}"

/-- Build the shared Expr table once and validate every declared root reference. -/
def decodeExprDag (dag : Json) : Except String (Array Expr) := do
  unless (← stringField dag "schema") == "foundation-expr-dag-v1" do
    throw "Unexpected Expr DAG schema"
  let entries ← arrayField dag "nodes"
  let mut decoded : Array Expr := #[]
  for entry in entries do
    decoded := decoded.push (← decodeExprDagNode decoded entry)
  for root in ← arrayField dag "roots" do
    let ref ← root.getNat?
    unless ref < decoded.size do
      throw s!"Expr DAG root reference {ref} is outside {decoded.size} nodes"
  return decoded


def installInitialThetaAdicSourceDagValues (rs : Relocations) (allowedOwners : Array Name)
    (config : Json) : MetaM (Relocations × Json) := do
  let compatibility ← checked (field config "initialThetaStandardCompatibility")
  let binding ← checked (field compatibility "adicSourceCompatibility")
  let priorProvenance ← checked (field compatibility "priorProvenance")
  unless (← checked (stringField binding "schema")) == "tate-theta-adic-two-leaf-compatibility-v1" do
    throwError "Expected the exact accepted A19/B16 source DAG compatibility"
  let leaves ← checked (arrayField binding "leaves")
  unless leaves.size == 2 && rs.sourceCompatibilityValues.isEmpty do
    throwError "Expected exactly two source DAG leaves and no preinstalled data compatibility"
  let expectedNameList ← namesFromJson (← checked (field binding "requiredOriginalNames"))
  let expectedNames := expectedNameList.toArray
  unless expectedNames.size == 35 && expectedNames.toList.eraseDups.length == 35 do
    throwError "Expected exactly35 original compatibility declarations"
  let mut result := rs
  let mut seen : Array Name := #[]
  let mut reports : Array Json := #[]
  let mut dataCount := 0
  let mut genuineProofCount := 0
  let mut cardPowCount := 0
  let mut ringCount := 0
  for leafIndex in [:leaves.size] do
    let leaf := leaves[leafIndex]!
    let view ← jsonFile (← checked (stringField leaf "viewPath"))
    let receipt ← jsonFile (← checked (stringField leaf "receiptPath"))
    unless view == (← checked (field leaf "viewContents")) && receipt == (← checked (field leaf "receiptContents")) do
      throwError "Accepted source DAG view or receipt changed after hash binding"
    unless (← checked (stringField leaf "viewSha256")).length == 64 &&
        (← checked (stringField leaf "receiptSha256")).length == 64 do
      throwError "Missing external accepted source DAG SHA256 binding"
    unless (← checked (stringField view "schema")) == "tate-theta-adic-receipt-bound-dag-view-v1" &&
        (← checked (stringField receipt "status")) == "succeeded" &&
        (← checked (stringField receipt "job_id")) == (if leafIndex == 0 then "ci-014497-4264b653" else "ci-014507-f12c827f") do
      throwError "Wrong exact accepted source DAG leaf identity/status"
    let receiptResult ← checked (field receipt "result")
    let request ← checked (field receipt "request")
    unless (← checked (receiptResult.getObjValAs? Nat "exit_code")) == 0 &&
        (← checked (request.getObjValAs? Bool "exclusive")) do
      throwError "Accepted source DAG leaf did not exit zero exclusively"
    let snapshot ← checked (field receiptResult "snapshot")
    unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
        (← checked (field snapshot "snapshot_id")) == Json.null do
      throwError "Wrong accepted source DAG workspace mode"
    let resources ← checked (field receipt "resources")
    unless (← checked (resources.getObjValAs? Nat "peak_rss_bytes")) ≤ 17179869184 do
      throwError "Over16GiB source DAG leaf cannot supply accepted compatibility"
    let fields ← checked (field view "sourceFields")
    unless (← checked (stringField fields "schema")) == "tate-theta-adic-split-expr-dag-v1" &&
        (← checked (stringField fields "stage")) == (if leafIndex == 0 then "absnorm-support" else "finite-place") &&
        (← checked (fields.getObjValAs? Nat "stageOriginalRecordCount")) == (if leafIndex == 0 then 19 else 16) &&
        (← checked (fields.getObjValAs? Nat "allActiveOriginalRecordCount")) == 35 &&
        (← checked (fields.getObjValAs? Bool "allCompleteTypeValueKernelChecksPassed")) &&
        (← checked (fields.getObjValAs? Bool "allExprDagRootsStrictExprEqualRoundTrip")) do
      throwError "Accepted source DAG stage dimensions/checks differ"
    for key in #["inventorySha256", "graphSha256"] do
      unless (← checked (field fields key)) == (← checked (field priorProvenance key)) do
        throwError "Accepted source DAG original prior provenance differs: {key}"
    let decoded ← checked (decodeExprDag (← checked (field fields "exprDag")))
    let rows ← checked (arrayField fields "entries")
    unless rows.size == (if leafIndex == 0 then 20 else 17) do throwError "Wrong source DAG entry count"
    for row in rows do
      let name ← checked (decodeName (← checked (field row "nameExpr")))
      let params ← namesFromJson (← checked (field row "levelParams"))
      unless params.eraseDups == params do throwError "Repeated source DAG universe parameter: {name}"
      let typeRoot ← checked ((← checked (field row "typeRoot")).getNat?)
      let valueRoot ← checked ((← checked (field row "valueRoot")).getNat?)
      let some type := decoded[typeRoot]? | throwError "Missing complete source DAG type"
      let some value := decoded[valueRoot]? | throwError "Missing complete source DAG value"
      kernelTypeEq s!"complete accepted source DAG type/value {name}"
        (← kernelCheck s!"complete accepted source DAG value {name}" value) type
      let axs ← expressionAxioms value
      let taxs ← expressionAxioms type
      ensureStandard s!"complete accepted source DAG value {name}" axs
      ensureStandard s!"complete accepted source DAG type {name}" taxs
      for term in #[type, value] do
        for used in term.getUsedConstants do allowedOwner result allowedOwners used
      if name == `NumberField.RingOfIntegers.instHasFiniteQuotients then
        let some seed := result.standardProofValues.find? (·.1 == name) |
          throwError "The exact checked Ring proof seed is absent"
        unless params == seed.2.1 && Expr.equal value seed.2.2 do
          throwError "The complete source DAG Ring seed differs from the exact checked proof"
        ringCount := ringCount + 1
        continue
      unless expectedNames.contains name && !seen.contains name && !(result.any (·.original == name)) do
        throwError "Source DAG declaration is duplicated/unapproved/project-mapped: {name}"
      seen := seen.push name
      let isProof ← checked (row.getObjValAs? Bool "isProposition")
      let typeSort ← kernelCheck s!"complete source DAG declared type sort {name}" type
      let kernelProofStatus ← match typeSort with
        | .sort level => pure level.isAlwaysZero
        | _ => throwError "Complete source DAG declaration type does not inhabit a sort: {name}"
      unless isProof == kernelProofStatus do throwError "Source DAG proof/data status changed: {name}"
      let method ← checked (stringField row "resolution")
      if name == `cardQuot_pow_of_prime then
        unless method == "exact-original-type-native-theorem-proof" && isProof &&
            Expr.equal value (Lean.mkConst name (params.map Level.param)) do
          throwError "Only the exact native CardPow theorem proof may override its archived old proof body"
        cardPowCount := cardPowCount + 1
      else
        unless method == "genuine-original-complete-body" do throwError "Original source body was replaced: {name}"
        if isProof then genuineProofCount := genuineProofCount + 1 else dataCount := dataCount + 1
      result := { result with sourceCompatibilityValues := result.sourceCompatibilityValues.push (name, (params, value)) }
      reports := reports.push (Json.mkObj [
        ("original", toJson name.toString), ("originalName", encodeName name),
        ("levelParams", Json.arr (params.toArray.map encodeName)),
        ("resolution", toJson method), ("isProposition", toJson isProof),
        ("standaloneTargetIdentity", Json.null),
        ("leafJob", ← checked (field receipt "job_id")),
        ("viewPath", ← checked (field leaf "viewPath")),
        ("typeRoot", toJson typeRoot), ("valueRoot", toJson valueRoot),
        ("completeTypeAndValueRetainedInExactExprDag", toJson true),
        ("exactOriginalTypeKernelChecked", toJson true),
        ("completeValueKernelCheckedAtExactOriginalType", toJson true),
        ("typeAxioms", toJson (taxs.map Name.toString)), ("valueAxioms", toJson (axs.map Name.toString)),
        ("publicConsumerFullKernelEqualityRequired", toJson true)])
  unless seen.size == 35 && expectedNames.all seen.contains && ringCount == 2 &&
      dataCount == 8 && genuineProofCount == 26 && cardPowCount == 1 do
    throwError "Exact accepted source DAG35/data8/genuineproof26/nativeCardPow1 coverage differs"
  logInfo "Validated complete source types and values for35 source DAG declarations"
  return (result, Json.mkObj [
    ("schema", toJson "tate-theta-adic-source-dag-compatibility-result-v1"),
    ("requiredOriginalRecordCount", toJson seen.size), ("genuineOriginalDataCount", toJson dataCount),
    ("genuineOriginalProofBodyCount", toJson genuineProofCount), ("nativeCardPowProofCount", toJson cardPowCount),
    ("standardNativeProofCountIncludingRing", toJson (2 : Nat)),
    ("completeTypeValueChecksPassed", toJson true), ("entries", Json.arr reports),
    ("unusedOriginalProofArchiveCount", toJson (15 : Nat)),
    ("publicRawSignatureBinderGuardsAndFullDataEqualityRemainRequired", toJson true)])


-- Insert inside namespace FoundationAudit, after checked and the existing
-- Name/Level/Binder codecs. Roots must already be metadata-erased.

structure ExprDagEncoder where
  nodes : Array Json := #[]
  index : Lean.ExprStructMap Nat := {}
  deriving Inhabited

abbrev ExprDagM := StateT ExprDagEncoder MetaM

/-- Intern by Expr.equal, which preserves binder Names and BinderInfo. -/
partial def addExpr (e : Expr) : ExprDagM Nat := do
  let initial ← get
  if let some ref := initial.index[(⟨e⟩ : ExprStructEq)]? then
    return ref
  let payload : Json ← match e with
    | .bvar i => pure (node "bvar" [("index", toJson i)])
    | .sort u => do
        let encoded ← liftM (checked (encodeLevel u))
        pure (node "sort" [("level", encoded)])
    | .const n us => do
        let levels ← liftM (checked (us.toArray.mapM encodeLevel))
        pure (node "const" [("name", encodeName n), ("levels", Json.arr levels)])
    | .app f a => do
        let fnRef ← addExpr f
        let argRef ← addExpr a
        pure (node "app" [("fn", toJson fnRef), ("arg", toJson argRef)])
    | .lam n t b bi => do
        let typeRef ← addExpr t
        let bodyRef ← addExpr b
        pure (node "lam" [("name", encodeName n), ("type", toJson typeRef),
          ("body", toJson bodyRef), ("binder", toJson (encodeBinder bi))])
    | .forallE n t b bi => do
        let typeRef ← addExpr t
        let bodyRef ← addExpr b
        pure (node "forall" [("name", encodeName n), ("type", toJson typeRef),
          ("body", toJson bodyRef), ("binder", toJson (encodeBinder bi))])
    | .letE n t v b nd => do
        let typeRef ← addExpr t
        let valueRef ← addExpr v
        let bodyRef ← addExpr b
        pure (node "let" [("name", encodeName n), ("type", toJson typeRef),
          ("value", toJson valueRef), ("body", toJson bodyRef), ("nondependent", toJson nd)])
    | .lit (.natVal n) => pure (node "nat" [("value", toJson n)])
    | .lit (.strVal s) => pure (node "string" [("value", toJson s)])
    | .proj n i b => do
        let bodyRef ← addExpr b
        pure (node "proj" [("name", encodeName n), ("index", toJson i), ("body", toJson bodyRef)])
    | .mdata _ _ => throwError "Expr DAG requires metadata-erased roots; metadata was not discarded"
    | .fvar _ => throwError "Free variable in Expr DAG input"
    | .mvar _ => throwError "Expression metavariable in Expr DAG input"
  let current ← get
  let ref := current.nodes.size
  set { current with nodes := current.nodes.push payload,
                     index := current.index.insert (⟨e⟩ : ExprStructEq) ref }
  return ref


/-- Finalize only after one strict round trip for every original root. -/
def finishExprDag (encoder : ExprDagEncoder) (rootRefs : Array Nat)
    (originalRoots : Array Expr) : MetaM Json := do
  unless rootRefs.size == originalRoots.size do
    throwError "Expr DAG root references and original roots differ in count"
  let dag := Json.mkObj [("schema", toJson "foundation-expr-dag-v1"),
    ("nodes", Json.arr encoder.nodes), ("roots", toJson rootRefs)]
  let decoded ← checked (decodeExprDag dag)
  for i in [:rootRefs.size] do
    let ref := rootRefs[i]!
    let some actual := decoded[ref]? | throwError "Expr DAG root {i} is absent"
    unless Expr.equal originalRoots[i]! actual do
      throwError "Expr DAG strict Expr.equal round trip failed at root {i} (node {ref})"
  return dag


abbrev SplitEvidenceDagRef := IO.Ref (ExprDagEncoder × Array Nat × Array Expr)

def saveEvidenceExpr (dagStore : SplitEvidenceDagRef) (e : Expr) : MetaM Json := do
  requireClosed "complete shared evidence DAG root" e
  let (state, roots, originals) ← dagStore.get
  let (ref, next) ← (addExpr e).run state
  dagStore.set (next, roots.push ref, originals.push e)
  return Json.mkObj [("schema", toJson "foundation-expr-dag-root-v1"), ("root", toJson ref)]

def finishSplitEvidenceDag (dagStore : SplitEvidenceDagRef) : MetaM Json := do
  let (state, roots, originals) ← dagStore.get
  let dag ← finishExprDag state roots originals
  return Json.mkObj [("exprDag", dag), ("rootCount", toJson roots.size),
    ("allRootsStrictExprEqualRoundTrip", toJson true),
    ("includesFullNamesBinderNamesBinderInfoAndUniverseLevels", toJson true)]

-- Diagnostic only. An emitted candidate is not an accepted relaxation.
structure BatchViews where
  sourceView : Expr
  targetView : Expr
  sourceRestored : Expr
  targetRestored : Expr
  slots : Array Json

-- Output recipe only. The existing mathematical BinderInfo comparisons below
-- still run on the original expressions. Resolve the named root in the enclosing
-- signature report, follow expressionPath, then run the unchanged traversal.
private def binderTraversalRef (signatureRootField expressionPath traversal : String) : Json :=
  Json.mkObj [("encoding", toJson "exact-signature-dag-binder-traversal-v1"),
    ("rootFieldScope", toJson "enclosing signature report"),
    ("signatureRootField", toJson signatureRootField),
    ("relativeExpressionPath", toJson expressionPath), ("traversal", toJson traversal),
    ("initialBinderPlacementPath", toJson "root"), ("expandEveryDAGOccurrence", toJson true)]

private def strictBinderShape (s t : Expr) : Bool :=
  binderInventory s == binderInventory t && binderPlacement s == binderPlacement t

private def batchOwnedClosed (rs : Relocations) (owners : Array Name) (label : String) (e : Expr) : MetaM Unit := do
  requireClosed label e
  for dep in e.getUsedConstants do allowedOwner rs owners dep
  ensureStandard label (← expressionAxioms e)

private def batchPathCheck (label : String) (action : MetaM α) : MetaM α := do
  logInfo s!"Exact path check start: {label}"
  let (result, ticks) ← boundedMetaAuditUnit label action
  logInfo s!"Exact path check passed: {label}; internal heartbeat ticks {ticks}"
  return result

-- Read the consuming Pi from the actual head declaration and supplied arguments.
-- inferType on the entire large partial application is unnecessary.
private def batchConsumingFunctionType (label : String) (fn : Expr) : MetaM Expr :=
  batchPathCheck label do
    let head := fn.getAppFn
    let mut type ← match head with
      | .const n us => do
        let ci ← getConstInfo n
        pure (ci.type.instantiateLevelParams ci.levelParams us)
      | .fvar id => do
        let d ← id.getDecl
        pure d.type
      | _ => inferType head
    for a in fn.getAppArgs do
      let pi ← match type with
        | .forallE .. => pure type
        | _ => whnf type
      let .forallE _ _ body _ := pi | throwError "Actual function type is not a Pi at {label}"
      type := body.instantiate1 a
    match type with
    | .forallE .. => pure type
    | _ => whnf type

private def batchJoin (s t sr tr : Expr) (a b : BatchViews) : BatchViews :=
  ⟨s, t, sr, tr, a.slots ++ b.slots⟩

private partial def eraseAdicSeedLevelNames : Level → Level
  | .param _ => .param `_initialThetaAdicSeedUniverse
  | .succ u => .succ (eraseAdicSeedLevelNames u)
  | .max a b => .max (eraseAdicSeedLevelNames a) (eraseAdicSeedLevelNames b)
  | .imax a b => .imax (eraseAdicSeedLevelNames a) (eraseAdicSeedLevelNames b)
  | u => u

private def eraseAdicSeedExprLevels (e : Expr) : Expr := e.replace fun node =>
  match node with
  | .sort u => some (.sort (eraseAdicSeedLevelNames u))
  | .const n us => some (.const n (us.map eraseAdicSeedLevelNames))
  | _ => none

private def exactAdicSourceBoundary? (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name)
    (ctx : Array Expr) (path : String) (source target : Expr) : MetaM (Option BatchViews) := withCurrHeartbeats do
  unless source.getAppFn.isLambda && target.getAppFn.isConst do return none
  let targetName := target.getAppFn.constName!
  let some seed := rs.sourceCompatibilityValues.find? (·.1 == targetName) | return none
  let sameSeed ← batchPathCheck s!"exact accepted DAG seed identity {targetName} at {path}" do
    pure ((eraseAdicSeedExprLevels source.getAppFn).equal (eraseAdicSeedExprLevels seed.2.2))
  unless sameSeed do return none
  -- This exact old API computational boundary is supplied by the actual A19/B16
  -- complete DAG. It is separate from the non-Prop typeclass argument policy.
  let (cs, ct) ← batchPathCheck s!"close exact API occurrence over full existing context {targetName} at {path}" do
    return (← mkLambdaFVars ctx source, ← mkLambdaFVars ctx target)
  batchPathCheck s!"complete accepted original adic API occurrence {targetName} at {path}" do
    kernelTermEq s!"complete accepted original adic API occurrence {targetName} at {path}" cs ct
  let st ← batchPathCheck s!"complete original adic API inferred type {targetName} at {path}"
    (kernelCheck "complete original adic API application type" cs)
  let tt ← batchPathCheck s!"complete actual native adic API inferred type {targetName} at {path}"
    (kernelCheck "complete actual native API application type" ct)
  let closureTerms := #[cs, ct, st, tt]
  for i in [:closureTerms.size] do
    let term := closureTerms[i]!
    batchPathCheck s!"complete exact API owner and axiom closure {targetName} term{i} at {path}" do
      batchOwnedClosed rs owners path term
  let row ← batchPathCheck s!"complete exact API evidence serialization {targetName} at {path}" do
    return Json.mkObj [
    ("kind", toJson "exact-accepted-original-adic-dag-api-boundary"),
    ("path", toJson path), ("originalStandardName", toJson targetName.toString),
    ("originalStandardNameExpr", encodeName targetName),
    ("actualSourceDagJobs", toJson #["ci-014497-4264b653", "ci-014507-f12c827f"]),
    ("completeSourceDataExpression", ← saveEvidenceExpr dagStore cs),
    ("completeTargetDataExpression", ← saveEvidenceExpr dagStore ct),
    ("completeSourceDataType", ← saveEvidenceExpr dagStore st),
    ("completeTargetDataType", ← saveEvidenceExpr dagStore tt),
    ("sourceRawBinderInventory", binderTraversalRef "completeFaithfulReplaySignature" path "binderInventory"),
    ("targetRawBinderInventory", binderTraversalRef "completeTargetSignature" path "binderInventory"),
    ("sourceRawBinderPlacement", binderTraversalRef "completeFaithfulReplaySignature" path "binderPlacement"),
    ("targetRawBinderPlacement", binderTraversalRef "completeTargetSignature" path "binderPlacement"),
    ("completeClosedTypesAndValuesKernelEqual", toJson true),
    ("notANewNativeProofReplacement", toJson true),
    ("allDependenciesHaveAllowedOwners", toJson true),
    ("allAxiomsStandardOnly", toJson true), ("viewNeverUsedAsKernelInput", toJson true)]
  let marker := Expr.sort .zero
  return some ⟨marker, marker, source, target, #[row]⟩

-- Views are used only for BinderInfo accounting, never as kernel inputs.
partial def batchSignatureViews (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name)
    (ctx : Array Expr) (path : String) (source target : Expr) : MetaM BatchViews := withCurrHeartbeats do
  let (sameRawShape, _) ← boundedMetaAuditUnit s!"exact raw binder shape {path}" (pure (strictBinderShape source target))
  if sameRawShape then return ⟨source, target, source, target, #[]⟩
  if let some boundary ← exactAdicSourceBoundary? dagStore rs owners ctx path source target then
    return boundary
  let result ← match source, target with
  | .app sf sa, .app tf ta => do
    let mut argumentViews : Option BatchViews := none
    if !strictBinderShape sa ta then
      let tft ← batchConsumingFunctionType s!"target consuming function {path}" tf
      let sft ← batchConsumingFunctionType s!"source consuming function {path}" sf
      if let .forallE _ sd _ .instImplicit := sft then
        if let .forallE _ td _ .instImplicit := tft then
          let st := sd.headBeta
          let tt := td.headBeta
          if let .const sc _ := st.getAppFn then
            if let .const tc _ := tt.getAppFn then
              let isSameNonPropClass ← batchPathCheck s!"both actual consumed domains are the same non-Prop class {path}" do
                return sc == tc && isClass (← getEnv) sc && !(← isProp st) && !(← isProp tt)
              if isSameNonPropClass then
                let exactSlot ← withCurrHeartbeats do
                  let (cs, ct, cst, ctt) ← batchPathCheck s!"close complete class data and types {path}.arg" do
                    return (← mkLambdaFVars ctx sa, ← mkLambdaFVars ctx ta,
                      ← mkForallFVars ctx st, ← mkForallFVars ctx tt)
                  batchPathCheck s!"complete consumed instance domains {path}.arg" do
                    kernelTypeEq s!"complete consumed instance parameter domains {path}"
                      (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
                  batchPathCheck s!"complete closed data instance types {path}.arg" do
                    kernelTypeEq s!"complete closed data instance types {path}" cst ctt
                  batchPathCheck s!"complete closed data instance values {path}.arg" do
                    kernelTermEq s!"complete closed non-Prop typeclass data values {path}" cs ct
                  let closureTerms := #[cs, ct, cst, ctt]
                  for i in [:closureTerms.size] do
                    batchPathCheck s!"complete class data owner/axiom closure {path}.arg term{i}" do
                      batchOwnedClosed rs owners path closureTerms[i]!
                  let row ← batchPathCheck s!"complete shared DAG class data evidence {path}.arg" do
                    return Json.mkObj [
                    ("path", toJson (path ++ ".arg")), ("contextSize", toJson ctx.size),
                    ("applicationHeadSource", ← saveEvidenceExpr dagStore (← mkLambdaFVars ctx sf.getAppFn)),
                    ("applicationHeadTarget", ← saveEvidenceExpr dagStore (← mkLambdaFVars ctx tf.getAppFn)),
                    ("applicationArgumentIndex", toJson sf.getAppArgs.size),
                    ("bothConsumedBinders", toJson "instImplicit"),
                    ("instanceClass", toJson sc.toString), ("isProp", toJson false),
                    ("sourceRawBinderInventory", binderTraversalRef "completeFaithfulReplaySignature" (path ++ ".arg") "binderInventory"),
                    ("targetRawBinderInventory", binderTraversalRef "completeTargetSignature" (path ++ ".arg") "binderInventory"),
                    ("sourceRawBinderPlacement", binderTraversalRef "completeFaithfulReplaySignature" (path ++ ".arg") "binderPlacement"),
                    ("targetRawBinderPlacement", binderTraversalRef "completeTargetSignature" (path ++ ".arg") "binderPlacement"),
                    ("sourceClosedExpr", ← saveEvidenceExpr dagStore cs),
                    ("targetClosedExpr", ← saveEvidenceExpr dagStore ct),
                    ("sourceClosedType", ← saveEvidenceExpr dagStore cst),
                    ("targetClosedType", ← saveEvidenceExpr dagStore ctt),
                    ("completeConsumedParameterDomainsKernelEqual", toJson true),
                    ("completeClosedTypesKernelEqual", toJson true),
                    ("completeClosedValuesKernelEqual", toJson true),
                    ("allDependenciesHaveAllowedOwners", toJson true),
                    ("allAxiomsStandardOnly", toJson true),
                    ("viewNeverUsedAsKernelInput", toJson true)]
                  let marker := Expr.sort .zero
                  return (⟨marker, marker, sa, ta, #[row]⟩ : BatchViews)
                argumentViews := some exactSlot
    let av ← match argumentViews with
      | some v => pure v
      | none => batchSignatureViews dagStore rs owners ctx (path ++ ".arg") sa ta
    let fnViews ← batchSignatureViews dagStore rs owners ctx (path ++ ".fn") sf tf
    pure (batchJoin (.app fnViews.sourceView av.sourceView) (.app fnViews.targetView av.targetView)
      (.app fnViews.sourceRestored av.sourceRestored) (.app fnViews.targetRestored av.targetRestored) fnViews av)
  | .forallE sn sd sb si, .forallE tn td tb ti => do
    unless si == ti do throwError "Exposed/nested forall BinderInfo changed outside data slot at {path}"
    batchPathCheck s!"complete local binder type/value {path}" do
      kernelTypeEq s!"complete forall domains {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    let dv ← batchSignatureViews dagStore rs owners ctx (path ++ ".domain") sd td
    logInfo s!"Exact path local instance context start: {path}"
    withCurrHeartbeats <| withLocalDecl sn si sd fun x => do
      Lean.Core.checkMaxHeartbeats s!"exact path local instance registration {path}"
      logInfo s!"Exact path local instance context passed: {path}"
      let bv ← batchSignatureViews dagStore rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure (batchJoin
        (.forallE sn dv.sourceView (bv.sourceView.abstract #[x]) si)
        (.forallE tn dv.targetView (bv.targetView.abstract #[x]) ti)
        (.forallE sn dv.sourceRestored (bv.sourceRestored.abstract #[x]) si)
        (.forallE tn dv.targetRestored (bv.targetRestored.abstract #[x]) ti) dv bv)
  | .lam sn sd sb si, .lam tn td tb ti => do
    unless si == ti do throwError "Lambda BinderInfo changed outside data slot at {path}"
    batchPathCheck s!"complete local binder type/value {path}" do
      kernelTypeEq s!"complete lambda domains {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    let dv ← batchSignatureViews dagStore rs owners ctx (path ++ ".domain") sd td
    logInfo s!"Exact path local instance context start: {path}"
    withCurrHeartbeats <| withLocalDecl sn si sd fun x => do
      Lean.Core.checkMaxHeartbeats s!"exact path local instance registration {path}"
      logInfo s!"Exact path local instance context passed: {path}"
      let bv ← batchSignatureViews dagStore rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure (batchJoin
        (.lam sn dv.sourceView (bv.sourceView.abstract #[x]) si)
        (.lam tn dv.targetView (bv.targetView.abstract #[x]) ti)
        (.lam sn dv.sourceRestored (bv.sourceRestored.abstract #[x]) si)
        (.lam tn dv.targetRestored (bv.targetRestored.abstract #[x]) ti) dv bv)
  | .letE sn sd sv sb snon, .letE tn td tv tb tnon => do
    unless snon == tnon do throwError "Let dependency metadata differs at {path}"
    batchPathCheck s!"complete local binder type/value {path}" do
      kernelTypeEq s!"complete let types {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    batchPathCheck s!"complete local binder type/value {path}" do
      kernelTermEq s!"complete let values {path}" (← mkLambdaFVars ctx sv) (← mkLambdaFVars ctx tv)
    let dv ← batchSignatureViews dagStore rs owners ctx (path ++ ".type") sd td
    let vv ← batchSignatureViews dagStore rs owners ctx (path ++ ".value") sv tv
    logInfo s!"Exact path local let context start: {path}"
    withCurrHeartbeats <| withLetDecl sn sd sv (fun x => do
      Lean.Core.checkMaxHeartbeats s!"exact path local let registration {path}"
      logInfo s!"Exact path local let context passed: {path}"
      let bv ← batchSignatureViews dagStore rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure ⟨.letE sn dv.sourceView vv.sourceView (bv.sourceView.abstract #[x]) snon,
        .letE tn dv.targetView vv.targetView (bv.targetView.abstract #[x]) tnon,
        .letE sn dv.sourceRestored vv.sourceRestored (bv.sourceRestored.abstract #[x]) snon,
        .letE tn dv.targetRestored vv.targetRestored (bv.targetRestored.abstract #[x]) tnon,
        dv.slots ++ vv.slots ++ bv.slots⟩) (nondep := snon)
  | .proj sn si se, .proj tn ti te => do
    unless sn == tn && si == ti do throwError "Projection metadata changed at {path}"
    let v ← batchSignatureViews dagStore rs owners ctx (path ++ ".projected") se te
    pure ⟨.proj sn si v.sourceView, .proj tn ti v.targetView,
      .proj sn si v.sourceRestored, .proj tn ti v.targetRestored, v.slots⟩
  | .mdata sm se, .mdata tm te => do
    let v ← batchSignatureViews dagStore rs owners ctx path se te
    pure ⟨.mdata sm v.sourceView, .mdata tm v.targetView,
      .mdata sm v.sourceRestored, .mdata tm v.targetRestored, v.slots⟩
  | _, _ => throwError "Unaccounted raw BinderInfo difference at {path}; no typeclass data slot accepted"
  let (_, _) ← boundedMetaAuditUnit s!"complete exact Expr reconstruction and remaining binder shape {path}" do
    unless result.sourceRestored.equal source && result.targetRestored.equal target do
      throwError "Data-slot view is not exactly reversible at {path}"
    unless strictBinderShape result.sourceView result.targetView do
      throwError "Unaccounted BinderInfo remains outside exact data slots at {path}"
  return result

private partial def batchExposedDomainLoop (ctx : Array Expr) (source target : Expr)
    (rows : Array Json) : MetaM Json := do
  match source, target with
  | .forallE n sd sb si, .forallE _ td tb ti =>
    unless si == ti do throwError "Exposed BinderInfo differs at parameter {ctx.size}"
    kernelTypeEq s!"complete exposed domain {ctx.size}"
      (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    let row := Json.mkObj [("index", toJson ctx.size), ("binderInfo", toJson (encodeBinder ti)),
      ("completeClosedDomainKernelEqual", toJson true),
      ("rawDomainBinderInventoryEqual", toJson (binderInventory sd == binderInventory td)),
      ("rawDomainBinderPlacementEqual", toJson (binderPlacement sd == binderPlacement td))]
    withLocalDecl n si sd fun x =>
      batchExposedDomainLoop (ctx.push x) (sb.instantiate1 x) (tb.instantiate1 x) (rows.push row)
  | .forallE .., _ => throwError "Target exposed forall count differs"
  | _, .forallE .. => throwError "Source exposed forall count differs"
  | _, _ =>
    kernelTypeEq "complete syntactic result closed over exposed parameters"
      (← mkForallFVars ctx source) (← mkForallFVars ctx target)
    return Json.mkObj [("allExposedBinderFlagsStrict", toJson true), ("domains", Json.arr rows),
      ("completeClosedResultKernelEqual", toJson true), ("syntacticTelescopeNoWhnf", toJson true)]

private def batchExposedDomains (source target : Expr) : MetaM Json :=
  batchExposedDomainLoop #[] source target #[]


-- Recheck the exact actual prior source proposition and native proof in this job.
-- There is no named target identity and no source-body-success claim.
def installInitialThetaStandardCompatibility (rs : Relocations) (owners : Array Name)
    (config : Json) : MetaM (Relocations × Json) := do
  let binding ← checked (field config "initialThetaStandardCompatibility")
  let finite ← checked (field binding "finiteQuotients")
  let evidence ← checked (field finite "evidence")
  let readBound := fun (key : String) => do
    let b ← checked (field evidence key)
    let fresh ← jsonFile (← checked (stringField b "path"))
    unless fresh == (← checked (field b "contents")) && (← checked (stringField b "sha256")).length == 64 do
      throwError "Exact prior finite-quotients evidence changed: {key}"
    pure fresh
  let source ← readBound "sourceFacts"
  let platform ← readBound "platformFacts"
  let sr ← readBound "sourceReceipt"
  let pr ← readBound "platformReceipt"
  unless (← checked (stringField sr "job_id")) == "ci-014215-2414b895" &&
      (← checked (stringField pr "job_id")) == "ci-014243-25ac457f" do throwError "Wrong actual standard query identities"
  for r in #[sr, pr] do
    unless (← checked (stringField r "status")) == "succeeded" &&
        (← checked ((← checked (field r "result")).getObjValAs? Nat "exit_code")) == 0 do
      throwError "No successful actual standard query"
    let snapshot ← checked (field (← checked (field r "result")) "snapshot")
    unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
        (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Wrong standard evidence workspace mode"
  unless (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" &&
      (← checked (stringField platform "compilerVersion")) == Lean.versionString &&
      (← checked (source.getObjValAs? Nat "selectedOriginalScopeCount")) == 78 &&
      (← checked (source.getObjValAs? Nat "relevantStandardNameCount")) == 270 &&
      (← checked (platform.getObjValAs? Nat "relevantStandardNameCount")) == 270 do
    throwError "Actual prior provenance/compiler dimensions differ"
  let priorProvenance ← checked (field binding "priorProvenance")
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field source key)) == (← checked (field platform key)) &&
        (← checked (field source key)) == (← checked (field priorProvenance key)) do
      throwError "Prior standard provenance was silently changed to current scope"
  let original := `NumberField.RingOfIntegers.instHasFiniteQuotients
  let env ← getEnv
  unless !(env.contains original) && rs.standardProofValues.isEmpty &&
      !(rs.any (·.original == original)) && Lean.isClass env `Ring.HasFiniteQuotients do
    throwError "Absent source theorem/class/identity conditions changed"
  let shapeChecks ← checked (arrayField platform "originalCurrentStandardShapeChecks")
  unless shapeChecks.size == 7 do throwError "Expected all7 actual prior standard class API checks"
  for row in shapeChecks do
    unless (← checked (row.getObjValAs? Bool "succeeded")) do throwError "Prior source/current standard API check failed"
  let actualFacts ← checked (arrayField platform "facts")
  unless actualFacts.size == 7 do throwError "Expected7 current standard API records"
  for row in actualFacts do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    let ci ← getConstInfo name
    unless (← checked (encodeExpr ci.type)) == (← checked (field row "elaboratedExpr")) do
      throwError "Current standard API type changed after actual prior query: {name}"
    let value ← match ci.value? (allowOpaque := true) with
      | none => pure Json.null
      | some e => checked (encodeExpr e)
    unless value == (← checked (field row "valueExpr")) do
      throwError "Current standard API value changed after actual prior query: {name}"
  let records ← checked (arrayField source "facts")
  unless records.size == 8 do throwError "Expected8 original standard records"
  let exact := records.filter fun r => (stringField r "name").toOption == some original.toString
  unless exact.size == 1 do throwError "No exact actual original standard theorem record"
  let record := exact[0]!
  unless (← checked (stringField record "constantKind")) == "theorem" &&
      (← checked (record.getObjValAs? Bool "isProposition")) &&
      (← checked (record.getObjValAs? Bool "isInstance")) &&
      !(← checked (record.getObjValAs? Bool "hasSorryAx")) do throwError "Original standard wrapper is not an actual Prop theorem instance"
  let bodyFailure ← checked (field platform "genuineSourceBodyAttempt")
  unless !(← checked (bodyFailure.getObjValAs? Bool "succeeded")) do throwError "Original standard-body API failure must remain false"
  let native ← checked (field platform "nativeProofAttempt")
  for key in #["succeeded", "kernelCheckedExactSourceType", "dependencyOwnersStandardOnly"] do
    unless (← checked (native.getObjValAs? Bool key)) do throwError "No actual native standard proof evidence"
  unless !(← checked (native.getObjValAs? Bool "hasSorryAx")) do throwError "Native proof has sorryAx"
  let params ← namesFromJson (← checked (field record "levelParams"))
  let nparams ← namesFromJson (← checked (field finite "nativeLevelParams"))
  unless params.length == 1 && nparams == [Name.num (Name.str .anonymous "_finiteQuotientsQueryUniverse") 0] do
    throwError "Exact original/native standard proof universe map changed"
  let type ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let nativeType := (← checked (decodeExpr rs (← checked (field native "type")))).instantiateLevelParams nparams (params.map Level.param)
  let value := (← checked (decodeExpr rs (← checked (field native "value")))).instantiateLevelParams nparams (params.map Level.param)
  kernelTypeEq "exact original standard proposition versus restored native proof type" type nativeType
  unless binderInventory type == (← checked (record.getObjValAs? (Array String) "binderInventory")) &&
      strictBinderShape type nativeType do throwError "Exact standard proposition BinderInfo changed"
  let canonical : List Level := (canonicalLevels params.length).map Level.param
  let ct := type.instantiateLevelParams params canonical
  let cv := value.instantiateLevelParams params canonical
  unless (← isProp ct) do throwError "Standard compatibility may only install a proof"
  let inferred ← kernelCheck "actual native standard proof rechecked in current job" cv
  kernelTypeEq "native standard proof inhabits exact original full proposition" inferred ct
  unless strictBinderShape inferred ct do throwError "Current native proof inferred type BinderInfo changed"
  let standardPrefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
  for e in #[ct, cv] do
    ensureStandard "finite-quotients exact proposition/native proof" (← expressionAxioms e)
    for dep in e.getUsedConstants do
      allowedOwner rs owners dep
      let some m := moduleOf (← getEnv) dep | throwError "Native standard proof dependency has no imported owner"
      unless standardPrefixes.any (·.isPrefixOf m) do throwError "Native standard proof uses project input"
  let result := {rs with standardProofValues := #[(original, (params, value))]}
  return (result, Json.mkObj [
    ("schema", toJson "initial-theta-exact-finite-quotients-native-proof-replay-v1"),
    ("original", toJson original.toString), ("standaloneTargetIdentity", Json.null),
    ("resolution", toJson "kernel-checked-native-proof-at-exact-original-type"),
    ("originalSourceBodyAttempt", bodyFailure), ("priorProvenanceRetained", toJson true),
    ("sourceRecord", record), ("nativeProofAttempt", native),
    ("currentExactOriginalFullPropositionKernelChecked", toJson true),
    ("currentNativeValueKernelCheckedAtExactOriginalType", toJson true),
    ("currentFullBinderInfoPreserved", toJson true), ("currentOwnersStandardOnly", toJson true),
    ("currentAxiomsStandardOnly", toJson true), ("allRequiredKernelChecksPassed", toJson true),
    ("wholeConsumerDataKernelEqualityStillRequired", toJson true)])

structure InitialThetaReplay where
  expr : Expr
  restored : Expr
  changes : Array Json

private partial def eraseReplayLevelNames : Level → Level
  | .param _ => .param `_initialThetaReplayUniverse
  | .succ u => .succ (eraseReplayLevelNames u)
  | .max a b => .max (eraseReplayLevelNames a) (eraseReplayLevelNames b)
  | .imax a b => .imax (eraseReplayLevelNames a) (eraseReplayLevelNames b)
  | u => u

private def eraseReplayExprLevelNames (e : Expr) : Expr := e.replace fun node =>
  match node with
  | .sort u => some (.sort (eraseReplayLevelNames u))
  | .const n us => some (.const n (us.map eraseReplayLevelNames))
  | _ => none

private def initialThetaLiesOverConsumers : Array Name := #[
  `Iut.ValuationSection.casesOn, `Iut.ValuationSection.mk, `Iut.ValuationSection.rec,
  `Iut.ValuationSection.recOn, `Iut.ValuationSection.sectInf_liesOver,
  `Iut.ValuationSection.mk._flat_ctor, `Iut.ValuationSection.mk.inj,
  `Iut.ValuationSection.mk.injEq, `Iut.ValuationSection.mk.noConfusion,
  `Iut.ValuationSection.mk.sizeOf_spec]

def verifyInitialThetaSemanticBridges (config : Json) : MetaM Json := do
  let compat ← checked (field config "initialThetaStandardCompatibility")
  let binding ← checked (field compat "semanticBridges")
  let mut reports := #[]
  for key in #["original435", "native433"] do
    let b ← checked (field binding key)
    let receiptBinding ← checked (field b "receipt")
    let receipt ← jsonFile (← checked (stringField receiptBinding "path"))
    unless receipt == (← checked (field receiptBinding "contents")) &&
        (← checked (stringField receiptBinding "sha256")).length == 64 &&
        (← checked (stringField receipt "job_id")) == (← checked (stringField b "job_id")) &&
        (← checked (stringField receipt "status")) == "succeeded" do
      throwError "Actual standard predicate semantic bridge is pending or changed: {key}"
    let result ← checked (field receipt "result")
    unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Semantic bridge compiler failed"
    let snapshot ← checked (field result "snapshot")
    unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
        (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Wrong semantic bridge workspace mode"
    let sourceBinding ← checked (field b "source")
    let text ← IO.FS.readFile (← checked (stringField sourceBinding "path"))
    unless text == (← checked (stringField sourceBinding "text")) &&
        (← checked (stringField sourceBinding "sha256")).length == 64 do throwError "Actual semantic bridge source changed"
    reports := reports.push b
  for name in #[`InitialThetaStandardCompatibilityDraft.restrictionBodyEq,
      `InitialThetaStandardCompatibilityDraft.source435IffNative433,
      `InitialThetaStandardCompatibilityDraft.native433IffRestrictionEquality] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "Missing complete current semantic bridge proof"
    kernelTypeEq "current semantic bridge proof inhabits its complete type" (← kernelCheck name.toString value) ci.type
    ensureStandard name.toString (← collectAxioms name)
  return Json.mkObj [("actualSourceAndNativeBridgeBindings", Json.arr reports),
    ("currentCompleteBridgeProofsKernelChecked", toJson true), ("axiomsStandardOnly", toJson true),
    ("classIdentityClaimedDefinitionallyEqual", toJson false), ("allRequiredKernelChecksPassed", toJson true)]

private def closedReplayJson (dagStore : SplitEvidenceDagRef) (ctx : Array Expr) (e : Expr) : MetaM Json := do
  saveEvidenceExpr dagStore (← mkLambdaFVars ctx e)

partial def replayInitialThetaExpr (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name)
    (original : Name) (ctx : Array Expr) (path : String) (e : Expr) : MetaM InitialThetaReplay := do
  if e.isAppOf ``AbsoluteValue.LiesOver then
    unless initialThetaLiesOverConsumers.contains original do throwError "Unapproved original standard predicate consumer"
    let a := e.getAppArgs
    unless a.size == 11 do throwError "Expected one maximal complete original11argument standard predicate application"
    let l := a[0]!
    let k := a[1]!
    let s := a[2]!
    let w := a[9]!
    let v := a[10]!
    -- These types must already have Field instances in the original telescope.
    let fk ← synthInstance (← mkAppM ``Field #[k])
    let fl ← synthInstance (← mkAppM ``Field #[l])
    let canonicalKSemiring ← synthInstance (← mkAppM ``CommSemiring #[k])
    let canonicalLSemiring ← synthInstance (← mkAppM ``Semiring #[l])
    for (label, before, after) in #[
        ("complete K CommSemiring", a[3]!, canonicalKSemiring),
        ("complete L Semiring", a[4]!, canonicalLSemiring)] do
      kernelTermEq s!"standard API complete computational structure {label}"
        (← mkLambdaFVars ctx before) (← mkLambdaFVars ctx after)
    let scalarType ← mkAppM ``SMul #[k, l]
    let scalar ← synthInstance scalarType
    let faithfulType ← mkAppOptM ``FaithfulSMul #[some k, some l, some scalar]
    unless faithfulType.isAppOf ``FaithfulSMul && faithfulType.getAppArgs.size == 3 do
      throwError "FaithfulSMul must include its complete computational SMul argument"
    kernelTypeEq "original FaithfulSMul proof exact proposition"
      (← mkForallFVars ctx (← inferType a[6]!)) (← mkForallFVars ctx faithfulType)
    let after ← mkAppM ``AbsoluteValue.LiesOver #[w, v]
    let b := after.getAppArgs
    unless after.isAppOf ``AbsoluteValue.LiesOver && b.size == 12 do throwError "Expected complete native12argument predicate"
    let targetKSemiring ← mkAppOptM ``CommRing.toCommSemiring #[some k, some b[3]!]
    let targetLSemiring ← mkAppOptM ``Ring.toSemiring #[some l,
      some (← mkAppOptM ``CommRing.toRing #[some l, some b[5]!])]
    kernelTermEq "old K CommSemiring versus actual native CommRing projection"
      (← mkLambdaFVars ctx a[3]!) (← mkLambdaFVars ctx targetKSemiring)
    kernelTermEq "old L Semiring versus actual native CommRing projection"
      (← mkLambdaFVars ctx a[4]!) (← mkLambdaFVars ctx targetLSemiring)
    -- All mathematical types, algebra data, ordered codomain data and values are retained.
    for (label, before, translated) in #[
        ("K", k, b[0]!), ("L", l, b[1]!), ("S", s, b[2]!),
        ("Algebra", a[5]!, b[6]!), ("PartialOrder S", a[7]!, b[7]!),
        ("Semiring S", a[8]!, b[9]!), ("w", w, b[10]!), ("v", v, b[11]!)] do
      kernelTermEq s!"standard predicate preserves full argument {label}"
        (← mkLambdaFVars ctx before) (← mkLambdaFVars ctx translated)
    let closedAfter ← mkForallFVars ctx after
    discard <| kernelCheck "complete native predicate closed over existing telescope" closedAfter
    let .const _ sourceLevels := e.getAppFn | throwError "Original predicate application lost constant head"
    let cloneName := ``InitialThetaStandardCompatibilityDraft.Source435.LiesOver
    unless (← getConstInfo cloneName).levelParams.length == sourceLevels.length do
      throwError "Exact source semantic model universe arity differs"
    let sourceModelApplication := mkAppN (mkConst cloneName sourceLevels) a
    let bridge ← mkAppM ``InitialThetaStandardCompatibilityDraft.source435IffNative433 #[w, v]
    let bridgeType ← inferType bridge
    unless bridgeType.isAppOf ``Iff && bridgeType.getAppArgs.size == 2 do throwError "No exact predicate Iff bridge"
    kernelTypeEq "exact original11arguments agree with semantic bridge source side"
      (← mkForallFVars ctx sourceModelApplication) (← mkForallFVars ctx bridgeType.getAppArgs[0]!)
    kernelTypeEq "native side of actual semantic Iff at exact existing fields"
      (← mkForallFVars ctx bridgeType.getAppArgs[1]!) closedAfter
    let closedBridge ← mkLambdaFVars ctx bridge
    discard <| kernelCheck "complete instantiated predicate Iff proof" closedBridge
    ensureStandard "instantiated standard predicate semantic bridge" (← expressionAxioms closedBridge)
    for term in #[fk, fl, after] do
      for dep in term.getUsedConstants do allowedOwner rs owners dep
    let sourceArguments ← a.mapM (closedReplayJson dagStore ctx)
    let targetArguments ← b.mapM (closedReplayJson dagStore ctx)
    let report := Json.mkObj [
      ("kind", toJson "exact-source435-predicate-to-native433-semantic-translation"),
      ("path", toJson path), ("sourceArgumentCount", toJson (11 : Nat)),
      ("targetArgumentCount", toJson (12 : Nat)), ("contextSize", toJson ctx.size),
      ("completePreReplayApplication", ← closedReplayJson dagStore ctx e),
      ("completeReplayApplication", ← closedReplayJson dagStore ctx after),
      ("sourceArguments", Json.arr sourceArguments), ("targetArguments", Json.arr targetArguments),
      ("existingFieldK", ← closedReplayJson dagStore ctx fk), ("existingFieldL", ← closedReplayJson dagStore ctx fl),
      ("completeSourceModelApplication", ← closedReplayJson dagStore ctx sourceModelApplication),
      ("completeInstantiatedPredicateIffProof", ← saveEvidenceExpr dagStore closedBridge),
      ("addedTelescopeBinders", toJson (0 : Nat)), ("allCompleteArgumentRelationsKernelChecked", toJson true),
      ("rawApplicationClaimedKernelChecked", toJson false),
      ("sourceAndNativeClassesClaimedDefinitionallyEqual", toJson false),
      ("semanticPredicateTranslation", toJson true), ("nativeApplicationKernelChecked", toJson true)]
    return ⟨after, e, #[report]⟩
  if e.isApp && e.getAppFn.isLambda then
    -- Complete source DAG values were independently kernel checked at setup.
    -- Do not walk their internal finite-place/valuation implementation again.
    if rs.sourceCompatibilityValues.any (fun seed =>
        (eraseReplayExprLevelNames e.getAppFn).equal (eraseReplayExprLevelNames seed.2.2)) then
      return ⟨e, e, #[]⟩
    if let some seed := rs.standardProofValues.find? (·.1 == `NumberField.RingOfIntegers.instHasFiniteQuotients) then
      if (eraseReplayExprLevelNames e.getAppFn).equal (eraseReplayExprLevelNames seed.2.2) then
        let after := e.headBeta
        unless !after.equal e do throwError "Exact native proof substitution has no head beta redex"
        kernelTermEq "exact installed standard proof head-beta replay"
          (← mkLambdaFVars ctx e) (← mkLambdaFVars ctx after)
        let row := Json.mkObj [("kind", toJson "exact-installed-finite-quotients-proof-head-beta"),
          ("path", toJson path), ("completeBefore", ← closedReplayJson dagStore ctx e),
          ("completeAfter", ← closedReplayJson dagStore ctx after),
          ("completeTypesAndProofValuesKernelEqual", toJson true)]
        return ⟨after, e, #[row]⟩
  let result : InitialThetaReplay ← match e with
  | .forallE n d body bi => do
    let dv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".domain") d
    withLocalDecl n bi dv.expr fun x => do
      let bv ← replayInitialThetaExpr dagStore rs owners original (ctx.push x) (path ++ ".body") (body.instantiate1 x)
      pure ⟨.forallE n dv.expr (bv.expr.abstract #[x]) bi,
        .forallE n dv.restored (bv.restored.abstract #[x]) bi, dv.changes ++ bv.changes⟩
  | .lam n d body bi => do
    let dv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".domain") d
    withLocalDecl n bi dv.expr fun x => do
      let bv ← replayInitialThetaExpr dagStore rs owners original (ctx.push x) (path ++ ".body") (body.instantiate1 x)
      pure ⟨.lam n dv.expr (bv.expr.abstract #[x]) bi,
        .lam n dv.restored (bv.restored.abstract #[x]) bi, dv.changes ++ bv.changes⟩
  | .app f a => do
    let fv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".fn") f
    let av ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".arg") a
    pure ⟨.app fv.expr av.expr, .app fv.restored av.restored, fv.changes ++ av.changes⟩
  | .letE n d value body nondep => do
    let dv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".type") d
    let vv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".value") value
    withLetDecl n dv.expr vv.expr (fun x => do
      let bv ← replayInitialThetaExpr dagStore rs owners original (ctx.push x) (path ++ ".body") (body.instantiate1 x)
      pure ⟨.letE n dv.expr vv.expr (bv.expr.abstract #[x]) nondep,
        .letE n dv.restored vv.restored (bv.restored.abstract #[x]) nondep,
        dv.changes ++ vv.changes ++ bv.changes⟩) (nondep := nondep)
  | .proj n i value => do
    let v ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".projected") value
    pure ⟨.proj n i v.expr, .proj n i v.restored, v.changes⟩
  | .mdata md value => do
    let v ← replayInitialThetaExpr dagStore rs owners original ctx path value
    pure ⟨.mdata md v.expr, .mdata md v.restored, v.changes⟩
  | _ => pure ⟨e, e, #[]⟩
  unless result.restored.equal e do throwError "Exact standard replay inverse did not reconstruct original expression"
  return result

def replayExactInitialThetaStandardApps (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name) (_config : Json)
    (original : Name) (source : Expr) : MetaM (Expr × Json) := do
  let result ← replayInitialThetaExpr dagStore rs owners original #[] "root" source
  unless result.restored.equal source do throwError "Whole exact standard replay is not reversible"
  return (result.expr, Json.mkObj [
    ("changes", Json.arr result.changes), ("exactExprEqualInverseReconstruction", toJson true),
    ("addedTelescopeBinders", toJson (0 : Nat)),
    ("rawOriginalClaimedKernelChecked", toJson false),
    ("allRequiredKernelChecksPassed", toJson true)])

def retryValueAndRuleChecks (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name) (config record : Json)
    (target : ConstantInfo) (sourceParams : List Name) (canonical targetLevels : List Level)
    (sourceType : Expr) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do throwError "Complete recursor/constructor computation shape changed"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  let mut valueCompared := false
  let mut replayReports := #[]
  let valueJson ← checked (field record "valueExpr")
  if !sourceProp && valueJson != Json.null then
    let decoded := (← checked (decodeExpr rs valueJson)).instantiateLevelParams sourceParams canonical
    let (value, report) ← replayExactInitialThetaStandardApps dagStore rs owners config original decoded
    let some targetValue := target.value? (allowOpaque := true) | throwError "Actual complete data value missing"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq "complete replayed data value inhabits complete replayed source type"
      (← kernelCheck original.toString value) sourceType
    kernelTermEq "complete faithful replayed computational source/current value" value targetValue
    for term in #[value, targetValue] do
      for dep in term.getUsedConstants do allowedOwner rs owners dep
      ensureStandard "complete data replay dependency axioms" (← expressionAxioms term)
    valueCompared := true
    replayReports := replayReports.push (Json.mkObj [("location", toJson "whole-computational-value"),
      ("completeDecodedSourceValue", ← saveEvidenceExpr dagStore decoded),
      ("completeReplayedSourceValue", ← saveEvidenceExpr dagStore value),
      ("completeActualTargetValue", ← saveEvidenceExpr dagStore targetValue),
      ("completeReplayedValueType", ← saveEvidenceExpr dagStore sourceType), ("replay", report)])
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut ruleCount := 0
  if let .recInfo recursor := target then
    unless rules.size == recursor.rules.length do throwError "Complete recursor rule count changed"
    for i in [:rules.size] do
      let decoded := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let (rhs, report) ← replayExactInitialThetaStandardApps dagStore rs owners config original decoded
      let actual := recursor.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      kernelTermEq s!"complete faithful replayed recursor RHS {i}" rhs actual
      for term in #[rhs, actual] do
        for dep in term.getUsedConstants do allowedOwner rs owners dep
        ensureStandard "complete recursor replay axioms" (← expressionAxioms term)
      replayReports := replayReports.push (Json.mkObj [("location", toJson s!"recursor-rule-{i}"),
        ("completeDecodedSourceRule", ← saveEvidenceExpr dagStore decoded),
        ("completeReplayedSourceRule", ← saveEvidenceExpr dagStore rhs),
        ("completeActualTargetRule", ← saveEvidenceExpr dagStore actual), ("replay", report)])
      ruleCount := ruleCount + 1
  else
    unless rules.isEmpty do throwError "Unexpected archived recursor rules"
  let structureJson ← checked (field record "structure")
  if structureJson != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name | throwError "Actual complete structure missing"
    unless (← checked (field structureJson "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do throwError "Complete structure metadata changed"
    let autos ← checked (arrayField structureJson "fieldAutoParamExprs")
    unless autos.size == info.fieldInfo.size do throwError "Structure autoParam count changed"
    for i in [:autos.size] do
      match autos[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some actual =>
        unless sourceJson != Json.null do throwError "Archived autoParam missing"
        let decoded := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let (value, report) ← replayExactInitialThetaStandardApps dagStore rs owners config original decoded
        let actual := actual.instantiateLevelParams target.levelParams targetLevels
        kernelTermEq "complete faithful replayed structure autoParam" value actual
        replayReports := replayReports.push (Json.mkObj [("location", toJson s!"structure-autoParam-{i}"),
          ("completeDecodedSourceAutoParam", ← saveEvidenceExpr dagStore decoded),
          ("completeReplayedSourceAutoParam", ← saveEvidenceExpr dagStore value),
          ("completeActualTargetAutoParam", ← saveEvidenceExpr dagStore actual), ("replay", report)])
      | sourceJson, none => unless sourceJson == Json.null do throwError "Actual autoParam missing"
  return Json.mkObj [("completeComputationalDataValueCompared", toJson valueCompared),
    ("proofValueComparisonOmittedForPropositions", toJson sourceProp),
    ("completeRecursorRulesCompared", toJson ruleCount), ("replayLocations", Json.arr replayReports),
    ("completeComputationShapeEqual", toJson true), ("kernelPropositionalValueEqualityUsed", toJson false)]

-- Independent logical checks retain the unchanged default heartbeat option.
-- No phase is accepted from a progress log; all phases must return successfully.
def retryDefaultPhase (label : String) (action : MetaM α) : MetaM α := do
  phaseTrace ("retry:" ++ label) "before"
  logInfo s!"Retry phase start: {label}"
  let (result, ticks) ← boundedMetaAuditUnit label action
  logInfo s!"Retry phase passed: {label}; internal heartbeat ticks {ticks}"
  phaseTrace ("retry:" ++ label) "after"
  return result

def splitSignatureCheck (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name) (config record : Json) (target : ConstantInfo) : MetaM Json := do
  let (original, sp, canonical, tl, raw, decodedSource, t, rawInventoryEqual, rawPlacementEqual, baseline) ← retryDefaultPhase "decode and raw signature serialization" do
    let original ← checked (decodeName (← checked (field record "nameExpr")))
    let sp ← namesFromJson (← checked (field record "levelParams"))
    unless sp.length == target.levelParams.length do throwError "Universe arity changed"
    let canonical : List Level := (canonicalLevels sp.length).map Level.param
    let some r := rs.find? (·.original == original) | throwError "No exact named map"
    let tl : List Level ← match r.permutation with
      | none => pure canonical
      | some p => do
        let reordered : Array Level ← checked (reorder p canonical.toArray)
        pure reordered.toList
    let rawRs := {rs with sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[]}
    let raw := (← checked (decodeExpr rawRs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical
    let decodedSource := (← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical
    let t := target.type.instantiateLevelParams target.levelParams tl
    unless binderInventory raw == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
      throwError "Original exported raw inventory serialization differs"
    let rawInventoryEqual := binderInventory raw == binderInventory t
    let rawPlacementEqual := binderPlacement raw == binderPlacement t
    let baseline := [("original", toJson original.toString), ("target", toJson target.name.toString),
      ("rawSignatureBinderInventoryEqual", toJson rawInventoryEqual),
      ("rawSignatureBinderPlacementEqual", toJson rawPlacementEqual),
      ("sourceRawBinderCount", toJson (binderInventory raw).size), ("targetRawBinderCount", toJson (binderInventory t).size),
      ("sourceSignatureSerializationValidated", toJson true)]
    return (original, sp, canonical, tl, raw, decodedSource, t, rawInventoryEqual, rawPlacementEqual, baseline)
  try
    let rawFailure ← retryDefaultPhase s!"raw target433 kernel failure {original}" do
      try
        discard <| kernelCheck "unmodified original raw signature in target433" raw
        pure (none : Option String)
      catch ex => pure (some (← ex.toMessageData.toString))
    unless rawFailure.isSome do throwError "Retry raw signature no longer has its actual recorded standard API failure"
    let (s, replayEvidence) ← retryDefaultPhase s!"exact standard API replay {original}"
      (replayExactInitialThetaStandardApps dagStore rs owners config original decodedSource)
    retryDefaultPhase s!"complete faithful signature and owner/axiom closure {original}" do
      kernelTypeEq s!"complete faithful replay signature {original}" s t
      for e in #[s, t] do batchOwnedClosed rs owners original.toString e
    let domains ← retryDefaultPhase s!"all complete exposed domains and result {original}" (batchExposedDomains s t)
    logInfo s!"Retry phase start: exact data slots and all remaining BinderInfo {original}; each path independently default200000"
    let views ← batchSignatureViews dagStore rs owners #[] "root" s t
    logInfo s!"Retry phase passed: exact data slots and all remaining BinderInfo {original}; checked path count {views.slots.size}"
    unless !rawInventoryEqual && !rawPlacementEqual do throwError "Original literal raw-false signature evidence changed"
    unless !views.slots.isEmpty || !(← checked (arrayField replayEvidence "changes")).isEmpty do
      throwError "Neither exact data slots nor exact standard API replay accounts for the raw difference"
    let valueEvidence := Json.mkObj [("status", toJson "requires independent whole-value sibling leaf"),
      ("mode", toJson "value"), ("noWholeValueAcceptanceClaimedFromSignatureLeaf", toJson true)]
    return ← retryDefaultPhase s!"complete evidence serialization {original}" do
      let replaySignatureJson ← saveEvidenceExpr dagStore s
      let sourceSignatureJson ← saveEvidenceExpr dagStore raw
      let targetSignatureJson ← saveEvidenceExpr dagStore t
      let sourceViewJson ← saveEvidenceExpr dagStore views.sourceView
      let targetViewJson ← saveEvidenceExpr dagStore views.targetView
      return Json.mkObj (baseline ++ [
        ("diagnosticPassed", toJson true), ("error", Json.null),
        ("completeUnmodifiedTypesKernelEqual", toJson false),
        ("rawOriginalTypeKernelCheckSucceeded", toJson false), ("rawOriginalTypeKernelError", toJson rawFailure),
        ("rawOriginalSignatureClaimedKernelChecked", toJson false),
        ("faithfulReplaySignatureKernelEqual", toJson true),
        ("completeFaithfulReplaySignature", replaySignatureJson),
        ("sourceReplayBinderCount", toJson (binderInventory s).size),
        ("standardApiReplayEvidence", replayEvidence),
        ("wholeValuesAndRecursorRules", valueEvidence),
        ("binderViewScope", toJson "faithful-replay-signature-versus-actual-target; original raw flags remain false"),
        ("exposedDomains", domains), ("changedDataSlots", Json.arr views.slots),
        ("exactExprEqualRoundTrip", toJson true), ("allOtherBinderInfoStrictlyEqual", toJson true),
        ("rawFalseRemainsLiteral", toJson (!rawInventoryEqual || !rawPlacementEqual)),
        ("completeSourceSignature", sourceSignatureJson),
        ("completeTargetSignature", targetSignatureJson),
        ("sourceBinderView", sourceViewJson),
        ("targetBinderView", targetViewJson),
        ("viewNeverUsedAsKernelInput", toJson true)])

  catch e =>
    return Json.mkObj (baseline ++ [("diagnosticPassed", toJson false),
      ("error", toJson (← e.toMessageData.toString)), ("acceptedCorrespondenceGenerated", toJson false)])


def splitSetup : TermElabM (Json × Relocations × Array Name × Json × Json) := do
  let (config, rs, owners, compatibility) ← withCurrHeartbeats do
    unless Lean.versionString == "4.33.1" && maxHeartbeats.get (← getOptions) == 200000 do
      throwError "Exact target compiler and unchanged default budget required"
    let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
    let rs ← readRelocations config
    let modules ← (← checked (arrayField config "modules")).mapM fun r => return (← checked (stringField r "target")).toName
    let deps := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
    let prefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
    let env ← getEnv
    let mut owners := #[]
    for m in env.header.moduleNames do
      unless prefixes.any (·.isPrefixOf m) || (modules ++ deps).contains m do throwError "Forbidden module {m}"
      owners := owners.push m
    let (facts, _) ← boundedMetaAuditUnit "actual platform facts" (verifyPlatformHelperFacts config)
    let ((rs, _), _) ← boundedMetaAuditUnit "four genuine original source proofs" (installExactInitialThetaProofValues rs owners config facts)
    let ((rs, finite), _) ← boundedMetaAuditUnit "exact standard Prop proof" (installInitialThetaStandardCompatibility rs owners config)
    let ((rs, adic), _) ← boundedMetaAuditUnit "all35accepted genuine adic DAG types and values" (installInitialThetaAdicSourceDagValues rs owners config)
    let (bridges, _) ← boundedMetaAuditUnit "actual source/native predicate bridges" (verifyInitialThetaSemanticBridges config)
    return (config, rs, owners, Json.mkObj [("finiteQuotients", finite), ("adicCompleteSourceTypeValueReplay", adic),
      ("predicateSemanticBridges", bridges), ("allRequiredKernelChecksPassed", toJson true)])
  let binding ← checked (field config "singleSourceDeclaration")
  let view ← jsonFile (← checked (stringField binding "path"))
  unless (← checked (stringField view "schema")) == "initial-theta-exact-single-source-record-view-v1" &&
      (← checked (view.getObjValAs? Nat "completeOriginalRecordCount")) == 232 &&
      (← checked (view.getObjValAs? Nat "completeOriginalSelectedCount")) == 204 do throwError "Wrong source record view"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field view key)) == (← checked (field config key)) do throwError "Source provenance changed"
  let record ← checked (field view "record")
  unless (← checked (field record "name")) == (← checked (field config "splitOriginal")) &&
      (← checked (record.getObjValAs? Bool "selected")) do throwError "Wrong exact selected split declaration"
  return (config, rs, owners, compatibility, record)

def splitValueCheck (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name) (config record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sp ← namesFromJson (← checked (field record "levelParams"))
  let canonical : List Level := (canonicalLevels sp.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "No exact identity"
  let targetLevels : List Level ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let levels : Array Level ← checked (reorder indices canonical.toArray)
      pure levels.toList
  let decoded ← retryDefaultPhase "complete source type decode" do
    pure ((← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical)
  let (sourceType, typeReplay) ← retryDefaultPhase "complete source type replay" (replayExactInitialThetaStandardApps dagStore rs owners config original decoded)
  retryDefaultPhase "whole value leaf exact complete type precondition" do
    kernelTypeEq "faithful source type and actual target type" sourceType (target.type.instantiateLevelParams target.levelParams targetLevels)
  let values ← retryDefaultPhase "complete data value and available recursor/autoParam comparisons" do
    retryValueAndRuleChecks dagStore rs owners config record target sp canonical targetLevels sourceType
  return Json.mkObj [("wholeValueAndRules", values), ("wholeTypeReplay", typeReplay),
    ("completeReplayedSourceType", ← saveEvidenceExpr dagStore sourceType),
    ("completeActualTargetType", ← saveEvidenceExpr dagStore (target.type.instantiateLevelParams target.levelParams targetLevels)),
    ("completeTypePreconditionKernelChecked", toJson true), ("kernelPropositionalValueEqualityUsed", toJson false)]

def splitAxiomCheck (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name)
    (targetName : Name) : MetaM Json :=
  retryDefaultPhase "complete actual owned type/value/recursor axiom and owner audit" do
    let target ← getConstInfo targetName
    let row ← auditDeclaration rs owners targetName
    let fields ← checked row.getObj?
    let fullType ← saveEvidenceExpr dagStore target.type
    let fullValue ← match target.value? (allowOpaque := true) with
      | none => pure Json.null
      | some value => saveEvidenceExpr dagStore value
    return Json.mkObj ((fields.toList.filter (fun p => p.1 != "elaboratedExpr")) ++
      [("elaboratedExpr", fullType), ("completeActualValue", fullValue)])

def runSplitDeclaration : TermElabM Unit := do
  phaseTrace "top.run" "before"
  let dagStore : SplitEvidenceDagRef ← IO.mkRef (default, #[], #[])
  phaseTrace "top.setup" "before"
  let (config, rs, owners, compatibility, record) ← splitSetup
  phaseTrace "top.setup" "after"
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let targetName ← checked (relocated rs original)
  let target ← getConstInfo targetName
  let mode ← checked (stringField config "splitMode")
  phaseTrace ("top." ++ mode) "before"
  let report : Json ← match mode with
    | "signature" => splitSignatureCheck dagStore rs owners config record target
    | "value" => splitValueCheck dagStore rs owners config record target
    | "axioms" => splitAxiomCheck dagStore rs owners targetName
    | "all" => do
      let signature ← splitSignatureCheck dagStore rs owners config record target
      unless (← checked (signature.getObjValAs? Bool "diagnosticPassed")) do
        throwError "Complete single-declaration signature failed; no all-mode report accepted"
      let value ← splitValueCheck dagStore rs owners config record target
      let axioms ← splitAxiomCheck dagStore rs owners targetName
      pure <| Json.mkObj [("signature", signature), ("wholeValueAndRules", value),
        ("ownerAndAxiomClosure", axioms), ("allRequiredChecksPassed", toJson true),
        ("singleDeclarationOnly", toJson true)]
    | _ => throwError "Unsupported first split mode"
  phaseTrace ("top." ++ mode) "after"
  let dag ← retryDefaultPhase "complete shared Expr DAG strict roundtrip for every evidence root" (finishSplitEvidenceDag dagStore)
  phaseTrace "top.report-emission" "before"
  withCurrHeartbeats do
    let output ← absoluteEnv "NEXT_CARRIER_SPLIT_DIAGNOSTIC_OUTPUT"
    IO.FS.writeFile output ((Json.mkObj [
      ("schema", toJson "initial-theta-one-declaration-split-diagnostic-v1"), ("compilerVersion", toJson Lean.versionString),
      ("original", toJson original.toString), ("target", toJson targetName.toString), ("mode", toJson mode),
      ("report", report), ("sharedLosslessExpressionEvidence", dag), ("standardCompatibilityEvidence", compatibility),
      ("completeSingleSourceRecordBinding", ← checked (field config "singleSourceDeclaration")),
      ("requiredSiblingModes", toJson (if mode == "all" then #["all"] else #["signature", "value", "axioms"])),
      ("rawOriginalTypeClaimedNative433KernelChecked", toJson false), ("defaultLogicalCheckHeartbeatBudget", toJson (200000 : Nat)),
      ("acceptedCorrespondenceGenerated", toJson false), ("formalKernelAcceptanceGenerated", toJson false),
      ("priorOver16GiBLeafAccepted", toJson false)]).compress ++ "\n")
    Lean.Core.checkMaxHeartbeats "single declaration split report emission"
  phaseTrace "top.report-emission" "after"
  phaseTrace "top.run" "after"

end FoundationAudit
syntax (name := runSplitDeclaration) "run_split_declaration" : command
@[command_elab runSplitDeclaration] def elabRunSplitDeclaration : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.runSplitDeclaration
run_split_declaration
