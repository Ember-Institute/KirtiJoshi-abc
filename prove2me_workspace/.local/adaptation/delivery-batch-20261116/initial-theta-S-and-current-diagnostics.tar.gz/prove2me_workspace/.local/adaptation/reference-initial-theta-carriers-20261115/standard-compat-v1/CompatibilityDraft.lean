/-
Copyright (c) 2024 Salvatore Mercuri. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Salvatore Mercuri
-/
/-
READ-ONLY REVIEW DRAFT. Not compiled by this subagent.
Root must submit through MCP-CI before treating any declaration below as checked.
The namespace is deliberate: this is a source-shape semantic model, not an alias
which claims that the two distinct standard classes are kernel definitionally equal.
-/
import Mathlib.Analysis.Normed.Ring.WithAbs
import Mathlib.NumberTheory.NumberField.Basic
import Mathlib.RingTheory.Ideal.Quotient.HasFiniteQuotients

namespace InitialThetaStandardCompatibilityDraft

-- Source435 WithAbs.lean:310-328, with only the namespace changed.
namespace Source435
variable {L K S : Type*} [CommSemiring K] [Semiring L] [Algebra K L]
  [FaithfulSMul K L] [PartialOrder S] [Semiring S]

variable (K)
def under (w : AbsoluteValue L S) : AbsoluteValue K S :=
  w.comp (FaithfulSMul.algebraMap_injective K L)

variable {K}
class LiesOver (w : AbsoluteValue L S) (v : AbsoluteValue K S) : Prop where
  under_eq (w) (v) : under K w = v
end Source435

section ExistingFieldContext
variable {L K S : Type*} [Field K] [Field L] [Algebra K L]
  [PartialOrder S] [Semiring S]
variable (w : AbsoluteValue L S) (v : AbsoluteValue K S)

-- Native433 still receives every structural parameter. Field K / Field L are
-- ALREADY PRESENT at the ValuationSection application site, not new hypotheses
-- to insert into a source declaration.
def targetLiesOverAtExistingFields : Prop :=
  @AbsoluteValue.LiesOver K L S
    (inferInstance : CommRing K) (inferInstance : IsSimpleRing K)
    (inferInstance : CommRing L) (inferInstance : Algebra K L)
    (inferInstance : PartialOrder S) (inferInstance : Nontrivial L)
    (inferInstance : Semiring S) w v

-- The injectivity proof arguments have the same proposition; kernel proof
-- irrelevance is sufficient for this equation-body comparison. Root must check.
theorem restrictionBodyEq :
    Source435.under K w = w.comp (algebraMap K L).injective := rfl

-- This is Iff evidence, not definitional equality between the two classes.
theorem source435IffNative433 :
    Source435.LiesOver w v ↔ AbsoluteValue.LiesOver w v := by
  constructor
  · intro h
    letI := h
    exact ⟨Source435.LiesOver.under_eq w v⟩
  · intro h
    letI := h
    exact ⟨AbsoluteValue.LiesOver.comp_eq w v⟩

-- The common semantic normal form, useful for receipts from both environments.
theorem native433IffRestrictionEquality :
    AbsoluteValue.LiesOver w v ↔ w.comp (algebraMap K L).injective = v := by
  constructor
  · intro h
    letI := h
    exact AbsoluteValue.LiesOver.comp_eq w v
  · intro h
    exact ⟨h⟩
end ExistingFieldContext

-- The target general instance already supplies precisely this proposition.
-- Do not register a constant with the absent source constant's name.
theorem finiteQuotientsNativeAtSourceType (K : Type*) [Field K] [NumberField K] :
    Ring.HasFiniteQuotients (NumberField.RingOfIntegers K) := by
  infer_instance

end InitialThetaStandardCompatibilityDraft

#print axioms InitialThetaStandardCompatibilityDraft.restrictionBodyEq
#print axioms InitialThetaStandardCompatibilityDraft.source435IffNative433
#print axioms InitialThetaStandardCompatibilityDraft.native433IffRestrictionEquality
#print axioms InitialThetaStandardCompatibilityDraft.finiteQuotientsNativeAtSourceType
