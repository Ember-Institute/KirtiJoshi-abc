-- Insert inside namespace FoundationAudit, after checked and the existing
-- Name/Level/Binder codecs. Roots must already be metadata-erased.

structure ExprDagEncoder where
  nodes : Array Json := #[]
  index : Lean.ExprStructMap Nat := {}
  deriving Inhabited

abbrev ExprDagM := StateT ExprDagEncoder MetaM

/-- Intern by Expr.equal, which preserves binder Names and BinderInfo. -/
partial def addExpr (e : Expr) : ExprDagM Nat := do
  let initial ← get
  if let some ref := initial.index[(⟨e⟩ : ExprStructEq)]? then
    return ref
  let payload : Json ← match e with
    | .bvar i => pure (node "bvar" [("index", toJson i)])
    | .sort u => do
        let encoded ← liftM (checked (encodeLevel u))
        pure (node "sort" [("level", encoded)])
    | .const n us => do
        let levels ← liftM (checked (us.toArray.mapM encodeLevel))
        pure (node "const" [("name", encodeName n), ("levels", Json.arr levels)])
    | .app f a => do
        let fnRef ← addExpr f
        let argRef ← addExpr a
        pure (node "app" [("fn", toJson fnRef), ("arg", toJson argRef)])
    | .lam n t b bi => do
        let typeRef ← addExpr t
        let bodyRef ← addExpr b
        pure (node "lam" [("name", encodeName n), ("type", toJson typeRef),
          ("body", toJson bodyRef), ("binder", toJson (encodeBinder bi))])
    | .forallE n t b bi => do
        let typeRef ← addExpr t
        let bodyRef ← addExpr b
        pure (node "forall" [("name", encodeName n), ("type", toJson typeRef),
          ("body", toJson bodyRef), ("binder", toJson (encodeBinder bi))])
    | .letE n t v b nd => do
        let typeRef ← addExpr t
        let valueRef ← addExpr v
        let bodyRef ← addExpr b
        pure (node "let" [("name", encodeName n), ("type", toJson typeRef),
          ("value", toJson valueRef), ("body", toJson bodyRef), ("nondependent", toJson nd)])
    | .lit (.natVal n) => pure (node "nat" [("value", toJson n)])
    | .lit (.strVal s) => pure (node "string" [("value", toJson s)])
    | .proj n i b => do
        let bodyRef ← addExpr b
        pure (node "proj" [("name", encodeName n), ("index", toJson i), ("body", toJson bodyRef)])
    | .mdata _ _ => throwError "Expr DAG requires metadata-erased roots; metadata was not discarded"
    | .fvar _ => throwError "Free variable in Expr DAG input"
    | .mvar _ => throwError "Expression metavariable in Expr DAG input"
  let current ← get
  let ref := current.nodes.size
  set { current with nodes := current.nodes.push payload,
                     index := current.index.insert (⟨e⟩ : ExprStructEq) ref }
  return ref


/-- Finalize only after one strict round trip for every original root. -/
def finishExprDag (encoder : ExprDagEncoder) (rootRefs : Array Nat)
    (originalRoots : Array Expr) : MetaM Json := do
  unless rootRefs.size == originalRoots.size do
    throwError "Expr DAG root references and original roots differ in count"
  let dag := Json.mkObj [("schema", toJson "foundation-expr-dag-v1"),
    ("nodes", Json.arr encoder.nodes), ("roots", toJson rootRefs)]
  let decoded ← checked (decodeExprDag dag)
  for i in [:rootRefs.size] do
    let ref := rootRefs[i]!
    let some actual := decoded[ref]? | throwError "Expr DAG root {i} is absent"
    unless Expr.equal originalRoots[i]! actual do
      throwError "Expr DAG strict Expr.equal round trip failed at root {i} (node {ref})"
  return dag


abbrev SplitEvidenceDagRef := IO.Ref (ExprDagEncoder × Array Nat × Array Expr)

def saveEvidenceExpr (dagStore : SplitEvidenceDagRef) (e : Expr) : MetaM Json := do
  requireClosed "complete shared evidence DAG root" e
  let (state, roots, originals) ← dagStore.get
  let (ref, next) ← (addExpr e).run state
  dagStore.set (next, roots.push ref, originals.push e)
  return Json.mkObj [("schema", toJson "foundation-expr-dag-root-v1"), ("root", toJson ref)]

def finishSplitEvidenceDag (dagStore : SplitEvidenceDagRef) : MetaM Json := do
  let (state, roots, originals) ← dagStore.get
  let dag ← finishExprDag state roots originals
  return Json.mkObj [("exprDag", dag), ("rootCount", toJson roots.size),
    ("allRootsStrictExprEqualRoundTrip", toJson true),
    ("includesFullNamesBinderNamesBinderInfoAndUniverseLevels", toJson true)]
