#!/usr/bin/env python3
"""Offline S report analysis: reproduce the20 existing arrays from existing DAG roots.

No compiler or mathematical acceptance. Hash the exact original compact JSON
array bytes while enumerating every occurrence, without storing the huge arrays.
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def locate(nodes, root, path):
    pieces = path.split('.')
    assert pieces[0] == 'root'
    for piece in pieces[1:]:
        node = nodes[root]
        if piece == 'domain':
            assert node['kind'] in ['lam', 'forall']
            root = node['type']
        elif piece == 'projected':
            assert node['kind'] == 'proj'
            root = node['body']
        else:
            assert piece in {'fn', 'arg', 'type', 'value', 'body'}
            root = node[piece]
    return root


def strings(nodes, root, placement):
    stack = [(root, 'root')]
    while stack:
        ref, path = stack.pop()
        node = nodes[ref]
        kind = node['kind']
        if kind in ['forall', 'lam']:
            entry = ('forall' if kind == 'forall' else 'lambda') + ':' + node['binder']
            yield path + ':' + entry if placement else entry
            stack.append((node['body'], path + '.body'))
            stack.append((node['type'], path + '.domain'))
        elif kind == 'app':
            stack.append((node['arg'], path + '.arg'))
            stack.append((node['fn'], path + '.fn'))
        elif kind == 'let':
            stack.append((node['body'], path + '.body'))
            stack.append((node['value'], path + '.value'))
            stack.append((node['type'], path + '.type'))
        elif kind == 'proj':
            stack.append((node['body'], path + '.projected'))
        else:
            assert kind in {'sort', 'const', 'bvar', 'nat', 'string'}


def array_hash(items):
    h = hashlib.sha256()
    h.update(b'[')
    size, count = 1, 0
    for item in items:
        blob = json.dumps(item, ensure_ascii=False, separators=(',', ':')).encode()
        if count:
            h.update(b',')
            size += 1
        h.update(blob)
        size += len(blob)
        count += 1
    h.update(b']')
    return h.hexdigest(), size + 1, count


def main():
    report = json.loads((HERE / 'S-report-with-binder-arrays-omitted-for-analysis.json').read_text())
    original = json.loads((HERE / 'S-binder-array-sizes.json').read_text())
    signature = report['report']
    nodes = report['sharedLosslessExpressionEvidence']['exprDag']['nodes']
    assert report['sharedLosslessExpressionEvidence']['allRootsStrictExprEqualRoundTrip'] is True
    results = []
    for i, row in enumerate(signature['changedDataSlots']):
        for side, root_field in [('source', 'completeFaithfulReplaySignature'),
                                 ('target', 'completeTargetSignature')]:
            root = locate(nodes, signature[root_field]['root'], row['path'])
            for traversal in ['Inventory', 'Placement']:
                key = side + 'RawBinder' + traversal
                expected = original['rows'][4 * i + ['sourceRawBinderInventory', 'sourceRawBinderPlacement',
                    'targetRawBinderInventory', 'targetRawBinderPlacement'].index(key)]
                assert expected['key'] == key
                digest, size, count = array_hash(strings(nodes, root, traversal == 'Placement'))
                assert (digest, size, count) == (expected['sha256'], expected['bytes'], expected['items']), (i, key)
                results.append({'slotIndex': i, 'rowPath': row['path'], 'key': key,
                                'completeSignatureRootField': root_field,
                                'completeSignatureRoot': signature[root_field]['root'],
                                'relativeSubexpressionRoot': root, 'sha256': digest,
                                'bytes': size, 'items': count, 'exactExistingArrayReconstructed': True})
                print(json.dumps({'slotIndex': i, 'key': key, 'exactExistingArrayReconstructed': True}), flush=True)
    out = HERE / 'S-all20-binder-arrays-exact-reconstruction.json'
    out.write_text(json.dumps({'schema': 'S-original-binder-array-serialization-analysis-v1',
        'status': 'offline serialization identity only; no compiler or new acceptance',
        'originalReportBytes': original['reportBytes'], 'reconstructedArrayBytes': original['totalArrayBytes'],
        'arrays': results, 'all20OriginalCompactJsonArrayHashesMatch': True,
        'sameFullSignatureDagRootsUsed': True, 'dagEveryOccurrenceExpandedForReconstruction': True,
        'noContextLambdaStrippingAssumption': True}, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'analysis': str(out), 'all20OriginalCompactJsonArrayHashesMatch': True}))


if __name__ == '__main__':
    main()
