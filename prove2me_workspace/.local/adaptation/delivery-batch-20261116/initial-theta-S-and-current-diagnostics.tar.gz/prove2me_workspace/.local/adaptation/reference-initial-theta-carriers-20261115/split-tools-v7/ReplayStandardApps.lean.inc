structure InitialThetaReplay where
  expr : Expr
  restored : Expr
  changes : Array Json

private partial def eraseReplayLevelNames : Level → Level
  | .param _ => .param `_initialThetaReplayUniverse
  | .succ u => .succ (eraseReplayLevelNames u)
  | .max a b => .max (eraseReplayLevelNames a) (eraseReplayLevelNames b)
  | .imax a b => .imax (eraseReplayLevelNames a) (eraseReplayLevelNames b)
  | u => u

private def eraseReplayExprLevelNames (e : Expr) : Expr := e.replace fun node =>
  match node with
  | .sort u => some (.sort (eraseReplayLevelNames u))
  | .const n us => some (.const n (us.map eraseReplayLevelNames))
  | _ => none

private def initialThetaLiesOverConsumers : Array Name := #[
  `Iut.ValuationSection.casesOn, `Iut.ValuationSection.mk, `Iut.ValuationSection.rec,
  `Iut.ValuationSection.recOn, `Iut.ValuationSection.sectInf_liesOver,
  `Iut.ValuationSection.mk._flat_ctor, `Iut.ValuationSection.mk.inj,
  `Iut.ValuationSection.mk.injEq, `Iut.ValuationSection.mk.noConfusion,
  `Iut.ValuationSection.mk.sizeOf_spec]

def verifyInitialThetaSemanticBridges (config : Json) : MetaM Json := do
  let compat ← checked (field config "initialThetaStandardCompatibility")
  let binding ← checked (field compat "semanticBridges")
  let mut reports := #[]
  for key in #["original435", "native433"] do
    let b ← checked (field binding key)
    let receiptBinding ← checked (field b "receipt")
    let receipt ← jsonFile (← checked (stringField receiptBinding "path"))
    unless receipt == (← checked (field receiptBinding "contents")) &&
        (← checked (stringField receiptBinding "sha256")).length == 64 &&
        (← checked (stringField receipt "job_id")) == (← checked (stringField b "job_id")) &&
        (← checked (stringField receipt "status")) == "succeeded" do
      throwError "Actual standard predicate semantic bridge is pending or changed: {key}"
    let result ← checked (field receipt "result")
    unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do throwError "Semantic bridge compiler failed"
    let snapshot ← checked (field result "snapshot")
    unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
        (← checked (field snapshot "snapshot_id")) == Json.null do throwError "Wrong semantic bridge workspace mode"
    let sourceBinding ← checked (field b "source")
    let text ← IO.FS.readFile (← checked (stringField sourceBinding "path"))
    unless text == (← checked (stringField sourceBinding "text")) &&
        (← checked (stringField sourceBinding "sha256")).length == 64 do throwError "Actual semantic bridge source changed"
    reports := reports.push b
  for name in #[`InitialThetaStandardCompatibilityDraft.restrictionBodyEq,
      `InitialThetaStandardCompatibilityDraft.source435IffNative433,
      `InitialThetaStandardCompatibilityDraft.native433IffRestrictionEquality] do
    let ci ← getConstInfo name
    let some value := ci.value? (allowOpaque := true) | throwError "Missing complete current semantic bridge proof"
    kernelTypeEq "current semantic bridge proof inhabits its complete type" (← kernelCheck name.toString value) ci.type
    ensureStandard name.toString (← collectAxioms name)
  return Json.mkObj [("actualSourceAndNativeBridgeBindings", Json.arr reports),
    ("currentCompleteBridgeProofsKernelChecked", toJson true), ("axiomsStandardOnly", toJson true),
    ("classIdentityClaimedDefinitionallyEqual", toJson false), ("allRequiredKernelChecksPassed", toJson true)]

private def closedReplayJson (dagStore : SplitEvidenceDagRef) (ctx : Array Expr) (e : Expr) : MetaM Json := do
  saveEvidenceExpr dagStore (← mkLambdaFVars ctx e)

partial def replayInitialThetaExpr (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name)
    (original : Name) (ctx : Array Expr) (path : String) (e : Expr) : MetaM InitialThetaReplay := do
  if e.isAppOf ``AbsoluteValue.LiesOver then
    unless initialThetaLiesOverConsumers.contains original do throwError "Unapproved original standard predicate consumer"
    let a := e.getAppArgs
    unless a.size == 11 do throwError "Expected one maximal complete original11argument standard predicate application"
    let l := a[0]!
    let k := a[1]!
    let s := a[2]!
    let w := a[9]!
    let v := a[10]!
    -- These types must already have Field instances in the original telescope.
    let fk ← synthInstance (← mkAppM ``Field #[k])
    let fl ← synthInstance (← mkAppM ``Field #[l])
    let canonicalKSemiring ← synthInstance (← mkAppM ``CommSemiring #[k])
    let canonicalLSemiring ← synthInstance (← mkAppM ``Semiring #[l])
    for (label, before, after) in #[
        ("complete K CommSemiring", a[3]!, canonicalKSemiring),
        ("complete L Semiring", a[4]!, canonicalLSemiring)] do
      kernelTermEq s!"standard API complete computational structure {label}"
        (← mkLambdaFVars ctx before) (← mkLambdaFVars ctx after)
    let scalarType ← mkAppM ``SMul #[k, l]
    let scalar ← synthInstance scalarType
    let faithfulType ← mkAppOptM ``FaithfulSMul #[some k, some l, some scalar]
    unless faithfulType.isAppOf ``FaithfulSMul && faithfulType.getAppArgs.size == 3 do
      throwError "FaithfulSMul must include its complete computational SMul argument"
    kernelTypeEq "original FaithfulSMul proof exact proposition"
      (← mkForallFVars ctx (← inferType a[6]!)) (← mkForallFVars ctx faithfulType)
    let after ← mkAppM ``AbsoluteValue.LiesOver #[w, v]
    let b := after.getAppArgs
    unless after.isAppOf ``AbsoluteValue.LiesOver && b.size == 12 do throwError "Expected complete native12argument predicate"
    let targetKSemiring ← mkAppOptM ``CommRing.toCommSemiring #[some k, some b[3]!]
    let targetLSemiring ← mkAppOptM ``Ring.toSemiring #[some l,
      some (← mkAppOptM ``CommRing.toRing #[some l, some b[5]!])]
    kernelTermEq "old K CommSemiring versus actual native CommRing projection"
      (← mkLambdaFVars ctx a[3]!) (← mkLambdaFVars ctx targetKSemiring)
    kernelTermEq "old L Semiring versus actual native CommRing projection"
      (← mkLambdaFVars ctx a[4]!) (← mkLambdaFVars ctx targetLSemiring)
    -- All mathematical types, algebra data, ordered codomain data and values are retained.
    for (label, before, translated) in #[
        ("K", k, b[0]!), ("L", l, b[1]!), ("S", s, b[2]!),
        ("Algebra", a[5]!, b[6]!), ("PartialOrder S", a[7]!, b[7]!),
        ("Semiring S", a[8]!, b[9]!), ("w", w, b[10]!), ("v", v, b[11]!)] do
      kernelTermEq s!"standard predicate preserves full argument {label}"
        (← mkLambdaFVars ctx before) (← mkLambdaFVars ctx translated)
    let closedAfter ← mkForallFVars ctx after
    discard <| kernelCheck "complete native predicate closed over existing telescope" closedAfter
    let .const _ sourceLevels := e.getAppFn | throwError "Original predicate application lost constant head"
    let cloneName := ``InitialThetaStandardCompatibilityDraft.Source435.LiesOver
    unless (← getConstInfo cloneName).levelParams.length == sourceLevels.length do
      throwError "Exact source semantic model universe arity differs"
    let sourceModelApplication := mkAppN (mkConst cloneName sourceLevels) a
    let bridge ← mkAppM ``InitialThetaStandardCompatibilityDraft.source435IffNative433 #[w, v]
    let bridgeType ← inferType bridge
    unless bridgeType.isAppOf ``Iff && bridgeType.getAppArgs.size == 2 do throwError "No exact predicate Iff bridge"
    kernelTypeEq "exact original11arguments agree with semantic bridge source side"
      (← mkForallFVars ctx sourceModelApplication) (← mkForallFVars ctx bridgeType.getAppArgs[0]!)
    kernelTypeEq "native side of actual semantic Iff at exact existing fields"
      (← mkForallFVars ctx bridgeType.getAppArgs[1]!) closedAfter
    let closedBridge ← mkLambdaFVars ctx bridge
    discard <| kernelCheck "complete instantiated predicate Iff proof" closedBridge
    ensureStandard "instantiated standard predicate semantic bridge" (← expressionAxioms closedBridge)
    for term in #[fk, fl, after] do
      for dep in term.getUsedConstants do allowedOwner rs owners dep
    let sourceArguments ← a.mapM (closedReplayJson dagStore ctx)
    let targetArguments ← b.mapM (closedReplayJson dagStore ctx)
    let report := Json.mkObj [
      ("kind", toJson "exact-source435-predicate-to-native433-semantic-translation"),
      ("path", toJson path), ("sourceArgumentCount", toJson (11 : Nat)),
      ("targetArgumentCount", toJson (12 : Nat)), ("contextSize", toJson ctx.size),
      ("completePreReplayApplication", ← closedReplayJson dagStore ctx e),
      ("completeReplayApplication", ← closedReplayJson dagStore ctx after),
      ("sourceArguments", Json.arr sourceArguments), ("targetArguments", Json.arr targetArguments),
      ("existingFieldK", ← closedReplayJson dagStore ctx fk), ("existingFieldL", ← closedReplayJson dagStore ctx fl),
      ("completeSourceModelApplication", ← closedReplayJson dagStore ctx sourceModelApplication),
      ("completeInstantiatedPredicateIffProof", ← saveEvidenceExpr dagStore closedBridge),
      ("addedTelescopeBinders", toJson (0 : Nat)), ("allCompleteArgumentRelationsKernelChecked", toJson true),
      ("rawApplicationClaimedKernelChecked", toJson false),
      ("sourceAndNativeClassesClaimedDefinitionallyEqual", toJson false),
      ("semanticPredicateTranslation", toJson true), ("nativeApplicationKernelChecked", toJson true)]
    return ⟨after, e, #[report]⟩
  if e.isApp && e.getAppFn.isLambda then
    -- Complete source DAG values were independently kernel checked at setup.
    -- Do not walk their internal finite-place/valuation implementation again.
    if rs.sourceCompatibilityValues.any (fun seed =>
        (eraseReplayExprLevelNames e.getAppFn).equal (eraseReplayExprLevelNames seed.2.2)) then
      return ⟨e, e, #[]⟩
    if let some seed := rs.standardProofValues.find? (·.1 == `NumberField.RingOfIntegers.instHasFiniteQuotients) then
      if (eraseReplayExprLevelNames e.getAppFn).equal (eraseReplayExprLevelNames seed.2.2) then
        let after := e.headBeta
        unless !after.equal e do throwError "Exact native proof substitution has no head beta redex"
        kernelTermEq "exact installed standard proof head-beta replay"
          (← mkLambdaFVars ctx e) (← mkLambdaFVars ctx after)
        let row := Json.mkObj [("kind", toJson "exact-installed-finite-quotients-proof-head-beta"),
          ("path", toJson path), ("completeBefore", ← closedReplayJson dagStore ctx e),
          ("completeAfter", ← closedReplayJson dagStore ctx after),
          ("completeTypesAndProofValuesKernelEqual", toJson true)]
        return ⟨after, e, #[row]⟩
  let result : InitialThetaReplay ← match e with
  | .forallE n d body bi => do
    let dv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".domain") d
    withLocalDecl n bi dv.expr fun x => do
      let bv ← replayInitialThetaExpr dagStore rs owners original (ctx.push x) (path ++ ".body") (body.instantiate1 x)
      pure ⟨.forallE n dv.expr (bv.expr.abstract #[x]) bi,
        .forallE n dv.restored (bv.restored.abstract #[x]) bi, dv.changes ++ bv.changes⟩
  | .lam n d body bi => do
    let dv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".domain") d
    withLocalDecl n bi dv.expr fun x => do
      let bv ← replayInitialThetaExpr dagStore rs owners original (ctx.push x) (path ++ ".body") (body.instantiate1 x)
      pure ⟨.lam n dv.expr (bv.expr.abstract #[x]) bi,
        .lam n dv.restored (bv.restored.abstract #[x]) bi, dv.changes ++ bv.changes⟩
  | .app f a => do
    let fv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".fn") f
    let av ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".arg") a
    pure ⟨.app fv.expr av.expr, .app fv.restored av.restored, fv.changes ++ av.changes⟩
  | .letE n d value body nondep => do
    let dv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".type") d
    let vv ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".value") value
    withLetDecl n dv.expr vv.expr (fun x => do
      let bv ← replayInitialThetaExpr dagStore rs owners original (ctx.push x) (path ++ ".body") (body.instantiate1 x)
      pure ⟨.letE n dv.expr vv.expr (bv.expr.abstract #[x]) nondep,
        .letE n dv.restored vv.restored (bv.restored.abstract #[x]) nondep,
        dv.changes ++ vv.changes ++ bv.changes⟩) (nondep := nondep)
  | .proj n i value => do
    let v ← replayInitialThetaExpr dagStore rs owners original ctx (path ++ ".projected") value
    pure ⟨.proj n i v.expr, .proj n i v.restored, v.changes⟩
  | .mdata md value => do
    let v ← replayInitialThetaExpr dagStore rs owners original ctx path value
    pure ⟨.mdata md v.expr, .mdata md v.restored, v.changes⟩
  | _ => pure ⟨e, e, #[]⟩
  unless result.restored.equal e do throwError "Exact standard replay inverse did not reconstruct original expression"
  return result

def replayExactInitialThetaStandardApps (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name) (_config : Json)
    (original : Name) (source : Expr) : MetaM (Expr × Json) := do
  let result ← replayInitialThetaExpr dagStore rs owners original #[] "root" source
  unless result.restored.equal source do throwError "Whole exact standard replay is not reversible"
  return (result.expr, Json.mkObj [
    ("changes", Json.arr result.changes), ("exactExprEqualInverseReconstruction", toJson true),
    ("addedTelescopeBinders", toJson (0 : Nat)),
    ("rawOriginalClaimedKernelChecked", toJson false),
    ("allRequiredKernelChecksPassed", toJson true)])
