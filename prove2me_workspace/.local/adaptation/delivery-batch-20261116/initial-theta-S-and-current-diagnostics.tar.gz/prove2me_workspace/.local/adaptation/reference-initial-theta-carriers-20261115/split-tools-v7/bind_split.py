#!/usr/bin/env python3
"""Make only TateFamily.S signature/value/axioms leaves with shared exact Expr DAG evidence.
No compiler, CI, network, Git, acceptance; writes only --out.
"""
import argparse,copy,json,hashlib,re
from pathlib import Path
HERE=Path(__file__).resolve().parent
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
def load(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def dump(p,j):Path(p).write_text(json.dumps(j,ensure_ascii=False,separators=(',',':'))+'\n')
def pin(p):return {'path':str(p.resolve()),'sha256':sha(p)}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--base',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();b=a.base.resolve();a.out.mkdir(parents=True,exist_ok=True)
 receiptpath=b/'batch-instance-retry36-v6-result.json';receipt=load(receiptpath)
 assert receipt['job_id']=='ci-015356-4cd294eb' and receipt['status']=='failed' and receipt['resources']['peak_rss_bytes']==29512400896
 req=receipt['request'];source=(W/req['parameters']['source']).resolve();assert sha(source)==req['worktree_manifest']['source_sha256']
 cfgpath=Path(req['environment']['NEXT_CARRIER_AUDIT_CONFIG']);assert sha(cfgpath)==req['worktree_manifest']['input_hashes'][str(cfgpath)]
 old=load(cfgpath)
 profilepath=b/'original-exprs-size-profile.json';profile=load(profilepath);meta=next(r for r in profile['records'] if r['name']=='Iut.TateFamily.S')
 rawpath=Path(profile['source'])
 with rawpath.open('rb') as f:
  f.seek(meta['offset']);raw=f.read(meta['bytes'])
 record=json.loads(raw);assert record['name']=='Iut.TateFamily.S' and record['selected'] and not record['isProposition'] and record['recursorRuleRhs']==[] and record['structure'] is None
 moduleview=next(m for m in old['batchModuleViews'] if m['module']==record['module']);assert sha(moduleview['path'])==moduleview['sha256']
 oldrecord=next(r for r in load(moduleview['path'])['records'] if r['name']==record['name']);assert oldrecord==record
 fields={}
 for key,offset in meta['fieldOffsets'].items():
  begin=offset-meta['offset'];data=raw[begin:begin+meta['fieldBytes'][key]]
  fields[key]={'start':offset,'end':offset+len(data),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 single=a.out/'TateFamily.S.source-record.json'
 view={'schema':'initial-theta-exact-single-source-record-view-v1','compilerVersion':'4.35.0-rc3','sourceCompilerJob':'ci-014813-9a2dd40b','completeOriginalRecordCount':232,'completeOriginalSelectedCount':204,
  'inventorySha256':old['inventorySha256'],'graphSha256':old['graphSha256'],'record':record,
  'rawRecordBinding':{'path':str(rawpath),'artifactSha256':profile['sourceSha256'],'start':meta['offset'],'end':meta['endOffset'],'bytes':len(raw),'recordSpanSha256':hashlib.sha256(raw).hexdigest(),'fieldSpans':fields},
  'exactModuleView':moduleview,'sourceProfile':pin(profilepath),'rawRecordAndCompactModuleRecordExactlyEqual':True}
 dump(single,view)
 # Remove every runtime batch view and whole-report read; retain full immutable
 # four-proof/parent/actual-platform/DAG context needed by setup.
 common=copy.deepcopy(old)
 for key in ['batchModuleViews','previousActualBatch','sourceModuleView','originalExprFile','outputDir']:common.pop(key,None)
 common['singleSourceDeclaration']=pin(single);common['splitOriginal']=record['name']
 common['retainedActual164Evidence']={'job_id':'ci-015133-a27f3349','report':pin(b/'batch-instance-signature-diagnostic.json'),'successfulRows':164,'loadedBySplitLeaf':False}
 common['over16GiBAttempt']={'job_id':receipt['job_id'],'receipt':pin(receiptpath),'status':'failed','peakRssBytes':29512400896,'accepted':False}
 common['status']='pending TateFamily.S signature/value/axioms independent leaves; no former36process or over16GiB result accepted'
 text=source.read_text();start=text.index('/-! Stable JSON');prefix=text[start:text.index('-- Diagnostic only. An emitted candidate')]
 header=text[:start]
 nativepath=b/'standard-compat-v1/CompatibilityDraft.lean';native=nativepath.read_text();nativebody='\n'.join(x for x in native.splitlines() if not x.startswith('import '))+'\n'
 # Already submitted source contains native semantic declarations before codecs.
 # Avoid duplicating that namespace when reusing its full existing header.
 i=header.find('namespace InitialThetaStandardCompatibilityDraft')
 if i>=0:header=header[:i]+nativebody+'\n'
 adic=(HERE/'InstallAdicSourceCompatibility.lean.inc').read_text()
 shared=(HERE/'SharedEvidenceDag.lean.inc').read_text()
 walker=(HERE/'BatchInstanceSignature.lean.inc').read_text().split('def batchOneSignature',1)[0]
 body=adic+'\n'+shared+'\n'+walker+'\n'+'\n'.join((HERE/f).read_text() for f in ['InstallFiniteQuotientsCompatibility.lean.inc','ReplayStandardApps.lean.inc','RetryValueAndRuleChecks.lean.inc','RetryOneSignature.lean.inc','SplitDeclarationMain.lean.inc'])
 tail='''\nend FoundationAudit
syntax (name := runSplitDeclaration) "run_split_declaration" : command
@[command_elab runSplitDeclaration] def elabRunSplitDeclaration : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.runSplitDeclaration
run_split_declaration
'''
 leaves=[]
 for mode in ['signature','value','axioms']:
  d=a.out/mode;d.mkdir(exist_ok=True);cfg=copy.deepcopy(common);cfg['splitMode']=mode
  cp=d/'split-config.json';sp=d/'CheckTateFamilyS.lean';dump(cp,cfg);sp.write_text(header+prefix+body+tail)
  leaves.append({'original':record['name'],'mode':mode,'source':str(sp.resolve()),'sourceSha256':sha(sp),'config':str(cp.resolve()),'configSha256':sha(cp),
    'environment':{'NEXT_CARRIER_AUDIT_CONFIG':str(cp.resolve()),'NEXT_CARRIER_SPLIT_DIAGNOSTIC_OUTPUT':str((d/'split-result.json').resolve())},
    'task_type':'leaf','target':'file','expectedDuration':('180s' if mode=='signature' else '60s'),'expectedMemory':('8GiB' if mode=='signature' else '16GiB'),'estimateBasis':('same declaration signature failed ci-015388-002e952f at 147.3138746000186s and RSS5230010368bytes; local state repair' if mode=='signature' else 'first compilation of this mode'),'expectedPhysicalRssAtMostBytes':17179869184})
 manifest={'schema':'initial-theta-first-single-declaration-split-plan-v1','status':'pendingactual3independentleafreceipts','original':record['name'],'leaves':leaves,'singleSourceRecord':pin(single),
  'runtimeSourceRecordCount':1,'allOldModuleViewsLoadedAtRuntime':False,'actual200reportLoadedAtRuntime':False,'fullFourOriginalProofContextRetained':True,
  'expressionEvidence':'Shared foundation-expr-dag-v1; every referenced complete Expr root strict Expr.equal roundtrip; original raw flags and paths retained',
  'priorOver16GiBLeafAccepted':False,'priorOver16GiBReceipt':pin(receiptpath),'compilerRun':False,'acceptedCorrespondenceGenerated':False,
  'toolInputs':[pin(x) for x in sorted(HERE.glob('*.lean.inc'))]+[pin(Path(__file__))]}
 dump(a.out/'split-plan.json',manifest);print(json.dumps({'leaves':leaves,'singleSourceRecord':pin(single),'acceptedCorrespondenceGenerated':False}))
if __name__=='__main__':main()
