本目录只增加阶段定位输出，未编译或提交 CI。公共源以 serialization-only-v3 为基线，保留全部数学检查、rawfalse、完整值/recursor/autoParam、owner/axiom 与 DAG strict Expr.equal 检查，以及原 200000 heartbeat 选项和原 withCurrHeartbeats 逻辑边界。

NEXT_CARRIER_PHASE_TRACE 未设置时不写文件。设置时必须为绝对路径。每个事件以 IO.FS.withFile .append 追加一行 JSON，并立即 handle.flush；审计不读取该文件。每行只有 phase、event 和 monoMsNow；时间来自 IO.monoMsNow，单位为单调毫秒，不是墙钟日期或 CPU 时间。trace 是过程定位，不是通过回执。

所有原 boundedMetaAuditUnit 标签均记录 bounded:<label> 的 before/after，trace 调用位于原 withCurrHeartbeats 外侧。所有原 retryDefaultPhase 标签均记录 retry:<label> 的 before/after。顶层另外记录 top.run、top.setup、top.signature/top.value/top.axioms 及 top.report-emission。原 action、默认预算检查、heartbeat 起止计数和最终 checkMaxHeartbeats 均保留。before 后缺 after 表示该层未正常返回；若异常被已有代码捕获，后续顶层事件仍可能出现，应结合最后事件与真正终态回执判断。

三个配置仅复用同一原 graphLine 完整 source-record，改 splitMode 与描述性 status。先使用 signature 配置；value 和 axioms 配置只作后续独立阶段草稿。真实 workspace/source/config/output/trace 路径由 root 绑定后再提交，trace 路径每次尝试使用新文件，以免混入旧事件。根目录及模式目录已在 tmp 中建立。

若没有 top.run，执行尚未进入 runSplitDeclaration；因此这份 trace 不能把此前源码 elaboration 时间细分。本草稿不请求更大时间预算，不重复 S，也不从先前 timeout 推定最终 wall/CPU/peakRSS。
