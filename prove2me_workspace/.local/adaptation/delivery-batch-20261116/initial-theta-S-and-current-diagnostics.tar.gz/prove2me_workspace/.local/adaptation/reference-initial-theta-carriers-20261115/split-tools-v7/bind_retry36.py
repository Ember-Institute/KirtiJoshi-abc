#!/usr/bin/env python3
"""Bind exactly36 failed actual signatures, both actual semantic bridges, exact prior native Prop proof.
No compiler, CI, network, Git or acceptance. Writes only --out.
"""
import argparse,copy,json,hashlib,importlib.util
from pathlib import Path
HERE=Path(__file__).resolve().parent
W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace')
def load(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def bind(p):return {'path':str(p.resolve()),'sha256':sha(p),'contents':load(p)}
def actual(p,job):
 r=load(p);assert r['job_id']==job and r['status']=='succeeded' and r['result']['exit_code']==0
 q=r['request'];assert q['exclusive'] and Path(q['workspace']).resolve()==W
 assert r['result']['snapshot']['workspace_mode']=='exclusive_worktree' and r['result']['snapshot']['snapshot_id'] is None
 source=(W/q['parameters']['source']).resolve();assert sha(source)==q['worktree_manifest']['source_sha256']==q['worktree_manifest']['input_hashes'][str(source)]
 return r,source

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--base',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();b=a.base.resolve();a.out.mkdir(parents=True,exist_ok=True)
 firstpath=b/'batch-instance-signature-diagnostic.json';first=load(firstpath);firstreceipt=b/'batch-instance-diagnostic-v2-result.json';fr,firstsource=actual(firstreceipt,'ci-015133-a27f3349')
 firstcfgpath=Path(fr['request']['environment']['NEXT_CARRIER_AUDIT_CONFIG']);assert sha(firstcfgpath)==fr['request']['worktree_manifest']['input_hashes'][str(firstcfgpath)]
 config=load(firstcfgpath);rows=first['reports'];assert len(rows)==200 and sum(r['diagnosticPassed'] for r in rows)==164
 failed=[r for r in rows if not r['diagnosticPassed']];assert len(failed)==36
 failednames={r['original'] for r in failed};assert len(failednames)==36
 semantic={};semanticinputs=[];native_source=None
 for key,receiptname,job in [('original435','standard-source435-semantic-v1-result.json','ci-015189-5eae8df4'),('native433','standard-compat-semantic-v1-result.json','ci-015187-6b86c163')]:
  rp=b/receiptname;r,source=actual(rp,job);semantic[key]={'job_id':job,'receipt':bind(rp),'source':{'path':str(source),'sha256':sha(source),'text':source.read_text()}}
  semanticinputs += [rp,source]
  if key=='native433':native_source=source
 prior=b.parent/'reference-tate-theta-carriers-20261115';prpath=prior/'kernel-audit-v10-result.json';pr,prsrc=actual(prpath,'ci-014723-4ace0d05')
 assert pr['status']=='succeeded' and pr['result']['exit_code']==0
 priorconfigpath=Path(pr['request']['environment']['NEXT_CARRIER_AUDIT_CONFIG']);assert sha(priorconfigpath)==pr['request']['worktree_manifest']['input_hashes'][str(priorconfigpath)]
 oldconfig=load(priorconfigpath);finite=copy.deepcopy(oldconfig['standardProofCompatibility']);finiteinputs=[]
 for key in ['sourceFacts','sourceReceipt','platformFacts','platformReceipt']:
  old=finite['evidence'][key];path=Path(old['path']);assert sha(path)==old['sha256'];finite['evidence'][key]=bind(path);finiteinputs.append(path)
 sourcefacts=finite['evidence']['sourceFacts']['contents']
 assert finite['evidence']['sourceReceipt']['contents']['job_id']=='ci-014215-2414b895' and finite['evidence']['platformReceipt']['contents']['job_id']=='ci-014243-25ac457f'
 adic=copy.deepcopy(oldconfig['adicSourceCompatibility']);adicinputs=[]
 spec=importlib.util.spec_from_file_location('actual_prior_dag_binder',prior/'bind_dag_main.py');dagbinder=importlib.util.module_from_spec(spec);spec.loader.exec_module(dagbinder)
 historical=prior/'attempts/kernel-audit-v4/audit-config.json'
 for i,leaf in enumerate(adic['leaves']):
  viewpath=Path(leaf['viewPath']);job,stage,count=('ci-014497-4264b653','absnorm-support',19) if i==0 else ('ci-014507-f12c827f','finite-place',16)
  view,receipt,fields,paths=dagbinder.verify_leaf(viewpath,job,stage,count,historical)
  assert view['sourceFields']['inventorySha256']==sourcefacts['inventorySha256'] and view['sourceFields']['graphSha256']==sourcefacts['graphSha256']
  leaf['viewContents']=view;leaf['receiptContents']=receipt;adicinputs+=paths
 config['initialThetaStandardCompatibility']={'finiteQuotients':finite,'priorProvenance':{k:sourcefacts[k] for k in ['inventorySha256','graphSha256']},'semanticBridges':semantic,'adicSourceCompatibility':adic}
 config['previousActualBatch']={'job_id':fr['job_id'],'path':str(firstpath),'sha256':sha(firstpath),'receipt':bind(firstreceipt)}
 config['batchModuleViews']=[m for m in config['batchModuleViews'] if failednames.intersection(m['recordNames'])]
 assert len(config['batchModuleViews'])==2
 config['auditorStandardImports']=['Mathlib.RingTheory.Ideal.Quotient.HasFiniteQuotients']
 config['status']='diagnostic-only exact36actual failed standard API signatures; retain original164success and36raw failures; no accepted map'
 text=firstsource.read_text();start=text.index('/-! Stable JSON');end=text.index('-- Diagnostic only. An emitted candidate')
 header=text[:start]
 line='import Mathlib.RingTheory.Ideal.Quotient.HasFiniteQuotients\n'
 if line not in header:header=header.replace('import Lean\n','import Lean\n'+line,1)
 nativebody='\n'.join(line for line in native_source.read_text().splitlines() if not line.startswith('import '))+'\n'
 prefix=text[start:end]
 batch=(HERE/'BatchInstanceSignature.lean.inc').read_text();walker=batch[:batch.index('def batchOneSignature')]
 parts=['InstallFiniteQuotientsCompatibility.lean.inc','InstallAdicSourceCompatibility.lean.inc','ReplayStandardApps.lean.inc','RetryValueAndRuleChecks.lean.inc','RetryOneSignature.lean.inc','Retry36Main.lean.inc']
 tail='''\nend FoundationAudit
syntax (name := retry36StandardSignatures) "retry36_standard_signatures" : command
@[command_elab retry36StandardSignatures] def elabRetry36StandardSignatures : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.retry36StandardSignatures
retry36_standard_signatures
'''
 leaf=a.out/'Retry36StandardSignatures.lean';leaf.write_text(header+'\n'+nativebody+'\n'+prefix+walker+'\n'+'\n'.join((HERE/x).read_text() for x in parts)+tail)
 cfg=a.out/'retry36-config.json';dump(cfg,config)
 inputs=[firstpath,firstreceipt,firstsource,firstcfgpath,priorconfigpath,prpath,*semanticinputs,*finiteinputs,*adicinputs,HERE/'BatchInstanceSignature.lean.inc',*[HERE/x for x in parts]]
 manifest={'schema':'initial-theta-actual36-standard-api-retry-input-v1','source':str(leaf.resolve()),'sourceSha256':sha(leaf),'config':str(cfg.resolve()),'configSha256':sha(cfg),'actualPreviousJob':fr['job_id'],'retainedActualSuccesses':164,'supersededActualRetryJob':'ci-015342-7543c235','supersededActualRetryResult':'default200000whnf limit at first consumer after35completeDAG passed; original0/36 and failed receipt retained','exactRetryOriginals':sorted(failednames),
  'inputEvidence':[{'path':str(q.resolve()),'sha256':sha(q)} for q in dict.fromkeys(inputs)],
  'environment':{'NEXT_CARRIER_AUDIT_CONFIG':str(cfg.resolve()),'NEXT_CARRIER_BATCH_INSTANCE_DIAGNOSTIC_OUTPUT':str(b/'batch-instance-signature-retry36-v5.json')},
  'firstExpectedDuration':'60s','firstExpectedMemory':'16GiB','acceptedCorrespondenceGenerated':False,'compilerRun':False}
 dump(a.out/'retry36-binding-manifest.json',manifest);print(json.dumps({k:manifest[k] for k in ['source','sourceSha256','config','configSha256','environment']}))
if __name__=='__main__':main()
