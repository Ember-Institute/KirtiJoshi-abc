-- Independent logical checks retain the unchanged default heartbeat option.
-- No phase is accepted from a progress log; all phases must return successfully.
def retryDefaultPhase (label : String) (action : MetaM α) : MetaM α := do
  logInfo s!"Retry phase start: {label}"
  let (result, ticks) ← boundedMetaAuditUnit label action
  logInfo s!"Retry phase passed: {label}; internal heartbeat ticks {ticks}"
  return result

def splitSignatureCheck (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name) (config record : Json) (target : ConstantInfo) : MetaM Json := do
  let (original, sp, canonical, tl, raw, decodedSource, t, rawInventoryEqual, rawPlacementEqual, baseline) ← retryDefaultPhase "decode and raw signature serialization" do
    let original ← checked (decodeName (← checked (field record "nameExpr")))
    let sp ← namesFromJson (← checked (field record "levelParams"))
    unless sp.length == target.levelParams.length do throwError "Universe arity changed"
    let canonical : List Level := (canonicalLevels sp.length).map Level.param
    let some r := rs.find? (·.original == original) | throwError "No exact named map"
    let tl : List Level ← match r.permutation with
      | none => pure canonical
      | some p => do
        let reordered : Array Level ← checked (reorder p canonical.toArray)
        pure reordered.toList
    let rawRs := {rs with sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[]}
    let raw := (← checked (decodeExpr rawRs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical
    let decodedSource := (← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical
    let t := target.type.instantiateLevelParams target.levelParams tl
    unless binderInventory raw == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
      throwError "Original exported raw inventory serialization differs"
    let rawInventoryEqual := binderInventory raw == binderInventory t
    let rawPlacementEqual := binderPlacement raw == binderPlacement t
    let baseline := [("original", toJson original.toString), ("target", toJson target.name.toString),
      ("rawSignatureBinderInventoryEqual", toJson rawInventoryEqual),
      ("rawSignatureBinderPlacementEqual", toJson rawPlacementEqual),
      ("sourceRawBinderCount", toJson (binderInventory raw).size), ("targetRawBinderCount", toJson (binderInventory t).size),
      ("sourceSignatureSerializationValidated", toJson true)]
    return (original, sp, canonical, tl, raw, decodedSource, t, rawInventoryEqual, rawPlacementEqual, baseline)
  try
    let rawFailure ← retryDefaultPhase s!"raw target433 kernel failure {original}" do
      try
        discard <| kernelCheck "unmodified original raw signature in target433" raw
        pure (none : Option String)
      catch ex => pure (some (← ex.toMessageData.toString))
    unless rawFailure.isSome do throwError "Retry raw signature no longer has its actual recorded standard API failure"
    let (s, replayEvidence) ← retryDefaultPhase s!"exact standard API replay {original}"
      (replayExactInitialThetaStandardApps dagStore rs owners config original decodedSource)
    retryDefaultPhase s!"complete faithful signature and owner/axiom closure {original}" do
      kernelTypeEq s!"complete faithful replay signature {original}" s t
      for e in #[s, t] do batchOwnedClosed rs owners original.toString e
    let domains ← retryDefaultPhase s!"all complete exposed domains and result {original}" (batchExposedDomains s t)
    logInfo s!"Retry phase start: exact data slots and all remaining BinderInfo {original}; each path independently default200000"
    let views ← batchSignatureViews dagStore rs owners #[] "root" s t
    logInfo s!"Retry phase passed: exact data slots and all remaining BinderInfo {original}; checked path count {views.slots.size}"
    unless !rawInventoryEqual && !rawPlacementEqual do throwError "Original literal raw-false signature evidence changed"
    unless !views.slots.isEmpty || !(← checked (arrayField replayEvidence "changes")).isEmpty do
      throwError "Neither exact data slots nor exact standard API replay accounts for the raw difference"
    let valueEvidence := Json.mkObj [("status", toJson "requires independent whole-value sibling leaf"),
      ("mode", toJson "value"), ("noWholeValueAcceptanceClaimedFromSignatureLeaf", toJson true)]
    return ← retryDefaultPhase s!"complete evidence serialization {original}" do
      let replaySignatureJson ← saveEvidenceExpr dagStore s
      let sourceSignatureJson ← saveEvidenceExpr dagStore raw
      let targetSignatureJson ← saveEvidenceExpr dagStore t
      let sourceViewJson ← saveEvidenceExpr dagStore views.sourceView
      let targetViewJson ← saveEvidenceExpr dagStore views.targetView
      return Json.mkObj (baseline ++ [
        ("diagnosticPassed", toJson true), ("error", Json.null),
        ("completeUnmodifiedTypesKernelEqual", toJson false),
        ("rawOriginalTypeKernelCheckSucceeded", toJson false), ("rawOriginalTypeKernelError", toJson rawFailure),
        ("rawOriginalSignatureClaimedKernelChecked", toJson false),
        ("faithfulReplaySignatureKernelEqual", toJson true),
        ("completeFaithfulReplaySignature", replaySignatureJson),
        ("sourceReplayBinderCount", toJson (binderInventory s).size),
        ("standardApiReplayEvidence", replayEvidence),
        ("wholeValuesAndRecursorRules", valueEvidence),
        ("binderViewScope", toJson "faithful-replay-signature-versus-actual-target; original raw flags remain false"),
        ("exposedDomains", domains), ("changedDataSlots", Json.arr views.slots),
        ("exactExprEqualRoundTrip", toJson true), ("allOtherBinderInfoStrictlyEqual", toJson true),
        ("rawFalseRemainsLiteral", toJson (!rawInventoryEqual || !rawPlacementEqual)),
        ("completeSourceSignature", sourceSignatureJson),
        ("completeTargetSignature", targetSignatureJson),
        ("sourceBinderView", sourceViewJson),
        ("targetBinderView", targetViewJson),
        ("viewNeverUsedAsKernelInput", toJson true)])

  catch e =>
    return Json.mkObj (baseline ++ [("diagnosticPassed", toJson false),
      ("error", toJson (← e.toMessageData.toString)), ("acceptedCorrespondenceGenerated", toJson false)])

