def retry36StandardSignatures : TermElabM Unit := do
  let (config, rs, owners, compatibility) ← withCurrHeartbeats do
    unless Lean.versionString == "4.33.1" && maxHeartbeats.get (← getOptions) == 200000 do
      throwError "Exact target compiler and default heartbeat budget required"
    let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
    let rs ← readRelocations config
    let modules ← (← checked (arrayField config "modules")).mapM fun r => return (← checked (stringField r "target")).toName
    let deps := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
    let prefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
    let env ← getEnv
    let mut owners := #[]
    for m in env.header.moduleNames do
      unless prefixes.any (·.isPrefixOf m) || (modules ++ deps).contains m do throwError "Forbidden module {m}"
      owners := owners.push m
    let (facts, _) ← boundedMetaAuditUnit "actual platform facts" (verifyPlatformHelperFacts config)
    let ((rs, _), _) ← boundedMetaAuditUnit "four genuine original source proofs" (installExactInitialThetaProofValues rs owners config facts)
    let ((rs, finite), _) ← boundedMetaAuditUnit "exact standard Prop instance native proof" (installInitialThetaStandardCompatibility rs owners config)
    let ((rs, adic), _) ← boundedMetaAuditUnit "complete accepted original adic DAG types and values" (installInitialThetaAdicSourceDagValues rs owners config)
    let (bridges, _) ← boundedMetaAuditUnit "actual original/native semantic bridges" (verifyInitialThetaSemanticBridges config)
    let compatibility := Json.mkObj [("finiteQuotients", finite), ("adicCompleteSourceTypeValueReplay", adic), ("predicateSemanticBridges", bridges),
      ("allRequiredKernelChecksPassed", toJson true)]
    return (config, rs, owners, compatibility)
  let previous ← checked (field config "previousActualBatch")
  let firstReport ← jsonFile (← checked (stringField previous "path"))
  unless (← checked (stringField previous "job_id")) == "ci-015133-a27f3349" &&
      (← checked (firstReport.getObjValAs? Nat "namedDeclarationCount")) == 200 do throwError "Wrong original actual all200diagnostic"
  let firstRows ← checked (arrayField firstReport "reports")
  let failedRows ← firstRows.filterM fun r => do return !(← checked (r.getObjValAs? Bool "diagnosticPassed"))
  let failedNames ← failedRows.mapM fun r => return (← checked (stringField r "original")).toName
  unless failedRows.size == 36 && firstRows.size == 200 && failedNames.toList.eraseDups.length == 36 do
    throwError "Expected exact36actual failed declarations; actual164successes are retained"
  let mut reports := #[]
  let mut seen : Array Name := #[]
  for module in ← checked (arrayField config "batchModuleViews") do
    let source ← jsonFile (← checked (stringField module "path"))
    for key in #["inventorySha256", "graphSha256"] do
      unless (← checked (field source key)) == (← checked (field config key)) do throwError "Original source provenance changed"
    for record in ← checked (arrayField source "records") do
      let original ← checked (decodeName (← checked (field record "nameExpr")))
      unless failedNames.contains original do continue
      unless !(seen.contains original) && (← checked (record.getObjValAs? Bool "selected")) do
        throwError "Retry duplicate or unselected declaration"
      let actualName ← checked (relocated rs original)
      logInfo s!"Retry exact failed standard API declaration {original}"
      let started ← IO.getNumHeartbeats
      let report ← retryOneSignature rs owners config record (← getConstInfo actualName)
      let ticks := (← IO.getNumHeartbeats) - started
      reports := reports.push (Json.mkObj ((← checked report.getObj?).toList ++ [
        ("independentDefaultHeartbeatBudget", toJson (200000 : Nat)),
        ("budgetScope", toJson "each complete logical check phase; unchanged default200000; total declaration ticks reported separately"),
        ("heartbeatsInternalTicks", toJson ticks)]))
      seen := seen.push original
  unless seen.size == 36 && failedNames.all seen.contains do throwError "Exact36failed retry coverage incomplete"
  withCurrHeartbeats do
    let output ← absoluteEnv "NEXT_CARRIER_BATCH_INSTANCE_DIAGNOSTIC_OUTPUT"
    IO.FS.writeFile output ((Json.mkObj [
      ("schema", toJson "initial-theta-failed36-standard-api-signature-diagnostic-v1"),
      ("compilerVersion", toJson Lean.versionString), ("namedDeclarationCount", toJson (36 : Nat)),
      ("previousActualBatchJob", ← checked (field previous "job_id")),
      ("previousActualBatchReport", Json.mkObj [("path", ← checked (field previous "path")), ("sha256", ← checked (field previous "sha256"))]),
      ("retainedActualPreviousSuccessCount", toJson (164 : Nat)), ("reports", Json.arr reports),
      ("standardCompatibilityEvidence", compatibility), ("acceptedCorrespondenceGenerated", toJson false),
      ("formalKernelAcceptanceGenerated", toJson false), ("rawOriginalSignatureClaimedKernelChecked", toJson false)]).compress ++ "\n")
    Lean.Core.checkMaxHeartbeats "retry36 diagnostic emission"
