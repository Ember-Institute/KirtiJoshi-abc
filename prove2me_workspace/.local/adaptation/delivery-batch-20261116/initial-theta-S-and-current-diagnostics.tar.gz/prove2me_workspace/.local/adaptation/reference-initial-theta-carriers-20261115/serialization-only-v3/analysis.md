S 的实际 signature 报告为 457,549,780 bytes。20 个 source/targetRawBinderInventory/Placement 数组占 456,690,898 bytes（99.812%），其余内容仅 858,882 bytes。路径数组按完整 Expr 树的每次出现展开，并为每个 BinderInfo 复制完整路径；现有 Expr DAG 的共享不会作用于已经生成的 Array String。前两条路径的四数组彼此相同，接着两条路径也彼此相同。

本草稿基于两行类型修正版，只增加一个返回 Json 的输出辅助函数，并替换两处 row 各四个数组字段。替换值明确指定 enclosing signature report 中已有的 completeFaithfulReplaySignature 或 completeTargetSignature 根、同一 row path、原 binderInventory 或 binderPlacement 函数名、初始路径 root，以及每条 DAG 入边均展开的规则。它们是现有数组的重建表示。所有原实际比较、rawfalse 字段、完整数据和 recursor/autoParam 检查、owner/axiom 检查、严格 Expr.equal roundtrip 与默认 heartbeat 预算均不改。

恢复先从指定完整 signature DAG 根按 row path 选子表达式：domain 选择 forall/lam 的 type，fn/arg/type/value/body 选择对应子节点，projected 选择 proj.body。然后执行原遍历。forall/lam 先输出各自的 BinderInfo，再依次访问 domain、body；app 访问 fn、arg；let 访问 type、value、body，且不额外输出 let BinderInfo；proj 访问 body；原 mdata 规则忽略元数据。Placement 从新的 root 开始，边路径完全使用原函数字符串。必须展开每次出现，不能用全局 visited 集合去重。

不使用 contextSize 剥闭包：mkLambdaFVars 的默认 usedLetOnly=true 会省略未使用的 let。直接从完整 signature 根按原路径定位，不需要该假设。遍历过程的局部 instantiate1 仅把原 bound-variable 叶替换成 free-variable 叶；两者在原两个 BinderInfo 遍历中均不产生条目，故不会改变数组。引用 faithful source 根是必要的；不能误用未经 replay 的 completeSourceSignature。

S 的 20 个原数组均已离线重建，逐项核对原数组的 SHA-256、字节数和条目数，全部一致。结果在 ../serialization-analysis/S-all20-binder-arrays-exact-reconstruction.json，脚本在同目录 reconstruct_S_binder_arrays.py。这证明本次 S 输入上的序列化恢复恒等；不构成新的内核验收。原 S 文件未修改。

新输出不再构造这 20 个数组，但原 strictBinderShape、暴露 domain 比较以及原计数计算仍保留，并仍可能展开大树。因此这里只量化输出体积，不能据此推定图算、总耗时或峰值内存。当前超时任务没有终态资源回执，仍按未知记录。本目录未编译，未提交 CI；下一次仅需验收这一条修改后的源，不重复 S。
