def retryValueAndRuleChecks (rs : Relocations) (owners : Array Name) (config record : Json)
    (target : ConstantInfo) (sourceParams : List Name) (canonical targetLevels : List Level)
    (sourceType : Expr) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do throwError "Complete recursor/constructor computation shape changed"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  let mut valueCompared := false
  let mut replayReports := #[]
  let valueJson ← checked (field record "valueExpr")
  if !sourceProp && valueJson != Json.null then
    let decoded := (← checked (decodeExpr rs valueJson)).instantiateLevelParams sourceParams canonical
    let (value, report) ← replayExactInitialThetaStandardApps rs owners config original decoded
    let some targetValue := target.value? (allowOpaque := true) | throwError "Actual complete data value missing"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq "complete replayed data value inhabits complete replayed source type"
      (← kernelCheck original.toString value) sourceType
    kernelTermEq "complete faithful replayed computational source/current value" value targetValue
    for term in #[value, targetValue] do
      for dep in term.getUsedConstants do allowedOwner rs owners dep
      ensureStandard "complete data replay dependency axioms" (← expressionAxioms term)
    valueCompared := true
    replayReports := replayReports.push (Json.mkObj [("location", toJson "whole-computational-value"), ("replay", report)])
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut ruleCount := 0
  if let .recInfo recursor := target then
    unless rules.size == recursor.rules.length do throwError "Complete recursor rule count changed"
    for i in [:rules.size] do
      let decoded := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let (rhs, report) ← replayExactInitialThetaStandardApps rs owners config original decoded
      let actual := recursor.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      kernelTermEq s!"complete faithful replayed recursor RHS {i}" rhs actual
      for term in #[rhs, actual] do
        for dep in term.getUsedConstants do allowedOwner rs owners dep
        ensureStandard "complete recursor replay axioms" (← expressionAxioms term)
      replayReports := replayReports.push (Json.mkObj [("location", toJson s!"recursor-rule-{i}"), ("replay", report)])
      ruleCount := ruleCount + 1
  else
    unless rules.isEmpty do throwError "Unexpected archived recursor rules"
  let structureJson ← checked (field record "structure")
  if structureJson != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name | throwError "Actual complete structure missing"
    unless (← checked (field structureJson "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do throwError "Complete structure metadata changed"
    let autos ← checked (arrayField structureJson "fieldAutoParamExprs")
    unless autos.size == info.fieldInfo.size do throwError "Structure autoParam count changed"
    for i in [:autos.size] do
      match autos[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some actual =>
        unless sourceJson != Json.null do throwError "Archived autoParam missing"
        let decoded := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let (value, report) ← replayExactInitialThetaStandardApps rs owners config original decoded
        let actual := actual.instantiateLevelParams target.levelParams targetLevels
        kernelTermEq "complete faithful replayed structure autoParam" value actual
        replayReports := replayReports.push (Json.mkObj [("location", toJson s!"structure-autoParam-{i}"), ("replay", report)])
      | sourceJson, none => unless sourceJson == Json.null do throwError "Actual autoParam missing"
  return Json.mkObj [("completeComputationalDataValueCompared", toJson valueCompared),
    ("proofValueComparisonOmittedForPropositions", toJson sourceProp),
    ("completeRecursorRulesCompared", toJson ruleCount), ("replayLocations", Json.arr replayReports),
    ("completeComputationShapeEqual", toJson true), ("kernelPropositionalValueEqualityUsed", toJson false)]
