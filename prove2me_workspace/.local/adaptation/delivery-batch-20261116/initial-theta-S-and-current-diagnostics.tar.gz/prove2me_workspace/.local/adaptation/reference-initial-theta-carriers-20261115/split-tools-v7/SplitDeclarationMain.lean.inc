def splitSetup : TermElabM (Json × Relocations × Array Name × Json × Json) := do
  let (config, rs, owners, compatibility) ← withCurrHeartbeats do
    unless Lean.versionString == "4.33.1" && maxHeartbeats.get (← getOptions) == 200000 do
      throwError "Exact target compiler and unchanged default budget required"
    let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
    let rs ← readRelocations config
    let modules ← (← checked (arrayField config "modules")).mapM fun r => return (← checked (stringField r "target")).toName
    let deps := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
    let prefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
    let env ← getEnv
    let mut owners := #[]
    for m in env.header.moduleNames do
      unless prefixes.any (·.isPrefixOf m) || (modules ++ deps).contains m do throwError "Forbidden module {m}"
      owners := owners.push m
    let (facts, _) ← boundedMetaAuditUnit "actual platform facts" (verifyPlatformHelperFacts config)
    let ((rs, _), _) ← boundedMetaAuditUnit "four genuine original source proofs" (installExactInitialThetaProofValues rs owners config facts)
    let ((rs, finite), _) ← boundedMetaAuditUnit "exact standard Prop proof" (installInitialThetaStandardCompatibility rs owners config)
    let ((rs, adic), _) ← boundedMetaAuditUnit "all35accepted genuine adic DAG types and values" (installInitialThetaAdicSourceDagValues rs owners config)
    let (bridges, _) ← boundedMetaAuditUnit "actual source/native predicate bridges" (verifyInitialThetaSemanticBridges config)
    return (config, rs, owners, Json.mkObj [("finiteQuotients", finite), ("adicCompleteSourceTypeValueReplay", adic),
      ("predicateSemanticBridges", bridges), ("allRequiredKernelChecksPassed", toJson true)])
  let binding ← checked (field config "singleSourceDeclaration")
  let view ← jsonFile (← checked (stringField binding "path"))
  unless (← checked (stringField view "schema")) == "initial-theta-exact-single-source-record-view-v1" &&
      (← checked (view.getObjValAs? Nat "completeOriginalRecordCount")) == 232 &&
      (← checked (view.getObjValAs? Nat "completeOriginalSelectedCount")) == 204 do throwError "Wrong source record view"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field view key)) == (← checked (field config key)) do throwError "Source provenance changed"
  let record ← checked (field view "record")
  unless (← checked (field record "name")) == (← checked (field config "splitOriginal")) &&
      (← checked (record.getObjValAs? Bool "selected")) do throwError "Wrong exact selected split declaration"
  return (config, rs, owners, compatibility, record)

def splitValueCheck (dagStore : SplitEvidenceDagRef) (rs : Relocations) (owners : Array Name) (config record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sp ← namesFromJson (← checked (field record "levelParams"))
  let canonical : List Level := (canonicalLevels sp.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "No exact identity"
  let targetLevels : List Level ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let levels : Array Level ← checked (reorder indices canonical.toArray)
      pure levels.toList
  let decoded ← retryDefaultPhase "complete source type decode" do
    pure ((← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical)
  let (sourceType, typeReplay) ← retryDefaultPhase "complete source type replay" (replayExactInitialThetaStandardApps dagStore rs owners config original decoded)
  retryDefaultPhase "whole value leaf exact complete type precondition" do
    kernelTypeEq "faithful source type and actual target type" sourceType (target.type.instantiateLevelParams target.levelParams targetLevels)
  let values ← retryDefaultPhase "complete data value and available recursor/autoParam comparisons" do
    retryValueAndRuleChecks dagStore rs owners config record target sp canonical targetLevels sourceType
  return Json.mkObj [("wholeValueAndRules", values), ("wholeTypeReplay", typeReplay),
    ("completeReplayedSourceType", ← saveEvidenceExpr dagStore sourceType),
    ("completeActualTargetType", ← saveEvidenceExpr dagStore (target.type.instantiateLevelParams target.levelParams targetLevels)),
    ("completeTypePreconditionKernelChecked", toJson true), ("kernelPropositionalValueEqualityUsed", toJson false)]

def runSplitDeclaration : TermElabM Unit := do
  let dagStore : SplitEvidenceDagRef ← IO.mkRef (default, #[], #[])
  let (config, rs, owners, compatibility, record) ← splitSetup
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let targetName ← checked (relocated rs original)
  let target ← getConstInfo targetName
  let mode ← checked (stringField config "splitMode")
  let report ← match mode with
    | "signature" => splitSignatureCheck dagStore rs owners config record target
    | "value" => splitValueCheck dagStore rs owners config record target
    | "axioms" => retryDefaultPhase "complete actual owned type/value/recursor axiom and owner audit" do
      let row ← auditDeclaration rs owners targetName
      let fields ← checked row.getObj?
      let fullType ← saveEvidenceExpr dagStore target.type
      let fullValue ← match target.value? (allowOpaque := true) with
        | none => pure Json.null
        | some value => saveEvidenceExpr dagStore value
      return Json.mkObj ((fields.toList.filter (fun p => p.1 != "elaboratedExpr")) ++
        [("elaboratedExpr", fullType), ("completeActualValue", fullValue)])
    | _ => throwError "Unsupported first split mode"
  let dag ← retryDefaultPhase "complete shared Expr DAG strict roundtrip for every evidence root" (finishSplitEvidenceDag dagStore)
  withCurrHeartbeats do
    let output ← absoluteEnv "NEXT_CARRIER_SPLIT_DIAGNOSTIC_OUTPUT"
    IO.FS.writeFile output ((Json.mkObj [
      ("schema", toJson "initial-theta-one-declaration-split-diagnostic-v1"), ("compilerVersion", toJson Lean.versionString),
      ("original", toJson original.toString), ("target", toJson targetName.toString), ("mode", toJson mode),
      ("report", report), ("sharedLosslessExpressionEvidence", dag), ("standardCompatibilityEvidence", compatibility),
      ("completeSingleSourceRecordBinding", ← checked (field config "singleSourceDeclaration")),
      ("requiredSiblingModes", toJson #["signature", "value", "axioms"]),
      ("rawOriginalTypeClaimedNative433KernelChecked", toJson false), ("defaultLogicalCheckHeartbeatBudget", toJson (200000 : Nat)),
      ("acceptedCorrespondenceGenerated", toJson false), ("formalKernelAcceptanceGenerated", toJson false),
      ("priorOver16GiBLeafAccepted", toJson false)]).compress ++ "\n")
    Lean.Core.checkMaxHeartbeats "single declaration split report emission"
