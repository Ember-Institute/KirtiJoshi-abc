import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Places
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PointMap
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_GlobalField
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_PlacesOver
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_PrimeToOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Weierstrass
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_NormalizedOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_JInvariant
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Parametrization
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_AdmissiblePrime
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateStructure
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Orbicurve
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_TateFamily
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_LocalConditions
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ThetaData_Basic

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

structure Relocation where
  original : Name
  target : Name
  permutation : Option (Array Nat)
  expectedInstance : Option Bool
  expectedAxioms : Option (Array Name)

structure Relocations where
  rows : Array Relocation
  projectPrefixes : Array Name
  sourcePrefixes : Array Name
  targetPrefix : Name
  excludedSourceNames : Array Name
  sourceProofValues : Array (Name × (List Name × Expr))
  standardProofValues : Array (Name × (List Name × Expr))
  sourceCompatibilityValues : Array (Name × (List Name × Expr))

def Relocations.find? (rs : Relocations) (p : Relocation → Bool) : Option Relocation := rs.rows.find? p
def Relocations.any (rs : Relocations) (p : Relocation → Bool) : Bool := rs.rows.any p

def projectName (rs : Relocations) (n : Name) : Bool :=
  rs.projectPrefixes.any (·.isPrefixOf n) || rs.excludedSourceNames.contains n

def relocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.original == n) then return r.target
  if projectName rs n then throw s!"Unmapped project name {n}"
  return n

def inverseRelocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.target == n) then return r.original
  if projectName rs n then throw s!"Unmapped wrapped name {n}"
  return n

def reorder (indices : Array Nat) (us : Array α) : Except String (Array α) := do
  unless indices.size == us.size && indices.toList.eraseDups.length == us.size do
    throw "Universe permutation has incorrect size or repeated indices"
  indices.mapM fun i => match us[i]? with
    | some u => pure u
    | none => throw "Universe permutation index out of range"

partial def decodeExpr (rs : Relocations) (j : Json) : Except String Expr := do
  let recur := decodeExpr rs
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    if let some source := rs.sourceCompatibilityValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == source.2.1.length do throw "Exact source compatibility universe arity differs"
      return source.2.2.instantiateLevelParams source.2.1 levels.toList
    if let some proof := rs.standardProofValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == proof.2.1.length do
        throw "Universe arity differs for the exact standard proposition-valued instance proof"
      return proof.2.2.instantiateLevelParams proof.2.1 levels.toList
    if let some proof := rs.sourceProofValues.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == proof.2.1.length do
        throw "Universe arity differs for exact genuine equation source proof value"
      return proof.2.2.instantiateLevelParams proof.2.1 levels.toList
    let target ← relocated rs original
    let mut levels ← (← arrayField j "levels").mapM decodeLevel
    if let some r := rs.find? (·.original == original) then
      if let some indices := r.permutation then levels ← reorder indices levels
    return .const target levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocated rs (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unknown Expr kind {k}"

def readRelocations (config : Json) : MetaM Relocations := do
  let projectPrefixes := (← namesFromJson (← checked (field config "projectPrefixes"))).toArray
  let sourcePrefixes := (← namesFromJson (← checked (field config "originalProjectPrefixes"))).toArray
  let targetPrefix ← checked (decodeName (← checked (field config "targetProjectPrefix")))
  unless !projectPrefixes.isEmpty && !sourcePrefixes.isEmpty && targetPrefix != .anonymous do
    throwError "Empty project-prefix policy"
  let mut result : Array Relocation := #[]
  for key in #["projectMap", "standardRenames"] do
    for row in ← checked (arrayField config key) do
      let original ← checked (decodeName (← checked (field row "originalName")))
      let targetJson ← checked (field row "targetName")
      let target ← if targetJson == Json.null then do
        unless key == "projectMap" && (← checked (stringField row "mappingRole")) == "prior-accepted-required" do
          throwError "Only accepted legacy prior identities may need platform Name resolution"
        let display ← checked (stringField row "target")
        let owner := (← checked (stringField row "targetOwner")).toName
        let env ← getEnv
        let matchingTargets := env.constants.fold (fun acc n _ =>
          if n.toString == display && moduleOf env n == some owner then acc.push n else acc) (#[] : Array Name)
        unless matchingTargets.size == 1 do
          throwError "Accepted prior target Name is not unique at expected owner: {display}"
        pure matchingTargets[0]!
      else checked (decodeName targetJson)
      unless original.toString == (← checked (stringField row "original")) &&
        target.toString == (← checked (stringField row "target")) do
        throwError "Structural relocation name mismatch"
      if key == "standardRenames" then
        if projectPrefixes.any (·.isPrefixOf original) || projectPrefixes.any (·.isPrefixOf target) then
          throwError "Standard relocation contains project name"
        unless (← checked (stringField row "evidence")).length > 0 do
          throwError "Standard rename requires reviewed compiler/source evidence"
      else
        let exactShifts := #[(`Iut.OrbicurveDataSection.XK._proof_2, `AbcAdaptation.Reference.Iut.OrbicurveDataSection.XK._proof_1),
          (`Iut.curveK._proof_2, `AbcAdaptation.Reference.Iut.curveK._proof_1)]
        let exactShift := exactShifts.contains (original, target)
        unless sourcePrefixes.any (·.isPrefixOf original) && (target == targetPrefix ++ original || exactShift) do
          throwError "Unexpected project relocation {original} -> {target}"
      if result.any (fun r => r.original == original || r.target == target) then
        throwError "Duplicate or non-injective relocation {original} -> {target}"
      let indicesJson ← checked (field row "targetToSourceUniverseIndices")
      let permutation ← if indicesJson == Json.null then pure none else
        pure (some (← checked ((← checked indicesJson.getArr?).mapM Json.getNat?)))
      let expectedInstance ← if key == "projectMap" then
        pure (some (← checked (row.getObjValAs? Bool "expectedIsInstance"))) else pure none
      let expectedAxioms ← if key == "projectMap" then
        pure (some (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray) else pure none
      result := result.push ⟨original, target, permutation, expectedInstance, expectedAxioms⟩
  let excludedRows ← checked (arrayField config "excludedOriginalDeclarations")
  let excludedSourceNames ← excludedRows.mapM fun row => do
    checked (decodeName (← checked (field row "originalName")))
  unless excludedSourceNames.size == excludedSourceNames.toList.eraseDups.length &&
      excludedSourceNames.all (fun n => (`_private).isPrefixOf n && !(result.any (·.original == n))) do
    throwError "Excluded original-private identities overlap relocation map or are not private"
  return ⟨result, projectPrefixes, sourcePrefixes, targetPrefix, excludedSourceNames, #[], #[], #[]⟩

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No imported owner for {name}"
  unless modules.contains owner do
    throwError "Forbidden dependency {name}, owner {owner}"
  if rs.sourcePrefixes.any (·.isPrefixOf name) || rs.excludedSourceNames.contains name then
    throwError "Unrelocated original project dependency {name}"

def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  if let .axiomInfo _ := ci then throwError "Carrier declares an axiom {name}"
  let axs ← collectAxioms name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"carrier {name}" axs
  ensureStandard s!"carrier type {name}" taxs
  let value? := ci.value? (allowOpaque := true)
  let vaxs ← match value? with
    | some v => expressionAxioms v
    | none => pure #[]
  ensureStandard s!"carrier value {name}" vaxs
  for expr in #[ci.type] ++ value?.toArray do
    for dep in expr.getUsedConstants do allowedOwner rs modules dep
  if let .recInfo r := ci then
    for rule in r.rules do
      for dep in rule.rhs.getUsedConstants do allowedOwner rs modules dep
      ensureStandard s!"recursor rule {name}" (← expressionAxioms rule.rhs)
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("hasValue", toJson value?.isSome),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name))]

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

def boundPlatformHelperEvidence (config : Json) (key : String) : MetaM Json := do
  let evidence ← checked (field config "platformHelperEvidence")
  let binding ← checked (field evidence key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do
    throwError "Platform helper evidence changed after hash binding: {key}"
  unless (← checked (stringField binding "sha256")).length == 64 do
    throwError "Missing external SHA256 binding for platform helper evidence: {key}"
  return actual

def verifyPlatformHelperFacts (config : Json) : MetaM Json := do
  let facts ← boundPlatformHelperEvidence config "facts"
  let receipt ← boundPlatformHelperEvidence config "receipt"
  unless (← checked (stringField receipt "job_id")) == (← checked (stringField (← checked (field config "platformHelperEvidence")) "job_id")) &&
      (← checked (stringField receipt "status")) == "succeeded" do
    throwError "Expected successful actual platform helper query receipt"
  let result ← checked (field receipt "result")
  unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
    throwError "Actual platform helper query exit code is not zero"
  let snapshot ← checked (field result "snapshot")
  unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
      (← checked (field snapshot "snapshot_id")) == Json.null do
    throwError "Wrong actual platform helper query workspace mode"
  unless (← checked (stringField facts "schema")) == "initial-theta-platform-helper-facts-v1" &&
      (← checked (stringField facts "compilerVersion")) == Lean.versionString &&
      (← checked (facts.getObjValAs? Nat "sourceRecordCount")) == 232 &&
      (← checked (facts.getObjValAs? Nat "selectedSourceCount")) == 204 &&
      (← checked (facts.getObjValAs? Nat "selectedMissingCount")) == 3 &&
      (← checked (facts.getObjValAs? Nat "ownedDeclarationCount")) == (← checked (config.getObjValAs? Nat "expectedOwnedDeclarationCount")) do
    throwError "Unexpected actual platform helper query dimensions/compiler"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field facts key)) == (← checked (field config key)) do
      throwError "Actual platform helper query provenance changed: {key}"
  unless (← checked (arrayField facts "targetOnlyNames")).isEmpty do
    throwError "Unresolved target-only compiler declaration requires source provenance review"
  let env ← getEnv
  let moduleRows ← checked (arrayField config "modules")
  let modules ← moduleRows.mapM fun row => do
    return (← checked (stringField row "target")).toName
  let actualOwned := env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)
  let ownedRows ← checked (arrayField facts "ownedDeclarations")
  let ownedNames ← ownedRows.mapM fun row => do
    checked (decodeName (← checked (field row "nameExpr")))
  unless ownedNames.size == (← checked (config.getObjValAs? Nat "expectedOwnedDeclarationCount")) && ownedNames.toList.eraseDups.length == ownedNames.size &&
      actualOwned.size == ownedNames.size && actualOwned.all ownedNames.contains do
    throwError "Actual current owned declaration set changed after platform query"
  for row in ownedRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    let ci ← getConstInfo name
    unless name.toString == (← checked (stringField row "name")) &&
        moduleOf env name == some (← checked (stringField row "module")).toName &&
        kind ci == (← checked (stringField row "constantKind")) &&
        Json.arr (ci.levelParams.toArray.map encodeName) == (← checked (field row "levelParams")) &&
        Lean.Meta.isInstanceCore env name == (← checked (row.getObjValAs? Bool "isInstance")) do
      throwError "Actual owned declaration identity/owner/kind/universes/instance changed: {name}"
    unless !(← checked (row.getObjValAs? Bool "hasSorryAx")) do
      throwError "Actual platform query contains sorryAx: {name}"
    for key in #["axioms", "typeAxioms", "valueAxioms"] do
      for ax in ← checked (arrayField row key) do
        unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
          throwError "Unexpected actual platform query axiom: {name}"
  let helperRows ← checked (arrayField facts "helperFacts")
  for row in helperRows do
    let name ← checked (decodeName (← checked (field row "nameExpr")))
    unless ownedNames.contains name do throwError "Unowned actual helper fact {name}"
    let ci ← getConstInfo name
    unless (← checked (encodeExpr ci.type)) == (← checked (field row "elaboratedExpr")) do
      throwError "Actual platform helper type changed: {name}"
    let value ← match ci.value? (allowOpaque := true) with
      | none => pure Json.null | some expr => checked (encodeExpr expr)
    unless value == (← checked (field row "valueExpr")) do
      throwError "Actual platform helper value changed: {name}"
  let candidates ← checked (arrayField facts "expectedCurrentCandidates")
  unless candidates.size == 232 do throwError "Wrong actual public source candidate count"
  let mut selectedCount := 0
  let mut missingCount := 0
  for row in candidates do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let target ← checked (decodeName (← checked (field row "candidateTargetName")))
    let selected ← checked (row.getObjValAs? Bool "selected")
    let present ← checked (row.getObjValAs? Bool "present")
    unless env.contains target == present do
      throwError "Actual source candidate presence changed: {original}"
    if selected then
      selectedCount := selectedCount + 1
      if !present then
        missingCount := missingCount + 1
        unless #[`Iut.OrbicurveDataSection.XK._proof_2, `Iut.curveK._proof_2, `Iut.galK._proof_2].contains original do
          throwError "Unresolved missing selected declaration {original}"
  unless selectedCount == 204 && missingCount == 3 do
    throwError "Unresolved generated names require actual evidence and a reviewed new attempt"
  return facts

-- Exact parent only. This diagnostic never changes the original raw guard.
def galKInternalSemiringData (sourceType targetType : Expr) : MetaM Json := do
  unless (binderInventory sourceType).size == 28 && (binderInventory targetType).size == 32 do
    throwError "Unexpected exact galK full raw BinderInfo dimensions"
  let expectedFlags : Array String := #["implicit", "instImplicit", "default", "implicit", "instImplicit", "instImplicit", "default", "default"]
  let accounting ← forallTelescope sourceType fun args sourceBody => do
    unless args.size == 8 do throwError "Expected all eight original galK parameters"
    let mut targetBody := targetType
    let mut domainReports : Array Json := #[]
    let mut instanceReports : Array Json := #[]
    for index in [:args.size] do
      let sourceDecl ← args[index]!.fvarId!.getDecl
      let .forallE _ targetDomain targetRest targetBinder := targetBody |
        throwError "Actual galK lost an exposed Pi binder"
      unless encodeBinder sourceDecl.binderInfo == expectedFlags[index]! && sourceDecl.binderInfo == targetBinder do
        throwError "Exact galK exposed binder attribute changed at {index}"
      let prefixArgs := args.extract 0 index
      kernelTypeEq s!"exact galK complete exposed parameter domain {index}"
        (← mkForallFVars prefixArgs sourceDecl.type) (← mkForallFVars prefixArgs targetDomain)
      let rawInventoryEqual := binderInventory sourceDecl.type == binderInventory targetDomain
      let rawPlacementEqual := binderPlacement sourceDecl.type == binderPlacement targetDomain
      if index != 7 then
        unless rawInventoryEqual && rawPlacementEqual do
          throwError "A galK parameter domain outside sigma contains different BinderInfo at {index}"
      else
        let sourceSigma := sourceDecl.type
        let targetSigma := targetDomain
        unless sourceSigma.getAppFn.isConstOf ``AlgEquiv && targetSigma.getAppFn.isConstOf ``AlgEquiv &&
            sourceSigma.getAppArgs.size == 8 && targetSigma.getAppArgs.size == 8 do
          throwError "Expected exact sigma AlgEquiv with three types and five data instances"
        let sourceSigmaArgs := sourceSigma.getAppArgs
        let targetSigmaArgs := targetSigma.getAppArgs
        for argumentIndex in [:8] do
          let sourceArgument := sourceSigmaArgs[argumentIndex]!
          let targetArgument := targetSigmaArgs[argumentIndex]!
          let sourceBinders := binderInventory sourceArgument
          let targetBinders := binderInventory targetArgument
          let argumentRawEqual := sourceBinders == targetBinders && binderPlacement sourceArgument == binderPlacement targetArgument
          if argumentIndex < 3 then
            unless argumentRawEqual do throwError "Exact sigma mathematical type argument BinderInfo changed"
            kernelTypeEq s!"sigma full mathematical type argument {argumentIndex}"
              (← mkForallFVars prefixArgs sourceArgument) (← mkForallFVars prefixArgs targetArgument)
            instanceReports := instanceReports.push (Json.mkObj [
              ("AlgEquivArgumentIndex", toJson argumentIndex), ("kind", toJson "mathematical-type"),
              ("rawBinderInfoInventoryAndPlacementEqual", toJson true), ("completeClosedTypeKernelEqual", toJson true)])
          else
            let sourceInstanceType ← whnf (← inferType sourceArgument)
            let targetInstanceType ← whnf (← inferType targetArgument)
            unless !(← isProp sourceInstanceType) && !(← isProp targetInstanceType) do
              throwError "An alleged galK data instance is a proposition"
            let expectedHead := if argumentIndex == 3 then ``CommSemiring else if argumentIndex < 6 then ``Semiring else ``Algebra
            unless sourceInstanceType.getAppFn.isConstOf expectedHead && targetInstanceType.getAppFn.isConstOf expectedHead do
              throwError "Exact sigma data instance class changed at {argumentIndex}"
            if argumentIndex == 4 || argumentIndex == 5 then
              unless sourceBinders.size == 1 && targetBinders.size == 3 &&
                  sourceBinders.all (· == "lambda:default") && targetBinders.all (· == "lambda:default") do
                throwError "Exact Semiring subtype-predicate lambda inventory changed"
            else
              unless argumentRawEqual do throwError "A sigma data slot outside the two Semiring instances changed BinderInfo"
            let closedSource ← mkLambdaFVars prefixArgs sourceArgument
            let closedTarget ← mkLambdaFVars prefixArgs targetArgument
            kernelTermEq s!"sigma complete closed computational data instance {argumentIndex}" closedSource closedTarget
            instanceReports := instanceReports.push (Json.mkObj [
              ("AlgEquivArgumentIndex", toJson argumentIndex), ("kind", toJson "computational-data-instance"),
              ("instanceClass", toJson expectedHead.toString), ("isProofSubterm", toJson false),
              ("sourceRawBinderInfo", toJson sourceBinders), ("targetRawBinderInfo", toJson targetBinders),
              ("rawBinderInfoInventoryAndPlacementEqual", toJson argumentRawEqual),
              ("closedOverAllSevenPreviousParameters", toJson true),
              ("completeClosedDataInstanceTypesAndValuesKernelEqual", toJson true),
              ("completeSourceDataExpression", ← checked (encodeExpr closedSource)),
              ("completeTargetDataExpression", ← checked (encodeExpr closedTarget))])
        -- This view records the two complete data slots separately. The original
        -- expressions are retained; exact reconstruction proves reversibility.
        -- The view itself is not used as a kernel typing or conversion input.
        let marker := Expr.sort .zero
        let sourceSlots := #[sourceSigmaArgs[4]!, sourceSigmaArgs[5]!]
        let targetSlots := #[targetSigmaArgs[4]!, targetSigmaArgs[5]!]
        let sourceViewArgs := (sourceSigmaArgs.set! 4 marker).set! 5 marker
        let targetViewArgs := (targetSigmaArgs.set! 4 marker).set! 5 marker
        let sourceView := mkAppN sourceSigma.getAppFn sourceViewArgs
        let targetView := mkAppN targetSigma.getAppFn targetViewArgs
        let sourceRestored := mkAppN sourceSigma.getAppFn ((sourceViewArgs.set! 4 sourceSlots[0]!).set! 5 sourceSlots[1]!)
        let targetRestored := mkAppN targetSigma.getAppFn ((targetViewArgs.set! 4 targetSlots[0]!).set! 5 targetSlots[1]!)
        unless sourceRestored.equal sourceSigma && targetRestored.equal targetSigma do
          throwError "Exact sigma data-slot view did not restore the complete original expressions"
        unless binderInventory sourceView == binderInventory targetView && binderPlacement sourceView == binderPlacement targetView do
          throwError "A sigma binder difference remains outside the two exact kernel-equal Semiring data slots"
      domainReports := domainReports.push (Json.mkObj [
        ("parameterIndex", toJson index), ("binderInfo", toJson (encodeBinder sourceDecl.binderInfo)),
        ("exposedBinderInfoStrictlyEqual", toJson true), ("completeClosedParameterDomainKernelEqual", toJson true),
        ("rawDomainBinderInventoryEqual", toJson rawInventoryEqual),
        ("rawDomainBinderPlacementEqual", toJson rawPlacementEqual),
        ("onlyTwoExactSemiringDataSlotsAccounted", toJson (index == 7))])
      targetBody := targetRest.instantiate1 args[index]!
    unless binderInventory sourceBody == binderInventory targetBody && binderPlacement sourceBody == binderPlacement targetBody do
      throwError "galK result type contains an unaccounted BinderInfo difference"
    kernelTypeEq "galK complete result type over all original parameters"
      (← mkForallFVars args sourceBody) (← mkForallFVars args targetBody)
    return (domainReports, instanceReports)
  return Json.mkObj [
    ("scope", toJson "Only AlgEquiv args4/5 in galK parameter7 sigma; complete Semiring data instances"),
    ("sourceRawSignatureBinderCount", toJson (28 : Nat)), ("targetRawSignatureBinderCount", toJson (32 : Nat)),
    ("originalRawSignatureInventoryEqual", toJson false), ("originalRawSignaturePlacementEqual", toJson false),
    ("allEightExposedBinderAttributesStrictlyEqual", toJson true),
    ("allEightCompleteParameterDomainsKernelEqual", toJson true),
    ("allOtherDomainAndResultBinderInfoStrictlyEqual", toJson true),
    ("allFiveCompleteAlgEquivDataInstanceTypesAndValuesKernelEqual", toJson true),
    ("threeMathematicalTypeArgumentsBinderInfoAndKernelTypesEqual", toJson true),
    ("twoSemiringSlotViewExactExprEqualRoundTrip", toJson true),
    ("twoSemiringSlotViewRemainingBinderInfoStrictlyEqual", toJson true),
    ("viewNeverUsedAsKernelTypeOrValue", toJson true),
    ("domainComparisons", Json.arr accounting.1), ("AlgEquivArgumentComparisons", Json.arr accounting.2)]


def boundExactProofEvidence (config : Json) (key : String) : MetaM Json := do
  let binding ← checked (field config key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) &&
      (← checked (stringField binding "sha256")).length == 64 do
    throwError "Exact source-backed evidence changed after binding: {key}"
  return actual

def installExactInitialThetaProofValues (rs : Relocations) (allowedOwners : Array Name)
    (config facts : Json) : MetaM (Relocations × Array Json) := do
  let source ← boundExactProofEvidence config "exactOriginalProofRecords"
  let priorShiftReceipt ← boundExactProofEvidence config "successfulShiftReceipt"
  let priorGalReceipt ← boundExactProofEvidence config "successfulGalReceipt"
  unless (← checked (stringField priorShiftReceipt "job_id")) == "ci-014978-ca2f4850" &&
      (← checked (stringField priorShiftReceipt "status")) == "succeeded" &&
      (← checked (stringField priorGalReceipt "job_id")) == "ci-015034-278554cf" &&
      (← checked (stringField priorGalReceipt "status")) == "succeeded" do
    throwError "Exact actual successful source-backed diagnostics are not bound"
  for receipt in #[priorShiftReceipt, priorGalReceipt] do
    unless (← checked ((← checked (field receipt "result")).getObjValAs? Nat "exit_code")) == 0 do
      throwError "Exact diagnostic receipt did not exit zero"
  let exact := #[`Iut.OrbicurveDataSection.XK._proof_1, `Iut.curveK._proof_1,
    `Iut.galK._proof_1, `Iut.galK._proof_2]
  let bindings ← checked (arrayField config "proofValueResolutions")
  unless bindings.size == 4 && rs.sourceProofValues.isEmpty && rs.standardProofValues.isEmpty && rs.sourceCompatibilityValues.isEmpty do
    throwError "Expected exactly four actual source proof values and no data/standard substitutions"
  let sourceRecords ← checked (arrayField source "records")
  let mut result := rs
  let mut reports : Array Json := #[]
  for original in exact do
    let rows := bindings.filter fun row => (field row "originalName").toOption == some (encodeName original)
    let matchingRecords := sourceRecords.filter fun row => (field row "nameExpr").toOption == some (encodeName original)
    unless rows.size == 1 && matchingRecords.size == 1 && !(result.any (·.original == original)) do
      throwError "Genuine source proof identity missing or improperly mapped: {original}"
    let binding := rows[0]!
    let record := matchingRecords[0]!
    unless record == (← checked (field binding "sourceRecord")) &&
        (← checked (field binding "standaloneTargetIdentity")) == Json.null &&
        (← checked (stringField record "constantKind")) == "theorem" &&
        (← checked (record.getObjValAs? Bool "selected")) &&
        (← checked (record.getObjValAs? Bool "isProposition")) &&
        !(← checked (record.getObjValAs? Bool "isInstance")) do
      throwError "Only exact genuine selected original proposition proofs may be replayed"
    let parent ← checked (decodeName (← checked (field binding "parentOriginalName")))
    let parentTarget ← checked (relocated result parent)
    let parentFacts := (← checked (arrayField facts "helperFacts")).filter fun row =>
      (field row "nameExpr").toOption == some (encodeName parentTarget)
    unless parentFacts.size == 1 && parentFacts[0]! == (← checked (field binding "actualParentFact")) do
      throwError "Whole original proof-parent data is not bound to actual current compiler facts"
    let params ← namesFromJson (← checked (field record "levelParams"))
    unless params.eraseDups == params do throwError "Repeated source proof universe parameter"
    let levels := (canonicalLevels params.length).map Level.param
    let type ← checked (decodeExpr result (← checked (field record "elaboratedExpr")))
    let value ← checked (decodeExpr result (← checked (field record "valueExpr")))
    let rawRs := { result with rows := #[], projectPrefixes := #[], excludedSourceNames := #[], sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[] }
    let rawType ← checked (decodeExpr rawRs (← checked (field record "elaboratedExpr")))
    unless binderInventory rawType == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
      throwError "Original source proof signature BinderInfo serialization differs"
    let canonicalType := type.instantiateLevelParams params levels
    let canonicalValue := value.instantiateLevelParams params levels
    match ← kernelCheck "genuine original source proof proposition type" canonicalType with
    | .sort level => unless level.isAlwaysZero do throwError "Genuine source proof type is not Prop"
    | _ => throwError "Genuine source proof type is not a type"
    let inferred ← kernelCheck "genuine original source proof body" canonicalValue
    kernelTypeEq "genuine original source proof inhabits its exact full original type" inferred canonicalType
    let inferredInventoryEqual := binderInventory inferred == binderInventory canonicalType
    let inferredPlacementEqual := binderPlacement inferred == binderPlacement canonicalType
    if original != `Iut.galK._proof_2 then
      unless inferredInventoryEqual && inferredPlacementEqual do throwError "Source class proof inferred full BinderInfo differs"
    else
      unless !inferredInventoryEqual && !inferredPlacementEqual do
        throwError "The exact actual galK source proof inferred BinderInfo diagnostic changed"
    let sourceAxioms := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
    let expectedAxioms := (← namesFromJson (← checked (field binding "expectedSourceAxioms"))).toArray
    unless sourceAxioms.qsort Name.lt == expectedAxioms.qsort Name.lt do
      throwError "Genuine source proof axiom closure differs from accepted graph"
    let taxs ← expressionAxioms canonicalType
    let vaxs ← expressionAxioms canonicalValue
    ensureStandard "genuine original source proof type" taxs
    ensureStandard "genuine original source proof body" vaxs
    for term in #[canonicalType, canonicalValue] do
      for dep in term.getUsedConstants do allowedOwner result allowedOwners dep
    result := { result with sourceProofValues := result.sourceProofValues.push (original, (params, value)) }
    reports := reports.push (Json.mkObj [
      ("original", toJson original.toString), ("originalName", encodeName original), ("sourceRecord", record),
      ("resolution", toJson "genuine-exported-original-proof-value"), ("standaloneTargetIdentity", Json.null),
      ("sourceSignatureBinderInfoSerializationValidated", toJson true),
      ("exactOriginalTypeKernelChecked", toJson true), ("genuineOriginalValueInhabitsExactOriginalType", toJson true),
      ("inferredTypeFullBinderInfoInventoryEqual", toJson inferredInventoryEqual),
      ("inferredTypeFullBinderInfoPlacementEqual", toJson inferredPlacementEqual),
      ("inferredBinderInfoPolicy", toJson (if original == `Iut.galK._proof_2 then
        "Actual full inferred implementation BinderInfo differs; no named target identity. Exact original proposition/body kernel checked; parent whole computational data equality remains mandatory." else "Full inferred BinderInfo inventory and placement strictly equal.")),
      ("expandedTypeAxioms", toJson (taxs.map Name.toString)), ("expandedValueAxioms", toJson (vaxs.map Name.toString)),
      ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true), ("expandedDependenciesHaveAllowedOwners", toJson true),
      ("parentOriginal", toJson parent.toString), ("parentTarget", encodeName parentTarget),
      ("parentWholeValueEqualityRequired", toJson true), ("parentKernelDefinitionalValueEqualityRequired", toJson true),
      ("actualSourceDiagnosticJob", toJson "ci-014978-ca2f4850"), ("actualWholeDataDiagnosticJob", toJson "ci-015034-278554cf"),
      ("hasSorryAx", toJson false)])
  return (result, reports)

def compareRecord (rs : Relocations) (allowedOwners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.eraseDups == sourceParams do throwError "Duplicate universe parameter {original}"
  unless sourceParams.length == target.levelParams.length do
    throwError "Universe parameter count differs for {original}"
  unless (← checked (stringField record "constantKind")) == kind target do
    throwError "ConstantInfo kind differs for {original}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original axiom for {original}"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "Missing map entry {original}"
  let some expectedAxioms := rel.expectedAxioms |
    throwError "Missing accepted-graph source axiom inventory {original}"
  let sourceAxiomNames := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxiomNames.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Original axiom closure differs from accepted compiler graph {original}"
  let some expectedInstance := rel.expectedInstance |
    throwError "Missing accepted-graph instance flag {original}"
  unless (← checked (record.getObjValAs? Bool "isInstance")) == expectedInstance do
    throwError "Exported original instance flag differs from accepted graph {original}"
  unless Lean.Meta.isInstanceCore (← getEnv) target.name == expectedInstance do
    throwError "Instance registry membership differs for {original}"
  let targetLevels ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let reordered ← checked (reorder indices canonical.toArray)
      pure reordered.toList
  let signatureRs := { rs with sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[] }
  let originalSignature ← checked (decodeExpr signatureRs (← checked (field record "elaboratedExpr")))
  let originalSignature := originalSignature.instantiateLevelParams sourceParams canonical
  let sourceTypeRaw ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams targetLevels
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory originalSignature do
    throwError "Unexpanded original signature BinderInfo serialization differs for {original}"
  let rawInventoryEqual := binderInventory originalSignature == binderInventory targetType
  let rawPlacementEqual := binderPlacement originalSignature == binderPlacement targetType
  let internalInstanceEvidence ← if original == `Iut.galK then do
    unless target.name == `AbcAdaptation.Reference.Iut.galK && !rawInventoryEqual && !rawPlacementEqual do
      throwError "Exact galK raw implementation BinderInfo diagnostic changed"
    galKInternalSemiringData sourceType targetType
  else do
    unless rawInventoryEqual do
      throwError "Full unexpanded original/actual target signature BinderInfo inventory differs for {original}"
    unless rawPlacementEqual do
      throwError "Full unexpanded original/actual target signature BinderInfo placement differs for {original}"
    pure Json.null
  kernelTypeEq s!"original versus target type {original}" sourceType targetType
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do
    throwError "Inductive/constructor/recursor computation shape differs for {original}"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  unless sourceProp == (← isProp target.type) do throwError "Proposition status differs {original}"
  let mut comparedValue := false
  let mut definitionallyEqualValue := false
  let originalValueJson ← checked (field record "valueExpr")
  -- Proof declarations are audited by exact type and axiom closure. For a data
  -- value containing proof fields, Kernel.isDefEq itself uses proof irrelevance.
  if !sourceProp && originalValueJson != Json.null then
    let sourceValue := (← checked (decodeExpr rs originalValueJson)).instantiateLevelParams sourceParams canonical
    let some targetValue := target.value? (allowOpaque := true) |
      throwError "Target value missing for {original}"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq s!"original value inhabits original type {original}"
      (← kernelCheck s!"original value {original}" sourceValue) sourceType
    kernelTypeEq s!"target value inhabits target type {original}"
      (← kernelCheck s!"target value {original}" targetValue) targetType
    kernelTermEq s!"original versus target computational value {original}" sourceValue targetValue
    definitionallyEqualValue := true
    comparedValue := true
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut comparedRules := 0
  if let .recInfo r := target then
    unless rules.size == r.rules.length do throwError "Recursor rule count differs {original}"
    for i in [:rules.size] do
      let sourceRhs := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let targetRhs := r.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      kernelTermEq s!"recursor rule {original} #{i}" sourceRhs targetRhs
      comparedRules := comparedRules + 1
  else
    unless rules.isEmpty do throwError "Unexpected original recursor rules {original}"
  let sourceStruct ← checked (field record "structure")
  unless (sourceStruct != Json.null) == (getStructureInfo? (← getEnv) target.name).isSome do
    throwError "Structure metadata presence differs {original}"
  if sourceStruct != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name |
      throwError "Target structure metadata missing {target.name}"
    unless (← checked (field sourceStruct "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do
      throwError "Complete structure field/parent metadata differs {original}"
    let autoParams ← checked (arrayField sourceStruct "fieldAutoParamExprs")
    unless autoParams.size == info.fieldInfo.size do
      throwError "Structure field autoParam count differs {original}"
    for i in [:autoParams.size] do
      match autoParams[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some targetExpr =>
        if sourceJson == Json.null then throwError "Missing source autoParam {original} #{i}"
        let sourceExpr := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let targetExpr := targetExpr.instantiateLevelParams target.levelParams targetLevels
        unless binderPlacement sourceExpr == binderPlacement targetExpr do
          throwError "Structure autoParam BinderInfo placement differs {original} #{i}"
        kernelTermEq s!"structure field autoParam {original} #{i}" sourceExpr targetExpr
      | sourceJson, none =>
        unless sourceJson == Json.null do throwError "Missing target autoParam {original} #{i}"
    unless (← checked (field sourceStruct "fieldsInConstructorOrder")) ==
        toJson (info.fieldNames.map Name.toString) do
      throwError "Structure field order differs {original}"
    let projections ← namesFromJson (← checked (field sourceStruct "projections"))
    let targetProjections ← projections.toArray.mapM fun n => checked (relocated rs n)
    unless targetProjections == info.fieldInfo.map (·.projFn) do
      throwError "Structure accessor identities/order differ {original}"
    for p in targetProjections do
      unless rs.any (·.target == p) do throwError "Unaudited structure accessor {p}"
  return Json.mkObj [("original", toJson original.toString), ("originalName", encodeName original),
    ("target", toJson target.name.toString), ("targetName", encodeName target.name),
    ("sourceRecord", record), ("kernelTypeEqual", toJson true),
    ("allExpressionBinderInfoEqual", toJson (rawInventoryEqual && rawPlacementEqual)),
    ("binderInfoPlacementEqual", toJson rawPlacementEqual),
    ("sourceSignatureBinderInfoSerializationValidated", toJson true),
    ("sourceTargetSignatureBinderInfoInventoryEqual", toJson rawInventoryEqual),
    ("sourceTargetSignatureBinderInfoPlacementEqual", toJson rawPlacementEqual),
    ("binderInfoComparisonScope", toJson "unexpanded-original-exported-signature-after-named-relocation-vs-actual-target-type"),
    ("exactInternalDataInstanceBinderAccounting", internalInstanceEvidence),
    ("strictRawBinderInfoOrExactGalKTwoSemiringDataAccountingPassed", toJson true),
    ("expandedOriginalTypeKernelEqual", toJson true),
    ("computationShapeEqual", toJson true), ("completeStructureMetadataEqual", toJson true),
    ("kernelValueEqual", toJson definitionallyEqualValue),
    ("computationalValueEqualityChecked", toJson comparedValue),
    ("kernelPropositionalValueEquality", toJson false),
    ("propositionalValueEqualityEvidence", Json.null),
    ("proofDeclaration", toJson sourceProp), ("recursorRulesCompared", toJson comparedRules),
    ("instanceRegistryMatchesAcceptedGraph", toJson true),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("expectedIsInstance", toJson expectedInstance),
    ("universeOriginalOrder", Json.arr (sourceParams.toArray.map encodeName)),
    ("universeTargetOrder", Json.arr (target.levelParams.toArray.map encodeName)),
    ("targetToSourceUniverseIndices", match rel.permutation with | none => Json.null | some a => toJson a)]

-- Each declaration receives the existing default budget. Neither the option nor
-- the maximum is increased. The final check also bounds work without internal
-- heartbeat checkpoints. IO counters use 1000 internal ticks per user heartbeat.
def boundedMetaAuditUnit (label : String) (action : MetaM α) : MetaM (α × Nat) :=
  withCurrHeartbeats do
    unless maxHeartbeats.get (← getOptions) == 200000 do
      throwError "Expected default maxHeartbeats200000 for each independent audit unit"
    let start ← IO.getNumHeartbeats
    let value ← action
    Lean.Core.checkMaxHeartbeats label
    let finish ← IO.getNumHeartbeats
    return (value, finish - start)

-- Diagnostic only. An emitted candidate is not an accepted relaxation.
structure BatchViews where
  sourceView : Expr
  targetView : Expr
  sourceRestored : Expr
  targetRestored : Expr
  slots : Array Json

private def strictBinderShape (s t : Expr) : Bool :=
  binderInventory s == binderInventory t && binderPlacement s == binderPlacement t

private def batchOwnedClosed (rs : Relocations) (owners : Array Name) (label : String) (e : Expr) : MetaM Unit := do
  requireClosed label e
  for dep in e.getUsedConstants do allowedOwner rs owners dep
  ensureStandard label (← expressionAxioms e)

private def batchJoin (s t sr tr : Expr) (a b : BatchViews) : BatchViews :=
  ⟨s, t, sr, tr, a.slots ++ b.slots⟩

-- Views are used only for BinderInfo accounting, never as kernel inputs.
partial def batchSignatureViews (rs : Relocations) (owners : Array Name)
    (ctx : Array Expr) (path : String) (source target : Expr) : MetaM BatchViews := do
  if strictBinderShape source target then return ⟨source, target, source, target, #[]⟩
  let result ← match source, target with
  | .app sf sa, .app tf ta => do
    let fnViews ← batchSignatureViews rs owners ctx (path ++ ".fn") sf tf
    let mut argumentViews : Option BatchViews := none
    if !strictBinderShape sa ta then
      let sft ← whnf (← inferType sf)
      let tft ← whnf (← inferType tf)
      if let .forallE _ sd _ .instImplicit := sft then
        if let .forallE _ td _ .instImplicit := tft then
          let st ← whnf (← inferType sa)
          let tt ← whnf (← inferType ta)
          if let .const sc _ := st.getAppFn then
            if let .const tc _ := tt.getAppFn then
              if sc == tc && isClass (← getEnv) sc && !(← isProp st) && !(← isProp tt) then
                let cs ← mkLambdaFVars ctx sa
                let ct ← mkLambdaFVars ctx ta
                let cst ← mkForallFVars ctx st
                let ctt ← mkForallFVars ctx tt
                kernelTypeEq s!"complete consumed instance parameter domains {path}"
                  (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
                kernelTypeEq s!"complete closed data instance types {path}" cst ctt
                kernelTermEq s!"complete closed non-Prop typeclass data values {path}" cs ct
                for e in #[cs, ct, cst, ctt] do batchOwnedClosed rs owners path e
                let row := Json.mkObj [
                  ("path", toJson (path ++ ".arg")), ("contextSize", toJson ctx.size),
                  ("applicationHeadSource", ← checked (encodeExpr (← mkLambdaFVars ctx sf.getAppFn))),
                  ("applicationHeadTarget", ← checked (encodeExpr (← mkLambdaFVars ctx tf.getAppFn))),
                  ("applicationArgumentIndex", toJson sf.getAppArgs.size),
                  ("bothConsumedBinders", toJson "instImplicit"),
                  ("instanceClass", toJson sc.toString), ("isProp", toJson false),
                  ("sourceRawBinderInventory", toJson (binderInventory sa)),
                  ("targetRawBinderInventory", toJson (binderInventory ta)),
                  ("sourceRawBinderPlacement", toJson (binderPlacement sa)),
                  ("targetRawBinderPlacement", toJson (binderPlacement ta)),
                  ("sourceClosedExpr", ← checked (encodeExpr cs)),
                  ("targetClosedExpr", ← checked (encodeExpr ct)),
                  ("sourceClosedType", ← checked (encodeExpr cst)),
                  ("targetClosedType", ← checked (encodeExpr ctt)),
                  ("completeConsumedParameterDomainsKernelEqual", toJson true),
                  ("completeClosedTypesKernelEqual", toJson true),
                  ("completeClosedValuesKernelEqual", toJson true),
                  ("allDependenciesHaveAllowedOwners", toJson true),
                  ("allAxiomsStandardOnly", toJson true),
                  ("viewNeverUsedAsKernelInput", toJson true)]
                let marker := Expr.sort .zero
                argumentViews := some ⟨marker, marker, sa, ta, #[row]⟩
    let av ← match argumentViews with
      | some v => pure v
      | none => batchSignatureViews rs owners ctx (path ++ ".arg") sa ta
    pure (batchJoin (.app fnViews.sourceView av.sourceView) (.app fnViews.targetView av.targetView)
      (.app fnViews.sourceRestored av.sourceRestored) (.app fnViews.targetRestored av.targetRestored) fnViews av)
  | .forallE sn sd sb si, .forallE tn td tb ti => do
    unless si == ti do throwError "Exposed/nested forall BinderInfo changed outside data slot at {path}"
    kernelTypeEq s!"complete forall domains {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    let dv ← batchSignatureViews rs owners ctx (path ++ ".domain") sd td
    withLocalDecl sn si sd fun x => do
      let bv ← batchSignatureViews rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure (batchJoin
        (.forallE sn dv.sourceView (bv.sourceView.abstract #[x]) si)
        (.forallE tn dv.targetView (bv.targetView.abstract #[x]) ti)
        (.forallE sn dv.sourceRestored (bv.sourceRestored.abstract #[x]) si)
        (.forallE tn dv.targetRestored (bv.targetRestored.abstract #[x]) ti) dv bv)
  | .lam sn sd sb si, .lam tn td tb ti => do
    unless si == ti do throwError "Lambda BinderInfo changed outside data slot at {path}"
    kernelTypeEq s!"complete lambda domains {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    let dv ← batchSignatureViews rs owners ctx (path ++ ".domain") sd td
    withLocalDecl sn si sd fun x => do
      let bv ← batchSignatureViews rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure (batchJoin
        (.lam sn dv.sourceView (bv.sourceView.abstract #[x]) si)
        (.lam tn dv.targetView (bv.targetView.abstract #[x]) ti)
        (.lam sn dv.sourceRestored (bv.sourceRestored.abstract #[x]) si)
        (.lam tn dv.targetRestored (bv.targetRestored.abstract #[x]) ti) dv bv)
  | .letE sn sd sv sb snon, .letE tn td tv tb tnon => do
    unless snon == tnon do throwError "Let dependency metadata differs at {path}"
    kernelTypeEq s!"complete let types {path}" (← mkForallFVars ctx sd) (← mkForallFVars ctx td)
    kernelTermEq s!"complete let values {path}" (← mkLambdaFVars ctx sv) (← mkLambdaFVars ctx tv)
    let dv ← batchSignatureViews rs owners ctx (path ++ ".type") sd td
    let vv ← batchSignatureViews rs owners ctx (path ++ ".value") sv tv
    withLetDecl sn sd sv (fun x => do
      let bv ← batchSignatureViews rs owners (ctx.push x) (path ++ ".body") (sb.instantiate1 x) (tb.instantiate1 x)
      pure ⟨.letE sn dv.sourceView vv.sourceView (bv.sourceView.abstract #[x]) snon,
        .letE tn dv.targetView vv.targetView (bv.targetView.abstract #[x]) tnon,
        .letE sn dv.sourceRestored vv.sourceRestored (bv.sourceRestored.abstract #[x]) snon,
        .letE tn dv.targetRestored vv.targetRestored (bv.targetRestored.abstract #[x]) tnon,
        dv.slots ++ vv.slots ++ bv.slots⟩) (nondep := snon)
  | .proj sn si se, .proj tn ti te => do
    unless sn == tn && si == ti do throwError "Projection metadata changed at {path}"
    let v ← batchSignatureViews rs owners ctx (path ++ ".projected") se te
    pure ⟨.proj sn si v.sourceView, .proj tn ti v.targetView,
      .proj sn si v.sourceRestored, .proj tn ti v.targetRestored, v.slots⟩
  | .mdata sm se, .mdata tm te => do
    let v ← batchSignatureViews rs owners ctx path se te
    pure ⟨.mdata sm v.sourceView, .mdata tm v.targetView,
      .mdata sm v.sourceRestored, .mdata tm v.targetRestored, v.slots⟩
  | _, _ => throwError "Unaccounted raw BinderInfo difference at {path}; no typeclass data slot accepted"
  unless result.sourceRestored.equal source && result.targetRestored.equal target do
    throwError "Data-slot view is not exactly reversible at {path}"
  unless strictBinderShape result.sourceView result.targetView do
    throwError "Unaccounted BinderInfo remains outside exact data slots at {path}"
  return result

private def batchExposedDomains (s t : Expr) : MetaM Json :=
  forallTelescope s fun args body => do
    let mut tb := t
    let mut rows := #[]
    for i in [:args.size] do
      let d ← args[i]!.fvarId!.getDecl
      let .forallE _ td tr ti := tb | throwError "Exposed forall count differs"
      unless d.binderInfo == ti do throwError "Exposed BinderInfo differs at parameter {i}"
      let ctx := args.extract 0 i
      kernelTypeEq s!"complete exposed domain {i}" (← mkForallFVars ctx d.type) (← mkForallFVars ctx td)
      rows := rows.push (Json.mkObj [("index", toJson i), ("binderInfo", toJson (encodeBinder ti)),
        ("completeClosedDomainKernelEqual", toJson true),
        ("rawDomainBinderInventoryEqual", toJson (binderInventory d.type == binderInventory td)),
        ("rawDomainBinderPlacementEqual", toJson (binderPlacement d.type == binderPlacement td))])
      tb := tr.instantiate1 args[i]!
    if tb.isForall then throwError "Additional exposed target forall"
    kernelTypeEq "complete result closed over exposed parameters" (← mkForallFVars args body) (← mkForallFVars args tb)
    return Json.mkObj [("allExposedBinderFlagsStrict", toJson true), ("domains", Json.arr rows),
      ("completeClosedResultKernelEqual", toJson true)]

def batchOneSignature (rs : Relocations) (owners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sp ← namesFromJson (← checked (field record "levelParams"))
  unless sp.length == target.levelParams.length do throwError "Universe arity changed"
  let canonical : List Level := (canonicalLevels sp.length).map Level.param
  let some r := rs.find? (·.original == original) | throwError "No exact named map"
  let tl : List Level ← match r.permutation with
    | none => pure canonical
    | some p => do
      let reordered : Array Level ← checked (reorder p canonical.toArray)
      pure reordered.toList
  let rawRs := {rs with sourceProofValues := #[], standardProofValues := #[], sourceCompatibilityValues := #[]}
  let raw := (← checked (decodeExpr rawRs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical
  let s := (← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))).instantiateLevelParams sp canonical
  let t := target.type.instantiateLevelParams target.levelParams tl
  unless binderInventory raw == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
    throwError "Original exported raw inventory serialization differs"
  unless strictBinderShape raw s do throwError "Proof expansion changed raw signature BinderInfo; batch refuses to conflate views"
  let rawInventoryEqual := binderInventory raw == binderInventory t
  let rawPlacementEqual := binderPlacement raw == binderPlacement t
  let baseline := [("original", toJson original.toString), ("target", toJson target.name.toString),
    ("rawSignatureBinderInventoryEqual", toJson rawInventoryEqual),
    ("rawSignatureBinderPlacementEqual", toJson rawPlacementEqual),
    ("sourceRawBinderCount", toJson (binderInventory raw).size), ("targetRawBinderCount", toJson (binderInventory t).size),
    ("sourceSignatureSerializationValidated", toJson true)]
  try
    kernelTypeEq s!"complete unmodified signature {original}" s t
    for e in #[s, t] do batchOwnedClosed rs owners original.toString e
    let domains ← batchExposedDomains s t
    let views ← batchSignatureViews rs owners #[] "root" s t
    unless (!rawInventoryEqual || !rawPlacementEqual) == !views.slots.isEmpty do
      throwError "Raw failure and changed-slot presence disagree"
    let sourceSignatureJson ← if views.slots.isEmpty then pure Json.null else checked (encodeExpr raw)
    let targetSignatureJson ← if views.slots.isEmpty then pure Json.null else checked (encodeExpr t)
    let sourceViewJson ← if views.slots.isEmpty then pure Json.null else checked (encodeExpr views.sourceView)
    let targetViewJson ← if views.slots.isEmpty then pure Json.null else checked (encodeExpr views.targetView)
    return Json.mkObj (baseline ++ [
      ("diagnosticPassed", toJson true), ("error", Json.null),
      ("completeUnmodifiedTypesKernelEqual", toJson true),
      ("exposedDomains", domains), ("changedDataSlots", Json.arr views.slots),
      ("exactExprEqualRoundTrip", toJson true), ("allOtherBinderInfoStrictlyEqual", toJson true),
      ("rawFalseRemainsLiteral", toJson (!rawInventoryEqual || !rawPlacementEqual)),
      ("completeSourceSignature", sourceSignatureJson),
      ("completeTargetSignature", targetSignatureJson),
      ("sourceBinderView", sourceViewJson),
      ("targetBinderView", targetViewJson),
      ("viewNeverUsedAsKernelInput", toJson true)])
  catch e =>
    return Json.mkObj (baseline ++ [("diagnosticPassed", toJson false),
      ("error", toJson (← e.toMessageData.toString)), ("acceptedCorrespondenceGenerated", toJson false)])

def batchInstanceDiagnostic : TermElabM Unit := do
  let (config, rs, owners) ← withCurrHeartbeats do
    unless Lean.versionString == "4.33.1" do throwError "Expected exact target compiler"
    let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
    let rs ← readRelocations config
    let modules ← (← checked (arrayField config "modules")).mapM fun row => return (← checked (stringField row "target")).toName
    let deps := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
    let prefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
    let env ← getEnv
    let mut owners := #[]
    for m in env.header.moduleNames do
      unless prefixes.any (·.isPrefixOf m) || (modules ++ deps).contains m do throwError "Forbidden module {m}"
      owners := owners.push m
    let (facts, _) ← boundedMetaAuditUnit "actual platform evidence" (verifyPlatformHelperFacts config)
    let ((rs, _), _) ← boundedMetaAuditUnit "four genuine proof values" (installExactInitialThetaProofValues rs owners config facts)
    return (config, rs, owners)
  let mut reports := #[]
  let mut namedCount := 0
  for module in ← checked (arrayField config "batchModuleViews") do
    let source ← jsonFile (← checked (stringField module "path"))
    unless (← checked (source.getObjValAs? Nat "completeOriginalRecordCount")) == 232 &&
      (← checked (source.getObjValAs? Nat "completeOriginalSelectedCount")) == 204 do throwError "Wrong source view"
    for key in #["inventorySha256", "graphSha256"] do
      unless (← checked (field config key)) == (← checked (field source key)) do throwError "Source provenance changed"
    for record in ← checked (arrayField source "records") do
      unless (← checked (record.getObjValAs? Bool "selected")) do continue
      let original ← checked (decodeName (← checked (field record "nameExpr")))
      if rs.sourceProofValues.any (·.1 == original) then continue
      let target ← checked (relocated rs original)
      let ci ← getConstInfo target
      logInfo s!"Batch exact signature diagnostic {original}"
      let (report, ticks) ← boundedMetaAuditUnit s!"batch signature {original}" (batchOneSignature rs owners record ci)
      reports := reports.push (Json.mkObj ((← checked report.getObj?).toList ++ [
        ("independentDefaultHeartbeatBudget", toJson (200000 : Nat)), ("heartbeatsInternalTicks", toJson ticks)]))
      namedCount := namedCount + 1
  unless namedCount == 200 do throwError "Expected all200 exact named declarations"
  withCurrHeartbeats do
    let output ← absoluteEnv "NEXT_CARRIER_BATCH_INSTANCE_DIAGNOSTIC_OUTPUT"
    IO.FS.writeFile output ((Json.mkObj [
      ("schema", toJson "initial-theta-all-named-instance-signature-diagnostic-v1"),
      ("compilerVersion", toJson Lean.versionString), ("namedDeclarationCount", toJson namedCount),
      ("reports", Json.arr reports), ("acceptedCorrespondenceGenerated", toJson false),
      ("mathematicalSourcesChanged", toJson false),
      ("scope", toJson "Diagnostic candidates only: exact paths and complete closed non-Prop typeclass arguments; raw mismatches remain false. Full formal data/recursor/instance/axiom gates remain separate and mandatory.")]).compress ++ "\n")
    Lean.Core.checkMaxHeartbeats "batch diagnostic emission"

end FoundationAudit
syntax (name := batchInstanceDiagnostic) "batch_instance_diagnostic" : command
@[command_elab batchInstanceDiagnostic] def elabBatchInstanceDiagnostic : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.batchInstanceDiagnostic
batch_instance_diagnostic
