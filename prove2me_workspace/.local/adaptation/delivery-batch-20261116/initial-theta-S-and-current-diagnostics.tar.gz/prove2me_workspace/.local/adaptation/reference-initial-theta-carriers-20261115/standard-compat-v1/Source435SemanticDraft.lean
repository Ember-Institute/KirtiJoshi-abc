/-
Copyright (c) 2024 Salvatore Mercuri. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Salvatore Mercuri
-/
/- Original435 environment only. Uncompiled review draft. -/
import Mathlib.Analysis.Normed.Ring.WithAbs

namespace InitialThetaSource435SemanticDraft
variable {L K S : Type*} [CommSemiring K] [Semiring L] [Algebra K L]
  [FaithfulSMul K L] [PartialOrder S] [Semiring S]
variable (w : AbsoluteValue L S) (v : AbsoluteValue K S)

theorem source435IffUnderEquality : AbsoluteValue.LiesOver w v ↔ w.under K = v := by
  constructor
  · intro h
    letI := h
    exact AbsoluteValue.LiesOver.under_eq w v
  · intro h
    exact ⟨h⟩

theorem source435IffRestrictionEquality :
    AbsoluteValue.LiesOver w v ↔
      w.comp (FaithfulSMul.algebraMap_injective K L) = v := by
  constructor
  · intro h
    letI := h
    exact AbsoluteValue.LiesOver.under_eq w v
  · intro h
    exact ⟨h⟩
end InitialThetaSource435SemanticDraft

#print axioms InitialThetaSource435SemanticDraft.source435IffUnderEquality
#print axioms InitialThetaSource435SemanticDraft.source435IffRestrictionEquality
