import Mathlib.Algebra.BigOperators.Finprod
import Mathlib.Algebra.BigOperators.Group.Finset.Defs
import Mathlib.Algebra.Group.Defs
import Mathlib.Algebra.Group.Pointwise.Set.Scalar
import Mathlib.Algebra.Group.Units.Defs
import Mathlib.Algebra.Ring.Defs
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Real.Basic
import Mathlib.Data.Fintype.Basic
import Mathlib.Data.Fintype.Defs
import Mathlib.Data.Int.Cast.Defs
import Mathlib.Data.Nat.Cast.Defs
import Mathlib.Data.Nat.Prime.Defs
import Mathlib.Data.Set.Defs
import Mathlib.Data.Set.Operations
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Container
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_PacketPresentation
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RationalPlace

set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3

namespace AbcAdaptation.Reference

set_option relaxedAutoImplicit false

set_option maxSynthPendingDepth 3



namespace Iut

open scoped Pointwise

universe u₁ u₂ v

variable {ι : Type u₁} {V : Type u₂}


structure LogVolumeData (D : LargeVolumeContainerData.{u₁, u₂, v} ι V) :
    Type (max u₁ u₂ v) where
  
  weight : (vQ : RationalPlace) → D.Fiber vQ → ℝ
  
  weight_pos : ∀ vQ v, 0 < weight vQ v
  
  weight_sum_one : ∀ vQ, ∑ v, weight vQ v = 1
  
  componentVol : ∀ (i : Fin D.proc.length) (vQ : RationalPlace)
    (c : D.Components i vQ), Set ((D.packet i vQ).Summand c) → ℝ
  
  componentVol_integral_nonarch : ∀ i (p : Nat.Primes) (c : D.Components i (.finite p)),
    componentVol i (.finite p) c ((D.packet i (.finite p)).integral c) = 0
  
  componentVol_prime_preimage : ∀ i (p : Nat.Primes) (c : D.Components i (.finite p)),
    letI : CommRing ((D.packet i (.finite p)).Summand c) :=
      (D.packet i (.finite p)).ring_summand c
    ∀ (a : (D.packet i (.finite p)).Summand c), IsUnit a →
    componentVol i (.finite p) c
        ((fun x : (D.packet i (.finite p)).Summand c =>
          ((p : ℕ) : (D.packet i (.finite p)).Summand c) * x) ⁻¹'
            (a • (D.packet i (.finite p)).integral c)) =
      componentVol i (.finite p) c (a • (D.packet i (.finite p)).integral c) + Real.log p
  
  archBall : ∀ (i : Fin D.proc.length) (c : D.Components i .infinite),
    Set ((D.packet i .infinite).Summand c)
  
  componentVol_archBall : ∀ i (c : D.Components i .infinite),
    componentVol i .infinite c (archBall i c) = 0
  
  packetVol : ∀ (i : Fin D.proc.length) (vQ : RationalPlace),
    Set (D.packet i vQ).Total → ℝ
  
  packetVol_integral : ∀ i vQ, packetVol i vQ (D.packet i vQ).integralRegion = 0
  
  packetVol_product : ∀ i vQ (U : ∀ c : D.Components i vQ,
      Set ((D.packet i vQ).Summand c)), (∀ c, (U c).Nonempty) →
    packetVol i vQ ((D.packet i vQ).productRegion U) =
      ∑ c, (∏ j, weight vQ (c j)) * componentVol i vQ c (U c)

namespace LogVolumeData

variable {D : LargeVolumeContainerData.{u₁, u₂, v} ι V} (vol : LogVolumeData D)


noncomputable def globalVol {i : Fin D.proc.length} (R : D.AdmissibleRegion i) : ℝ :=
  ∑ᶠ vQ, vol.packetVol i vQ (R.region vQ)


noncomputable def processionVol (R : ∀ i : Fin D.proc.length, D.AdmissibleRegion i) :
    ℝ :=
  (∑ i, vol.globalVol (R i)) / D.proc.length

end LogVolumeData

end Iut

end AbcAdaptation.Reference
