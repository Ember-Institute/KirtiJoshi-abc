import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RationalPlace
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Procession
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_PacketPresentation
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Container
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_HolomorphicHull
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_Basic
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_ContainerHull
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LogVolume
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_PrimeToOrder
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_TateCurve_Weierstrass
import Definitions.Def_AbcAdaptation_Reference_TateCurvesTheta_QParameter_NormalizedOrder

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

def expressionAxioms (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← collectAxioms name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"

-- Preserve inductive/constructor/recursor computation metadata as well as types.
def computationShape (ci : ConstantInfo) (rename : Name → Except String Name) : Except String Json := do
  let ns := fun xs : List Name => do
    return Json.arr (← xs.toArray.mapM fun n => return encodeName (← rename n))
  match ci with
  | .inductInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("constructors", ← ns i.ctors),
      ("numParams", toJson i.numParams), ("numIndices", toJson i.numIndices),
      ("numNested", toJson i.numNested), ("isRec", toJson i.isRec),
      ("isUnsafe", toJson i.isUnsafe), ("isReflexive", toJson i.isReflexive)]
  | .ctorInfo i => return Json.mkObj [
      ("inductive", encodeName (← rename i.induct)), ("index", toJson i.cidx),
      ("numParams", toJson i.numParams), ("numFields", toJson i.numFields),
      ("isUnsafe", toJson i.isUnsafe)]
  | .recInfo i => return Json.mkObj [
      ("all", ← ns i.all), ("numParams", toJson i.numParams),
      ("numIndices", toJson i.numIndices), ("numMotives", toJson i.numMotives),
      ("numMinors", toJson i.numMinors), ("k", toJson i.k), ("isUnsafe", toJson i.isUnsafe),
      ("rules", Json.arr (← i.rules.toArray.mapM fun r => return Json.mkObj [
        ("constructor", encodeName (← rename r.ctor)), ("numFields", toJson r.nfields)]))]
  | .defnInfo i => return Json.mkObj [("safety", toJson (reprStr i.safety))]
  | _ => return Json.null

-- Include elaborator-visible field and parent metadata, not only kernel arities.
def structureShape (info : StructureInfo) (rename : Name → Except String Name) : Except String Json := do
  let fields ← info.fieldInfo.mapM fun p => do
    let subobject ← match p.subobject? with
      | none => pure Json.null
      | some n => pure (encodeName (← rename n))
    return Json.mkObj [
      ("fieldName", encodeName p.fieldName), ("projection", encodeName (← rename p.projFn)),
      ("subobject", subobject), ("binderInfo", toJson (encodeBinder p.binderInfo)),
      ("hasAutoParam", toJson p.autoParam?.isSome)]
  let parents ← info.parentInfo.mapM fun p => do
    return Json.mkObj [
      ("structure", encodeName (← rename p.structName)), ("subobject", toJson p.subobject),
      ("projection", encodeName (← rename p.projFn))]
  return Json.mkObj [
    ("structure", encodeName (← rename info.structName)),
    ("fieldNamesInConstructorOrder", Json.arr (info.fieldNames.map encodeName)),
    ("fieldsSortedByName", Json.arr fields), ("parentsInExtendsOrder", Json.arr parents)]

def telescopeJson (type : Expr) : MetaM Json :=
  forallTelescope type fun xs result => do
    let binders ← xs.mapM fun x => do
      let d ← x.fvarId!.getDecl
      return Json.mkObj [("name", toJson d.userName.toString),
        ("binderInfo", toJson (encodeBinder d.binderInfo)),
        ("typeDisplay", toJson (← ppExpr d.type).pretty)]
    return Json.mkObj [("binders", Json.arr binders),
      ("resultDisplay", toJson (← ppExpr result).pretty)]

end FoundationAudit
namespace FoundationAudit
open Lean Elab Term Meta

structure Relocation where
  original : Name
  target : Name
  permutation : Option (Array Nat)
  expectedInstance : Option Bool
  expectedAxioms : Option (Array Name)

structure Relocations where
  rows : Array Relocation
  projectPrefixes : Array Name
  sourcePrefixes : Array Name
  targetPrefix : Name
  standardExpansions : Array (Name × (List Name × Expr))

def Relocations.find? (rs : Relocations) (p : Relocation → Bool) : Option Relocation := rs.rows.find? p
def Relocations.any (rs : Relocations) (p : Relocation → Bool) : Bool := rs.rows.any p

def projectName (rs : Relocations) (n : Name) : Bool :=
  rs.projectPrefixes.any (·.isPrefixOf n)

def relocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.original == n) then return r.target
  if projectName rs n then throw s!"Unmapped project name {n}"
  return n

def inverseRelocated (rs : Relocations) (n : Name) : Except String Name := do
  if let some r := rs.find? (·.target == n) then return r.original
  if projectName rs n then throw s!"Unmapped wrapped name {n}"
  return n

def reorder (indices : Array Nat) (us : Array α) : Except String (Array α) := do
  unless indices.size == us.size && indices.toList.eraseDups.length == us.size do
    throw "Universe permutation has incorrect size or repeated indices"
  indices.mapM fun i => match us[i]? with
    | some u => pure u
    | none => throw "Universe permutation index out of range"

partial def decodeExpr (rs : Relocations) (j : Json) : Except String Expr := do
  let recur := decodeExpr rs
  match ← stringField j "kind" with
  | "bvar" => return .bvar (← (← field j "index").getNat?)
  | "sort" => return .sort (← decodeLevel (← field j "level"))
  | "const" =>
    let original ← decodeName (← field j "name")
    if let some expansion := rs.standardExpansions.find? (·.1 == original) then
      let levels ← (← arrayField j "levels").mapM decodeLevel
      unless levels.size == expansion.2.1.length do
        throw "Universe arity differs in genuine source value expansion"
      return expansion.2.2.instantiateLevelParams expansion.2.1 levels.toList
    let target ← relocated rs original
    let mut levels ← (← arrayField j "levels").mapM decodeLevel
    if let some r := rs.find? (·.original == original) then
      if let some indices := r.permutation then levels ← reorder indices levels
    return .const target levels.toList
  | "app" => return .app (← recur (← field j "fn")) (← recur (← field j "arg"))
  | "lam" => return .lam (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "forall" => return .forallE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "body")) (← decodeBinder (← stringField j "binder"))
  | "let" => return .letE (← decodeName (← field j "name")) (← recur (← field j "type")) (← recur (← field j "value")) (← recur (← field j "body")) (← (← field j "nondependent").getBool?)
  | "nat" => return .lit (.natVal (← (← field j "value").getNat?))
  | "string" => return .lit (.strVal (← stringField j "value"))
  | "proj" => return .proj (← relocated rs (← decodeName (← field j "name"))) (← (← field j "index").getNat?) (← recur (← field j "body"))
  | k => throw s!"Unknown Expr kind {k}"

def readRelocations (config : Json) : MetaM Relocations := do
  let projectPrefixes := (← namesFromJson (← checked (field config "projectPrefixes"))).toArray
  let sourcePrefixes := (← namesFromJson (← checked (field config "originalProjectPrefixes"))).toArray
  let targetPrefix ← checked (decodeName (← checked (field config "targetProjectPrefix")))
  unless !projectPrefixes.isEmpty && !sourcePrefixes.isEmpty && targetPrefix != .anonymous do
    throwError "Empty project-prefix policy"
  let mut result : Array Relocation := #[]
  for key in #["projectMap", "standardRenames"] do
    for row in ← checked (arrayField config key) do
      let original ← checked (decodeName (← checked (field row "originalName")))
      let target ← checked (decodeName (← checked (field row "targetName")))
      unless original.toString == (← checked (stringField row "original")) &&
        target.toString == (← checked (stringField row "target")) do
        throwError "Structural relocation name mismatch"
      if key == "standardRenames" then
        if projectPrefixes.any (·.isPrefixOf original) || projectPrefixes.any (·.isPrefixOf target) then
          throwError "Standard relocation contains project name"
        unless (← checked (stringField row "evidence")).length > 0 do
          throwError "Standard rename requires reviewed compiler/source evidence"
      else
        unless sourcePrefixes.any (·.isPrefixOf original) && target == targetPrefix ++ original do
          throwError "Unexpected project relocation {original} -> {target}"
      if result.any (fun r => r.original == original || r.target == target) then
        throwError "Duplicate or non-injective relocation {original} -> {target}"
      let indicesJson ← checked (field row "targetToSourceUniverseIndices")
      let permutation ← if indicesJson == Json.null then pure none else
        pure (some (← checked ((← checked indicesJson.getArr?).mapM Json.getNat?)))
      let expectedInstance ← if key == "projectMap" then
        pure (some (← checked (row.getObjValAs? Bool "expectedIsInstance"))) else pure none
      let expectedAxioms ← if key == "projectMap" then
        pure (some (← namesFromJson (← checked (field row "expectedSourceAxioms"))).toArray) else pure none
      result := result.push ⟨original, target, permutation, expectedInstance, expectedAxioms⟩
  return ⟨result, projectPrefixes, sourcePrefixes, targetPrefix, #[]⟩

def requireClosed (label : String) (e : Expr) : MetaM Unit := do
  if e.hasMVar || e.hasFVar || e.hasLooseBVars then throwError "Open expression in {label}"

def kernelCheck (label : String) (e : Expr) : MetaM Expr := do
  requireClosed label e
  match Kernel.check (← getEnv) {} e with
  | .ok type => pure type
  | .error ex => throwKernelException ex

-- Kernel conversion assumes well-typed inputs. Check both terms and their types.
def kernelTermEq (label : String) (left right : Expr) : MetaM Unit := do
  let lt ← kernelCheck label left
  let rt ← kernelCheck label right
  match Kernel.isDefEq (← getEnv) {} lt rt with
  | .ok true => pure ()
  | .ok false => throwError "Kernel inferred types differ: {label}"
  | .error ex => throwKernelException ex
  match Kernel.isDefEq (← getEnv) {} left right with
  | .ok true => pure ()
  | .ok false => throwError "Kernel values/types differ: {label}"
  | .error ex => throwKernelException ex

def kernelTypeEq (label : String) (left right : Expr) : MetaM Unit := do
  for e in #[left, right] do
    match ← kernelCheck label e with
    | .sort _ => pure ()
    | _ => throwError "Expected type: {label}"
  kernelTermEq label left right

def allowedOwner (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Unit := do
  let some owner := moduleOf (← getEnv) name | throwError "No imported owner for {name}"
  unless modules.contains owner do
    throwError "Forbidden dependency {name}, owner {owner}"
  if rs.sourcePrefixes.any (·.isPrefixOf name) then
    throwError "Unrelocated original project dependency {name}"

def auditDeclaration (rs : Relocations) (modules : Array Name) (name : Name) : MetaM Json := do
  let ci ← getConstInfo name
  if let .axiomInfo _ := ci then throwError "Carrier declares an axiom {name}"
  let axs ← collectAxioms name
  let taxs ← expressionAxioms ci.type
  ensureStandard s!"carrier {name}" axs
  ensureStandard s!"carrier type {name}" taxs
  let value? := ci.value? (allowOpaque := true)
  let vaxs ← match value? with
    | some v => expressionAxioms v
    | none => pure #[]
  ensureStandard s!"carrier value {name}" vaxs
  for expr in #[ci.type] ++ value?.toArray do
    for dep in expr.getUsedConstants do allowedOwner rs modules dep
  if let .recInfo r := ci then
    for rule in r.rules do
      for dep in rule.rhs.getUsedConstants do allowedOwner rs modules dep
      ensureStandard s!"recursor rule {name}" (← expressionAxioms rule.rhs)
  return Json.mkObj [("name", toJson name.toString), ("nameExpr", encodeName name),
    ("constantKind", toJson (kind ci)),
    ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
    ("elaboratedExpr", ← checked (encodeExpr ci.type)),
    ("binderInventory", toJson (binderInventory ci.type)),
    ("axioms", toJson (axs.map Name.toString)),
    ("typeAxioms", toJson (taxs.map Name.toString)),
    ("valueAxioms", toJson (vaxs.map Name.toString)),
    ("hasSorryAx", toJson false), ("hasValue", toJson value?.isSome),
    ("isInstance", toJson (Lean.Meta.isInstanceCore (← getEnv) name))]

-- Paths distinguish binders at different positions even when the flattened
-- BinderInfo sequence is the same. Kernel conversion itself erases BinderInfo.
partial def binderPlacement (e : Expr) (path := "root") : Array String :=
  match e with
  | .forallE _ t b bi => #[path ++ ":forall:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .lam _ t b bi => #[path ++ ":lambda:" ++ encodeBinder bi] ++
      binderPlacement t (path ++ ".domain") ++ binderPlacement b (path ++ ".body")
  | .app f a => binderPlacement f (path ++ ".fn") ++ binderPlacement a (path ++ ".arg")
  | .letE _ t v b _ => binderPlacement t (path ++ ".type") ++
      binderPlacement v (path ++ ".value") ++ binderPlacement b (path ++ ".body")
  | .mdata _ e => binderPlacement e path
  | .proj _ _ e => binderPlacement e (path ++ ".projected")
  | _ => #[]

def canonicalLevels (n : Nat) : List Name :=
  (List.range n).map fun i => Name.num (Name.str .anonymous "_foundationAuditUniverse") i

def approvedExtensionalEliminators : Array Name :=
  #[`TateCurvesTheta.IsUniformizer.casesOn, `TateCurvesTheta.IsUniformizer.recOn]

-- The only fallback proves equality of the complete values. It does not change
-- their types, erase computation checks, or assert definitional equality.
def proveGeneratedEliminatorEquality (rs : Relocations) (allowedOwners : Array Name)
    (original : Name) (sourceType sourceValue targetValue : Expr) : MetaM Json := do
  unless approvedExtensionalEliminators.contains original do
    throwError "Computational values are not definitionally equal: {original}"
  let structureName := `AbcAdaptation.Reference.TateCurvesTheta.IsUniformizer
  let constructorName := `AbcAdaptation.Reference.TateCurvesTheta.IsUniformizer.mk
  let recursorName := `AbcAdaptation.Reference.TateCurvesTheta.IsUniformizer.rec
  let .inductInfo inductiveInfo ← getConstInfo structureName |
    throwError "Expected exact uniformizer inductive"
  unless inductiveInfo.numParams == 3 && inductiveInfo.numIndices == 0 &&
      inductiveInfo.ctors == [constructorName] && inductiveInfo.numNested == 0 do
    throwError "Unexpected uniformizer structure computation shape"
  let .ctorInfo constructorInfo ← getConstInfo constructorName |
    throwError "Expected exact uniformizer constructor"
  unless constructorInfo.induct == structureName && constructorInfo.cidx == 0 &&
      constructorInfo.numParams == inductiveInfo.numParams && constructorInfo.numFields == 3 &&
      !constructorInfo.isUnsafe do
    throwError "Unexpected uniformizer constructor metadata"
  let .recInfo recursor ← getConstInfo recursorName |
    throwError "Expected exact uniformizer primitive recursor"
  unless recursor.numParams == 3 && recursor.numIndices == 0 &&
      recursor.numMotives == 1 && recursor.numMinors == 1 &&
      recursor.rules.length == 1 && recursor.rules[0]!.ctor == constructorName &&
      recursor.rules[0]!.nfields == 3 && !recursor.k && !recursor.isUnsafe &&
      recursor.levelParams.tail == inductiveInfo.levelParams do
    throwError "Unexpected uniformizer primitive recursor metadata"
  let parameterCount := inductiveInfo.numParams
  let fieldCount := recursor.rules[0]!.nfields
  let majorIndex := parameterCount + 1
  let branchIndex := parameterCount + 2
  let proof ← forallTelescope sourceType fun args _ => do
    unless args.size == parameterCount + 3 do throwError "Expected three parameters, motive, major and minor"
    let majorType ← inferType args[majorIndex]!
    unless majorType.getAppFn.isConstOf structureName && majorType.getAppArgs.size == parameterCount &&
        majorType.getAppArgs == args.extract 0 parameterCount && (← isProp majorType) do
      throwError "Unexpected generated eliminator major premise"
    let levels := majorType.getAppFn.constLevels!
    unless levels.length == inductiveInfo.levelParams.length do
      throwError "Unexpected generated eliminator structure universes"
    let left := mkAppN sourceValue args
    let right := mkAppN targetValue args
    let pointwiseGoal ← mkEq left right
    -- Generalize the branch argument inside the recursor motive, so the motive
    -- depends only on the major premise and the parameters and motive.
    let branchGoal ← mkForallFVars #[args[branchIndex]!] pointwiseGoal
    let equalityMotive ← mkLambdaFVars #[args[majorIndex]!] branchGoal
    let constructorPrefix := mkAppN (mkConst constructorName levels) (args.extract 0 parameterCount)
    let constructorCase ← forallTelescope (← inferType constructorPrefix) fun fields _ => do
      unless fields.size == fieldCount do throwError "Expected exactly three structure fields"
      for component in fields do
        unless (← isProp (← inferType component)) do
          throwError "Generated eliminator fallback requires every field to be a proposition"
      let constructed := mkAppN constructorPrefix fields
      let caseGoal ← whnf (mkApp equalityMotive constructed)
      let caseProof ← forallTelescope caseGoal fun branchArgs _ => do
        unless branchArgs.size == 1 do throwError "Expected one generalized branch argument"
        let caseArgs := (args.extract 0 majorIndex) ++ #[constructed, branchArgs[0]!]
        -- The final kernel check verifies that this reflexivity term also has
        -- the required right-hand side, using the primitive constructor rule.
        mkLambdaFVars branchArgs (← mkEqRefl (mkAppN sourceValue caseArgs))
      mkLambdaFVars fields caseProof
    let recursion := mkAppN (mkConst recursorName (.zero :: levels))
      ((args.extract 0 parameterCount) ++ #[equalityMotive, constructorCase, args[majorIndex]!])
    let mut pointwiseProof := mkApp recursion args[branchIndex]!
    -- Each step turns a proof for all values of one argument into equality of
    -- the corresponding functions. All inferred metavariables must disappear.
    for index in (List.range args.size).reverse do
      pointwiseProof ← mkFunExt (← mkLambdaFVars #[args[index]!] pointwiseProof)
    pure pointwiseProof
  let proof ← instantiateMVars proof
  requireClosed s!"generated eliminator equality proof {original}" proof
  let expectedEquality ← mkEq sourceValue targetValue
  let inferredEquality ← kernelCheck s!"generated eliminator equality proof {original}" proof
  kernelTypeEq s!"generated eliminator equality proof has exact full-value equation {original}"
    inferredEquality expectedEquality
  let axs ← expressionAxioms proof
  ensureStandard s!"generated eliminator equality proof {original}" axs
  for dep in proof.getUsedConstants do allowedOwner rs allowedOwners dep
  return Json.mkObj [
    ("original", encodeName original),
    ("method", toJson "primitive-recursion reflexivity on all three symbolic proof fields, followed by function extensionality on every actual telescope argument"),
    ("definitionalValueEqual", toJson false),
    ("kernelCheckedPropositionalValueEquality", toJson true),
    ("exactFullValueEquality", ← checked (encodeExpr expectedEquality)),
    ("kernelCheckedEqualityProof", ← checked (encodeExpr proof)),
    ("primitiveRecursor", encodeName recursorName),
    ("constructor", encodeName constructorName),
    ("constructorFieldCount", toJson fieldCount),
    ("extensionalArgumentCount", toJson (parameterCount + 3)),
    ("axioms", toJson (axs.map Name.toString)),
    ("hasSorryAx", toJson false)]


-- Decode only absent standard definitions/proofs reached by the exact two roots.
-- Existing native API constants remain native and are checked in the resulting terms.
partial def installMissingDecidableSupport (rs : Relocations) (rows : Array Json)
    (original : Name) (stack : Array Name := #[]) : MetaM (Relocations × Array Json) := do
  if rs.standardExpansions.any (·.1 == original) || (← getEnv).contains original then
    return (rs, #[])
  if stack.contains original then throwError "Recursive missing source support {original}"
  let matchingRecords := rows.filter fun r => (stringField r "name").toOption == some original.toString
  unless matchingRecords.size == 1 do throwError "Missing genuine support body {original}"
  let record := matchingRecords[0]!
  let declarationKind ← checked (stringField record "kind")
  unless declarationKind == "definition" || declarationKind == "theorem" do
    throwError "Absent core inductive/constructor/recursor has no body transport {original}"
  let valueJson ← checked (field record "valueExpr")
  if valueJson == Json.null then throwError "Absent core support has no genuine value {original}"
  let rawRs := { rs with standardExpansions := #[] }
  let rawType ← checked (decodeExpr rawRs (← checked (field record "typeExpr")))
  unless binderInventory rawType == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
    throwError "Original core support type BinderInfo changed {original}"
  let rawValue ← checked (decodeExpr rawRs valueJson)
  let mut rs := rs
  let mut reports : Array Json := #[]
  for dependency in (rawType.getUsedConstants ++ rawValue.getUsedConstants).toList.eraseDups do
    if rs.projectPrefixes.any (·.isPrefixOf dependency) then
      throwError "Project dependency in exact standard support {dependency}"
    let (updated, dependencyReports) ← installMissingDecidableSupport rs rows dependency (stack.push original)
    rs := updated
    reports := reports ++ dependencyReports
  let params ← namesFromJson (← checked (field record "levelParams"))
  unless params.eraseDups == params do throwError "Duplicate standard support universe parameter {original}"
  let type ← checked (decodeExpr rs (← checked (field record "typeExpr")))
  let value ← checked (decodeExpr rs valueJson)
  let levels := (canonicalLevels params.length).map Level.param
  let canonicalType := type.instantiateLevelParams params levels
  let canonicalValue := value.instantiateLevelParams params levels
  kernelTypeEq s!"genuine absent support value inhabits its exact source type {original}"
    (← kernelCheck s!"genuine absent core support {original}" canonicalValue) canonicalType
  let axs ← expressionAxioms canonicalValue
  ensureStandard s!"genuine absent core support {original}" axs
  for term in #[canonicalType, canonicalValue] do
    for dependency in term.getUsedConstants do
      let some owner := moduleOf (← getEnv) dependency |
        throwError "Missing expanded core dependency owner {dependency}"
      unless (`Init).isPrefixOf owner do
        throwError "Non-Init dependency in exact source core support {dependency}"
  rs := { rs with standardExpansions := rs.standardExpansions.push (original, (params, value)) }
  reports := reports.push (Json.mkObj [
    ("original", encodeName original), ("standaloneTargetIdentity", Json.null),
    ("method", toJson "inline genuine absent source definition/proof body"),
    ("sourceRecord", record), ("exactOriginalTypeKernelChecked", toJson true),
    ("expandedValue", ← checked (encodeExpr value)),
    ("expandedAxioms", toJson (axs.map Name.toString)), ("hasSorryAx", toJson false)])
  return (rs, reports)

def boundDecidableEvidence (config : Json) (key : String) : MetaM Json := do
  let evidence ← checked (field config "decidableStandardCompatibility")
  let binding ← checked (field evidence key)
  let actual ← jsonFile (← checked (stringField binding "path"))
  unless actual == (← checked (field binding "contents")) do
    throwError "Decidable evidence contents changed after hash binding: {key}"
  unless (← checked (stringField binding "sha256")).length == 64 do
    throwError "Missing external SHA256 binding: {key}"
  return actual

def exactDecidableSourceProofNames : Array Name :=
  #[`TateCurvesTheta.OrderedTateParameter.decidable._proof_1,
    `TateCurvesTheta.PrimeToOrder.decidable._proof_1]

def installExactDecidableSourceProofs (rs : Relocations) (allowedOwners : Array Name)
    (source config : Json) : MetaM (Relocations × Array Json) := do
  let records ← checked (arrayField source "records")
  let configured ← checked (arrayField config "proofValueResolutions")
  unless configured.size == exactDecidableSourceProofNames.size do
    throwError "Unexpected exact Decidable proof-resolution configuration"
  let mut rs := rs
  let mut reports : Array Json := #[]
  for original in exactDecidableSourceProofNames do
    let originalRows := records.filter fun r => (stringField r "name").toOption == some original.toString
    let configRows := configured.filter fun r => (stringField r "original").toOption == some original.toString
    unless originalRows.size == 1 && configRows.size == 1 do
      throwError "Missing/duplicate exact source proof record {original}"
    let record := originalRows[0]!
    let binding := configRows[0]!
    unless record == (← checked (field binding "sourceRecord")) do
      throwError "Exact source proof changed after config binding {original}"
    unless (← checked (stringField record "constantKind")) == "theorem" &&
        (← checked (record.getObjValAs? Bool "selected")) &&
        (← checked (record.getObjValAs? Bool "isProposition")) &&
        !(← checked (record.getObjValAs? Bool "isInstance")) do
      throwError "Exact source proof resolution is not a selected non-instance theorem {original}"
    unless (← checked (field binding "standaloneTargetIdentity")) == Json.null do
      throwError "A proof-value resolution cannot assert a standalone target identity"
    let rawType ← checked (decodeExpr { rs with standardExpansions := #[] }
      (← checked (field record "elaboratedExpr")))
    unless binderInventory rawType == (← checked (record.getObjValAs? (Array String) "binderInventory")) do
      throwError "Exact original source proof type BinderInfo changed {original}"
    let params ← namesFromJson (← checked (field record "levelParams"))
    unless params.eraseDups == params do throwError "Duplicate original proof universe parameter {original}"
    let type ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
    let value ← checked (decodeExpr rs (← checked (field record "valueExpr")))
    let levels := (canonicalLevels params.length).map Level.param
    let canonicalType := type.instantiateLevelParams params levels
    let canonicalValue := value.instantiateLevelParams params levels
    unless (← isProp canonicalType) do throwError "Expanded exact source proof is not propositional {original}"
    kernelTypeEq s!"genuine source proof inhabits exact original transported type {original}"
      (← kernelCheck s!"genuine original Decidable proof value {original}" canonicalValue) canonicalType
    let taxs ← expressionAxioms canonicalType
    let vaxs ← expressionAxioms canonicalValue
    ensureStandard s!"exact original proof type {original}" taxs
    ensureStandard s!"exact original proof value {original}" vaxs
    for term in #[canonicalType, canonicalValue] do
      for dependency in term.getUsedConstants do allowedOwner rs allowedOwners dependency
    rs := { rs with standardExpansions := rs.standardExpansions.push (original, (params, value)) }
    reports := reports.push (Json.mkObj [
      ("original", toJson original.toString), ("originalName", encodeName original),
      ("resolution", toJson "genuine-exported-original-proof-value"),
      ("standaloneTargetIdentity", Json.null), ("sourceRecord", record),
      ("originalTypeBinderInfoPreserved", toJson true),
      ("exactOriginalTypeKernelChecked", toJson true),
      ("genuineOriginalValueInhabitsExactOriginalType", toJson true),
      ("expandedType", ← checked (encodeExpr type)), ("expandedValue", ← checked (encodeExpr value)),
      ("expandedTypeAxioms", toJson (taxs.map Name.toString)),
      ("expandedValueAxioms", toJson (vaxs.map Name.toString)),
      ("parentOriginal", ← checked (field binding "parentOriginal")),
      ("parentWholeValueEqualityRequired", toJson true),
      ("expandedDependenciesHaveAllowedOwners", toJson true), ("hasSorryAx", toJson false)])
  return (rs, reports)

-- Source-specific representation transport: Lean 4.35's Bool/proof constructor
-- becomes Lean 4.33's true/false constructors. No decision algorithm is replaced.
def installDecidable435Transport (rs : Relocations) (config : Json) : MetaM (Relocations × Json) := do
  let facts ← boundDecidableEvidence config "sourceFacts"
  let binding ← checked (field (← checked (field config "decidableStandardCompatibility")) "sourceFacts")
  let path ← checked (stringField binding "path")
  let closure ← boundDecidableEvidence config "supportClosure"
  unless (← checked (stringField closure "schema")) == "decidable-standard-source-closure-v1" &&
      (← checked (stringField closure "compiler")) == "4.35.0-rc3" do
    throwError "Wrong genuine source standard proof closure"
  let supportRows ← checked (arrayField closure "records")
  let platformFacts ← boundDecidableEvidence config "platformFacts"
  unless (← checked (stringField platformFacts "compiler")) == "4.33.1" &&
      !(← checked (platformFacts.getObjValAs? Bool "Decidable.intro.present")) &&
      !(← checked (platformFacts.getObjValAs? Bool "Bool.Reflects.present")) do
    throwError "Unexpected actual platform core representation facts"
  for (key, expectedJob) in #[
      ("sourceReceipt", "ci-013901-2c932c62"), ("platformReceipt", "ci-013907-b9f0843a"),
      ("supportReceipt", "ci-013924-3a1c20d9")] do
    let receipt ← boundDecidableEvidence config key
    unless (← checked (stringField receipt "job_id")) == expectedJob &&
        (← checked (stringField receipt "status")) == "succeeded" do
      throwError "Wrong accepted genuine core query receipt {key}"
    let result ← checked (field receipt "result")
    unless (← checked (result.getObjValAs? Nat "exit_code")) == 0 do
      throwError "Genuine core query did not exit successfully {key}"
    let snapshot ← checked (field result "snapshot")
    unless (← checked (stringField snapshot "workspace_mode")) == "exclusive_worktree" &&
        (← checked (field snapshot "snapshot_id")) == Json.null do
      throwError "Wrong genuine core query workspace mode {key}"
  unless (← checked (stringField facts "schema")) == "decidable-standard-source-facts-v1" &&
      (← checked (stringField facts "compiler")) == "4.35.0-rc3" do
    throwError "Wrong genuine source Decidable facts"
  let records ← checked (arrayField facts "records")
  let getRecord := fun n => do
    let rows := records.filter fun r => (stringField r "name").toOption == some n
    unless rows.size == 1 do throwError "Missing/duplicate genuine standard source record {n}"
    pure rows[0]!
  let decidableRecord ← getRecord "Decidable"
  let decideRecord ← getRecord "Decidable.decide"
  let reflectsRecord ← getRecord "Bool.Reflects"
  let introRecord ← getRecord "Decidable.intro"
  unless (← checked (stringField reflectsRecord "kind")) == "definition" &&
      (← checked (stringField introRecord "kind")) == "constructor" do
    throwError "Unexpected genuine Decidable source declaration kinds"
  for record in #[reflectsRecord, introRecord] do
    unless (← checked (arrayField record "levelParams")).isEmpty do
      throwError "Unexpected universe parameters in exact Decidable compatibility"
    unless (← checked (field record "owner")) == toJson "Init.Prelude" do
      throwError "Unexpected source owner in exact Decidable compatibility"
    unless (← checked (arrayField record "axioms")).isEmpty do
      throwError "Exact core representation transport expects axiom-free source declarations"
  let inductiveShape ← checked (field decidableRecord "shape")
  let constructorShape ← checked (field introRecord "shape")
  unless (← checked (stringField decidableRecord "kind")) == "inductive" &&
      (← checked (inductiveShape.getObjValAs? Nat "numParams")) == 1 &&
      (← checked (inductiveShape.getObjValAs? Nat "numIndices")) == 0 &&
      (← checked (inductiveShape.getObjValAs? Nat "numNested")) == 0 &&
      (← checked (field inductiveShape "constructors")) == Json.arr #[encodeName `Decidable.intro] &&
      !(← checked (inductiveShape.getObjValAs? Bool "isUnsafe")) do
    throwError "Wrong genuine source Boolean/reflection Decidable structure shape"
  unless (← checked (field constructorShape "inductive")) == encodeName `Decidable &&
      (← checked (constructorShape.getObjValAs? Nat "index")) == 0 &&
      (← checked (constructorShape.getObjValAs? Nat "numParams")) == 1 &&
      (← checked (constructorShape.getObjValAs? Nat "numFields")) == 2 &&
      !(← checked (constructorShape.getObjValAs? Bool "isUnsafe")) do
    throwError "Wrong genuine source Decidable.intro constructor shape"
  for record in #[decidableRecord, decideRecord] do
    let n ← checked (decodeName (← checked (field record "nameExpr")))
    let originalType ← checked (decodeExpr rs (← checked (field record "typeExpr")))
    let targetType := (← getConstInfo n).type
    kernelTypeEq s!"Decidable representation API type {n}" originalType targetType
    unless binderPlacement originalType == binderPlacement targetType do
      throwError "Decidable representation API type BinderInfo differs {n}"
  let reflectedType ← checked (decodeExpr rs (← checked (field reflectsRecord "typeExpr")))
  let (rs, matcherSupport) ← installMissingDecidableSupport rs supportRows `Bool.Reflects.match_1
  let reflectedValue ← checked (decodeExpr rs (← checked (field reflectsRecord "valueExpr")))
  kernelTypeEq "genuine Bool.Reflects body has its exact source type"
    (← kernelCheck "genuine Bool.Reflects body" reflectedValue) reflectedType
  unless binderInventory reflectedType ==
      (← checked (reflectsRecord.getObjValAs? (Array String) "binderInventory")) do
    throwError "Genuine Bool.Reflects type BinderInfo changed"
  let rs := { rs with standardExpansions := rs.standardExpansions.push (`Bool.Reflects, ([], reflectedValue)) }
  let introType ← checked (decodeExpr rs (← checked (field introRecord "typeExpr")))
  let introBridge ← forallTelescope introType fun args result => do
    unless args.size == 3 do throwError "Expected exact source Decidable.intro p b reflection telescope"
    let p := args[0]!
    let b := args[1]!
    let h := args[2]!
    unless (← inferType p) == mkSort .zero && (← inferType b).isConstOf ``Bool do
      throwError "Wrong proposition/Bool arguments of exact Decidable.intro"
    unless (← isDefEq (← inferType h) (mkApp2 reflectedValue b p)) &&
        (← isDefEq result (mkApp (mkConst ``Decidable) p)) do
      throwError "Wrong reflection/result type of exact Decidable.intro"
    let motive ← withLocalDeclD `flag (mkConst ``Bool) fun flag => do
      mkLambdaFVars #[flag] (← mkArrow (mkApp2 reflectedValue flag p) result)
    let falseCase ← withLocalDeclD `reflection (mkApp2 reflectedValue (mkConst ``Bool.false) p) fun hf => do
      mkLambdaFVars #[hf] (mkApp2 (mkConst ``Decidable.isFalse) p hf)
    let trueCase ← withLocalDeclD `reflection (mkApp2 reflectedValue (mkConst ``Bool.true) p) fun ht => do
      mkLambdaFVars #[ht] (mkApp2 (mkConst ``Decidable.isTrue) p ht)
    let value := mkAppN (mkConst ``Bool.rec [.succ .zero]) #[motive, falseCase, trueCase, b, h]
    mkLambdaFVars args value
  requireClosed "exact Decidable.intro representation transport" introBridge
  kernelTypeEq "transport inhabits exact genuine source constructor type"
    (← kernelCheck "exact Decidable.intro representation transport" introBridge) introType
  unless binderPlacement introType == binderPlacement (← inferType introBridge) do
    throwError "Exact constructor transport type BinderInfo placement changed. Expected: {reprStr (binderPlacement introType)}; inferred: {reprStr (binderPlacement (← inferType introBridge))}; expected type: {introType}; inferred type: {← inferType introBridge}"
  -- Prove that the transport preserves the actual original Boolean argument.
  let bitProof ← forallTelescope introType fun args _ => do
    let p := args[0]!
    let b := args[1]!
    let h := args[2]!
    let motive ← withLocalDeclD `flag (mkConst ``Bool) fun flag => do
      let reflected := mkApp2 reflectedValue flag p
      let goal ← withLocalDeclD `reflection reflected fun reflection => do
        let bit := mkApp2 (mkConst ``Decidable.decide) p (mkApp3 introBridge p flag reflection)
        mkForallFVars #[reflection] (← mkEq bit flag)
      mkLambdaFVars #[flag] goal
    let falseCase ← withLocalDeclD `reflection (mkApp2 reflectedValue (mkConst ``Bool.false) p) fun hf => do
      mkLambdaFVars #[hf] (← mkEqRefl (mkConst ``Bool.false))
    let trueCase ← withLocalDeclD `reflection (mkApp2 reflectedValue (mkConst ``Bool.true) p) fun ht => do
      mkLambdaFVars #[ht] (← mkEqRefl (mkConst ``Bool.true))
    let proof := mkAppN (mkConst ``Bool.rec [.zero]) #[motive, falseCase, trueCase, b, h]
    mkLambdaFVars args proof
  let bitProof ← instantiateMVars bitProof
  let expectedBitType ← forallTelescope introType fun args _ => do
    let bit := mkApp2 (mkConst ``Decidable.decide) args[0]! (mkAppN introBridge args)
    mkForallFVars args (← mkEq bit args[1]!)
  kernelTypeEq "constructor transport preserves genuine source decision bit"
    (← kernelCheck "constructor decision-bit preservation proof" bitProof) expectedBitType
  let mut axiomNames : Array Name := #[]
  for term in #[reflectedType, reflectedValue, introType, introBridge, bitProof] do
    let axs ← expressionAxioms term
    ensureStandard "Decidable representation transport" axs
    for ax in axs do
      unless axiomNames.contains ax do axiomNames := axiomNames.push ax
    for dependency in term.getUsedConstants do
      if rs.projectPrefixes.any (·.isPrefixOf dependency) then
        throwError "Project input in core Decidable representation transport {dependency}"
      let some owner := moduleOf (← getEnv) dependency |
        throwError "Missing core transport owner {dependency}"
      unless (`Init).isPrefixOf owner do
        throwError "Non-Init dependency in exact core representation transport {dependency}"
  let rs := { rs with standardExpansions := rs.standardExpansions.push (`Decidable.intro, ([], introBridge)) }
  let (rs, reflectionProofSupport) ← installMissingDecidableSupport rs supportRows `Nat.instDecidableCoprime._proof_1
  return (rs, Json.mkObj [
    ("boundCompatibilityEvidence", ← checked (field config "decidableStandardCompatibility")),
    ("missingStandardSupportExpansions", Json.arr (matcherSupport ++ reflectionProofSupport)),
    ("schema", toJson "decidable435-to433-representation-transport-v1"),
    ("genuineSourceFacts", facts),
    ("sourceFactFile", toJson path),
    ("sourceConstructor", toJson "Decidable.intro"),
    ("translatedConstructorType", ← checked (encodeExpr introType)),
    ("sourceBoolReflectsBody", ← checked (encodeExpr reflectedValue)),
    ("inlineConstructorTransport", ← checked (encodeExpr introBridge)),
    ("exactConstructorTypeKernelChecked", toJson true),
    ("exactConstructorTypeBinderInfoPreserved", toJson true),
    ("originalDecisionBitPreserved", toJson true),
    ("kernelCheckedDecisionBitProof", ← checked (encodeExpr bitProof)),
    ("decisionBitEquation", ← checked (encodeExpr expectedBitType)),
    ("axioms", toJson (axiomNames.map Name.toString)),
    ("classicalDecisionSubstitution", toJson false), ("hasSorryAx", toJson false)])

def exactDecidableTransportInstances : Array Name :=
  #[`TateCurvesTheta.OrderedTateParameter.decidable, `TateCurvesTheta.PrimeToOrder.decidable]

-- A full equality proof, limited to the two actual source instance values.
-- Each translated source value still executes its original Boolean computation.
def proveExactDecidableTransportEquality (rs : Relocations) (allowedOwners : Array Name)
    (original : Name) (sourceType sourceValue targetValue : Expr) : MetaM Json := do
  unless exactDecidableTransportInstances.contains original do
    throwError "No Decidable representation equality permission for {original}"
  let proof ← forallTelescope sourceType fun args result => do
    let expectedArgs := if original == `TateCurvesTheta.PrimeToOrder.decidable then 2 else 4
    unless args.size == expectedArgs && result.getAppFn.isConstOf ``Decidable &&
        result.getAppArgs.size == 1 do
      throwError "Unexpected exact prime-to-order decision instance telescope"
    let left := mkAppN sourceValue args
    let right := mkAppN targetValue args
    let pointwise ← mkAppM ``Subsingleton.elim #[left, right]
    let mut pointwise := pointwise
    for index in (List.range args.size).reverse do
      pointwise ← mkFunExt (← mkLambdaFVars #[args[index]!] pointwise)
    pure pointwise
  let proof ← instantiateMVars proof
  let expected ← mkEq sourceValue targetValue
  kernelTypeEq "exact translated instance full-value equality"
    (← kernelCheck "exact translated instance full-value equality proof" proof) expected
  let bitProof ← forallTelescope sourceType fun args result => do
    let p := result.getAppArgs[0]!
    -- Apply the full function equation to every actual instance argument.
    let mut instanceEquality := proof
    for argument in args do
      instanceEquality ← mkAppM ``congrFun #[instanceEquality, argument]
    let bitEquality ← mkAppM ``congrArg #[mkApp (mkConst ``Decidable.decide) p, instanceEquality]
    mkLambdaFVars args bitEquality
  let bitProof ← instantiateMVars bitProof
  let expectedBitType ← forallTelescope sourceType fun args result => do
    let decide := mkApp (mkConst ``Decidable.decide) result.getAppArgs[0]!
    mkForallFVars args (← mkEq (mkApp decide (mkAppN sourceValue args))
      (mkApp decide (mkAppN targetValue args)))
  kernelTypeEq "exact transported source and target decision bits equal"
    (← kernelCheck "exact transported instance decision-bit equality" bitProof) expectedBitType
  for term in #[proof, bitProof] do
    ensureStandard "exact transported decision equality" (← expressionAxioms term)
    for dependency in term.getUsedConstants do allowedOwner rs allowedOwners dependency
  return Json.mkObj [
    ("method", toJson "constructive subsingleton equality of exact Decidable p results; function extensionality over every instance argument"),
    ("original", encodeName original), ("definitionalValueEqual", toJson false),
    ("kernelCheckedPropositionalValueEquality", toJson true),
    ("exactFullValueEquality", ← checked (encodeExpr expected)),
    ("kernelCheckedEqualityProof", ← checked (encodeExpr proof)),
    ("kernelCheckedDecisionBitEquality", ← checked (encodeExpr bitProof)),
    ("sourceTargetDecisionBitEquation", ← checked (encodeExpr expectedBitType)),
    ("sourceBooleanComputationTransported", toJson true),
    ("axioms", toJson ((← expressionAxioms proof).map Name.toString)),
    ("classicalDecisionSubstitution", toJson false), ("hasSorryAx", toJson false)]


def compareRecord (rs : Relocations) (allowedOwners : Array Name) (record : Json) (target : ConstantInfo) : MetaM Json := do
  let original ← checked (decodeName (← checked (field record "nameExpr")))
  let sourceParams ← namesFromJson (← checked (field record "levelParams"))
  unless sourceParams.eraseDups == sourceParams do throwError "Duplicate universe parameter {original}"
  unless sourceParams.length == target.levelParams.length do
    throwError "Universe parameter count differs for {original}"
  unless (← checked (stringField record "constantKind")) == kind target do
    throwError "ConstantInfo kind differs for {original}"
  for key in #["axioms", "typeAxioms", "valueAxioms"] do
    for ax in ← checked (arrayField record key) do
      unless (standardAxioms.map fun n => Json.str n.toString).contains ax do
        throwError "Unexpected original axiom for {original}"
  let canonical := (canonicalLevels sourceParams.length).map Level.param
  let some rel := rs.find? (·.original == original) | throwError "Missing map entry {original}"
  let some expectedAxioms := rel.expectedAxioms |
    throwError "Missing accepted-graph source axiom inventory {original}"
  let sourceAxiomNames := (← checked (record.getObjValAs? (Array String) "axioms")).map String.toName
  unless sourceAxiomNames.qsort Name.lt == expectedAxioms.qsort Name.lt do
    throwError "Original axiom closure differs from accepted compiler graph {original}"
  let some expectedInstance := rel.expectedInstance |
    throwError "Missing accepted-graph instance flag {original}"
  unless (← checked (record.getObjValAs? Bool "isInstance")) == expectedInstance do
    throwError "Exported original instance flag differs from accepted graph {original}"
  unless Lean.Meta.isInstanceCore (← getEnv) target.name == expectedInstance do
    throwError "Instance registry membership differs for {original}"
  let targetLevels ← match rel.permutation with
    | none => pure canonical
    | some indices => do
      let reordered ← checked (reorder indices canonical.toArray)
      pure reordered.toList
  let sourceTypeRaw ← checked (decodeExpr rs (← checked (field record "elaboratedExpr")))
  let sourceType := sourceTypeRaw.instantiateLevelParams sourceParams canonical
  let targetType := target.type.instantiateLevelParams target.levelParams targetLevels
  unless (← checked (record.getObjValAs? (Array String) "binderInventory")) == binderInventory sourceType do
    throwError "Source serialization BinderInfo inventory differs for {original}"
  unless binderInventory sourceType == binderInventory targetType do
    throwError "Full type BinderInfo inventory differs for {original}"
  unless binderPlacement sourceType == binderPlacement targetType do
    throwError "BinderInfo placement inside the type differs for {original}"
  kernelTypeEq s!"original versus target type {original}" sourceType targetType
  unless (← checked (field record "computationShape")) ==
      (← checked (computationShape target (inverseRelocated rs))) do
    throwError "Inductive/constructor/recursor computation shape differs for {original}"
  let sourceProp ← checked (record.getObjValAs? Bool "isProposition")
  unless sourceProp == (← isProp target.type) do throwError "Proposition status differs {original}"
  let mut comparedValue := false
  let mut definitionallyEqualValue := false
  let mut propositionalValueEquality := Json.null
  let originalValueJson ← checked (field record "valueExpr")
  -- Proof declarations are audited by exact type and axiom closure. For a data
  -- value containing proof fields, Kernel.isDefEq itself uses proof irrelevance.
  if !sourceProp && originalValueJson != Json.null then
    let sourceValue := (← checked (decodeExpr rs originalValueJson)).instantiateLevelParams sourceParams canonical
    let some targetValue := target.value? (allowOpaque := true) |
      throwError "Target value missing for {original}"
    let targetValue := targetValue.instantiateLevelParams target.levelParams targetLevels
    kernelTypeEq s!"original value inhabits original type {original}"
      (← kernelCheck s!"original value {original}" sourceValue) sourceType
    kernelTypeEq s!"target value inhabits target type {original}"
      (← kernelCheck s!"target value {original}" targetValue) targetType
    -- Both terms and their exact common type were kernel-checked above.
    let definitionallyEqual ← match Kernel.isDefEq (← getEnv) {} sourceValue targetValue with
      | .ok equal => pure equal
      | .error exception => throwKernelException exception
    if definitionallyEqual then
      definitionallyEqualValue := true
    else
      if exactDecidableTransportInstances.contains original then
        propositionalValueEquality ← proveExactDecidableTransportEquality rs allowedOwners
          original sourceType sourceValue targetValue
      else
        propositionalValueEquality ← proveGeneratedEliminatorEquality rs allowedOwners
          original sourceType sourceValue targetValue
    comparedValue := true
  let rules ← checked (arrayField record "recursorRuleRhs")
  let mut comparedRules := 0
  if let .recInfo r := target then
    unless rules.size == r.rules.length do throwError "Recursor rule count differs {original}"
    for i in [:rules.size] do
      let sourceRhs := (← checked (decodeExpr rs rules[i]!)).instantiateLevelParams sourceParams canonical
      let targetRhs := r.rules[i]!.rhs.instantiateLevelParams target.levelParams targetLevels
      kernelTermEq s!"recursor rule {original} #{i}" sourceRhs targetRhs
      comparedRules := comparedRules + 1
  else
    unless rules.isEmpty do throwError "Unexpected original recursor rules {original}"
  let sourceStruct ← checked (field record "structure")
  unless (sourceStruct != Json.null) == (getStructureInfo? (← getEnv) target.name).isSome do
    throwError "Structure metadata presence differs {original}"
  if sourceStruct != Json.null then
    let some info := getStructureInfo? (← getEnv) target.name |
      throwError "Target structure metadata missing {target.name}"
    unless (← checked (field sourceStruct "completeMetadata")) ==
        (← checked (structureShape info (inverseRelocated rs))) do
      throwError "Complete structure field/parent metadata differs {original}"
    let autoParams ← checked (arrayField sourceStruct "fieldAutoParamExprs")
    unless autoParams.size == info.fieldInfo.size do
      throwError "Structure field autoParam count differs {original}"
    for i in [:autoParams.size] do
      match autoParams[i]!, info.fieldInfo[i]!.autoParam? with
      | sourceJson, some targetExpr =>
        if sourceJson == Json.null then throwError "Missing source autoParam {original} #{i}"
        let sourceExpr := (← checked (decodeExpr rs sourceJson)).instantiateLevelParams sourceParams canonical
        let targetExpr := targetExpr.instantiateLevelParams target.levelParams targetLevels
        unless binderPlacement sourceExpr == binderPlacement targetExpr do
          throwError "Structure autoParam BinderInfo placement differs {original} #{i}"
        kernelTermEq s!"structure field autoParam {original} #{i}" sourceExpr targetExpr
      | sourceJson, none =>
        unless sourceJson == Json.null do throwError "Missing target autoParam {original} #{i}"
    unless (← checked (field sourceStruct "fieldsInConstructorOrder")) ==
        toJson (info.fieldNames.map Name.toString) do
      throwError "Structure field order differs {original}"
    let projections ← namesFromJson (← checked (field sourceStruct "projections"))
    let targetProjections ← projections.toArray.mapM fun n => checked (relocated rs n)
    unless targetProjections == info.fieldInfo.map (·.projFn) do
      throwError "Structure accessor identities/order differ {original}"
    for p in targetProjections do
      unless rs.any (·.target == p) do throwError "Unaudited structure accessor {p}"
  return Json.mkObj [("original", toJson original.toString), ("originalName", encodeName original),
    ("target", toJson target.name.toString), ("targetName", encodeName target.name),
    ("sourceRecord", record), ("kernelTypeEqual", toJson true),
    ("allExpressionBinderInfoEqual", toJson true),
    ("binderInfoPlacementEqual", toJson true),
    ("computationShapeEqual", toJson true), ("completeStructureMetadataEqual", toJson true),
    ("kernelValueEqual", toJson definitionallyEqualValue),
    ("computationalValueEqualityChecked", toJson comparedValue),
    ("kernelPropositionalValueEquality", toJson (propositionalValueEquality != Json.null)),
    ("propositionalValueEqualityEvidence", propositionalValueEquality),
    ("proofDeclaration", toJson sourceProp), ("recursorRulesCompared", toJson comparedRules),
    ("instanceRegistryMatchesAcceptedGraph", toJson true),
    ("sourceAxiomInventoryMatchesAcceptedGraph", toJson true),
    ("expectedIsInstance", toJson expectedInstance),
    ("universeOriginalOrder", Json.arr (sourceParams.toArray.map encodeName)),
    ("universeTargetOrder", Json.arr (target.levelParams.toArray.map encodeName)),
    ("targetToSourceUniverseIndices", match rel.permutation with | none => Json.null | some a => toJson a)]

def audit : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected platform4.33.1, got {Lean.versionString}"
  let config ← jsonFile (← absoluteEnv "NEXT_CARRIER_AUDIT_CONFIG")
  unless (← checked (stringField config "schema")) == "next-carrier-kernel-audit-config-v3" do
    throwError "Wrong config schema"
  let source ← jsonFile (← checked (stringField config "originalExprFile"))
  unless (← checked (stringField source "schema")) == "foundation-original-exprs-v2" &&
      (← checked (stringField source "compilerVersion")) == "4.35.0-rc3" do
    throwError "Wrong original compiler/schema"
  for key in #["inventorySha256", "graphSha256"] do
    unless (← checked (field source key)) == (← checked (field config key)) do
      throwError "Input provenance hash differs: {key}"
  let records ← checked (arrayField source "records")
  let expectedRecordCount ← checked (config.getObjValAs? Nat "expectedRecordCount")
  let expectedSelectedCount ← checked (config.getObjValAs? Nat "expectedSelectedCount")
  unless records.size == expectedRecordCount do throwError "Original record count differs from config"
  unless (← checked (source.getObjValAs? Nat "recordCount")) == expectedRecordCount do
    throwError "Exporter record count differs from config"
  unless (← checked (source.getObjValAs? Nat "selectedCount")) == expectedSelectedCount do
    throwError "Exporter selected count differs from config"
  let moduleRows ← checked (arrayField config "modules")
  unless moduleRows.size == (← checked (config.getObjValAs? Nat "expectedModuleCount")) do
    throwError "Module count differs from config"
  let modules ← moduleRows.mapM fun row => return (← checked (stringField row "target")).toName
  let (rs, standardTransportEvidence) ← installDecidable435Transport (← readRelocations config) config
  let env ← getEnv
  let dependencyModules := (← namesFromJson (← checked (field config "allowedDependencyModules"))).toArray
  let standardPrefixes := (← namesFromJson (← checked (field config "standardModulePrefixes"))).toArray
  let allowedProjectModules := modules ++ dependencyModules
  unless allowedProjectModules.size == allowedProjectModules.toList.eraseDups.length do
    throwError "Duplicate allowed project modules"
  let mut allowedOwners := #[]
  for imported in env.header.moduleNames do
    unless standardPrefixes.any (·.isPrefixOf imported) || allowedProjectModules.contains imported do
      throwError "Forbidden imported module {imported}"
    allowedOwners := allowedOwners.push imported
  let (rs, proofResolutionReports) ← installExactDecidableSourceProofs rs allowedOwners source config
  let directImports := ((env.header.imports.map (·.module)).toList.eraseDups).toArray.filter (· != `Init)
  unless directImports.size == allowedProjectModules.size + 1 && directImports.contains `Lean &&
      allowedProjectModules.all directImports.contains do
    throwError "Auditor direct imports differ from exact configured Def-module set plus Lean"
  let mut directImportReports : Array Json := #[]
  for row in moduleRows do
    let owner := (← checked (stringField row "target")).toName
    let expected := (← checked (row.getObjValAs? (Array String) "allowedDirectImports")).map String.toName
    unless expected.size == expected.toList.eraseDups.length do throwError "Duplicate direct imports {owner}"
    let mut actual : Array Name := #[]
    let mut ownerFound := false
    for i in [:env.header.moduleNames.size] do
      if env.header.moduleNames[i]! == owner then
        let some data := env.header.moduleData[i]? | throwError "Module data missing {owner}"
        actual := ((data.imports.map (·.module)).toList.eraseDups).toArray.filter (· != `Init)
        ownerFound := true
    unless ownerFound && actual.size == expected.size && actual.all expected.contains do
      throwError "Target direct imports differ from precise configured imports {owner}"
    if actual.contains `Mathlib then throwError "Broad Mathlib import forbidden {owner}"
    directImportReports := directImportReports.push (Json.mkObj [
      ("module", toJson owner.toString), ("actual", toJson (actual.map Name.toString)),
      ("exactConfiguredImportSet", toJson true)])
  let declarations := env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)
  unless declarations.size > 0 do throwError "No carrier declarations"
  let mut ownedReports := #[]
  let mut comparisons := #[]
  let mut seenOriginal : Array Name := #[]
  let mut requiredCount := 0
  let mut requiredNamedCount := 0
  let mut resolvedProofNames : Array Name := #[]
  let mut missingOptional := #[]
  for record in records do
    let original ← checked (decodeName (← checked (field record "nameExpr")))
    if seenOriginal.contains original then throwError "Duplicate original record {original}"
    seenOriginal := seenOriginal.push original
    unless original.toString == (← checked (stringField record "name")) do
      throwError "Original name identity differs"
    let sourceOwner ← checked (stringField record "module")
    let ownerRows := moduleRows.filter fun row => (stringField row "original").toOption == some sourceOwner
    unless ownerRows.size == 1 do throwError "Original module not configured: {sourceOwner}"
    for key in #["sourceSha256", "normalizedSha256"] do
      unless (← checked (field record key)) == (← checked (field ownerRows[0]! key)) do
        throwError "Original source provenance differs: {key}"
    let selected ← checked (record.getObjValAs? Bool "selected")
    if exactDecidableSourceProofNames.contains original then
      unless selected && proofResolutionReports.any (fun row => (stringField row "original").toOption == some original.toString) do
        throwError "Unvalidated mandatory genuine source proof {original}"
      requiredCount := requiredCount + 1
      resolvedProofNames := resolvedProofNames.push original
      continue
    let targetName ← checked (relocated rs original)
    if selected then requiredCount := requiredCount + 1
    unless env.contains targetName do
      if selected then throwError "Required generated/source declaration missing: {original} -> {targetName}"
      missingOptional := missingOptional.push (toJson original.toString)
      continue
    unless moduleOf env targetName == some (← checked (stringField ownerRows[0]! "target")).toName do
      throwError "Wrong target artifact owner {targetName}"
    comparisons := comparisons.push (← compareRecord rs allowedOwners record (← getConstInfo targetName))
    if selected then requiredNamedCount := requiredNamedCount + 1
  unless requiredCount == expectedSelectedCount do throwError "Mandatory selected count differs from config"
  unless resolvedProofNames.size == exactDecidableSourceProofNames.size &&
      requiredNamedCount == (← checked (config.getObjValAs? Nat "expectedNamedSelectedCount")) &&
      proofResolutionReports.size == (← checked (config.getObjValAs? Nat "expectedProofValueResolutionCount")) do
    throwError "Named/proof-resolution dimensions differ from actual configured inventory"
  for resolution in proofResolutionReports do
    let parent ← checked (stringField resolution "parentOriginal")
    let parents := comparisons.filter fun row => (stringField row "original").toOption == some parent
    unless parents.size == 1 do throwError "Missing mandatory whole-value parent comparison {parent}"
    let parentReport := parents[0]!
    unless (← checked (parentReport.getObjValAs? Bool "computationalValueEqualityChecked")) &&
        ((← checked (parentReport.getObjValAs? Bool "kernelValueEqual")) ||
         (← checked (parentReport.getObjValAs? Bool "kernelPropositionalValueEquality"))) do
      throwError "Genuine proof resolution parent has no kernel whole-value equality {parent}"
  let mut targetOnly := #[]
  for name in declarations.qsort Name.lt do
    ownedReports := ownedReports.push (← auditDeclaration rs allowedOwners name)
    if !(rs.any fun r => r.target == name && seenOriginal.contains r.original) then
      targetOnly := targetOnly.push (toJson name.toString)
  let expectedTargetOnly ← checked (arrayField config "expectedTargetOnlyCompilerDeclarations")
  unless targetOnly.size == expectedTargetOnly.size && targetOnly.all expectedTargetOnly.contains do
    throwError "Actual target-only compiler declarations differ from genuine platform facts"
  let output ← checked (stringField config "outputDir")
  IO.FS.createDirAll output
  IO.FS.writeFile (output ++ "/next-carrier-kernel-audit.json") ((Json.mkObj [
    ("schema", toJson "next-carrier-kernel-audit-v3"), ("compilerVersion", toJson Lean.versionString),
    ("originalCompilerVersion", toJson "4.35.0-rc3"),
    ("configuration", config), ("standardRepresentationTransport", standardTransportEvidence),
    ("requiredComparedCount", toJson requiredCount),
    ("requiredSourceDeclarationCount", toJson requiredCount),
    ("requiredResolvedCount", toJson (requiredNamedCount + proofResolutionReports.size)),
    ("requiredEliminatedInternalProofCount", toJson proofResolutionReports.size),
    ("requiredNamedComparedCount", toJson requiredNamedCount),
    ("requiredProofValueResolutionCount", toJson proofResolutionReports.size),
    ("proofValueResolutions", Json.arr proofResolutionReports),
    ("comparisons", Json.arr comparisons), ("ownedDeclarations", Json.arr ownedReports),
    ("directImportReports", Json.arr directImportReports),
    ("previouslyAcceptedDependencyModules", Json.arr (dependencyModules.map encodeName)),
    ("missingUnselectedOriginalDeclarations", Json.arr missingOptional),
    ("targetOnlyCompilerDeclarations", Json.arr targetOnly),
    ("allOwnedTypeValueClosuresStandardAxiomsOnly", toJson true),
    ("hasSorryAx", toJson false),
    ("targetOnlyPolicy", toJson "all reported and axiom audited; review source-command generation provenance before acceptance")]).pretty ++ "\n")
  logInfo s!"Next carrier audit: {requiredCount} mandatory exact types; {comparisons.size} total original/target pairs; {ownedReports.size} artifact-owned axiom closures"

end FoundationAudit

syntax (name := auditNextCarrier) "audit_next_carriers" : command
@[command_elab auditNextCarrier] def elabAuditNextCarrier : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM FoundationAudit.audit

audit_next_carriers
