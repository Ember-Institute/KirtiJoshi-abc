import Lean
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_LeftHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_RightHandSide
import Definitions.Def_AbcAdaptation_Reference_Iut_Cor312_Statement
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Invariants
import Definitions.Def_AbcAdaptation_Reference_Iut_Implication_LogVolumeBound

/-! Stable JSON for *actual compiler Exprs*. No pretty-printer text is decoded here.
    Metadata is erased; local/metavariables are rejected. -/
namespace FoundationAudit
open Lean

def field (j : Json) (key : String) : Except String Json := j.getObjVal? key
def stringField (j : Json) (key : String) : Except String String := do
  (← field j key).getStr?
def arrayField (j : Json) (key : String) : Except String (Array Json) := do
  (← field j key).getArr?

-- Preserve actual Name components, including numeric components; do not use String.toName.
partial def encodeName : Name → Json
  | .anonymous => Json.arr #[]
  | .str p s => Json.arr #[(encodeName p), Json.str "str", Json.str s]
  | .num p n => Json.arr #[(encodeName p), Json.str "num", toJson n]

partial def decodeName (j : Json) : Except String Name := do
  let a ← j.getArr?
  if a.isEmpty then return .anonymous
  unless a.size == 3 do throw "Invalid Name JSON"
  let p ← decodeName a[0]!
  match ← a[1]!.getStr? with
  | "str" => return .str p (← a[2]!.getStr?)
  | "num" => return .num p (← a[2]!.getNat?)
  | _ => throw "Invalid Name component"

def node (kind : String) (values : List (String × Json)) : Json :=
  Json.mkObj (("kind", Json.str kind) :: values)

partial def encodeLevel : Level → Except String Json
  | .zero => return node "zero" []
  | .succ u => return node "succ" [("arg", ← encodeLevel u)]
  | .max u v => return node "max" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .imax u v => return node "imax" [("left", ← encodeLevel u), ("right", ← encodeLevel v)]
  | .param n => return node "param" [("name", encodeName n)]
  | .mvar _ => throw "Universe metavariable in compiler type"

partial def decodeLevel (j : Json) : Except String Level := do
  match ← stringField j "kind" with
  | "zero" => return .zero
  | "succ" => return .succ (← decodeLevel (← field j "arg"))
  | "max" => return .max (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "imax" => return .imax (← decodeLevel (← field j "left")) (← decodeLevel (← field j "right"))
  | "param" => return .param (← decodeName (← field j "name"))
  | k => throw s!"Unknown universe kind: {k}"

def encodeBinder : BinderInfo → String
  | .default => "default"
  | .implicit => "implicit"
  | .strictImplicit => "strictImplicit"
  | .instImplicit => "instImplicit"

def decodeBinder : String → Except String BinderInfo
  | "default" => return .default
  | "implicit" => return .implicit
  | "strictImplicit" => return .strictImplicit
  | "instImplicit" => return .instImplicit
  | k => throw s!"Unknown binder info: {k}"

partial def encodeExpr : Expr → Except String Json
  | .bvar i => return node "bvar" [("index", toJson i)]
  | .sort u => return node "sort" [("level", ← encodeLevel u)]
  | .const n us => return node "const" [("name", encodeName n),
      ("levels", Json.arr (← us.toArray.mapM encodeLevel))]
  | .app f a => return node "app" [("fn", ← encodeExpr f), ("arg", ← encodeExpr a)]
  | .lam n t b bi => return node "lam" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .forallE n t b bi => return node "forall" [("name", encodeName n),
      ("type", ← encodeExpr t), ("body", ← encodeExpr b), ("binder", toJson (encodeBinder bi))]
  | .letE n t v b nd => return node "let" [("name", encodeName n),
      ("type", ← encodeExpr t), ("value", ← encodeExpr v), ("body", ← encodeExpr b),
      ("nondependent", toJson nd)]
  | .lit (.natVal n) => return node "nat" [("value", toJson n)]
  | .lit (.strVal s) => return node "string" [("value", toJson s)]
  | .mdata _ b => encodeExpr b
  | .proj n i b => return node "proj" [("name", encodeName n), ("index", toJson i),
      ("body", ← encodeExpr b)]
  | .fvar _ => throw "Free variable in compiler declaration type"
  | .mvar _ => throw "Expression metavariable in compiler declaration type"

open Lean Elab Term Meta

def checked {α : Type} (x : Except String α) : MetaM α :=
  match x with
  | .ok a => pure a
  | .error e => throwError "{e}"

def namesFromJson (j : Json) : MetaM (List Name) := do
  return (← checked ((← checked j.getArr?).mapM decodeName)).toList

def jsonFile (p : String) : MetaM Json := do
  checked (Json.parse (← IO.FS.readFile p))

def absoluteEnv (key : String) : MetaM String := do
  let some p ← IO.getEnv key | throwError "Missing environment variable {key}"
  unless p.startsWith "/" do throwError "Expected absolute path: {key}"
  return p

def moduleOf (env : Environment) (name : Name) : Option Name := do
  let index ← env.getModuleIdxFor? name
  env.header.moduleNames[index.toNat]?

def standardAxioms : Array Name := #[`propext, `Classical.choice, `Quot.sound]

def ensureStandard (label : String) (axs : Array Name) : MetaM Unit := do
  for ax in axs do
    unless standardAxioms.contains ax do throwError "Unexpected axiom in {label}: {ax}"

abbrev AxiomCache := IO.Ref (Std.HashMap Name (Array Name))

-- The imported source environment is stable throughout this one export run.
-- Cache only successful collectAxioms results; errors still propagate normally.
def cachedAxioms (cache : AxiomCache) (name : Name) : MetaM (Array Name) := do
  if let some axs := (← cache.get)[name]? then return axs
  let axs ← collectAxioms name
  cache.modify fun entries => entries.insert name axs
  return axs

def expressionAxioms (cache : AxiomCache) (e : Expr) : MetaM (Array Name) := do
  let mut axs : Array Name := #[]
  for name in e.getUsedConstants do
    for ax in ← cachedAxioms cache name do
      unless axs.contains ax do axs := axs.push ax
  return axs.qsort Name.lt

partial def binderInventory : Expr → Array String
  | .forallE _ t b bi => #["forall:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .lam _ t b bi => #["lambda:" ++ encodeBinder bi] ++ binderInventory t ++ binderInventory b
  | .app f a => binderInventory f ++ binderInventory a
  | .letE _ t v b _ => binderInventory t ++ binderInventory v ++ binderInventory b
  | .mdata _ e => binderInventory e
  | .proj _ _ e => binderInventory e
  | _ => #[]

def kind (ci : ConstantInfo) : String := match ci with
  | .axiomInfo _ => "axiom" | .defnInfo _ => "definition" | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque" | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor"


end FoundationAudit
namespace MainFiveOwned173Query
open Lean Elab Term Meta FoundationAudit

def query : TermElabM Unit := do
  unless Lean.versionString == "4.33.1" do throwError "Expected locked target Lean4.33.1"
  let config ← jsonFile (← absoluteEnv "MAIN_FIVE_OWNED173_CONFIG")
  unless (← checked (stringField config "schema")) == "main5-selected173-and-full-owned-inventory-config/v2" do
    throwError "Wrong owned173 query configuration"
  unless !(← checked (config.getObjValAs? Bool "publishAllowed")) &&
      !(← checked (config.getObjValAs? Bool "finalAcceptance")) do
    throwError "Owned173 query cannot grant formal acceptance"
  let modules ← (← checked (config.getObjValAs? (Array String) "nativeModules")).mapM fun s => pure s.toName
  unless modules.size == 5 && (← checked (config.getObjValAs? Nat "expectedSelectedCount")) == 173 do
    throwError "Expected five native owners and173 selected native declarations"
  let rows ← checked (arrayField config "projectMap")
  unless rows.size == 173 do throwError "Owned173 query lost a selected original record"
  let fullNames ← namesFromJson (← checked (field config "fullFactNames"))
  unless fullNames.length == 6 do throwError "Expected dmod plus all five complete proof facts"
  -- The first declaration lookup inspects the imported environment directly.
  let env ← getEnv
  let globalPriority ← Lean.Meta.getInstancePriority? `AddSubmonoidClass.toAddCommMonoid
  unless globalPriority == some 75 do throwError "Expected global instance priority75 outside the local dmod section"
  let owned := (env.constants.fold (fun acc n _ =>
    if (moduleOf env n).any modules.contains then acc.push n else acc) (#[] : Array Name)).qsort Name.lt
  Lean.logInfo m!"Observed imported native owned declaration count: {owned.size}"
  let axiomCache ← IO.mkRef ({} : Std.HashMap Name (Array Name))
  let mut expectedTargets : Array Name := #[]
  let mut declarations : Array Json := #[]
  let mut fullFacts : Array Json := #[]
  for row in rows do
    let original ← checked (decodeName (← checked (field row "originalName")))
    let target ← checked (decodeName (← checked (field row "targetName")))
    let owner := (← checked (stringField row "targetOwner")).toName
    unless (← checked (row.getObjValAs? Bool "currentSelectedNamed")) do
      throwError "A nonselected mapping entered the owned173 query: {original}"
    unless !expectedTargets.contains target do throwError "Duplicate structural target Name: {target}"
    expectedTargets := expectedTargets.push target
    let some ci := env.find? target | throwError "Missing persisted selected native declaration: {target}"
    unless moduleOf env target == some owner && modules.contains owner do
      throwError "Actual native owner differs: {target}"
    unless kind ci == (← checked (stringField row "expectedConstantKind")) do
      throwError "Actual ConstantInfo kind differs: {target}"
    let expectedInstance ← checked (row.getObjValAs? Bool "expectedIsInstance")
    unless Lean.Meta.isInstanceCore env target == expectedInstance do
      throwError "Actual instance registry differs: {target}"
    let axs ← cachedAxioms axiomCache target
    ensureStandard s!"owned173 declaration {target}" axs
    let expectedAxioms ← namesFromJson (← checked (field row "expectedSourceAxioms"))
    unless axs.qsort Name.lt == expectedAxioms.toArray.qsort Name.lt do
      throwError "Actual source/native axiom inventory differs: {target}"
    let typeAxs ← expressionAxioms axiomCache ci.type
    let value := ci.value? (allowOpaque := true)
    let valueAxs ← match value with
      | none => pure #[]
      | some e => expressionAxioms axiomCache e
    let complete := fullNames.contains target
    declarations := declarations.push (Json.mkObj [
      ("original", toJson original.toString), ("originalName", encodeName original),
      ("name", toJson target.toString), ("nameExpr", encodeName target),
      ("module", toJson owner.toString), ("constantKind", toJson (kind ci)),
      ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
      ("isProposition", toJson (← isProp ci.type)),
      ("isInstance", toJson (Lean.Meta.isInstanceCore env target)),
      ("axioms", toJson (axs.map Name.toString)),
      ("typeAxioms", toJson (typeAxs.map Name.toString)),
      ("valueAxioms", toJson (valueAxs.map Name.toString)),
      ("hasSorryAx", toJson (axs.contains `sorryAx)),
      ("hasValue", toJson value.isSome), ("fullFactExported", toJson complete),
      ("selectedOriginalRecord", toJson true), ("originalSourceCorrespondenceAccepted", toJson false),
      ("sourceView", ← checked (field row "sourceView"))])
    if complete then
      fullFacts := fullFacts.push (Json.mkObj [
        ("name", toJson target.toString), ("nameExpr", encodeName target),
        ("module", toJson owner.toString), ("constantKind", toJson (kind ci)),
        ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
        ("elaboratedExpr", ← checked (encodeExpr ci.type)),
        ("valueExpr", ← match value with
          | none => pure Json.null
          | some e => checked (encodeExpr e)),
        ("binderInventory", toJson (binderInventory ci.type)),
        ("valueBinderInventory", toJson (match value with
          | none => #[] | some e => binderInventory e)),
        ("isProposition", toJson (← isProp ci.type)),
        ("isInstance", toJson (Lean.Meta.isInstanceCore env target)),
        ("axioms", toJson (axs.map Name.toString)),
        ("typeAxioms", toJson (typeAxs.map Name.toString)),
        ("valueAxioms", toJson (valueAxs.map Name.toString)),
        ("typeUsedConstants", Json.arr (ci.type.getUsedConstants.map encodeName)),
        ("valueUsedConstants", Json.arr (match value with
          | none => #[] | some e => e.getUsedConstants.map encodeName)),
        ("hasSorryAx", toJson (axs.contains `sorryAx))])
  let additionalOwned := owned.filter fun n => !expectedTargets.contains n
  let expectedAdditional ← namesFromJson (← checked (field config "expectedAdditionalOwnedNames"))
  unless owned.size == (← checked (config.getObjValAs? Nat "expectedWholeOwnedCount")) &&
      expectedTargets.all owned.contains && additionalOwned == expectedAdditional.toArray.qsort Name.lt do
    Lean.logInfo m!"Actual owned structural Names: {(Json.arr (owned.map encodeName)).compress}"
    throwError "Selected173 coverage or complete additional-owned inventory changed"
  let mut additionalFacts : Array Json := #[]
  for name in additionalOwned do
    let some ci := env.find? name | throwError "Missing additional owned declaration: {name}"
    let some owner := moduleOf env name | throwError "Missing additional declaration owner: {name}"
    unless modules.contains owner do throwError "Additional declaration has forbidden owner: {name}"
    let axs ← cachedAxioms axiomCache name
    ensureStandard s!"additional owned compiler declaration {name}" axs
    let typeAxs ← expressionAxioms axiomCache ci.type
    let value := ci.value? (allowOpaque := true)
    let valueAxs ← match value with
      | none => pure #[]
      | some e => expressionAxioms axiomCache e
    additionalFacts := additionalFacts.push (Json.mkObj [
      ("name", toJson name.toString), ("nameExpr", encodeName name),
      ("module", toJson owner.toString), ("constantKind", toJson (kind ci)),
      ("levelParams", Json.arr (ci.levelParams.toArray.map encodeName)),
      ("elaboratedExpr", ← checked (encodeExpr ci.type)),
      ("valueExpr", ← match value with
        | none => pure Json.null
        | some e => checked (encodeExpr e)),
      ("binderInventory", toJson (binderInventory ci.type)),
      ("isProposition", toJson (← isProp ci.type)),
      ("isInstance", toJson (Lean.Meta.isInstanceCore env name)),
      ("axioms", toJson (axs.map Name.toString)),
      ("typeAxioms", toJson (typeAxs.map Name.toString)),
      ("valueAxioms", toJson (valueAxs.map Name.toString)),
      ("hasSorryAx", toJson (axs.contains `sorryAx)), ("hasValue", toJson value.isSome),
      ("selectedOriginalRecord", toJson false),
      ("classification", toJson "additional-private-compiler-declaration-outside-selected173"),
      ("originalSourceCorrespondenceAccepted", toJson false),
      ("compilerFactExportIsNotSourceIdentityAcceptance", toJson true)])
  unless fullFacts.size == 6 do throwError "A complete dmod/proof fact was omitted"
  IO.FS.writeFile (← checked (stringField config "outputFile")) ((Json.mkObj [
    ("schema", toJson "main5-selected173-with-complete-owned-inventory/v2"),
    ("compilerVersion", toJson Lean.versionString),
    ("configuration", config), ("nativeModules", toJson (modules.map Name.toString)),
    ("ownedDeclarationCount", toJson owned.size),
    ("ownedDeclarations", Json.arr (declarations ++ additionalFacts)),
    ("selectedSourceDeclarationCount", toJson declarations.size),
    ("selectedNativeDeclarations", Json.arr declarations),
    ("additionalOwnedDeclarationCount", toJson additionalFacts.size),
    ("additionalOwnedDeclarations", Json.arr additionalFacts),
    ("additionalDeclarationsSourceIdentityAccepted", toJson false),
    ("completeDmodAndFiveProofFacts", Json.arr fullFacts),
    ("all173StructuralNamesOwnersKindsInstancesAndAxiomsChecked", toJson true),
    ("globalPriorityOutsideDmodSection", toJson (75 : Nat)),
    ("fullOriginalSourceTypeCorrespondenceClaimed", toJson false),
    ("fullOriginalSourceDataValueCorrespondenceClaimed", toJson false),
    ("constantExpansionPerformed", toJson false),
    ("relativeOnly", toJson true), ("publishAllowed", toJson false),
    ("finalAcceptance", toJson false)]).compress ++ "\n")

end MainFiveOwned173Query
syntax (name := mainFiveOwned173Facts) "query_main_five_owned173_facts" : command
@[command_elab mainFiveOwned173Facts] def elabMainFiveOwned173Facts : Lean.Elab.Command.CommandElab := fun _ => do
  Lean.Elab.Command.liftTermElabM MainFiveOwned173Query.query

query_main_five_owned173_facts
