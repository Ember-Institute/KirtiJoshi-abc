# main5 LOCAL SOURCE-relative dossier（173 named +独立private3）

五模块selected173实际证据已齐：

| 来源模块 | selected named | 实际成功job | 当前输入处理 |
| --- | ---: | --- | --- |
| LeftHandSide |25|ci-016289-67f9e99c|复用未受影响源码/传递import闭包 |
| RightHandSide |26|ci-016309-be6b18cf|复用未受影响源码/传递import闭包 |
| Statement |19|ci-016310-7b16a5b6|复用未受影响源码/传递import闭包 |
| Invariants |71|ci-017060-d0215257|当前621ad6...源码、新两证书已重验 |
| LogVolumeBound |32|ci-017112-783745de|当前Invariants依赖重建后的strict32已重验 |
| 合计 |173| | |

原Left25/Right26/Statement19全部70项的Definitions传递import闭包都不包含Invariants或LogVolumeBound；每份当前源码SHA都匹配历史readback manifest的production pin。当前olean存在并另行记录hash，但旧回执没有individual olean hash，不能把“源码/依赖传播不受影响”夸大成旧产物二进制身份。toolchain/configuration locks也核对旧回执。上游尚余pending2，因此复用只在LOCAL SOURCE-relative边界内成立，不增补平台或上游接受声明。

三个旧模块配置虽然曾安装全局dmod source proof值，merge逐个扫描这70份完整source DAG，确认没有任何记录引用该proof Name。因此这70项仍是named对应，没有通过proof-value替换改变其任一原type/value。

## 最小汇总脚本

```text
python3 merge_local_source_dossier.py
```

脚本只读实际receipt/config/inner报告、原DAG及当前源码/产物pin，验证173唯一来源和173唯一target、各模块计数、173owner/axiom、两具名完整函数证明与其余171 strict结果。private3另从实际strict `ci-016760-3b51d7c0` 复用完整type/value/BinderInfo/axiom证据；它们是原197中的selected=false编译器声明，不混入数学selected173。

结果：`main5-local-source-relative-dossier.json`。当前已执行的本地归并确认五模块173来源证据齐全，同时明确 `currentOwned176FreshlyConfirmed=false`（字段为ownedInventory.freshCurrentInventoryConfirmed），因为整个owned176清单仍需要下面同一已有查询在当前输入下更新；旧ci016686清单不冒充新当前清单。

source-record范围为197原记录中的173 selected +3 private未selected=176；另21条公开数学定理未覆盖，不能宣称original197全部完成。

raw false事实保持：Theorem110Certificate.casesOn的raw两项false/defeq=false/完整Eq=true；recOn raw两项false/defeq=true/完整Eq=true。其余171项保留strict条件。没有新增signature容错、数据等价桥、标准rename、alias或replacement。

## 当前owned176最小刷新（已有query重跑，不是新gate）

入口：`QueryCurrentSelected173AndOwned176.lean`（逐字原通过query，SHA3590ce837a880050f9770b35bf87aff6107f5f78bf87d4a6be2a7c57e8839117）。

```text
MAIN_FIVE_OWNED173_CONFIG=<actual root task directory>/current-owned176-config.json
```

root复制时仅改新config.outputFile，source复制原字节。它仍核对selected173/wholeowned176/额外private3的同一精确结构Name集合，并导出当前完整dmod5proof和private3事实。旧owned查询包含已经变化的Invariants类型，故只更新这份既有事实，不重编未受影响三模块。

新query实际成功后：

```text
python3 merge_local_source_dossier.py --owned-receipt <actual fresh receipt> --owned-output <actual fresh facts JSON>
```

脚本会把当前176owned集合与173named+private3精确结构Name对齐，并逐项要求private3当前完整type/value/universe/kind/instance/axioms与原strict证明输入完全相同。当前Log32已经严格检查它们依赖的placeBound.match_1。private3旧事实/config没有旧五源码SHA硬绑定，且源文件/匹配器依赖未变；因此若当前完整Expr事实相同，就直接复用已有private3严格证明，无需新编译或另加gate。若事实有差异，merge明确失败，不覆盖旧绑定、不伪造源对应；root再选择重放原private3审查。

## 当前Log32输入的历史记录

`current-source-log32-config.json`和`next-log32-review-plan.json`是已给root使用的最小重验输入；当前实际成功ci017112已取代旧ci016601的主证据。新报告与current71的173named map一致、32records/0proof，旧受影响Log32报告不冒用。

`reuse-three-modules-and-private-plan.json`记录未影响70项完整闭包源码pin、当前artifact pin、旧成功receipt、private3复用条件。`merge_local_source_dossier.py`、现有owned query和原strict审查器均没有新增数学目标或验收门。

所有总结果始终 `initialUpstreamPendingObligationCountReportedByRoot=2`、`platformAccepted=false`、`platformFinalAcceptance=false`、`publishAllowed=false`、`finalAcceptance=false`。此任务没有CI/编译/API/Git或主区写入，未读取巨量original export；本脚本也不会调用这些操作。
