#!/usr/bin/env python3
"""Package saved LOCAL evidence only. No compiler, CI, API, Git, or mathematical review."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

ROOT = Path('/home/admin-wsl/Coq/abc')
WORK = ROOT / 'prove2me_workspace'
BASE = WORK / '.local/adaptation'
MIB = 1024 * 1024
INPUT_LIMIT = 128 * MIB
# Reserve eight MiB for generated manifest and a copy of this script.
PAYLOAD_LIMIT = 120 * MIB
SEEDS = [
    (BASE / 'reference-initial-theta-carriers-20261115/basic34-math-dossier-v27/final-kernel-dossier.json',
     '0efd5de890fd1b5d3180da270635e4fed31dfc1549d7939698f63955773b2b99'),
    (BASE / 'main5-local-dossier-v27-20261116/main5-local-source-relative-dossier.json',
     '8921a39bb3955c4b87ddec4fd24f15a1571b5b5632ddb5a08cdf2cff7445243d'),
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output-dir', required=True, help='New directory under /tmp; never a repository directory')
    ap.add_argument('--plan', action='store_true', help='Print stat-only selection summary; create no archive')
    args = ap.parse_args()
    destination = Path(args.output_dir).resolve()
    if not destination.is_relative_to(Path('/tmp')) or destination == Path('/tmp'):
        raise SystemExit('--output-dir must be a new directory below /tmp')
    if destination.exists():
        raise SystemExit('Output directory already exists; select a new /tmp directory')
    candidates = {}
    references = {}
    dossier_data = []

    def add(path, pin=None, role='support', priority=5, origin=None):
        path = Path(path)
        if not path.is_absolute():
            path = WORK / path
        key = str(path)
        row = candidates.setdefault(key, {'path': key, 'pins': set(), 'roles': set(), 'origins': set(), 'priority': priority})
        if pin:
            row['pins'].add(pin)
        row['roles'].add(role)
        if origin:
            row['origins'].add(origin)
        row['priority'] = min(row['priority'], priority)

    def walk(value, pointer='', origin='dossier'):
        # Only walk already loaded dossier structure. Never open referenced configs/exports.
        if isinstance(value, dict):
            if isinstance(value.get('path'), str):
                path = value['path']
                role = 'source-view' if any(x in pointer.lower() for x in ['sourceview', 'sourcerecord']) else 'support'
                add(path, value.get('sha256'), role, 6 if role == 'source-view' else 4, origin + pointer)
            for key, child in value.items():
                # These are historical input pins, not a request to collect dependency closures.
                if key == 'actualInputPins' and isinstance(child, dict):
                    for path, pin in child.items():
                        references.setdefault(path, {'path': path, 'original_pin': pin, 'reason': 'historical-input-pin; dependency closure not traversed'})
                    continue
                walk(child, pointer + '/' + str(key), origin)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, pointer + '/' + str(index), origin)

    for path, pin in SEEDS:
        if path.stat().st_size > 16 * MIB:
            raise SystemExit('Seed unexpectedly exceeds 16 MiB')
        data = path.read_bytes()
        if digest(data) != pin:
            raise SystemExit('Dossier changed: ' + str(path))
        parsed = json.loads(data)
        dossier_data.append(parsed)
        add(path, pin, 'dossier', 0)
        walk(parsed, origin=str(path))
    basic, main5 = dossier_data
    # Consume explicit saved dossier outcomes, without rerunning mathematical checks.
    if basic.get('locallyCompleteNamedCount') != 34 or not basic.get('all34NamedMathGatesPassed'):
        raise SystemExit('Saved Basic local completion outcome differs')
    if main5.get('selectedNamedCount') != 173 or main5.get('independentlyCheckedPrivateCount') != 3:
        raise SystemExit('Saved main5 outcome differs')
    if main5.get('ownedInventory', {}).get('actualJob') != 'ci-017117-e744b85b':
        raise SystemExit('Expected fresh owned inventory receipt missing')
    if not main5.get('localSourceRelativeOnly') or main5.get('platformAccepted'):
        raise SystemExit('Expected LOCAL SOURCE-relative scope differs')

    add(ROOT / 'refer/iut/LICENSE', role='license', priority=0)
    add(Path(__file__).absolute(), role='packaging-script', priority=0)
    # Restrict current Definition sources to the dossier's exact Basic plus five-native inputs.
    add(basic['sourceDefinition']['path'], basic['sourceDefinition']['sha256'], 'current-definition', 0)
    for entry in main5['currentFiveNativeInputs']:
        add(entry['source']['path'], entry['source']['sha256'], 'current-definition', 0)
    for filename in ['README.md', 'delivery-manifest.json', 'root-integration.json']:
        path = SEEDS[1][0].parent / filename
        if path.is_file():
            add(path, role='local-summary', priority=3)

    # Actual CI triplets only; do not recursively discover dependencies from result manifests.
    for row in list(candidates.values()):
        result = Path(row['path'])
        if result.name.endswith('-result.json'):
            request = result.with_name(result.name[:-len('-result.json')] + '-request.json')
            submit = result.with_name(result.name[:-len('-result.json')] + '-submit.json')
            if request.is_file():
                add(result, role='ci-result', priority=1)
                add(request, role='ci-request', priority=1)
                add(submit, role='ci-submit', priority=1)
                if request.stat().st_size <= MIB:
                    req = json.loads(request.read_text())
                    source = req.get('parameters', {}).get('source')
                    if source:
                        add(source, role='actual-query-source', priority=2, origin=str(request))
                    for key, value in req.get('environment', {}).items():
                        if key not in ['PATH', 'LEAN_PATH'] and isinstance(value, str) and value.startswith('/'):
                            add(value, role='small-query-config', priority=3, origin=str(request))

    exclusions = list(references.values())
    selected = []
    total = 0
    for row in sorted(candidates.values(), key=lambda r: (r['priority'], r['path'])):
        row = dict(row)
        for key in ['pins', 'roles', 'origins']:
            row[key] = sorted(row[key])
        path = Path(row['path'])
        reason = None
        if not path.is_file():
            reason = 'missing-saved-reference'
        elif path.is_symlink():
            reason = 'symlink-not-collected'
        elif path.suffix in ['.olean', '.ilean', '.ir', '.c', '.o', '.a', '.so'] or '.lake' in path.parts:
            reason = 'prebuilt-artifact-pin-only'
        else:
            row['size_bytes'] = path.stat().st_size
            if row['size_bytes'] > 16 * MIB:
                reason = 'over-16MiB; original pin only; not read or rehashed'
            elif any(token in path.name.lower() for token in ['original-exprs', 'environment-export', 'full-export']):
                reason = 'large-source-export-family; original pin only; not read or rehashed'
            elif ('config' in path.name.lower() or 'small-query-config' in row['roles']) and row['size_bytes'] > MIB:
                reason = 'embedded-config-over-1MiB; original pin only; not traversed'
            elif 'source-view' in row['roles'] and row['size_bytes'] > 512 * 1024:
                reason = 'source-view-over-512KiB; finite selection; original pin only'
            elif row['priority'] >= 4 and row['size_bytes'] > 2 * MIB:
                reason = 'support-report-over-2MiB; dossier summary and original pin retained'
            elif total + row['size_bytes'] > PAYLOAD_LIMIT:
                reason = '120MiB-payload-budget; dossier summary and original pin retained'
        if reason:
            row['reason'] = reason
            row['original_pins'] = row.pop('pins')
            exclusions.append(row)
        else:
            total += row['size_bytes']
            selected.append(row)
    selected_paths = {row['path'] for row in selected}
    exclusions = [row for row in exclusions if not (row.get('reason', '').startswith('historical-input-pin') and row['path'] in selected_paths)]
    summary = {'selected_files': len(selected), 'payload_bytes': total, 'excluded_references': len(exclusions), 'input_limit_bytes': INPUT_LIMIT}
    if args.plan:
        print(json.dumps(summary, indent=2))
        return
    destination.mkdir(parents=False)
    archive_path = destination / 'local-basic34-main5-173-private3.tar.gz'
    manifest = {
        'schema': 'compact-LOCAL-basic34-main5-evidence-archive/v1',
        'scope': 'LOCAL SOURCE-relative; saved mathematical dossier outcomes only',
        'basic_local_named_complete': 34, 'main5_local_selected_named': 173,
        'main5_private_proofs': 3, 'main5_current_owned': 176,
        'fresh_owned_inventory_job': 'ci-017117-e744b85b',
        'platformpending2': 2,
        'platformpending2_scope': 'upstream obligations reported by root; this archive grants no platform acceptance',
        'platformAccepted': False, 'platformFinalAcceptance': False, 'publishAllowed': False,
        'S2-04': False, 'S2_04Complete': False, 'canonicalC22Connected': False,
        'root_graph_membership': False, 'mathematical_validation_repeated': False,
        'CIInvoked': False, 'APIInvoked': False, 'GitInvoked': False,
        'GB_or_560MB_exports_read_or_rehashed': False,
        'policy': {'input_limit_bytes': INPUT_LIMIT, 'payload_limit_bytes': PAYLOAD_LIMIT,
                   'single_file_limit_bytes': 16 * MIB, 'config_limit_bytes': MIB,
                   'source_view_limit_bytes': 512 * 1024, 'referenced_configs_recursively_followed': False},
        'files': [], 'excluded_files_and_pin_only_references': exclusions,
    }
    expected = {}
    with tarfile.open(archive_path, 'w:gz') as archive:
        for row in selected:
            path = Path(row['path'])
            # Check size again before reading; no excluded file is read or rehashed.
            if path.stat().st_size != row['size_bytes'] or row['size_bytes'] > 16 * MIB:
                raise SystemExit('Input changed size: ' + str(path))
            data = path.read_bytes()
            sha = digest(data)
            if row['pins'] and any(pin != sha for pin in row['pins']):
                raise SystemExit('Saved pin mismatch: ' + str(path))
            member = ('workspace/' + str(path.relative_to(ROOT))) if path.is_relative_to(ROOT) else ('external/' + str(path).lstrip('/'))
            info = tarfile.TarInfo(member)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
            expected[member] = sha
            manifest['files'].append({**row, 'archive_member': member, 'sha256': sha})
        manifest['payload_bytes'] = total
        manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
        if total + len(manifest_data) > INPUT_LIMIT:
            raise SystemExit('Generated manifest exceeds reserved input budget')
        manifest['total_input_bytes_including_manifest'] = total + len(manifest_data)
        # Re-serialize after the total is inserted; count exact final bytes.
        for _ in range(4):
            manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
            manifest['total_input_bytes_including_manifest'] = total + len(manifest_data)
        manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
        if total + len(manifest_data) > INPUT_LIMIT:
            raise SystemExit('Final manifest exceeds 128MiB input limit')
        info = tarfile.TarInfo('manifest.json')
        info.size, info.mode, info.mtime = len(manifest_data), 0o644, 0
        archive.addfile(info, io.BytesIO(manifest_data))
        expected['manifest.json'] = digest(manifest_data)
    observed = {}
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive.getmembers():
            if not member.isfile() or member.name in observed:
                raise SystemExit('Unexpected or duplicate archive member')
            with archive.extractfile(member) as stream:
                observed[member.name] = digest(stream.read())
    if observed != expected:
        raise SystemExit('Archive member SHA verification failed')
    (destination / 'manifest.json').write_bytes(manifest_data)
    (destination / 'archive-verification.json').write_text(json.dumps({
        'schema': 'tar-member-sha-verification/v1', 'passed': True,
        'archive': str(archive_path), 'member_count': len(expected),
        'all_member_sha256_match': True, 'payload_bytes': total,
        'total_input_bytes': total + len(manifest_data), 'input_limit_bytes': INPUT_LIMIT,
        'mathematical_validation_repeated': False,
    }, indent=2) + '\n')
    print(json.dumps({**summary, 'archive': str(archive_path), 'tar_member_sha_verification': 'passed'}, indent=2))

if __name__ == '__main__':
    main()
