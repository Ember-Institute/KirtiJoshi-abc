ci017887 所缺 `LocalHeightData.height_eq_add` 的完整来源私有化补丁。

把 `PrivateHeightEqAdd.lean.txt` 整块插入 c2 solution 声明之前。该补丁只给原始 lemma 加 private 并恢复适配命名空间；原始类型、完整证明、既有 `L` 参数均不变。父 c2 的 `have hsplit := L.height_eq_add 2 ℓ hℓ2.symm` 逐字保留。不新增平台节点或数学输入。

来源为 `refer/iut/Iut/Implication/PrimeSelection.lean:196–207`。完整 proof（含 `:=`）493 bytes，SHA256 `71c4b952c194c90b7410e0917dadbdb6fe23dd29814b31c2d4120b74204559e6`。`source-map.json` 提供字节位置、字符/字节列、上下文及摘要；`original-context.lean.txt` 含原始 namespace、L、height/heightEq/heightOther 定义；完整源文件副本与原命令另附。

静态源码分析显示：只展开现有 height、heightEq、heightOther 定义，消费 LocalHeightData 的 bad/p/hv/f/deg 字段和 Mathlib 的 Finset 分拆求和、filter/sum congruence、add_div/add_assoc；没有其它待复制的项目 lemma。现有 `Mathlib.Algebra.BigOperators.Ring.Finset` 与父 Definitions 导入已包含所需常量。实际 proof-term 依赖仍以主智能体 MCP-CI 审查为准；原归约查询会自动展开该同模块 private lemma。

未编译，未调用 CI/API/Git，未修改主工作区。
