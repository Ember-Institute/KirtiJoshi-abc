**English**

Fix all the height data and inputs of the target. Put $h=I.h(x)$, $\delta=\delta(d)$, $D=\log\operatorname{Diff}(x)+\log\operatorname{Cond}(x)$ and $C=40\eta_{\mathrm{prm}}+I.B/3$. The three conclusions are

$$\frac h6\leq(1+\epsilon_E(\delta,h))D+C,\qquad \epsilon_E(\delta,h)\leq1,\qquad 0\leq D.$$

The reduction uses the open child Theorem 1.10. The supplied threshold makes $h$ large enough to choose a prime between the stated square-root and logarithmic bounds. The cyclic-subgroup bound rules out a cyclic subgroup at that prime. Splitting the local height into the contributions at $2$, at the chosen prime, and away from both proves that a suitable bad place remains.

The supplied P7 existence input then produces the initial data and invariants together with their arithmetic certificate, local estimates and the required height, different and conductor comparisons. The universal Corollary 3.12 hypothesis applies to that same data. Apply the open Theorem 1.10 to those inputs and use the accepted numerical estimates to obtain the first conclusion with the stated constant. The threshold also gives the second conclusion. The remaining different and conductor comparisons give the third. All original existence and identity hypotheses remain explicit; this reduction does not construct them.

**简体中文**

固定目标中的全部高度资料和输入。记 $h=I.h(x)$、$\delta=\delta(d)$、$D=\log\operatorname{Diff}(x)+\log\operatorname{Cond}(x)$、$C=40\eta_{\mathrm{prm}}+I.B/3$。三个结论为

$$\frac h6\leq(1+\epsilon_E(\delta,h))D+C,\qquad \epsilon_E(\delta,h)\leq1,\qquad 0\leq D.$$

归约使用开放子节点定理 1.10。给定阈值保证高度足够大，可以在指定的平方根下界与对数上界之间选择一个素数。循环子群估计排除该素数对应的循环子群；把局部高度拆成素数二、所选素数及其余处的贡献，可证明仍存在适用的坏处。

随后，给定的第七项存在性输入产生同一组初始资料和不变量，以及算术证书、局部估计和所需的高度、不同理想及导子比较。全称的推论 3.12 假设适用于这组资料。将开放的定理 1.10 应用于这些输入，再使用已证明的数值估计，得到具有指定常数的第一项结论。阈值同时给出第二项结论，其余不同理想和导子比较给出第三项结论。原有存在性及身份假设均保留为显式输入，本归约不构造它们。

**日本語**

目標に現れるすべての高さのデータと入力を固定し、$h=I.h(x)$、$\delta=\delta(d)$、$D=\log\operatorname{Diff}(x)+\log\operatorname{Cond}(x)$、$C=40\eta_{\mathrm{prm}}+I.B/3$ と置く。三つの結論は

$$\frac h6\leq(1+\epsilon_E(\delta,h))D+C,\qquad \epsilon_E(\delta,h)\leq1,\qquad 0\leq D$$

である。帰着には未解決の子命題である定理1.10を用いる。与えられた閾値により高さは十分大きく、指定された平方根の下界と対数の上界の間に素数を選べる。巡回部分群の評価によってその素数に対応する巡回部分群を排除する。局所高さを素数二、選んだ素数、それら以外の素点からの寄与に分けると、必要な悪い素点の存在が従う。

続いて、与えられた第七の存在性入力から、同じ初期データと不変量、それらの算術的証明書、局所評価、および高さ・差積イデアル・導手の比較を得る。全称的に仮定された系3.12はこのデータに適用できる。未解決の定理1.10をこれらの入力に適用し、既証明の数値評価を用いて指定された定数による第一の結論を得る。閾値から第二の結論が従い、残りの差積イデアルと導手の比較から第三の結論が従う。元の存在性と同一性の仮定はすべて明示的な入力として残り、この帰着はそれらを構成しない。
