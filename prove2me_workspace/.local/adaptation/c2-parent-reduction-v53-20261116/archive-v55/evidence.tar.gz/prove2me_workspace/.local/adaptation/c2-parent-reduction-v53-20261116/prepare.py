from pathlib import Path
import json, hashlib, re, shutil
D=Path('/home/admin-wsl/Coq/abc/prove2me_workspace/.local/adaptation/c2-parent-reduction-v53-20261116'); W=Path('/home/admin-wsl/Coq/abc/prove2me_workspace'); A=W/'.local/adaptation'; G=A/'main-chain-open-20261116/tools/generated'
for p in ['solution','source','queries','frozen-imports','actual']: (D/p).mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def write(p,x):
 p=D/p; p.parent.mkdir(parents=True,exist_ok=True);p.write_text(x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def pin(p,dest):
 b=p.read_bytes();target=D/dest;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 return {'path':str(p),'sha256':sha(b),'bytes':len(b),'frozenCopy':str(target)}
root='AbcAdaptation.Reference.Iut.Corollary22Inputs.c2'; child='AbcAdaptation.Reference.Iut.Theorem110Invariants.theorem110'
solmod='Solutions.Sol_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2'; solfile='solution/Sol_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2.lean'
meta=json.loads((G/'metadata/Iut_Corollary22Inputs_c2.json').read_text()); hm=json.loads((G/'metadata/Iut_Theorem110Invariants_eStar_cast.json').read_text())
src=Path(meta['originalCoordinateSource']).read_bytes(); bmap=meta['oracleOriginalBodyByteMaps'][0]; span=bmap['originalRange']; body=src[span['start']['offset']:span['end']['offset']];assert sha(body)==bmap['sha256']
helper=(G/'OriginalCommands/Iut_Theorem110Invariants_eStar_cast.lean').read_text();helper=helper.strip()+'\n';private='private '+helper
stubpath=W/'Theorems/Thm_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2.lean';stub=stubpath.read_text();signature=stub[stub.index('theorem '+root):stub.index(':= by')].replace('theorem '+root,'theorem solution',1)
accepted=['LocalHeightData.exists_prime_selection','epsilonE_le','log_le_half_of_pos','log_le_self_of_pos','log_bound_ell','log_le_four_mul_sqrt_sqrt','log_ell_bound','p5_height_bound','c2_final'];accepted=['AbcAdaptation.Reference.Iut.'+x for x in accepted]
regpath=A/'platform-node-registry.json';reg=json.loads(regpath.read_text()); nodes={x['name']:x for x in reg['reference_source_preparation']['proved_nodes']}
imports=['Definitions.Def_AbcAdaptation_Reference_Iut_Implication_Corollary22']+['Theorems.Thm_'+x.replace('.','_') for x in accepted+[child]]+['Mathlib.Algebra.BigOperators.Ring.Finset','Mathlib.Analysis.SpecialFunctions.Log.Basic','Mathlib.Analysis.SpecialFunctions.Sqrt','Mathlib.Analysis.Complex.ExponentialBounds','Mathlib.Data.Fintype.BigOperators','Mathlib.Tactic.FieldSimp','Mathlib.Tactic.Linarith','Mathlib.Tactic.NormNum','Mathlib.Tactic.Positivity','Mathlib.Tactic.Push','Mathlib.Tactic.Ring','Mathlib.Tactic.GCongr']
preamble='''/-
Copyright (c) 2026 The iut contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The iut contributors
-/
/- Exact c2 parent reduction draft. theorem110 is the Open semantic child.
   Public helpers refer to accepted platform nodes; this file has no c2 import. -/
'''+''.join('import '+x+'\n' for x in imports)+'''
set_option relaxedAutoImplicit false
set_option maxSynthPendingDepth 3
open scoped BigOperators
open AbcAdaptation.Reference
open AbcAdaptation.Reference.Iut
open Finset Real
universe u v w

namespace AbcAdaptation.Reference.Iut.Theorem110Invariants
variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}
variable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)

'''+private+'''
end AbcAdaptation.Reference.Iut.Theorem110Invariants

'''
solution=preamble+signature+body.decode()+'\n';write(solfile,solution)
assert solution.encode().count(body)==1
rows=[]
for n in accepted+[child]:
 m='Theorems.Thm_'+n.replace('.','_');p=W/(m.replace('.','/')+'.lean')
 row={'name':n,'module':m,'canonicalFile':pin(p,'frozen-imports/'+m.replace('.','/')+'.lean'),'localCanonicalFileContainsSorry':bool(re.search(r'\bsorry\b',p.read_text()))}
 if n in accepted:
  rec=nodes[n];assert rec['verification_status']=='ACCEPTED';row.update(platform=rec,classification='accepted_closed_platform_helper')
 else: row.update(platform={'theorem_id':'93117622-a286-4b02-b27e-5b4c98818d07','status':'Open'},classification='open_semantic_child')
 rows.append(row)
write('dependencies.json',{'schema':'c2-parent-reduction-dependencies/v49','registry':pin(regpath,'source/platform-node-registry.json'),'semanticOpenChildren':[rows[-1]],'acceptedClosedPlatformHelpers':rows[:-1],'privateClosedSourceHelpers':['Iut.Theorem110Invariants.eStar_cast'],'publicImports':imports,'noNewMathematicalParameters':True,'parentInputTelescope':['T','AG','TG','K','d','I','P','hd','ex','cheb','pnt','h312','x','hx','hxe','hH'],'allThreeConjunctsPreserved':True,'runtimeDependencyExtractionStatus':'pending compiled dependency query','localSorryAxExplanation':'Open theorem110 and accepted platform helpers can have local canonical sorry stubs. Classify them by actual platform ID/status; no local sorry-free or closed c2 claim.'})
# Traverse project imports; external Mathlib files are existence-checked, not copied.
seen={};external=set();todo=list(imports)
while todo:
 m=todo.pop()
 if m in seen or m in external:continue
 p=W/(m.replace('.','/')+'.lean')
 if not p.exists():
  external.add(m);continue
 txt=p.read_text();nested=re.findall(r'^import\s+(\S+)',txt,re.M)
 seen[m]={'path':str(p),'sha256':sha(p.read_bytes()),'imports':nested};todo.extend(nested)
for m in seen:
 assert m!='Theorems.Thm_'+root.replace('.','_'),m
 assert not m.startswith(('Iut.','Genl.','ArithmeticTeichmullerSpaces.')),m
mathroot=Path('/home/admin-wsl/Coq/mathlib4-0df444a')
missing=[m for m in external if m.startswith('Mathlib.') and not (mathroot/(m.replace('.','/')+'.lean')).exists()]
assert not missing,missing
write('static-import-audit.json',{'schema':'c2-static-import-audit/v49','compiled':False,'parentImportAbsent':True,'originalProjectImportsAbsent':True,'projectModuleClosure':seen,'externalModules':sorted(external),'missingExternalMathlibSourceModules':missing})
hb=helper.split(':=',1)[1];pb=private.split(':=',1)[1]
write('private-source-map.json',[{'sourceName':'Iut.Theorem110Invariants.eStar_cast','sourceCommand':pin(G/'OriginalCommands/Iut_Theorem110Invariants_eStar_cast.lean','source/Iut_Theorem110Invariants_eStar_cast.lean'),'sourceMetadata':pin(G/'metadata/Iut_Theorem110Invariants_eStar_cast.json','source/Iut_Theorem110Invariants_eStar_cast.metadata.json'),'originalCoordinateSource':pin(Path(hm['originalCoordinateSource']),'source/Invariants.normalized.lean'),'sourceRange':hm['originalRange'],'sourceBodyRanges':hm['proofAndDefinitionBodyRanges'],'sourceBodyHashesFromParser':hm['originalBodyHashes'],'sourceExactCommand':helper,'targetExactCommand':private,'targetDeclarationLine':solution[:solution.index(private)].count('\n')+1,'targetHeaderContext':'variable {AG : AnabelianGeometry.{u}} {TG : TemperedGeometry AG}\nvariable {X : Corollary312VariantData.{u, v} AG TG} (inv : Theorem110Invariants X)','proofBodyByteIdenticalAfterColonEquals':hb==pb,'bodySHA256AfterColonEquals':sha(hb.encode()),'edits':[{'kind':'visibility','before':'lemma','after':'private lemma'}]}])
write('source/root-source.json',{'sourceName':'Iut.Corollary22Inputs.c2','targetName':'solution','expectedParentName':root,'originalCoordinateSource':pin(Path(meta['originalCoordinateSource']),'source/Corollary22.normalized.lean'),'originalCommand':pin(G/'OriginalCommands/Iut_Corollary22Inputs_c2.lean','source/Iut_Corollary22Inputs_c2.lean'),'metadata':pin(G/'metadata/Iut_Corollary22Inputs_c2.json','source/Iut_Corollary22Inputs_c2.metadata.json'),'canonicalParentStub':pin(stubpath,'source/canonical-parent-stub.lean'),'sourceBodyRange':span,'sourceBodySHA256':sha(body),'sourceBodyBytes':len(body),'solutionBodyStartByte':len((preamble+signature).encode()),'proofBodyByteExact':True,'sourceTypeFacts':pin(A/'c2-open-v48-20261116/actual/source-type.json','source/source-type.json'),'targetTypeAuditFacts':pin(A/'c2-open-v48-20261116/actual/target-type-audit.json','source/target-type-audit.json'),'receiptInterpretation':'Files pinned only; CI acceptance is established by main agent receipts.'})
write('adaptation-differences.json',{'schema':'c2-parent-reduction-adaptation-differences/v49','mainProofBody':{'byteExact':True,'bytes':len(body),'sha256':sha(body),'edits':[]},'signature':{'canonicalParentSignatureExactExceptDeclarationName':True,'originalAmbientDataBindersMadeExplicitInCanonicalParent':True,'additionalMathematicalInputs':[],'binderCountExpected':16,'conjunctCountExpected':3},'fileLevelEdits':['Use adapted Definitions and real canonical Theorems imports','Move source eStar_cast into private complete helper with original proof','Change parent declaration name to top-level solution','Retain canonical parent full signature and complete original source body'],'privateHelperProofChanges':[]})
# Reuse proven audit support code through canonicalLevels, before source-specific TYPE decoding.
base=(A/'c2-open-v48-20261116/target/AuditOpenStatementType.lean').read_text()
support=base[:base.index('abbrev TypeNames')].replace('import Theorems.Thm_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2','import '+solmod+'\nimport Theorems.Thm_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2',1)
# support has FoundationAudit reopened and is intentionally continued by the final audit.
write('queries/audit-support-prefix.lean.txt',support)
write('queries/dependency-audit.config.json',{'schema':'c2-parent-reduction-dependency-audit/v49','expectedCompiler':'4.33.1','root':'solution','rootModule':solmod,'forbiddenParent':root,'openChild':child,'expectedTopLevelBinders':16,'expectedConjuncts':3,'requireEveryClassifiedPublicProofConsumed':True,'publicProofs':[{'name':r['name'],'module':r['module'],'theoremId':r['platform']['theorem_id'],'status':'Open' if r['name']==child else 'ACCEPTED','classification':r['classification']} for r in rows],'outputFile':str(D/'actual/reduction-audit.json')})
write('queries/install-map.json',{'solutionSource':str(D/solfile),'solutionDestination':str(W/'Solutions'/Path(solfile).name),'querySource':str(D/'queries/QueryC2ReductionAudit.lean'),'configSource':str(D/'queries/dependency-audit.config.json'),'structuredEnvironment':{'C2_REDUCTION_AUDIT_CONFIG':str(D/'queries/dependency-audit.config.json')},'status':'draft paths; main agent selects final installed query/config/output paths'})
print(json.dumps({'directory':str(D),'solutionSHA256':sha(solution.encode()),'mainProofSHA256':sha(body),'projectImportModules':len(seen),'acceptedHelpers':len(accepted),'localSorryHelpers':[r['name'] for r in rows if r['localCanonicalFileContainsSorry']]},ensure_ascii=False,indent=2))
