这是 c2 ← theorem110 的完整父归约草稿。只写入本临时目录；未编译，未调用 CI、API 或 Git，未修改主工作区。

入口：`solution/Sol_AbcAdaptation_Reference_Iut_Corollary22Inputs_c2.lean`。顶层 `solution` 完整复制当前 c2 父 stub 类型，仅改声明名；16 个输入绑定、`ex` 与通用 `h312`、原有高度与非例外条件、三个合取结论均保留。主证明体（含 `:= by`）与源 AST 字节区间完全相同：8744 bytes，SHA256 `83bddd1fd1bf35e6f686af71d2e7b62e6f1d8496624fc226dffa74112609960d`。

主证明实际从 `ex.thetaData` 提取 X、inv、cert、est 及比较条件，调用 `inv.theorem110 cert est pnt (h312 X hPX)`，再消费数值归并 `c2_final`。没有新增数学输入，没有把父结论作为输入。唯一语义 Open 子节点为 theorem110，平台 ID `93117622-a286-4b02-b27e-5b4c98818d07`。其余九项公开辅助定理均引用 registry 的真实 ACCEPTED 节点与当前 canonical 文件；详见 `dependencies.json`。

唯一内部完整辅助是私有 `Theorem110Invariants.eStar_cast`。其原始证明未改，只有 private 可见性和原有继承参数上下文的显式恢复。源码范围、命令、proof hashes 与目标行号见 `private-source-map.json`。`source/root-source.json` 固定原始坐标文件、父 stub、源 TYPE facts、目标 TYPE facts 的字节摘要；facts 文件的存在不替代主智能体检查对应 CI 回执。`adaptation-differences.json` 和 `source/consumption-map.json` 区分逐字主证明、文件层适配与静态引用位置。

静态递归导入闭包包含 44 个项目模块，没有父 c2、原项目 Iut/Genl 模块或父导入循环。Mathlib 导入源文件均存在，没有使用当前工具链中不存在的 `Mathlib.Tactic.Omega`。这只是静态检查，Lean 兼容性仍待验收。

`queries/QueryC2ReductionAudit.lean` 与 `queries/dependency-audit.config.json` 供主智能体整合后通过 MCP-CI 编译。查询使用 Lean 4.33 的 `env.header.moduleNames`，验证：安装源码与固定文本相同；solution/父 stub 完整 kernel TYPE 与 BinderInfo 位置一致；16 绑定和三个结论；展开 solution 同模块 private/generated 辅助；无直接 sorryAx、无父 c2 引用、无未分类 Theorems 依赖；Open theorem110 与九个 ACCEPTED helper 均被实际消费；输出本地公理闭包。父 c2 仅为 TYPE 比较导入，查询不读取其证明值。结构化环境变量为 `C2_REDUCTION_AUDIT_CONFIG`。整合时需同步配置中的安装路径、expectedSolutionText 与 outputFile；参考 `queries/install-map.json`。

当前本地 canonical 的 exists_prime_selection、log_le_half_of_pos、log_bound_ell、c2_final 仍是 sorry stub，但对应平台证明已 ACCEPTED；theorem110 本身是预期 Open。因此本地 solution 公理闭包可能含 sorryAx。本归约不等于封闭 c2 证明，不能把这些本地 stub 当作新的平台 Open 债务，也不能据此宣称 c2 已闭合。

主智能体下一步：整合并按项目纪律完成叶检查与 compiled TYPE/实际消费审查，再按当前授权进行平台归约提交。`artifact-manifest.json` 固定本包文件；`static-validation.json` 明确当前验收范围。
